//
//  Patient.swift
//  CoreDataMRDemo
//
//  Created by Viral Narshana on 10/28/16.
//  Copyright © 2016 ISM. All rights reserved.
//

import UIKit
import CoreData

@objc(Patient)

class Patient: NSManagedObject {
    @NSManaged var name: String
}
