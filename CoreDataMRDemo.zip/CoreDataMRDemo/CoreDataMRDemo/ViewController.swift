//
//  ViewController.swift
//  CoreDataMRDemo
//
//  Created by Viral Narshana on 10/26/16.
//  Copyright © 2016 ISM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var objPatient: [Patient]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        objPatient = Patient.MR_findAll() as! [Patient]
        
        print("count  " + " \(objPatient.count)")
        
        for index in 0...objPatient.count-1 {
            let objTemp = objPatient[index]
            print(objTemp.name)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
        
    }


}

