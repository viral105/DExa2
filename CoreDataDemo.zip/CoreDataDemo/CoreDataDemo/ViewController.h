//
//  ViewController.h
//  CoreDataDemo
//
//  Created by Viral Narshana on 9/16/16.
//  Copyright © 2016 ISM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface ViewController : UIViewController

@property (nonatomic,strong) NSMutableArray *arrStudents;
@end

