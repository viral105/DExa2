//
//  ViewController.m
//  CoreDataDemo
//
//  Created by Viral Narshana on 9/16/16.
//  Copyright © 2016 ISM. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSManagedObjectContext *objManagedContext = [self managedObjectContext];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Student"];
    
    NSPredicate *predicate=[NSPredicate predicateWithFormat:@"name==\"asd\""]; // If required to fetch specific vehicle
    fetchRequest.predicate=predicate;
    self.arrStudents = [[objManagedContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
/*
 Delete
    for (NSManagedObject *managedObject in self.arrStudents) {
        [objManagedContext deleteObject:managedObject];
    }
*/
    
/* 
 Update
    NSManagedObject *objNew = [self.arrStudents objectAtIndex:0];
    [objNew setValue:@"jkl" forKey:@"school"];
    
    NSError *error = nil;
    if (![objManagedContext save:&error]) {
        NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
    }
*/
    [self save:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    
    
}
- (IBAction)save:(id)sender {
    NSManagedObjectContext *context = [self managedObjectContext];
    
    
        // Create a new device
        NSManagedObject *newDevice = [NSEntityDescription insertNewObjectForEntityForName:@"Student" inManagedObjectContext:context];
        [newDevice setValue:@"abc" forKey:@"name"];
        [newDevice setValue:@"xyz" forKey:@"school"];
        [newDevice setValue:@"pqr" forKey:@"std"];
    
    
    NSError *error = nil;
    // Save the object to persistent store
    if (![context save:&error]) {
        NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (NSManagedObjectContext *)managedObjectContext
{
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    return context;
}
@end
