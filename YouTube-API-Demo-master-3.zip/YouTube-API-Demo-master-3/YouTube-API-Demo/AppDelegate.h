//
//  AppDelegate.h
//  YouTube-API-Demo
//
//  Created by Nirbhay Agarwal on 18/04/14.
//  Copyright (c) 2014 Nirbhay Agarwal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
