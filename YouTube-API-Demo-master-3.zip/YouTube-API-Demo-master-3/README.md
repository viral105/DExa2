YouTube-API-Demo
================

An app to demonstrate integration of YouTube API for iOS. 

Note: This demo will not directly run on your machine unless the proper configurations are made. 
Please visit http://nsrover.wordpress.com/2014/04/23/youtube-api-on-ios/ to learn how to configure.

