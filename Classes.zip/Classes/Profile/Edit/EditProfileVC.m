//
//  EditProfileVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 8/4/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "EditProfileVC.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "MBProgressHUD.h"


@interface EditProfileVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
    BOOL isProfileImageChaged;
}


@end

@implementation EditProfileVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];

	[self performSelector:@selector(LoadViewSettings)];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    appDelegate.currentVc = self;
}

-(void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
    appDelegate.isShouldShowReplyPopUp = NO;
	//[self removeObjectDependancy];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark	Method

-(void)LoadViewSettings{
	
	self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:Blue_BG]];
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:30];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
	
	[self.btnSave.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnSave setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
	
	[self.tfDisplayName setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.tfDisplayName setTextColor:UIColorFromRGB(0X585f66)];
    
    [self.tfMaidenName setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [self.tfMaidenName setTextColor:UIColorFromRGB(0X585f66)];
	
	[self.tfPassword setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.tfPassword setTextColor:UIColorFromRGB(0X585f66)];
	
	[self.tfEmail setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.tfEmail setTextColor:UIColorFromRGB(0X585f66)];
	
	[self.tfMobileNo setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.tfMobileNo setTextColor:UIColorFromRGB(0X585f66)];
	
	[self.tfDisplayName setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
    [self.tfMaidenName setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
	[self.tfEmail setValue:UIColorFromRGB(0X585f66)		forKeyPath:@"_placeholderLabel.textColor"];
	[self.tfPassword setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
	[self.tfMobileNo setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
	
    [self.btnGender.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [self.btnGender setTintColor:UIColorFromRGB(0X585f66)];
    
    [self.btnDOB.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [self.btnDOB setTintColor:UIColorFromRGB(0X585f66)];
    
    
    [self.btnAnnivarsaryDate.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [self.btnAnnivarsaryDate setTintColor:UIColorFromRGB(0X585f66)];
    
    [self.btnProfilePrivacy.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [self.btnProfilePrivacy setTintColor:UIColorFromRGB(0X585f66)];
    
//	self.scrollContainer.contentSize = CGSizeMake(self.scrollContainer.contentSize.width, 400);
//	self.scrollContainer.scrollEnabled = FALSE;
	
    self.scrollContainer.contentSize = CGSizeMake(self.scrollContainer.contentSize.width, self.btnProfilePrivacy.frame.origin.y+self.btnProfilePrivacy.frame.size.height+40);
	self.scrollContainer.scrollEnabled = YES;
    self.selectedGender = 1;
    [self.btnGender setTitle:GenderMale forState:UIControlStateNormal];
    
	
	self.img_UserProfileImg.layer.borderColor = [UIColor whiteColor].CGColor;
	self.img_UserProfileImg.layer.borderWidth = 1;

	[Validation setCorners:self.img_UserProfileImg];
	[self.view bringSubviewToFront:self.img_UserProfileImg];

	[self fillProfileValues];
}

-(void)fillProfileValues{
    NSLog(@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]);
	NSString *strDisplayName = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_DISPLAY_NAME]];
    NSString *strMaidenName = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_MAIDEN_NAME]];
    NSString *strUserName = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:USER_NAME]];
	NSString *strEmail = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]];
	NSString *strMobileNo = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHONE]];
	NSString *strProfilePicURL = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]];
	NSString *strGender = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_GENDER]];
    self.strDOB = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_DateOfBirth]];
    self.strAnniversary = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_ANNIVERSARY]];
    self.selectedProfile = ([[NSUserDefaults standardUserDefaults] boolForKey:IsPrivate])?1:0;
    
    self.selectedGender = [strGender intValue];
    
	if ([DataValidation checkNullString:strDisplayName].length > 0) {
		self.tfDisplayName.text = strDisplayName;
	}
    if ([DataValidation checkNullString:strMaidenName].length > 0) {
        self.tfMaidenName.text = strMaidenName;
    }
    if ([DataValidation checkNullString:strUserName].length > 0) {
		self.lblTitle.text = strUserName;
	}
	if ([DataValidation checkNullString:strEmail].length > 0) {
		self.tfEmail.text = strEmail;
	}
	if ([DataValidation checkNullString:strMobileNo].length > 0) {
		self.tfMobileNo.text = strMobileNo;
	}
	
	if ([DataValidation checkNullString:strProfilePicURL].length > 0) {
		[self.img_UserProfileImg setImageURL:[NSURL URLWithString:strProfilePicURL]];
	}
	
    self.tfDisplayName.text = [HASHTAG_CHARACTER stringByAppendingFormat:@"%@",self.tfDisplayName.text];
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    
    if ([DataValidation checkNullString:self.strDOB].length > 0) {
        
        NSDate *dtDOB = [NSDate date];
        dtDOB = [df dateFromString:self.strDOB];
        
        NSDateFormatter *df1 = [[NSDateFormatter alloc] init] ;
        [df1 setDateFormat:@"MMM dd, yyyy"];

        [self.btnDOB setTitle:[df1  stringFromDate:dtDOB] forState:UIControlStateNormal];
    }
    
    if ([DataValidation checkNullString:self.strAnniversary].length > 0) {
//        NSDate *dtAnniversary = [NSDate date];
//        dtAnniversary = [df dateFromString:self.strAnniversary];
        
        NSDate *dtDOB = [NSDate date];
        dtDOB = [df dateFromString:self.strAnniversary];
        
        NSDateFormatter *df1 = [[NSDateFormatter alloc] init];
        [df1 setDateFormat:@"MMM dd, yyyy"];
        
        [self.btnAnnivarsaryDate setTitle:[df1  stringFromDate:dtDOB] forState:UIControlStateNormal];

    }
    
    
    switch ([strGender intValue]) {
        case 0:
            strGender = GenderDoNotDisclose;
            break;
        case 1:
            strGender = GenderMale;
            break;
        case 2:
            strGender = GenderFemale;
            break;
            
            
        default:
            break;
    }
    
    [self.btnGender setTitle:strGender forState:UIControlStateNormal];
    
    
    
    [self.btnProfilePrivacy setTitle:(self.selectedProfile==0)?Profile_Public:Profile_Private forState:UIControlStateNormal];

    
	strDisplayName = nil;
	strEmail = nil;
	strMobileNo = nil;
	strProfilePicURL = nil;
    strGender = nil;

}
-(BOOL)compareProfileValues{
    int cntValueChanged = 0;
    NSLog(@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]);
    NSString *strDisplayName = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_DISPLAY_NAME]];
    NSString *strEmail = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]];
    NSString *strMobileNo = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHONE]];
    NSString *strProfilePicURL = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]];
    NSString *strGender = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_GENDER]];
    NSString *strDateOfBirth = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_DateOfBirth]];
    NSString *strAnniversaryDate = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_ANNIVERSARY]];
    int strPrivacyStatus = ([[NSUserDefaults standardUserDefaults] boolForKey:IsPrivate])?1:0;
    
//  Display name
    if ([[DataValidation checkNullString:strDisplayName] isEqualToString:self.tfDisplayName.text] || [[DataValidation checkNullString:self.tfDisplayName.text] isEqualToString:[HASHTAG_CHARACTER stringByAppendingFormat:@"%@",strDisplayName]]) {
        cntValueChanged++;
    }
    
//  Email
    if ([[DataValidation checkNullString:strEmail] isEqualToString:self.tfEmail.text]) {
        cntValueChanged++;
    }

//  Mobile number
    if ([[DataValidation checkNullString:strMobileNo] isEqualToString:self.tfMobileNo.text]) {
        cntValueChanged++;
    }
    
//  profile image
    if (!isProfileImageChaged) {
        cntValueChanged++;
    }
    
//  Password
    if ([DataValidation checkNullString:self.tfPassword.text].length==0) {
        cntValueChanged++;
    }
    
//  Date of birth
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    
    NSDate *dtDOB = [NSDate date];
    dtDOB = [df dateFromString:strDateOfBirth];
    
    NSDateFormatter *df1 = [[NSDateFormatter alloc] init] ;
    [df1 setDateFormat:@"MMM dd, yyyy"];
    NSLog(@"%@ %@ %@",self.btnDOB.currentTitle,strDateOfBirth,[df1  stringFromDate:dtDOB]);
    if ([self.btnDOB.currentTitle isEqualToString:[df1  stringFromDate:dtDOB]] || [self.btnDOB.currentTitle isEqualToString:@"Birthday"]) {
        cntValueChanged++;
    }
    
//  Annivarsary Date
    NSDate *dtAnniDate = [NSDate date];
    dtAnniDate = [df dateFromString:strAnniversaryDate];
    
    NSDateFormatter *df2 = [[NSDateFormatter alloc] init];
    [df2 setDateFormat:@"MMM dd, yyyy"];
    
    if ([self.btnAnnivarsaryDate.currentTitle isEqualToString:[df1  stringFromDate:dtAnniDate]]  || [self.btnAnnivarsaryDate.currentTitle isEqualToString:@"Anniversary Date"]) {
        cntValueChanged++;
    }
//  Gender
    if (self.selectedGender == [strGender intValue]) {
        cntValueChanged++;
    }

//  Privacy Status
    if (strPrivacyStatus==self.selectedProfile) {
        cntValueChanged++;
    }
    
    BOOL isNeedMsgDisplay;
    if (cntValueChanged!=9) {
        NSLog(@"Value Changed. Need to show message");
        isNeedMsgDisplay = YES;
    }
    else{
        NSLog(@"Value Not Changed. Don't show message");
        isNeedMsgDisplay = NO;
    }
    strDisplayName = nil;
    strEmail = nil;
    strMobileNo = nil;
    strProfilePicURL = nil;
    strGender = nil;
    
    return isNeedMsgDisplay;
}
-(void)removeObjectDependancy{
	self.tfDisplayName.text = @"#";
	self.tfPassword.text = @"";
	self.tfEmail.text = @"";
	self.tfMobileNo.text = @"";
    
    [self hideKeyboard];
	
}

-(void)hideKeyboard{
    [self.tfDisplayName resignFirstResponder];
    [self.tfEmail resignFirstResponder];
    [self.tfPassword resignFirstResponder];
    [self.tfMobileNo resignFirstResponder];

}

-(IBAction)btnBackClicked:(id)sender{

    if (self.request!=nil) {
        [self.request cancel];
        self.request = nil;
    }
    if ([self compareProfileValues]) {
        [AlertHandler alertTitle:CONFIRM message:@"Your changes are not saved, are you really want to go back?" delegate:self tag:3 cancelButtonTitle:nil OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:NO_BUTTON_TITLE];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }

//	[self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnSaveClicked:(id)sender{
	
	if (self.request !=nil) {
		self.request = nil;
	}
	
	[self.tfEmail resignFirstResponder];
	
	if ([self checkForValidation]) {
		if (![self.tfEmail.text isEqualToString:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]]) {
			[HUD show:YES];
			NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
								 [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:[DataValidation checkNullString:self.tfEmail.text] isGeneral:TRUE],KeyValue,@"emailID",KeyName, nil],@"1",
								 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"userName",KeyName, nil],@"2",
								 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"facebookID",KeyName, nil],@"3",
								 [NSDictionary dictionaryWithObjectsAndKeys:@"-1",KeyValue,@"IsActive",KeyName, nil],@"4",
								 nil];
			
			NSString *strUrl = [WebServiceContainer getServiceURL:CHECK_USER_EXIST withParameters:nil];
			self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
            if (self.request == nil) {
                [HUD hide:YES];
            }
            else{
                [self.request setDelegate:self];
                [self.request setTag:4];
            }
//			self.request.delegate = self;
//			self.request.tag = 4;
			strUrl = nil;

		}
		else{
			//[Validation showLoadingIndicator];
            [HUD show:YES];
			[self EditProfile];
		}
	}
	else{
//		[Validation showToastMessage:@"Please enter valid\nemail address." displayDuration:ERROR_MSG_DURATION];
	//	[HUD hide:YES];
	}
}

-(IBAction)btnUserProfileImgClicked:(id)sender{
	
	//[self.tfDisplyName resignFirstResponder];
	
	UIActionSheet *actionCameraOption = [[UIActionSheet alloc] initWithTitle:@"Options" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:@"Camera",@"Library", nil];
	
	[actionCameraOption showInView:self.view];
	
}

-(void)EditProfile{
	NSString *strDisplayName = [DataValidation checkNullString:self.tfDisplayName.text];
	NSString *strPWD = [DataValidation checkNullString:self.tfPassword.text];
	NSString *strEmail = [DataValidation checkNullString:self.tfEmail.text];
	NSString *strPhone = [DataValidation checkNullString:self.tfMobileNo.text];
    NSString *strMaidenName = [DataValidation checkNullString:self.tfMaidenName.text];
	
    if ([strDisplayName hasPrefix:HASHTAG_CHARACTER]) {
        strDisplayName = [strDisplayName substringFromIndex:1];
    }
    
	
	NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
						  [NSDictionary dictionaryWithObjectsAndKeys:strDisplayName,KeyValue,@"Name",KeyName, nil],@"1",
						  [NSDictionary dictionaryWithObjectsAndKeys:strPhone,KeyValue,@"Phone",KeyName, nil],@"2",
						  [NSDictionary dictionaryWithObjectsAndKeys:strEmail,KeyValue,@"Email",KeyName, nil],@"3",
						  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"UserName",KeyName, nil],@"4",
						  [NSDictionary dictionaryWithObjectsAndKeys:strPWD,KeyValue,@"Pwd",KeyName, nil],@"5",
						  [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:self.strDOB].length>0)?self.strDOB:@"",KeyValue,@"DateOfBirth",KeyName, nil],@"6",
						  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.selectedGender],KeyValue,@"Gender",KeyName, nil],@"7",
						  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"ID",KeyName, nil],@"8",
						  [NSDictionary dictionaryWithObjectsAndKeys:((self.img_UserProfileImg.image!= nil)?self.img_UserProfileImg.image:@""),KeyValue,@"ImgData",KeyName, nil],@"9",
						  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"FacebookID",KeyName, nil],@"10",
                          [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:self.strAnniversary].length>0)?self.strAnniversary:@"",KeyValue,@"AnniversaryDate",KeyName, nil],@"11",
                          [NSDictionary dictionaryWithObjectsAndKeys:(self.selectedProfile==0)?@"false":@"true",KeyValue,@"IsPrivate",KeyName, nil],@"12",
                          [NSDictionary dictionaryWithObjectsAndKeys:strMaidenName,KeyValue,@"MaidenName",KeyName, nil],@"13",
						  nil];
	NSString *strUrl = [WebServiceContainer getServiceURL:EDIT_USER_PROFILE withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:3];
    }
//	request.delegate = self;
//	request.tag = 3;
	strUrl = nil;
	
	strPhone = nil;
	strPWD = nil;
	strDisplayName = nil;
	strEmail = nil;

}

-(void)ShowCamera{
	self.imagePicker = [[UIImagePickerController alloc] init];
	
	self.imagePicker.delegate = self;
	
	self.imagePicker.sourceType =
	UIImagePickerControllerSourceTypeCamera;
	
	self.imagePicker.allowsEditing = YES;
	[self presentViewController:self.imagePicker
					   animated:YES completion:nil];
}
-(void)ShowLibrary{
	if ([ALAssetsLibrary authorizationStatus] == ALAuthorizationStatusDenied) {
		[AlertHandler alertTitle:MESSAGE message:ALERT_FOR_PHOTO_LIBRARY_ACCESS delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else{
		self.imagePicker = [[UIImagePickerController alloc] init];
		
		self.imagePicker.delegate = self;
		
		self.imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
		
		self.imagePicker.allowsEditing = YES;
		[self presentViewController:self.imagePicker
						   animated:YES completion:nil];
		
	}
}
-(void)hideImagePicker{
	[self.imagePicker dismissViewControllerAnimated:YES completion:nil];
}

-(BOOL)checkForValidation{
	
	/*
//	if ([DataValidation checkNullString:self.tfDisplayName.text].length==0) {
//		[HUD hide:YES];
//		[Validation showToastMessage:@"Please enter valid\nusername."];
//		return FALSE;
//	}
//	else
	 */
	if ([DataValidation checkNullString:self.tfEmail.text].length == 0 ) {
		[HUD hide:YES];
		[Validation showToastMessage:@"Please enter valid\nemail address." displayDuration:ERROR_MSG_DURATION];
		[Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
		return FALSE;
	}
	else if (![DataValidation validateEmailWithString:self.tfEmail.text]){
		[HUD hide:YES];
		[Validation showToastMessage:@"Please enter valid\nemail address." displayDuration:ERROR_MSG_DURATION];
		[Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
		return FALSE;
	}
	else if ([DataValidation checkNullString:self.tfMobileNo.text].length > 0 && ![DataValidation CheckNumericOnly:self.tfMobileNo.text]){
//		if(![DataValidation CheckNumericOnly:self.tfMobileNo.text]){
			[HUD hide:YES];
			[Validation showToastMessage:@"Please enter valid\ncontact number." displayDuration:ERROR_MSG_DURATION];
			[Validation highLightTextField:self.tfMobileNo inView:self.scrollContainer];
			return FALSE;
//		}
    }
    else if ([DataValidation checkNullString:self.tfMobileNo.text].length > 0 && !([self.tfMobileNo.text length] >= 10 && self.tfMobileNo.text.length <= 15)){
//    else if (self.tfMobileNo.text.length != 0) {
	//		if (!([self.tfMobileNo.text length] >= 10 && self.tfMobileNo.text.length <= 15)){
				[HUD hide:YES];
				[Validation showToastMessage:@"Contact number must be of 10-15 digit." displayDuration:ERROR_MSG_DURATION];
				[Validation highLightTextField:self.tfMobileNo inView:self.scrollContainer];
				return FALSE;
			}
//		}
//		else return TRUE;
//	}
    else if (([DataValidation checkNullString:self.tfPassword.text].length != 0) &&([DataValidation checkNullString:self.tfPassword.text].length < 6 || [DataValidation checkNullString:self.tfPassword.text].length > 30)){
        [HUD hide:YES];
		[Validation showToastMessage:@"Please enter passowrd\nminimum of 6 and maximum of 30 characters." displayDuration:ERROR_MSG_DURATION];
		[Validation highLightTextField:self.tfPassword inView:self.scrollContainer];
        return FALSE;
    }
	/*
//	else if ([DataValidation checkNullString:self.tfPassword.text].length==0) {
//		[HUD hide:YES];
//		[Validation showToastMessage:@"Please enter\npassowrd."];
//		return FALSE;
//	}
//	else if ([DataValidation checkNullString:self.tfMobileNo.text].length == 0){
//		[HUD hide:YES];
//		[Validation showToastMessage:@"Please enter\nmobile number."];
//		return FALSE;
//	}
//	else if(![DataValidation CheckNumericOnly:self.tfMobileNo.text]){
//		[HUD hide:YES];
//		[Validation showToastMessage:@"Please enter valid\nmobile number."];
//		return FALSE;
//	}
	 */
	else{
		return TRUE;
	}
	return TRUE;
}


-(IBAction)btnAnniversaryClicked:(id)sender{
    
    self.selectedBtnForDate = (int)((UIButton *)sender).tag;
    
    if (self.objPkrView != nil) {
		[self.objPkrView.view removeFromSuperview];
        [self.objPkrView removeFromParentViewController];
        self.objPkrView.delegate = nil;
        self.objPkrView = nil;
	}
	
//	UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
	self.objPkrView = [MainStoryboard instantiateViewControllerWithIdentifier:SHOW_PKR_VC];
	self.objPkrView.delegate = self;
    self.objPkrView.view.frame = self.view.frame;
    [self.objPkrView setPickerView:2];
    [self.view addSubview:self.objPkrView.view];
    [self.objPkrView didMoveToParentViewController:self];
    [self addChildViewController:self.objPkrView];
    self.objPkrView.view.alpha = 0.0f;
    
//    self.objPkrView.arrData = [NSArray arrayWithObjects:GenderDoNotDisclose,GenderMale,GenderFemale, nil];
//    [self.objPkrView.pkr reloadAllComponents];
//    [self.objPkrView.pkr selectRow:self.selectedGender inComponent:0 animated:NO];
    
    
    
    [UIView beginAnimations:nil context:NULL];
    //[UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.5];
    self.objPkrView.view.alpha = 1.0f;
    [UIView commitAnimations];
}

-(IBAction)btnDOBClicked:(id)sender{
    
    self.selectedBtnForDate = (int)((UIButton *)sender).tag;
    
    if (self.objPkrView != nil) {
		[self.objPkrView.view removeFromSuperview];
        [self.objPkrView removeFromParentViewController];
        self.objPkrView.delegate = nil;
        self.objPkrView = nil;
	}
	
//	UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
	self.objPkrView = [MainStoryboard instantiateViewControllerWithIdentifier:SHOW_PKR_VC];
	self.objPkrView.delegate = self;
    self.objPkrView.view.frame = self.view.frame;
    [self.objPkrView setPickerView:1];
    [self.view addSubview:self.objPkrView.view];
    [self.objPkrView didMoveToParentViewController:self];
    [self addChildViewController:self.objPkrView];
    self.objPkrView.view.alpha = 0.0f;
    
//    self.objPkrView.arrData = [NSArray arrayWithObjects:GenderDoNotDisclose,GenderMale,GenderFemale, nil];
//    [self.objPkrView.pkr reloadAllComponents];
//    [self.objPkrView.pkr selectRow:self.selectedGender inComponent:0 animated:NO];
    
    [UIView beginAnimations:nil context:NULL];
    //[UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.5];
    self.objPkrView.view.alpha = 1.0f;
    [UIView commitAnimations];
}


-(IBAction)btnGenderClicked:(id)sender{
    
    if (self.objPkrView != nil) {
		[self.objPkrView.view removeFromSuperview];
        [self.objPkrView removeFromParentViewController];
        self.objPkrView.delegate = nil;
        self.objPkrView = nil;
	}
	
//	UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
	self.objPkrView = [MainStoryboard instantiateViewControllerWithIdentifier:SHOW_PKR_VC];
	self.objPkrView.delegate = self;
    self.objPkrView.view.frame = self.view.frame;
    [self.objPkrView setPickerView:0];
    [self.view addSubview:self.objPkrView.view];
    [self.objPkrView didMoveToParentViewController:self];
    [self addChildViewController:self.objPkrView];
    self.objPkrView.view.alpha = 0.0f;
    
    self.objPkrView.arrData = [NSArray arrayWithObjects:GenderDoNotDisclose,GenderMale,GenderFemale, nil];
    [self.objPkrView.pkr reloadAllComponents];
    [self.objPkrView.pkr selectRow:self.selectedGender inComponent:0 animated:NO];
    
    [UIView beginAnimations:nil context:NULL];
    //[UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.5];
    self.objPkrView.view.alpha = 1.0f;
    [UIView commitAnimations];
}

-(IBAction)btnPrivacyClicked:(id)sender{
    
    if (self.objPkrView != nil) {
		[self.objPkrView.view removeFromSuperview];
        [self.objPkrView removeFromParentViewController];
        self.objPkrView.delegate = nil;
        self.objPkrView = nil;
	}
	
//	UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
	self.objPkrView = [MainStoryboard instantiateViewControllerWithIdentifier:SHOW_PKR_VC];
	self.objPkrView.delegate = self;
    self.objPkrView.view.frame = self.view.frame;
    [self.objPkrView setPickerView:3];
    [self.view addSubview:self.objPkrView.view];
    [self.objPkrView didMoveToParentViewController:self];
    [self addChildViewController:self.objPkrView];
    self.objPkrView.view.alpha = 0.0f;
    
    self.objPkrView.arrData = [NSArray arrayWithObjects:Profile_Public,Profile_Private, nil];
    [self.objPkrView.pkr reloadAllComponents];
    [self.objPkrView.pkr selectRow:self.selectedProfile inComponent:0 animated:NO];
    
    
    
    [UIView beginAnimations:nil context:NULL];
    //[UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.5];
    self.objPkrView.view.alpha = 1.0f;
    [UIView commitAnimations];
}

- (void)doneDTPButton{
    NSDate *dt = [self.objPkrView.pkr date];
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init] ;
	[df setDateFormat:@"MM/dd/yyyy"];
	NSString *strDate = [df stringFromDate:dt];
  
    NSDateFormatter *df1 = [[NSDateFormatter alloc] init] ;
	[df1 setDateFormat:@"MMM dd, yyyy"];

    if (self.selectedBtnForDate == 2) {
        //birthdate
        [self.btnDOB setTitle:[df1 stringFromDate:dt] forState:UIControlStateNormal];
        self.strDOB = strDate;
    }
    else if (self.selectedBtnForDate == 3){
        //anniversary
        self.strAnniversary = strDate;
        [self.btnAnnivarsaryDate setTitle:[df1 stringFromDate:dt] forState:UIControlStateNormal];
    }
    
//    NSLog(@"date = %@",strDate);
    [self hidePicker];
}

- (void)doneButton:(id)callerId{
    
    if ([callerId intValue] == 0) {
        self.selectedGender = (int)[self.objPkrView.pkr selectedRowInComponent:0];
        NSString *strGender = @"";
        switch (self.selectedGender) {
            case 0:
                strGender = GenderDoNotDisclose;
                break;
            case 1:
                strGender = GenderMale;
                break;
            case 2:
                strGender = GenderFemale;
                break;
            default:
                break;
        }
        [self.btnGender setTitle:strGender forState:UIControlStateNormal];
        
        strGender = nil;
    }
    else if ([callerId intValue] == 3){
        //profile privacy
        self.selectedProfile = (int)[self.objPkrView.pkr selectedRowInComponent:0];
        
        NSString *strProfile = @"";
        switch (self.selectedProfile) {
            case 0:
                strProfile = Profile_Public;
                break;
            case 1:
                strProfile = Profile_Private;
                break;
                
            default:
                break;
        }
        [self.btnProfilePrivacy setTitle:strProfile forState:UIControlStateNormal];
        
        strProfile = nil;
        
    }

    [self hidePicker];
}

-(void)CancelButton{
    [self hidePicker];
}

-(void)hidePicker{
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    self.objPkrView.view.alpha = 0.0f;
    [UIView commitAnimations];
    
    [self performSelector:@selector(removePickerFromView) withObject:nil afterDelay:0.8];
}

-(void)removePickerFromView{
    
    self.objPkrView.delegate = nil;
    [self.objPkrView.view removeFromSuperview];
    [self.objPkrView removeFromParentViewController];
    self.objPkrView = nil;
}

#pragma mark UIActionSheet Delegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
	if (buttonIndex == actionSheet.cancelButtonIndex) {
	}
	else{
		if (buttonIndex == 0) {
			//camera
			if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
			{
				// code here
				[self ShowCamera];
			}
			else{
				[AlertHandler alertTitle:ALERT message:@"Camera not available." delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
			}
		}
		else if (buttonIndex == 1){
			if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
				//code here
				[self ShowLibrary];
			}
			else{
				[AlertHandler alertTitle:ALERT message:@"Library not available." delegate:self tag:2 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
			}
		}
	}
}
#pragma mark	UIAlertView Delegate

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
	if (alertView.tag == 1) {
		//camera not available
		[self hideImagePicker];
	}
	else if (alertView.tag == 2){
		//library not available
		[self hideImagePicker];
	}
    else if (alertView.tag == 3){
        if (buttonIndex==0) {
            [self.navigationController popViewControllerAnimated:NO];
        }
    }
}

#pragma mark UITextField Delegate

-(void)textFieldDidBeginEditing:(UITextField *)textField{
	self.scrollContainer.scrollEnabled = TRUE;
	
	if (textField.tag >2) {
		
		[UIView beginAnimations:@"textFieldPositionUp" context:nil];
        //[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.7];
		
		self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, self.tfEmail.frame.origin.y+10);
		
		[UIView commitAnimations];
	}
	else{
		[UIView beginAnimations:@"textFieldPositionUp" context:nil];
        //[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.5];
		
		self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, self.tfDisplayName.frame.origin.y-6);
		
		[UIView commitAnimations];
	}
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
	
	[Validation resetTextFieldBorderColor];
	if (textField.tag == 1) {
		//username
	}
	else if (textField.tag == 2){
		//email address
		if (self.request !=nil) {
			self.request = nil;
		}
		if (![self.tfEmail.text isEqualToString:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]]) {
			if ([DataValidation checkNullString:self.tfEmail.text].length > 0) {
				if ([DataValidation validateEmailWithString:self.tfEmail.text]){
					//check if email exists
					
					NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
										 [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:[DataValidation checkNullString:self.tfEmail.text] isGeneral:TRUE],KeyValue,@"emailID",KeyName, nil],@"1",
										 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"userName",KeyName, nil],@"2",
										 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"facebookID",KeyName, nil],@"3",
										 [NSDictionary dictionaryWithObjectsAndKeys:@"-1",KeyValue,@"IsActive",KeyName, nil],@"4",
										 nil];
					
					NSString *strUrl = [WebServiceContainer getServiceURL:CHECK_USER_EXIST withParameters:nil];
					self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
                    if (self.request == nil) {
                        [HUD hide:YES];
                    }
                    else{
                        [self.request setDelegate:self];
                        [self.request setTag:2];
                    }
//					self.request.delegate = self;
//					self.request.tag = 2;
					strUrl = nil;
				}
				else{
					[Validation showToastMessage:@"Please enter valid\nemail address." displayDuration:ERROR_MSG_DURATION];
				}
			}
			else{
				[Validation showToastMessage:@"Please enter valid\nemail address." displayDuration:ERROR_MSG_DURATION];
			}
		}
	}
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    NSLog(@"%d",(int)range.location);
    if (textField == self.tfDisplayName) {
        if ([string isEqualToString:@""]) {
            if (range.location==0) {
                return FALSE;
            }
        }
        if (range.location==1 && ![string isEqualToString:@""]) {
            NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"];
            s = [s invertedSet];
            NSRange r = [string rangeOfCharacterFromSet:s];
            if (r.location != NSNotFound) {
                return FALSE;
            }
        }
    }
    else if (textField == self.tfPassword) {
        if (![string isEqualToString:@""]) {
            NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_+"];
            s = [s invertedSet];
            NSRange r = [string rangeOfCharacterFromSet:s];
            if (r.location != NSNotFound) {
                return FALSE;
            }
        }
    }
    else if (textField == self.tfMaidenName) {
        
        if (![string isEqualToString:@""]) {
            NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"];
            s = [s invertedSet];
            NSRange r = [string rangeOfCharacterFromSet:s];
            if (r.location != NSNotFound) {
                return FALSE;
            }
        }
    }
    return TRUE;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
	
	if (textField == self.tfMobileNo) {
		[UIView beginAnimations:@"textFieldPositionDown" context:nil];
        //[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.3];
		self.scrollContainer.scrollEnabled = TRUE;
		[textField resignFirstResponder];
		self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, 0);
		[UIView commitAnimations];
	}
	else if (textField == self.tfDisplayName){
		[self.tfMaidenName becomeFirstResponder];
	}
    else if (textField == self.tfMaidenName){
        [self.tfEmail becomeFirstResponder];
    }
	else if (textField == self.tfEmail){
		[self.tfPassword becomeFirstResponder];
	}
	else if (textField == self.tfPassword){
		[self.tfMobileNo becomeFirstResponder];
	}
	
	
	return TRUE;
}


#pragma  mark	UIImagePickerController Delegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
	self.img_UserProfileImg.image = info[UIImagePickerControllerEditedImage];
	[Validation setCorners:self.img_UserProfileImg];
	
	[self hideImagePicker];
    isProfileImageChaged = YES;
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
	
	[self hideImagePicker];
}

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	
	NSLog(@"response =%@",[request responseString]);

	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];;
	
		NSLog(@"dictionary = %@",dicResponse);
	
	[Validation resetTextFieldBorderColor];
	
    if (dicResponse != nil) {
        if (request.tag == 2){
            //email exists
            if ([dicResponse objectForKey:RESPONSE] != nil) {
                
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    id response = [dicResponse objectForKey:RESPONSE];
                    
                    if ([response isKindOfClass:[NSDictionary class]]) {
                        if (((NSDictionary *)response).count>0) {
                            [Validation showToastMessage:@"Email already exist" displayDuration:ERROR_MSG_DURATION];
                            [Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
                        }
                    }
                    else if ([response isKindOfClass:[NSArray class]]){
                        if (((NSArray *)response).count > 0) {
                            [Validation showToastMessage:@"Email already exist" displayDuration:ERROR_MSG_DURATION];
                            [Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
                        }
                    }
                }
            }
            if ([self.tfMobileNo isFirstResponder] || [self.tfPassword isFirstResponder]) {
                self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, self.tfEmail.frame.origin.y-5);
            }
            self.request = nil;
        }
        else if (request.tag == 4){
            self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, 0);
            BOOL isUserExist = FALSE;
            if ([dicResponse objectForKey:RESPONSE] != nil) {
                
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    id response = [dicResponse objectForKey:RESPONSE];
                    
                    
                    if ([response isKindOfClass:[NSDictionary class]]) {
                        if (((NSDictionary *)response).count>0) {
                            isUserExist = TRUE;
                            [Validation showToastMessage:@"Email already exist" displayDuration:ERROR_MSG_DURATION];
                            [Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
                        }
                    }
                    else if ([response isKindOfClass:[NSArray class]]){
                        if (((NSArray *)response).count > 0) {
                            isUserExist = TRUE;
                            [Validation showToastMessage:@"Email already exist" displayDuration:ERROR_MSG_DURATION];
                            [Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
                        }
                    }
                    
                    
                }
                self.request = nil;
            }
            if (!isUserExist) {
                [self EditProfile];
            }
        }
        else {
            if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                NSLog(@"dic = %@",dicResponse);
                [appDelegate callLogOutService];
            }
            else{
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (request.tag == 3) {
                            if (response != nil) {
                                NSMutableDictionary *dic = nil;
                                if ([[response valueForKey:RESPONSE] isKindOfClass:[NSDictionary class]]) {
                                    dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)response];
                                }
                                else if ([[response valueForKey:RESPONSE] isKindOfClass:[NSArray class]]){
                                    dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[response objectAtIndex:0]];
                                }
                                NSLog(@"di  -%@",dic);
                                
                                if ([DataValidation checkNullString:self.tfPassword.text].length > 0) {
                                    [dic setValue:[DataValidation checkNullString:self.tfPassword.text] forKey:LOGIN_USER_KEY];
                                }
                                [Validation setAllKeyValueFromData:dic];
                                [HUD hide:YES];
                                
                                
                                dic = nil;
                                
                                [self.navigationController popViewControllerAnimated:YES];
                                
                            }
                            
                        }
                        else if (request.tag == 1){
                            //username Exists
                            NSLog(@"resposne = %@",response);
                            if ([response isKindOfClass:[NSDictionary class]]) {
                                if (((NSDictionary *)response).count>0) {
                                    [Validation showToastMessage:@"Username already exist" displayDuration:ERROR_MSG_DURATION];
                                    [Validation highLightTextField:self.tfDisplayName inView:self.scrollContainer];
                                }
                            }
                            else if ([response isKindOfClass:[NSArray class]]){
                                if (((NSArray *)response).count > 0) {
                                    [Validation showToastMessage:@"Username already exist" displayDuration:ERROR_MSG_DURATION];
                                    [Validation highLightTextField:self.tfDisplayName inView:self.scrollContainer];
                                }
                            }
                            self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, self.tfDisplayName.frame.origin.y-5);
                        }
                        else if (request.tag == 2){
                            //email exists
                            if ([response isKindOfClass:[NSDictionary class]]) {
                                if (((NSDictionary *)response).count>0) {
                                    [Validation showToastMessage:@"Email already exist" displayDuration:ERROR_MSG_DURATION];
                                    [Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
                                }
                            }
                            else if ([response isKindOfClass:[NSArray class]]){
                                if (((NSArray *)response).count > 0) {
                                    [Validation showToastMessage:@"Email already exist" displayDuration:ERROR_MSG_DURATION];
                                    [Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
                                }
                            }
                            self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, self.tfEmail.frame.origin.y-5);
                        }
                        
                        response = nil;
                    }
                    self.request = nil;
                }
                else{
                    self.request = nil;
                    [Validation showToastMessage:@"Request failure.\nPlease try again saving." displayDuration:ERROR_MSG_DURATION];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
	dicResponse = nil;
	[HUD hide:YES];

}
//bhavik 13-Feb-2015
#pragma mark - Photo Selected Status bar Color not Change

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

#pragma mark UITouch Methods

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [[event allTouches] anyObject];
    if (![touch.view isKindOfClass:[UIScrollView class]]) {
        [self hideKeyboard];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
