//
//  EditProfileVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/4/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShowPickerVC.h"

@interface EditProfileVC : UIViewController <UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate, UIActionSheetDelegate, UIAlertViewDelegate,ShowPickerVCDelegate>

@property (nonatomic, strong) IBOutlet UITextField		*tfDisplayName;			//name
@property (nonatomic, strong) IBOutlet UITextField		*tfMaidenName;
@property (nonatomic, strong) IBOutlet UITextField		*tfEmail;
@property (nonatomic, strong) IBOutlet UITextField		*tfPassword;
@property (nonatomic, strong) IBOutlet UITextField		*tfMobileNo;

@property (nonatomic, strong) IBOutlet UIButton			*btnDOB;
@property (nonatomic, strong) IBOutlet UIButton			*btnAnnivarsaryDate;
@property (nonatomic, strong) IBOutlet UIButton			*btnGender;

@property (nonatomic, strong) IBOutlet UIButton			*btnSave;
@property (nonatomic, strong) IBOutlet UILabel			*lblTitle;

@property (nonatomic, strong) IBOutlet UIScrollView		*scrollContainer;

@property (nonatomic, strong) IBOutlet UIButton			*btnUserProfileImg;
@property (nonatomic, strong) IBOutlet AsyncImageView	*img_UserProfileImg;
@property (nonatomic, strong) UIImagePickerController	*imagePicker;

@property (nonatomic, strong) ASIHTTPRequest			*request;

@property (nonatomic, readwrite) int                    selectedGender;
@property (nonatomic, strong) ShowPickerVC              *objPkrView;
@property (nonatomic, readwrite) int                    selectedBtnForDate;

@property (nonatomic, strong) NSString                  *strDOB;
@property (nonatomic, strong) NSString                  *strAnniversary;

@property (nonatomic, strong) IBOutlet UIButton			*btnProfilePrivacy;
@property (nonatomic, readwrite) int                    selectedProfile;    //0=public, 1-private


@end
