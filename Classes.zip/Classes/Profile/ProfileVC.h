//
//  ProfileVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/4/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileVC : UIViewController <UIImagePickerControllerDelegate,UINavigationControllerDelegate, UIActionSheetDelegate, UIAlertViewDelegate>

@property (nonatomic, strong) IBOutlet UITextField		*tfDisplyName;
@property (nonatomic, strong) IBOutlet UITextField		*tfMaidenName;
@property (nonatomic, strong) IBOutlet UIButton			*btnUserProfileImg;
@property (nonatomic, strong) IBOutlet UIButton			*btnNext;

@property (nonatomic, strong) IBOutlet AsyncImageView		*img_UserProfileImg;

@property (nonatomic, strong) IBOutlet UILabel			*lblTitle;

@property (nonatomic, readwrite) BOOL					isBackPressed;

@property (nonatomic, strong) UIImagePickerController	*imagePicker;
@property (nonatomic, strong) NSString					*strFBID;
@property (nonatomic, readwrite) BOOL					isFBID_Exists;
@end
