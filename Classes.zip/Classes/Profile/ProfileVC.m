//
//  ProfileVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 8/4/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "ProfileVC.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "MBProgressHUD.h"
#import "GetGenderBDatePrivacyVC.h"


@interface ProfileVC () <MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation ProfileVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	
    
	[self LoadViewSettings];
//	[AlertHandler alertTitle:CONFIRM message:@"Do you wish to find your PHONE BOOK friends on Blabeey?" delegate:self tag:4 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
/*
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
*/
}

-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
    appDelegate.currentVc = self;
}

-(void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
	self.isBackPressed = TRUE;
    appDelegate.isShouldShowReplyPopUp = NO;

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark	Methods

-(void)LoadViewSettings{
	
	self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:Blue_BG]];
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:30];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];

	[self.btnNext.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnNext setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
	
	[self setUserImageCorners];
	
	NSString *strFBID = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]];
		
	if (strFBID.length>0) {
        self.img_UserProfileImg.image = nil;
        self.img_UserProfileImg.imageURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]]];
//		[self.img_UserProfileImg setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]]]];

	}
	else{
//		self.img_UserProfileImg.image = nil;
	}
		
	[self.tfDisplyName setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.tfDisplyName setTextColor:UIColorFromRGB(0X585f66)];
	[self.tfDisplyName setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
    
    [self.tfMaidenName setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [self.tfMaidenName setTextColor:UIColorFromRGB(0X585f66)];
    [self.tfMaidenName setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
//	[self.tfDisplyName setText:[NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults] valueForKey:DIC_SIGNUP] valueForKey:SIGNUP_USERNAME]]];
	
//    self.tfDisplyName.text = [HASHTAG_CHARACTER stringByAppendingFormat:@"%@",self.tfDisplyName.text];
    
    
    
}

-(void)setUserImageCorners{
	
	id fbView = [self.view viewWithTag:33];
	if (fbView != nil) {
		[fbView removeFromSuperview];
		fbView = nil;
	}
	
	self.img_UserProfileImg.layer.borderColor = [UIColor whiteColor].CGColor;
	self.img_UserProfileImg.layer.borderWidth = 1;
	[Validation setCorners:self.img_UserProfileImg];
	[self.view bringSubviewToFront:self.img_UserProfileImg];
}

-(IBAction)btnNextClicked:(id)sender{
    [self.tfMaidenName resignFirstResponder];
    [self.tfDisplyName resignFirstResponder];
/*    if (self.img_UserProfileImg.image == nil) {
        [Validation showToastMessage:@"Select profile picture." displayDuration:ERROR_MSG_DURATION];
        return;
    }
*/
    if (![self checkForValidation]){
        //message is shown in this method itself so no need to show msg again
    }
    else{
        
        NSData *data = [Validation compressImage:self.img_UserProfileImg.image];
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[[NSUserDefaults standardUserDefaults] valueForKey:DIC_SIGNUP]];
        [dic setValue:[self.tfDisplyName.text substringFromIndex:1] forKey:SIGNUP_DISPLAYNAME];
        [dic setValue:self.tfMaidenName.text forKey:SIGNUP_MAIDENNAME];
        [dic setValue:(data.length>0)?data:@"" forKey:SIGNUP_USER_PHOTO];
        [[NSUserDefaults standardUserDefaults] setValue:dic forKey:DIC_SIGNUP];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        GetGenderBDatePrivacyVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:GET_GENDER_BDATE_ORIVACY_VC];
        [self.navigationController pushViewController:obj animated:YES];
    }
    
    
    /*
    NSString *strDisplayName = [DataValidation checkNullString:self.tfDisplyName.text];
    if ([strDisplayName hasPrefix:HASHTAG_CHARACTER]) {
        strDisplayName = [strDisplayName substringFromIndex:1];
    }
    
	if ([DataValidation checkNullString:strDisplayName].length > 0) {
		[self.tfDisplyName resignFirstResponder];
		
		//[Validation showLoadingIndicator];
        [HUD show:YES];
		
        

        
		NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
							  [NSDictionary dictionaryWithObjectsAndKeys:strDisplayName,KeyValue,@"Name",KeyName, nil],@"1",
							  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Phone",KeyName, nil],@"2",
							  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Email",KeyName, nil],@"3",
							  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"UserName",KeyName, nil],@"4",
							  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Pwd",KeyName, nil],@"5",
							  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"DateOfBirth",KeyName, nil],@"6",
							  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:LOGIN_USER_GENDER]],KeyValue,@"Gender",KeyName, nil],@"7",
							  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"ID",KeyName, nil],@"8",
							  [NSDictionary dictionaryWithObjectsAndKeys:((self.img_UserProfileImg.image!= nil)?self.img_UserProfileImg.image:@""),KeyValue,@"ImgData",KeyName, nil],@"9",
							  [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:self.strFBID].length > 0)?self.strFBID:@"",KeyValue,@"FacebookID",KeyName, nil],@"10",
							  nil];

		NSString *strUrl = [WebServiceContainer getServiceURL:EDIT_USER_PROFILE withParameters:nil];
		ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
		request.delegate = self;
		request.tag = 1;
		strUrl = nil;
	}
	else{
		[HUD hide:YES];
		[Validation showToastMessage:@"Enter valid display name" displayDuration:ERROR_MSG_DURATION];
		[self.tfDisplyName becomeFirstResponder];
	}
     */
}

-(IBAction)btnBackClicked:(id)sender{
//	[self removeObjectDependancy];
	self.isBackPressed = TRUE;
	[self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnUserProfileImgClicked:(id)sender{
	
	//[self.tfDisplyName resignFirstResponder];
	
	UIActionSheet *actionCameraOption = [[UIActionSheet alloc] initWithTitle:@"Options" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:@"Camera",@"Library", nil];
	
	[actionCameraOption showInView:self.view];

}

-(BOOL)checkForValidation{
	
    NSString *strName = self.tfDisplyName.text;
    if (strName.length > 1) {
        if ([DataValidation checkNullString:[strName substringFromIndex:1]].length==0) {
            [Validation showToastMessage:@"Please enter valid\ndisplay name." displayDuration:ERROR_MSG_DURATION];
            return FALSE;
        }
        else return TRUE;
    }
    else{
        [Validation showToastMessage:@"Please enter valid\ndisplay name." displayDuration:ERROR_MSG_DURATION];

        return FALSE;
    }
	
	return TRUE;
}

-(void)ShowCamera{
	self.imagePicker = [[UIImagePickerController alloc] init];
	
	self.imagePicker.delegate = self;
	
	self.imagePicker.sourceType =
	UIImagePickerControllerSourceTypeCamera;
	
	self.imagePicker.allowsEditing = YES;
	[self presentViewController:self.imagePicker
					   animated:YES completion:nil];
}
-(void)ShowLibrary{
	if ([ALAssetsLibrary authorizationStatus] == ALAuthorizationStatusDenied) {
		[AlertHandler alertTitle:MESSAGE message:ALERT_FOR_PHOTO_LIBRARY_ACCESS delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else{
		self.imagePicker = [[UIImagePickerController alloc] init];
		
		self.imagePicker.delegate = self;
		
		self.imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
		
		self.imagePicker.allowsEditing = YES;
		[self presentViewController:self.imagePicker
						   animated:YES completion:nil];

	}
}

-(void)hideImagePicker{
	[self.imagePicker dismissViewControllerAnimated:YES completion:nil];
	[self.tfDisplyName becomeFirstResponder];
}

-(void)SendUserContactListToServer{
	/*
	 The piece of code in
	 
	 dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
	 
	 });
	 
	 is run asynchronously on a background thread. This is done because parsing data may be a time consuming task and it could block the main thread which would stop all animations and the application wouldn't be responsive.
	 */
	
		__block NSArray *arr = nil;
	dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{

		arr = [DataValidation getAllContacts];
		if (arr!=nil) {
			if (arr.count>0) {
				//[self performSelectorInBackground:@selector(sendContactToServer:) withObject:arr];
				//[self performSelector:@selector(sendContactToServer:) withObject:arr afterDelay:1];
				[self performSelector:@selector(sendContactToServer:) withObject:arr];
				//[self sendContactToServer:arr];
			}
            else{
                [HUD hide:YES];
            }
		}
        else{
            [HUD hide:YES];
            [AlertHandler alertTitle:CONFIRM message:@"Do you wish to find your FACEBOOK friends on Blabeey?" delegate:self tag:3 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
        }
		NSLog(@"%@",arr);
        
	});
}

-(void)sendContactToServer:(NSArray *)arr{
	NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
						  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"PhoneNo",KeyName, nil],@"2",
						  [NSDictionary dictionaryWithObjectsAndKeys:[arr componentsJoinedByString:@"|"],KeyValue,@"ContactList",KeyName, nil],@"3",
						  nil];
	NSString *strUrl = [WebServiceContainer getServiceURL:SEND_USER_CONTACT_LIST withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:3];
    }
//	request.delegate = self;
//	request.tag = 3;
	strUrl = nil;
}

#pragma mark UIActionSheet Delegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
	if (buttonIndex == actionSheet.cancelButtonIndex) {
		[self.tfDisplyName becomeFirstResponder];
	}
	else{
		if (buttonIndex == 0) {
			//camera
			if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
			{
				// code here
				[self ShowCamera];
			}
			else{
				[AlertHandler alertTitle:ALERT message:@"Camera not available." delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
			}
		}
		else if (buttonIndex == 1){
			if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
				//code here
				[self ShowLibrary];
			}
			else{
				[AlertHandler alertTitle:ALERT message:@"Library not available." delegate:self tag:2 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
			}
		}
	}
}

#pragma mark	UIAlertView Delegate

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
	if (alertView.tag == 1) {
		//camera not available
		[self hideImagePicker];
	}
	else if (alertView.tag == 2){
		//library not available
		[self hideImagePicker];
	}
	else if (alertView.tag == 3){
		if (buttonIndex == alertView.cancelButtonIndex) {
			[self.tfDisplyName becomeFirstResponder];
		}
		else{
			[self addFaceBookFriends];
		}
	}
	else if (alertView.tag == 4){
		//share phonebook with Yapeey
		if (buttonIndex == alertView.cancelButtonIndex) {
			[HUD hide:YES];
			[AlertHandler alertTitle:CONFIRM message:@"Do you wish to find your FACEBOOK friends on Blabeey?" delegate:self tag:3 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
		}
		else{
			//[Validation showLoadingIndicator];
            [HUD show:YES];
			[self SendUserContactListToServer];
		}
	}
}

-(void)addFaceBookFriends{
	NSLog(@"fb btn pressed");
	//[Validation showLoadingIndicator];
    [HUD show:YES];
	
	
	if (!FBSession.activeSession.isOpen) {
        // if the session is closed, then we open it here, and establish a handler for state changes
        [FBSession openActiveSessionWithReadPermissions:@[@"public_profile", @"email", @"user_friends"]
                                           allowLoginUI:YES
                                      completionHandler:^(FBSession *session,
														  FBSessionState state,
														  NSError *error) {
										  if (error) {
											  [HUD hide:YES];
											  UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
																								  message:@"Could not get your Facebook data.\nPlease check you internet connectivity or try later."
																								 delegate:nil
																						cancelButtonTitle:@"OK"
																						otherButtonTitles:nil];
											  [alertView show];
										  } else if (session.isOpen) {
											  // [self pickFriendsButtonClick:sender];
											  NSLog(@"facebook login");
											  [self getUserInfo];
										  }
									  }];
        return;
    }
	else if (FBSession.activeSession.isOpen) {
		NSLog(@"facebook login");
		[self getUserInfo];
	}
}

- (void)GetUserFriendList {
	
	[FBRequestConnection startWithGraphPath:@"/me/friends"
								 parameters:nil
								 HTTPMethod:@"GET"
						  completionHandler:^(
											  FBRequestConnection *connection,
											  id result,
											  NSError *error
											  ) {
							  /* handle the result */
							  NSLog(@"%@",result);
							  NSArray *arr = [((NSArray *)[result valueForKey:@"data"]) valueForKey:@"id"];
							  [self addFacebookFreinds:arr];
						  }
	 ];
	
}

-(void)getUserInfo{
	//[Validation showLoadingIndicator];
    [HUD show:YES];
	[[FBRequest requestForMe] startWithCompletionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
		//result contains a dictionary of your user, including Facebook ID.
		NSLog(@"result=  %@",result);
		self.strFBID = [result valueForKey:@"id"];
		[self GetUserFriendList];
		
	}];
}

-(void)addFacebookFreinds:(NSArray *)arrFbId{
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[arrFbId componentsJoinedByString:@"|"]],KeyValue,@"FacebookIDs",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:ADD_FB_FRIENDS withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:4];
    }
//	request.delegate = self;
//	request.tag = 4;
	strUrl = nil;
}

-(void)checkFBID_Exist{
	NSLog(@"%@",[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]);
	if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]].length == 0) {
		NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
							 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"emailID",KeyName, nil],@"1",
							 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"userName",KeyName, nil],@"2",
							 [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:self.strFBID isGeneral:YES],KeyValue,@"facebookID",KeyName, nil],@"3",
							 [NSDictionary dictionaryWithObjectsAndKeys:@"-1",KeyValue,@"IsActive",KeyName, nil],@"4",
							 nil];
		
		NSString *strUrl = [WebServiceContainer getServiceURL:CHECK_USER_EXIST withParameters:nil];
		ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
        if (request == nil) {
            [HUD hide:YES];
        }
        else{
            [request setDelegate:self];
            [request setTag:5];
        }
//		request.delegate = self;
//		request.tag = 5;
		strUrl = nil;
		
	}
	else{
		[HUD hide:YES];
		[self.tfDisplyName becomeFirstResponder];
	}
}

#pragma mark UITextField Delegate
- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    [self animateYPoint:0 viewToAnimate:self.view];
}

- (void)keyboardWillShow:(NSNotification*)notification {
    [self animateYPoint:-50 viewToAnimate:self.view];
}
-(void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField==self.tfDisplyName) {
        if (textField.text.length == 0)
            textField.text = @"@";
    }
}
-(void)animateYPoint:(int)yPoint viewToAnimate:(UIView *)viewToAni{
    [UIView animateWithDuration:0.5 animations:^{
        
        CGRect frame;
        
        // move our subView to its new position
        frame=viewToAni.frame;
        frame.origin.y=yPoint;
        viewToAni.frame=frame;
        viewToAni.alpha=1.0;
    }];
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (textField == self.tfDisplyName) {
        if ([string isEqualToString:@""]) {
            if (range.location==0) {
                return FALSE;
            }
        }
        
        if (range.location==1 && ![string isEqualToString:@""]) {
            NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"];
            s = [s invertedSet];
            NSRange r = [string rangeOfCharacterFromSet:s];
            if (r.location != NSNotFound) {
                return FALSE;
            }
        }
    }
    else if (textField == self.tfMaidenName) {
        
        if (![string isEqualToString:@""]) {
            NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"];
            s = [s invertedSet];
            NSRange r = [string rangeOfCharacterFromSet:s];
            if (r.location != NSNotFound) {
                return FALSE;
            }
        }
    }
    return TRUE;
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
//	if (!self.isBackPressed && self.imagePicker==nil) {
//		if ([self checkForValidation]) {
//			[Validation showToastMessage:@"Validation Passed\ngo to next VC" displayDuration:ERROR_MSG_DURATION];
//		}
//	}
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self.tfMaidenName resignFirstResponder];
    [self.tfDisplyName resignFirstResponder];
	return TRUE;
}


#pragma  mark	UIImagePickerController Delegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
	self.img_UserProfileImg.image = info[UIImagePickerControllerEditedImage];
	[self setUserImageCorners];
	[self hideImagePicker];
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
	
	[self hideImagePicker];
}
-(void)moveToNextVC{
	[HUD hide:YES];
    appDelegate.selectedMenuIndex = 0;
 //   UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
    
    [UIView transitionWithView:self.navigationController.view
                      duration:0.5
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        [self.navigationController pushViewController:ivc animated:NO];
                    }
                    completion:nil];

//    appDelegate.selectedMenuIndex = 0;
//    [self performSegueWithIdentifier:NOTIFICATION_VC sender:nil];
}

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	//	NSError *error = nil;
	
	NSLog(@"response =%@",[request responseString]);
	
	
	NSError *error= nil;
	id response = [NSJSONSerialization JSONObjectWithData:[request responseData] options:0 error:&error];
	NSMutableDictionary *dic  = nil;
	NSLog(@"%@",response);
	
	[HUD hide:YES];
	
    if (response != nil) {
        
        if (request.tag <5) {
            if (![[NSString stringWithFormat:@"%@",[[response valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                NSLog(@"dic = %@",response);
                [appDelegate callLogOutService];
            }
            else{
                if (request.tag == 1) {
                    if ([[response valueForKey:STATUS] intValue] != 0) {
                        response = [response valueForKey:RESPONSE];
                        if (response != nil) {
                            if ([[response valueForKey:RESPONSE] isKindOfClass:[NSDictionary class]]) {
                                dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)response];
                            }
                            else if ([[response valueForKey:RESPONSE] isKindOfClass:[NSArray class]]){
                                dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[response objectAtIndex:0]];
                            }
                            
                            [Validation setAllKeyValueFromData:dic];
                            dic = nil;
                            [HUD hide:YES];
                            [self moveToNextVC];
                        }
                    }
                }
                else if (request.tag == 3){
                    [HUD hide:YES];
                    [AlertHandler alertTitle:CONFIRM message:@"Do you wish to find your FACEBOOK friends on Blabeey?" delegate:self tag:3 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
                }
                else if (request.tag == 4){
                    //add fb friends
                    [self checkFBID_Exist];
                }
            }
        }
        else if (request.tag == 5){
            //check user exist
            id response = [dic objectForKey:RESPONSE];
            if ([response isKindOfClass:[NSArray class]]) {
                if (((NSDictionary *)response).count>0) {
                    //so call login service
                    if ([response isKindOfClass:[NSArray class]]) {
                        int breakReason = -1;
                        NSArray *arr = [NSArray arrayWithArray:(NSArray *)response];
                        for (int i = 0; i<arr.count; i++) {
                            for (int y = 0; y<3; y++) {
                                switch (y) {
                                    case 0:{
                                        //check for username
                                        
                                    }
                                        break;
                                    case 1:{
                                        //check for email
                                        
                                    }
                                        break;
                                    case 2:{
                                        //check for fb ID
                                        if ([self.strFBID isEqualToString:[NSString stringWithFormat:@"%@",[[arr objectAtIndex:i] valueForKey:FB_ID]]]) {
                                            breakReason = 3;
                                            break;
                                        }
                                    }
                                        break;
                                    default:
                                        break;
                                }
                                if (breakReason != -1) {
                                    break;
                                }
                            }
                            if (breakReason != -1) {
                                break;
                            }
                        }
                        
                        if (breakReason == 3) {
                            //fb id exists
                        }
                        else if (breakReason == -1){
                            //fb id does not exists
                            self.isFBID_Exists = NO;
                        }
                    }
                }
                else {
                    self.isFBID_Exists = NO;
                }
            }
            else if (response==nil){
                self.isFBID_Exists = NO;
            }
            [self.tfDisplyName becomeFirstResponder];
        }
    }
  	[HUD hide:YES];
	response = nil;
	dic = nil;
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [[event allTouches] anyObject];
    if (![touch.view isKindOfClass:[UITextField class]]) {
        [self.tfDisplyName resignFirstResponder];
    }
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
