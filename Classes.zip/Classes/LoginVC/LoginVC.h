//
//  LoginVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginVC : UIViewController <UITextFieldDelegate,UIAlertViewDelegate>

@property (nonatomic, strong) IBOutlet UIButton			*btnBack;
@property (nonatomic, strong) IBOutlet UIButton			*btnSignIn;
@property (nonatomic, strong) IBOutlet UIButton			*btnForgotPwd;

@property (nonatomic, strong) IBOutlet UITextField		*tfUserName;
@property (nonatomic, strong) IBOutlet UITextField		*tfPassword;

@property (nonatomic, strong) IBOutlet UILabel			*lblTitle;

@property (nonatomic, strong) ASIHTTPRequest			*request;

@end
