//
//  LoginVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "LoginVC.h"
#import "MBProgressHUD.h"


@interface LoginVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}


@end

@implementation LoginVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
}

-(void)viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
	[super viewWillAppear:animated];
	[self performSelector:@selector(LoadViewSettings)];


}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark	Methods

-(void)LoadViewSettings{
	
	self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:Blue_BG]];
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:30];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
	
	[self.btnForgotPwd.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnSignIn.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	
	[self.btnSignIn setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
	
	[self.tfUserName setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.tfUserName setTextColor:UIColorFromRGB(0X585f66)];
	
	[self.tfPassword setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.tfPassword setTextColor:UIColorFromRGB(0X585f66)];
	
	[self.tfUserName setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
	[self.tfPassword setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
	
	[self.tfUserName becomeFirstResponder];
}

-(void)removeObjectDependancy{
    
	self.tfUserName.text = @"";
	self.tfPassword.text = @"";
	
	[self.tfUserName resignFirstResponder];
	[self.tfPassword resignFirstResponder];
}

-(IBAction)btnBackClicked:(id)sender{
    
	[self removeObjectDependancy];
	[self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnSignInClicked:(id)sender{
    
	if (self.request !=nil) {
		self.request = nil;
	}
	if ([self checkForValidation]) {
		[self HideKeyBoard];
		//[Validation showLoadingIndicator];
        [HUD show:YES];
        NSLog(@"DEVICE_TOKEN %@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]);
		BOOL isEmail = [DataValidation validateEmailWithString:self.tfUserName.text];
/*		NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
							 [NSString stringWithFormat:@"email=%@",(isEmail)?self.tfUserName.text:@""],@"param1",
							 [NSString stringWithFormat:@"userName=%@",(isEmail)?@"":self.tfUserName.text],@"param2",
							 [NSString stringWithFormat:@"password=%@",self.tfPassword.text],@"param3",
							 [NSString stringWithFormat:@"regID=%@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]],@"param4",
							 [NSString stringWithFormat:@"OS=%@",APPLICATION_OS],@"param5",
							 nil];
*/
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                              [NSDictionary dictionaryWithObjectsAndKeys:(isEmail)?self.tfUserName.text:@"",KeyValue,@"email",KeyName, nil],@"1",
                              [NSDictionary dictionaryWithObjectsAndKeys:(isEmail)?@"":self.tfUserName.text,KeyValue,@"userName",KeyName, nil],@"2",
                              [NSDictionary dictionaryWithObjectsAndKeys:self.tfPassword.text,KeyValue,@"password",KeyName, nil],@"3",
                              [NSDictionary dictionaryWithObjectsAndKeys:[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN],KeyValue, @"regID", KeyName, nil],@"4",
                              [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"5",
                              nil];

		NSString *strUrl = [WebServiceContainer getServiceURL:LOGIN withParameters:nil];
		
		self.request = [WebServiceContainer CallWebserviceWithPost:dic	forURL:strUrl isAddHeader:FALSE];
        if (self.request == nil) {
            [HUD hide:YES];
        }
        else{
            self.request.delegate = self;
            self.request.tag = 1;
        }
//		self.request.delegate = self;
//		self.request.tag = 1;
		strUrl = nil;
	}
}

-(IBAction)btnForgotPWDClicked:(id)sender{
    
    [self HideKeyBoard];
    
    UIView *viewForgotPassword = [[UIView alloc] initWithFrame:CGRectMake(0, DEVICE_HEIGHT, DEVICE_WIDTH, DEVICE_HEIGHT)];
    [viewForgotPassword setBackgroundColor:UIColorFromRGB(0X1FBEF8)];
    viewForgotPassword.tag = 45;
    [self.view addSubview:viewForgotPassword];
  
    UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(10, 20, 300, 40)];
    lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:25];
    lblTitle.textAlignment = NSTextAlignmentCenter;
    [lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    [lblTitle setText:@"FORGOT PASSWORD"];
    [viewForgotPassword addSubview:lblTitle];
    
    UITextField *tfEmail = [[UITextField alloc] initWithFrame:CGRectMake((DEVICE_WIDTH-300)/2, 110, 300, 40)];
    tfEmail.keyboardType = UIKeyboardTypeEmailAddress;
    tfEmail.tag = 46;
    [tfEmail setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [tfEmail setTextColor:UIColorFromRGB(0X585f66)];
    [tfEmail setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
    tfEmail.delegate = self;
    tfEmail.autocapitalizationType = UITextAutocapitalizationTypeNone;
    tfEmail.placeholder = @"Email address";
    [tfEmail setTextAlignment:NSTextAlignmentCenter];
    tfEmail.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfEmail.borderStyle = UITextBorderStyleNone;
    tfEmail.backgroundColor = [UIColor whiteColor];
    [tfEmail becomeFirstResponder];
    [viewForgotPassword addSubview:tfEmail];
    
    
    UIButton *btnDone = [UIButton buttonWithType:UIButtonTypeCustom];
    btnDone.frame = CGRectMake((DEVICE_WIDTH-210)/2, 200, 210, 45);
    [btnDone setTitle:@"Done" forState:UIControlStateNormal];
    [btnDone.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [btnDone setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
    [btnDone setBackgroundImage:[UIImage imageNamed:btn_With_WhiteBg] forState:UIControlStateNormal];
    [btnDone addTarget:self action:@selector(sendEmailForForgotPWD) forControlEvents:UIControlEventTouchUpInside];
    [viewForgotPassword addSubview:btnDone];
    
    UIButton *btnCancel = [UIButton buttonWithType:UIButtonTypeCustom];
    btnCancel.frame = CGRectMake((DEVICE_WIDTH-210)/2, 262, 210, 45);
    [btnCancel setTitle:@"Cancel" forState:UIControlStateNormal];
    [btnCancel.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [btnCancel setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
    [btnCancel addTarget:self action:@selector(hideForgotPWDView) forControlEvents:UIControlEventTouchUpInside];
    [btnCancel setBackgroundImage:[UIImage imageNamed:btn_With_WhiteBg] forState:UIControlStateNormal];
    [viewForgotPassword addSubview:btnCancel];
    
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.4];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
    
    viewForgotPassword.center = self.view.center;
    
    [UIView commitAnimations];
    
//	UIAlertView *alertEmail = [[UIAlertView alloc] initWithTitle:@"Forgot Password" message:@"Enter your email address." delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE otherButtonTitles:@"Done", nil];
//	alertEmail.alertViewStyle = UIAlertViewStylePlainTextInput;
//	[alertEmail textFieldAtIndex:0].delegate = self;
//	[alertEmail textFieldAtIndex:0].tag = 4;
//	[alertEmail textFieldAtIndex:0].keyboardType = UIKeyboardTypeEmailAddress;
//	[alertEmail show];
}

-(void)removeForgotPasswordView:(UIView *)v{
    for (id c in v.subviews) {
        [c removeFromSuperview];
    }
    [v removeFromSuperview];
}

-(void)hideForgotPWDView{
    UIView *v = (UIView *)[self.view viewWithTag:45];
    UITextField *tf = (UITextField *)[v viewWithTag:46];
    [tf resignFirstResponder];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.4];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
    [UIView animateWithDuration:0.4 animations:^(void){
        v.frame = CGRectMake(0, DEVICE_HEIGHT, DEVICE_WIDTH, DEVICE_HEIGHT);

    }completion:^(BOOL finished){
        [self removeForgotPasswordView:v];
    }];
    
    
    [UIView commitAnimations];
}
-(void)sendEmailForForgotPWD{
    if (self.request !=nil) {
        self.request = nil;
    }
    
    UIView *v = [self.view viewWithTag:45];
    UITextField *tf = (UITextField *)[v viewWithTag:46];
    
    if ([DataValidation validateEmailWithString:tf.text]) {
//        [self hideForgotPWDView];

        [HUD show:YES];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",tf.text],KeyValue,@"Email",KeyName, nil],@"1",
                             nil];
        
        NSString *strUrl = [WebServiceContainer getServiceURL:FORGOT_PWD withParameters:nil];
        self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
        if (self.request == nil) {
            [HUD hide:YES];
        }
        else{
            [self.request setDelegate:self];
            [self.request setTag:2];
        }
//        self.request.delegate = self;
//        self.request.tag = 2;
        strUrl = nil;
//        [self hideForgotPWDView];
    }
    else{
        [Validation highLightTextField:tf inView:v];
        //[self performSelector:@selector(ShowValidationForAlertView) withObject:nil afterDelay:0.5];
        [self ShowValidationForAlertView];
    }
}

-(BOOL)checkForValidation{
		
	[Validation removeToastFromMemory];
	if ([DataValidation checkNullString:self.tfUserName.text].length==0) {
		[Validation showToastMessage:@"Please enter valid username" displayDuration:ERROR_MSG_DURATION];
		return FALSE;
	}
	else if ([DataValidation checkNullString:self.tfPassword.text].length==0) {
		[Validation showToastMessage:@"Please enter passowrd" displayDuration:ERROR_MSG_DURATION];
		return FALSE;
	}
	else{
		return TRUE;
	}
	return TRUE;
}

-(void)HideKeyBoard{
	[self.tfUserName resignFirstResponder];
	[self.tfPassword resignFirstResponder];
}

#pragma mark	UIAlertView Delegate

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
	if (buttonIndex == alertView.cancelButtonIndex) {
		
	}
	else{
		if (self.request !=nil) {
			self.request = nil;
		}
		if ([DataValidation validateEmailWithString:[alertView textFieldAtIndex:0].text]) {
			
			//[Validation showLoadingIndicator];
            [HUD show:YES];
			
			NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
								 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[alertView textFieldAtIndex:0].text],KeyValue,@"Email",KeyName, nil],@"1",
								 nil];
			
			NSString *strUrl = [WebServiceContainer getServiceURL:FORGOT_PWD withParameters:nil];
			self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
            if (self.request == nil) {
                [HUD hide:YES];
            }
            else{
                [self.request setDelegate:self];
                [self.request setTag:2];
            }
//			self.request.delegate = self;
//			self.request.tag = 2;
			strUrl = nil;
			
		}
		else{
            [self performSelector:@selector(ShowValidationForAlertView) withObject:nil afterDelay:0.5];
		}
	}
}

-(void)ShowValidationForAlertView{
    [Validation showToastMessage:@"Enter valid email address" displayDuration:ERROR_MSG_DURATION];
}

#pragma mark
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
	if (textField == self.tfUserName) {
		[self.tfPassword becomeFirstResponder];
	}
	else if (textField == self.tfPassword) {
		[self btnSignInClicked:nil];
	}
	return TRUE;
}

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
//	NSError *error = nil;
	
	//NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[self.request responseData]
	//														  options:0
	//															error:&error];;
	
	NSLog(@"response =%@",[request responseString]);
	
	
	NSError *error= nil;
	id response = [NSJSONSerialization JSONObjectWithData:[self.request responseData] options:0 error:&error];
	
	NSMutableDictionary *dic  = nil;
	
	if (request.tag == 1) {
		if (([[response valueForKey:STATUS] intValue] != 0) && ([[response valueForKey:STATUS] intValue] != -1)) {
			response = [response valueForKey:RESPONSE];
			if (response != nil) {
				if ([response isKindOfClass:[NSDictionary class]]) {
					dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)response];
				}
				else if ([response isKindOfClass:[NSArray class]]){
					if (((NSArray *)response).count >0) {
						dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[response objectAtIndex:0]];
					}
					
				}
				NSLog(@"di  -%@",dic);
				[HUD hide:YES];
				if (dic.count>0) {
					[dic setValue:self.tfPassword.text forKey:LOGIN_USER_KEY];
					[Validation setAllKeyValueFromData:dic];
                    [Validation setMatTrackingForRegisterAndLogin:dic index:1];
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_FROM_SIGN_UP];
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_CONVOS];
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_FRIENDLIST];
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_REMINDER];
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_SENDBLAB];
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_SETTING];
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_FRIEND_REMINDER];
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_MESSAGE_SHOW_FOR_AUDIO_SCREEN];
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_MESSAGE_SHOW_FOR_VIDEO_SCREEN];
                    [[NSUserDefaults standardUserDefaults] synchronize];
					[Validation showToastMessage:@"Login successful." displayDuration:SUCCESS_MSG_DURATION];
					
					[self performSelector:@selector(MoveToNextVC) withObject:nil afterDelay:2];
					
				}
				else{
					[Validation showToastMessage:@"Login failed." displayDuration:ERROR_MSG_DURATION];
					[self.tfUserName becomeFirstResponder];
				}
				
			}
		}
		else{
			[HUD hide:YES];
			[Validation showToastMessage:@"Login Failed" displayDuration:ERROR_MSG_DURATION];
		}
	}
	else if (request.tag == 2){
        [HUD hide:YES];
		if (([[response valueForKey:STATUS] intValue] != 0) && ([[response valueForKey:STATUS] intValue] != -1)) {
			[Validation showToastMessage:@"Email sent successfully.\nPlease check your mailbox." displayDuration:ERROR_MSG_DURATION];
            [self hideForgotPWDView];
		}
        else if ([[response valueForKey:STATUS] intValue] == 0){
            [Validation showToastMessage:@"Email does not exists.\nPlease enter valid Email address." displayDuration:ERROR_MSG_DURATION];
        }
	}
	[HUD hide:YES];
	self.request = nil;
	dic = nil;
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
-(void)MoveToNextVC{
	[Validation CancelOnGoingRequests:self.request];
    appDelegate.selectedMenuIndex = 0;
 //   UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
    
    [UIView transitionWithView:self.navigationController.view
                      duration:0.5
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        [self.navigationController pushViewController:ivc animated:NO];
                    }
                    completion:nil];

    //appDelegate.selectedMenuIndex = 0;
	//[self performSegueWithIdentifier:NOTIFICATION_VC sender:nil];
		//	[self performSegueWithIdentifier:PROFILE_VC sender:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
