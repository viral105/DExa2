//
//  AddFriendFromExistingFriendListVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/8/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserCell.h"
#import "UserProfileVC.h"

@interface AddFriendFromExistingFriendListVC : UIViewController<UITableViewDataSource, UITableViewDelegate,UIActionSheetDelegate,UIAlertViewDelegate,AFNetworkingDataTransactionDelegate,UITextFieldDelegate,UserCellDelegate,UserProfileVCDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, strong) NSMutableDictionary			*sections;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, strong) NSMutableArray				*arrSelected;
@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) AFNetworkingDataTransaction	*request;

@property (strong, nonatomic) IBOutlet UIView *viewSearch;
@property (strong, nonatomic) IBOutlet UITextField *tfSearch;
@property (strong, nonatomic) IBOutlet UIImageView *imgSearch;  //bhavik 23-Feb-2015
@property (strong, nonatomic) IBOutlet UILabel *lblNoFriend;
@property (nonatomic, strong) UIScrollView					*scrollContainer;

@property (nonatomic, strong) IBOutlet UIButton				*btnNext;
@property (nonatomic, strong) IBOutlet UIButton				*btnSelectAll;
@property (nonatomic, strong) IBOutlet UIButton				*btnMenuBack;

//@property (nonatomic, readwrite) int                        ForwardNotifId;
@property (nonatomic, strong) NSDictionary                  *dicSelectedNotifToForward;
@property (nonatomic, readwrite) BOOL						isNotifSendToAll;
@property (nonatomic, readwrite) BOOL                       isReloadData;
@property (nonatomic, strong) NSIndexPath                   *selectedUserIndexPath;


@property (nonatomic, readwrite) BOOL                       isMultipleUsersSelected;

- (IBAction)btnCancel_Clicked:(id)sender;
- (IBAction)btnSearch_Clicked:(id)sender;
@end
