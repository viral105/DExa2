//
//  SignUpVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 7/29/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "SignUpVC.h"
#import "ProfileVC.h"
#import "UserInterestList.h"
#import "MBProgressHUD.h"


@interface SignUpVC () <MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
    int showUrlInWeb; // 1 means TermsAndConditions     2 means Privacy Policy
    BOOL isGoingToTandCorPP;
}

@end

@implementation SignUpVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	NSLog(@"fbID = %@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]);
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
    
    [self performSelector:@selector(LoadViewSettings)];
}

-(void)viewWillAppear:(BOOL)animated{
	appDelegate.currentVc = self;
    isGoingToTandCorPP = NO;
	[super viewWillAppear:animated];
	
}

-(void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
    if (!isGoingToTandCorPP) {
        [self removeObjectDependancy];
    }
	
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark	Methods

-(void)LoadViewSettings{
	
	self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:Blue_BG]];
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:30];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
	
	[self.btnSignUp.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnSignUp setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
	
	[self.tfUserName setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.tfUserName setTextColor:UIColorFromRGB(0X585f66)];
	
	[self.tfPassword setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.tfPassword setTextColor:UIColorFromRGB(0X585f66)];

	[self.tfEmail setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.tfEmail setTextColor:UIColorFromRGB(0X585f66)];

	[self.tfUserName setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
	[self.tfEmail setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
	[self.tfPassword setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
    
/*    [self.tfUserName setText:@"devtest1"];
    [self.tfEmail setText:@"devtest1@test.com"];
    [self.tfPassword setText:@"123456"];
*/ 
	self.scrollContainer.scrollEnabled = YES;

    self.Count = 1;
	self.btnSignUp.alpha = 0;
	self.btnSignUp.frame = CGRectMake(self.btnSignUp.frame.origin.x, DEVICE_HEIGHT+self.btnSignUp.frame.size.height, self.btnSignUp.frame.size.width, self.btnSignUp.frame.size.height);
	
	[self performSelector:@selector(animateTextPosition)];
}

-(void)animateTextPosition{

    if (self.Count<4) {
        UIImageView *imgBg = (UIImageView *)[self.scrollContainer viewWithTag:self.Count+10];
        
        UITextField *tf = (UITextField *)[self.scrollContainer viewWithTag:self.Count];
        imgBg.alpha = 0.5;
        tf.alpha = 0.5;
        
        [UIView beginAnimations:@"SlideTextView" context:nil];
        [UIView setAnimationDuration:0.35];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(animateTextPosition)];
        imgBg.frame = CGRectMake(0, imgBg.frame.origin.y, imgBg.frame.size.width, imgBg.frame.size.height);
        tf.frame = CGRectMake(8, tf.frame.origin.y, tf.frame.size.width, tf.frame.size.height);
        imgBg.alpha = 1;
        tf.alpha = 1;
        [UIView commitAnimations];

    }
    else{
        [UIView beginAnimations:@"SlideTextView" context:nil];
        [UIView setAnimationDuration:0.35];
        self.btnSignUp.alpha = 1;
        self.btnSignUp.frame = CGRectMake(self.btnSignUp.frame.origin.x, self.scrollContainer.frame.origin.y+self.scrollContainer.frame.size.height+50, self.btnSignUp.frame.size.width, self.btnSignUp.frame.size.height);
        [UIView commitAnimations];
    }
    self.Count++;
}

-(void)removeObjectDependancy{
	self.tfUserName.text = @"";
	self.tfPassword.text = @"";
	self.tfEmail.text = @"";

    [self HideKeyboard];
}

-(void)HideKeyboard{
    [self.tfUserName resignFirstResponder];
	[self.tfEmail resignFirstResponder];
	[self.tfPassword resignFirstResponder];
}

-(IBAction)btnBackClicked:(id)sender{
	if (FBSession.activeSession.isOpen) {
		[FBSession.activeSession closeAndClearTokenInformation];
	}
    self.isBackClicked = YES;
	[self removeObjectDependancy];
	[self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnSignUpClicked:(id)sender{

    [self HideKeyboard];
	[Validation resetTextFieldBorderColor];
	if ([self checkForValidation]) {

        [HUD show:YES];
		
		NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
							 [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:[DataValidation checkNullString:self.tfEmail.text] isGeneral:TRUE],KeyValue,@"emailID",KeyName, nil],@"1",
							 [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:[DataValidation checkNullString:self.tfUserName.text] isGeneral:TRUE],KeyValue,@"userName",KeyName, nil],@"2",
							 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"facebookID",KeyName, nil],@"3",
							 [NSDictionary dictionaryWithObjectsAndKeys:@"-1",KeyValue,@"IsActive",KeyName, nil],@"4",
							 nil];
		
		NSString *strUrl = [WebServiceContainer getServiceURL:CHECK_USER_EXIST withParameters:nil];
		ASIHTTPRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
        if (request == nil) {
            [HUD hide:YES];
        }
        else{
            [request setDelegate:self];
            [request setTag:3];
        }
//		request.delegate = self;
//		request.tag = 3;
		strUrl = nil;
	}
}

-(BOOL)checkForValidation{
	
	if ([DataValidation checkNullString:self.tfUserName.text].length==0) {
		[HUD hide:YES];
		[Validation showToastMessage:@"Please enter valid\nusername." displayDuration:ERROR_MSG_DURATION];
		[Validation highLightTextField:self.tfUserName inView:self.scrollContainer];
		return FALSE;
	}
	else if (![DataValidation validateEmailWithString:self.tfEmail.text]){
		[HUD hide:YES];
		[Validation showToastMessage:@"Please enter valid\nemail address." displayDuration:ERROR_MSG_DURATION];
		[Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
		return FALSE;
	}
	else if ([DataValidation checkNullString:self.tfPassword.text].length==0) {
		[HUD hide:YES];
		[Validation showToastMessage:@"Please enter\npassowrd." displayDuration:ERROR_MSG_DURATION];
		[Validation highLightTextField:self.tfPassword inView:self.scrollContainer];
		return FALSE;
	}
    else if ([DataValidation checkNullString:self.tfPassword.text].length < 6 || [DataValidation checkNullString:self.tfPassword.text].length > 30){
        [HUD hide:YES];
		[Validation showToastMessage:@"Please enter\npassowrd min of 6 and max of 30 characters." displayDuration:ERROR_MSG_DURATION];
		[Validation highLightTextField:self.tfPassword inView:self.scrollContainer];
        return FALSE;
    }
	else{
		return TRUE;
	}
	return TRUE;
}

-(void)cleanAllValuesFromView{
	self.tfUserName.text = @"";
	self.tfPassword.text = @"";
	self.tfEmail.text = @"";
    
	self.Count = 0;
}

#pragma mark UITextField Delegate

-(void)textFieldDidEndEditing:(UITextField *)textField{

	[Validation resetTextFieldBorderColor];
    if (!self.isBackClicked) {
        if (textField.tag == 1) {
            //username
            if ([DataValidation checkNullString:self.tfUserName.text].length > 0) {
                //check if it does exist
                
                NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                                     [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"emailID",KeyName, nil],@"1",
                                     [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[Validation getEncryptedTextForString:[DataValidation checkNullString:self.tfUserName.text] isGeneral:TRUE]],KeyValue,@"userName",KeyName, nil],@"2",
                                     [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"facebookID",KeyName, nil],@"3",
                                     [NSDictionary dictionaryWithObjectsAndKeys:@"-1",KeyValue,@"IsActive",KeyName, nil],@"4",
                                     
                                     nil];
                
                NSString *strUrl = [WebServiceContainer getServiceURL:CHECK_USER_EXIST withParameters:nil];
                ASIHTTPRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
                if (request == nil) {
                    [HUD hide:YES];
                }
                else{
                    [request setDelegate:self];
                    [request setTag:1];
                }
//                request.delegate = self;
//                request.tag = 1;
                strUrl = nil;
            }
            
        }
        else if (textField.tag == 2){
            //email address
            
            if ([DataValidation validateEmailWithString:self.tfEmail.text]){
                if ([DataValidation checkNullString:self.tfEmail.text].length > 0) {
                    //check if email exists
                    
                    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                                         [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:[DataValidation checkNullString:self.tfEmail.text] isGeneral:TRUE],KeyValue,@"emailID",KeyName, nil],@"1",
                                         [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"userName",KeyName, nil],@"2",
                                         [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"facebookID",KeyName, nil],@"3",
                                         [NSDictionary dictionaryWithObjectsAndKeys:@"-1",KeyValue,@"IsActive",KeyName, nil],@"4",
                                         
                                         nil];
                    
                    NSString *strUrl = [WebServiceContainer getServiceURL:CHECK_USER_EXIST withParameters:nil];
                    ASIHTTPRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
                    if (request == nil) {
                        [HUD hide:YES];
                    }
                    else{
                        [request setDelegate:self];
                        [request setTag:2];
                    }
//                    request.delegate = self;
//                    request.tag = 2;
                    strUrl = nil;
                }
                else{
                    [Validation showToastMessage:@"Please enter valid\nemail address." displayDuration:ERROR_MSG_DURATION];
                    [Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
                }
            }
            else{
                [Validation showToastMessage:@"Please enter valid\nemail address." displayDuration:ERROR_MSG_DURATION];
                [Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
            }
        }
        
    }
    else{
        [textField resignFirstResponder];
    }
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{

	if (textField == self.tfPassword) {
        [textField resignFirstResponder];
	}
	else if (textField == self.tfUserName){
		[self.tfEmail becomeFirstResponder];
	}
	else if (textField == self.tfEmail){
		[self.tfPassword becomeFirstResponder];
	}
	return TRUE;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (textField == self.tfPassword) {
        if (![string isEqualToString:@""]) {
            NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_+"];
            s = [s invertedSet];
            NSRange r = [string rangeOfCharacterFromSet:s];
            if (r.location != NSNotFound) {
                return FALSE;
            }
        }
    }
    return TRUE;
}

#pragma mark	Web Service

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	
	[HUD hide:YES];
	NSLog(@"response =%@",[request responseString]);
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
															  options:0
																error:&error];;
	
	
	NSLog(@"dictionary = %@",dicResponse);
	
	[Validation resetTextFieldBorderColor];
	
	if ([dicResponse objectForKey:RESPONSE] != nil) {
		
		if ([[dicResponse valueForKey:STATUS] intValue] != -1 && [[dicResponse valueForKey:STATUS] intValue] != 0) {
			id response = [dicResponse objectForKey:RESPONSE];
			if (request.tag == 3) {
				if ([response isKindOfClass:[NSArray class]]) {
					int breakReason = -1;
					NSArray *arr = [NSArray arrayWithArray:(NSArray *)response];
					for (int i = 0; i<arr.count; i++) {
						for (int y = 0; y<3; y++) {
							switch (y) {
								case 0:{
									//check for username
									if ([[self.tfUserName.text lowercaseString] isEqualToString:[[[arr objectAtIndex:i] valueForKey:USER_NAME] lowercaseString]]) {
										breakReason = 1;
										break;
									}
								}
									break;
								case 1:{
									//check for email
									if ([[self.tfEmail.text lowercaseString] isEqualToString:[[[arr objectAtIndex:i] valueForKey:EMAIL] lowercaseString]]) {
										breakReason = 2;
										break;
									}
								}
									break;
								case 2:{
									//check for fb ID
									//							if ([self.tfEmail.text isEqualToString:[[arr objectAtIndex:i] valueForKey:EMAIL]]) {
									//								breakReason = 3;
									//								break;
									//							}
								}
									break;
								default:
									break;
							}
							if (breakReason != -1) {
								break;
							}
						}
						if (breakReason != -1) {
							break;
						}
					}
					
					if (breakReason == 1) {
						[Validation showToastMessage:@"Username already exist" displayDuration:ERROR_MSG_DURATION];
						[Validation highLightTextField:self.tfUserName inView:self.scrollContainer];
					}
					else if (breakReason == 2){
						[Validation showToastMessage:@"Email already exist" displayDuration:ERROR_MSG_DURATION];
						[Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
					}
					else if (breakReason == 3){
						[AlertHandler alertTitle:ALERT message:@"User already exist" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
					}
				}
				
			}
			else if (request.tag == 1){
				//username Exists
				NSLog(@"resposne = %@",response);
				if ([response isKindOfClass:[NSDictionary class]]) {
					if (((NSDictionary *)response).count>0) {
						[Validation showToastMessage:@"Username already exist" displayDuration:ERROR_MSG_DURATION];
						[Validation highLightTextField:self.tfUserName inView:self.scrollContainer];
					}
				}
				else if ([response isKindOfClass:[NSArray class]]){
					if (((NSArray *)response).count > 0) {
						[Validation showToastMessage:@"Username already exist" displayDuration:ERROR_MSG_DURATION];
						[Validation highLightTextField:self.tfUserName inView:self.scrollContainer];
					}
				}
			}
			else if (request.tag == 2){
				//email exists
				if ([response isKindOfClass:[NSDictionary class]]) {
					if (((NSDictionary *)response).count>0) {
						[Validation showToastMessage:@"Email already exist" displayDuration:ERROR_MSG_DURATION];
						[Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
					}
				}
				else if ([response isKindOfClass:[NSArray class]]){
					if (((NSArray *)response).count > 0) {
						[Validation showToastMessage:@"Email already exist" displayDuration:ERROR_MSG_DURATION];
						[Validation highLightTextField:self.tfEmail inView:self.scrollContainer];
					}
				}
			}
			else if (request.tag == 4){
				//registration successfull
				
				[Validation showToastMessage:[NSString stringWithFormat:@"Welcome\n%@",[DataValidation checkNullString:self.tfUserName.text]] displayDuration:SUCCESS_MSG_DURATION];
				NSMutableDictionary *dic = nil;
				
				if ([response isKindOfClass:[NSDictionary class]]) {
					if (((NSDictionary *)response).count>0) {
						dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)response];
					}
				}
				else if ([response isKindOfClass:[NSArray class]]){
					if (((NSArray *)response).count > 0) {
						dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[response objectAtIndex:0]];
					}
				}
				
				[dic setValue:self.tfPassword.text forKey:LOGIN_USER_KEY];

				[Validation setAllKeyValueFromData:dic];
                
                [self performSegueWithIdentifier:INTRODUCTION_VC sender:nil];
				
				dic = nil;
			}
			//self.request = nil;
			response = nil;
		}
		else if ([[dicResponse valueForKey:STATUS] intValue] == 0){
			if (request.tag == 3) {
			 // no entry for this user in DB
				//so register
					//it means data is correct
					//create new user
                
                NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                            [DataValidation checkNullString:self.tfUserName.text],SIGNUP_USERNAME,
                                            [DataValidation checkNullString:self.tfEmail.text],SIGNUP_EMAIL,
                                            [DataValidation checkNullString:self.tfPassword.text],SIGNUP_PASSWORD,
                                            nil];
                [[NSUserDefaults standardUserDefaults] setValue:dic forKey:DIC_SIGNUP];
                [[NSUserDefaults standardUserDefaults] synchronize];
                
                [self performSegueWithIdentifier:INTRODUCTION_VC sender:nil];
			}
            else if (request.tag == 4){
                [HUD hide:YES];
                [Validation showToastMessage:@"Could not register due to some issues.\nPlease try again later." displayDuration:ERROR_MSG_DURATION];

            }
		}
        else if ([[dicResponse valueForKey:STATUS] intValue] == 1){
            if (request.tag == 4){
                
                [HUD hide:YES];
                [Validation showToastMessage:[NSString stringWithFormat:@"Welcome\n%@",[DataValidation checkNullString:self.tfUserName.text]] displayDuration:SUCCESS_MSG_DURATION];
                id response = [dicResponse objectForKey:RESPONSE];
                NSMutableDictionary *dic = nil;
                
                if ([response isKindOfClass:[NSDictionary class]]) {
                    if (((NSDictionary *)response).count>0) {
                        dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)response];
                    }
                }
                else if ([response isKindOfClass:[NSArray class]]){
                    if (((NSArray *)response).count > 0) {
                        dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[response objectAtIndex:0]];
                    }
                }
                NSLog(@"dic after sign up user %@",dic);
                [dic setValue:self.tfPassword.text forKey:LOGIN_USER_KEY];
                [Validation setAllKeyValueFromData:dic];
                [self performSegueWithIdentifier:INTRODUCTION_VC sender:nil];
                
                response = nil;
                dic = nil;
            }
        }
		else{
			[HUD hide:YES];
			[Validation showToastMessage:@"Request failure.\nPlease try again saving." displayDuration:ERROR_MSG_DURATION];
		}
	}
	else{
		[HUD hide:YES];
		[Validation showToastMessage:@"Request failure.\nPlease try again saving." displayDuration:ERROR_MSG_DURATION];
	}
	dicResponse = nil;
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
	
	
	if ([segue.identifier isEqualToString:PROFILE_VC]) {
        [self cleanAllValuesFromView];
		ProfileVC *obj = segue.destinationViewController;
		FBProfilePictureView *profileImage = [[FBProfilePictureView alloc] initWithProfileID:[[NSUserDefaults standardUserDefaults]valueForKey:FB_ID] pictureCropping:FBProfilePictureCroppingOriginal];

		obj.img_UserProfileImg.image = (UIImage *)profileImage;
	}
    else if ([segue.identifier isEqualToString:INTRODUCTION_VC]){
        [self cleanAllValuesFromView];
        IntroductionVC *obj = segue.destinationViewController;
        obj.isFromRegister = YES;
        obj.strShowSkip = @"1";
        NSLog(@"OBJ = %@",obj);
    }
    else if ([segue.identifier isEqualToString:@"TermsAndConditionsPrivacyPolicyVC"]){
        isGoingToTandCorPP = YES;
        TermsAndConditionsPrivacyPolicyVC *obj = segue.destinationViewController;
        if (showUrlInWeb==1) {
            obj.strUrl = TERMS_AND_CONDITION;
        }
        else{
            obj.strUrl = PRIVACY_POLICY;
        }
    }
}
-(IBAction)btnTermsAndConditions_Clicked:(id)sender{
    showUrlInWeb = 1;
    [self performSegueWithIdentifier:@"TermsAndConditionsPrivacyPolicyVC" sender:nil];
}
-(IBAction)btnPrivacyPolicy_Clicked:(id)sender{
    showUrlInWeb = 2;
    [self performSegueWithIdentifier:@"TermsAndConditionsPrivacyPolicyVC" sender:nil];
}
#pragma mark UITouch Methods

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [[event allTouches] anyObject];
    if (![touch.view isKindOfClass:[UIScrollView class]]) {
        [self HideKeyboard];
    }
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
