//
//  TermsAndConditionsPrivacyPolicyVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 4/2/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "TermsAndConditionsPrivacyPolicyVC.h"

@interface TermsAndConditionsPrivacyPolicyVC ()

@end

@implementation TermsAndConditionsPrivacyPolicyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSURLRequest *req = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:self.strUrl]];
    [webView loadRequest:req];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
}
-(IBAction)btnBack_Clicked:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
