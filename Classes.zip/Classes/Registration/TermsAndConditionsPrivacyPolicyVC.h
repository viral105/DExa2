//
//  TermsAndConditionsPrivacyPolicyVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 4/2/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TermsAndConditionsPrivacyPolicyVC : UIViewController{
    IBOutlet UIWebView *webView;
}
@property (nonatomic, strong) NSString *strUrl;
@end
