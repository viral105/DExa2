//
//  FindFriendsOnFB_VC.m
//  WWHHAAZZAAPP
//
//  Created by Nivid on 19/03/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "FindFriendsOnFB_VC.h"
#import "FbOrContactUserListVC.h"

@interface FindFriendsOnFB_VC () <MBProgressHUDDelegate> {
    MBProgressHUD *HUD;
}
@end

@implementation FindFriendsOnFB_VC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:30];
    [self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    UIButton *btnSkip = (UIButton *)[self.view viewWithTag:111];
    [btnSkip.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [btnSkip setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
}
- (void)viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)btnFindFB_Friends:(id)sender{
    [self addFaceBookFriends];
}

-(IBAction)btnSkipClicked:(id)sender{
    [self moveToNextVC];
}

-(void)addFaceBookFriends{
    NSLog(@"fb btn pressed");
    //[Validation showLoadingIndicator];
    [HUD show:YES];
    
    
    if (!FBSession.activeSession.isOpen) {
        // if the session is closed, then we open it here, and establish a handler for state changes
        [FBSession openActiveSessionWithReadPermissions:@[@"public_profile", @"email", @"user_friends"]
                                           allowLoginUI:YES
                                      completionHandler:^(FBSession *session,
                                                          FBSessionState state,
                                                          NSError *error) {
                                          if (error) {
                                              [HUD hide:YES];
                                              UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                                                  message:@"Could not get your Facebook data.\nPlease check you internet connectivity or try later."
                                                                                                 delegate:nil
                                                                                        cancelButtonTitle:@"OK"
                                                                                        otherButtonTitles:nil];
                                              [alertView show];
                                          } else if (session.isOpen) {
                                              // [self pickFriendsButtonClick:sender];
                                              NSLog(@"facebook login");
                                              [self getUserInfo];
                                          }
                                      }];
        return;
    }
    else if (FBSession.activeSession.isOpen) {
        NSLog(@"facebook login");
        [self getUserInfo];
    }
}

- (void)GetUserFriendList {
    
    [FBRequestConnection startWithGraphPath:@"/me/friends"
                                 parameters:nil
                                 HTTPMethod:@"GET"
                          completionHandler:^(
                                              FBRequestConnection *connection,
                                              id result,
                                              NSError *error
                                              ) {
                              /* handle the result */
                              NSLog(@"%@",result);
                              NSArray *arr = [((NSArray *)[result valueForKey:@"data"]) valueForKey:@"id"];
                              [self addFacebookFreinds:arr];
                          }
     ];
    
}

-(void)getUserInfo{
    //[Validation showLoadingIndicator];
    [HUD show:YES];
    [[FBRequest requestForMe] startWithCompletionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
        //result contains a dictionary of your user, including Facebook ID.
        NSLog(@"result=  %@",result);
        self.strFBID = [result valueForKey:@"id"];
        [self GetUserFriendList];
        
    }];
}

-(void)addFacebookFreinds:(NSArray *)arrFbId{
    [HUD show:YES];
/*    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[arrFbId componentsJoinedByString:@"|"]],KeyValue,@"FacebookIDs",KeyName, nil],@"2",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:ADD_FB_FRIENDS withParameters:nil];
*/
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[arrFbId componentsJoinedByString:@"|"]],KeyValue,@"FacebookIDs",KeyName, nil],@"2",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_FB_OR_CONTACT_USER withParameters:nil];
    ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:4];
    }
//    request.delegate = self;
//    request.tag = 4;
    strUrl = nil;
}

-(void)checkFBID_Exist{
    NSLog(@"%@",[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]);
    if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]].length == 0) {
        [HUD show:YES];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"emailID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"userName",KeyName, nil],@"2",
                             [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:self.strFBID isGeneral:YES],KeyValue,@"facebookID",KeyName, nil],@"3",
                             [NSDictionary dictionaryWithObjectsAndKeys:@"-1",KeyValue,@"IsActive",KeyName, nil],@"4",
                             nil];
        
        NSString *strUrl = [WebServiceContainer getServiceURL:CHECK_USER_EXIST withParameters:nil];
        ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
        if (request == nil) {
            [HUD hide:YES];
        }
        else{
            [request setDelegate:self];
            [request setTag:5];
        }
//        request.delegate = self;
//        request.tag = 5;
        strUrl = nil;
        
    }
    else{
        [HUD hide:YES];
        
        if (self.arrUserList.count==0) {
            [self moveToNextVC];
        }
        else{
            FbOrContactUserListVC *obj = [self.storyboard instantiateViewControllerWithIdentifier:@"FbOrContactUserListVC"];
            obj.arrUsers = [NSMutableArray new];
            [obj.arrUsers addObjectsFromArray:self.arrUserList];
            obj.isFromContact = NO;
            obj.isSignUpFlow = YES;
            [self.navigationController pushViewController:obj animated:YES];
        }
    }
}

- (void)requestFinished:(ASIHTTPRequest *)request{
    //	NSError *error = nil;
    
    NSLog(@"response =%@",[request responseString]);
    
    
    NSError *error= nil;
    id response = [NSJSONSerialization JSONObjectWithData:[request responseData] options:0 error:&error];
    NSMutableDictionary *dic  = nil;
    NSLog(@"%@",response);
    
    [HUD hide:YES];
    
    if (response != nil) {
        
        if (request.tag == 5) {
            //it is check user exists, which wont return userStatus as we are not passing header
            //check user exist
            if ([response objectForKey:RESPONSE] != nil) {
                
                if ([[response valueForKey:STATUS] intValue] != -1 && [[response valueForKey:STATUS] intValue] != 0) {
                    response = [response objectForKey:RESPONSE];
                    
                    if ([response isKindOfClass:[NSArray class]]) {
                        if (((NSDictionary *)response).count>0) {
                            //so call login service
                            if ([response isKindOfClass:[NSArray class]]) {
                                int breakReason = -1;
                                NSArray *arr = [NSArray arrayWithArray:(NSArray *)response];
                                self.isFBID_Exists = YES;
                                for (int i = 0; i<arr.count; i++) {
                                    for (int y = 0; y<3; y++) {
                                        switch (y) {
                                            case 0:{
                                                //check for username
                                                
                                            }
                                                break;
                                            case 1:{
                                                //check for email
                                                
                                            }
                                                break;
                                            case 2:{
                                                //check for fb ID
                                                if ([self.strFBID isEqualToString:[NSString stringWithFormat:@"%@",[[arr objectAtIndex:i] valueForKey:FB_ID]]]) {
                                                    breakReason = 3;
                                                    break;
                                                }
                                            }
                                                break;
                                            default:
                                                break;
                                        }
                                        if (breakReason != -1) {
                                            break;
                                        }
                                    }
                                    if (breakReason != -1) {
                                        break;
                                    }
                                }
                                
                                if (breakReason == 3) {
                                    //fb id exists
                                    self.isFBID_Exists = YES;
                                }
                                else if (breakReason == -1){
                                    //fb id does not exists
                                    self.isFBID_Exists = NO;
                                }
                            }
                        }
                        else {
                            self.isFBID_Exists = NO;
                        }
                    }
                    else if (response==nil){
                        self.isFBID_Exists = NO;
                    }
                    
                    if (!self.isFBID_Exists) {
                        //FBID doesnot exists, so edit user profile
                        [self UpdateFBID];
                    }
                    else{
                        //fbid exists so no need to update

                        if (self.arrUserList.count==0) {
                            [self moveToNextVC];
                        }
                        else{
                            FbOrContactUserListVC *obj = [self.storyboard instantiateViewControllerWithIdentifier:@"FbOrContactUserListVC"];
                            obj.arrUsers = [NSMutableArray new];
                            [obj.arrUsers addObjectsFromArray:self.arrUserList];
                            obj.isFromContact = NO;
                            obj.isSignUpFlow = YES;
                            [self.navigationController pushViewController:obj animated:YES];
                        }
                    }
                    
                }
            }
        }
        else if (![[NSString stringWithFormat:@"%@",[[response valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",response);
            [appDelegate callLogOutService];
        }
        else{
            if (request.tag == 1) {
                if ([[response valueForKey:STATUS] intValue] != 0) {
                    response = [response valueForKey:RESPONSE];
                    if (response != nil) {
                        if ([[response valueForKey:RESPONSE] isKindOfClass:[NSDictionary class]]) {
                            dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)response];
                        }
                        else if ([[response valueForKey:RESPONSE] isKindOfClass:[NSArray class]]){
                            dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[response objectAtIndex:0]];
                        }
                        
                        [Validation setAllKeyValueFromData:dic];
                        dic = nil;
                        [HUD hide:YES];
 
                        if (self.arrUserList.count==0) {
                            [self moveToNextVC];
                        }
                        else{
                            FbOrContactUserListVC *obj = [self.storyboard instantiateViewControllerWithIdentifier:@"FbOrContactUserListVC"];
                            obj.arrUsers = [NSMutableArray new];
                            [obj.arrUsers addObjectsFromArray:self.arrUserList];
                            obj.isFromContact = NO;
                            obj.isSignUpFlow = YES;
                            [self.navigationController pushViewController:obj animated:YES];
                        }
                    }
                }
            }

            if (request.tag == 4){
                //add fb friends
                [HUD hide:YES];
                if ([[response objectForKey:RESPONSE] isKindOfClass:[NSArray class]]) {
                    NSArray *arr = [NSArray arrayWithArray:(NSArray *)[response objectForKey:RESPONSE]];
                    self.arrUserList = [NSMutableArray new];
                    [self.arrUserList addObjectsFromArray:arr];
                }
                
                

                [self checkFBID_Exist];
            }
            else if (request.tag == 5){
                [HUD hide:YES];

            }
        }
        
        
        response = nil;
        dic = nil;
    }
}

-(void)UpdateFBID{
    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Name",KeyName, nil],@"1",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Phone",KeyName, nil],@"2",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Email",KeyName, nil],@"3",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"UserName",KeyName, nil],@"4",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Pwd",KeyName, nil],@"5",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"DateOfBirth",KeyName, nil],@"6",
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:LOGIN_USER_GENDER]],KeyValue,@"Gender",KeyName, nil],@"7",
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"ID",KeyName, nil],@"8",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"ImgData",KeyName, nil],@"9",
                          [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:self.strFBID].length > 0)?self.strFBID:@"",KeyValue,@"FacebookID",KeyName, nil],@"10",
                          nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:EDIT_USER_PROFILE withParameters:nil];
    ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:1];
    }
//    request.delegate = self;
//    request.tag = 1;
    strUrl = nil;

}
-(void)moveToNextVC{
    [HUD hide:YES];
    appDelegate.selectedMenuIndex = 0;
    //   UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
    
    [UIView transitionWithView:self.navigationController.view
                      duration:0.5
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        [self.navigationController pushViewController:ivc animated:NO];
                    }
                    completion:nil];
    
    //    appDelegate.selectedMenuIndex = 0;
    //    [self performSegueWithIdentifier:NOTIFICATION_VC sender:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
