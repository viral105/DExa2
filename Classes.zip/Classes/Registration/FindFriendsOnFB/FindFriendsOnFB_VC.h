//
//  FindFriendsOnFB_VC.h
//  WWHHAAZZAAPP
//
//  Created by Nivid on 19/03/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FindFriendsOnFB_VC : UIViewController

@property (nonatomic, strong) NSString					*strFBID;
@property (nonatomic, readwrite) BOOL					isFBID_Exists;
@property (nonatomic, strong) IBOutlet UILabel *lblTitle;
@property (strong,nonatomic) NSMutableArray *arrUserList;

@end
