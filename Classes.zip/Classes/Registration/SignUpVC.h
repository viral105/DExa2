//
//  SignUpVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 7/29/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShowPickerVC.h"
#import "IntroductionVC.h"
#import "TermsAndConditionsPrivacyPolicyVC.h"

@interface SignUpVC : UIViewController <UITextFieldDelegate>

@property (nonatomic, strong) IBOutlet UITextField		*tfUserName;
@property (nonatomic, strong) IBOutlet UITextField		*tfEmail;
@property (nonatomic, strong) IBOutlet UITextField		*tfPassword;
//@property (nonatomic, strong) IBOutlet UITextField		*tfConfirmPassword;
//@property (nonatomic, strong) IBOutlet UITextField		*tfMobileNo;
//@property (nonatomic, strong) IBOutlet UIButton			*btnDOB;
//@property (nonatomic, strong) IBOutlet UIButton			*btnGender;
//@property (nonatomic, strong) IBOutlet UIButton			*btnProfilePrivacy;

@property (nonatomic, strong) IBOutlet UIButton			*btnSignUp;
@property (nonatomic, strong) IBOutlet UILabel			*lblTitle;

@property (nonatomic, strong) IBOutlet UIScrollView		*scrollContainer;
@property (nonatomic, readwrite) BOOL                   isBackClicked;
@property (nonatomic, strong) ASIHTTPRequest			*request;

@property (nonatomic, readwrite) int					Count;

//@property (nonatomic, readwrite) int                    selectedGender;
////@property (nonatomic, readwrite) int                    selectedBtnForDate;
//@property (nonatomic, readwrite) int                    selectedProfile;        //0=public, 1= private
//@property (nonatomic, strong) NSString                  *strDOB;
//@property (nonatomic, strong) ShowPickerVC              *objPkrView;

@end
