//
//  SinUpGetUserContactNumberVC.m
//  WWHHAAZZAAPP
//
//  Created by Nivid on 19/03/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "SinUpGetUserContactNumberVC.h"
#import "MBProgressHUD.h"
#import "FindFriendsOnFB_VC.h"
#import "FbOrContactUserListVC.h"

@interface SinUpGetUserContactNumberVC () <MBProgressHUDDelegate> {
    MBProgressHUD *HUD;
}



@end

@implementation SinUpGetUserContactNumberVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    [self.tfPhoneNumber becomeFirstResponder];
    
    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:30];
    [self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    [self.tfPhoneNumber setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [self.tfPhoneNumber setTextColor:UIColorFromRGB(0X585f66)];
    [self.tfPhoneNumber setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
   
    UIButton *btnNext = (UIButton *)[self.view viewWithTag:110];
    [btnNext.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [btnNext setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
    
    UIButton *btnSkip = (UIButton *)[self.view viewWithTag:111];
    [btnSkip.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [btnSkip setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
    
    
    
    [AlertHandler alertTitle:@"Info" message:@"You may have friends already in Blabeey who are anxious to Blab with you. Please tell us your phone number so that we may look to see if any of your friends are already here." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
}
- (void) viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    
}

-(IBAction)btnSaveClicked:(id)sender{
    [self.tfPhoneNumber resignFirstResponder];
    NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"1234567890"];
    s = [s invertedSet];
    NSRange r = [self.tfPhoneNumber.text rangeOfCharacterFromSet:s];
    if ([DataValidation checkNullString:self.tfPhoneNumber.text].length==0) {
        [Validation showToastMessage:@"Please enter valid\ncontact number." displayDuration:ERROR_MSG_DURATION];
        return;
    }
    else if ([DataValidation checkNullString:self.tfPhoneNumber.text].length > 0 && !([self.tfPhoneNumber.text length] >= 10 && self.tfPhoneNumber.text.length <= 15)){
        [Validation showToastMessage:@"Contact number must be of 10-15 digit." displayDuration:ERROR_MSG_DURATION];
        return;
    }
    else if (r.location != NSNotFound) {
        //  HAVE TO CHECK FOR NUMBERS ONLY HERE ALSO. BECAUSE IT IS POSSIBLE USER CAN COPY PASTE TEXT IN TEXT FIELD.
        [Validation showToastMessage:@"Please enter only numbers." displayDuration:ERROR_MSG_DURATION];
        return;
    }
    else{
        [HUD show:YES];
        [self SendUserContactListToServer];
    }
}

-(IBAction)btnSkipClicked:(id)sender{
    [self.tfPhoneNumber resignFirstResponder];
    FindFriendsOnFB_VC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:FIND_FRIENDS_ON_FB_VC];
    [self.navigationController pushViewController:obj animated:YES];
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag==1) {
        [self btnSkipClicked:nil];
    }
    
}
#pragma mark UITextfieldDelegate

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (range.location==1 && ![string isEqualToString:@""]) {
        NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"1234567890"];
        s = [s invertedSet];
        NSRange r = [string rangeOfCharacterFromSet:s];
        if (r.location != NSNotFound) {
            return FALSE;
        }
    }
    return TRUE;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return TRUE;
}

-(void)SendUserContactListToServer{
    /*
     The piece of code in
     
     dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
     
     });
     
     is run asynchronously on a background thread. This is done because parsing data may be a time consuming task and it could block the main thread which would stop all animations and the application wouldn't be responsive.
     */
    
    __block NSArray *arr = nil;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        arr = [DataValidation getAllContacts];
        if (arr!=nil) {
            if (arr.count>0) {

//                [HUD show:YES];
                [self performSelector:@selector(sendContactToServer:) withObject:arr];
            }
            else{
                [HUD hide:YES];
            }
        }
        else{
            [HUD hide:YES];
            [AlertHandler alertTitle:CONFIRM message:@"Do you wish to find your FACEBOOK friends on Blabeey?" delegate:self tag:3 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
        }
        NSLog(@"%@",arr);
        
    });
}

-(void)sendContactToServer:(NSArray *)arr{
    NSString *strPhone = [DataValidation checkNullString:self.tfPhoneNumber.text];
    NSString *strContactNum;
    NSDictionary *dic1;
/*
    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                          [NSDictionary dictionaryWithObjectsAndKeys:(strPhone.length == 0)?@"":strPhone,KeyValue,@"PhoneNo",KeyName, nil],@"2",
                          [NSDictionary dictionaryWithObjectsAndKeys:[arr componentsJoinedByString:@"|"],KeyValue,@"ContactList",KeyName, nil],@"3",
                          nil];
*/
    if (strPhone.length==0) {
        strContactNum = @"";
        dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                [NSDictionary dictionaryWithObjectsAndKeys:[arr componentsJoinedByString:@"|"],KeyValue,@"PhoneList",KeyName, nil],@"2",
                nil];
    }
    else{
        strContactNum = self.tfPhoneNumber.text;
        dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                [NSDictionary dictionaryWithObjectsAndKeys:strContactNum,KeyValue,@"MyPhone",KeyName, nil],@"2",
                [NSDictionary dictionaryWithObjectsAndKeys:[arr componentsJoinedByString:@"|"],KeyValue,@"PhoneList",KeyName, nil],@"3",
                nil];
    }
//    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_USER_CONTACT_LIST withParameters:nil];
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_FB_OR_CONTACT_USER withParameters:nil];
    ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:3];
    }
//    request.delegate = self;
//    request.tag = 3;
    strUrl = nil;
}
- (void)requestFinished:(ASIHTTPRequest *)request{
    NSError *error = nil;
    
    [HUD hide:YES];
    NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
                                                                 options:0
                                                                   error:&error];
    NSLog(@"response =%@",dicResponse);
    if (dicResponse != nil){
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [appDelegate callLogOutService];
        }
        else{
            if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if (request.tag == 3) {
                        NSArray *arr = [dicResponse objectForKey:RESPONSE];
                        if (arr.count!=0) {
                            [[NSUserDefaults standardUserDefaults] setValue:[DataValidation checkNullString:self.tfPhoneNumber.text] forKey:LOGIN_USER_PHONE];
                            [[NSUserDefaults standardUserDefaults] synchronize];
//                            [AlertHandler alertTitle:MESSAGE message:@"We have found a few of your friends in Blabeey.  Check your friend list and start a fun Blabeey conversation" delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                            [HUD hide:YES];
                            FbOrContactUserListVC *obj = [self.storyboard instantiateViewControllerWithIdentifier:@"FbOrContactUserListVC"];
                            obj.arrUsers = [NSMutableArray new];
                            [obj.arrUsers addObjectsFromArray:arr];
                            obj.isFromContact = YES;
                            obj.isSignUpFlow = YES;
                            [self.navigationController pushViewController:obj animated:YES];
                            
                        }
                        else{
                            [AlertHandler alertTitle:MESSAGE message:@"No friends found from your contacts" delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                        }
                        
                        
                    }
                }
            }
        }
    }
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [[event allTouches] anyObject];
    if (![touch.view isKindOfClass:[UITextField class]]) {
        [self.tfPhoneNumber resignFirstResponder];
    }
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
