//
//  SinUpGetUserContactNumberVC.h
//  WWHHAAZZAAPP
//
//  Created by Nivid on 19/03/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SinUpGetUserContactNumberVC : UIViewController <UITextFieldDelegate>

@property (nonatomic, strong) IBOutlet UITextField  *tfPhoneNumber;
@property (nonatomic, strong) IBOutlet UILabel *lblTitle;
@end
