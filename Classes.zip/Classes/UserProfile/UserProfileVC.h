//
//  UserProfileVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 3/27/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol UserProfileVCDelegate <NSObject>

-(void)hideUserProfileVC;
@optional
-(void)updateUserInfoFromPopup:(NSDictionary *)dic updatedInfo:(NSMutableDictionary *)updatedInfo;
-(void)btnAddFriendFromPopup_Clicked:(NSDictionary *)dicOld;
@end

@interface UserProfileVC : UIViewController<UITableViewDataSource,UITableViewDelegate,AFNetworkingDataTransactionDelegate,UIGestureRecognizerDelegate,UIScrollViewDelegate>{
    IBOutlet AsyncImageView *imgViewUser;
    IBOutlet UILabel *lblName;
    IBOutlet UILabel *lblUserName;
    IBOutlet UILabel *lblMaidenName;
    IBOutlet UILabel *lblAge;
    IBOutlet UIView *viewUserPopupSub1;
    IBOutlet UITableView *tblView;
    IBOutlet UIActivityIndicatorView *activityIndiView;
    IBOutlet AsyncImageView *imgViewUserBig;
    
    IBOutlet UIView *viewTransparent;
    IBOutlet UIView *viewUserData;
    IBOutlet UIView *viewUserImage;
}
@property (strong, nonatomic) IBOutlet UILabel *lblFriendCnt;
@property (strong, nonatomic) IBOutlet UILabel *lblFriendsCntTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblFollowersCnt;
@property (strong, nonatomic) IBOutlet UILabel *lblFollowersCntTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblHblabCnt;
@property (strong, nonatomic) IBOutlet UILabel *lblHblabCntTitle;
@property (strong, nonatomic) IBOutlet UIButton *btnBorderHblab;
@property (strong, nonatomic) IBOutlet UIButton *btnFollow;
@property (strong, nonatomic) IBOutlet UIButton *btnAddFriend;
@property (strong, nonatomic) IBOutlet UIButton *btnBlock;
@property (strong, nonatomic) IBOutlet UIView *viewInfo1;
@property (strong, nonatomic) IBOutlet UIView *viewInfo2;
@property (strong, nonatomic) IBOutlet UIPageControl *pageControl;
@property (strong, nonatomic) IBOutlet UIScrollView *scrlUserInfo;
@property (strong, nonatomic) IBOutlet UIView *viewContainingUserInfo;
@property (nonatomic,strong) NSMutableDictionary *dicUserDetail;
@property (strong, nonatomic) IBOutlet UIButton *btnShareProfile;

@property (nonatomic, strong) id<UserProfileVCDelegate> delegate;
@property (nonatomic, strong) NSDictionary *dicSelected;
@property (nonatomic, strong) NSString *strUserID;
@property (nonatomic, assign) int selType;  //      1 means display big image 2 means display user data
-(void)updateUserInfo;
-(void)LoadViewSetting;
@end
