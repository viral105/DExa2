//
//  UserProfileVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 3/27/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "UserProfileVC.h"
#import "UserChannelVC.h"
#import "FriendListVC.h"

#define Str_Follow  [NSString stringWithFormat:@"Follow\nChannel"]
#define Str_Unfollow  [NSString stringWithFormat:@"Unfollow\nChannel"]
#define Str_Add_Friend  @"Add Friend"
#define Str_Req_Send  @"Req. Sent"
#define Str_Req_Recieved  @"Req. Received"
#define Str_Unfriend  @"Unfriend"
#define Str_Block  @"Block"
#define Str_Unblock  @"Unblock"
#define Max_Page    2

@interface UserProfileVC (){
    NSMutableArray *arrCatInt;
    NSMutableArray *arrSubcatInt;
    NSMutableArray *arrCatProfileDesc;
    NSMutableArray *arrSubcatProfileDesc;
    AFNetworkingDataTransaction *request;
    
    AFNetworkingDataTransaction *requestFollowUnfollow;
    AFNetworkingDataTransaction *requestBlockUnblock;
    AFNetworkingDataTransaction *requestFriend;
    AFNetworkingDataTransaction *requestUnFriend;
//    AFNetworkingDataTransaction *request;
//    AFNetworkingDataTransaction *request;
    int cntPage;
}
@property (nonatomic,strong) NSMutableArray *arrCatInt;
@property (nonatomic,strong) NSMutableArray *arrSubcatInt;
@property (nonatomic,strong) NSMutableArray *arrCatProfileDesc;
@property (nonatomic,strong) NSMutableArray *arrSubcatProfileDesc;
@property (nonatomic,strong) AFNetworkingDataTransaction *request;

@end

@implementation UserProfileVC
@synthesize arrCatInt;
@synthesize arrSubcatInt;
@synthesize arrCatProfileDesc;
@synthesize arrSubcatProfileDesc;
@synthesize request;
@synthesize dicUserDetail;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.arrCatInt = [NSMutableArray new];
    self.arrSubcatInt = [NSMutableArray new];
    self.arrCatProfileDesc = [NSMutableArray new] ;
    self.arrSubcatProfileDesc = [NSMutableArray new];
    cntPage = 1;
    lblName.text = @"";

    UITapGestureRecognizer *tapGesture1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideSelfView:)];
    tapGesture1.delegate = self;
    [tapGesture1 setNumberOfTapsRequired:1];
    [viewTransparent setUserInteractionEnabled:YES];
    [viewTransparent addGestureRecognizer:tapGesture1];

/*
    UITapGestureRecognizer *tapGesture2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideSelfView:)];
    tapGesture2.delegate = self;
    [tapGesture2 setNumberOfTapsRequired:1];
    [viewUserData setUserInteractionEnabled:YES];
    [viewUserData addGestureRecognizer:tapGesture2];
    
    UITapGestureRecognizer *tapGesture3 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideSelfView:)];
    tapGesture3.delegate = self;
    [tapGesture3 setNumberOfTapsRequired:1];
    [viewUserImage setUserInteractionEnabled:YES];
    [viewUserImage addGestureRecognizer:tapGesture3];
*/
    
//    tapGesture1 = nil;
//    tapGesture2 = nil;
//    tapGesture3 = nil;
}
-(void)LoadViewSetting{
    NSLog(@"self.dicUserDetail %@",self.dicUserDetail);
    if ([[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:IS_USER_BLOCKED]] boolValue]) {
        self.btnBlock.layer.cornerRadius = 10.0;
        self.btnBlock.layer.borderWidth = 1.0f;
        self.btnBlock.layer.borderColor = [UIColor blackColor].CGColor;
        self.btnBlock.backgroundColor = [UIColor blackColor];
        [self.btnBlock setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.btnBlock setTitle:Str_Unblock forState:UIControlStateNormal];
    }
    else{
        self.btnBlock.layer.cornerRadius = 10.0;
        self.btnBlock.layer.borderWidth = 1.0f;
        self.btnBlock.layer.borderColor = [UIColor blackColor].CGColor;
        self.btnBlock.backgroundColor = [UIColor whiteColor];
        [self.btnBlock setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.btnBlock setTitle:Str_Block forState:UIControlStateNormal];
    }
    if ([[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:IS_Follow]] boolValue]) {
        self.btnFollow.layer.cornerRadius = 10.0;
        self.btnFollow.layer.borderWidth = 1.0f;
        self.btnFollow.layer.borderColor = UIColorFromRGB(0X00c2d9).CGColor;
        self.btnFollow.backgroundColor = UIColorFromRGB(0X00c2d9);
        [self.btnFollow setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.btnFollow setTitle:Str_Unfollow forState:UIControlStateNormal];
    }
    else{
        self.btnFollow.layer.cornerRadius = 10.0;
        self.btnFollow.layer.borderWidth = 1.0f;
        self.btnFollow.layer.borderColor = UIColorFromRGB(0X00c2d9).CGColor;
        self.btnFollow.backgroundColor = [UIColor whiteColor];
        [self.btnFollow setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
        [self.btnFollow setTitle:Str_Follow forState:UIControlStateNormal];
    }
    
    if ([[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:IS_FRIEND]] boolValue]) {
        self.btnAddFriend.layer.cornerRadius = 10.0;
        self.btnAddFriend.layer.borderWidth = 1.0f;
        self.btnAddFriend.layer.borderColor = UIColorFromRGB(0X00c2d9).CGColor;
        self.btnAddFriend.backgroundColor = UIColorFromRGB(0X00c2d9);
        [self.btnAddFriend setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.btnAddFriend setTitle:Str_Unfriend forState:UIControlStateNormal];
    }
    else if ([[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:IS_FRND_REQ_SENT]] boolValue]){
        self.btnAddFriend.layer.cornerRadius = 10.0;
        self.btnAddFriend.layer.borderWidth = 1.0f;
        self.btnAddFriend.layer.borderColor = UIColorFromRGB(0X00c2d9).CGColor;
        self.btnAddFriend.backgroundColor = [UIColor whiteColor];
        [self.btnAddFriend setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
        [self.btnAddFriend setTitle:Str_Req_Send forState:UIControlStateNormal];
    }
    else if ([[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:IS_FRND_REQ_REC]] boolValue]){
        self.btnAddFriend.layer.cornerRadius = 10.0;
        self.btnAddFriend.layer.borderWidth = 1.0f;
        self.btnAddFriend.layer.borderColor = UIColorFromRGB(0X00c2d9).CGColor;
        self.btnAddFriend.backgroundColor = [UIColor whiteColor];
        [self.btnAddFriend setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
        [self.btnAddFriend setTitle:Str_Req_Recieved forState:UIControlStateNormal];
    }
    else{
        self.btnAddFriend.layer.cornerRadius = 10.0;
        self.btnAddFriend.layer.borderWidth = 1.0f;
        self.btnAddFriend.layer.borderColor = UIColorFromRGB(0X00c2d9).CGColor;
        self.btnAddFriend.backgroundColor = [UIColor whiteColor];
        [self.btnAddFriend setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
        [self.btnAddFriend setTitle:Str_Add_Friend forState:UIControlStateNormal];
    }
    
    if ([[self.dicUserDetail valueForKey:@"TotalHashBlab"] intValue]==0) {
        self.btnFollow.hidden = YES;
        
        CGRect frame = self.btnAddFriend.frame;
        frame.origin.x = 30;
        self.btnAddFriend.frame = frame;
        
        frame= self.btnBlock.frame;
        frame.origin.x = 150;
        frame.size.width = 110;
        self.btnBlock.frame = frame;
    }

    UIColor *colorForText = [Validation getColorForAlphabet:[self.dicUserDetail valueForKey:@"Name"]];
    self.lblFriendCnt.textColor = colorForText;
    self.lblFriendsCntTitle.textColor = colorForText;
    self.lblFollowersCnt.textColor = colorForText;
    self.lblFollowersCntTitle.textColor = colorForText;
    self.lblHblabCnt.textColor = colorForText;
    self.lblHblabCntTitle.textColor = colorForText;
    self.btnBorderHblab.layer.borderWidth = 1.0f;
    self.btnBorderHblab.layer.borderColor = colorForText.CGColor;
    self.btnBorderHblab.layer.cornerRadius = 5.0f;
    
    self.btnShareProfile.layer.borderWidth = 1.0f;
    self.btnShareProfile.layer.borderColor = colorForText.CGColor;
    self.btnShareProfile.layer.cornerRadius = 5.0f;
    [self.btnShareProfile setTitleColor:colorForText forState:UIControlStateNormal];
    [self.btnShareProfile setTitle:@"Share\nProfile" forState:UIControlStateNormal];
    
    if ([[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:@"TotalFriend"]] intValue]<=1) {
        self.lblFriendsCntTitle.text = @"Friend";
    }
    if ([[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:@"TotalFollower"]] intValue]<=1) {
        self.lblFollowersCntTitle.text = @"Follower";
    }
    if ([[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:@"TotalHashBlab"]] intValue]<=1) {
        self.lblHblabCntTitle.text = @"Channel";
    }
    self.lblFriendCnt.text = [NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:@"TotalFriend"]];
    self.lblFollowersCnt.text = [NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:@"TotalFollower"]];
    self.lblHblabCnt.text = [NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:@"TotalHashBlab"]];
    
    imgViewUser.image = nil;
    imgViewUser.imageURL = [NSURL URLWithString:[self.dicUserDetail valueForKey:@"PhotoPath"]];
    
    self.scrlUserInfo.contentSize = CGSizeMake(600, 90);
    self.pageControl.hidden = NO;
    self.viewInfo1.frame = CGRectMake(0, 0, 300, 90);
    self.viewInfo1.hidden = NO;
    [self.scrlUserInfo addSubview:self.viewInfo1];
    
    self.viewInfo2.frame = CGRectMake(300, 0, 300, 90);
    self.viewInfo2.hidden = NO;
    [self.scrlUserInfo addSubview:self.viewInfo2];
    
}
-(void)updateUserInfo{
    if (self.selType==1) {
        viewUserData.hidden = YES;
        viewUserImage.hidden = NO;
        if ([self.strUserID isEqualToString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]]]) {
            imgViewUserBig.imageURL = [NSURL URLWithString:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]];
        }
        else{
            imgViewUserBig.imageURL = [NSURL URLWithString:[self.dicSelected valueForKey:@"PhotoPath"]];
        }
    }
    else{
        [self.view setUserInteractionEnabled:NO];
        viewUserImage.hidden = YES;
        viewUserData.hidden = NO;
        
        [Validation setCorners:imgViewUser];
        viewUserPopupSub1.layer.cornerRadius = 5.0f;
/*        if ([self.strUserID isEqualToString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]]]) {
            imgViewUser.imageURL = [NSURL URLWithString:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]];
        }
        else{
            imgViewUser.imageURL = [NSURL URLWithString:[self.dicSelected valueForKey:@"PhotoPath"]];
        }
*/        
        
        [self getUserDetail:self.dicSelected];
    }
    
}
/*
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if(touch.view == viewTransparent)
    {
        return YES;
    }
    else
    {
        return NO;
    }
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([viewUserData.subviews containsObject:touch.view] || [viewUserImage.subviews containsObject:touch.view])
        return NO;
    else
        return YES;
}*/
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)hideSelfView:(id)sender{
//    [self hideContentController:self];
    if (self.selType!=1) {
    NSMutableDictionary *dicUpdatedFlag = [NSMutableDictionary dictionaryWithObjectsAndKeys:[self.dicUserDetail valueForKey:IS_FRND_REQ_SENT],IS_FRND_REQ_SENT,[self.dicUserDetail valueForKey:IS_FRIEND],IS_FRIEND,[self.dicUserDetail valueForKey:IS_Follow],IS_Follow,[self.dicUserDetail valueForKey:IS_USER_BLOCKED],IS_USER_BLOCKED, nil];
    [self.delegate updateUserInfoFromPopup:self.dicSelected updatedInfo:dicUpdatedFlag];
    }
        [Validation animateYpoint:[UIScreen mainScreen].bounds.size.height viewToAnimate:self.view];
        
        [self performSelector:@selector(hideContentController:) withObject:self afterDelay:0.3];
    
    
}
- (void) hideContentController: (UIViewController*) content

{
    [content willMoveToParentViewController:nil];  // 1
    
    [content.view removeFromSuperview];            // 2
    
    [content removeFromParentViewController];      // 3
    
    
    [self.delegate hideUserProfileVC];
}

#pragma mark  UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (self.arrCatProfileDesc.count==0 && self.arrCatInt.count==0) {
        return 0;
    }
    else if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
        return 2;
    }
    else{
        return 1;
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UILabel *lblHeader = [[UILabel alloc] init];
    [lblHeader setFrame:CGRectMake(0, 0, tblView.frame.size.width, 30)];
    lblHeader.numberOfLines = 1;
    [lblHeader setFont:[UIFont boldSystemFontOfSize:16]];
    [lblHeader setBackgroundColor:[UIColor whiteColor]];
    [lblHeader setTextColor:[UIColor colorWithRed:98/255.0 green:106/255.0 blue:119/255.0 alpha:1]];
    [lblHeader setTextAlignment:NSTextAlignmentCenter];
    
    if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
        if (section==0) {
            [lblHeader setText:@"PROFILE DESCRIPTION"];
        }
        else{
            [lblHeader setText:@"INTEREST"];
        }
    }
    else if(self.arrCatInt.count==0 && self.arrCatProfileDesc.count!=0){
        [lblHeader setText:@"PROFILE DESCRIPTION"];
    }
    else if(self.arrCatInt.count!=0 && self.arrCatProfileDesc.count==0){
        [lblHeader setText:@"INTEREST"];
    }
    return lblHeader;

}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
        float height = 28;
        if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            if (indexPath.section==0) {
                CGSize rect = [self getHeightForSection:[self.arrSubcatProfileDesc objectAtIndex:indexPath.row]];
                NSLog(@"pro desc height %f ipath %d",rect.height,(int)indexPath.row);
                //                if ((int)rect.height>16) {
                height+=rect.height;
                //                }
            }
            else{
                CGSize rect = [self getHeightForSection:[self.arrSubcatInt objectAtIndex:indexPath.row]];
                NSLog(@"interest height %f ipath %d",rect.height,(int)indexPath.row);
                //                if ((int)rect.height>16) {
                height+=rect.height;
                //                }
            }
        }
        else if(self.arrCatInt.count==0 && self.arrCatProfileDesc.count!=0){
            CGSize rect = [self getHeightForSection:[self.arrSubcatProfileDesc objectAtIndex:indexPath.row]];
            NSLog(@"pro desc height %f ipath %d",rect.height,(int)indexPath.row);
            //            if ((int)rect.height>16) {
            height+=rect.height;
            //            }
        }
        else if(self.arrCatInt.count!=0 && self.arrCatProfileDesc.count==0){
            CGSize rect = [self getHeightForSection:[self.arrSubcatInt objectAtIndex:indexPath.row]];
            NSLog(@"interest height %f ipath %d",rect.height,(int)indexPath.row);
            //            if ((int)rect.height>16) {
            height+=rect.height;
            //            }
        }
        return height;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    //return self.arrData.count;

        if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            if (section==0) {
                return self.arrCatProfileDesc.count;
            }
            else{
                return self.arrCatInt.count;
            }
        }
        else if(self.arrCatInt.count==0 && self.arrCatProfileDesc.count!=0){
            return self.arrCatProfileDesc.count;
        }
        else if(self.arrCatInt.count!=0 && self.arrCatProfileDesc.count==0){
            return self.arrCatInt.count;
        }
        else{
            return 0;
        }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
        UserListingByInterestCatSubcatCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
        if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            if (indexPath.section==0) {
                cell.strCat = [self.arrCatProfileDesc objectAtIndex:indexPath.row];
                cell.strSubcat = [self.arrSubcatProfileDesc objectAtIndex:indexPath.row];
            }
            else{
                cell.strCat = [self.arrCatInt objectAtIndex:indexPath.row];
                cell.strSubcat = [self.arrSubcatInt objectAtIndex:indexPath.row];
            }
        }
        else if(self.arrCatInt.count==0 && self.arrCatProfileDesc.count!=0){
            cell.strCat = [self.arrCatProfileDesc objectAtIndex:indexPath.row];
            cell.strSubcat = [self.arrSubcatProfileDesc objectAtIndex:indexPath.row];
        }
        else if(self.arrCatInt.count!=0 && self.arrCatProfileDesc.count==0){
            cell.strCat = [self.arrCatInt objectAtIndex:indexPath.row];
            cell.strSubcat = [self.arrSubcatInt objectAtIndex:indexPath.row];
        }
        [cell setUI];
        return cell;
}
-(CGSize)getHeightForSection:(NSString *)strText{
    //    NSString *strText = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:NAME]];
    if (strText.length==0) {
        return CGSizeMake(0, 0);
    }
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    NSLog(@"************* %f",tblView.frame.size.width);
    CGRect text = [strText boundingRectWithSize:CGSizeMake(270, 10000)
                                        options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading
                                     attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14],NSParagraphStyleAttributeName:paragraphStyle}
                                        context:nil];
    strText = nil;
    return text.size;
    
}
-(void)getUserDetail:(NSDictionary*)dic{
    NSLog(@"userid-->> %@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]);
    NSDictionary *dicNew = [NSDictionary dictionaryWithObjectsAndKeys:
                            [NSDictionary dictionaryWithObjectsAndKeys:self.strUserID,KeyValue,@"UserID",KeyName, nil],@"1",
                            [NSDictionary dictionaryWithObjectsAndKeys:[[NSUserDefaults standardUserDefaults] valueForKey:W_ID],KeyValue,@"LoginUserID",KeyName, nil],@"2",
                            nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_USER_ALL_DETAIL withParameters:nil];
    
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dicNew isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
//        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:1];
    strUrl = nil;
    
}
#pragma mark
#pragma mark web service method
- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);

            [appDelegate callLogOutService];
        }
        else{
            if (tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.dicUserDetail = [NSMutableDictionary dictionaryWithDictionary:[[arr objectAtIndex:0] valueForKey:@"UserDetail"]];
                            
                            [self LoadViewSetting];
                            lblName.text =[[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"Name"];
                            lblAge.text = [NSString stringWithFormat:@"%d years old",[[[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"Age"] intValue]];
                            lblUserName.text = [[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"UserName"];
                            if ([DataValidation checkNullString:[[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"MaidenName"]].length!=0) {
                                lblMaidenName.text = [[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"MaidenName"];
                            }
                            else{
                                lblAge.frame = CGRectMake(lblAge.frame.origin.x, lblMaidenName.frame.origin.y, lblAge.frame.size.width, lblAge.frame.size.height);
                                self.btnFollow.frame = CGRectMake(self.btnFollow.frame.origin.x, self.btnFollow.frame.origin.y-20, self.btnFollow.frame.size.width, self.btnFollow.frame.size.height);
                                self.btnAddFriend.frame = CGRectMake(self.btnAddFriend.frame.origin.x, self.btnAddFriend.frame.origin.y-20, self.btnAddFriend.frame.size.width, self.btnAddFriend.frame.size.height);
                                self.btnBlock.frame = CGRectMake(self.btnBlock.frame.origin.x, self.btnBlock.frame.origin.y-20, self.btnBlock.frame.size.width, self.btnBlock.frame.size.height);
                            }
                            
                            [lblName setTextColor:[Validation getColorForAlphabet:lblName.text]];
                            [lblAge setTextColor:[Validation getColorForAlphabet:lblName.text]];
                            [lblUserName setTextColor:[Validation getColorForAlphabet:lblName.text]];
                            [lblMaidenName setTextColor:[Validation getColorForAlphabet:lblName.text]];
                            
                            lblName.text = [HASHTAG_CHARACTER stringByAppendingString:lblName.text];
                            
                            lblUserName.text = [[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"UserName"];//[HASHTAG_CHARACTER stringByAppendingFormat:@"%@",[[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"UserName"]];
                            
                            //                            NSLog(@"arr obj UserDescriptions %@ UserInterests %@",[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"],[[[[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] objectAtIndex:0] valueForKey:@"UserSubInterest"] objectAtIndex:0] valueForKey:@"Name"]);
                            
                            //                            NSString *strInterest = @"";
                            //                            NSString *strProfileDesc = @"";
                            for (int i=0; i<[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] count]; i++) {
                                [self.arrCatInt addObject:[[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] objectAtIndex:i] valueForKey:@"Name"]];
                                NSString *strInterest = @"";
                                for (int j=0; j<[[[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] objectAtIndex:i] valueForKey:@"UserSubInterest"] count]; j++) {
                                    strInterest = [strInterest stringByAppendingFormat:@"%@, ",[[[[[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] objectAtIndex:i] valueForKey:@"UserSubInterest"] objectAtIndex:j] valueForKey:@"Name"] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
                                }
                                if (strInterest.length==0) {
                                    [self.arrSubcatInt addObject:@""];
                                }
                                else{
                                    strInterest = [strInterest substringToIndex:strInterest.length-2];
                                    [self.arrSubcatInt addObject:[strInterest stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
                                }
                            }
                            NSLog(@"final strInterest %@ %@",self.arrCatInt,self.arrSubcatInt);
                            
                            for (int i=0; i<[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] count]; i++) {
                                [self.arrCatProfileDesc addObject:[[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] objectAtIndex:i] valueForKey:@"Name"]];
                                NSString *strProfileDesc = @"";// [strProfileDesc stringByAppendingFormat:@"%@, ",[[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] objectAtIndex:i] valueForKey:@"Name"]];
                                for (int j=0; j<[[[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] objectAtIndex:i] valueForKey:@"UserSubDesc"] count]; j++) {
                                    strProfileDesc = [strProfileDesc stringByAppendingFormat:@"%@, ",[[[[[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] objectAtIndex:i] valueForKey:@"UserSubDesc"] objectAtIndex:j] valueForKey:@"Name"] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
                                }
                                if (strProfileDesc.length==0) {
                                    [self.arrSubcatProfileDesc addObject:@""];
                                }
                                else{
                                    strProfileDesc = [strProfileDesc substringToIndex:strProfileDesc.length-2];
                                    [self.arrSubcatProfileDesc addObject:[strProfileDesc stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
                                }
                            }
                            NSLog(@"final strProfileDesc %@ %@",self.arrCatProfileDesc,self.arrSubcatProfileDesc);
                            //                            NSLog(@"final strProfileDesc %d %d",(int)self.arrCatProfileDesc.count,(int)self.arrSubcatProfileDesc.count);
                            [tblView reloadData];
                            /*
                             if (strInterest.length!=0) {
                             self.lblInterest.hidden=NO;
                             strInterest = [strInterest substringToIndex:strInterest.length-1];
                             }
                             self.tvPopupInterest.text = strInterest;
                             if (strProfileDesc.length!=0) {
                             strProfileDesc = [strProfileDesc substringToIndex:strProfileDesc.length-1];
                             }
                             
                             self.tvPopupProfileDesc.text = strProfileDesc;
                             */
                            [self.view setUserInteractionEnabled:YES];
                            [activityIndiView stopAnimating];
                            
                            arr = nil;
                        }
                    }
                }
                
            }
        }
    }
    else{

    }
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");

}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [self.view setUserInteractionEnabled:YES];
    [activityIndiView stopAnimating];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    NSLog(@"scrollViewDidEndDragging %f %f",scrollView.contentOffset.x,scrollView.contentOffset.y);
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
/*    if (scrollView==self.scrlUserInfo) {
        if (scrollView.contentOffset.x==0) {
            if (self.pageControl.currentPage==1) {
                self.pageControl.currentPage = 0;
                self.scrlUserInfo.contentSize = CGSizeMake(600, self.viewInfo1.frame.size.height);
                self.scrlUserInfo.contentOffset = CGPointMake(0, 0);
                self.pageControl.frame = CGRectMake(self.pageControl.frame.origin.x, self.pageControl.frame.origin.y+40, self.pageControl.frame.size.width, self.pageControl.frame.size.height);
                tblView.frame = CGRectMake(tblView.frame.origin.x, tblView.frame.origin.y+40, tblView.frame.size.width, tblView.frame.size.height);
            }
        }
        else if (scrollView.contentOffset.x==300){
            if (self.pageControl.currentPage==0) {
                self.pageControl.currentPage = 1;
                self.scrlUserInfo.contentSize = CGSizeMake(600, self.viewInfo2.frame.size.height);
                self.scrlUserInfo.contentOffset = CGPointMake(300, 0);
                self.pageControl.frame = CGRectMake(self.pageControl.frame.origin.x, self.pageControl.frame.origin.y-40, self.pageControl.frame.size.width, self.pageControl.frame.size.height);
                tblView.frame = CGRectMake(tblView.frame.origin.x, tblView.frame.origin.y-40, tblView.frame.size.width, tblView.frame.size.height);
            }
        }
    }
    NSLog(@"scrollViewDidEndDragging %f %f",scrollView.contentOffset.x,scrollView.contentOffset.y);
*/
    if (scrollView==self.scrlUserInfo) {
        if (scrollView.contentOffset.x==0) {
            if (self.pageControl.currentPage==1) {
                self.pageControl.currentPage = 0;
            }
        }
        else if (scrollView.contentOffset.x==300){
            if (self.pageControl.currentPage==0) {
                self.pageControl.currentPage = 1;
            }
        }
    }
}
#pragma mark IBActions
-(IBAction)btnBorderChannerCount_Clicked:(id)sender{
    NSLog(@"self.navigationController.viewControllers %@",self.navigationController.viewControllers);
    UserChannelVC *obj = [self.storyboard instantiateViewControllerWithIdentifier:@"UserChannelVC"];
    obj.dicSel = self.dicUserDetail;
    [self.navigationController pushViewController:obj animated:YES];
}
-(IBAction)btnFollow_Clicked:(id)sender{
    if ([self.btnFollow.currentTitle isEqualToString:Str_Follow]) {
        self.btnFollow.layer.cornerRadius = 10.0;
        self.btnFollow.layer.borderWidth = 1.0f;
        self.btnFollow.layer.borderColor = UIColorFromRGB(0X00c2d9).CGColor;
        self.btnFollow.backgroundColor = UIColorFromRGB(0X00c2d9);
        [self.btnFollow setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.btnFollow setTitle:Str_Unfollow forState:UIControlStateNormal];
        [self.dicUserDetail setValue:@"1" forKey:IS_Follow];
    }
    else{
        self.btnFollow.layer.cornerRadius = 10.0;
        self.btnFollow.layer.borderWidth = 1.0f;
        self.btnFollow.layer.borderColor = UIColorFromRGB(0X00c2d9).CGColor;
        self.btnFollow.backgroundColor = [UIColor whiteColor];
        [self.btnFollow setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
        [self.btnFollow setTitle:Str_Follow forState:UIControlStateNormal];
        [self.dicUserDetail setValue:@"0" forKey:IS_Follow];
    }
    [self performSelectorInBackground:@selector(doFollowUnfollow) withObject:nil];
}
-(IBAction)btnFriend_Clicked:(id)sender{
    if ([[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:IS_FRND_REQ_SENT]] boolValue] || [[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:IS_FRND_REQ_REC]] boolValue]) {
        return;
    }
    else if ([[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:IS_FRIEND]] boolValue]) {
        [AlertHandler alertTitle:CONFIRM message:@"Are you sure you want to unfriend selected friend?" delegate:self tag:1 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
    }
    else {
/*        self.btnAddFriend.layer.cornerRadius = 10.0;
        self.btnAddFriend.layer.borderWidth = 1.0f;
        self.btnAddFriend.layer.borderColor = UIColorFromRGB(0X00c2d9).CGColor;
        self.btnAddFriend.backgroundColor = [UIColor whiteColor];
        [self.btnAddFriend setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
        [self.btnAddFriend setTitle:Str_Req_Send forState:UIControlStateNormal];
        [self.dicUserDetail setValue:@"1" forKey:IS_FRND_REQ_SENT];
*/
        if ([[self.dicUserDetail valueForKey:IS_USER_BLOCKED] boolValue]) {
            [Validation showToastMessage:@"You cannot send friend request to a blocked user." displayDuration:ERROR_MSG_DURATION];
        }
        else{
            [self sendFriendReq];
        }
//        [self performSelectorInBackground:@selector(sendFriendReq) withObject:nil];
    }
}
-(IBAction)btnBlock_Clicked:(id)sender{
    if ([[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:IS_USER_BLOCKED]] boolValue]) {
        self.btnBlock.layer.cornerRadius = 10.0;
        self.btnBlock.layer.borderWidth = 1.0f;
        self.btnBlock.layer.borderColor = [UIColor blackColor].CGColor;
        self.btnBlock.backgroundColor = [UIColor whiteColor];
        [self.btnBlock setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.btnBlock setTitle:Str_Block forState:UIControlStateNormal];
        
        [self.dicUserDetail setValue:@"0" forKey:IS_USER_BLOCKED];
    }
    else{
        self.btnBlock.layer.cornerRadius = 10.0;
        self.btnBlock.layer.borderWidth = 1.0f;
        self.btnBlock.layer.borderColor = [UIColor blackColor].CGColor;
        self.btnBlock.backgroundColor = [UIColor blackColor];
        [self.btnBlock setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.btnBlock setTitle:Str_Unblock forState:UIControlStateNormal];
        [self.dicUserDetail setValue:@"1" forKey:IS_USER_BLOCKED];
    }
    [self performSelectorInBackground:@selector(doBlockUnblock) withObject:nil];
}
-(void)doFollowUnfollow{
    BOOL isFollow = [[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:IS_Follow]] boolValue];
    NSDictionary *dicNew = [NSDictionary dictionaryWithObjectsAndKeys:
                            [NSDictionary dictionaryWithObjectsAndKeys:[[NSUserDefaults standardUserDefaults] valueForKey:W_ID],KeyValue,@"FollowingID",KeyName, nil],@"1",
                            [NSDictionary dictionaryWithObjectsAndKeys:self.strUserID,KeyValue,@"FollowedBy",KeyName, nil],@"2",
                            [NSDictionary dictionaryWithObjectsAndKeys:(isFollow)?@"true":@"false",KeyValue,@"Status",KeyName, nil],@"3",
                            nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:FOLLOW_UNFOLLOW withParameters:nil];
    
    requestFollowUnfollow = [AFNetworkingDataTransaction sharedManager];
    [requestFollowUnfollow SetCallForURL:strUrl WithDic:dicNew isAddHeader:TRUE];
    if (requestFollowUnfollow._currentRequest == nil) {
    }
    else{
        [requestFollowUnfollow setDelegate:nil];
        [requestFollowUnfollow setTag:-1];
    }
    strUrl = nil;
}
-(void)doBlockUnblock{
    if (requestBlockUnblock._currentRequest!=nil) {
        NSLog(@"cancel block req");
        [requestBlockUnblock CancleOngoingRequest];
    }
    else{
        NSLog(@"not cancel block req");
    }
    BOOL isBlocked = [[NSString stringWithFormat:@"%@",[self.dicUserDetail valueForKey:IS_USER_BLOCKED]] boolValue];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:self.strUserID,KeyValue,@"BlockUserID",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:(isBlocked)?@"true":@"false",KeyValue,@"IsBlock",KeyName, nil],@"3",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:BLOCK_UNBLOCK_USER withParameters:nil];
    
    requestBlockUnblock = [AFNetworkingDataTransaction sharedManager];
    [requestBlockUnblock SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (requestBlockUnblock._currentRequest == nil) {
    }
    else{
        [requestBlockUnblock setDelegate:nil];
        [requestBlockUnblock setTag:-2];
    }
    strUrl = nil;
}
-(void)sendFriendReq{
    if (requestFriend._currentRequest !=nil) {
        [requestFriend CancleOngoingRequest];
    }
    [self.delegate btnAddFriendFromPopup_Clicked:self.dicSelected];
    
/*    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:self.strUserID,KeyValue,@"RequestID",KeyName, nil],@"2",
                         nil];
    
    
    NSString *strUrl = [WebServiceContainer getServiceURL:ADD_FRIEND withParameters:nil];
    requestFriend = [AFNetworkingDataTransaction sharedManager];
    [requestFriend SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (requestFriend._currentRequest == nil) {
        
    }
    else{
        [requestFriend setDelegate:nil];
        [requestFriend setTag:-4];
    }
    strUrl = nil;
*/
}
-(void)unFriendReq{
    self.btnAddFriend.layer.cornerRadius = 10.0;
    self.btnAddFriend.layer.borderWidth = 1.0f;
    self.btnAddFriend.layer.borderColor = UIColorFromRGB(0X00c2d9).CGColor;
    self.btnAddFriend.backgroundColor = [UIColor whiteColor];
    [self.btnAddFriend setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
    [self.btnAddFriend setTitle:Str_Add_Friend forState:UIControlStateNormal];
    [self.dicUserDetail setValue:@"0" forKey:IS_FRIEND];
    
    if (requestUnFriend._currentRequest !=nil) {
        [requestUnFriend CancleOngoingRequest];
    }
    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                          [NSDictionary dictionaryWithObjectsAndKeys:self.strUserID,KeyValue,@"FriendID",KeyName, nil],@"2",
                          nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:UNFRIEND_A_FRIEND withParameters:nil];
    requestUnFriend = [AFNetworkingDataTransaction sharedManager];
    [requestUnFriend SetCallForURL:strUrl WithDic:dic1 isAddHeader:TRUE];
    if (requestUnFriend._currentRequest == nil) {
        
    }
    else{
        [requestUnFriend setDelegate:nil];
        [requestUnFriend setTag:-3];
    }
    strUrl = nil;
}
-(IBAction)btnShareProfile_Clicked{
    
    FriendListVC *obj = [self.storyboard instantiateViewControllerWithIdentifier:@"FriendListVC"];
    obj.index = 0;
    obj.strShareId = self.strUserID;
    obj.strShareName = [self.dicUserDetail valueForKey:@"Name"];
    
    [self.navigationController pushViewController:obj animated:YES];
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 1) {
        //unfrind user
        if (buttonIndex == alertView.cancelButtonIndex) {
            
        }
        else{
            [self performSelectorInBackground:@selector(unFriendReq) withObject:nil];
        }
    }
}
@end
