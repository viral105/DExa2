//
//  UserCell.m
//  WWHHAAZZAAPP
//
//  Created by s on 8/8/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "UserCell.h"
#define CellHeight		90

@implementation UserCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
		self.backgroundColor = [UIColor clearColor];
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		
		float xStart = 5;
		float yStart = 5;
		
		self.cellBg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:LilstBox_Bg]];
        self.imgViewFriendType = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icn_friends_blabeey.png"]];
        self.imgViewIsNewFriend = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icn_new_user.png"]];
		self.ProfileImg = [[AsyncImageView alloc] init] ;
		self.btnNotificationProfile = [UIButton buttonWithType:UIButtonTypeCustom];
        self.btnDisplayName = [UIButton buttonWithType:UIButtonTypeCustom];
		self.lblDisplayName = [[UILabel alloc] init] ;
		self.lblUserName = [[UILabel alloc] init] ;
		self.imgFriendshipStatus = [[UIImageView alloc] init] ;
        self.btnUnfriend = [UIButton buttonWithType:UIButtonTypeCustom] ;
        self.btnRemoveFromGRP = [UIButton buttonWithType:UIButtonTypeCustom] ;
		self.btnUserBlocked = [UIButton buttonWithType:UIButtonTypeCustom];
        self.imgSelected = [[UIImageView alloc] init];
        self.lblDistance = [[UILabel alloc] init];
        self.btnFriendCount = [UIButton buttonWithType:UIButtonTypeCustom];
        self.lblMaidenName = [[UILabel alloc] init];
        self.btnPlayPause = [UIButton buttonWithType:UIButtonTypeCustom];
        
		self.cellBg.frame = CGRectMake(3.5, 4, 313, 92);
		
		xStart = 7;
		yStart = 10;
		
		self.ProfileImg.frame = CGRectMake(xStart, yStart, 66, 66);
		self.btnNotificationProfile.frame = self.ProfileImg.frame;
		self.btnDisplayName.frame = self.lblDisplayName.frame;
        
		xStart += self.ProfileImg.frame.size.width;
		xStart += 10;
		
		float lbl1Height = (self.ProfileImg.frame.size.height/2);
		float lbl2Height = (self.ProfileImg.frame.size.height/2)/2;
		yStart += (self.ProfileImg.frame.size.height-lbl1Height-lbl2Height)/2;
		
		self.lblDisplayName.frame = CGRectMake(xStart, yStart, self.cellBg.frame.size.width-xStart-45, self.ProfileImg.frame.size.height/2);
		
		//self.btnNotificationDetail.frame = CGRectMake(self.cellBg.frame.size.width-36, yStart, 36, self.ProfileImg.frame.size.height/2);
		
		//yStart = (CellHeight/2);
		yStart += self.lblDisplayName.frame.size.height;
		self.lblUserName.frame = CGRectMake(xStart, yStart, self.cellBg.frame.size.width-xStart-45, (self.ProfileImg.frame.size.height/2)/1.8);
		yStart += self.lblUserName.frame.size.height;
        
        self.lblDistance.frame  = CGRectMake(xStart, yStart, self.lblUserName.frame.size.width, 12);
        self.lblDistance.hidden = TRUE;
        yStart += self.lblDistance.frame.size.height;
        
        self.lblMaidenName.frame = CGRectMake(xStart, yStart, self.lblUserName.frame.size.width, 12);
        self.lblMaidenName.hidden = YES;
        
        self.btnFriendCount.frame = CGRectMake(xStart, yStart, self.lblUserName.frame.size.width, 12);
        self.btnFriendCount.hidden = YES;
        
		self.imgFriendshipStatus.frame = CGRectMake(self.frame.size.width-40, 10, 29, 30);
		self.imgFriendshipStatus.hidden = TRUE;
		
        self.btnRemoveFromGRP.frame = self.imgFriendshipStatus.frame;
        self.btnRemoveFromGRP.hidden = TRUE;
        
        
        self.btnUserBlocked.frame  = CGRectMake(self.frame.size.width-40, CellHeight-40, 29, 30);
        self.btnUserBlocked.hidden = YES;
        [self.btnUserBlocked setImage:[UIImage imageNamed:Btn_User_Blocked] forState:UIControlStateNormal];

        
        self.btnUnfriend.frame = CGRectMake(self.frame.size.width-40, self.frame.size.height-40, 30, 31);
        self.btnUnfriend.hidden = YES;
		
        self.imgSelected.frame = self.btnUserBlocked.frame;
        self.imgSelected.hidden = YES;
        
//		self.lblDisplayName.font = [UIFont fontWithName:Font_OpneSans_Light size:24];
		self.lblDisplayName.font = [UIFont fontWithName:Font_OpneSans_SemiBol size:24];
		self.lblUserName.font = [UIFont fontWithName:Font_OpneSans_Regular size:12];
		self.lblDistance.font = [UIFont fontWithName:Font_OpneSans_Regular size:10];
		
		self.lblDisplayName.backgroundColor = [UIColor clearColor];
		self.lblUserName.backgroundColor = [UIColor clearColor];
        self.lblDistance.backgroundColor = [UIColor clearColor];
		
		self.btnReqDeny = [UIButton buttonWithType:UIButtonTypeCustom];
		self.btnReqDeny.frame = CGRectMake(self.frame.size.width-90, 10, 29, 30);
		self.btnReqDeny.hidden = TRUE;
		
		self.btnReqStatus = [UIButton buttonWithType:UIButtonTypeCustom];
		self.btnReqStatus.frame = CGRectMake(self.frame.size.width-40, 10, 29, 30);
		self.btnReqStatus.hidden = TRUE;
				
        self.lblUserStatusInGrp = [[UILabel alloc] init];
        self.lblUserStatusInGrp.textAlignment = NSTextAlignmentRight;
        self.lblUserStatusInGrp.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
        self.lblUserStatusInGrp.textColor = UIColorFromRGB(0Xff5252);
        self.lblUserStatusInGrp.hidden = YES;

        
        
		[self.contentView addSubview:self.cellBg];
        [self.contentView addSubview:self.imgViewFriendType];
        [self.contentView addSubview:self.imgViewIsNewFriend];
		[self.contentView addSubview:self.ProfileImg];
		[self.contentView addSubview:self.btnNotificationProfile];
        
		[self.contentView addSubview:self.lblDisplayName];
        [self.contentView addSubview:self.btnDisplayName];
		[self.contentView addSubview:self.lblUserName];
		[self.contentView addSubview:self.imgFriendshipStatus];
        [self.contentView addSubview:self.btnRemoveFromGRP];
        [self.contentView addSubview:self.btnUnfriend];
        [self.contentView addSubview:self.btnUserBlocked];
		[self.contentView addSubview:self.btnReqDeny];
		[self.contentView addSubview:self.btnReqStatus];
        [self.contentView addSubview:self.imgSelected];
        [self.contentView addSubview:self.lblUserStatusInGrp];
        [self.contentView addSubview:self.lblDistance];
        [self.contentView addSubview:self.btnFriendCount];
        [self.contentView addSubview:self.lblMaidenName];
        [self.contentView addSubview:self.btnPlayPause];
   }
    return self;
}



- (id)initWithStyleForInterest:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
		self.backgroundColor = [UIColor clearColor];
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		
		float xStart = 5;
	//	float yStart = 5;
		
		self.cellBg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:LilstBox_Bg]];
		self.btnNotificationProfile = [UIButton buttonWithType:UIButtonTypeCustom];
		self.lblDisplayName = [[UILabel alloc] init] ;
		self.imgFriendshipStatus = [[UIImageView alloc] init] ;
		
		self.cellBg.frame = CGRectMake(3.5, 2, 313, 36);

		xStart += 10;
		
		self.lblDisplayName.frame = CGRectMake(xStart, 5, self.cellBg.frame.size.width-xStart-45, 66/2);
						
		self.imgFriendshipStatus.frame = CGRectMake(self.frame.size.width-40, 5, 29, 30);
		self.imgFriendshipStatus.hidden = TRUE;
		
		self.lblDisplayName.font = [UIFont fontWithName:Font_OpneSans_SemiBol size:24];
		
		self.lblDisplayName.backgroundColor = [UIColor clearColor];
		
		      
		[self.contentView addSubview:self.cellBg];
		[self.contentView addSubview:self.lblDisplayName];
		[self.contentView addSubview:self.imgFriendshipStatus];

    }
    return self;
}


- (void)awakeFromNib
{
    // Initialization code
    self.btnNotificationProfile = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btnDisplayName = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btnNotificationProfile.frame = self.ProfileImg.frame;
    self.btnDisplayName.frame = self.lblDisplayName.frame;
    
    self.btnReqDeny = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btnReqDeny.frame = CGRectMake(self.frame.size.width-90, 10, 29, 30);
    self.btnReqDeny.hidden = TRUE;
    
    self.btnReqStatus = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btnReqStatus.frame = CGRectMake(self.frame.size.width-40, 10, 29, 30);
    self.btnReqStatus.hidden = TRUE;
    
    [self.contentView addSubview:self.btnDisplayName];
    [self.contentView addSubview:self.self.btnReqDeny];
    [self.contentView addSubview:self.btnReqStatus];
    [self.contentView addSubview:self.btnNotificationProfile];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
	
    // Configure the view for the selected state
}

-(void)validateDisplayName:(NSDictionary *)dic{
	NSString *strDisplayName = [DataValidation checkNullString:[dic valueForKey:NAME]];
	if (strDisplayName.length==0) {
		strDisplayName = [NSString stringWithFormat:@"%@",[dic valueForKey:USER_NAME]];
	}

	self.lblDisplayName.text = strDisplayName;
}

-(void)setBoxValuesWithData:(NSDictionary *)dic{
    self.ProfileImg.imageURL = nil;
    self.ProfileImg.image = nil;
	selDic = dic;
	self.cellBg.hidden = NO;
	self.ProfileImg.hidden = NO;
	self.btnNotificationProfile.hidden = NO;
	self.lblDisplayName.hidden = NO;
	self.lblUserName.hidden = NO;
	self.imgFriendshipStatus.hidden = NO;
	self.btnReqStatus.hidden = NO;
	self.btnReqDeny.hidden = NO;
    self.btnUnfriend.hidden = NO;
	self.imgSelected.hidden = YES;
    self.btnRemoveFromGRP.hidden = YES;
    self.lblUserStatusInGrp.hidden = YES;
    self.lblDistance.hidden = YES;
    self.imgViewFriendType.hidden = YES;
    self.lblMaidenName.hidden = YES;
    self.imgViewIsNewFriend.hidden = YES;
    self.btnPlayPause.hidden = YES;
    
    
	float xStart = 5;
	float yStart = 5;
	self.cellBg.frame = CGRectMake(3.5, 4, 313, 87);
	
	xStart = 7;
	yStart = 10;
	
	self.ProfileImg.frame = CGRectMake(xStart, yStart, 66, 66);
	self.btnNotificationProfile.frame = self.ProfileImg.frame;
    
    self.imgViewFriendType.frame = CGRectMake(55, 55, 18, 18);
    self.imgViewIsNewFriend.frame = CGRectMake(5, 55, 17, 17);
	
	xStart += self.ProfileImg.frame.size.width;
	xStart += 10;
	
	float lbl1Height = (self.ProfileImg.frame.size.height/2);
	float lbl2Height = (self.ProfileImg.frame.size.height/2)/2;
	yStart += (self.ProfileImg.frame.size.height-lbl1Height-lbl2Height)/2;
	
	self.lblDisplayName.frame = CGRectMake(xStart, yStart, self.cellBg.frame.size.width-xStart-45, self.ProfileImg.frame.size.height/2);
	
	yStart += self.lblDisplayName.frame.size.height;
	self.lblUserName.frame = CGRectMake(xStart, yStart, self.cellBg.frame.size.width-xStart-45, (self.ProfileImg.frame.size.height/2)/1.5);
	if (self.isUserSelectionInView) {
        [self.btnNotificationProfile addTarget:self action:@selector(btnBlabCreatorName_Clicked:) forControlEvents:UIControlEventTouchUpInside];
        self.btnNotificationProfile.frame = self.ProfileImg.frame;
        self.btnNotificationProfile.backgroundColor = [UIColor clearColor];

        [self.btnDisplayName removeTarget:self action:@selector(btnBlabCreatorName_Clicked:) forControlEvents:UIControlEventTouchUpInside];
        [self.btnDisplayName removeFromSuperview];
        self.btnDisplayName = nil;
//        [self.btnDisplayName addTarget:self action:@selector(btnBlabCreatorName_Clicked:) forControlEvents:UIControlEventTouchUpInside];
//        self.btnDisplayName.frame = self.lblDisplayName.frame;
//        self.btnDisplayName.backgroundColor = [UIColor clearColor];
    }
    else{
        [self.btnNotificationProfile addTarget:self action:@selector(btnBlabCreatorImage_Clicked:) forControlEvents:UIControlEventTouchUpInside];
        self.btnNotificationProfile.frame = self.ProfileImg.frame;
        self.btnNotificationProfile.backgroundColor = [UIColor clearColor];
        
        [self.btnDisplayName addTarget:self action:@selector(btnBlabCreatorName_Clicked:) forControlEvents:UIControlEventTouchUpInside];
        self.btnDisplayName.frame = self.lblDisplayName.frame;
        self.btnDisplayName.backgroundColor = [UIColor clearColor];
    }
	
	self.imgFriendshipStatus.frame = CGRectMake(self.frame.size.width-40, 10, 29, 30);
	self.imgFriendshipStatus.hidden = TRUE;
	
    self.btnRemoveFromGRP.frame = self.imgFriendshipStatus.frame;
    self.btnRemoveFromGRP.hidden = TRUE;
    
    self.btnUserBlocked.frame  = CGRectMake(self.frame.size.width-40, CellHeight-40, 29, 30);
    self.btnUserBlocked.hidden = YES;
    [self.btnUserBlocked setImage:[UIImage imageNamed:Btn_User_Blocked] forState:UIControlStateNormal];
    
	self.btnUnfriend.frame = CGRectMake(self.frame.size.width-40, self.frame.size.height-40, 30, 31);
    self.btnUnfriend.hidden = FALSE;
    self.btnUnfriend.backgroundColor = [UIColor clearColor];
    [self.btnUnfriend setTitle:@"Unfriend" forState:UIControlStateNormal];

    self.imgSelected.frame = self.btnUserBlocked.frame;
    self.imgSelected.hidden = YES;
    
	self.lblDisplayName.font = [UIFont fontWithName:Font_OpneSans_SemiBol size:24];
	self.lblUserName.font = [UIFont fontWithName:Font_OpneSans_Light size:18];
    
	
	self.lblDisplayName.backgroundColor = [UIColor clearColor];
	self.lblUserName.backgroundColor = [UIColor clearColor];
	
	self.btnReqDeny.frame = CGRectMake(self.frame.size.width-90, 10, 29, 30);
	self.btnReqDeny.hidden = TRUE;
	
	self.btnReqStatus.frame = CGRectMake(self.frame.size.width-40, 10, 29, 30);
	self.btnReqStatus.hidden = TRUE;
	
	
	//[self.ProfileImg setImage:[UIImage imageNamed:@"index.jpg"]];
	self.ProfileImg.imageURL = [NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]];
	[self validateDisplayName:dic];
	self.lblUserName.text = [DataValidation checkNullString:[dic valueForKey:USER_NAME]];

	
	[Validation setCorners:self.ProfileImg];

	
	self.lblDisplayName.contentMode = UIViewContentModeBottom;
	self.lblUserName.contentMode = UIViewContentModeTop;
	if (self.lblDisplayName.text.length >0) {
		[self.lblDisplayName setTextColor:[Validation getColorForAlphabet:self.lblDisplayName.text]];
	}
	
	[self.lblUserName setTextColor:UIColorFromRGB(0X727478)];
    self.lblUserName.text = [HASHTAG_CHARACTER stringByAppendingFormat:@"%@",self.lblUserName.text];
    self.lblDisplayName.text = [HASHTAG_CHARACTER stringByAppendingFormat:@"%@",self.lblDisplayName.text];

    self.lblUserStatusInGrp.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    self.lblUserStatusInGrp.textColor = UIColorFromRGB(0Xff5252);
    self.lblUserStatusInGrp.frame = CGRectMake(self.cellBg.frame.origin.x+self.cellBg.frame.size.width-150, CellHeight-20, 140, 15);
    
    if ([[dic valueForKey:IS_USER_BLOCKED] boolValue]) {
        self.btnUserBlocked.hidden = NO;
    }
    else{
        self.btnUserBlocked.hidden = YES;
    }
    
    
    if ([self.btnUserBlocked isHidden]) {
        self.lblUserStatusInGrp.frame = CGRectMake(self.cellBg.frame.size.width-100, CellHeight-20, 90, 15);
    }
    else{
        self.lblUserStatusInGrp.frame = CGRectMake(self.cellBg.frame.size.width-135, CellHeight-20, 90, 15);
    }

   
//    self.lblUserName.backgroundColor = [UIColor grayColor];
//    self.lblDisplayName.backgroundColor = [UIColor yellowColor];
    
}

-(void)setValueForInterestBox:(NSDictionary *)dic{
    self.cellBg.hidden = NO;
	self.lblDisplayName.hidden = NO;
	self.imgFriendshipStatus.hidden = NO;
    self.btnUnfriend.hidden = YES;
    self.lblDistance.hidden = YES;
	
	float xStart = 5;
//	float yStart = 5;
	self.cellBg.frame = CGRectMake(3.5, 2, 313, 56);
	
	xStart = 15;
//	yStart = 2;
		
	self.lblDisplayName.frame = CGRectMake(xStart, 2, self.cellBg.frame.size.width-xStart-45, 56);
	
//	yStart += self.lblDisplayName.frame.size.height;

	self.imgFriendshipStatus.frame = CGRectMake(self.frame.size.width-40, 15, 29, 30);
	self.imgFriendshipStatus.hidden = FALSE;
	
	self.lblDisplayName.font = [UIFont fontWithName:Font_Montserrat_Regular size:24];
	
	self.lblDisplayName.backgroundColor = [UIColor clearColor];
    
	self.lblDisplayName.text = [DataValidation checkNullString:[dic valueForKey:NAME]];

	if (self.lblDisplayName.text.length >0) {
		[self.lblDisplayName setTextColor:[Validation getColorForAlphabet:self.lblDisplayName.text]];
	}
	
    [self.imgFriendshipStatus setImage:[UIImage imageNamed:btn_Checkbox_Deselected] ];
    self.lblDisplayName.text = [HASHTAG_CHARACTER stringByAppendingFormat:@"%@",self.lblDisplayName.text];
}
-(IBAction)btnBlabCreatorName_Clicked:(id)sender{
    [self.delegate btnBlabCreatorName_Clicked:selDic];
}
-(IBAction)btnBlabCreatorImage_Clicked:(id)sender{
    [self.delegate btnBlabCreatorImage_Clicked:selDic];
}
@end
