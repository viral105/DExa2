//
//  UserCell.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/8/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol UserCellDelegate <NSObject>

-(void)btnBlabCreatorName_Clicked:(NSDictionary *)dic;
-(void)btnBlabCreatorImage_Clicked:(NSDictionary *)dic;

@end

@interface UserCell : UITableViewCell{
    NSDictionary *selDic;
}

@property (nonatomic, strong) IBOutlet UIImageView		*cellBg;
@property (nonatomic, strong) IBOutlet UIImageView		*imgViewFriendType;
@property (nonatomic, strong) IBOutlet UIImageView		*imgViewIsNewFriend;
@property (nonatomic, strong) IBOutlet AsyncImageView	*ProfileImg;
@property (nonatomic, strong) IBOutlet UIButton			*btnNotificationProfile;
@property (nonatomic, strong) IBOutlet UILabel			*lblDisplayName;
@property (nonatomic, strong) IBOutlet UILabel			*lblUserName;
@property (nonatomic, strong) IBOutlet UIImageView		*imgFriendshipStatus;
//@property (nonatomic, strong) UIButton			*btnNotificationDetail;
@property (nonatomic, strong) IBOutlet UIButton			*btnReqStatus;      //accept, waiting, send request
@property (nonatomic, strong) IBOutlet UIButton			*btnReqDeny;
@property (nonatomic, strong) IBOutlet UIButton			*btnUserBlocked;
@property (nonatomic, strong) IBOutlet UIButton			*btnUnfriend;
@property (nonatomic, strong) IBOutlet UIButton			*btnRemoveFromGRP;
@property (nonatomic, strong) IBOutlet UIImageView      *imgSelected;
@property (nonatomic, strong) IBOutlet UILabel          *lblUserStatusInGrp;
@property (nonatomic, strong) IBOutlet UILabel          *lblMaidenName;
@property (nonatomic, strong) IBOutlet UILabel          *lblDistance;
@property (nonatomic, strong) UIButton          *btnDisplayName;
@property (nonatomic, assign) BOOL isShowUserDetailPopup;
@property (nonatomic, assign) BOOL isUserSelectionInView;
@property (nonatomic, strong) UIButton *btnFriendCount;
@property (nonatomic, strong) IBOutlet UIButton		*btnPlayPause;

@property (nonatomic, strong) id<UserCellDelegate> delegate;
- (id)initWithStyleForInterest:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier;
-(void)setBoxValuesWithData:(NSDictionary *)dic;
-(void)setValueForInterestBox:(NSDictionary *)dic;
@end



/*
 self.btnReqBlocked.frame  = CGRectMake(self.frame.size.width-40, self.frame.size.height-40, 29, 30);
 self.btnReqBlocked.hidden = YES;
 [self.btnReqBlocked setImage:[UIImage imageNamed:Btn_User_Blocked] forState:UIControlStateNormal];
*/