//
//  SetAlarmVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GeneralDelegate.h"
#import "AlarmFriendListVC.h"
#import "AlarmGrpListVC.h"


@interface SetAlarmVC : UIViewController<UITextFieldDelegate,GeneralDelegate,UITableViewDelegate,UITableViewDataSource>

@property (strong, nonatomic) IBOutlet UITableView *tblView;
@property (strong, nonatomic) IBOutlet UILabel *lblAlarmPeriod;
@property (strong, nonatomic) IBOutlet UILabel *lblTitle;
@property (strong, nonatomic) IBOutlet UIButton *btnDate;
@property (strong, nonatomic) IBOutlet UIButton *btnTime;
@property (strong, nonatomic) IBOutlet UILabel *lblAlarmName;
@property (strong, nonatomic) IBOutlet UITextField *tfAlarmName;
@property (strong, nonatomic) IBOutlet UILabel *lblAlarmSound;
@property (strong, nonatomic) IBOutlet UIButton *btnAlarmSound;
@property (strong, nonatomic) IBOutlet UIView *viewDtPicker;
@property (strong, nonatomic) IBOutlet UIDatePicker *dtPicker;
@property (strong, nonatomic) IBOutlet UIView *viewAlertPicker;
@property (strong, nonatomic) IBOutlet UIView *viewContainingPicker;

@property (strong, nonatomic) IBOutlet UIView   *viewAlarmReceiverType;
@property (strong, nonatomic) IBOutlet UILabel  *lblAlarmReceiverType;
@property (strong, nonatomic) IBOutlet UIButton *btnSetForMe;
@property (strong, nonatomic) IBOutlet UIButton *btnSendToFriend;
@property (strong, nonatomic) IBOutlet UIButton *btnSendToGroup;
@property (strong, nonatomic) IBOutlet UILabel *lblRecurringAndAlertOptionTitle;

@property (strong, nonatomic) IBOutlet UIButton *btnNext;

@property (strong, nonatomic) NSDictionary *dicSel;
@property (readwrite, nonatomic) int         selectedReceiverType;

- (IBAction)btnDTPickerCancel_Clicked:(id)sender;
- (IBAction)btnDTPickerDone_Clicked:(id)sender;
- (IBAction)btnDate_Clicked:(id)sender;
- (IBAction)btnTime_Clicked:(id)sender;
- (IBAction)btnBack_Clicked:(id)sender;
@end
