//
//  AlertPickerVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 2/10/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "AlarmAlertPickerVC.h"

@interface AlarmAlertPickerVC (){
    NSMutableArray *arrAlertTime;
    NSIndexPath *lastIndexPath;
}
@property (nonatomic, strong)NSMutableArray *arrAlertTime;
@property (nonatomic, strong)NSIndexPath *lastIndexPath;
@end

@implementation AlarmAlertPickerVC
@synthesize arrAlertTime,lastIndexPath;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.arrAlertTime = [[NSMutableArray alloc] initWithObjects:@"5 minutes before",@"10 minutes before",@"15 minutes before",@"30 minutes before",@"1 hour before",@"2 hour before",@"1 day",@"1 week", nil];
    self.lastIndexPath = [NSIndexPath indexPathForItem:0 inSection:0];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrAlertTime.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
    
    cell.textLabel.text = [self.arrAlertTime objectAtIndex:indexPath.row];
    if ([indexPath compare:self.lastIndexPath] == NSOrderedSame)
    {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    else
    {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.lastIndexPath = indexPath;
    
    [tableView reloadData];
}
@end
