//
//  RecordSoundFromAlarm.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
// Import EZAudio header
#import "ASIFormDataRequest.h"
#import "SetAlarmVC.h"
#import "GeneralDelegate.h"
@interface RecordSoundFromAlarmVC : UIViewController<AVAudioRecorderDelegate,AVAudioPlayerDelegate,UIAlertViewDelegate,GeneralDelegate>

@property (nonatomic, assign) BOOL isRecording;


@property (nonatomic, retain) IBOutlet UIButton     *btnRecord;
@property (nonatomic, retain) IBOutlet UIButton     *btnPreview;
@property (nonatomic, retain) IBOutlet UIButton     *btnNext;

@property (nonatomic, strong) AVAudioPlayer *audioPlayer;

@property (nonatomic, retain) IBOutlet UILabel      *lblTime;
@property (nonatomic, retain) IBOutlet UILabel      *lblSec;
@property (nonatomic, strong) NSTimer               *timerRecord;
@property (nonatomic, strong) IBOutlet UILabel		*lblTitle;
@property (nonatomic, readwrite) int				timeRemaining;
@property (nonatomic, readwrite) BOOL               isShouldStop;
@property (nonatomic, readwrite) BOOL               isPrivate;
@property (nonatomic, strong) NSString              *strFilePath;
@property (nonatomic, strong) NSArray				*arrSelectedIds;
@property (nonatomic, strong) ASIFormDataRequest		*request;
@property (nonatomic, readwrite) BOOL				isGroupNotif;
@property (nonatomic, readwrite) BOOL				isNotifSendToAll;

@property (nonatomic, strong) NSTimer               *timer;
@property (nonatomic, strong) UIProgressView			*progress;
@property (nonatomic, strong)    SetAlarmVC                 *childController;
@property (nonatomic, weak) id<GeneralDelegate> delegate;
@end
