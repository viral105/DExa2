//
//  AlarmRequestListCell.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 2/3/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "AlarmRequestListCell.h"
#define xPointAMPM5Char 105
#define xPointAMPM4Char 95

@implementation AlarmRequestListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
    self.viewBack.layer.cornerRadius = 5.0f;
    self.lblTime.textColor = UIColorFromRGB(0X00c2d9);
    self.lblAMPM.textColor = UIColorFromRGB(0X00c2d9);
    self.lblDate.textColor = UIColorFromRGB(0X616161);
    self.lblAlarmName.textColor = UIColorFromRGB(0X00c2d9);
    self.lblCreatedBy.textColor = UIColorFromRGB(0X616161);
    self.lblCreatedByUserName.textColor = UIColorFromRGB(0X00c2d9);
    self.lblRequestStatus.textColor = UIColorFromRGB(0X616161);
    self.lblStatus.textColor = UIColorFromRGB(0X00c2d9);
    [Validation setCorners:self.imgViewUser];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setUI:(int)selectedList{
    [self.imgViewUser setImage:nil];
    [self.imgViewUser setImageURL:nil];
    
    NSDateFormatter *dateFormatters = [[NSDateFormatter alloc] init];
    [dateFormatters setDateFormat:FORMAT_DATE_TIME];
    NSString *strDate = [Validation getCurrentTimeZoneDateFromUtcDate:[self.dicSel valueForKey:@"UtcDateTime"]];
    NSDate *combDate = [dateFormatters dateFromString:strDate];

//    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
//    [dateFormatters setDateFormat:FORMAT_DATE];
//    NSDate *yourDate = [dateFormatters dateFromString:strDate];
    [dateFormatters setDateFormat:@"EEEE"];
    NSString *dayName = [dateFormatters stringFromDate:combDate];
    
    [dateFormatters setDateFormat:@"dd/MM/yyyy"];
    NSString *strToDisplay = [dateFormatters stringFromDate:combDate];
    self.lblDate.text = [NSString stringWithFormat:@"%@ - %@",dayName,strToDisplay];
    /*
     NSCalendar* calender = [NSCalendar currentCalendar];
     NSDateComponents* component = [calender components:NSWeekdayCalendarUnit fromDate:yourDate];
     
     self.lblDay.text = [NSString stringWithFormat:@"%d",(int)[component weekday]];
     */
    self.lblAlarmName.text = [self.dicSel valueForKey:@"AlarmName"];
    
    [dateFormatters setDateFormat:@"hh:mm a"];
    NSString *strTimeDisplay = [dateFormatters stringFromDate:combDate];
    NSLog(@"self.dicSel --> %@",strTimeDisplay);
    NSArray *arr = [strTimeDisplay componentsSeparatedByString:@" "];
    self.lblTime.text = [arr objectAtIndex:0];
    if (self.lblTime.text.length==5) {
        self.lblAMPM.frame = CGRectMake(xPointAMPM5Char, self.lblTime.frame.origin.y, self.lblTime.frame.size.width, self.lblTime.frame.size.height);
    }
    else{
        self.lblAMPM.frame = CGRectMake(xPointAMPM4Char, self.lblTime.frame.origin.y, self.lblTime.frame.size.width, self.lblTime.frame.size.height);
    }
    self.lblAMPM.text = [arr objectAtIndex:1];
/*    if ([[self.dicSel valueForKey:@"IsFromRequest"] boolValue]) {
        self.btnEdit.hidden = YES;
    }
    else{
        self.btnEdit.hidden = NO;
    }
*/
    self.lblCreatedByUserName.text = [self.dicSel valueForKey:@"Name"];
    CGSize size = [self.lblCreatedByUserName.text sizeWithAttributes:@{NSFontAttributeName:[self.lblCreatedByUserName font]}];
    if (size.width>150) {
        self.lblCreatedByUserName.frame = CGRectMake(self.lblCreatedByUserName.frame.origin.x, self.lblCreatedByUserName.frame.origin.y, 150, self.lblCreatedByUserName.frame.size.height);
        self.imgViewUser.frame = CGRectMake(self.lblCreatedByUserName.frame.origin.x+self.lblCreatedByUserName.frame.size.width+5, self.imgViewUser.frame.origin.y, self.imgViewUser.frame.size.width, self.imgViewUser.frame.size.height);
    }
    else{
        self.lblCreatedByUserName.frame = CGRectMake(self.lblCreatedByUserName.frame.origin.x, self.lblCreatedByUserName.frame.origin.y, size.width, self.lblCreatedByUserName.frame.size.height);
        self.imgViewUser.frame = CGRectMake(self.lblCreatedByUserName.frame.origin.x+self.lblCreatedByUserName.frame.size.width+5, self.imgViewUser.frame.origin.y, self.imgViewUser.frame.size.width, self.imgViewUser.frame.size.height);
    }
    
    
    self.btnPlay.frame = CGRectMake(self.frame.size.width-165, self.lblTime.frame.origin.y, 30, 30);
    self.btnEdit.frame = CGRectMake(self.frame.size.width-132, self.lblTime.frame.origin.y, 55, self.btnEdit.frame.size.height);
    self.btnDelete.frame = CGRectMake(self.frame.size.width-72, self.lblTime.frame.origin.y, 50, self.btnDelete.frame.size.height);
    switch ([[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:USER_REMINDER_REQUEST_STATUS]] intValue]) {
        case 0:
            //pending
            self.lblStatus.text = @"Pending";
            [self.btnEdit setTitle:@"Accept" forState:UIControlStateNormal];
            [self.btnDelete setTitle:@"Reject" forState:UIControlStateNormal];
            [self.btnEdit.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:13]];
            [self.btnDelete.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:13]];
            [self.btnEdit setTitleColor:UIColorFromRGB(0X424242) forState:UIControlStateNormal];
            [self.btnDelete setTitleColor:UIColorFromRGB(0X424242) forState:UIControlStateNormal];
            [self.btnEdit setImage:nil forState:UIControlStateNormal];
            [self.btnDelete setImage:nil forState:UIControlStateNormal];
            self.btnEdit.backgroundColor = [UIColor clearColor];
            self.btnDelete.backgroundColor = [UIColor clearColor];
            self.btnPlay.backgroundColor = [UIColor clearColor];
            
            
            break;
        case 1:{
            //Accepted
            self.lblStatus.text = @"Accepted";
            if (selectedList == 1) {
                //recieved
                //hide accept/reject buttons
                self.btnEdit.hidden = TRUE;
                self.btnDelete.hidden = TRUE;
                self.btnPlay.frame = CGRectMake(self.frame.size.width-65, self.lblTime.frame.origin.y, 30, 30);
            }
        }
            break;
        case 2:
            //pending
            self.lblStatus.text = @"Rejected";
            if (selectedList == 1) {
                //recieved
                //hide accept/reject buttons
                self.btnEdit.hidden = TRUE;
                self.btnDelete.hidden = TRUE;
                self.btnPlay.frame = CGRectMake(self.frame.size.width-65, self.lblTime.frame.origin.y, 30, 30);
            }
            break;
            
            
        default:
            break;
    }
    self.imgViewUser.imageURL = [NSURL URLWithString:[self.dicSel valueForKey:@"PhotoPath"]];
}
- (IBAction)btnAcceptReject_Clicked:(id)sender {
    UIButton *btn = (UIButton *)sender;
    if (btn.tag==101) {
        [self.delegate btnAcceptRejectCalled:self.indPathSel flag:YES];
    }
    else{
        [self.delegate btnAcceptRejectCalled:self.indPathSel flag:NO];
    }
}
-(IBAction)btnPlay_Clicked:(id)sender{
    [self.delegate PlayAlarm:self.indPathSel];
}
@end
