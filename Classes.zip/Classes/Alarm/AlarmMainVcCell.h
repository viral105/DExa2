//
//  AlarmMainVcCell.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/30/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AlarmMainVcCellDelegate <NSObject>

-(void)editAlarm:(NSIndexPath *)indPath;
-(void)deleteAlarm:(NSIndexPath *)indPath;
-(void)PlayAlarm:(NSIndexPath *)indPath;

@end

@interface AlarmMainVcCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIView *viewBack;
@property (strong, nonatomic) IBOutlet UILabel *lblTime;
@property (strong, nonatomic) IBOutlet UILabel *lblAMPM;
@property (strong, nonatomic) IBOutlet UILabel *lblAlarmName;
@property (strong, nonatomic) IBOutlet UILabel *lblCreatedBy;
@property (strong, nonatomic) IBOutlet UILabel *lblCreatedByUserName;
@property (strong, nonatomic) IBOutlet AsyncImageView *imgViewUser;
@property (strong, nonatomic) IBOutlet UILabel *lblDate;
@property (strong, nonatomic) IBOutlet UIButton *btnEdit;
@property (strong, nonatomic) IBOutlet UIButton *btnPlay;
@property (strong, nonatomic) NSDictionary *dicSel;
@property (strong, nonatomic) NSIndexPath *indPathSel;
@property (strong, nonatomic) id<AlarmMainVcCellDelegate> delegate;
-(void)setUI;
@end
