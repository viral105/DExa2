//
//  ListAllMyCatSubcatVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SetAlarmVC.h"
#import "GeneralDelegate.h"

@interface ListAllMyCatSubcatVC : UIViewController<UITableViewDataSource, UITableViewDelegate,UICollectionViewDataSource, UICollectionViewDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, strong) NSMutableArray				*arrSubCat;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, strong) NSArray						*arrSelectedIds;
@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) ASIHTTPRequest				*request;
@property (nonatomic, readwrite) BOOL						isGroupNotif;
@property (nonatomic, readwrite) BOOL						isShowSubCategories;
@property (nonatomic, readwrite) BOOL						isNotifSentMsgVisible;
@property (nonatomic, readwrite) BOOL						isNotifSendToAll;
@property (nonatomic, readwrite) BOOL						isShowFooter;
@property (nonatomic, readwrite) int						selectedSection;
@property (nonatomic, strong)    SetAlarmVC                 *childController;
@property (nonatomic, weak) id<GeneralDelegate> delegate;

@property (nonatomic, strong) NSMutableDictionary *contentOffsetDictionary;

-(void)popToNotifListScreen;

@end
