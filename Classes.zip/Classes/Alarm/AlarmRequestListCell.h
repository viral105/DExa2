//
//  AlarmRequestListCell.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 2/3/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AlarmRequestListCellDelegate <NSObject>

-(void)btnAcceptRejectCalled:(NSIndexPath *)indPathSel flag:(BOOL)flag;
-(void)PlayAlarm:(NSIndexPath *)indPath;
@end
@interface AlarmRequestListCell : UITableViewCell{
    
}
@property (strong, nonatomic) IBOutlet UIView *viewBack;
@property (strong, nonatomic) IBOutlet UILabel *lblTime;
@property (strong, nonatomic) IBOutlet UILabel *lblAMPM;
@property (strong, nonatomic) IBOutlet UILabel *lblAlarmName;
@property (strong, nonatomic) IBOutlet UILabel *lblCreatedBy;
@property (strong, nonatomic) IBOutlet UILabel *lblCreatedByUserName;
@property (strong, nonatomic) IBOutlet AsyncImageView *imgViewUser;
@property (strong, nonatomic) IBOutlet UILabel *lblRequestStatus;
@property (strong, nonatomic) IBOutlet UILabel *lblStatus;

@property (strong, nonatomic) IBOutlet UILabel *lblDate;
@property (strong, nonatomic) IBOutlet UIButton *btnEdit;
@property (strong, nonatomic) IBOutlet UIButton *btnDelete;
@property (strong, nonatomic) IBOutlet UIButton *btnPlay;

@property (strong, nonatomic) NSDictionary *dicSel;
@property (strong, nonatomic) NSIndexPath *indPathSel;
@property (strong, nonatomic) id<AlarmRequestListCellDelegate> delegate;

-(void)setUI:(int)selectedList;
@end
