//
//  SelectBlabFromAlarmVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "SelectBlabFromAlarmVC.h"

@interface SelectBlabFromAlarmVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation SelectBlabFromAlarmVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"%@",appDelegate.dic_NotificationReleatedData);
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
    
    
    self.arrData = [[NSArray alloc] init];
    [self LoadViewSetting];
    [self get_BannerListWithUsers];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    appDelegate.currentVc = self;
    
    [self.tblData reloadData];
    
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];

}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    if ([self.timer isValid]) {
        [self.timer invalidate];
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    self.tblData.showsVerticalScrollIndicator = NO;
    self.tblData.showsHorizontalScrollIndicator = NO;
    self.tblData.transform = CGAffineTransformMakeRotation(-M_PI * 0.5);
    self.tblData.backgroundColor = [UIColor whiteColor];

    
    //temp
//    if ([UIScreen mainScreen].bounds.size.height == 480) {// Done by viral for ipad campatible screen as client wants it to give demo to others
//        [self.tblData setFrame:CGRectMake(0, 64+155+10+25,320, 100)];
//    }
//    else{
//        [self.tblData setFrame:CGRectMake(0, 64+155+10+25,320, 160)];
//    }
    
    if ([UIScreen mainScreen].bounds.size.height == 480) {// Done by viral for ipad campatible screen as client wants it to give demo to others
        [self.tblData setFrame:CGRectMake(0, 110,320, 100)];
    }
    else{
        [self.tblData setFrame:CGRectMake(0, 110,320, 160)];
    }

    self.tblData.pagingEnabled = YES;
    
}

-(void)get_BannerListWithUsers{
    
    
	NSString *strUrl = [WebServiceContainer getServiceURL:FEATURED_BANNER_LIST withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:nil isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:1];
    
	strUrl = nil;
    NSLog(@"call initiated");
}

- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
    
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    
    if (dicResponse != nil) {
        
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.2];
            Validation.viewPullToRefresh.alpha = 0;
            [UIView commitAnimations];
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            NSArray *arr = [NSArray arrayWithArray:(NSArray *)response];
                            self.arrData = arr;
                        }
                        response = nil;
                        [self.tblData reloadData];
                    }
                    else{
                        [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                        [HUD hide:YES];
                    }
                }
                else{
                    [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                    [HUD hide:YES];
                }
            }
            request = nil;
            
        }
    }
}

- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}

#pragma mark    UIButton methods

-(IBAction)btnOwnRecordClicked:(id)sender{
    [self performSegueWithIdentifier:RECORD_VC sender:nil];
}

-(IBAction)btnStoreClicked:(id)sender{
    [self performSegueWithIdentifier:LISTALL_MY_CAT_SUBCAT_VC sender:nil];
}

-(IBAction)btnBackClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return tableView.frame.size.width;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    // return self.arrData.count;
    if (![self.timer isValid] && self.arrData.count>0) {
        [self performSelector:@selector(startTimer) withObject:nil afterDelay:1];
    }
    return ((int)self.arrData.count)*100;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellIdentifier = @"cellIdentifier";
    
    RecordOptionBannerCell *cell = (RecordOptionBannerCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    NSUInteger actualRow = indexPath.row % ((int)self.arrData.count);
    NSLog(@"indexPath = %d",(int)actualRow);
    [cell clearsContextBeforeDrawing];
    [cell setBannerControlls:[self.arrData objectAtIndex:actualRow]];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self btnStoreClicked:nil];
}

-(void)startTimer{
    
    if ([self.timer isValid]) {
        [self.timer invalidate];
    }
    
    self.timer = [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(showCellAtIndex) userInfo:nil repeats:YES];
}

-(void)showCellAtIndex{
    if ([appDelegate.currentVc isKindOfClass:[self class]]) {
        NSArray *arr = [self.tblData indexPathsForVisibleRows];
        if (arr.count>1) {
            //        NSIndexPath
            NSIndexPath *path = [arr lastObject];
            //     NSLog(@"%@", path);
            [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:path.row+1 inSection:path.section] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        }
        else{
            NSIndexPath *path = [arr objectAtIndex:0];
            //        NSLog(@"%@", path);
            [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:path.row+1 inSection:path.section] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        }
    }
}
@end
