//
//  AlarmRequestListVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 2/3/15.
//  Copyright (c) 2015 s. All rights reserved.
//
/*  Used Tag num
 
 101 viewAlertPicker when viewing Set Alert Option
 102 viewAlertPicker when viewing Recurring Option
 
 */
#import "AlarmRequestListVC.h"
#define ReceivedAlarmList   @"RecievedAlarmRequest"
#define SentAlarmList       @"SentAlarmRequest"


@interface AlarmRequestListVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
    NSIndexPath *selIndPath;
    NSMutableArray *arrAlertTime;
    NSIndexPath *lastIndexPath;
    NSMutableDictionary *dicValidated;
    NSMutableArray *arrReminderRecurringOption;
    NSMutableArray *arrCommonRecurringAndAlertOption;
}
@property (nonatomic, strong)NSMutableArray *arrAlertTime;
@property (nonatomic, strong)NSIndexPath *lastIndexPath;
@property (nonatomic, strong)NSMutableArray *arrReminderRecurringOption;
@property (nonatomic, strong)NSMutableArray *arrCommonRecurringAndAlertOption;
@end

@implementation AlarmRequestListVC
@synthesize arrAlertTime;
@synthesize lastIndexPath;
@synthesize arrReminderRecurringOption;
@synthesize arrCommonRecurringAndAlertOption;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self performSelector:@selector(LoadViewSetting)];
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
    
    self.viewAlertPicker.tag = 101;
    self.arrAllRecievedAlarmRequest = [NSMutableArray new];
    self.arrAllSentAlarmRequest = [NSMutableArray new];
    self.arrCommonRecurringAndAlertOption = [NSMutableArray new];
    
    NSLog(@"%@",self.arrAllRecievedAlarmRequest);

    self.arrAlertTime = [[NSMutableArray alloc] initWithObjects:@"5 minutes before",@"10 minutes before",@"15 minutes before",@"30 minutes before",@"1 hour before",@"2 hour before",@"1 day before",@"1 week before", nil];
    self.arrReminderRecurringOption = [[NSMutableArray alloc] initWithObjects:@"Daily",@"Weekly",@"Monthly",@"Yearly", nil];
    [self.arrCommonRecurringAndAlertOption addObjectsFromArray:self.arrAlertTime];
    self.lastIndexPath = [NSIndexPath indexPathForItem:0 inSection:0];
    
    [self setSentRecBg];
    if ([Validation setOverlayFlags:6]) {
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
        [imgView setImage:[UIImage imageNamed:@"friends_reminders@2x.png"]];
        [imgView setUserInteractionEnabled:YES];
        
        UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(overlayImageTaped:)];
        [tapGes setNumberOfTapsRequired:1];
        [imgView addGestureRecognizer:tapGes];
        tapGes = nil;
        
        [[[UIApplication sharedApplication] keyWindow] addSubview:imgView];
    }
}
-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
    
	appDelegate.currentVc = self;
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
    
    [self performSelectorInBackground:@selector(getAllRequest) withObject:nil];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)setSentRecBg{
    [self.btnReceived setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.btnSent setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
    
    [self.btnReceived.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:17]];
    [self.btnSent.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:17]];
    
    [self.btnReceived setBackgroundImage:[UIImage imageNamed:btn_Blue_Selected] forState:UIControlStateNormal];
    [self.btnSent setBackgroundImage:[UIImage imageNamed:btn_White_DeSelected] forState:UIControlStateNormal];
    
    self.SelectedAlarmList = 1;
    
}

-(IBAction)btnRecSentClicked:(id)sender{
    UIButton *btn = (UIButton *)sender;
    
    if (btn.tag == 1) {
        self.SelectedAlarmList = 1;
        [self.btnReceived setBackgroundImage:[UIImage imageNamed:btn_Blue_Selected] forState:UIControlStateNormal];
        [self.btnSent setBackgroundImage:[UIImage imageNamed:btn_White_DeSelected] forState:UIControlStateNormal];
        [self.btnReceived setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.btnSent setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
        if (self.arrAllRecievedAlarmRequest.count == 0) {
            self.lblNoAlarmFound.hidden = FALSE;
        }
        else{
            self.lblNoAlarmFound.hidden = TRUE;
        }
    }
    else{
        self.SelectedAlarmList = 2;
        [self.btnReceived setBackgroundImage:[UIImage imageNamed:btn_White_DeSelected] forState:UIControlStateNormal];
        [self.btnSent setBackgroundImage:[UIImage imageNamed:btn_Blue_Selected] forState:UIControlStateNormal];
        [self.btnSent setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.btnReceived setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
        if (self.arrAllSentAlarmRequest.count == 0) {
            self.lblNoAlarmFound.hidden = FALSE;
        }
        else{
            self.lblNoAlarmFound.hidden = TRUE;
        }
    }
    [self.tblData reloadData];
}

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    [self.lblNoAlarmFound setTextColor:TWITTER_BLUE_COLOR];
    [self.lblNoAlarmFound setShadowColor:[UIColor clearColor]];
}
- (IBAction)btnBack_Clicked:(id)sender {
    [self.delegate isBackFromAlarmList];
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)getAllRequest{
    if (self.request !=nil) {
		self.request = nil;
	}
    [HUD show:YES];
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_ALL_ALARM_REQUEST withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:1];
    
	strUrl = nil;
}
- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
    NSLog(@"%@",self.arrAllRecievedAlarmRequest);
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
	//NSLog(@"dictionary = %@",dicResponse);
	
    //	[HUD hide:YES];
    //    [HUD hide:YES];
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [appDelegate callLogOutService];
        }
        else{
            
            if ([dicResponse objectForKey:RESPONSE] != nil) {
                
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    
                    if (tag == 1) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            if (self.arrAllRecievedAlarmRequest.count > 0) {
                                [self.arrAllRecievedAlarmRequest removeAllObjects];
                            }
                            if (self.arrAllSentAlarmRequest.count > 0) {
                                [self.arrAllSentAlarmRequest removeAllObjects];
                            }
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)[response valueForKey:ReceivedAlarmList]];
                            [self.arrAllRecievedAlarmRequest addObjectsFromArray:arr];
                            
                            arr = [NSMutableArray arrayWithArray:(NSArray *)[response valueForKey:SentAlarmList]];
                            [self.arrAllSentAlarmRequest addObjectsFromArray:arr];
                            arr = nil;
                            self.request = nil;
                            
                            if (self.SelectedAlarmList == 1) {
                                if (self.arrAllRecievedAlarmRequest.count == 0) {
                                    self.lblNoAlarmFound.hidden = FALSE;
                                }
                                else{
                                    self.lblNoAlarmFound.hidden = TRUE;
                                }
                            }
                            else{
                                if (self.arrAllSentAlarmRequest.count == 0) {
                                    self.lblNoAlarmFound.hidden = FALSE;
                                }
                                else{
                                    self.lblNoAlarmFound.hidden = TRUE;
                                }
                            }
                            
                            [self.tblData reloadData];
                            
                            
                        }
                        else{
                            [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                            [HUD hide:YES];
                        }
                    }
                    else if (tag == 2) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSDictionary *dic = (NSDictionary *)response;
                            
                            
                            
//                            [self.arrAllRecievedAlarmRequest removeObjectAtIndex:selIndPath.row];
                            /*
                             // Alarm Request Status Type
                             public enum StatusType
                             {
                             Pending = 0,
                             Accept = 1,
                             Denied = 2
                             }
                             */
                            NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrAllRecievedAlarmRequest objectAtIndex:selIndPath.row]];
                            
                            if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"IsAccept"]] boolValue]) {
                                [dic1 setValue:@"1" forKey:USER_REMINDER_REQUEST_STATUS];
                            }else{
                                [dic1 setValue:@"2" forKey:USER_REMINDER_REQUEST_STATUS];
                            }
                            
                            [self.arrAllRecievedAlarmRequest replaceObjectAtIndex:selIndPath.row withObject:dic1];
                            if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"IsAccept"]] boolValue]) {
                                [self scheduleLocalNotif:[self.arrAllRecievedAlarmRequest objectAtIndex:selIndPath.row]];
                            }
                            dic1 = nil;
                            dic = nil;
                            
                            if (self.SelectedAlarmList == 1) {
                                if (self.arrAllRecievedAlarmRequest.count == 0) {
                                    self.lblNoAlarmFound.hidden = FALSE;
                                }
                                else{
                                    self.lblNoAlarmFound.hidden = TRUE;
                                }
                            }
                            else{
                                if (self.arrAllSentAlarmRequest.count == 0) {
                                    self.lblNoAlarmFound.hidden = FALSE;
                                }
                                else{
                                    self.lblNoAlarmFound.hidden = TRUE;
                                }
                            }
                            
                            int cntPendingReq = 0;
                            for (int i=0; i<self.arrAllRecievedAlarmRequest.count; i++) {
                                NSDictionary *dic = [self.arrAllRecievedAlarmRequest objectAtIndex:i];
                                if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"StatusType"]] intValue]==0) {
                                    cntPendingReq++;
                                }
                            }
                            NSString *strFR = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_FRIENDS_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strNotif = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_UNREAD_NOTIF]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strKeepReq = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_KEEP_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strTotalCount = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_NOTIF_COUNT]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strARCount;
                            if (cntPendingReq==0) {
                                strARCount = [NSString stringWithFormat:@"0"];
                                Validation.dicNotifCount = [NSDictionary
                                                            dictionaryWithObjectsAndKeys:
                                                            strFR,TOTAL_FRIENDS_REQUEST,
                                                            strNotif,TOTAL_UNREAD_NOTIF,
                                                            strKeepReq,TOTAL_KEEP_REQUEST,
                                                            strTotalCount, TOTAL_NOTIF_COUNT,
                                                            strARCount,TOTAL_ALARM_REQUEST,
                                                            nil];
                            }
                            else{
                                strARCount = [NSString stringWithFormat:@"%d",cntPendingReq];
                                
                                Validation.dicNotifCount = [NSDictionary
                                                            dictionaryWithObjectsAndKeys:
                                                            strFR,TOTAL_FRIENDS_REQUEST,
                                                            strNotif,TOTAL_UNREAD_NOTIF,
                                                            strKeepReq,TOTAL_KEEP_REQUEST,
                                                            strTotalCount, TOTAL_NOTIF_COUNT,
                                                            strARCount,TOTAL_ALARM_REQUEST,
                                                            nil];
                                
                            }
                            
                            [self.tblData reloadData];
                            self.request = nil;
                        }
                        else{
                            [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                            [HUD hide:YES];
                        }
                    }
                }
                else{
                    [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                    [HUD hide:YES];
                }
            }
            else{
                [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                [HUD hide:YES];
            }
        }
    }
    [HUD hide:YES];
    dicResponse = nil;
}


- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView==self.tblData) {
        if (self.SelectedAlarmList == 1) {
            //received
            return self.arrAllRecievedAlarmRequest.count;
        }
        else{
            //sent alarm
            return self.arrAllSentAlarmRequest.count;
        }
        
    }
    else{
        return self.arrCommonRecurringAndAlertOption.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView==self.tblData) {
        AlarmRequestListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
        cell.indPathSel = indexPath;
        cell.dicSel = (self.SelectedAlarmList == 1)?[self.arrAllRecievedAlarmRequest objectAtIndex:indexPath.row]:[self.arrAllSentAlarmRequest objectAtIndex:indexPath.row];
        
        
        
        if (self.SelectedAlarmList == 2) {
            
            //sent, so no accept/reject button
            cell.lblCreatedBy.text = @"Sent To -";
            [cell setUI:self.SelectedAlarmList];
            cell.btnEdit.hidden = TRUE;
            cell.btnDelete.hidden = TRUE;
            cell.btnPlay.frame = cell.btnDelete.frame;
        }
        else{
            cell.btnEdit.hidden = FALSE;
            cell.btnDelete.hidden = FALSE;
            cell.btnPlay.frame = CGRectMake(cell.btnEdit.frame.origin.x-cell.btnPlay.frame.size.width-5, cell.btnPlay.frame.origin.y, cell.btnPlay.frame.size.width, cell.btnPlay.frame.size.height);
            
            [cell setUI:self.SelectedAlarmList];
            cell.lblCreatedBy.text = @"Created by -";
            
        }
        return cell;
    }
    else{
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellidalarmreq"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.text = [self.arrCommonRecurringAndAlertOption objectAtIndex:indexPath.row];
        if ([indexPath compare:self.lastIndexPath] == NSOrderedSame)
        {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
        else
        {
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
        return cell;
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView==self.tblView) {
        self.lastIndexPath = indexPath;
        
        [tableView reloadData];
    }
    
}
-(void)overlayImageTaped:(UIGestureRecognizer *)gesRecognizer{
    [gesRecognizer.view removeFromSuperview];
}
-(void)btnAcceptRejectCalled:(NSIndexPath *)indPathSel flag:(BOOL)flag{
    if (self.request !=nil) {
		self.request = nil;
	}
    selIndPath = indPathSel;
    [HUD show:YES];
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[self.arrAllRecievedAlarmRequest objectAtIndex:indPathSel.row] valueForKey:@"ID"]],KeyValue,@"RequestAlarmID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:flag ? @"true":@"false"],KeyValue,@"IsAccept",KeyName, nil],@"2",
                         nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:ACCEPTDENY_ALARM_REQUEST withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:2];
    
	strUrl = nil;
}
-(void)PlayAlarm:(NSIndexPath *)indPath{
    NSMutableDictionary *dic = (self.SelectedAlarmList == 1)?[self createAlarmDictionary:[self.arrAllRecievedAlarmRequest objectAtIndex:indPath.row]]:[self createAlarmDictionary:[self.arrAllSentAlarmRequest objectAtIndex:indPath.row]];
    [appDelegate playLocalAlarm:dic];
}
-(void)scheduleLocalNotif:(NSDictionary*)dicSel{
    
    dicValidated = [NSMutableDictionary dictionaryWithDictionary:dicSel];
    
    NSDateFormatter *dateFormatters = [[NSDateFormatter alloc] init];
    [dateFormatters setDateFormat:FORMAT_DATE_TIME];
    NSString *strDate = [Validation getCurrentTimeZoneDateFromUtcDate:[dicValidated valueForKey:@"UtcDateTime"]];
    NSDate *combDate = [dateFormatters dateFromString:strDate];
    
    NSLog(@"schedule time--> %@",[[strDate componentsSeparatedByString:@" "] objectAtIndex:1]);
    NSDate *currDate = [NSDate date];
    
    if ([currDate compare:combDate]==NSOrderedDescending) {
        [AlertHandler alertTitle:ALERT message:@"Requested alarm time has been passed." delegate:self tag:-1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        return;
    }
    
    if (dicValidated!=nil) {
        self.viewAlertPicker.hidden = NO;
        
    }
/*
    NSDateFormatter *dateFormatters = [[NSDateFormatter alloc] init];
    [dateFormatters setDateFormat:FORMAT_DATE_TIME];
    NSString *strDate = [Validation getCurrentTimeZoneDateFromUtcDate:[dicSel valueForKey:@"UtcDateTime"]];
    NSDate *combDate = [dateFormatters dateFromString:strDate];
    
    NSLog(@"schedule time--> %@",[[strDate componentsSeparatedByString:@" "] objectAtIndex:1]);
    NSDate *currDate = [NSDate date];
    
    if ([currDate compare:combDate]==NSOrderedDescending) {
        [AlertHandler alertTitle:ALERT message:@"Requested alarm time has been passed." delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        return;
    }

    NSMutableDictionary *dic = [NSMutableDictionary new];

    if ([DataValidation checkNullString:[dicSel valueForKey:@"SubCatName"]].length==0) {
        if ([DataValidation checkNullString:[dicSel valueForKey:@"CatName"]].length==0) {
            [dic setObject:@"" forKey:NOTIF_Category];
        }
        else{
            [dic setObject:[dicSel valueForKey:@"CatName"] forKey:NOTIF_Category];
        }
    }
    else{
        [dic setObject:[dicSel valueForKey:@"SubCatName"] forKey:NOTIF_Category];
    }
    [dic setObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@ --> %@",TXT_ALARM,[dicSel valueForKey:@"AlarmName"]],@"alert", nil] forKey:@"aps"];
    [dic setObject:@"1" forKey:@"TypeID"];
    [dic setObject:[[strDate componentsSeparatedByString:@" "] objectAtIndex:0] forKey:@"Alarmdate"];
    [dic setObject:[NSString stringWithFormat:@"%@ %@",[[strDate componentsSeparatedByString:@" "] objectAtIndex:1],[[strDate componentsSeparatedByString:@" "] objectAtIndex:2]] forKey:@"Alarmtime"];
    [dic setObject:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH] forKey:@"PhotoPath"];
    [dic setObject:TXT_ALARM forKey:@"Name"];
    [dic setObject:[dicSel valueForKey:@"AlarmName"] forKey:@"Alarmname"];
    [dic setObject:[dicSel valueForKey:@"FilePath"] forKey:@"SoundPath"];
    [dic setObject:[dicSel valueForKey:@"RandomSoundID"] forKey:@"RandomSoundID"];
    [dic setObject:@"YES" forKey:@"IsFromRequest"];
    [dic setObject:[dicSel valueForKey:@"Name"] forKey:@"Createdby"];
    [dic setObject:[dicSel valueForKey:@"PhotoPath"] forKey:@"Createdbyphotopath"];
    
    NSString *strId = [appDelegate InfoSaveAlarm:dic];
    [dic setObject:strId forKey:@"Aid"];
    
    UILocalNotification* n1 = [[UILocalNotification alloc] init];
    n1.fireDate = combDate;
    n1.alertBody = [NSString stringWithFormat:@"%@ --> %@",TXT_ALARM,[dicSel valueForKey:@"AlarmName"]];
    n1.userInfo = dic;
    n1.soundName = @"audio_local_notif.mp3";
    [[UIApplication sharedApplication] scheduleLocalNotification:n1];
*/
}
-(IBAction)btnNone_Clicked:(id)sender{
    if (self.viewAlertPicker.tag==101) {
        self.viewAlertPicker.tag=102;
        [dicValidated setObject:@"" forKey:@"Alertdatetime"];
        [dicValidated setObject:@"" forKey:@"SelectedAlertOptionIndexpath"];
        self.lblRecurringAndAlertOptionTitle.text = @"Repeat";
        self.lastIndexPath = [NSIndexPath indexPathForItem:0 inSection:0];
        
        [self.arrCommonRecurringAndAlertOption removeAllObjects];
        [self.arrCommonRecurringAndAlertOption addObjectsFromArray:self.arrReminderRecurringOption];
        [self.tblView reloadData];
        return;
    }
    NSDateFormatter *dateFormatters = [[NSDateFormatter alloc] init];
    [dateFormatters setDateFormat:FORMAT_DATE_TIME];
    NSString *strDate = [Validation getCurrentTimeZoneDateFromUtcDate:[dicValidated valueForKey:@"UtcDateTime"]];
    NSDate *combDate = [dateFormatters dateFromString:strDate];
    
    NSLog(@"schedule time--> %@",[[strDate componentsSeparatedByString:@" "] objectAtIndex:1]);
    NSDate *currDate = [NSDate date];
    
    if ([currDate compare:combDate]==NSOrderedDescending) {
        [AlertHandler alertTitle:ALERT message:@"Requested alarm time has been passed." delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        return;
    }
    
    NSMutableDictionary *dic = [NSMutableDictionary new];
    
    if ([DataValidation checkNullString:[dicValidated valueForKey:@"SubCatName"]].length==0) {
        if ([DataValidation checkNullString:[dicValidated valueForKey:@"CatName"]].length==0) {
            [dic setObject:@"" forKey:NOTIF_Category];
        }
        else{
            [dic setObject:[dicValidated valueForKey:@"CatName"] forKey:NOTIF_Category];
        }
    }
    else{
        [dic setObject:[dicValidated valueForKey:@"SubCatName"] forKey:NOTIF_Category];
    }
    [dic setObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@ --> %@",TXT_ALARM,[dicValidated valueForKey:@"AlarmName"]],@"alert", nil] forKey:@"aps"];
    [dic setObject:@"1" forKey:@"TypeID"];
    [dic setObject:[[strDate componentsSeparatedByString:@" "] objectAtIndex:0] forKey:@"Alarmdate"];
    [dic setObject:[NSString stringWithFormat:@"%@ %@",[[strDate componentsSeparatedByString:@" "] objectAtIndex:1],[[strDate componentsSeparatedByString:@" "] objectAtIndex:2]] forKey:@"Alarmtime"];
//    [dic setObject:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH] forKey:@"PhotoPath"];
    [dic setObject:[dicValidated valueForKey:@"PhotoPath"] forKey:@"PhotoPath"];
    [dic setObject:TXT_ALARM forKey:@"Name"];
    [dic setObject:[dicValidated valueForKey:@"AlarmName"] forKey:@"Alarmname"];
    [dic setObject:[dicValidated valueForKey:@"FilePath"] forKey:@"SoundPath"];
    [dic setObject:[dicValidated valueForKey:@"RandomSoundID"] forKey:@"RandomSoundID"];
    [dic setObject:@"404" forKey:@"StatusType"];
    [dic setObject:@"YES" forKey:@"IsFromRequest"];
    [dic setObject:[dicValidated valueForKey:@"Name"] forKey:@"Createdby"];
    [dic setObject:[dicValidated valueForKey:@"PhotoPath"] forKey:@"Createdbyphotopath"];
    
    NSString *strId = [appDelegate InfoSaveAlarm:dic];
    [dic setObject:strId forKey:@"Aid"];
    
    UILocalNotification* n1 = [[UILocalNotification alloc] init];
    n1.fireDate = combDate;
    n1.alertBody = [NSString stringWithFormat:@"Reminder --> %@",[dicValidated valueForKey:@"AlarmName"]];
    n1.userInfo = dic;
    n1.soundName = @"audio_local_notif.mp3";
    [[UIApplication sharedApplication] scheduleLocalNotification:n1];
    
    self.viewAlertPicker.tag = 101;
    self.lblRecurringAndAlertOptionTitle.text = @"Set Alert";
    [self.arrCommonRecurringAndAlertOption removeAllObjects];
    [self.arrCommonRecurringAndAlertOption addObjectsFromArray:self.arrAlertTime];
    [self.tblView reloadData];
    self.viewAlertPicker.hidden = YES;
}
-(IBAction)btnSet_Clicked:(id)sender{
    if (self.viewAlertPicker.tag==102) {
        NSDateFormatter *dateFormatters = [[NSDateFormatter alloc] init];
        [dateFormatters setDateFormat:FORMAT_DATE_TIME];
        NSString *strDate = [Validation getCurrentTimeZoneDateFromUtcDate:[dicValidated valueForKey:@"UtcDateTime"]];
        NSDate *combDate = [dateFormatters dateFromString:strDate];
        
        NSLog(@"schedule time--> %@",[[strDate componentsSeparatedByString:@" "] objectAtIndex:1]);
        NSDate *currDate = [NSDate date];
        
        if ([currDate compare:combDate]==NSOrderedDescending) {
            [AlertHandler alertTitle:ALERT message:@"Requested alarm time has been passed." delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
            return;
        }
        
        NSMutableDictionary *dic = [NSMutableDictionary new];
        
        if ([DataValidation checkNullString:[dicValidated valueForKey:@"SubCatName"]].length==0) {
            if ([DataValidation checkNullString:[dicValidated valueForKey:@"CatName"]].length==0) {
                [dic setObject:@"" forKey:NOTIF_Category];
            }
            else{
                [dic setObject:[dicValidated valueForKey:@"CatName"] forKey:NOTIF_Category];
            }
        }
        else{
            [dic setObject:[dicValidated valueForKey:@"SubCatName"] forKey:NOTIF_Category];
        }
        [dic setObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@ --> %@",TXT_ALARM,[dicValidated valueForKey:@"AlarmName"]],@"alert", nil] forKey:@"aps"];
        [dic setObject:@"1" forKey:@"TypeID"];
        [dic setObject:[[strDate componentsSeparatedByString:@" "] objectAtIndex:0] forKey:@"Alarmdate"];
        [dic setObject:[NSString stringWithFormat:@"%@ %@",[[strDate componentsSeparatedByString:@" "] objectAtIndex:1],[[strDate componentsSeparatedByString:@" "] objectAtIndex:2]] forKey:@"Alarmtime"];
//        [dic setObject:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH] forKey:@"PhotoPath"];
        [dic setObject:[dicValidated valueForKey:@"PhotoPath"] forKey:@"PhotoPath"];
        [dic setObject:TXT_ALARM forKey:@"Name"];
        [dic setObject:[dicValidated valueForKey:@"AlarmName"] forKey:@"Alarmname"];
        [dic setObject:[dicValidated valueForKey:@"FilePath"] forKey:@"SoundPath"];
        [dic setObject:[dicValidated valueForKey:@"RandomSoundID"] forKey:@"RandomSoundID"];
        [dic setObject:@"404" forKey:@"StatusType"];
        [dic setObject:@"YES" forKey:@"IsFromRequest"];
        [dic setObject:[dicValidated valueForKey:@"Name"] forKey:@"Createdby"];
        [dic setObject:[dicValidated valueForKey:@"PhotoPath"] forKey:@"Createdbyphotopath"];
        
        NSString *strId = [appDelegate InfoSaveAlarm:dic];
        [dic setObject:strId forKey:@"Aid"];
        
        //      SET REMINDER WITH REPEAT INTERVAL
        UILocalNotification* n1 = [[UILocalNotification alloc] init];
        [self setRepetInterval:n1];
        n1.fireDate = combDate;
        n1.alertBody = [NSString stringWithFormat:@"Reminder --> %@",[dicValidated valueForKey:@"AlarmName"]];
        n1.userInfo = dic;
        n1.soundName = @"audio_local_notif.mp3";
        [[UIApplication sharedApplication] scheduleLocalNotification:n1];
        
        
        NSString *temp = [DataValidation checkNullString:[dicValidated valueForKey:@"SelectedAlertOptionIndexpath"]];
        NSDate *alertDate;
        
        //      IF ALERT OPTION SELECTED FROM SET ALERT LIST SO IT MUST NOT BE BLANK
        if (temp.length!=0) {
            
            NSIndexPath *indPath = [NSIndexPath indexPathForRow:[temp intValue] inSection:0];
            alertDate = [self getAlertDate:combDate indxPath:indPath];
            
            //      IF ALERT TIME IS FUTURE TIME THEN SET ALERT WITH REPEAT INTERVAL.
            if ([alertDate compare:[NSDate date]]==NSOrderedDescending){
                
                [dic setObject:@"2" forKey:@"TypeID"];
                UILocalNotification* n2 = [[UILocalNotification alloc] init];
                [self setRepetInterval:n2];
                n2.fireDate = alertDate;
                n2.alertBody = [NSString stringWithFormat:@"Reminder --> %@",[dicValidated valueForKey:@"AlarmName"]];
                n2.userInfo = dic;
                n2.soundName = @"audio_local_notif.mp3";
                [[UIApplication sharedApplication] scheduleLocalNotification:n2];
            }
        }
        
        self.viewAlertPicker.tag = 101;
        self.lblRecurringAndAlertOptionTitle.text = @"Set Alert";
        [self.arrCommonRecurringAndAlertOption removeAllObjects];
        [self.arrCommonRecurringAndAlertOption addObjectsFromArray:self.arrAlertTime];
        [self.tblView reloadData];
        self.viewAlertPicker.hidden = YES;
        return;
    }
    NSDateFormatter *dateFormatters = [[NSDateFormatter alloc] init];
    [dateFormatters setDateFormat:FORMAT_DATE_TIME];
    NSString *strDate = [Validation getCurrentTimeZoneDateFromUtcDate:[dicValidated valueForKey:@"UtcDateTime"]];
    NSDate *combDate = [dateFormatters dateFromString:strDate];
    
    NSDate *alertDate = [self getAlertDate:combDate indxPath:self.lastIndexPath];
    if ([alertDate compare:[NSDate date]]==NSOrderedAscending) {
        [AlertHandler alertTitle:ALERT message:@"Reminder time is less then alert time difference." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        return;
    }
    else if (self.viewAlertPicker.tag == 101){
        NSDateFormatter *dateFormatters = [[NSDateFormatter alloc] init];
        [dateFormatters setDateFormat:FORMAT_DATE_TIME];
        NSString *strDate = [Validation getCurrentTimeZoneDateFromUtcDate:[dicValidated valueForKey:@"UtcDateTime"]];
        NSDate *combDate = [dateFormatters dateFromString:strDate];
        
        NSLog(@"schedule time--> %@",[[strDate componentsSeparatedByString:@" "] objectAtIndex:1]);
        NSDate *currDate = [NSDate date];
        
        if ([currDate compare:combDate]==NSOrderedDescending) {
            [AlertHandler alertTitle:ALERT message:@"Requested alarm time has been passed." delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
            return;
        }
        
        NSDate *alertDate = [self getAlertDate:combDate indxPath:lastIndexPath];
        
        self.viewAlertPicker.tag = 102;
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:FORMAT_DATE_TIME];
        [dicValidated setObject:[formatter stringFromDate:alertDate] forKey:@"Alertdatetime"];
        [dicValidated setObject:[NSString stringWithFormat:@"%d",(int)self.lastIndexPath.row] forKey:@"SelectedAlertOptionIndexpath"];
        self.lblRecurringAndAlertOptionTitle.text = @"Repeat";
        self.lastIndexPath = [NSIndexPath indexPathForItem:0 inSection:0];
        
        [self.arrCommonRecurringAndAlertOption removeAllObjects];
        [self.arrCommonRecurringAndAlertOption addObjectsFromArray:self.arrReminderRecurringOption];
        [self.tblView reloadData];
        formatter = nil;
        return;
    }
    else{
/*
        NSDateFormatter *dateFormatters = [[NSDateFormatter alloc] init];
        [dateFormatters setDateFormat:FORMAT_DATE_TIME];
        NSString *strDate = [Validation getCurrentTimeZoneDateFromUtcDate:[dicValidated valueForKey:@"UtcDateTime"]];
        NSDate *combDate = [dateFormatters dateFromString:strDate];
        
        NSLog(@"schedule time--> %@",[[strDate componentsSeparatedByString:@" "] objectAtIndex:1]);
        NSDate *currDate = [NSDate date];
        
        if ([currDate compare:combDate]==NSOrderedDescending) {
            [AlertHandler alertTitle:ALERT message:@"Requested alarm time has been passed." delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
            return;
        }
        
        NSMutableDictionary *dic = [NSMutableDictionary new];
        
        if ([DataValidation checkNullString:[dicValidated valueForKey:@"SubCatName"]].length==0) {
            if ([DataValidation checkNullString:[dicValidated valueForKey:@"CatName"]].length==0) {
                [dic setObject:@"" forKey:NOTIF_Category];
            }
            else{
                [dic setObject:[dicValidated valueForKey:@"CatName"] forKey:NOTIF_Category];
            }
        }
        else{
            [dic setObject:[dicValidated valueForKey:@"SubCatName"] forKey:NOTIF_Category];
        }
        [dic setObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@ --> %@",TXT_ALARM,[dicValidated valueForKey:@"AlarmName"]],@"alert", nil] forKey:@"aps"];
        [dic setObject:@"1" forKey:@"TypeID"];
        [dic setObject:[[strDate componentsSeparatedByString:@" "] objectAtIndex:0] forKey:@"Alarmdate"];
        [dic setObject:[NSString stringWithFormat:@"%@ %@",[[strDate componentsSeparatedByString:@" "] objectAtIndex:1],[[strDate componentsSeparatedByString:@" "] objectAtIndex:2]] forKey:@"Alarmtime"];
        [dic setObject:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH] forKey:@"PhotoPath"];
        [dic setObject:TXT_ALARM forKey:@"Name"];
        [dic setObject:[dicValidated valueForKey:@"AlarmName"] forKey:@"Alarmname"];
        [dic setObject:[dicValidated valueForKey:@"FilePath"] forKey:@"SoundPath"];
        [dic setObject:[dicValidated valueForKey:@"RandomSoundID"] forKey:@"RandomSoundID"];
        [dic setObject:@"YES" forKey:@"IsFromRequest"];
        [dic setObject:[dicValidated valueForKey:@"Name"] forKey:@"Createdby"];
        [dic setObject:[dicValidated valueForKey:@"PhotoPath"] forKey:@"Createdbyphotopath"];
        
        NSString *strId = [appDelegate InfoSaveAlarm:dic];
        [dic setObject:strId forKey:@"Aid"];
        
        UILocalNotification* n1 = [[UILocalNotification alloc] init];
        n1.fireDate = combDate;
        n1.alertBody = [NSString stringWithFormat:@"%@ --> %@",TXT_ALARM,[dicValidated valueForKey:@"AlarmName"]];
        n1.userInfo = dic;
        n1.soundName = @"audio_local_notif.mp3";
        [[UIApplication sharedApplication] scheduleLocalNotification:n1];
        
        NSDate *alertDate;
        switch (lastIndexPath.row) {
            case 0:
                alertDate = [combDate dateByAddingTimeInterval:-(5*60)];
                break;
            case 1:
                alertDate = [combDate dateByAddingTimeInterval:-(10*60)];
                break;
            case 2:
                alertDate = [combDate dateByAddingTimeInterval:-(15*60)];
                break;
            case 3:
                alertDate = [combDate dateByAddingTimeInterval:-(30*60)];
                break;
            case 4:
                alertDate = [combDate dateByAddingTimeInterval:-(60*60)];
                break;
            case 5:
                alertDate = [combDate dateByAddingTimeInterval:-(120*60)];
                break;
            case 6:
                alertDate = [combDate dateByAddingTimeInterval:-(1440*60)];
                break;
            case 7:
                alertDate = [combDate dateByAddingTimeInterval:-(10080*60)];
                break;
            default:
                break;
        }
        [dic setObject:@"2" forKey:@"TypeID"];
        UILocalNotification* n2 = [[UILocalNotification alloc] init];
        n2.fireDate = alertDate;
        n2.alertBody = [NSString stringWithFormat:@"%@ Reminder --> %@",TXT_ALARM,[dicValidated valueForKey:@"AlarmName"]];
        n2.userInfo = dic;
        n2.soundName = @"audio_local_notif.mp3";
        [[UIApplication sharedApplication] scheduleLocalNotification:n2];
        
//        [self.navigationController popViewControllerAnimated:YES];
*/
    }
    self.viewAlertPicker.hidden = YES;
}
-(NSDate *)getAlertDate:(NSDate *)combDate indxPath:(NSIndexPath *)indPath{
    NSDate *alertDate;
    switch (indPath.row) {
        case 0:
            alertDate = [combDate dateByAddingTimeInterval:-(5*60)];
            break;
        case 1:
            alertDate = [combDate dateByAddingTimeInterval:-(10*60)];
            break;
        case 2:
            alertDate = [combDate dateByAddingTimeInterval:-(15*60)];
            break;
        case 3:
            alertDate = [combDate dateByAddingTimeInterval:-(30*60)];
            break;
        case 4:
            alertDate = [combDate dateByAddingTimeInterval:-(60*60)];
            break;
        case 5:
            alertDate = [combDate dateByAddingTimeInterval:-(120*60)];
            break;
        case 6:
            alertDate = [combDate dateByAddingTimeInterval:-(1440*60)];
            break;
        case 7:
            alertDate = [combDate dateByAddingTimeInterval:-(10080*60)];
            break;
        default:
            break;
    }
    return alertDate;
}
-(void)setRepetInterval:(UILocalNotification *)localNotif{
    switch (self.lastIndexPath.row) {
        case 0:
            localNotif.repeatInterval = NSDayCalendarUnit;
            break;
        case 1:
            localNotif.repeatInterval = NSWeekCalendarUnit;
            break;
        case 2:
            localNotif.repeatInterval = NSMonthCalendarUnit;
            break;
        case 3:
            localNotif.repeatInterval = NSYearCalendarUnit;
            break;
        default:
            break;
    }
    [dicValidated setObject:[NSString stringWithFormat:@"%d",(int)self.lastIndexPath.row] forKey:@"SelectedRepeatOptionIndexpath"];
}
-(NSMutableDictionary *)createAlarmDictionary:(NSDictionary *)dicToSchedule{

    NSDateFormatter *dateFormatters = [[NSDateFormatter alloc] init];
    [dateFormatters setDateFormat:FORMAT_DATE_TIME];
    NSString *strDate = [Validation getCurrentTimeZoneDateFromUtcDate:[dicToSchedule valueForKey:@"UtcDateTime"]];

    NSMutableDictionary *dic = [NSMutableDictionary new];
    
    if ([DataValidation checkNullString:[dicToSchedule valueForKey:@"SubCatName"]].length==0) {
        if ([DataValidation checkNullString:[dicToSchedule valueForKey:@"CatName"]].length==0) {
            [dic setObject:@"" forKey:NOTIF_Category];
        }
        else{
            [dic setObject:[dicToSchedule valueForKey:@"CatName"] forKey:NOTIF_Category];
        }
    }
    else{
        [dic setObject:[dicToSchedule valueForKey:@"SubCatName"] forKey:NOTIF_Category];
    }
    [dic setObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@ --> %@",TXT_ALARM,[dicToSchedule valueForKey:@"AlarmName"]],@"alert", nil] forKey:@"aps"];
    [dic setObject:@"1" forKey:@"TypeID"];
    [dic setObject:[[strDate componentsSeparatedByString:@" "] objectAtIndex:0] forKey:@"Alarmdate"];
    [dic setObject:[NSString stringWithFormat:@"%@ %@",[[strDate componentsSeparatedByString:@" "] objectAtIndex:1],[[strDate componentsSeparatedByString:@" "] objectAtIndex:2]] forKey:@"Alarmtime"];
//    [dic setObject:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH] forKey:@"PhotoPath"];
    [dic setObject:[dicToSchedule valueForKey:@"PhotoPath"] forKey:@"PhotoPath"];
    [dic setObject:TXT_ALARM forKey:@"Name"];
    [dic setObject:[dicToSchedule valueForKey:@"AlarmName"] forKey:@"Alarmname"];
    [dic setObject:[dicToSchedule valueForKey:@"FilePath"] forKey:@"SoundPath"];
    [dic setObject:[dicToSchedule valueForKey:@"RandomSoundID"] forKey:@"RandomSoundID"];
    [dic setObject:@"YES" forKey:@"IsFromRequest"];
    [dic setObject:[dicToSchedule valueForKey:@"Name"] forKey:@"Createdby"];
    [dic setObject:[dicToSchedule valueForKey:@"PhotoPath"] forKey:@"Createdbyphotopath"];
    [dic setObject:[dicToSchedule valueForKey:@"StatusType"] forKey:@"StatusType"];
    
    return dic;
}
@end
