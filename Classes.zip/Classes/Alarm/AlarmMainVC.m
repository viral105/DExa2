//
//  AlarmMainVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "AlarmMainVC.h"

@interface AlarmMainVC (){
    NSMutableArray *arrAllAlarmNotif;
    NSIndexPath *selIndexPath;
    
}
@property (nonatomic, strong) NSMutableArray *arrAllAlarmNotif;

@end

@implementation AlarmMainVC
@synthesize arrAllAlarmNotif,isBackFromSentReceive;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.arrAllAlarmNotif = [NSMutableArray new];
    //B6702BA0-9144-48FC-8555-55AF61A3A8B0
//    NSString *strFilePath = [NSString stringWithFormat:@"%@",[Validation createAlramFolder]];
    
    [self.lblNoAlarmFound setTextColor:TWITTER_BLUE_COLOR];
    [self.lblNoAlarmFound setShadowColor:[UIColor clearColor]];
    NSLog(@"%d",(int)[[UIApplication sharedApplication] scheduledLocalNotifications].count);
    for (int i=0; i<[[UIApplication sharedApplication] scheduledLocalNotifications].count; i++) {
        NSLog(@"%@",[[[UIApplication sharedApplication] scheduledLocalNotifications] objectAtIndex:i]);
    }
    self.view.backgroundColor = UIColorFromRGB(0Xefefef);
    
    if ([Validation setOverlayFlags:3]) {
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
        [imgView setImage:[UIImage imageNamed:@"reminders@2x.png"]];
        [imgView setUserInteractionEnabled:YES];
        
        UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(overlayImageTaped:)];
        [tapGes setNumberOfTapsRequired:1];
        [imgView addGestureRecognizer:tapGes];
        tapGes = nil;
        
        [[[UIApplication sharedApplication] keyWindow] addSubview:imgView];
    }
    
    self.lblTotalNotifCount.backgroundColor = UIColorFromRGB(0Xfcc848);
    self.lblTotalNotifCount.textColor = [UIColor whiteColor];
    self.lblTotalNotifCount.font = [UIFont fontWithName:Font_Montserrat_Bold size:12];
    self.lblTotalNotifCount.layer.borderColor = [UIColor whiteColor].CGColor;
    self.lblTotalNotifCount.layer.borderWidth = 1;
    self.lblTotalNotifCount.clipsToBounds = YES;
    self.lblTotalNotifCount.textAlignment = NSTextAlignmentCenter;
    
}
- (void)viewWillAppear:(BOOL)animated{
    [self.btnMenu removeTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
	[self.btnMenu addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
    appDelegate.currentVc = self;
    
    NSLog(@"filepath is %@",NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES));
    
    [self.arrAllAlarmNotif removeAllObjects];
    [appDelegate selectAllAlarm:self.arrAllAlarmNotif];
    NSLog(@"self.arrAllAlarmNotif.count %d",(int)self.arrAllAlarmNotif.count);
    NSLog(@"self.arrAllAlarmNotif.count = %@",self.arrAllAlarmNotif);
    
    if (self.arrAllAlarmNotif.count == 0) {
        self.lblNoAlarmFound.hidden = FALSE;
    }
    else{
        self.lblNoAlarmFound.hidden = TRUE;
    }
    
    if (self.arrAllAlarmNotif.count == 0 && !self.isBackFromSentReceive) {
        self.isBackFromSentReceive = NO;
        [self performSegueWithIdentifier:@"AlarmRequestListManual" sender:self];
    }
    [self.tblData reloadData];
    [self setCountLabel];
    
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
}
-(void)setCountLabel{
    if ([appDelegate.currentVc isKindOfClass:[self class]]) {
        if ([[Validation.dicNotifCount valueForKey:TOTAL_ALARM_REQUEST] intValue] >0) {
            [self.lblTotalNotifCount setHidden:NO];
            self.lblTotalNotifCount.text = [NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_ALARM_REQUEST]];
            CGSize size = CGSizeMake(1000, 50);
            CGRect text = [self.lblTotalNotifCount.text boundingRectWithSize:size
                                                                     options:NSStringDrawingUsesLineFragmentOrigin
                                                                  attributes:@{NSFontAttributeName:self.lblTotalNotifCount.font}
                                                                     context:nil];
            
            self.lblTotalNotifCount.frame = CGRectMake(self.lblTotalNotifCount.frame.origin.x, self.lblTotalNotifCount.frame.origin.y, text.size.width+10, text.size.height+7);
            
            self.lblTotalNotifCount.layer.cornerRadius = (text.size.width+5)/3;
            
        }
        else{
            [self.lblTotalNotifCount setHidden:YES];
        }
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"EditAlarm"]) {
        SetAlarmVC *avc = [segue destinationViewController];
        
        avc.dicSel = [self.arrAllAlarmNotif objectAtIndex:selIndexPath.row];
    }
    if ([segue.identifier isEqualToString:@"AlarmRequestListManual"]) {
        AlarmRequestListVC *arl = [segue destinationViewController];
        arl.delegate = self;
    }
}
-(void)isBackFromAlarmList{
    self.isBackFromSentReceive = YES;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrAllAlarmNotif.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    AlarmMainVcCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellIdAlarmMain"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.delegate = self;
    NSDictionary *dic = [self.arrAllAlarmNotif objectAtIndex:indexPath.row];
    cell.dicSel = dic;
    cell.indPathSel = indexPath;
    [cell setUI];
    return cell;
}
-(void)overlayImageTaped:(UIGestureRecognizer *)gesRecognizer{
    [gesRecognizer.view removeFromSuperview];
}
-(void)editAlarm:(NSIndexPath *)indPath{
    selIndexPath = indPath;
    [self performSegueWithIdentifier:@"EditAlarm" sender:self];
}
-(void)deleteAlarm:(NSIndexPath *)indPath{
    UIAlertView *aView = [[UIAlertView alloc] initWithTitle:ALERT message:@"Are you sure to delete this reminder ?" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Yes",@"No", nil];
    aView.tag = 101;
    [aView show];
    
    selIndexPath = indPath;
}

-(void)PlayAlarm:(NSIndexPath *)indPath{
    
    NSMutableDictionary *dicTemp = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrAllAlarmNotif objectAtIndex:indPath.row]];
    [dicTemp setValue:@"404" forKey:USER_REMINDER_REQUEST_STATUS];
    [appDelegate playLocalAlarm:dicTemp];
    dicTemp = nil;
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 101) {
        if (buttonIndex==0) {
            NSDictionary *dic = [self.arrAllAlarmNotif objectAtIndex:selIndexPath.row];
            NSArray *arrNotif = [[UIApplication sharedApplication] scheduledLocalNotifications];
            for (int i=0; i<arrNotif.count; i++) {
                UILocalNotification *notifSel = [arrNotif objectAtIndex:i];
                if ([[notifSel.userInfo valueForKey:@"Aid"] isEqualToString:[dic valueForKey:@"Aid"]]) {
                    [[UIApplication sharedApplication] cancelLocalNotification:notifSel];
                }
            }
//            [[UIApplication sharedApplication] cancelLocalNotification:notif];
            BOOL isDeleted = [appDelegate InfoDeleteAlarm:dic];
            if (isDeleted) {
                [self.arrAllAlarmNotif removeObjectAtIndex:selIndexPath.row];
            }
            if (self.arrAllAlarmNotif.count == 0) {
                self.lblNoAlarmFound.hidden = FALSE;
            }
            else{
                self.lblNoAlarmFound.hidden = TRUE;
            }
            [self.tblData reloadData];
        }
    }
}
-(void)alarmRequestArrived{
    [self performSegueWithIdentifier:@"AlarmRequestList" sender:self];
//    self.isBackFromSentReceive = NO;
}
@end
