//
//  RecordSoundFromAlarm.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "RecordSoundFromAlarmVC.h"
#import "NotificationVC.h"
#import "UploadFormVC.h"
#import "MBProgressHUD.h"
#import "ASIFormDataRequest.h"
#import "UserConversationChatVC.h"
#import "IQAudioRecorderController.h"

@interface RecordSoundFromAlarmVC ()<MBProgressHUDDelegate,IQAudioRecorderControllerDelegate> {
	MBProgressHUD *HUD;
    IQAudioRecorderController *objIQRecorder;
}
@property (nonatomic,strong)IQAudioRecorderController *objIQRecorder;
@end

@implementation RecordSoundFromAlarmVC
@synthesize objIQRecorder;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
#pragma mark - Initialization
-(id)init {
    self = [super init];
    if(self){
        [self initializeViewController];
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if(self){
        [self initializeViewController];
    }
    return self;
}

#pragma mark - Initialize View Controller Here
-(void)initializeViewController {
    // Create an instance of the microphone and tell it to use this view controller instance as the delegate
//    self.microphone = [EZMicrophone microphoneWithDelegate:self];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSArray *array = [self.navigationController viewControllers];
    for (int i=0;i<array.count;i++) {
        if ([[array objectAtIndex:i] isKindOfClass:[SetAlarmVC class]]) {
            NSLog(@"going in loop");
            self.childController = [array objectAtIndex:i];
            self.delegate = self.childController;
        }
        
    }
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	
	// Set determinate mode
	HUD.mode = MBProgressHUDModeDeterminate;
	HUD.delegate = self;
	HUD.labelText = @"Uploading";
    self.progress = [[UIProgressView alloc] initWithFrame:CGRectZero] ;
	[self.progress setProgressViewStyle: UIProgressViewStyleBar];
	
	[self.progress setFrame:CGRectMake(([[UIScreen mainScreen]bounds].size.height-160)/2,181,160,10)];
	[self.view addSubview:self.progress];
    
//    self.arrSelectedIds = [NSArray arrayWithArray:(NSArray *)[appDelegate.dic_NotificationReleatedData valueForKey:SelectedIds]];
//    self.isGroupNotif = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue];
//    self.isNotifSendToAll = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_NotifSendToAll] boolValue];
    [self testFilePathURL];
    [self LoadViewSetting];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appplicationIsActive)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];
//    [Validation showToastMessage:@"Press and Hold button to begin recording and release when you want to stop." displayDuration:INFO_MSG_DURATION];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)appplicationIsActive{
    
    self.strFilePath = @"";
    self.lblTime.text = @"10";
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
//    appDelegate.isShouldShowReplyPopUp = NO;
//    self.microphone.microphoneDelegate = nil;
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    appDelegate.currentVc = self;
    self.lblTime.text = @"10";
    
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
}

-(void)getMicePermission{
    
	NSError *error;
	[[AVAudioSession sharedInstance] setCategory:
	 AVAudioSessionCategoryPlayAndRecord error:&error];
	[[AVAudioSession sharedInstance] requestRecordPermission:^(BOOL response){
		if (!response) {
			//	NSLog(@"Microphone mute");
		}
	}];
}

- (BOOL)isHeadsetPluggedIn {
    AVAudioSessionRouteDescription* route = [[AVAudioSession sharedInstance] currentRoute];
    for (AVAudioSessionPortDescription* desc in [route outputs]) {
        if ([[desc portType] isEqualToString:AVAudioSessionPortHeadphones])
            return YES;
    }
    [Validation setAudioPropertyForRecording];
    return NO;
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark CUSTOM METHODs

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    if (DEVICE_HEIGHT == 480) {
        self.lblTime.font = [UIFont fontWithName:Font_Montserrat_Regular size:72];
        self.lblSec.font = [UIFont fontWithName:Font_Montserrat_Regular size:20];
    }
    else{
        self.lblTime.font = [UIFont fontWithName:Font_Montserrat_Regular size:90];
        self.lblSec.font = [UIFont fontWithName:Font_Montserrat_Regular size:35];
    }
    
    [self.btnRecord setTitleColor:UIColorFromRGB(0Xff3b30) forState:UIControlStateNormal];
    [self.btnNext setTitleColor:UIColorFromRGB(0Xff3b30) forState:UIControlStateNormal];
    
    [self.btnPreview.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:17]];
    [self.btnNext.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:17]];
    
    
    //------------------------------------------------------------------------------
    
    /*
     Customizing the audio plot's look
     */
    [self createAudioPlot];
    // Starts fetching audio from the default device microphone and sends data to EZMicrophoneDelegate
    
    //    NSURL *url = [self testFilePathURL];
    //    NSFileManager *fm = [NSFileManager defaultManager];
    //    if ([fm fileExistsAtPath:self.strFilePath]) {
    //        [fm removeItemAtPath:self.strFilePath error:nil];
    //    }
    
    
}


-(NSURL*)testFilePathURL {
    
    //    NSURL *url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@",
    //                                         [self applicationDocumentsDirectory],
    //                                         kAudioFilePath]];
    
    NSString *strFilePath = [NSString stringWithFormat:@"%@",[Validation createAlramFolder]];
    NSLog(@"%@",(NSArray *)[[NSFileManager defaultManager] contentsOfDirectoryAtPath:strFilePath error:NULL]);

    self.strFilePath = [NSString stringWithFormat:@"%@",[Validation getAlarmRcordingFilePath]];
    
    NSURL *url = [NSURL fileURLWithPath:self.strFilePath];
    
    NSLog(@"testFilePathURL =====>> %@",[url absoluteString]);
    
    return url;
}

-(void)createAudioPlot{
/*
    if (self.audioPlot) {
        [self.audioPlot removeFromSuperview];
        //    [self.audioPlot release];
        self.audioPlot = nil;
    }
    
    self.audioPlot = [[EZAudioPlotGL alloc]  initWithFrame:CGRectMake(10, 68, 300, 400)];
    [self.audioPlot setAutoresizingMask:UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleTopMargin];
    self.audioPlot.contentMode = UIViewContentModeScaleAspectFill;
    self.audioPlot.center = self.btnRecord.center;
    [self.view addSubview:self.audioPlot];
    
    // Background color
    //    self.audioPlot.backgroundColor = [UIColor colorWithRed: 0.984 green: 0.71 blue: 0.365 alpha: 1];
    self.audioPlot.backgroundColor = UIColorFromRGB(0Xefefef);
    //    self.audioPlot.backgroundColor = UIColorFromRGB(0X00efef);
    
    
    // Waveform color
    //    self.audioPlot.color           = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:1.0];
    self.audioPlot.color           = [UIColor redColor];
    // Plot type
    self.audioPlot.plotType        = EZPlotTypeRolling;
    // Fill
    self.audioPlot.shouldFill      = YES;
    // Mirror
    self.audioPlot.shouldMirror    = YES;
    
    self.audioPlot.gain = 3;
    
    [self.view sendSubviewToBack:self.audioPlot];
*/
    self.objIQRecorder = [[IQAudioRecorderController alloc]  init];
    self.objIQRecorder.delegate = self;
    CGRect frame = CGRectMake(10, 178, 300, 200);
    self.objIQRecorder.view.frame = frame;
    [self.objIQRecorder willMoveToParentViewController:self];
    [self.view addSubview:self.objIQRecorder.view];
    [self.view sendSubviewToBack:self.objIQRecorder.view];
    [self addChildViewController:self.objIQRecorder];
    [self.objIQRecorder didMoveToParentViewController:self];
}
-(void)audioRecorderController:(IQAudioRecorderController *)controller didFinishWithAudioAtPath:(NSString *)filePath
{
    self.strFilePath = filePath;
    //    buttonPlayAudio.enabled = YES;
}

-(void)audioRecorderControllerDidCancel:(IQAudioRecorderController *)controller
{
    //    buttonPlayAudio.enabled = NO;
}
-(void)updateRemainingTimeLabel:(NSString*)str{
    
    self.lblTime.text = [NSString stringWithFormat:@"%d",10-[str intValue]];
}
-(void)checkForIsAudioPlaying{
    if( self.audioPlayer )
    {
        if( self.audioPlayer.playing)
        {
            [self.audioPlayer stop];
        }
        self.audioPlayer.delegate = nil;
        self.audioPlayer = nil;
        [self.btnPreview setTitle:@"Preview" forState:UIControlStateNormal];
    }
}
#pragma mark timer methods

-(void)startTimer:(NSTimer *)time{
    self.timeRemaining -= 1;
    
    self.lblTime.text = [NSString stringWithFormat:@"%d",self.timeRemaining];
    
    if (self.timeRemaining <= 0) {
        self.isShouldStop = YES;
    }
    
    if (self.isShouldStop) {
        [self.timerRecord invalidate];
        self.timerRecord = nil;
        
        NSFileManager *fm = [NSFileManager defaultManager];
        if ([fm fileExistsAtPath:self.strFilePath]) {
            NSLog(@"file exist");
        }
        
        
        self.isRecording = NO;
        
        if ([fm fileExistsAtPath:self.strFilePath]) {
            NSLog(@"file exist");
        }
        
        
        //
        //
        //        self.audioPlot.plotType        = EZPlotTypeRolling;
        //        // Fill
        //        self.audioPlot.shouldFill      = YES;
        //        // Mirror
        //        self.audioPlot.shouldMirror    = YES;
        //
        //        self.audioPlot.gain = 3;
        
        //      [self.recorder release];
    }
}


#pragma mark - Utility

-(NSArray*)applicationDocuments {
    return NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
}

-(NSString*)applicationDocumentsDirectory
{
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:RECORDING_FOLDER])
	{
		[fm createDirectoryAtPath:RECORDING_FOLDER
      withIntermediateDirectories:YES
                       attributes:nil
                            error:NULL];
	}
    
    
    NSString *basePath = [RECORDING_FOLDER stringByAppendingPathComponent:@"MySound.m4a"];
    
    
    if ([fm fileExistsAtPath:basePath]) {
        [fm removeItemAtPath:basePath error:nil];
    }
    return basePath;
}
/*
-(IBAction)btnStartStopRecording:(id)sender{
    
    if ([self.audioPlayer isPlaying]) {
        [self.audioPlayer stop];
    }
    
    if (![self.timerRecord isValid]) {
        if(((UIButton *)sender).tag == 10)
        {
            [self createAudioPlot];
            self.timeRemaining = 10;
            self.lblTime.text = [NSString stringWithFormat:@"%d",self.timeRemaining];
            
//             Create the recorder
            
            
            NSURL *url = [self testFilePathURL];
            self.recorder = [EZRecorder recorderWithDestinationURL:url
                                                      sourceFormat:self.microphone.audioStreamBasicDescription
                                               destinationFileType:EZRecorderFileTypeM4A];
            
            
            
            
            self.timerRecord = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(startTimer:) userInfo:nil repeats:YES];
            
            self.btnRecord.tag = 11;
            self.isShouldStop = NO;
            [self.microphone startFetchingAudio];
            self.isRecording = YES;
            [self.btnPreview setEnabled:NO];
            [self.btnRecord setImage:[UIImage imageNamed:btnRecordStop] forState:UIControlStateNormal];
        }
    }
}
*/
-(IBAction)btnStartStopRecording:(id)sender{
    
    if ([self.audioPlayer isPlaying]) {
        [self.audioPlayer stop];
        
        self.isRecording = NO;
    }
    
    if (![self.timerRecord isValid]) {
        if(((UIButton *)sender).tag == 10)
        {
            [self createAudioPlot];
            self.timeRemaining = 10;
            self.lblTime.text = [NSString stringWithFormat:@"%d",self.timeRemaining];
            /*
             Create the recorder
             */
            
            
            self.timerRecord = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(startTimer:) userInfo:nil repeats:YES];
            
            self.btnRecord.tag = 11;
            self.isShouldStop = NO;
            self.isRecording = YES;
            [self.btnPreview setEnabled:NO];
            [self.btnRecord setImage:[UIImage imageNamed:btnRecordStop] forState:UIControlStateNormal];
        }
    }
}
-(IBAction)btnStopRecordingClicked:(id)sender{
    self.btnRecord.tag = 10;
    
    self.isShouldStop = YES;
    //    self.isRecording = NO;
    [self.btnPreview setEnabled:YES];
    [self.btnRecord setImage:[UIImage imageNamed:btnRecordStart] forState:UIControlStateNormal];
    
}


-(IBAction)btnPreviewRecroding:(id)sender{
    // Create Audio Player
    [self isHeadsetPluggedIn];
    if( self.audioPlayer )
    {
        if( self.audioPlayer.playing )
        {
            [self.audioPlayer stop];
        }
        self.audioPlayer.delegate = nil;
        self.audioPlayer = nil;
        [self.btnRecord setEnabled:YES];
        [self.btnPreview setTitle:@"Preview" forState:UIControlStateNormal];
    }
    else{
        
        // [Validation setAudioPropertyForRecording];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        if ([fm fileExistsAtPath:self.strFilePath]) {
            NSLog(@"file exist");
            
            //        if( self.recorder )
            //        {
            //            [self.recorder closeAudioFile];
            //        }
            [self.btnPreview setTitle:@"Stop" forState:UIControlStateNormal];
            NSError *err;
            self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL URLWithString:self.strFilePath]
                                                                      error:&err];
            [self.audioPlayer prepareToPlay];
            
            self.audioPlayer.delegate = self;
            self.isRecording = NO;
            [self.btnRecord setEnabled:NO];
            [self.audioPlayer play];
            
        }
        else{
            [Validation showToastMessage:@"Please record a Blab." displayDuration:ERROR_MSG_DURATION];
        }
    }
    
    // Close the audio file
}

-(IBAction)btnNextUploadClicked:(id)sender{
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:self.strFilePath]) {
        NSLog(@"file exist");
        if(![self.delegate respondsToSelector:@selector(displayAlarmRecordedSoundName:)]) {
            
            NSLog(@"delegate cannot respond");
        } else {
            
            NSLog(@"delegate can respond");
            [self.delegate displayAlarmRecordedSoundName:self.strFilePath];
            NSArray *array = [self.navigationController viewControllers];
            for (int i = 0; i<array.count; i++) {
                if ([[array objectAtIndex:i] isKindOfClass:[SetAlarmVC class]]) {
                    [self.navigationController popToViewController:[array objectAtIndex:i] animated:YES];
                }
            }
        }
    }
    else{
        [Validation showToastMessage:@"Please record a Blab." displayDuration:ERROR_MSG_DURATION];
    }
}

-(IBAction)btnCancel:(id)sender{
    if (!self.isRecording) {
        if ([self.audioPlayer isPlaying]) {
            [self.audioPlayer stop];
        }
        [self.timerRecord invalidate];
        [self.navigationController popViewControllerAnimated:YES];
    }
    
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:self.strFilePath]) {
        [fm removeItemAtPath:self.strFilePath error:nil];
    }
    
}

- (void)setProgressFORHUD:(float)progress {
    NSLog(@"actual progress = %f",self.progress.progress);
    // int prog = (round(self.progress.progress*100));
    [HUD setProgress:self.progress.progress];
    if (self.progress.progress == 1.0) {
        [self.timer invalidate];
        HUD.mode = MBProgressHUDModeIndeterminate;
        HUD.labelText = @"";
    }
}

-(void)ShowUploadForm{
    
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:UPLOAD_FORM_VC]) {
        UploadFormVC *objUpload = segue.destinationViewController;
        objUpload.strFilePath = self.strFilePath;
    }
}

#pragma mark - EZMicrophoneDelegate
//#warning Thread Safety
// Note that any callback that provides streamed audio data (like streaming microphone input) happens on a separate audio thread that should not be blocked. When we feed audio data into any of the UI components we need to explicity create a GCD block on the main thread to properly get the UI to work.
/*
-(void)microphone:(EZMicrophone *)microphone
 hasAudioReceived:(float **)buffer
   withBufferSize:(UInt32)bufferSize
withNumberOfChannels:(UInt32)numberOfChannels {
    // Getting audio data as an array of float buffer arrays. What does that mean? Because the audio is coming in as a stereo signal the data is split into a left and right channel. So buffer[0] corresponds to the float* data for the left channel while buffer[1] corresponds to the float* data for the right channel.
    
    // See the Thread Safety warning above, but in a nutshell these callbacks happen on a separate audio thread. We wrap any UI updating in a GCD block on the main thread to avoid blocking that audio flow.
    dispatch_async(dispatch_get_main_queue(),^{
        // All the audio plot needs is the buffer data (float*) and the size. Internally the audio plot will handle all the drawing related code, history management, and freeing its own resources. Hence, one badass line of code gets you a pretty plot :)
        [self.audioPlot updateBuffer:buffer[0] withBufferSize:bufferSize];
    });
}

-(void)microphone:(EZMicrophone *)microphone
    hasBufferList:(AudioBufferList *)bufferList
   withBufferSize:(UInt32)bufferSize
withNumberOfChannels:(UInt32)numberOfChannels {
    
    // Getting audio data as a buffer list that can be directly fed into the EZRecorder. This is happening on the audio thread - any UI updating needs a GCD main queue block. This will keep appending data to the tail of the audio file.
    if( self.isRecording ){
        [self.recorder appendDataFromBufferList:bufferList
                                 withBufferSize:bufferSize];
    }
    
}
*/

#pragma mark - AVAudioPlayerDelegate
/*
 Occurs when the audio player instance completes playback
 */
-(void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag {
    
    self.audioPlayer.delegate = nil;
    self.audioPlayer = nil;
    [self.btnRecord setEnabled:YES];
    [self.btnPreview setTitle:@"Preview" forState:UIControlStateNormal];
    
}

@end
