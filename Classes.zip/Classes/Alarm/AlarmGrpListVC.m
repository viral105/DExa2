//
//  AlarmGrpListVC.m
//  WWHHAAZZAAPP
//
//  Created by Nivid on 23/03/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "AlarmGrpListVC.h"
#import "GroupListCell.h"
#import "MBProgressHUD.h"
#define CellHeight			63
#define PageSize			8

@interface AlarmGrpListVC ()<MBProgressHUDDelegate> {
    MBProgressHUD *HUD;
}


@end

@implementation AlarmGrpListVC

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.arrData = [[NSMutableArray alloc] init] ;
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    [self.lblNoGrpFound setTextColor:TWITTER_BLUE_COLOR];
    [self.lblNoGrpFound setShadowColor:[UIColor clearColor]];
    NSLog(@"dic = %@",appDelegate.dic_NotificationReleatedData);
    self.selectedIndex = -1;
    self.pageCounter= 1;
    self.lblNoGrpFound.hidden = YES;
    //[Validation showLoadingIndicator];
    
    [self loadUserListingVC];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    appDelegate.currentVc = self;
    //self.lblNoGrpFound.hidden = FALSE;
    
    self.imgSelected = [[UIImageView alloc] initWithFrame:CGRectMake(self.tblData.frame.size.width-40, (CellHeight-30)/2, 30, 30)];
    [self.imgSelected setImage:[UIImage imageNamed:btn_Checkbox_Selected]];
    
    
    [self performSelectorInBackground:@selector(GetGroupList) withObject:nil];
    
   // [Validation removeAdviewFromSuperView];
//    [self.view addSubview:[Validation sharedBannerView]];
//    [Validation ResizeViewForAds];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [Validation increaseTableSize];
    appDelegate.isShouldShowReplyPopUp = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark	UIButton Action

-(void)loadUserListingVC{
    
    //show user listing here only
    // and when user clickes on add user to group then go to this
    self.view.backgroundColor = UIColorFromRGB(0Xefefef);
    [self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    
    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
    [self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    
    self.pageCounter = 1;
    self.lblNoGrpFound.hidden = YES;
}

-(IBAction)btnBackClicked:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)GetGroupList{
    if (self.request !=nil) {
        self.request = nil;
    }
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_GRP_LIST withParameters:nil];
    //	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    //	self.request.delegate = self;
    //	self.request.tag = 1;
    
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:1];
    strUrl = nil;
}

#pragma mark
#pragma mark		UITableView DataSource Methos
#pragma mark

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.arrData.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return CellHeight;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *cellId = [NSString stringWithFormat:@"%d",(int)indexPath.row];
    
    if (indexPath.row < self.arrData.count) {
        cellId = [cellId stringByAppendingFormat:@"%@%@",[[self.arrData objectAtIndex:indexPath.row] valueForKey:GRP_ID],[[self.arrData objectAtIndex:indexPath.row] valueForKey:GRP_NAME]];
    }
    
    GroupListCell *cell = (GroupListCell *)[tableView dequeueReusableCellWithIdentifier:cellId];
    [cell clearsContextBeforeDrawing];
    
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary*)[self.arrData objectAtIndex:indexPath.row]];
    if (cell == nil) {
        cell = [[GroupListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        [cell setBoxValuesWithData:dic];
        cell.btnGroupDelete.hidden = YES;
        cell.btnGroupEdit.hidden = YES;
    }
    
    dic = nil;
    
    if (indexPath.row == self.arrData.count-1) {
        if (self.isDataNull == NO) {
            [HUD show:YES];
            
            self.pageCounter++;
            [self performSelectorInBackground:@selector(GetGroupList) withObject:nil];
        }
    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    self.selectedIndex = (int)indexPath.row;
    
    [self.imgSelected removeFromSuperview];
    
    GroupListCell *cell = (GroupListCell *)[tableView cellForRowAtIndexPath:indexPath];
    [cell addSubview:self.imgSelected];
//    NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indexPath.row inSection:indexPath.section]];
//    [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationAutomatic];
    
    
   // [tableView deselectRowAtIndexPath:indexPath animated:NO];
    [Validation CancelOnGoingRequests:self.request];
    if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:@"GroupUserIDs"]]].length > 0) {
//        [self showYapOptions];
    }
    else{
        [Validation showToastMessage:@"No friend found in this group." displayDuration:ERROR_MSG_DURATION];
        self.selectedIndex = -1;
        [self.imgSelected removeFromSuperview];
    }
}

- (void)successResponseWithData:(id)request withTag:(int)tag{
    //	NSError *error = nil;
    if (self.activityLoading != nil) {
        [self.activityLoading removeFromSuperview];
        self.activityLoading = nil;
    }
    
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    //NSLog(@"dictionary = %@",dicResponse);
    
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if ([dicResponse objectForKey:RESPONSE] != nil) {
                
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    
                    if (tag == 1){
                        //get grp list
                        //received
                        
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            if (self.pageCounter==1) {
                                [self.arrData removeAllObjects];
                            }
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.isDataNull = NO;
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            
                            if (arr.count>0) {
                                [self.arrData addObjectsFromArray:arr];
                                
                                [self.tblData reloadData];
                            }
                            if (self.arrData.count>0) {
                                self.lblNoGrpFound.hidden = YES;
                            }
                            arr = nil;
                        }
                        response = nil;
                        [HUD hide:YES];
                    }
                }
                else{
                    if ([[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:@"status"]] intValue] != 0) {
                        [HUD hide:YES];
                        UIButton *btnNext = (UIButton *)[self.view viewWithTag:112];
                        btnNext.hidden = YES;
                        self.isDataNull = YES;
                        if (self.arrData.count ==0) {
                            self.lblNoGrpFound.hidden = FALSE;
                        }
                    }
                    else{
                        [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                        [HUD hide:YES];
                    }
                    
                }
                self.request = nil;
            }
            else{
                if ([[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:@"status"]] intValue] != 0) {
                    [HUD hide:YES];
                    if (self.arrData.count ==0) {
                        self.lblNoGrpFound.hidden = FALSE;
                    }
                }
                else{
                    [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                    [HUD hide:YES];
                }
            }
            
            dicResponse = nil;
        }
        
    }
    else{
        [HUD hide:YES];
    }
    dicResponse = nil;
}


-(IBAction)btnNextClicked:(id)sender{
    [Validation CancelOnGoingRequests:self.request];
    
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
    self.request = nil;
    
    NSLog(@"arrSelected => %@",self.arrData);
    if (self.selectedIndex != -1) {
        NSFileManager *fm = [NSFileManager defaultManager];
        if ([fm fileExistsAtPath:[self.dicSel valueForKey:@"SoundPath"]]) {
            [HUD show:YES];
            [self callSendAlarmRequest:@"Recording"];
        }
        else{
            [HUD show:YES];
            [self callSendAlarmRequest:@""];
        }
    }
    else{
        [AlertHandler alertTitle:ALERT message:@"Please select group." delegate:self tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
}


-(void)callSendAlarmRequest:(NSString*)recordedSoundId{
    if (self.request !=nil) {
        self.request = nil;
    }
  
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",BASE_URL,SEND_ALARM_REQUEST];
    
    self.requestAsi = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:strUrl]];
    
    [self.requestAsi setDelegate:self];
    
    [self.requestAsi addRequestHeader:@"userid" value:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]];
    
    NSString *strT1 = [Validation GetUTCDate];
    
    [self.requestAsi addRequestHeader:@"T1" value:strT1];
    [self.requestAsi addRequestHeader:@"T2" value:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE]];
    
    [self.requestAsi setPostValue:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]] forKey:@"FromUserID"];
    [self.requestAsi setPostValue:[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:GRP_ID] forKey:@"GroupIDs"];
    [self.requestAsi setPostValue:[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"Utcdate"]] forKey:@"UtcDateTime"];
    
    if (recordedSoundId.length==0) {
        [self.requestAsi setPostValue:[self.dicSel valueForKey:@"RandomSoundID"] forKey:@"RandomSoundID"];
        [self.requestAsi setPostValue:[NSString stringWithFormat:@""] forKey:@"FileData"];
    }
    else{
        [self.requestAsi setPostValue:@"0" forKey:@"RandomSoundID"];
        NSString *strPath = [NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]];
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:strPath]) {
            NSLog(@"file exist");
        }
        NSMutableData *data = [NSMutableData dataWithContentsOfFile:strPath];
        [self.requestAsi addData:data withFileName:@"userSound.m4a" andContentType:@"multipart/form-data" forKey:@"FileData"];
    }
    [self.requestAsi setPostValue:[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"Alarmname"]] forKey:@"AlarmName"];
    
    
    self.requestAsi.tag = 3;
    [self.requestAsi startAsynchronous];
    
}

- (void)requestFinished:(ASIHTTPRequest *)request{
    NSError *error = nil;
    
    NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
                                                                 options:0
                                                                   error:&error];;
    
    NSLog(@"dicResponse = %@",dicResponse);
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (request.tag == 3){
                id response = [dicResponse objectForKey:RESPONSE];
                if (response != nil) {
                    [HUD hide:YES];
                    if ([NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]].length!=0 && [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]]]) {
                        [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]] error:nil];
                    }
                    NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                    NSLog(@"arr send alarm req response %@",arr);
                    [self.navigationController popToRootViewControllerAnimated:YES];
                }
                else{
                    [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                    [HUD hide:YES];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
    
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}

/*
-(void)StartUploadingAudioFile{
    //   [Validation showLoadingIndicatorInView:self.view];
    [HUD show:YES];
    
    [self uploadFile];
    
}
-(void)uploadFile{
    
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:[self.dicSel valueForKey:@"SoundPath"]]) {
        NSLog(@"file exists");
    }
    
    //	NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
    //						  [NSDictionary dictionaryWithObjectsAndKeys:self.strFilePath,KeyValue,@"SoundData",KeyName, nil],@"1",
    //						  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Name",KeyName, nil],@"2",
    //						  [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SoundMasterID",KeyName, nil],@"3",
    //						  [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SoundSubMasterID",KeyName, nil],@"4",
    //						  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"5",
    //						  [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"Gender",KeyName, nil],@"6",
    //						  [NSDictionary dictionaryWithObjectsAndKeys:(self.isPrivate)?@"true":@"false",KeyValue,@"IsPrivate",KeyName, nil],@"7",
    //						  nil];
    NSString *strUrl = [NSString stringWithFormat:@"%@",UPLOAD_AUDIO_FILE];
    //	self.request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    //	self.request.delegate = self;
    //    [self.request setUploadProgressDelegate:self.progress];
    //	[self.request setDelegate:self];
    //
    //	self.request.tag = 1;
    //	strUrl = nil;
    //
    //    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(setProgressFORHUD:) userInfo:nil repeats:YES];
    
    self.requestAudioUpload = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:strUrl]];
    
    [self.requestAudioUpload setDelegate:self];
    
    [self.requestAudioUpload addRequestHeader:@"userid" value:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]];
    NSString *strT1 = [Validation GetUTCDate];
    [self.requestAudioUpload addRequestHeader:@"T1" value:strT1];
    [self.requestAudioUpload addRequestHeader:@"T2" value:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE]];
    
    [self.requestAudioUpload setPostValue:@"" forKey:@"Name"];
    [self.requestAudioUpload setPostValue:@"0" forKey:@"SoundMasterID"];
    [self.requestAudioUpload setPostValue:@"0" forKey:@"SoundSubMasterID"];
    [self.requestAudioUpload setPostValue:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]] forKey:@"UserID"];
    [self.requestAudioUpload setPostValue:@"0" forKey:@"Gender"];
    [self.requestAudioUpload setPostValue:@"false" forKey:@"IsPrivate"];
    
    
    self.progress.progress = 0.0;
    self.progress.hidden = YES;
    [self.requestAudioUpload setUploadProgressDelegate:self.progress];
    [self.requestAudioUpload setShouldContinueWhenAppEntersBackground:YES];
    
    NSString *strPath = [NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]];
    
    if ([fm fileExistsAtPath:strPath]) {
        NSLog(@"file exist");
    }
    NSMutableData *data = [NSMutableData dataWithContentsOfFile:strPath];
    [self.requestAudioUpload addData:data withFileName:@"userSound.m4a" andContentType:@"multipart/form-data" forKey:@"SoundData"];
    
    self.requestAudioUpload.tag = 1;
    [self.requestAudioUpload startAsynchronous];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(setProgressFORHUD:) userInfo:nil repeats:YES];
    
}
 */
/*
- (void)setProgressFORHUD:(float)progress {
    NSLog(@"actual progress = %f",self.progress.progress);
    // int prog = (round(self.progress.progress*100));
    [HUD setProgress:self.progress.progress];
    if (self.progress.progress == 1.0) {
        [self.timer invalidate];
        HUD.mode = MBProgressHUDModeIndeterminate;
        HUD.labelText = @"";
    }
}
*/
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
