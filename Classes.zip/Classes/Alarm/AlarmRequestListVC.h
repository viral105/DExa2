//
//  AlarmRequestListVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 2/3/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AlarmRequestListCell.h"

@protocol AlarmRequestListVCDelegate <NSObject>

-(void)isBackFromAlarmList;

@end

@interface AlarmRequestListVC : UIViewController<UITableViewDataSource, UITableViewDelegate,UIActionSheetDelegate,UIAlertViewDelegate,AFNetworkingDataTransactionDelegate,UITextFieldDelegate,AlarmRequestListCellDelegate>

@property (nonatomic, strong) IBOutlet UITableView *tblData;
@property (nonatomic, strong) IBOutlet UILabel *lblTitle;
@property (nonatomic, strong) AFNetworkingDataTransaction	*request;
@property (nonatomic, strong) NSMutableArray *arrAllRecievedAlarmRequest;
@property (nonatomic, strong) NSMutableArray *arrAllSentAlarmRequest;

@property (strong, nonatomic) IBOutlet UITableView *tblView;
@property (strong, nonatomic) IBOutlet UIView *viewAlertPicker;
@property (strong, nonatomic) IBOutlet UIView *viewContainingPicker;
@property (strong, nonatomic) IBOutlet UILabel *lblRecurringAndAlertOptionTitle;

@property (strong, nonatomic) IBOutlet UIButton *btnReceived;
@property (strong, nonatomic) IBOutlet UIButton *btnSent;
@property (strong, nonatomic) IBOutlet UILabel  *lblNoAlarmFound;

@property (nonatomic, readwrite) int           SelectedAlarmList;  //1 = received; 2 = sent
@property (strong, nonatomic) id<AlarmRequestListVCDelegate> delegate;

@end
