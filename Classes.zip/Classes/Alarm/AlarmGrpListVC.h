//
//  AlarmGrpListVC.h
//  WWHHAAZZAAPP
//
//  Created by Nivid on 23/03/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlarmGrpListVC : UIViewController <UITableViewDataSource, UITableViewDelegate,UIAlertViewDelegate,UIActionSheetDelegate,AFNetworkingDataTransactionDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, strong) IBOutlet UILabel				*lblNoGrpFound;
@property (nonatomic, readwrite) int						selectedIndex;
@property (nonatomic, strong) AFNetworkingDataTransaction	*request;
@property (nonatomic, strong) ASIFormDataRequest		*requestAudioUpload;
@property (nonatomic, strong) ASIFormDataRequest		*requestAsi;

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) UIActivityIndicatorView		*activityLoading;

@property (nonatomic, strong) NSMutableDictionary           *dicSel;

@property (nonatomic, strong) UIImageView                   *imgSelected;

@end
