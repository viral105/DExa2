//
//  AlertPickerVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 2/10/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlarmAlertPickerVC : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    IBOutlet UITableView *tblView;

}

@end
