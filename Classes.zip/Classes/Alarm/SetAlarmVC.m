//
//  SetAlarmVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

/*  Used Tag num

 101 viewAlertPicker when viewing Set Alert Option
 102 viewAlertPicker when viewing Recurring Option

*/
#import "SetAlarmVC.h"

@interface SetAlarmVC (){
    NSDictionary *dicSelSound;
    NSString *strRecordedSoundUrl;
    NSMutableArray *arrAlertTime;
    NSIndexPath *lastIndexPath;
    NSMutableDictionary *dicValidated;
    BOOL isShowAd;
}
@property (nonatomic,strong)NSDictionary *dicSelSound;
@property (nonatomic, strong)NSMutableArray *arrAlertTime;
@property (nonatomic, strong)NSIndexPath *lastIndexPath;

@end

@implementation SetAlarmVC
@synthesize dicSelSound;
@synthesize arrAlertTime;
@synthesize lastIndexPath;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tfAlarmName.delegate = self;
    self.arrAlertTime = [[NSMutableArray alloc] initWithObjects:@"5 minutes before",@"10 minutes before",@"15 minutes before",@"30 minutes before",@"1 hour before",@"2 hour before",@"1 day before",@"1 week before", nil];
    self.viewAlertPicker.tag = 101;
    self.viewAlarmReceiverType.hidden = NO;
    
    self.selectedReceiverType = -1;
    [self LoadViewSetting];
    NSLog(@"%@",self.dicSel);
    NSLog(@"%@",self.self.dicSelSound);
    if ([self.dicSel allKeys]!=0) {
        [self.btnDate setTitle:[self.dicSel valueForKey:@"Alarmdate"] forState:UIControlStateNormal];
        [self.btnTime setTitle:[self.dicSel valueForKey:@"Alarmtime"] forState:UIControlStateNormal];
        [self.tfAlarmName setText:[self.dicSel valueForKey:@"Alarmname"]];
        if ([[self.dicSel valueForKey:NOTIF_Category] isEqualToString:@""]) {
            [self.btnAlarmSound setTitle:@"Recorded" forState:UIControlStateNormal];
        }
        else{
            [self.btnAlarmSound setTitle:[self.dicSel valueForKey:NOTIF_Category] forState:UIControlStateNormal];
        }
        if ([DataValidation checkNullString:[self.dicSel valueForKey:@"SelectedAlertOptionIndexpath"]].length==0) {
            self.lastIndexPath = [NSIndexPath indexPathForItem:0 inSection:0];
        }
        else{
            self.lastIndexPath = [NSIndexPath indexPathForItem:[[self.dicSel valueForKey:@"SelectedAlertOptionIndexpath"] intValue] inSection:0];
        }
        self.selectedReceiverType = 3;      //set for me.. in case of me only this edit screen would come
        
        self.lblAlarmReceiverType.hidden = YES;
        
        self.viewAlarmReceiverType.hidden = YES;
        //        self.btnSetForMe.tag = 3;
        //        [self.btnSetForMe setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        
        //[self.btnSetForMe setTitle:@"Done" forState:UIControlStateNormal];
        //        self.btnSetForMe.frame  = CGRectMake(0, self.btnSetForMe.frame.origin.y, self.view.frame.size.width, self.btnSetForMe.frame.size.height);
        // self.btnSendToFriend.hidden  = YES;
    }
    else{
        self.lastIndexPath = [NSIndexPath indexPathForItem:0 inSection:0];
        isShowAd = YES;
        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        //        self.btnSetForMe.hidden = YES;
        //        self.btnSendToFriend.hidden = YES;
        self.btnNext.hidden = YES;
        self.btnSetForMe.tag = 0;
    }
}
-(void)showAd:(BOOL)flagShowHide{
    
    if (!flagShowHide) {
        [Validation removeAdviewFromSuperView];
    }
    else{
        if ([self checkValidationFromAd] && [self.dicSel allKeys]== nil) {
            [Validation removeAdviewFromSuperView];
            [self.view addSubview:[Validation sharedBannerView]];
            self.btnNext.hidden = TRUE;
        }
        else{
            [Validation removeAdviewFromSuperView];

            self.btnNext.hidden = NO;
        }
    }
    /*
    if (self.btnSetForMe.tag == 0) {
        if (flagShowHide) {
            NSLog(@"bool val--> %d",[self checkValidationFromAd]);
            if ([self.dicSel allKeys]==0 || [self checkValidationFromAd]) {
                [Validation removeAdviewFromSuperView];
                [self.view addSubview:[Validation sharedBannerView]];
//                self.btnSetForMe.hidden = YES;
//                self.btnSendToFriend.hidden = YES;
                self.btnNext.hidden = YES;
            }
            else{
                if ([Validation.adView isDescendantOfView:self.view]) {
                    [Validation removeAdviewFromSuperView];
                }
//                self.btnSetForMe.hidden = NO;
//                self.btnSendToFriend.hidden = NO;
                self.btnNext.hidden = NO;
            }
        }
        else{
            if ([Validation.adView isDescendantOfView:self.view]) {
                [Validation removeAdviewFromSuperView];
            }
            
            //            self.btnSetForMe.hidden = NO;
            //            self.btnSendToFriend.hidden = NO;
            
            self.btnNext.hidden = NO;
        }
    }
     */
}

-(void)viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
    
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.tfAlarmName resignFirstResponder];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:ALARM_FRIEND_LIST_VC]) {
        AlarmFriendListVC *avc = [segue destinationViewController];
        avc.dicSel = (NSMutableDictionary *)sender;
    }
    else if ([segue.identifier isEqualToString:ALARM_GRP_LIST_VC]){
        AlarmGrpListVC *obj = [segue destinationViewController];
        obj.dicSel = (NSMutableDictionary *)sender;
    }
}

- (IBAction)btnDTPickerCancel_Clicked:(id)sender {
    [self showAd:YES];
    self.viewDtPicker.hidden = YES;
}

- (IBAction)btnDTPickerDone_Clicked:(id)sender {
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    if (self.dtPicker.datePickerMode == UIDatePickerModeDate) {
        [formatter setDateFormat:FORMAT_DATE];
        [self.btnDate setTitle:[formatter stringFromDate:[self.dtPicker date]] forState:UIControlStateNormal];
        [self.btnDate.titleLabel setText:[formatter stringFromDate:[self.dtPicker date]]];
    }
    else{
        [formatter setDateFormat:FORMAT_TIME];
        [self.btnTime setTitle:[formatter stringFromDate:[self.dtPicker date]] forState:UIControlStateNormal];
        [self.btnTime.titleLabel setText:[formatter stringFromDate:[self.dtPicker date]]];
    }
    
    [self showAd:YES];
    self.viewDtPicker.hidden = YES;
}

- (IBAction)btnDate_Clicked:(id)sender {
    [self showAd:NO];
    [self.tfAlarmName resignFirstResponder];
    self.viewDtPicker.hidden = NO;
    [self.dtPicker setDatePickerMode:UIDatePickerModeDate];
    [self.dtPicker setMinimumDate:[NSDate date]];
    [self.viewDtPicker setFrame:CGRectMake(self.viewDtPicker.frame.origin.x, [UIScreen mainScreen].bounds.size.height, self.viewDtPicker.frame.size.width, self.viewDtPicker.frame.size.height)];
    [Validation animateYpoint:[UIScreen mainScreen].bounds.size.height-self.viewDtPicker.frame.size.height viewToAnimate:self.viewDtPicker];
}

- (IBAction)btnTime_Clicked:(id)sender {
    [self showAd:NO];
    [self.tfAlarmName resignFirstResponder];
    self.viewDtPicker.hidden = NO;
    [self.dtPicker setDatePickerMode:UIDatePickerModeTime];
    [self.dtPicker setMinimumDate:[NSDate date]];
    [self.viewDtPicker setFrame:CGRectMake(self.viewDtPicker.frame.origin.x, [UIScreen mainScreen].bounds.size.height, self.viewDtPicker.frame.size.width, self.viewDtPicker.frame.size.height)];
    [Validation animateYpoint:[UIScreen mainScreen].bounds.size.height-self.viewDtPicker.frame.size.height viewToAnimate:self.viewDtPicker];
}

- (IBAction)btnBack_Clicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
-(NSMutableDictionary *) checkValidation{
    if ([self.btnDate.titleLabel.text isEqualToString:@"Date"]) {
        [AlertHandler alertTitle:ALERT message:@"Please select alarm date" delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        return nil;
    }
    if ([self.btnTime.titleLabel.text isEqualToString:@"Time"]) {
        [AlertHandler alertTitle:ALERT message:@"Please select alarm time" delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        return nil;
    }
    if (self.tfAlarmName.text.length==0) {
        [AlertHandler alertTitle:ALERT message:@"Please enter alarm name" delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        return nil;
    }
    if ([self.btnAlarmSound.titleLabel.text isEqualToString:@"Select Blab"]) {
        [AlertHandler alertTitle:ALERT message:@"Please enter alarm sound" delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        return nil;
    }
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:FORMAT_DATE];
    NSDate *date = [formatter dateFromString:self.btnDate.titleLabel.text];
    [formatter setDateFormat:FORMAT_TIME];
    NSDate *time = [formatter dateFromString:self.btnTime.titleLabel.text];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *dateComponents = [calendar components:NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit fromDate:date];
    NSDateComponents *timeComponents = [calendar components:NSHourCalendarUnit|NSMinuteCalendarUnit fromDate:time];
    
    NSDateComponents *newComponents = [[NSDateComponents alloc]init];
    //    newComponents.timeZone = [NSTimeZone systemTimeZone];
    [newComponents setDay:[dateComponents day]];
    [newComponents setMonth:[dateComponents month]];
    [newComponents setYear:[dateComponents year]];
    [newComponents setHour:[timeComponents hour]];
    [newComponents setMinute:[timeComponents minute]];
    
    NSDate *combDate = [calendar dateFromComponents:newComponents];
    NSDate *currDate = [[NSDate date] dateByAddingTimeInterval:(3*60)];
    
    if ([currDate compare:combDate]==NSOrderedDescending) {
        
        [AlertHandler alertTitle:ALERT message:@"Please select alarm date-time 3 minute later than current time." delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        return nil;
    }
    
    NSMutableDictionary *dic = [NSMutableDictionary new];
    if ([self.btnAlarmSound.titleLabel.text isEqualToString:@"Recorded"]) {
        [dic setObject:@"" forKey:NOTIF_Category];
    }
    else{
        [dic setObject:self.btnAlarmSound.titleLabel.text forKey:NOTIF_Category];
    }
    
    [dic setObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@ --> %@",TXT_ALARM,self.tfAlarmName.text],@"alert", nil] forKey:@"aps"];
    [dic setObject:@"1" forKey:@"TypeID"];
    [dic setObject:self.btnDate.titleLabel.text forKey:@"Alarmdate"];
    [dic setObject:self.btnTime.titleLabel.text forKey:@"Alarmtime"];
    [dic setObject:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH] forKey:@"PhotoPath"];
    [dic setObject:TXT_ALARM forKey:@"Name"];
    [dic setObject:self.tfAlarmName.text forKey:@"Alarmname"];
    [dic setObject:@"Me" forKey:@"Createdby"];
    [dic setObject:@"NO" forKey:@"IsFromRequest"];
    [dic setObject:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH] forKey:@"Createdbyphotopath"];
    
    NSLog(@"combDate %@ %d %d",combDate,(int)[timeComponents hour],(int)[timeComponents minute]);
    if ([self.dicSel allKeys]!=0) {
        // if it is future reminder then delete it from db and cancel scheduled notification also.
        NSArray *arrNotif = [[UIApplication sharedApplication] scheduledLocalNotifications];
        for (int i=0; i<arrNotif.count; i++) {
            UILocalNotification *notifSel = [arrNotif objectAtIndex:i];
            if ([[notifSel.userInfo valueForKey:@"Aid"] isEqualToString:[self.dicSel valueForKey:@"Aid"]]) {
                
                BOOL isDeleted = [appDelegate InfoDeleteAlarm:self.dicSel];
                if (isDeleted) {
                    NSLog(@"local notif canceled");
                    [[UIApplication sharedApplication] cancelLocalNotification:notifSel];
                }
            }
        }
        // if it is past reminder then delete it from db only.
//        BOOL isDeleted =
        [appDelegate InfoDeleteAlarm:self.dicSel];// it is ok if you are deleteing already deleted entry from db it will not crash. We have to delete it because it is from edit.
//        if (isDeleted) {
//            NSLog(@"local notif canceled");
//            
//            [[UIApplication sharedApplication] cancelLocalNotification:self.dicSel];
//        }
        
        if ([self.dicSelSound allKeys]==0) {
            [dic setObject:[self.dicSel valueForKey:@"ContentID"] forKey:@"ContentID"];
            [dic setObject:[self.dicSel valueForKey:@"SoundPath"] forKey:@"SoundPath"];
            if ([self.btnAlarmSound.titleLabel.text isEqualToString:@"Recorded"]) {
                [dic setObject:@"" forKey:@"RandomSoundID"];
            }
            else{
                [dic setObject:[self.dicSel valueForKey:@"RandomSoundID"] forKey:@"RandomSoundID"];
            }
        }
        else{
            [dic setObject:[self.dicSelSound valueForKey:@"ID"] forKey:@"ContentID"];
            [dic setObject:[self.dicSelSound valueForKey:@"RandomSoundURL"] forKey:@"SoundPath"];
            [dic setObject:[self.dicSelSound valueForKey:@"RandomSoundID"] forKey:@"RandomSoundID"];
        }
    }
    else{
        if (strRecordedSoundUrl.length==0) {
            [dic setObject:[self.dicSelSound valueForKey:@"ID"] forKey:@"ContentID"];
            [dic setObject:[self.dicSelSound valueForKey:@"RandomSoundURL"] forKey:@"SoundPath"];
            [dic setObject:[self.dicSelSound valueForKey:@"RandomSoundID"] forKey:@"RandomSoundID"];
        }
        else{
            [dic setObject:@"" forKey:@"ContentID"];
            [dic setObject:strRecordedSoundUrl forKey:@"SoundPath"];
        }
    }
    
//    self.objAlarmAlertPicVC = [self.storyboard instantiateViewControllerWithIdentifier:@"AlarmAlertPickerVC"];
//    self.objAlarmAlertPicVC.view.frame = self.viewContainingPicker.frame;
//    [self.objAlarmAlertPicVC willMoveToParentViewController:self];
//    [self.viewContainingPicker addSubview:self.objAlarmAlertPicVC.view];
//    [self addChildViewController:self.objAlarmAlertPicVC];
//    [self.objAlarmAlertPicVC didMoveToParentViewController:self];
    
    return dic;
}
-(BOOL) checkValidationFromAd{
   // NSLog(@"checkValidationFromAd %@ %@ %@ %@",self.btnDate.titleLabel.text,self.btnTime.titleLabel.text,self.tfAlarmName.text,self.btnAlarmSound.titleLabel.text);
    if ([self.btnDate.titleLabel.text isEqualToString:@"Date"]) {
        return YES;
    }
    else if ([self.btnTime.titleLabel.text isEqualToString:@"Time"]) {
        return YES;
    }
    else if (self.tfAlarmName.text.length==0) {
        return YES;
    }
    else if ([self.btnAlarmSound.titleLabel.text isEqualToString:@"Select Blab"]) {
        return YES;
    }
    else if (self.selectedReceiverType == -1){
        return YES;
    }
    else{
        return NO;
    }
}

- (IBAction)btnDone_Clicked:(id)sender {
    
    dicValidated = [self checkValidation];
    
    if (dicValidated!=nil) {
        self.viewAlertPicker.hidden = NO;
    }
}

- (IBAction)btnSendToFriend_Clicked:(id)sender{
    NSMutableDictionary *dic = [self checkValidation];
    if (dic!=nil) {
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:FORMAT_DATE];
        NSDate *date = [formatter dateFromString:[dic valueForKey:@"Alarmdate"]];
        [formatter setDateFormat:FORMAT_TIME];
        NSDate *time = [formatter dateFromString:[dic valueForKey:@"Alarmtime"]];
        NSCalendar *calendar = [NSCalendar currentCalendar];
        NSDateComponents *dateComponents = [calendar components:NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit fromDate:date];
        NSDateComponents *timeComponents = [calendar components:NSHourCalendarUnit|NSMinuteCalendarUnit fromDate:time];
        
        NSDateComponents *newComponents = [[NSDateComponents alloc]init];
        //    newComponents.timeZone = [NSTimeZone systemTimeZone];
        [newComponents setDay:[dateComponents day]];
        [newComponents setMonth:[dateComponents month]];
        [newComponents setYear:[dateComponents year]];
        [newComponents setHour:[timeComponents hour]];
        [newComponents setMinute:[timeComponents minute]];
        
        NSDate *combDate = [calendar dateFromComponents:newComponents];
        
        NSString *strDate = [Validation GetUTCDateFromDate:combDate];
        [dic setObject:strDate forKey:@"Utcdate"];
        
        [self performSegueWithIdentifier:ALARM_FRIEND_LIST_VC sender:dic];
    }
}

-(void)btnSendToGroupClicked:(id)sender{
    NSMutableDictionary *dic = [self checkValidation];
    if (dic!=nil) {
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:FORMAT_DATE];
        NSDate *date = [formatter dateFromString:[dic valueForKey:@"Alarmdate"]];
        [formatter setDateFormat:FORMAT_TIME];
        NSDate *time = [formatter dateFromString:[dic valueForKey:@"Alarmtime"]];
        NSCalendar *calendar = [NSCalendar currentCalendar];
        NSDateComponents *dateComponents = [calendar components:NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit fromDate:date];
        NSDateComponents *timeComponents = [calendar components:NSHourCalendarUnit|NSMinuteCalendarUnit fromDate:time];
        
        NSDateComponents *newComponents = [[NSDateComponents alloc]init];
        //    newComponents.timeZone = [NSTimeZone systemTimeZone];
        [newComponents setDay:[dateComponents day]];
        [newComponents setMonth:[dateComponents month]];
        [newComponents setYear:[dateComponents year]];
        [newComponents setHour:[timeComponents hour]];
        [newComponents setMinute:[timeComponents minute]];
        
        NSDate *combDate = [calendar dateFromComponents:newComponents];
        
        NSString *strDate = [Validation GetUTCDateFromDate:combDate];
        [dic setObject:strDate forKey:@"Utcdate"];
        
        [self performSegueWithIdentifier:ALARM_GRP_LIST_VC sender:dic];
    }
}

-(void)resetReceiver{
    
    [self.btnSendToFriend setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnSendToFriend.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:15]];
    [self.btnSendToFriend setTitle:@"Friend" forState:UIControlStateNormal];
    
    [self.btnSendToGroup setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnSendToGroup.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:15]];
    [self.btnSendToGroup setTitle:@"Group" forState:UIControlStateNormal];
    
    [self.btnSetForMe setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnSetForMe.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:15]];
    [self.btnSetForMe setTitle:@"Me" forState:UIControlStateNormal];
}

-(IBAction)btnSetAlarmForClicked:(id)sender{
    
    [self resetReceiver];
    
    UIButton *btn = (UIButton *)sender;
    
    if (btn.tag == 1) {
        //friends
        [self.btnSendToFriend setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        self.selectedReceiverType = 1;
    }
    else if (btn.tag == 2){
        //group
        [self.btnSendToGroup setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        self.selectedReceiverType = 2;
    }
    else if (btn.tag == 3 || btn.tag == 0){
        //me
        [self.btnSetForMe setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        self.selectedReceiverType = 3;
    }
    [self showAd:YES];
}

-(IBAction)btnNextClicked:(id)sender{
    if (self.selectedReceiverType == 1) {
        //friends
        [self btnSendToFriend_Clicked:nil];
    }
    else if (self.selectedReceiverType == 2){
        //group
        [self btnSendToGroupClicked:nil];
    }
    else if (self.selectedReceiverType == 3){
        //me
        [self btnDone_Clicked:nil];
    }

}

-(IBAction)btnNone_Clicked:(id)sender{
    if (self.viewAlertPicker.tag==101) {
        self.viewAlertPicker.tag=102;
        [dicValidated setObject:@"" forKey:@"Alertdatetime"];
        [dicValidated setObject:@"" forKey:@"SelectedRepeatOptionIndexpath"];
        self.lblRecurringAndAlertOptionTitle.text = @"Repeat";
        if ([self.dicSel allKeys]!=0) {
            if ([DataValidation checkNullString:[self.dicSel valueForKey:@"SelectedRepeatOptionIndexpath"]].length==0) {
                self.lastIndexPath = [NSIndexPath indexPathForItem:0 inSection:0];
            }
            else{
                self.lastIndexPath = [NSIndexPath indexPathForItem:[[self.dicSel valueForKey:@"SelectedRepeatOptionIndexpath"] intValue] inSection:0];
            }
        }
        else{
            self.lastIndexPath = [NSIndexPath indexPathForItem:0 inSection:0];
        }
        [self.arrAlertTime removeAllObjects];
        [self.arrAlertTime addObject:@"Daily"];
        [self.arrAlertTime addObject:@"Weekly"];
        [self.arrAlertTime addObject:@"Monthly"];
        [self.arrAlertTime addObject:@"Yearly"];
        [self.tblView reloadData];
        return;
    }
    
//  Set Reminder without alert and repet interval
/*    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:FORMAT_DATE];
    NSDate *date = [formatter dateFromString:[dicValidated valueForKey:@"Alarmdate"]];
    [formatter setDateFormat:FORMAT_TIME];
    NSDate *time = [formatter dateFromString:[dicValidated valueForKey:@"Alarmtime"]];
    NSLog(@"Alarmtime--> %@",[dicValidated valueForKey:@"Alarmtime"]);
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *dateComponents = [calendar components:NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit fromDate:date];
    NSDateComponents *timeComponents = [calendar components:NSHourCalendarUnit|NSMinuteCalendarUnit fromDate:time];
    
    NSDateComponents *newComponents = [[NSDateComponents alloc]init];
    //    newComponents.timeZone = [NSTimeZone systemTimeZone];
    [newComponents setDay:[dateComponents day]];
    [newComponents setMonth:[dateComponents month]];
    [newComponents setYear:[dateComponents year]];
    
    NSInteger hour = [timeComponents hour];
//
//  Commented by viral  17-03-2015
    if (hour < 10) {
        NSString *strHour = [NSString stringWithFormat:@"%ld",(long)[timeComponents hour]];
        if (strHour.length == 1) {
            hour = [[NSString stringWithFormat:@"0%@",strHour] integerValue];
        }
    }
//
    [newComponents setHour:hour];
    [newComponents setMinute:[timeComponents minute]];
*/
    NSDate *combDate = [Validation GetCombineDate:[dicValidated valueForKey:@"Alarmdate"] time:[dicValidated valueForKey:@"Alarmtime"]];
    
    [dicValidated setObject:@"" forKeyedSubscript:@"SelectedRepeatOptionIndexpath"];
    NSString *strId = [appDelegate InfoSaveAlarm:dicValidated];
    [dicValidated setObject:strId forKey:@"Aid"];
    [dicValidated setObject:@"" forKey:@"AlarmRepet"];
    [dicValidated setObject:@"404" forKey:@"StatusType"];
    
    UILocalNotification* n1 = [[UILocalNotification alloc] init];
    n1.fireDate = combDate;
    n1.alertBody = [NSString stringWithFormat:@"Reminder --> %@",self.tfAlarmName.text];
    n1.userInfo = dicValidated;
    n1.soundName = @"audio_local_notif.mp3";
    [[UIApplication sharedApplication] scheduleLocalNotification:n1];
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnSet_Clicked:(id)sender{
    
    if (self.viewAlertPicker.tag==102) {
        
        
        //      SET REMINDER WITH REPEAT INTERVAL
        NSDate *combDate = [Validation GetCombineDate:[dicValidated valueForKey:@"Alarmdate"] time:[dicValidated valueForKey:@"Alarmtime"]];
        
        [dicValidated setObject:[NSString stringWithFormat:@"%d",(int)self.lastIndexPath.row] forKeyedSubscript:@"SelectedRepeatOptionIndexpath"];
        NSString *strId = [appDelegate InfoSaveAlarm:dicValidated];
        [dicValidated setObject:strId forKey:@"Aid"];
        [dicValidated setObject:@"1" forKey:@"TypeID"];
        [dicValidated setObject:@"404" forKey:@"StatusType"];
        
        UILocalNotification* n1 = [[UILocalNotification alloc] init];
        [self setRepetInterval:n1];
        n1.fireDate = combDate;
        n1.alertBody = [NSString stringWithFormat:@"Reminder --> %@",self.tfAlarmName.text];
        n1.userInfo = dicValidated;
        n1.soundName = @"audio_local_notif.mp3";
        [[UIApplication sharedApplication] scheduleLocalNotification:n1];
        
        
        
        NSLog(@"SelectedAlertOptionIndexpath %d",(int)[DataValidation checkNullString:[dicValidated valueForKey:@"SelectedAlertOptionIndexpath"]].length);
        NSString *temp = [DataValidation checkNullString:[dicValidated valueForKey:@"SelectedAlertOptionIndexpath"]];

        NSDate *alertDate;
        //      IF ALERT OPTION SELECTED FROM SET ALERT LIST SO IT MUST NOT BE BLANK
        if (temp.length!=0) {

            NSIndexPath *indPath = [NSIndexPath indexPathForRow:[temp intValue] inSection:0];
            alertDate = [self getAlertDate:combDate indxPath:indPath];
            
            //      IF ALERT TIME IS FUTURE TIME THEN SET ALERT WITH REPEAT INTERVAL.
            if ([alertDate compare:[NSDate date]]==NSOrderedDescending){
                
                [dicValidated setObject:@"2" forKey:@"TypeID"];
                
                NSLog(@"Alertdatetime--> %@",[dicValidated valueForKey:@"Alertdatetime"]);
                
                UILocalNotification* n2 = [[UILocalNotification alloc] init];
                [self setRepetInterval:n2];
                n2.fireDate = alertDate;
                n2.alertBody = [NSString stringWithFormat:@"Reminder --> %@",self.tfAlarmName.text];
                n2.userInfo = dicValidated;
                n2.soundName = @"audio_local_notif.mp3";
                [[UIApplication sharedApplication] scheduleLocalNotification:n2];
            }
        }
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }

    NSDate *combDate = [Validation GetCombineDate:[dicValidated valueForKey:@"Alarmdate"] time:[dicValidated valueForKey:@"Alarmtime"]];
    
    NSDate *alertDate = [self getAlertDate:combDate indxPath:self.lastIndexPath];
    
    if ([alertDate compare:[NSDate date]]==NSOrderedAscending) {
        [AlertHandler alertTitle:ALERT message:@"Reminder time is less then alert time difference." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        return;
    }
    else if (self.viewAlertPicker.tag == 101){
        
        self.viewAlertPicker.tag = 102;
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:FORMAT_DATE_TIME];
        NSLog(@"[formatter stringFromDate:alertDate] %@",[formatter stringFromDate:alertDate]);
        [dicValidated setObject:[formatter stringFromDate:alertDate] forKey:@"Alertdatetime"];
        [dicValidated setObject:[NSString stringWithFormat:@"%d",(int)self.lastIndexPath.row] forKey:@"SelectedAlertOptionIndexpath"];
        self.lblRecurringAndAlertOptionTitle.text = @"Repeat";
        if ([self.dicSel allKeys]!=0) {
            if ([DataValidation checkNullString:[self.dicSel valueForKey:@"SelectedRepeatOptionIndexpath"]].length==0) {
                self.lastIndexPath = [NSIndexPath indexPathForItem:0 inSection:0];
            }
            else{
                self.lastIndexPath = [NSIndexPath indexPathForItem:[[self.dicSel valueForKey:@"SelectedRepeatOptionIndexpath"] intValue] inSection:0];
            }
        }
        else{
            self.lastIndexPath = [NSIndexPath indexPathForItem:0 inSection:0];
        }

        [self.arrAlertTime removeAllObjects];
        [self.arrAlertTime addObject:@"Daily"];
        [self.arrAlertTime addObject:@"Weekly"];
        [self.arrAlertTime addObject:@"Monthly"];
        [self.arrAlertTime addObject:@"Yearly"];
        [self.tblView reloadData];
        formatter = nil;
    }
}
-(NSDate *)getAlertDate:(NSDate *)combDate indxPath:(NSIndexPath *)indPath{
    NSDate *alertDate;
    switch (indPath.row) {
        case 0:
            alertDate = [combDate dateByAddingTimeInterval:-(5*60)];
            break;
        case 1:
            alertDate = [combDate dateByAddingTimeInterval:-(10*60)];
            break;
        case 2:
            alertDate = [combDate dateByAddingTimeInterval:-(15*60)];
            break;
        case 3:
            alertDate = [combDate dateByAddingTimeInterval:-(30*60)];
            break;
        case 4:
            alertDate = [combDate dateByAddingTimeInterval:-(60*60)];
            break;
        case 5:
            alertDate = [combDate dateByAddingTimeInterval:-(120*60)];
            break;
        case 6:
            alertDate = [combDate dateByAddingTimeInterval:-(1440*60)];
            break;
        case 7:
            alertDate = [combDate dateByAddingTimeInterval:-(10080*60)];
            break;
        default:
            break;
    }
    return alertDate;
}
-(void)setRepetInterval:(UILocalNotification *)localNotif{
    switch (self.lastIndexPath.row) {
        case 0:
            localNotif.repeatInterval = NSDayCalendarUnit;
            break;
        case 1:
            localNotif.repeatInterval = NSWeekCalendarUnit;
            break;
        case 2:
            localNotif.repeatInterval = NSMonthCalendarUnit;
            break;
        case 3:
            localNotif.repeatInterval = NSYearCalendarUnit;
            break;
        default:
            break;
    }
    [dicValidated setObject:[NSString stringWithFormat:@"%d",(int)self.lastIndexPath.row] forKey:@"SelectedRepeatOptionIndexpath"];
}
#pragma mark GeneralDelegate
-(void)displayAlarmSoundName:(NSDictionary *)selDic{
    NSLog(@"selDic %@",[selDic valueForKey:@"Name"]);
    if (strRecordedSoundUrl.length!=0 && [[NSFileManager defaultManager] fileExistsAtPath:strRecordedSoundUrl]) {
        [[NSFileManager defaultManager] removeItemAtPath:strRecordedSoundUrl error:nil];
        strRecordedSoundUrl = @"";
    }
    self.dicSelSound = selDic;
    [self.btnAlarmSound setTitle:[selDic valueForKey:@"Name"] forState:UIControlStateNormal];
    [self.btnAlarmSound.titleLabel setText:[selDic valueForKey:@"Name"]];
    [self showAd:YES];
}
-(void)displayAlarmRecordedSoundName:(NSString *)strAudioPath{
    if (strRecordedSoundUrl.length!=0 && [[NSFileManager defaultManager] fileExistsAtPath:strRecordedSoundUrl]) {
        [[NSFileManager defaultManager] removeItemAtPath:strRecordedSoundUrl error:nil];
        strRecordedSoundUrl = @"";
    }
    strRecordedSoundUrl = strAudioPath;
    [self.btnAlarmSound setTitle:@"Recorded" forState:UIControlStateNormal];
    [self.btnAlarmSound.titleLabel setText:@"Recorded"];
    [self showAd:YES];
}
-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);

	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];

    self.lblAlarmPeriod.textColor = UIColorFromRGB(0X616161);
    self.lblAlarmPeriod.font = [UIFont fontWithName:Font_Montserrat_Regular size:15];
    
    self.lblAlarmName.textColor = UIColorFromRGB(0X616161);
    self.lblAlarmName.font = [UIFont fontWithName:Font_Montserrat_Regular size:15];
    
    self.lblAlarmSound.textColor = UIColorFromRGB(0X616161);
    self.lblAlarmSound.font = [UIFont fontWithName:Font_Montserrat_Regular size:15];
    
    self.lblAlarmReceiverType.textColor = UIColorFromRGB(0X616161);
    self.lblAlarmReceiverType.font = [UIFont fontWithName:Font_Montserrat_Regular size:15];
    
    [self.btnDate setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnDate.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:15]];
    [self.btnDate setTitle:@"Date" forState:UIControlStateNormal];
    
    [self.btnTime setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnTime.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:15]];
    [self.btnTime setTitle:@"Time" forState:UIControlStateNormal];
    
    
    [self.btnAlarmSound setTitleColor:UIColorFromRGB(0Xff5252) forState:UIControlStateNormal];
    [self.btnAlarmSound.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:15]];
    
    self.tfAlarmName.textColor = UIColorFromRGB(0X00c2d9);
    self.tfAlarmName.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
    [self.tfAlarmName setValue:UIColorFromRGB(0X8a8a8a)	forKeyPath:@"_placeholderLabel.textColor"];

    [self resetReceiver];
    
/*
    self.lblPrivacy.textColor = UIColorFromRGB(0X616161);
    self.lblPrivacy.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    self.lblSetTimePeriod.textColor = UIColorFromRGB(0X616161);
    self.lblSetTimePeriod.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    self.lblRecipientCanOnly.textColor = UIColorFromRGB(0X616161);
    self.lblRecipientCanOnly.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    
    self.lblCharCounter.font = [UIFont fontWithName:Font_Montserrat_Regular size:10];
    
    [self resetPrivacy];
    [self resetTimePeriod];
    
    if ([[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue]) {
        [self hidePrivacyView];
    }
    else{
        [self showPrivacyView];
        if (self.selectedPrivacy == 1) {
            [self showTimePeriodView];
        }
        else{
            [self.btnPublic setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
            [self hideTimePeriodView];
        }
    }
*/
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (!self.viewDtPicker.isHidden) {
        self.viewDtPicker.hidden = YES;
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self showAd:YES];
    [self.tfAlarmName resignFirstResponder];
    return YES;
}

#pragma mark UITABLEVIEWDELEGATE
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrAlertTime.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
    
    cell.textLabel.text = [self.arrAlertTime objectAtIndex:indexPath.row];
    if ([indexPath compare:self.lastIndexPath] == NSOrderedSame)
    {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    else
    {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.lastIndexPath = indexPath;
    
    [tableView reloadData];
}
@end
