//
//  SelectBlabFromAlarmVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworkingDataTransaction.h"
#import "RecordOptionBannerCell.h"

@interface SelectBlabFromAlarmVC : UIViewController<UITableViewDelegate, UITableViewDataSource,AFNetworkingDataTransactionDelegate>

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;
@property (nonatomic, strong) IBOutlet UITableView          *tblData;
@property (nonatomic, strong) NSArray                       *arrData;

@property (nonatomic, strong) AFNetworkingDataTransaction   *request;
@property (nonatomic, strong) NSTimer                       *timer;

@end
