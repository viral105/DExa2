//
//  AlarmMainVcCell.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/30/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "AlarmMainVcCell.h"
#define xPointAMPM5Char 115
#define xPointAMPM4Char 105

@implementation AlarmMainVcCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
    self.viewBack.layer.cornerRadius = 5.0f;
    self.lblTime.textColor = UIColorFromRGB(0X00c2d9);
    self.lblAMPM.textColor = UIColorFromRGB(0X00c2d9);
    self.lblDate.textColor = UIColorFromRGB(0X616161);
    self.lblAlarmName.textColor = UIColorFromRGB(0X00c2d9);
    self.lblCreatedBy.textColor = UIColorFromRGB(0Xaab2bd);
    self.lblCreatedByUserName.textColor = UIColorFromRGB(0X00c2d9);
    
    [Validation setCorners:self.imgViewUser];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setUI{
    

    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:FORMAT_DATE];
    NSDate *yourDate = [formatter dateFromString:[self.dicSel valueForKey:@"Alarmdate"]];
    [formatter setDateFormat:@"EEEE"];
    NSString *dayName = [formatter stringFromDate:yourDate];
    
    [formatter setDateFormat:@"dd/MM/yyyy"];
    NSString *strToDisplay = [formatter stringFromDate:yourDate];
    self.lblDate.text = [NSString stringWithFormat:@"%@ - %@",dayName,strToDisplay];
/*
    NSCalendar* calender = [NSCalendar currentCalendar];
    NSDateComponents* component = [calender components:NSWeekdayCalendarUnit fromDate:yourDate];
 
    self.lblDay.text = [NSString stringWithFormat:@"%d",(int)[component weekday]];
*/
    self.lblAlarmName.text = [self.dicSel valueForKey:@"Alarmname"];
    NSLog(@"self.dicSel --> %@",[self.dicSel valueForKey:@"Alarmtime"]);
    
    //set alarm time
    NSArray *arr = [[self.dicSel valueForKey:@"Alarmtime"] componentsSeparatedByString:@" "];
    self.lblTime.text = [arr objectAtIndex:0];
    CGSize size = CGSizeMake(self.lblTime.frame.size.width+50, self.lblTime.frame.size.height);
    CGRect text =  [self.lblTime.text boundingRectWithSize:size
                                                   options:NSStringDrawingUsesLineFragmentOrigin
                                                attributes:@{NSFontAttributeName:self.lblTime.font}
                                                   context:nil];
    
    self.lblTime.frame = CGRectMake(self.lblTime.frame.origin.x, self.lblTime.frame.origin.y, size.width, self.lblTime.frame.size.height);
//    if (self.lblTime.text.length==5) {
        self.lblAMPM.frame = CGRectMake(self.lblTime.frame.origin.x+text.size.width+5, self.lblTime.frame.origin.y, self.lblTime.frame.size.width, self.lblTime.frame.size.height);
//    }
//    else{
//        self.lblAMPM.frame = CGRectMake(xPointAMPM4Char, self.lblTime.frame.origin.y, self.lblTime.frame.size.width, self.lblTime.frame.size.height);
//    }
    self.lblAMPM.text = [arr objectAtIndex:1];
    if ([[self.dicSel valueForKey:@"IsFromRequest"] boolValue]) {
        self.btnEdit.hidden = YES;
        CGRect frame = self.btnPlay.frame;
        frame.origin.x  = 221;
        self.btnPlay.frame = frame;
    }
    else{
        CGRect frame = self.btnEdit.frame;
        frame.origin.x  = 221;
        self.btnEdit.frame = frame;
        frame = self.btnPlay.frame;
        frame.origin.x = 183;
        self.btnPlay.frame = frame;
        self.btnEdit.hidden = NO;
    }
    self.lblCreatedByUserName.text = [self.dicSel valueForKey:@"Createdby"];
//    CGSize size = [self.lblCreatedByUserName.text sizeWithAttributes:@{NSFontAttributeName:[self.lblCreatedByUserName font]}];
    size = [self.lblCreatedByUserName.text sizeWithAttributes:@{NSFontAttributeName:[self.lblCreatedByUserName font]}];
    if (size.width>150) {
        self.lblCreatedByUserName.frame = CGRectMake(self.lblCreatedByUserName.frame.origin.x, self.lblCreatedByUserName.frame.origin.y, 150, self.lblCreatedByUserName.frame.size.height);
        self.imgViewUser.frame = CGRectMake(self.lblCreatedByUserName.frame.origin.x+self.lblCreatedByUserName.frame.size.width+5, self.imgViewUser.frame.origin.y, self.imgViewUser.frame.size.width, self.imgViewUser.frame.size.height);
    }
    else{
        self.lblCreatedByUserName.frame = CGRectMake(self.lblCreatedByUserName.frame.origin.x, self.lblCreatedByUserName.frame.origin.y, size.width, self.lblCreatedByUserName.frame.size.height);
        self.imgViewUser.frame = CGRectMake(self.lblCreatedByUserName.frame.origin.x+self.lblCreatedByUserName.frame.size.width+5, self.imgViewUser.frame.origin.y, self.imgViewUser.frame.size.width, self.imgViewUser.frame.size.height);
    }
    
    self.imgViewUser.imageURL = [NSURL URLWithString:[self.dicSel valueForKey:@"Createdbyphotopath"]];
}
-(IBAction)btnEdit_Clicked:(id)sender{
    [self.delegate editAlarm:self.indPathSel];
}
-(IBAction)btnDelete_Clicked:(id)sender{
    [self.delegate deleteAlarm:self.indPathSel];
}

-(IBAction)btnPlay_Clicked:(id)sender{
    [self.delegate PlayAlarm:self.indPathSel];
}


-(CGSize)getSize:(NSString *)text widthDeduct:(int)width{
    text = [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    CGRect textRect = [text boundingRectWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width-width, 20000.0f) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont fontWithName:@"AvenirNext-Medium" size:16]} context:nil];
    
    CGSize size = textRect.size;
    
    NSLog(@"%@",NSStringFromCGSize(size));
    return size;
}
@end
