//
//  AlarmMainVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AlarmMainVcCell.h"
#import "SetAlarmVC.h"
#import "AlarmRequestListVC.h"

@interface AlarmMainVC : UIViewController<UITableViewDataSource,UITableViewDelegate,AlarmMainVcCellDelegate,UIAlertViewDelegate,AlarmRequestListVCDelegate>{
    
}
@property (strong, nonatomic) IBOutlet UITableView *tblData;
@property (strong, nonatomic) IBOutlet UIButton *btnMenu;
@property (strong, nonatomic) IBOutlet UILabel *lblTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblNoAlarmFound;
@property (nonatomic, strong) IBOutlet  UILabel *lblTotalNotifCount;
@property (nonatomic, assign) BOOL isBackFromSentReceive;
-(void)alarmRequestArrived;
@end
