//
//  AlarmFriendListVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 2/2/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "AlarmFriendListVC.h"
#import "UserCell.h"
#import "NotifOptionVC.h"
#import "CaptureImageVC.h"
#import "MBProgressHUD.h"
#import "CreateGrpWithSelected.h"
#import "ASIFormDataRequest.h"

//#define BASE_URL			@"http://wwhhaazzuupp.com/api/"
#define IS_SELECTED			@"is_selected"
#define ScrollHeight		30
#define SelectedSection		@"selectedSection"
#define SelectedRow			@"selectedRow"

@interface AlarmFriendListVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
    NSMutableArray *arrTemp;
}
@property (nonatomic,strong) NSMutableArray *arrTemp;

@end

@implementation AlarmFriendListVC
@synthesize arrTemp;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self performSelector:@selector(LoadViewSetting)];
	
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
    self.progress = [[UIProgressView alloc] initWithFrame:CGRectZero] ;
    [self.progress setProgressViewStyle: UIProgressViewStyleBar];
    
    [self.progress setFrame:CGRectMake(([[UIScreen mainScreen]bounds].size.height-160)/2,181,160,10)];
    [self.view addSubview:self.progress];
	self.arrData = [[NSMutableArray alloc] init];
	self.sections = [[NSMutableDictionary alloc] init];
    self.arrTemp = [NSMutableArray new];

    self.isNotifSendToAll = NO;
	[self.tblData registerNib:[UINib nibWithNibName:@"UserCell" bundle:nil] forCellReuseIdentifier:@"cellIdentifier"];
	
	self.pageCounter = 1;
    
    self.isReloadData = YES;
    
    NSLog(@"self.dicSel--> %@",self.dicSel);
}
-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
    
	appDelegate.currentVc = self;
    
    [Validation removeAdviewFromSuperView];
    
    if (self.btnNext.hidden) {
        [self.view addSubview:[Validation sharedBannerView]];
        [Validation ResizeViewForAds];
    }
    if (self.isReloadData) {
        self.isReloadData = NO;
        [HUD show:YES];
        
        [self performSelectorInBackground:@selector(getMyFriendList) withObject:nil];
    }
}

-(void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
    
	[Validation increaseTableSize];
    appDelegate.isShouldShowReplyPopUp = NO;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    
    [self.btnSelectAll setTitleColor:UIColorFromRGB(0X5d6970) forState:UIControlStateNormal];
    [self.btnSelectAll.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Bold size:16]];
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)btnBack_Clicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)getMyFriendList{
    
	if (self.request !=nil) {
		self.request = nil;
	}
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"100"],KeyValue,@"PageSize",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_MYFRIENDS_LIST withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:2];
    
	strUrl = nil;
}

-(void)SetSectionArrayToLoadData{
    
	BOOL  found = NO;
    
	for (NSDictionary *user in self.arrData)
    {
		NSString *strName = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[user objectForKey:NAME]]];
		
		if (strName.length == 0) {
			strName = [NSString stringWithFormat:@"%@",[user objectForKey:USER_NAME]];
		}
		strName = [strName lowercaseString];
		
        NSString *c = [strName substringToIndex:1];
		
        found = NO;
		
        for (NSString *str in [self.sections allKeys])
        {
            if ([str isEqualToString:c])
            {
                found = YES;
				[[self.sections objectForKey:[strName substringToIndex:1]] addObject:user];
            }
        }
		
        if (!found)
        {
            [self.sections setValue:[[NSMutableArray alloc] init] forKey:c];
			[[self.sections objectForKey:[strName substringToIndex:1]] addObject:user];
        }
    }
	
	for (NSString *key in [self.sections allKeys])
    {
        [[self.sections objectForKey:key] sortUsingDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:NAME ascending:YES]]];
    }
	
	[self.sections setValue:[[NSMutableArray alloc] init] forKey:@"zoo"];

	//NSLog(@"Sections = %@",self.sections);
	
	[self.tblData reloadData];
}

-(IBAction)btnSelectAll:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    [UIView beginAnimations:@"moveDown" context:nil];
    [UIView setAnimationDuration:0.5];
    self.tblData.frame = CGRectMake(0, 100, 320, DEVICE_HEIGHT-100);
    [UIView commitAnimations];
    
    [[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self.arrSelected removeAllObjects];
    [self showSelectedUsersOnTop];
    
    NSArray *arrKeyName = [NSArray arrayWithArray:(NSArray *)[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)]];
    NSLog(@"key name = %@",arrKeyName);
    
    NSMutableDictionary *sectionToMute = [NSMutableDictionary dictionaryWithDictionary:self.sections];
    if (!self.isNotifSendToAll) {
        
        [btn setImage:[UIImage imageNamed:Btn_selectedUserIndication] forState:UIControlStateNormal];
        self.viewSearch.hidden = YES;
        if (self.arrSelected==nil) {
            self.arrSelected = [[NSMutableArray alloc] init];
        }
        for (int i =0; i<arrKeyName.count; i++) {
            //section loop
            int count = 0;
            NSArray *arrRow = [sectionToMute valueForKey:[arrKeyName objectAtIndex:i]];
            for (int y = 0; y< arrRow.count; y++) {
                NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arrRow objectAtIndex:y]];
                
                if (![[NSString stringWithFormat:@"%@",[dic1 valueForKey:IS_USER_BLOCKED]] boolValue]) {
//                    if ([[dic1 valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
//                    }
//                    else{
                        [dic1 setValue:@"1" forKey:IS_SELECTED];
                        [[self.sections valueForKey:[arrKeyName objectAtIndex:i]] replaceObjectAtIndex:count withObject:dic1];
                        [dic1 setValue:[NSNumber numberWithInteger:i] forKey:SelectedSection];
                        [dic1 setValue:[NSNumber numberWithInteger:count] forKey:SelectedRow];
                        [self.arrSelected addObject:dic1];
//                    }
                }
                
                dic1 = nil;
                
                count ++;
            }
        }
        
        [self.tblData reloadData];
//        self.tblData.alpha = 0.5;
        self.isNotifSendToAll = YES;
        self.btnNext.hidden= NO;
        [Validation removeAdviewFromSuperView];
        NSLog(@"count = %d",(int)[self.arrSelected count]);
    }
    else{
        
        [btn setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication] forState:UIControlStateNormal];
        self.viewSearch.hidden = NO;
        
        for (int i =0; i<arrKeyName.count; i++) {
            //section loop
            int count = 0;
            NSArray *arrRow = [self.sections valueForKey:[arrKeyName objectAtIndex:i]];
            for (int y = 0; y< arrRow.count; y++) {
                NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arrRow objectAtIndex:y]];
                if ([[dic1 valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
                    [dic1 setValue:@"0" forKey:IS_SELECTED];
                    [[self.sections valueForKey:[arrKeyName objectAtIndex:i]] replaceObjectAtIndex:count withObject:dic1];
                    [dic1 setValue:[NSNumber numberWithInteger:i] forKey:SelectedSection];
                    [dic1 setValue:[NSNumber numberWithInteger:count] forKey:SelectedRow];
                }
                else{
                    
                }
                dic1 = nil;
                count ++;
            }
        }
        [self.arrSelected removeAllObjects];
        [self.tblData reloadData];
        self.tblData.alpha = 1.0;
        self.isNotifSendToAll = NO;
        
        self.tblData.frame = CGRectMake(0, 100, 320, DEVICE_HEIGHT-100);
        self.btnNext.hidden = TRUE;
        [self.view addSubview:[Validation sharedBannerView]];
    }
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 1) {
        //unfrind user
        if (buttonIndex == alertView.cancelButtonIndex) {
            
        }
        else{
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:self.selectedUserIndexPath.section]] objectAtIndex:self.selectedUserIndexPath.row]];
            
            
            
            
            [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:self.selectedUserIndexPath.section]] removeObjectAtIndex:self.selectedUserIndexPath.row];
            
            if ([[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:self.selectedUserIndexPath.section]] count] == 0) {
                NSLog(@"count = %@",[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:self.selectedUserIndexPath.section]);
                [self.sections removeObjectForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:self.selectedUserIndexPath.section]];
                
            }
            
            
            int index = -1;
            if (self.arrSelected.count >0) {
                index = (int)[self.arrSelected indexOfObject:dic];
                NSLog(@"%d",index);
            }
            if (index > -1 && index < self.arrData.count) {
                [self.arrSelected removeObjectAtIndex:index];
            }
            
            [self.tblData reloadData];
            
            [[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
            
            [self showSelectedUsersOnTop];
            
            
            if (self.request !=nil) {
                self.request = nil;
            }
            NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                                  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                                  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dic valueForKey:USER_ID] ],KeyValue,@"FriendID",KeyName, nil],@"2",
                                  nil];
            
            NSString *strUrl = [WebServiceContainer getServiceURL:UNFRIEND_A_FRIEND withParameters:nil];
            self.request = [AFNetworkingDataTransaction sharedManager];
            [self.request SetCallForURL:strUrl WithDic:dic1 isAddHeader:TRUE];
            if (self.request._currentRequest == nil) {
                [HUD hide:YES];
            }
            else{
                [self.request setDelegate:self];
                [self.request setTag:5];
            }
//            [self.request setDelegate:self];
//            [self.request setTag:5];
            strUrl = nil;
            
            
        }
    }
}

-(void)btnUnfriendClicked:(id)sender{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tblData];
    NSIndexPath *indexPath = [self.tblData indexPathForRowAtPoint:buttonPosition];
    NSLog(@"indexpath = %@",indexPath);
    self.selectedUserIndexPath = indexPath;
    
    
    [AlertHandler alertTitle:CONFIRM message:@"Are you sure you want to unfriend selected friend?" delegate:self tag:1 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
    
}

-(IBAction)btnNextClicked:(id)sender{
	[Validation CancelOnGoingRequests:self.request];
    
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
	self.request = nil;
    
    NSLog(@"arrSelected => %@",self.arrSelected);
    if (self.arrSelected.count!=0) {
        NSFileManager *fm = [NSFileManager defaultManager];
        if ([fm fileExistsAtPath:[self.dicSel valueForKey:@"SoundPath"]]) {
            [HUD show:YES];
            [self callSendAlarmRequest:@"Recording"];
        }
        else{
            [HUD show:YES];
            [self callSendAlarmRequest:@""];
        }
    }
    else{
        [AlertHandler alertTitle:ALERT message:@"Please select any one friend." delegate:self tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
}


-(void)callSendAlarmRequest:(NSString*)recordedSoundId{
    if (self.request !=nil) {
        self.request = nil;
    }
/*

    if (recordedSoundId.length==0) {
        recordedSoundId = [self.dicSel valueForKey:@"RandomSoundID"];
    }
    NSLog(@"self.arrSelected--> %@ %@",self.arrSelected,[[self.arrSelected objectAtIndex:0] valueForKey:USER_ID]);
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"FromUserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[self.arrSelected valueForKey:USER_ID] componentsJoinedByString:@"|"]],KeyValue,@"ToUserID",KeyName, nil],@"2",
//                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",[[[self.arrSelected objectAtIndex:0] valueForKey:USER_ID] intValue]],KeyValue,@"ToUserID",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"Utcdate"]],KeyValue,@"UtcDateTime",KeyName, nil],@"3",
//                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"GroupIDs",KeyName, nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",recordedSoundId],KeyValue,@"RandomSoundID",KeyName, nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@""],KeyValue,@"FileData",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"Alarmname"]],KeyValue,@"AlarmName",KeyName, nil],@"6",
                         nil];
    
    NSLog(@"sendMessage => dic => %@",dic);
    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_ALARM_REQUEST withParameters:nil];
    //    self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    //    self.request.delegate = self;
    //    self.request.tag = 4;
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    [self.request setDelegate:self];
    [self.request setTag:5];
    strUrl = nil;
*/
    
    NSString *strUrl = [NSString stringWithFormat:@"%@%@",BASE_URL,SEND_ALARM_REQUEST];
    
    self.requestAsi = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:strUrl]];
    
    [self.requestAsi setDelegate:self];
    
    [self.requestAsi addRequestHeader:@"userid" value:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]];
    NSString *strT1 = [Validation GetUTCDate];
    [self.requestAsi addRequestHeader:@"T1" value:strT1];
    [self.requestAsi addRequestHeader:@"T2" value:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE]];
    
//    NSString *strName = [DataValidation checkNullString:self.tfName.text];
    [self.requestAsi setPostValue:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]] forKey:@"FromUserID"];
    
    [self.requestAsi setPostValue:[NSString stringWithFormat:@"%@",[[self.arrSelected valueForKey:USER_ID] componentsJoinedByString:@"|"]] forKey:@"ToUserID"];
    [self.requestAsi setPostValue:[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"Utcdate"]] forKey:@"UtcDateTime"];
    
    if (recordedSoundId.length==0) {
        [self.requestAsi setPostValue:[self.dicSel valueForKey:@"RandomSoundID"] forKey:@"RandomSoundID"];
        [self.requestAsi setPostValue:[NSString stringWithFormat:@""] forKey:@"FileData"];
    }
    else{
        [self.requestAsi setPostValue:@"0" forKey:@"RandomSoundID"];
        NSString *strPath = [NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]];
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:strPath]) {
            NSLog(@"file exist");
        }
        NSMutableData *data = [NSMutableData dataWithContentsOfFile:strPath];
        [self.requestAsi addData:data withFileName:@"userSound.m4a" andContentType:@"multipart/form-data" forKey:@"FileData"];
    }
    [self.requestAsi setPostValue:[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"Alarmname"]] forKey:@"AlarmName"];

/*
    self.progress.progress = 0.0;
    self.progress.hidden = YES;
    [self.requestAsi setUploadProgressDelegate:self.progress];
    [self.requestAsi setShouldContinueWhenAppEntersBackground:YES];
    
    NSString *strPath = [NSString stringWithFormat:@"%@",self.strFilePath];
    
    if ([fm fileExistsAtPath:strPath]) {
        NSLog(@"file exist");
    }
    NSMutableData *data = [NSMutableData dataWithContentsOfFile:strPath];
    [self.requestAsi addData:data withFileName:@"userSound.m4a" andContentType:@"multipart/form-data" forKey:@"SoundData"];
*/
    self.requestAsi.tag = 3;
    [self.requestAsi startAsynchronous];

}
-(void)StartUploadingAudioFile{
    //   [Validation showLoadingIndicatorInView:self.view];
    [HUD show:YES];
    
    [self uploadFile];
    
}
-(void)uploadFile{
    
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:[self.dicSel valueForKey:@"SoundPath"]]) {
        NSLog(@"file exists");
    }
    
    //	NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
    //						  [NSDictionary dictionaryWithObjectsAndKeys:self.strFilePath,KeyValue,@"SoundData",KeyName, nil],@"1",
    //						  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Name",KeyName, nil],@"2",
    //						  [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SoundMasterID",KeyName, nil],@"3",
    //						  [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SoundSubMasterID",KeyName, nil],@"4",
    //						  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"5",
    //						  [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"Gender",KeyName, nil],@"6",
    //						  [NSDictionary dictionaryWithObjectsAndKeys:(self.isPrivate)?@"true":@"false",KeyValue,@"IsPrivate",KeyName, nil],@"7",
    //						  nil];
    NSString *strUrl = [NSString stringWithFormat:@"%@",UPLOAD_AUDIO_FILE];
    //	self.request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    //	self.request.delegate = self;
    //    [self.request setUploadProgressDelegate:self.progress];
    //	[self.request setDelegate:self];
    //
    //	self.request.tag = 1;
    //	strUrl = nil;
    //
    //    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(setProgressFORHUD:) userInfo:nil repeats:YES];
    
    self.requestAudioUpload = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:strUrl]];
    
    [self.requestAudioUpload setDelegate:self];
    
    [self.requestAudioUpload addRequestHeader:@"userid" value:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]];
    NSString *strT1 = [Validation GetUTCDate];
    [self.requestAudioUpload addRequestHeader:@"T1" value:strT1];
    [self.requestAudioUpload addRequestHeader:@"T2" value:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE]];
    
    [self.requestAudioUpload setPostValue:@"" forKey:@"Name"];
    [self.requestAudioUpload setPostValue:@"0" forKey:@"SoundMasterID"];
    [self.requestAudioUpload setPostValue:@"0" forKey:@"SoundSubMasterID"];
    [self.requestAudioUpload setPostValue:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]] forKey:@"UserID"];
    [self.requestAudioUpload setPostValue:@"0" forKey:@"Gender"];
    [self.requestAudioUpload setPostValue:@"false" forKey:@"IsPrivate"];
    
    
    self.progress.progress = 0.0;
    self.progress.hidden = YES;
    [self.requestAudioUpload setUploadProgressDelegate:self.progress];
    [self.requestAudioUpload setShouldContinueWhenAppEntersBackground:YES];
    
    NSString *strPath = [NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]];
    
    if ([fm fileExistsAtPath:strPath]) {
        NSLog(@"file exist");
    }
    NSMutableData *data = [NSMutableData dataWithContentsOfFile:strPath];
    [self.requestAudioUpload addData:data withFileName:@"userSound.m4a" andContentType:@"multipart/form-data" forKey:@"SoundData"];
    
    self.requestAudioUpload.tag = 1;
    [self.requestAudioUpload startAsynchronous];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(setProgressFORHUD:) userInfo:nil repeats:YES];
    
}
- (void)setProgressFORHUD:(float)progress {
    NSLog(@"actual progress = %f",self.progress.progress);
    // int prog = (round(self.progress.progress*100));
    [HUD setProgress:self.progress.progress];
    if (self.progress.progress == 1.0) {
        [self.timer invalidate];
        HUD.mode = MBProgressHUDModeIndeterminate;
        HUD.labelText = @"";
    }
}
-(IBAction)btnGoToGroupClicked:(id)sender{
    //	[Validation CancelOnGoingRequests:self.request];
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
	self.request = nil;
	[self performSegueWithIdentifier:GROUP_LIST_VC sender:nil];
}

#pragma mark  UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [[self.sections allKeys] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	return 45;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
	NSString *strChar = [[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section];
	UIView *view = [[UIView alloc] init];
	[view setBackgroundColor:[UIColor clearColor]];
	
	if (![strChar isEqualToString:@"zoo"]) {
		
		UILabel *lblTitle = [[UILabel alloc] init];
		[lblTitle setBackgroundColor:[Validation getColorForAlphabet:strChar]];
		lblTitle.frame = CGRectMake(tableView.frame.size.width-50, 5, 40, 40);
		[lblTitle setTextColor:[UIColor whiteColor]];
		lblTitle.textAlignment = NSTextAlignmentCenter;
		[lblTitle setText:[strChar uppercaseString]];
		[Validation setCorners:lblTitle];
		[view addSubview:lblTitle];
		lblTitle = nil;
	}
	return view;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 90;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section]] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	//NSLog(@"%@",[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row]);
	
	NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row]];
    
	UserCell *cell = (UserCell *)[tableView dequeueReusableCellWithIdentifier:@"cellIdentifier"];
    cell.isUserSelectionInView = YES;
	cell.ProfileImg.image = nil;
    cell.ProfileImg.imageURL = nil;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
	[cell setBoxValuesWithData:dic];
	[cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
	[cell.imgFriendshipStatus setHidden:TRUE];
    
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_USER_BLOCKED]] boolValue]) {
        [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_User_Blocked]];
        cell.imgFriendshipStatus.hidden = FALSE;
        cell.btnUserBlocked.hidden = YES;
    }
    else{
        if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
            [cell.imgFriendshipStatus setHidden:FALSE];
        }
        else{
            [cell.imgFriendshipStatus setHidden:TRUE];
        }
        
        if ([self.arrSelected count]==0) {
            [cell.imgFriendshipStatus setHidden:TRUE];
            [dic setValue:@"0" forKey:IS_SELECTED];
            [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
        }
        else{
            NSLog(@"arrselected cnt %d %d",(int)[self.arrSelected count],(int)indexPath.row);
            for (int i=0; i<[self.arrSelected count]; i++) {
                NSDictionary *selDic = [self.arrSelected objectAtIndex:i];
                if ([[dic valueForKey:@"ID"] intValue] == [[selDic valueForKey:@"ID"] intValue]) {
                    NSLog(@"seldic name %@",[selDic valueForKey:NAME]);
                    if ([[selDic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
                        NSLog(@"seldic name %@ flag 1",[selDic valueForKey:NAME]);
                        [cell.imgFriendshipStatus setHidden:FALSE];
                        [dic setValue:@"1" forKey:IS_SELECTED];
                        [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
                    }
                    else{
                        NSLog(@"seldic name %@ flag 0",[selDic valueForKey:NAME]);
                        [cell.imgFriendshipStatus setHidden:TRUE];
                        [dic setValue:@"0" forKey:IS_SELECTED];
                        [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
                    }
                    break;
                }
                else{
                    NSLog(@"seldic name %@ flag 0 id not found",[dic valueForKey:NAME]);
                    [cell.imgFriendshipStatus setHidden:TRUE];
                    [dic setValue:@"0" forKey:IS_SELECTED];
                    [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
                }
            }
        }
    }
	
    cell.btnUnfriend.hidden = NO;
    [cell.btnUnfriend addTarget:self action:@selector(btnUnfriendClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    
    cell.imgViewFriendType.hidden = NO;
    switch ([[dic valueForKey:@"FriendType"] intValue]) {
        case 0:
            cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_blabeey.png"];
            break;
        case 1:
            cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_fb.png"];
            break;
        case 2:
            cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_contacts.png"];
            break;
            
        default:
            break;
    }
	dic = nil;
	
	if (indexPath.section == self.sections.count) {
		if (indexPath.row == [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] count]) {
			self.pageCounter++;
			[HUD show:YES];
			[self performSelectorInBackground:@selector(getMyFriendList) withObject:nil];
		}
	}
	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	
//    if (!self.isNotifSendToAll) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row]];
        
        
        if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_USER_BLOCKED]] boolValue]) {
            [AlertHandler alertTitle:MESSAGE message:@"You have blocked this user." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        }
        else{
            UserCell *cell = (UserCell *)[tableView cellForRowAtIndexPath:indexPath];
            
            if (self.arrSelected==nil) {
                self.arrSelected = [[NSMutableArray alloc] init];
            }
            
            int index = -1;
            if (self.arrSelected.count >0) {
                index = (int)[self.arrSelected indexOfObject:dic];
                NSLog(@"%d",index);
            }
            
            
            if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
                //so deselect it
                [dic setValue:@"0" forKey:IS_SELECTED];
                [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
                cell.imgFriendshipStatus.hidden = TRUE;
                self.isNotifSendToAll = NO;
                self.viewSearch.hidden = NO;
                [self.btnSelectAll setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication] forState:UIControlStateNormal];
                if (index > -1 && index < self.arrData.count) {
                    [self.arrSelected removeObjectAtIndex:index];
                }
                else{
                    for (int i=0; i<self.arrSelected.count; i++) {
                        NSDictionary *selDic = [self.arrSelected objectAtIndex:i];
                        if ([[selDic valueForKey:@"ID"] intValue]==[[dic valueForKey:@"ID"] intValue]) {
                            [self.arrSelected removeObjectAtIndex:i];
                            break;
                        }
                    }
                }
                [[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                
            }
            else{
                [dic setValue:@"1" forKey:IS_SELECTED];
                [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
                cell.imgFriendshipStatus.hidden = FALSE;
                [dic setValue:[NSNumber numberWithInteger:indexPath.section] forKey:SelectedSection];
                [dic setValue:[NSNumber numberWithInteger:indexPath.row] forKey:SelectedRow];
                [self.arrSelected addObject:dic];
            }
            
            [self showSelectedUsersOnTop];
            NSLog(@"%@",self.sections);
            
        }
        
//    }
    
}

-(void)showSelectedUsersOnTop{
	
	if (self.arrSelected.count>0) {
		
		[UIView beginAnimations:@"moveUp" context:nil];
        //[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.5];
        //		self.tblData.frame = CGRectMake(0, 68+ScrollHeight+5, 320, DEVICE_HEIGHT-(68+ScrollHeight+8));
        self.tblData.frame = CGRectMake(0, 100+ScrollHeight+5, 320, DEVICE_HEIGHT-(100+ScrollHeight+8));
		
		[UIView commitAnimations];
		
		if (self.scrollContainer == nil) {
            //			self.scrollContainer = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 68, 320, ScrollHeight)];
            self.scrollContainer = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 100, 320, ScrollHeight)];
			[self.view addSubview:self.scrollContainer];
			[self.scrollContainer setShowsHorizontalScrollIndicator:FALSE];
			[self.scrollContainer setShowsVerticalScrollIndicator:FALSE];
		}
		
		float xStart = 10;
        //      float scrollPosition = 10;
		for (int i=0; i<self.arrSelected.count; i++) {
			
			float X = 5;
			UIView *view = [[UIView alloc] init];
			UILabel *lblName = [[UILabel alloc] init];
			UIButton *btnRemove = [UIButton buttonWithType:UIButtonTypeCustom];
			
			lblName.font = [UIFont fontWithName:Font_Montserrat_Regular size:14];
			lblName.textColor = [UIColor whiteColor];
			
			NSDictionary *dic = [self.arrSelected objectAtIndex:i];
			NSString *strName = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:NAME]]];
			if (strName.length == 0) {
				strName = [NSString stringWithFormat:@"%@",[dic valueForKey:USER_NAME]];
			}
			
			CGSize size = CGSizeMake(1000, 46);
			CGRect text = [strName boundingRectWithSize:size
                                                options:NSStringDrawingUsesLineFragmentOrigin
                                             attributes:@{NSFontAttributeName:lblName.font}
                                                context:nil];
            
			size = text.size;
			view.frame = CGRectMake(xStart, 0, size.width+30, ScrollHeight);
            //			view.backgroundColor = [Validation getColorForAlphabet:[strName substringToIndex:1]];
			view.backgroundColor = [Validation getColorForAlphabet:strName];
			
			lblName.text = strName;
			lblName.frame = CGRectMake(X, 0, size.width+4, ScrollHeight);
			
			btnRemove.frame = CGRectMake(X, 0, view.frame.size.width-(X*2), ScrollHeight);
			[btnRemove setTitle:@"x" forState:UIControlStateNormal];
			[btnRemove setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
			btnRemove.tag = i;
			[btnRemove addTarget:self action:@selector(removeSelectedUserFromList:) forControlEvents:UIControlEventTouchUpInside];
			[view addSubview:lblName];
			[view addSubview:btnRemove];
			[self.scrollContainer addSubview:view];
			
			view.tag = i;
			lblName = nil;
			btnRemove = nil;
			
            //			if (i==self.arrSelected.count-1) {
            //
            //                scrollPosition = view.frame.size.width+5;
            //
            //			}
            //            else{
            //                self.scrollContainer.contentOffset = CGPointMake(xStart, self.scrollContainer.contentOffset.y);
            //            }
			xStart += (view.frame.size.width+5);
			
		}
		
		self.scrollContainer.contentSize = CGSizeMake(xStart, ScrollHeight);
        [UIView beginAnimations:@"ScrollToEnd" context:nil];
        //[UIView setAnimationBeginsFromCurrentState:YES];
        [UIView setAnimationDuration:0.5];
        self.scrollContainer.contentOffset = CGPointMake((xStart>320)?(xStart-320):0, self.scrollContainer.contentOffset.y);
        [UIView commitAnimations];
        
        
        
		self.btnNext.hidden = FALSE;
		
		[Validation removeAdviewFromSuperView];
        //		[Validation increaseTableSize];
        //		self.tblData.frame = CGRectMake(0, 68+ScrollHeight+5, 320, DEVICE_HEIGHT-(68+ScrollHeight+5));
        self.tblData.frame = CGRectMake(0, 100+ScrollHeight+5, 320, DEVICE_HEIGHT-(100+ScrollHeight+5));
	}
	else{
		[UIView beginAnimations:@"moveDown" context:nil];
        //[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.5];
        //		self.tblData.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-64);
        self.tblData.frame = CGRectMake(0, 100, 320, DEVICE_HEIGHT-100);
		self.btnNext.hidden = TRUE;
		[UIView commitAnimations];
		
		[Validation removeAdviewFromSuperView];
		[self.view addSubview:[Validation sharedBannerView]];
		//[Validation ResizeViewForAds];
	}
}

-(void)removeSelectedUserFromList:(id)sender{
	
	NSLog(@"arrB4Delete = %@",self.arrSelected);
	NSMutableDictionary *dic = [self.arrSelected objectAtIndex:((UIButton *)sender).tag];
	//UserCell *cell = (UserCell *)[self.tblData cellForRowAtIndexPath:[NSIndexPath indexPathForRow:[[dic valueForKey:SelectedRow] intValue] inSection:[[dic valueForKey:SelectedSection] intValue]]];
	
	[dic setValue:@"0" forKey:IS_SELECTED];
    //	[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:[[dic valueForKey:SelectedSection] intValue]]] replaceObjectAtIndex:[[dic valueForKey:SelectedRow] intValue] withObject:dic];
    //	cell.imgFriendshipStatus.hidden = TRUE;
    
	[self.arrSelected removeObjectAtIndex:((UIButton *)sender).tag];
	[self.tblData reloadData];
	
	NSLog(@"arrB4Delete = %@",self.arrSelected);
	[[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
	[self showSelectedUsersOnTop];
}


#pragma mark
#pragma mark web service method
/*
 - (void)requestFinished:(ASIHTTPRequest *)request{
 NSError *error = nil;
 
 //	NSLog(@"response =%@",[request responseString]);
 
 NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
 options:0
 error:&error];;
 */
- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
	
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
	//NSLog(@"dictionary = %@",dicResponse);
	
    //	[HUD hide:YES];
    //    [HUD hide:YES];
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (tag == 3) {
                [HUD show:YES];
                [self performSelectorInBackground:@selector(getMyFriendList) withObject:nil];
            }
            else{
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        if (tag == 2) {
                            id response = [dicResponse objectForKey:RESPONSE];
                            if (response != nil) {
                                
                                NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                                if (arr.count>0) {
                                    for (int i=0; i<arr.count; i++) {
                                        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[arr objectAtIndex:i]];
                                        [dic setValue:@"0" forKey:IS_SELECTED];
                                        [arr replaceObjectAtIndex:i withObject:dic];
                                        dic = nil;
                                    }
                                }
                                
                                if (self.pageCounter == 1) {
                                    [self.arrData removeAllObjects];
                                    [self.arrTemp removeAllObjects];
                                }
                                [self.arrData addObjectsFromArray:arr];
                                [self.arrTemp addObjectsFromArray:arr];
                                if (arr.count>0) {
                                    [self SetSectionArrayToLoadData];
                                }
                                arr = nil;
                            }
                            self.request = nil;
                            [HUD hide:YES];
                        }
                        else if (tag == 4){
                            //msg forwarded
                            /*
                             {
                             Response =     (
                             {
                             AllFriend = "<null>";
                             CName = "<null>";
                             CreateDate = "2014-09-23T04:26:42.227";
                             Ctype = 7;
                             Date = "<null>";
                             GroupIDs = "<null>";
                             ID = "<null>";
                             IsRead = "<null>";
                             Name = "<null>";
                             OS = "<null>";
                             PhotoPath = "<null>";
                             ReceiverID = 2;
                             ReceiverIDs = "<null>";
                             RegistrationID = "<null>";
                             SenderID = 7;
                             SoundPath = "<null>";
                             SubCatID = 0;
                             message = 172;
                             strDate = "<null>";
                             }
                             );
                             Status = 1;
                             UserStatus =     {
                             IsActive = 1;
                             IsDelete = 0;
                             Msg = success;
                             status = 1;
                             };
                             }
                             */
                            
                            // [HUD hide:YES];
                            //                            NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
                            //                            [Validation showToastMessage:@"Sent" displayDuration:3];
                            
                            NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
                            __block UIImageView *imageView;
                            UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                            imageView = [[UIImageView alloc] initWithImage:image];
                            
                            HUD.customView = imageView;
                            HUD.mode = MBProgressHUDModeText;
                            HUD.labelText = @"Sent";
                            imageView = nil;
                            
                            [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
                        }
                        else if (tag == 5){
                            id response = [dicResponse objectForKey:RESPONSE];
                            if (response != nil) {
                                [HUD hide:YES];
                                NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                                NSLog(@"arr send alarm req response %@",arr);
                                [self.navigationController popToRootViewControllerAnimated:YES];
                            }
                            else{
                                [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                                [HUD hide:YES];
                            }
                        }
                    }
                    else{
                        [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                        [HUD hide:YES];
                    }
                }
                else{
                    [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                    [HUD hide:YES];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
    dicResponse = nil;
}

- (void)requestFinished:(ASIHTTPRequest *)request{
    NSError *error = nil;
    
    NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
                                                                 options:0
                                                                   error:&error];;
    
    NSLog(@"dicResponse = %@",dicResponse);
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (request.tag == 1) {
                NSLog(@"upload Response");
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            /*
                             {
                             Response =     (
                             {
                             CreateBy = 20190;
                             CreateDate = "2014-10-07T06:04:30.92";
                             DeleteBy = "<null>";
                             DeleteDate = "<null>";
                             FilePath = "http://upload.wwhhaazzuupp.com/UserSound/0_0_EI8V92ME4730748_20190.mp3";
                             Gender = 0;
                             ID = 10257;
                             IsActive = 0;
                             IsDelete = 0;
                             IsPrivate = 1;
                             Name = "";
                             SoundMasterID = 0;
                             SoundSubMasterID = 0;
                             SubType = "<null>";
                             Type = "<null>";
                             UpdateBy = "<null>";
                             UpdateDate = "<null>";
                             UserID = "<null>";
                             }
                             );
                             Status = 1;
                             UserStatus =     {
                             IsActive = 1;
                             IsDelete = 0;
                             Msg = success;
                             status = 1;
                             };
                             }
                             */
                            
                            HUD.mode = MBProgressHUDModeIndeterminate;
                            NSString *strNotifId = [NSString stringWithFormat:@"%@",[response valueForKey:NEW_YAPEEY_ID]];
                            strNotifId = [strNotifId stringByTrimmingCharactersInSet: [[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
                            response = nil;
                            [self callSendAlarmRequest:strNotifId];
                        }
                        else{
                            response = nil;
                        }
                    }
                    else{
                        [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                        [HUD hide:YES];
                    }
                }
                else{
                    [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                    [HUD hide:YES];
                }
            }
            else if (request.tag == 2){
                //send notification
                
                NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
                __block UIImageView *imageView;
                UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                imageView = [[UIImageView alloc] initWithImage:image];
                
                HUD.customView = imageView;
                HUD.mode = MBProgressHUDModeText;
                HUD.labelText = @"Sent";
                imageView = nil;
                [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
            }
            else if (request.tag == 3){
                id response = [dicResponse objectForKey:RESPONSE];
                if (response != nil) {
                    [HUD hide:YES];
                    if ([NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]].length!=0 && [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]]]) {
                        [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]] error:nil];
                    }
                    NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                    NSLog(@"arr send alarm req response %@",arr);
                    [self.navigationController popToRootViewControllerAnimated:YES];
                }
                else{
                    [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                    [HUD hide:YES];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
    
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}
-(void)popToNotifListScreen{
    
    [Validation cleanNotifcationRelatedDicData];
    [HUD hide:YES];
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark    UIActionsheet Delegate

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"button index = %d",(int)buttonIndex);
    
    if (buttonIndex == actionSheet.cancelButtonIndex) {
        
    }
    else if (buttonIndex == 0){
        //only yap
        [self performSegueWithIdentifier:RECORD_OPTION_VC sender:nil];
    }
    else if (buttonIndex == 1){
        //yap with image
        [self performSegueWithIdentifier:CAPTURE_IMAGE_VC sender:nil];
    }
    else if (buttonIndex == 2){
        
        //        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        CreateGrpWithSelected *obj =  [MainStoryboard instantiateViewControllerWithIdentifier:CREATE_GRP_WITH_SELECTED];
        if (appDelegate.dic_NotificationReleatedData != nil) {
            appDelegate.dic_NotificationReleatedData = nil;
        }
        
        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    [NSNumber numberWithBool:TRUE],IS_GroupNotif,
                                                    [NSNumber numberWithBool:NO],IS_NotifSendToAll,
                                                    self.dicSelectedNotifToForward,SelectedBlabDic,
                                                    nil];
        
        if (self.isMultipleUsersSelected) {
            [appDelegate.dic_NotificationReleatedData setValue:[NSNumber numberWithBool:YES] forKey:Is_Create_Direct_Group];
            [appDelegate.dic_NotificationReleatedData setValue:[NSArray arrayWithArray:self.arrSelected] forKey:Selected_Friends_For_Creating_Group];
        }
        [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
        [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];
        
        [self.navigationController pushViewController:obj animated:YES];
    }
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
	if ([segue.identifier isEqualToString:RECORD_OPTION_VC] || [segue.identifier isEqualToString:CAPTURE_IMAGE_VC]) {
        if (appDelegate.dic_NotificationReleatedData != nil) {
            appDelegate.dic_NotificationReleatedData = nil;
        }
        
        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    [self.arrSelected valueForKey:USER_ID],SelectedIds,
                                                    [NSNumber numberWithBool:FALSE],IS_GroupNotif,
                                                    [NSNumber numberWithBool:self.isNotifSendToAll],IS_NotifSendToAll,
                                                    [NSDictionary dictionaryWithDictionary:self.dicSelectedNotifToForward],SelectedBlabDic,
                                                    
                                                    nil];
        
        
	}
    else if ([segue.identifier isEqualToString:GROUP_LIST_VC]){
        
        if (appDelegate.dic_NotificationReleatedData != nil) {
            appDelegate.dic_NotificationReleatedData = nil;
        }
        
        
        
        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    [NSNumber numberWithBool:TRUE],IS_GroupNotif,
                                                    [NSNumber numberWithBool:NO],IS_NotifSendToAll,
                                                    self.dicSelectedNotifToForward,SelectedBlabDic,
                                                    nil];
    }
	[appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
    [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];
    
    NSLog(@"appDelegate.dic_NotificationReleatedData = %@",appDelegate.dic_NotificationReleatedData);
}


- (IBAction)btnCancel_Clicked:(id)sender {
    if (self.arrData.count!=0) {
        [self.arrData removeAllObjects];
    }
    [self.arrData addObjectsFromArray:self.arrTemp];
    [self.sections removeAllObjects];
    [self SetSectionArrayToLoadData];
    [self.tblData reloadData];
    /*    [[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
     if (self.arrSelected.count!=0) {
     [self.arrSelected removeAllObjects];
     }
     [self showSelectedUsersOnTop];
     */
    [self.tfSearch resignFirstResponder];
    self.tfSearch.text = @"";
    [self animate:285 viewToAnimate:self.viewSearch];
}

- (IBAction)btnSearch_Clicked:(id)sender {
    [self animate:4 viewToAnimate:self.viewSearch];
}
-(void)animate:(int)xPoint viewToAnimate:(UIView *)viewToAni{
    [UIView animateWithDuration:0.3 animations:^{
        
        CGRect frame;
        
        // move our subView to its new position
        frame=viewToAni.frame;
        frame.origin.x=xPoint;
        viewToAni.frame=frame;
        viewToAni.alpha=1.0;
        
    }];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (self.arrData.count!=0) {
        [self.arrData removeAllObjects];
    }
    [self.arrData addObjectsFromArray:self.arrTemp];
    
    [self.tfSearch resignFirstResponder];
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if ([string isEqualToString:@"\n"]) {
        return YES;
    }
    //   indexSelUser=-1;
    /*
     [[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
     if (self.arrSelected.count!=0) {
     [self.arrSelected removeAllObjects];
     }
     [self showSelectedUsersOnTop];
     */
    NSString *str = [NSString stringWithFormat:@"%@%@",self.tfSearch.text,string];
    if ([string isEqualToString:@""]) {
        NSLog(@"%@",[self.tfSearch.text substringToIndex:self.tfSearch.text.length-1]);
        NSArray *arr =  [self filterArrayByADictionary:self.arrTemp andKey:[NSString stringWithFormat:@"Name beginswith[c] '%@'",[self.tfSearch.text substringToIndex:self.tfSearch.text.length-1]]];
        
        [self.arrData removeAllObjects];
        [self.arrData addObjectsFromArray:arr];
        [self.sections removeAllObjects];
        if (arr.count>0) {
            [self SetSectionArrayToLoadData];
        }
        
        //      Deleting last char from textfield than display all the friens.
        if (arr.count==0 && [self.tfSearch.text substringToIndex:self.tfSearch.text.length-1].length<=0) {
            [self.arrData addObjectsFromArray:self.arrTemp];
            [self SetSectionArrayToLoadData];
            //            [self.tblData reloadData];
        }
        else{
            [self.tblData reloadData];
        }
        //        [self.tblData reloadData];
        arr = nil;
    }
    else{
        NSArray *arr =  [self filterArrayByADictionary:self.arrTemp andKey:[NSString stringWithFormat:@"Name beginswith[c] '%@'",str]];
        [self.arrData removeAllObjects];
        [self.arrData addObjectsFromArray:arr];
        [self.sections removeAllObjects];
        if (arr.count>0) {
            [self SetSectionArrayToLoadData];
        }
        else{
            [self.tblData reloadData];
        }
        
        
        arr = nil;
    }
    
    return YES;
}
-(NSArray *)filterArrayByADictionary:(NSMutableArray *)aArray andKey:(NSString *)aPredicte
{
    NSPredicate *filter = [NSPredicate predicateWithFormat:aPredicte];
    return [aArray filteredArrayUsingPredicate:filter];
}
@end
