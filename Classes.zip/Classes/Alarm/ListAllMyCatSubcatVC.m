//
//  ListAllMyCatSubcatVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "ListAllMyCatSubcatVC.h"
#import "QBFlatButton.h"
#import "NotificationVC.h"
#import "NotifFileOptionCell.h"
#import "AFTableViewCell.h"
#import "SubCat_CollectionCell.h"
#import "MBProgressHUD.h"
#import "UserConversationChatVC.h"

#define PageSize			20
@interface ListAllMyCatSubcatVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation ListAllMyCatSubcatVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSArray *array = [self.navigationController viewControllers];
    for (int i=0;i<array.count;i++) {
        if ([[array objectAtIndex:i] isKindOfClass:[SetAlarmVC class]]) {
            NSLog(@"going in loop");
            self.childController = [array objectAtIndex:i];
            self.delegate = self.childController;
        }
        
    }
    
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
    
    self.arrSelectedIds = [NSArray arrayWithArray:(NSArray *)[appDelegate.dic_NotificationReleatedData valueForKey:SelectedIds]];
    self.isGroupNotif = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue];
    self.isNotifSendToAll = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_NotifSendToAll] boolValue];
    
	self.arrData = [[NSMutableArray alloc] init];
    self.contentOffsetDictionary = [NSMutableDictionary dictionary];
    
	[self performSelector:@selector(LoadViewSetting)];
}
-(void)viewWillAppear:(BOOL)animated{
	self.pageCounter = 1;
    appDelegate.currentVc = self;
    
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
    
    NSLog(@"%@",appDelegate.dic_NotificationReleatedData);
    //	[Validation showLoadingIndicator];
    [HUD show:YES];
    
    [self getAllMyCatSubcat];
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    appDelegate.isShouldShowReplyPopUp = NO;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
}

-(IBAction)btnBackClicked:(id)sender{
	[self.navigationController popViewControllerAnimated:NO];
}

-(void)getAllMyCatSubcat{
    
	if (self.request !=nil) {
		self.request = nil;
	}
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Name",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Descript",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue, @"PageSize",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"6",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_ALLMY_CAT_SUBCAT withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//	self.request.delegate = self;
//	self.request.tag = 1;
	strUrl = nil;
}

-(void)getSubCatList{
    
    if (self.arrSubCat== nil) {
        self.arrSubCat = [[NSMutableArray alloc] init] ;
    }
    
    [self.arrSubCat addObjectsFromArray:[NSArray arrayWithArray:[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"SoundSubMaster"]]];
    
    [self.tblData reloadData];
    
    if (self.arrSubCat.count > 0) {
        [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:self.selectedSection] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
}

-(void)sendNotifMsgAtIndex:(int)index isFromSubCat:(BOOL)isFromSubCat{
    if(![self.delegate respondsToSelector:@selector(displayAlarmSoundName:)]) {
        
        NSLog(@"delegate cannot respond");
    } else {
        
        NSLog(@"delegate can respond");
        if (isFromSubCat) {
            [self.delegate displayAlarmSoundName:[self.arrSubCat objectAtIndex:index]];
        }
        else{
            [self.delegate displayAlarmSoundName:[self.arrData objectAtIndex:self.selectedSection]];
        }
        NSArray *array = [self.navigationController viewControllers];
        for (int i = 0; i<array.count; i++) {
            if ([[array objectAtIndex:i] isKindOfClass:[SetAlarmVC class]]) {
                [self.navigationController popToViewController:[array objectAtIndex:i] animated:YES];
            }
        }
    }
    
/*
	if (self.request !=nil) {
		self.request = nil;
	}
	
    HUD.mode = MBProgressHUDModeIndeterminate;
    HUD.labelText = @"";
    
    UIImage *img = [appDelegate.dic_NotificationReleatedData valueForKey:CapturedImage];
    
    NSString *strCaption = [NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:ImageCaption]];
    
    [HUD show:YES];
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:(self.isGroupNotif)?@"":[NSString stringWithFormat:@"%@",[self.arrSelectedIds componentsJoinedByString:@"|"]],KeyValue,@"ReceiverIDs",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"ID"]],KeyValue,@"Ctype",KeyName, nil],@"3",
						 [NSDictionary dictionaryWithObjectsAndKeys:(self.isGroupNotif)?[NSString stringWithFormat:@"%@",[self.arrSelectedIds componentsJoinedByString:@"|"]]:@"0",KeyValue,@"GroupIDs",KeyName, nil],@"4",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",(isFromSubCat)?[[self.arrSubCat objectAtIndex:index] valueForKey:@"ID"]:@"0"],KeyValue,@"SubCatID",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"6",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",(self.isNotifSendToAll)?@"true":@"false"],KeyValue,@"AllFriend",KeyName, nil],@"7",
                         [NSDictionary dictionaryWithObjectsAndKeys:((img!= nil)?img:@""),KeyValue,@"ImgData",KeyName, nil],@"8",
                         [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:strCaption].length > 0)?strCaption:@"",KeyValue,@"Caption",KeyName, nil],@"9",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:IsPublicImg]],KeyValue, IsPublicImg,KeyName, nil],@"10",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:RequestedKeepStatus]],KeyValue, RequestedKeepStatus, KeyName, nil],@"11",
						 nil];
	
    //only @"ID" represents notif If that we want to forward, in this screen it will be 0 as we arent forwarding any notif
    
	NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];       //SEND_TEST_MSG     //SEND_NOTIF_MSG
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
	self.request.delegate = self;
	self.request.tag = 2;
	strUrl = nil;
*/ 
}

-(NSArray*) indexPathsForSection:(int)section withNumberOfRows:(int)numberOfRows {
    
    NSMutableArray* indexPaths = [NSMutableArray new];
    
    for (int i = 0; i < numberOfRows; i++) {
        NSIndexPath* indexPath = [NSIndexPath indexPathForRow:i inSection:section];
        [indexPaths addObject:indexPath];
    }
    
    return indexPaths;
}

-(IBAction)btnShowSubCategoriesClicked:(id)sender{
	
	UIButton *btn = ((UIButton *)sender);
    if ([[[self.arrData objectAtIndex:btn.tag] objectForKey:@"SoundSubMaster"] count]>0) {
        if (self.isShowSubCategories) {
            
            self.isShowFooter = NO;
            self.isShowSubCategories = NO;
            int numOfRows = (int)[self.tblData numberOfRowsInSection:self.selectedSection];
            NSArray* indexPaths = [self indexPathsForSection:self.selectedSection withNumberOfRows:numOfRows];
            [self.tblData deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationNone];
            
            CGRect rect = [self.tblData rectForSection:(int)btn.tag];
            
            [self.tblData scrollRectToVisible:rect animated:NO];
            
            if (self.selectedSection != btn.tag) {
                [self btnShowSubCategoriesClicked:sender];
            }
            else{
                [UIView setAnimationsEnabled:NO];
                [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:self.selectedSection] withRowAnimation:UITableViewRowAnimationFade];
                [UIView setAnimationsEnabled:YES];
            }
        }
        else{
            
            self.isShowSubCategories = YES;
            
            self.selectedSection = (int)btn.tag;
            
            if (self.selectedSection == self.arrData.count-1) {
                self.isShowFooter = YES;
            }
            else{
                self.isShowFooter = NO;
            }
            
            if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedSection] valueForKey:IS_CAT_HAS_SUBCATS]]].length > 0) {
                
                if ([[[self.arrData objectAtIndex:self.selectedSection] valueForKey:IS_CAT_HAS_SUBCATS] boolValue]) {
                    
                    //call web service
                    
                    if (self.arrSubCat != nil) {
                        if (self.arrSubCat.count > 0) {
                            [self.arrSubCat removeAllObjects];
                        }
                    }
                    [self getSubCatList];
                }
                else{
                    //initiate notif
                    //				self.isShowSubCategories = NO;
                    //				[self btnNotifSelected:nil];
                    self.isShowSubCategories = NO;
                    [Validation removeAdviewFromSuperView];
                    [self.tblData reloadData];
                }
            }
            else{
                //initiate notif
                //			self.isShowSubCategories = NO;
                //			[self btnNotifSelected:nil];
                self.isShowSubCategories = NO;
                [Validation removeAdviewFromSuperView];
                [self.tblData reloadData];
            }
        }
    }
    else{
        self.selectedSection = (int)btn.tag;
        self.isShowSubCategories = NO;
        [self btnNotifSelected:nil];
    }
    
}

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
    
	NSError *error = nil;
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];
    
    if (dicResponse != nil){
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if (request.tag == 1) {
                        //get cat list
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            [self.arrData addObjectsFromArray:arr];
                            
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            arr = nil;
                        }
                        [self.tblData reloadData];
                        response = nil;
                        [HUD hide:YES];
                    }
                    else if (request.tag == 2){
                        //send notification
                        
                        // [HUD hide:YES];
                        NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
                        self.isNotifSentMsgVisible = YES;
                        // [Validation showToastMessage:@"Sent" displayDuration:3];
                        __block UIImageView *imageView;
                        UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                        imageView = [[UIImageView alloc] initWithImage:image];
                        
                        HUD.customView = imageView;
                        HUD.mode = MBProgressHUDModeText;
                        HUD.labelText = @"Sent";
                        imageView = nil;
                        [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
                    }
                    if (request.tag == 3) {
                        //get sub-cat list
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            if (arr.count >0) {
                                if (self.arrSubCat== nil) {
                                    self.arrSubCat = [[NSMutableArray alloc] init];
                                }
                                [self.arrSubCat addObjectsFromArray:arr];
                                
                                [self.tblData reloadData];
                            }
                            
                            [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:self.selectedSection] atScrollPosition:UITableViewScrollPositionTop animated:NO];
                            
                            arr = nil;
                        }
                        //[self.tblData reloadData];
                        response = nil;
                        [HUD hide:YES];
                    }
                }
                else{
                    [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                    [HUD hide:YES];
                }
            }
            else{
                [HUD hide:YES];
                if (self.arrData.count == 0) {
                    [AlertHandler alertTitle:MESSAGE message:@"No Blabeey found under this category.\nPlease try another category." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
	
	self.request = nil;
	dicResponse = nil;
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

-(void)popToNotifListScreen{
    
    [Validation cleanNotifcationRelatedDicData];
    
	[HUD hide:YES];
    
    self.isNotifSentMsgVisible = NO;
    
    NSArray *arr = [self.navigationController viewControllers];
    BOOL isGotPopViewController = FALSE;
    
    for (UIViewController *v in arr) {
        if ([v isKindOfClass:[UserConversationChatVC class]]) {
            isGotPopViewController = TRUE;
            [self.navigationController popToViewController:v animated:YES];
            break;
        }
    }
    
    
    if (!isGotPopViewController) {
        
        [self removeViewControllersFromStack];
        
        if (appDelegate.selectedMenuIndex>0) {
            appDelegate.selectedMenuIndex = 0;
            //           UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
            
            [UIView transitionWithView:self.navigationController.view
                              duration:0.5
                               options:UIViewAnimationOptionTransitionCrossDissolve
                            animations:^{
                                [self.navigationController pushViewController:ivc animated:NO];
                            }
                            completion:nil];
            
        }
        else{
            //          UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            NotificationVC *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:NOTIFICATION_VC];
            [self.navigationController pushViewController:ivc animated:YES];
        }
    }
    
}

-(void)removeViewControllersFromStack{
    //   NSArray *arrVC = self.navigationController.viewControllers;
    for (id vc in self.navigationController.viewControllers){
		if ([vc isKindOfClass:[FavoritesVC class]]) {
			[self removeFromNavigationController:vc animated:NO];
		}
        else if ([vc isKindOfClass:[SearchFriendVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[OtherFriendNotifListVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[SettingsVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[CategoryListForUploadVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[GroupListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[UserListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[RecordingOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
	}
    
}

-(void)removeFromNavigationController:(UIViewController *)controller animated:(BOOL)animated {
    
    NSMutableArray *allViewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];;
    [allViewControllers removeObjectIdenticalTo:controller];
    self.navigationController.viewControllers = allViewControllers;
	
}


#pragma mark  UITableViewDelegate



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return self.arrData.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	return 130;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
	if (self.isShowFooter) {
		if (section == self.arrData.count-1) {
			return 40;
		}
		
	}
	return 0;
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
	UIView *viewFooterContainer = [[UIView alloc] init] ;
	viewFooterContainer.backgroundColor = [UIColor clearColor];
	return viewFooterContainer;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
	UIView *viewHeaderContainer = [[UIView alloc] init];
	
	AsyncImageView *catImg = [[AsyncImageView alloc] init];
	UILabel *lblTitle = [[UILabel alloc] init];
	UILabel *lblDesc = [[UILabel alloc] init];
	UIButton *btnCategories = [UIButton buttonWithType:UIButtonTypeCustom];
	UIImageView     *imgSubCategory = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icn_circle_plus.png"]];
    
    
	btnCategories.backgroundColor = [UIColor clearColor];
	
	lblTitle.numberOfLines = 0;
	lblDesc.numberOfLines = 0;
	lblDesc.lineBreakMode = NSLineBreakByWordWrapping;
	lblTitle.lineBreakMode = NSLineBreakByWordWrapping;
	
	catImg.layer.borderColor = [UIColor whiteColor].CGColor;
	catImg.layer.borderWidth = 2;
	
	if (section % 2==0) {
		lblDesc.textAlignment = NSTextAlignmentLeft;
		lblTitle.textAlignment = NSTextAlignmentLeft;
		
		catImg.frame = CGRectMake(5, 15, 100, 100);
		
		lblTitle.frame = CGRectMake(110, 8, tableView.frame.size.width-120, 35);
		lblDesc.frame = CGRectMake(110, 40, tableView.frame.size.width-120, 80);
        
        imgSubCategory.frame = CGRectMake(5, 105, 20, 20);
	}
	else{
		lblDesc.textAlignment = NSTextAlignmentRight;
		lblTitle.textAlignment = NSTextAlignmentRight;
		
		catImg.frame = CGRectMake(tableView.frame.size.width-100-5, 15, 100, 100);
		
		lblTitle.frame = CGRectMake(5, 8, tableView.frame.size.width-120, 35);
		lblDesc.frame = CGRectMake(5, 40, tableView.frame.size.width-120, 80);
        
        imgSubCategory.frame = CGRectMake(tableView.frame.size.width-25, 105, 20, 20);
	}
    
    imgSubCategory.hidden = YES;
    if ([[[self.arrData objectAtIndex:section] objectForKey:@"SoundSubMaster"] count]>0) {
        imgSubCategory.hidden = NO;
        if (self.isShowSubCategories && (self.selectedSection == section)) {
            [imgSubCategory setImage:[UIImage imageNamed:@"icn_circle_minus.png"]];
        }
        else{
            [imgSubCategory setImage:[UIImage imageNamed:@"icn_circle_plus.png"]];
        }
    }
    
    //	lblTitle.font = [UIFont fontWithName:Font_Montserrat_Bold size:26];
    //	lblDesc.font = [UIFont fontWithName:Font_Montserrat_Regular size:16];
	lblTitle.font = [UIFont fontWithName:Font_Montserrat_Bold size:20];
	lblDesc.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
	
	lblDesc.adjustsFontSizeToFitWidth = YES;
	lblTitle.adjustsFontSizeToFitWidth = YES;
	
	[catImg setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:CATEGORY_PHOTO_PATH]]]];
	[Validation setCorners:catImg];
	
	lblTitle.textColor = [UIColor whiteColor];
	[lblTitle setText:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:NAME]]];
	
	lblDesc.textColor = [UIColor colorWithRed:0.2 green:0.2 blue:0.2 alpha:0.8];
	lblDesc.text = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:DESCRIPTION]];
	NSString *strChar = [[[self.arrData objectAtIndex:section] valueForKey:NAME] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	viewHeaderContainer.backgroundColor = [Validation getColorForAlphabet:[NSString stringWithFormat:@"%@",strChar]];
	viewHeaderContainer.frame = CGRectMake(0, 0, tableView.frame.size.width, 130);
	
	btnCategories.frame = viewHeaderContainer.frame;
	[btnCategories addTarget:self action:@selector(btnShowSubCategoriesClicked:) forControlEvents:UIControlEventTouchUpInside];
	btnCategories.tag = section;
	
	
	[viewHeaderContainer addSubview:catImg];
	[viewHeaderContainer addSubview:lblTitle];
	[viewHeaderContainer addSubview:lblDesc];
	[viewHeaderContainer addSubview:btnCategories];
	[viewHeaderContainer addSubview:imgSubCategory];
    
    //	[lblTitle release];
	lblTitle = nil;
	
    ///	[lblDesc release];
	lblDesc = nil;
	
    //	[catImg release];
	catImg = nil;
    
    imgSubCategory = nil;
    
    if (section == self.arrData.count-1) {
        if (!self.isDataNull) {
            //  [Validation showLoadingIndicator];
            [HUD show:YES];
            
            self.pageCounter ++;
            [self performSelectorInBackground:@selector(getAllMyCatSubcat) withObject:nil];
        }
    }
    
	return viewHeaderContainer;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 120;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	//return self.arrData.count;
	if (section == self.selectedSection) {
		if (self.isShowSubCategories) {
            NSLog(@"%f",ceil([self.arrSubCat count]/2.0));
            int rows = (int)(ceil([self.arrSubCat count]/2.0));
			return rows;
		}
	}
	return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
    //	NSString *cellIdentifier = @"CellIdentifier";
    static NSString *CellIdentifier = @"CellIdentifier";
    
    AFTableViewCell *cell = (AFTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    [cell clearsContextBeforeDrawing];
    
    if (!cell)
    {
        cell = [[AFTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    [cell.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:CollectionViewCellIdentifier];
    
    NSString *strChar = [[[self.arrData objectAtIndex:self.selectedSection] valueForKey:NAME] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	cell.collectionView.backgroundColor = [Validation getColorForAlphabet:[NSString stringWithFormat:@"%@",strChar]];
    
    cell.collectionView.dataSource = self;
    cell.collectionView.delegate = self;
    
    return cell;
    
    //	NotifFileOptionCell *cell = (NotifFileOptionCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    //
    //	cell.lblSubCatTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:20];
    //	[cell.lblSubCatTitle setText:[NSString stringWithFormat:@"%@",[[self.arrSubCat objectAtIndex:indexPath.row] valueForKey:NAME]]];
    //
    //    cell.lblSubCatTitle.textColor = [Validation getColorForAlphabet:cell.lblSubCatTitle.text];
    //	[cell.imgProfile setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[self.arrSubCat objectAtIndex:indexPath.row] valueForKey:SUBCATEGORY_LOGO_PATH]]]];
    //    cell.imgProfile.layer.borderColor = [UIColor whiteColor].CGColor;
    //    cell.imgProfile.layer.borderWidth = 2;
    //    [Validation setCorners:cell.imgProfile];
    
    
	//return cell;
}

//-(void)tableView:(UITableView *)tableView willDisplayCell:(AFTableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
-(void)tableView:(UITableView *)tableView willDisplayCell:(AFTableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setCollectionViewDataSourceDelegate:self index:indexPath.row forDictionary:[self.arrSubCat objectAtIndex:indexPath.row]];
    
    NSInteger index = cell.collectionView.tag;
    
    CGFloat horizontalOffset = [self.contentOffsetDictionary[[@(index) stringValue]] floatValue];
    [cell.collectionView setContentOffset:CGPointMake(horizontalOffset, 0)];
}


#pragma mark - UICollectionViewDataSource Methods

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    int rowIndex = (int)collectionView.tag+1;
    if (self.isShowSubCategories) {
        if ((rowIndex*2) > self.arrSubCat.count) {
            return 1;
        }
        return  2;
    }
    
    // NSLog(@"section = %d",(int)collectionView.tag);
    // if (section == self.selectedSection) {
    //		if (self.isShowSubCategories) {
    //			return  2;
    //		}
    //	}
	return 0;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"Cell";
    
    SubCat_CollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    [cell clearsContextBeforeDrawing];
    
    cell.imgProfile.image = nil;
    cell.imgProfile.imageURL = nil;
    
    int count = ((int)collectionView.tag+1)*2;         //by multiples of 2
    int index = 0;
    
    if (indexPath.row == 0) {
        index = count - 2;
    }
    else{
        index = count - 1;
    }
    NSLog(@"index = %d",index);
    cell.layer.borderColor = [UIColor whiteColor].CGColor;
    cell.layer.borderWidth = 0.5;
    
    
    if (index < (int)self.arrSubCat.count) {
        cell.backgroundColor = [Validation getColorForAlphabet:[[self.arrSubCat objectAtIndex:index] valueForKey:NAME]];
        cell.layer.borderColor = [UIColor whiteColor].CGColor;
        cell.layer.borderWidth = 0.5;
        [cell setCollectionViewForindex:indexPath.row forDictionary:[self.arrSubCat objectAtIndex:index]];
    }
    else{
        cell.imgProfile.hidden = YES;
        [cell.imgProfile setImage:nil];
        cell.imgFriendshipStatus.hidden = YES;
        cell.lblSubCatTitle.textColor = [UIColor whiteColor];
        [cell.lblSubCatTitle setText:@""];
        cell.lblSubCatTitle.hidden = YES;
        NSString *strChar = [[[self.arrData objectAtIndex:self.selectedSection] valueForKey:NAME] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        cell.backgroundColor = [Validation getColorForAlphabet:[NSString stringWithFormat:@"%@",strChar]];
        
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    int count = ((int)collectionView.tag+1)*2;         //by multiples of 2
    int index = 0;
    
    if (indexPath.row == 0) {
        index = count - 2;
    }
    else{
        index = count - 1;
    }
    NSLog(@"index = %d",index);
    
    if (index < self.arrSubCat.count) {
        [self sendNotifMsgAtIndex:index isFromSubCat:YES];
    }
}

#pragma mark - UIScrollViewDelegate Methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
	[self sendNotifMsgAtIndex:(int)indexPath.row isFromSubCat:YES];
}

-(void)btnNotifSelected:(id)sender{
	[self sendNotifMsgAtIndex:self.selectedSection isFromSubCat:NO];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
