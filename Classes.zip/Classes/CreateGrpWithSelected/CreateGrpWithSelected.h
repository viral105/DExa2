//
//  CreateGrpWithSelected.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 09/01/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreateGrpWithSelected : UIViewController<UITextFieldDelegate,UserListVCDelegate,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIGestureRecognizerDelegate>

@property (nonatomic, strong) IBOutlet	UITextField			*tfGrpName;

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) IBOutlet UIButton				*btnSave;

@property (nonatomic, strong) IBOutlet UIButton				*btnBack;

@property (nonatomic, strong) IBOutlet UIButton				*btnShowUserListToAdd;

@property (nonatomic, strong) UserListVC					*objUserListVC;

@property (nonatomic, strong) ASIFormDataRequest			*request;

@property (nonatomic, strong) NSDictionary					*DicGrpDetail;

@property (nonatomic, strong) NSMutableArray				*arrData;

//@property (nonatomic, strong) NSMutableArray				*arrDeletedData;
//
//@property (nonatomic, strong) NSMutableArray				*arrAddedData;

@property (nonatomic, readwrite) int						pageCounter;

@property (nonatomic, readwrite) BOOL						isDataNull;

@property (nonatomic, strong) IBOutlet UITableView			*tblData;

@property (nonatomic, strong) IBOutlet UILabel				*lblNoUserInGrpFound;

@property (nonatomic, strong) IBOutlet UIButton             *btnEditGroupPic;

@property (nonatomic, assign) BOOL isSelectAll;

@end
