//
//  CreateGrpWithSelected.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 09/01/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "CreateGrpWithSelected.h"
#import "UserCell.h"
#import "MBProgressHUD.h"

#define IS_SELECTED			@"is_selected"
#define TextFieldHeight		45
#define SelectedSection		@"selectedSection"
#define SelectedRow			@"selectedRow"
#define EditGroupTitle		@"Edit Group"
#define UserListingTitle	@"Add User"


@interface CreateGrpWithSelected ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation CreateGrpWithSelected

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	self.arrData = [[NSMutableArray alloc] init];
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
    [self.lblNoUserInGrpFound setTextColor:TWITTER_BLUE_COLOR];
    [self.lblNoUserInGrpFound setShadowColor:[UIColor clearColor]];
//    [appDelegate.dic_NotificationReleatedData setValue:[NSArray arrayWithArray:(NSArray *)[self.arrSelected valueForKey:USER_ID]] forKey:Selected_Friends_For_Creating_Group];
    self.arrData = [[NSMutableArray alloc] initWithArray:(NSArray *)[appDelegate.dic_NotificationReleatedData valueForKey:Selected_Friends_For_Creating_Group]];
    
	[self.tblData registerNib:[UINib nibWithNibName:@"UserCell" bundle:nil] forCellReuseIdentifier:@"cellIdentifier"];
    
    // Do any additional setup after loading the view.
	[self loadUserListingVC];
    
}

-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
    
    [Validation removeAdviewFromSuperView];
    
	appDelegate.currentVc = self;
	self.btnShowUserListToAdd.tag = 1;
    [self.lblNoUserInGrpFound setHidden:YES];
	//[self showButton]; //bhavik 16-Feb-2015
	self.pageCounter = 1;
    
    //bhavik 16-Feb-2015
    if(self.isSelectAll)
    {
        self.btnSave.frame =  CGRectMake(0, self.btnSave.frame.origin.y, [UIScreen mainScreen].bounds.size.width, self.btnSave.frame.size.height);
        [self hideButton];
    }
    else
    {
        [self showButton];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    [self.view endEditing:YES];
    
    //    UITableView *tblRegister = (UITableView*) [self.view viewWithTag:kSignUpTableViewTag];
    //    [tblRegister setContentOffset:CGPointMake(0, 0) animated:YES];
}
#pragma mark	UIButton Methods
-(void)loadUserListingVC{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];

	self.pageCounter = 1;
	self.lblNoUserInGrpFound.hidden = YES;

    [self.tblData reloadData];
    
    if (self.isSelectAll) {
        
    }
//	if (self.objUserListVC != nil) {
//		self.objUserListVC.delegate = nil;
//		self.objUserListVC = nil;
//	}
	
//	self.objUserListVC = [MainStoryboard instantiateViewControllerWithIdentifier:USER_LIST_VC];
//	self.objUserListVC.delegate = self;
//	self.objUserListVC.selectedParentView_Index = 1;
//    self.objUserListVC.view.frame = CGRectMake(0, 68+TextFieldHeight, 320, DEVICE_HEIGHT-(68+TextFieldHeight));
//    [self.view addSubview:self.objUserListVC.view];
//    [self.objUserListVC didMoveToParentViewController:self];
//    [self addChildViewController:self.objUserListVC];
//	[self.view bringSubviewToFront:self.btnSave];
//    
//    [self performSelector:@selector(loadDataInChildView:) withObject:[NSNumber numberWithInt:1] afterDelay:0.1];
}

-(IBAction)btnAddUserToGroup:(id)sender{
    
    if (((UIButton *)sender).tag == 2) {
		if (self.objUserListVC != nil) {
			//[self hideButton];
			//it means user added to current group
			//check if selected user already exists??
			//if yes then filter them and add them to current array
			self.lblTitle.text = EditGroupTitle;
			self.btnShowUserListToAdd.hidden = NO;
			self.btnSave.hidden = NO;
            
			[self checkForRepeatedField:self.objUserListVC.arrSelected];
			[self.objUserListVC.view removeFromSuperview];
			[self.objUserListVC removeFromParentViewController];
			self.objUserListVC.delegate = nil;
			self.objUserListVC = nil;
			self.btnShowUserListToAdd.tag = 1;
			[self showButton];
			[self.tblData reloadData];
            
            self.btnShowUserListToAdd.frame = CGRectMake(0, self.btnShowUserListToAdd.frame.origin.y, 160, self.btnShowUserListToAdd.frame.size.height);
            [self.btnShowUserListToAdd setTitle:@"Add more" forState:UIControlStateNormal];
//            if (self.arrAddedData.count > 0) {
//                [self.lblNoUserInGrpFound setHidden:YES];
//            }
        }
	}
	else if (((UIButton *)sender).tag == 1){
		//show selected users
        if (Validation.imgBorderBox!=nil) {
            Validation.imgBorderBox.layer.borderColor = [UIColor clearColor].CGColor;
        }
        
		if (self.objUserListVC != nil) {
            self.objUserListVC.delegate = nil;
            self.objUserListVC = nil;
        }
        self.btnShowUserListToAdd.frame = CGRectMake(0, self.btnShowUserListToAdd.frame.origin.y, 320, self.btnShowUserListToAdd.frame.size.height);
        [self.btnShowUserListToAdd setTitle:@"Add" forState:UIControlStateNormal];
        self.btnShowUserListToAdd.tag = 2;
        self.btnBack.tag = 1;
        self.btnSave.hidden = TRUE;
        
        //	UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        self.objUserListVC = [MainStoryboard instantiateViewControllerWithIdentifier:USER_LIST_VC];
        self.objUserListVC.delegate = self;
        self.objUserListVC.selectedParentView_Index = 1;
        self.btnSave.hidden = YES;
        self.objUserListVC.view.frame = CGRectMake(DEVICE_WIDTH, 68, 320, DEVICE_HEIGHT-(68+2+50));
        [self.view addSubview:self.objUserListVC.view];
        [self.objUserListVC didMoveToParentViewController:self];
        [self addChildViewController:self.objUserListVC];
        [self.view bringSubviewToFront:self.btnShowUserListToAdd];
        
        [UIView beginAnimations:@"ScrollUp" context:nil];
        [UIView setAnimationDuration:0.5];
        self.objUserListVC.view.frame = CGRectMake(0, 68, 320, DEVICE_HEIGHT-(68+2+50));
        self.lblTitle.text = UserListingTitle;
        [UIView commitAnimations];
        
        self.btnShowUserListToAdd.hidden = YES;
        
        
        
        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        //[Validation ResizeViewForAds];
        Validation.sharedBannerView.alpha = 0;
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.6];
        Validation.sharedBannerView.alpha = 1;
        [UIView commitAnimations];
        
        [self performSelector:@selector(loadDataInChildView:) withObject:[NSNumber numberWithInt:1] afterDelay:0.1];
	}
}

-(void)loadDataInChildView:(NSNumber *)listForIndex{
    
    self.objUserListVC.selectedParentView_Index = [listForIndex intValue];
    [self.objUserListVC loadUserListingView];
    
}
- (void)showButton{
    self.btnShowUserListToAdd.alpha = 1;
    self.btnShowUserListToAdd.hidden = FALSE;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.6];
    self.btnShowUserListToAdd.alpha = 1;
    [UIView commitAnimations];
}

- (void)hideButton{
	self.btnShowUserListToAdd.hidden = TRUE;
}

#pragma mark	UIButton Action

-(IBAction)btnSetGroupImageClicked:(id)sender{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Select" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:@"From Camera",@"From Library", nil];
    [action showInView:self.view];
}

-(IBAction)btnBackClicked:(id)sender{
    
	if (self.btnBack.tag == 0) {
		[self.navigationController popViewControllerAnimated:YES];
	}
	else if (self.btnBack.tag == 1){
		self.lblTitle.text = EditGroupTitle;
		
        
        [UIView beginAnimations:@"ScrollUp" context:nil];
        [UIView setAnimationDuration:0.5];
        self.objUserListVC.view.frame = CGRectMake(DEVICE_WIDTH, 68, 320, DEVICE_HEIGHT-(68+2+50));
        [UIView commitAnimations];
        
        [self performSelector:@selector(removeUserListingView) withObject:nil afterDelay:0.6];
    }
}

-(void)removeUserListingView{
    self.btnShowUserListToAdd.hidden = NO;
    self.btnSave.hidden = NO;
    
    [self.objUserListVC.view removeFromSuperview];
    [self.objUserListVC removeFromParentViewController];
    self.objUserListVC.delegate = nil;
    self.objUserListVC = nil;
    self.btnShowUserListToAdd.tag = 1;
    self.btnBack = 0;
    [Validation removeAdviewFromSuperView];
    [self showButton];
}

-(IBAction)btnSaveClicked:(id)sender{
	
	//this is save of add user list and edited user list
	if ([DataValidation checkNullString:self.tfGrpName.text].length > 0) {
		
		[HUD show:YES];
		
//		NSLog(@"%@",self.arrAddedData);
		

//		NSArray *arrSelectedUsers = [NSArray arrayWithArray:[self.arrAddedData valueForKey:USER_ID]];
//		NSLog(@"selected Users = %@",arrSelectedUsers);
		self.objUserListVC.delegate = nil;
		self.objUserListVC = nil;
		[self createGroup:nil];
	}
	else{
		[Validation highLightTextField:self.tfGrpName inView:self.view];
		[Validation showToastMessage:@"Enter valid group name." displayDuration:ERROR_MSG_DURATION];
	}
}

-(void)checkForRepeatedField:(NSArray *)arrNewUsers{
	
//	if (self.arrAddedData == nil) {
//		self.arrAddedData = [[NSMutableArray alloc] init];
//	}
//	[self.arrAddedData removeAllObjects];
	
	NSArray *arrAddedUsers = [arrNewUsers valueForKey:USER_ID];
	NSArray *arrUserInGrp = [self.arrData valueForKey:USER_ID];
    
	NSLog(@"newUsers = %@",arrAddedUsers);
	NSLog(@"Users In grp = %@",arrUserInGrp);
	for (int i=0; i<arrAddedUsers.count; i++) {
		int index = (int)[arrUserInGrp indexOfObject:[arrAddedUsers objectAtIndex:i]];
		if (index < -1 || index > self.arrData.count) {
			[self.arrData addObject:[arrNewUsers objectAtIndex:i]];
			//[self.arrAddedData addObject:[arrNewUsers objectAtIndex:i]];
		}
	}
}

#pragma mark
#pragma mark    UIActionSheet Delegate
#pragma mark

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == actionSheet.cancelButtonIndex) {
        
    }
    else if (buttonIndex == 0){
        //open camera
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            UIImagePickerController *imgPicker = [[UIImagePickerController alloc] init];
            imgPicker.sourceType = UIImagePickerControllerSourceTypeCamera;
            imgPicker.delegate = self;
            imgPicker.allowsEditing = YES;
            [self presentViewController:imgPicker
                               animated:YES completion:nil];
        }
    }
    else if (buttonIndex == 1){
        //open library
        UIImagePickerController *imgPicker = [[UIImagePickerController alloc] init];
		
		imgPicker.delegate = self;
		
		imgPicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
		
		imgPicker.allowsEditing = YES;
		[self presentViewController:imgPicker
						   animated:YES completion:nil];
        
    }
}

#pragma mark
#pragma mark		UITableView DataSource Methos
#pragma mark

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *viewFooter = [[UIView alloc] init];
    viewFooter.backgroundColor = [UIColor clearColor];
    return viewFooter;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 56;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 90;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	return self.arrData.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
	NSDictionary *dic = [self.arrData objectAtIndex:indexPath.row];
	
	UserCell *cell = (UserCell *)[tableView dequeueReusableCellWithIdentifier:@"cellIdentifier"];
	cell.isUserSelectionInView = YES;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
    [cell setBoxValuesWithData:dic];
    [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
    [cell.imgFriendshipStatus setHidden:TRUE];
	
	if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
		[cell.imgFriendshipStatus setHidden:FALSE];
	}
	else{
		[cell.imgFriendshipStatus setHidden:TRUE];
	}
	
	cell.btnUnfriend.hidden = YES;
	dic = nil;
	
	return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
	UserCell *cell = (UserCell *)[tableView cellForRowAtIndexPath:indexPath];
    
	
	NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:indexPath.row]];
//	if (self.arrDeletedData==nil) {
//		self.arrDeletedData = [[NSMutableArray alloc] init];
//	}
	
//	int index = -1;
//	int index1 = -1;
//	if (self.arrDeletedData.count >0) {
//		index = (int)[self.arrDeletedData indexOfObject:dic];
//		NSLog(@"%d",index);
//	}
//	if (self.arrAddedData.count > 0) {
//		index1 = (int)[self.arrAddedData indexOfObject:dic];
//	}
	
	if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
		//so deselect it
		[dic setValue:@"0" forKey:IS_SELECTED];
		[self.arrData replaceObjectAtIndex:indexPath.row withObject:dic];
		cell.imgFriendshipStatus.hidden = TRUE;
//		if (self.arrAddedData != nil) {
//			if (self.arrAddedData.count>0) {
//				if (index1 > -1 && index1 < self.arrAddedData.count) {
//					[self.arrAddedData replaceObjectAtIndex:index1 withObject:dic];
//				}
//				else{
//					[self.arrDeletedData addObject:dic];
//				}
//			}
//			else{
//				[self.arrDeletedData addObject:dic];
//			}
//		}
//		else{
//			[self.arrDeletedData addObject:dic];
//		}
	}
	else{
		[dic setValue:@"1" forKey:IS_SELECTED];
		[self.arrData replaceObjectAtIndex:indexPath.row withObject:dic];
		cell.imgFriendshipStatus.hidden = FALSE;
//		if (index > -1 && index < self.arrDeletedData.count) {
//			[self.arrDeletedData removeObjectAtIndex:index];
//		}
//		if (self.arrAddedData && self.arrAddedData.count>0) {
//			if (index1 > -1 && index1 < self.arrAddedData.count) {
//				[self.arrAddedData replaceObjectAtIndex:index1 withObject:dic];
//			}
//		}
		
        
        //		[dic setValue:[NSNumber numberWithInteger:indexPath.section] forKey:SelectedSection];
        //		[dic setValue:[NSNumber numberWithInteger:indexPath.row] forKey:SelectedRow];
		//[self.arrDeletedData addObject:dic];
	}
    
    
//    if (self.arrDeletedData.count==0) {
//        [self.lblNoUserInGrpFound setHidden:NO];
//    }
//    
//	NSLog(@"deleteArray = %@",[[self.arrDeletedData valueForKey:USER_ID] componentsJoinedByString:@"|"]);
//	NSLog(@"arrAddedData = %@,%@",[[self.arrAddedData valueForKey:USER_ID] componentsJoinedByString:@"|"],[[self.arrAddedData valueForKey:IS_SELECTED] componentsJoinedByString:@"|"]);
}

#pragma mark	UITextField Action

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
	[textField resignFirstResponder];
	return YES;
}

-(void)createGroup:(NSArray *)arrSelectedUserId{
    
  //  NSString *strIdsToRemove = [[self.arrDeletedData valueForKey:USER_ID] componentsJoinedByString:@"|"];
	NSString *strIdsToAdd = @"";
	for (int i = 0; i<self.arrData.count; i++) {
		if ([[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:i] valueForKey:IS_SELECTED]] isEqualToString:@"1"]) {
			if (strIdsToAdd.length == 0) {
				strIdsToAdd = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:i] valueForKey:USER_ID]];
			}
			else{
				strIdsToAdd = [strIdsToAdd stringByAppendingFormat:@"|%@",[[self.arrData objectAtIndex:i] valueForKey:USER_ID]];
			}
		}
	}
	

    
	NSLog(@"createGroup:arrSelectedUserId = %@",strIdsToAdd);
	
	if (self.request !=nil) {
		self.request = nil;
	}
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[DataValidation checkNullString:self.tfGrpName.text]],KeyValue,@"GroupName",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"2",
						 
						 [NSDictionary dictionaryWithObjectsAndKeys:strIdsToAdd,KeyValue,@"GroupUserIDs",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"true", KeyValue, @"IsPublic",KeyName,nil],@"4",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:CREAT_NEW_GROUP withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }
//	self.request.delegate = self;
//	self.request.tag = 2;
	strUrl = nil;
}


#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];;
	
	//NSLog(@"dictionary = %@",dicResponse);
    self.lblNoUserInGrpFound.hidden = YES;
    
	[HUD hide:YES];
    if (dicResponse !=  nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [appDelegate callLogOutService];
        }
        else{
            if ([dicResponse objectForKey:RESPONSE] != nil) {
                
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    
                    if (request.tag == 1){
                        //get grp user list
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            if (arr.count>0) {
                                for (int i=0; i<arr.count; i++) {
                                    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[arr objectAtIndex:i]];
                                    [dic setValue:@"1" forKey:IS_SELECTED];
                                    [arr replaceObjectAtIndex:i withObject:dic];
                                    dic = nil;
                                }
                            }
                            [self.arrData addObjectsFromArray:arr];
                            
                            arr = nil;
                        }
                        [self.tblData reloadData];
                        response = nil;
                    }
                    else if (request.tag == 2){
                        //group edited
                        [Validation showToastMessage:@"Done" displayDuration:ERROR_MSG_DURATION];
                        GroupListVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:GROUP_LIST_VC];
                        [self.navigationController pushViewController:obj animated:YES];
                        
                        //[self.navigationController popViewControllerAnimated:YES];
                    }
                }
                else{
                    self.lblNoUserInGrpFound.hidden = NO;
                }
            }
        }
    }
    
	dicResponse = nil;
	self.request = nil;
	[HUD hide:YES];
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
