//
//  DataValidation.m
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "DataValidation.h"
#import <AddressBook/AddressBook.h>
#import "SearchFilterSelectionVC.h"
#import "UserConversationChatVC.h"
//#import "ContactList.h"
//#import "NotificationVC.h"
//#import "SettingsVC.h"
//#import "SearchFriendVC.h"
//#import "AddFriendFromExistingFriendListVC.h"
//#import "EditProfileVC.h"
//#import "OtherFriendNotifListVC.h"
//#import "ApnsPopupView.h"
//#import "NotificationCell.h"
//#import "NotifOptionVC.h"
//#import "CategoryListForUploadVC.h"
//#import "FavoritesVC.h"
//#import "GroupListVC.h"
//#import "UserListVC.h"
#import "LocationVC.h"

#define  AnimationDuration		4
#define  APNS_POPUP_HEIGHT      180

@implementation DataValidation

#pragma mark NetworkValidation

-(BOOL)checkInternetConnection{
	Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
	NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
	if (networkStatus == NotReachable) {
		//There IS NO internet connection

		//[[TWMessageBarManager sharedInstance] showMessageWithTitle:kStringMessageBarNetworkAvailabilityMessage
//													   description:kStringMessageBarNetworkAvailabilityMessage
//															  type:TWMessageBarMessageTypeInfo
//													statusBarStyle:UIStatusBarStyleDefault
//														  callback:nil];
        
//        [[dic valueForKey:@"aps"] valueForKey:@"alert"]
        NSDictionary *aps = [NSDictionary dictionaryWithObjectsAndKeys:kStringMessageBarNetworkAvailabilityMessage,@"alert", nil];
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:aps,@"aps", nil];
        
        [self showAPNS_PopUp:dic forId:404];
        
        [self.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];

		
		return FALSE;
	} else {
		//There IS internet connection
		return TRUE;
	}
}

-(void)closeNotificationPopup:(id)sender{
    
    //  [HUD hide:YES];
	[NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideAPNS_PopUp) object:nil];
	[self hideAPNS_PopUp];
    
}

#pragma data validation
/*
-(BOOL)CheckFirstChar_IS_ALPHABET:(NSString *)str{
    
	NSString *nameRegex = @"^[A-Za-z][A-Za-z0-9-_ ]+$";
    NSPredicate *nameTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", nameRegex];
    return [nameTest evaluateWithObject:str];
}
*/
/*
-(BOOL)CheckAlphaNumericOnly:(NSString *)str{
	NSString *nameRegex = @"^[A-Za-z0-9_]+$";
    NSPredicate *nameTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", nameRegex];
    return [nameTest evaluateWithObject:str];
}
 */
/*
-(BOOL)CheckClipTitleOnly:(NSString *)str{
	NSString *nameRegex = @"^[A-Za-z0-9 _-]+$";
    NSPredicate *nameTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", nameRegex];
    return [nameTest evaluateWithObject:str];
}
*/
+(BOOL)CheckNumericOnly:(NSString *)str{
	NSString *nameRegex = @"^[0-9-()]+$";
    NSPredicate *nameTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", nameRegex];
    return [nameTest evaluateWithObject:str];
}

+(BOOL)validateEmailWithString:(NSString *)email {
	
	// NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
	NSString *emailRegex = @"^[_A-Za-z0-9-+]+(\\.[_A-Za-z0-9-+]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z‌​]{2,4})$";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

+(NSString *)checkNullString : (NSString *)str
{
    if ([str isKindOfClass:[NSNull class]] || [str isEqual:[NSNull null]] || [str isEqualToString:@"<null>"]  || [str isEqualToString:@"(null)"] || [str isEqualToString:@""] || str.length == 0 || str == nil) {
        return @"";
    }
	else{
		str = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	}
    return str;
}

+(BOOL)CompareString:(NSString *)str1 withString:(NSString *)str2{
	str1 = [str1 stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	str2 = [str2 stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	if ([str1 isEqualToString:str2]) {
		return TRUE;
	}
	else return FALSE;
}
-(void)animateYpoint:(int)yPoint viewToAnimate:(UIView *)viewToAni{
    [UIView animateWithDuration:0.3 animations:^{
        
        CGRect frame;
        
        // move our subView to its new position
        frame=viewToAni.frame;
        frame.origin.y=yPoint;
        viewToAni.frame=frame;
        viewToAni.alpha=1.0;
        
    }];
}
-(NSString *)GetUTCDate{
	
	NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init] ;
	[dateFormatter1 setDateFormat:@"M/d/yyyy hh:mm:ss a"];
	[dateFormatter1 setAMSymbol:@"AM"];
	[dateFormatter1 setPMSymbol:@"PM"];
	NSDate  *objDate    = [NSDate date];
	[dateFormatter1 setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
	NSString *strDateTime   = [dateFormatter1 stringFromDate:objDate];
    NSLog(@"strDateTime %@",strDateTime);
	self.strTimeT1 = strDateTime;
//	NSLog(@"dateTime = %@",strDateTime);
	return strDateTime;
}
-(NSString *)GetUTCDateFromDate:(NSDate *)date{
	
	NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init] ;
	[dateFormatter1 setDateFormat:@"M/d/yyyy hh:mm:ss a"];
	[dateFormatter1 setAMSymbol:@"AM"];
	[dateFormatter1 setPMSymbol:@"PM"];
	
	[dateFormatter1 setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
	NSString *strDateTime   = [dateFormatter1 stringFromDate:date];
	self.strTimeT1 = strDateTime;
    //	NSLog(@"dateTime = %@",strDateTime);
	return strDateTime;
}
-(NSString *)getCurrentTimeZoneDateFromUtcDate:(NSString*)strDate{
    if ([DataValidation checkNullString:strDate].length>0) {
        NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
        [dateFormatter1 setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
        NSDate *date = [dateFormatter1 dateFromString:strDate];
        NSLog(@"date : %@",date);
        
        NSTimeZone *currentTimeZone = [NSTimeZone localTimeZone];
        NSTimeZone *utcTimeZone = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        
        NSInteger currentGMTOffset = [currentTimeZone secondsFromGMTForDate:date];
        NSInteger gmtOffset = [utcTimeZone secondsFromGMTForDate:date];
        NSTimeInterval gmtInterval = currentGMTOffset - gmtOffset;
        
        NSDate *destinationDate = [[NSDate alloc] initWithTimeInterval:gmtInterval sinceDate:date];
        
        NSDateFormatter *dateFormatters = [[NSDateFormatter alloc] init];
        [dateFormatters setDateFormat:FORMAT_DATE_TIME];
        [dateFormatters setTimeZone:[NSTimeZone systemTimeZone]];
        strDate = [dateFormatters stringFromDate: destinationDate];
    }
    else{
        return @"";
    }
    NSLog(@"DateString : %@", strDate);
    return strDate;
}
-(NSDate *)GetCombineDate:(NSString *)strDate time:(NSString *)strTime{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    if (strTime.length==0) {
        [formatter setDateFormat:FORMAT_DATE_TIME];
        NSDate *date = [formatter dateFromString:strDate];
        NSCalendar *calendar = [NSCalendar currentCalendar];
        NSDateComponents *dateComponents = [calendar components:NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit|NSHourCalendarUnit|NSMinuteCalendarUnit fromDate:date];
        
        NSDateComponents *newComponents = [[NSDateComponents alloc]init];
        //    newComponents.timeZone = [NSTimeZone systemTimeZone];
        [newComponents setDay:[dateComponents day]];
        [newComponents setMonth:[dateComponents month]];
        [newComponents setYear:[dateComponents year]];
        [newComponents setHour:[dateComponents hour]];
        [newComponents setMinute:[dateComponents minute]];
        
        NSDate *combDate = [calendar dateFromComponents:newComponents];
        return combDate;
    }
    else{
        [formatter setDateFormat:FORMAT_DATE];
        NSDate *date = [formatter dateFromString:strDate];
        [formatter setDateFormat:FORMAT_TIME];
        NSDate *time = [formatter dateFromString:strTime];
        NSCalendar *calendar = [NSCalendar currentCalendar];
        NSDateComponents *dateComponents = [calendar components:NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit fromDate:date];
        NSDateComponents *timeComponents = [calendar components:NSHourCalendarUnit|NSMinuteCalendarUnit fromDate:time];
        
        NSDateComponents *newComponents = [[NSDateComponents alloc]init];
        //    newComponents.timeZone = [NSTimeZone systemTimeZone];
        [newComponents setDay:[dateComponents day]];
        [newComponents setMonth:[dateComponents month]];
        [newComponents setYear:[dateComponents year]];
        [newComponents setHour:[timeComponents hour]];
        [newComponents setMinute:[timeComponents minute]];
        
        NSDate *combDate = [calendar dateFromComponents:newComponents];
        return combDate;
    }
}
-(NSString *)getEncryptedTextForString:(NSString *)strToEncrypt isGeneral:(BOOL)isGeneralKey{

	NSLog(@"String To Encrypt = %@",strToEncrypt);
	NSString *encryptedData = @"";
	if (isGeneralKey) {
	//	NSLog(@"ENC Key ==== %@",[DataValidation GetGeneralKey]);
		encryptedData = [AESCrypt encrypt:strToEncrypt password:[DataValidation GetGeneralKey]];
	}
	else{
		NSString *strKey = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_KEY]];
//		NSLog(@"ENC Key ==== %@",strKey);
		
		encryptedData = [AESCrypt encrypt:strToEncrypt password:strKey];
	}
	
//	NSLog(@"isGeneralKey = %@ ============= enc data ==== %@",[NSNumber numberWithBool:isGeneralKey],encryptedData);
//	NSLog(@"isGeneralKey = %@ ============= Dec Data ==== %@",[NSNumber numberWithBool:isGeneralKey],[self getDecryptedTextForString:encryptedData isGeneral:isGeneralKey]);
	
	return encryptedData;
}

-(NSString *)getDecryptedTextForString:(NSString *)strToDecrypt isGeneral:(BOOL)isGeneralKey{
	NSString *DecryptedData = @"";
	if (isGeneralKey) {
//		NSLog(@"DEC Key ==== %@",[DataValidation GetGeneralKey]);
		DecryptedData = [AESCrypt decrypt:strToDecrypt password:[DataValidation GetGeneralKey]];
	}
	else{
		NSString *strKey = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_KEY]];
//		NSLog(@"DEC Key ==== %@",strKey);
		
		DecryptedData = [AESCrypt decrypt:strToDecrypt password:strKey];
	}
	
//	NSLog(@"Dec data = %@",DecryptedData);
	return DecryptedData;
}

+(NSString *)GetGeneralKey{
	//NSLog(@"General Key = %@",[[NSBundle mainBundle] objectForInfoDictionaryKey:GENERAL_KEY]);
	//return [[NSBundle mainBundle] objectForInfoDictionaryKey:GENERAL_KEY];;
	return @"^^u|-!~l0gi3$";
}

-(NSString *)getEncryptedShareUrlId:(NSString *)str{
    
     NSString *strToCreate = [[self getEncryptedTextForString:str isGeneral:YES] stringByReplacingOccurrencesOfString:@"+" withString:@"_"];
    strToCreate = [strToCreate stringByReplacingOccurrencesOfString:@"/" withString:@"-"];
    
    return strToCreate;
}
-(NSString *)encodeString:(NSString *)strUrl{
    NSString * escapedUrlString =
    (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(
                                                        NULL,
                                                        (CFStringRef)strUrl,
                                                        NULL,
                                                        (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                        kCFStringEncodingUTF8 ));
    return  escapedUrlString;
}

-(void)highLightTextField:(id)tf inView:(id)view{
	
	[self resetTextFieldBorderColor];
	CAKeyframeAnimation * anim = [ CAKeyframeAnimation animationWithKeyPath:@"transform" ] ;
	anim.values = @[ [ NSValue valueWithCATransform3D:CATransform3DMakeTranslation(-5.0f, 0.0f, 0.0f) ], [ NSValue valueWithCATransform3D:CATransform3DMakeTranslation(5.0f, 0.0f, 0.0f) ] ] ;
	anim.autoreverses = YES ;
	anim.repeatCount = 2.0f ;
	anim.duration = 0.07f ;
	
	float xStart = 0;
	float yStart = 0;
	float width = DEVICE_WIDTH;
	float height = DEVICE_HEIGHT;
	
	if ([tf isKindOfClass:[UITextField class]]) {
		[ ((UITextField *)tf).layer addAnimation:anim forKey:nil ] ;
		xStart = ((UITextField *)tf).frame.origin.x-7;
		yStart = ((UITextField *)tf).frame.origin.y;
		width = ((UITextField *)tf).frame.size.width+14;
		height = ((UITextField *)tf).frame.size.height;
		
	}
	else if ([tf isKindOfClass:[UIButton class]]){
		xStart = ((UIButton *)tf).frame.origin.x-7;
		yStart = ((UIButton *)tf).frame.origin.y;
		width = ((UIButton *)tf).frame.size.width+14;
		height = ((UIButton *)tf).frame.size.height;
	}
	
	if (xStart<0) {
		xStart = 0;
	}
	if (yStart < 0) {
		yStart = 0;
	}
	if (width>DEVICE_WIDTH) {
		width = DEVICE_WIDTH;
	}
	if (height > DEVICE_HEIGHT) {
		height = DEVICE_HEIGHT;
	}
	
	self.imgBorderBox = [[UIImageView alloc] initWithFrame:CGRectMake(xStart, yStart, width, height)];
	self.imgBorderBox.backgroundColor = [UIColor clearColor];
	self.imgBorderBox.layer.borderWidth = 2;
	self.imgBorderBox.layer.borderColor = [UIColor redColor].CGColor;
	[view addSubview:self.imgBorderBox];
}

-(void)resetTextFieldBorderColor{
	[self.imgBorderBox removeFromSuperview];
//	[self.imgBorderBox release];
	self.imgBorderBox = nil;
}

-(NSArray *)SortArrayFromArray:(NSArray *)arrayToBeSorted throughKey:(NSString *)keyName{
	NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:keyName ascending:YES];
	NSArray *sortedArray=[arrayToBeSorted sortedArrayUsingDescriptors:[NSArray arrayWithObject:sort]];
	return sortedArray;
}
- (void) showLoadingView:(BOOL)show
{
    if(show)
    {
        if(self.loadingView == nil)
            self.loadingView = [UILoadingView loadingView];
        [self.loadingView showViewAnimated:NO onView:appDelegate.window.rootViewController.view];
    }
    else
    {
        [self.loadingView removeViewAnimated:NO];
    }
}
- (void) showPostToigViewController
{
/*
    PostToInstagramViewController* postToIgViewC = [[PostToInstagramViewController alloc] initWithNibName:@"PostToInstagramView" bundle:nil];
    UINavigationController* navC = [[UINavigationController alloc]
                                    initWithRootViewController:postToIgViewC];
    _window.rootViewController = navC;
    [navC release];
    _ReleaseObject(postToIgViewC);
 */
}
/*
 -(NSString *)encapsulateStringForURL:(NSString *)str{
 
 str = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
 str = [str stringByReplacingOccurrencesOfString:@"  " withString:@" "];
 
 NSString *result = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)str, NULL, CFSTR(":/?#[]@!$&’()*+,;="), kCFStringEncodingUTF8));
 return result;
 }
 */

#pragma mark	NSUserDefaults
-(void)removeAllKeyValue{
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:W_ID];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:LOGIN_USER_NAME];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:LOGIN_USER_EMAIL];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:LOGIN_USER_KEY];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:LOGIN_USER_DISPLAY_NAME];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:LOGIN_USER_PHONE];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:LOGIN_USER_PHOTOPATH];
    [[NSUserDefaults standardUserDefaults] setBool:FALSE forKey:IS_LOGIN];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:LOGIN_USER_ANNIVERSARY];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:LOGIN_USER_DOB];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:LOGIN_USER_DateOfBirth];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:LOGIN_USER_GENDER];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:LOGIN_USER_MAIDEN_NAME];
    
    [[NSUserDefaults standardUserDefaults] setBool:FALSE forKey:IsPrivate];
    [[NSUserDefaults standardUserDefaults] setBool:FALSE forKey:IS_APNS_OFF];
    [[NSUserDefaults standardUserDefaults] setBool:FALSE forKey:IS_QUIETMODE_ON];
    [[NSUserDefaults standardUserDefaults] setBool:FALSE forKey:IS_SAVE_TO_GALLERY];
    
    
    [[NSUserDefaults standardUserDefaults] setValue:nil forKey:FB_ID];
    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_FROM_SIGN_UP];
    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_CONVOS];
    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_FRIENDLIST];
    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_REMINDER];
    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_SENDBLAB];
    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_SETTING];
    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_FRIEND_REMINDER];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
	
	[[UIApplication sharedApplication] setApplicationIconBadgeNumber: 0];
	[[UIApplication sharedApplication] cancelAllLocalNotifications];
	
	[FBSession.activeSession closeAndClearTokenInformation];
    
    //clean Validation.dicNotifCount dictionary that stores notification count
    Validation.dicNotifCount = [NSDictionary
                                dictionaryWithObjectsAndKeys:
                                @"0",TOTAL_FRIENDS_REQUEST,
                                @"0",TOTAL_UNREAD_NOTIF,
                                @"0",TOTAL_KEEP_REQUEST,
                                @"0", TOTAL_NOTIF_COUNT,
                                @"0",TOTAL_ALARM_REQUEST,
                                nil];
	[self clearImageCache];
	[self.adView.adBanner cancelBannerViewAction];
	[self.adView removeFromSuperview];
//	[self.adView release];
	self.adView = nil;
	
}
-(void)clearImageCache{
	[[AsyncImageLoader sharedLoader].cache removeAllObjects];
}

-(void)setAudioPropertyForRecording{
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    NSError *err = NULL;
    [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord error:&err];
    if( err ){
        NSLog(@"There was an error creating the audio session");
    }
    [audioSession overrideOutputAudioPort:AVAudioSessionPortOverrideSpeaker error:NULL];
    if( err ){
        NSLog(@"There was an error sending the audio to the speakers");
    }
}

-(void)setAllKeyValueFromData:(id)response{
	if ([response isKindOfClass:[NSDictionary class]]) {
		
		NSString *strUserName = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:USER_NAME]]];
		NSString *strUserId = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:USER_ID]]];
		NSString *strEmail = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:EMAIL]]];
		NSString *strFBID = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:FB_ID]]];
		NSString *strDisplayName = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:LOGIN_USER_DISPLAY_NAME]]];
        NSString *strMaidenName = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:LOGIN_USER_MAIDEN_NAME]]];
		NSString *strPhone = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:LOGIN_USER_PHONE]]];
		NSString *strPhoto = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:LOGIN_USER_PHOTOPATH]]];
		NSString *strKey = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:LOGIN_USER_KEY]]];
		NSString *strIsAPNS_Off	= [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:IS_APNS_OFF]]];
		NSString *strDOB = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:LOGIN_USER_DOB]]];
        NSString *strDateOfBirth = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:LOGIN_USER_DateOfBirth]]];
        NSString *strAnniversary = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:LOGIN_USER_ANNIVERSARY]]];
        NSString *strGender = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:LOGIN_USER_GENDER]]];
        NSString *strProfile = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:IsPrivate]]];
		NSString *strIsQuietModeOff = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:IS_QUIETMODE_ON]]];
        
        

		if (strUserName.length > 0) {
			[[NSUserDefaults standardUserDefaults] setValue:strUserName forKey:LOGIN_USER_NAME];
		}
		if (strUserId.length > 0) {
			[[NSUserDefaults standardUserDefaults] setValue:strUserId forKey:W_ID];
		}
		if (strEmail.length>0) {
			[[NSUserDefaults standardUserDefaults] setValue:strEmail forKey:LOGIN_USER_EMAIL];
		}
        if (strMaidenName.length>0) {
            [[NSUserDefaults standardUserDefaults] setValue:strMaidenName forKey:LOGIN_USER_MAIDEN_NAME];
        }
		if (strFBID.length>0) {
			[[NSUserDefaults standardUserDefaults] setValue:strFBID forKey:FB_ID];
		}
		if (strDisplayName.length>0) {
			[[NSUserDefaults standardUserDefaults] setValue:strDisplayName forKey:LOGIN_USER_DISPLAY_NAME];
		}
		if (strPhone.length > 0) {
			[[NSUserDefaults standardUserDefaults] setValue:strPhone forKey:LOGIN_USER_PHONE];
		}
        else{
            [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:LOGIN_USER_PHONE];
        }
		if (strPhoto.length > 0) {
			[[NSUserDefaults standardUserDefaults] setValue:strPhoto forKey:LOGIN_USER_PHOTOPATH];
			[[AsyncImageLoader sharedLoader].cache removeObjectForKey:[NSURL URLWithString:strPhoto]];
		}
		if (strKey.length > 0)  {
			[[NSUserDefaults standardUserDefaults] setValue:strKey forKey:LOGIN_USER_KEY];
		}
		if (strIsAPNS_Off.length > 0) {
			[[NSUserDefaults standardUserDefaults] setBool:[strIsAPNS_Off boolValue] forKey:IS_APNS_OFF];
		}
		if (strDOB.length > 0) {
			[[NSUserDefaults standardUserDefaults] setValue:strDOB forKey:LOGIN_USER_DOB];
		}
        if (strDateOfBirth.length > 0) {
			[[NSUserDefaults standardUserDefaults] setValue:strDateOfBirth forKey:LOGIN_USER_DateOfBirth];
		}
        if (strAnniversary.length > 0) {
			[[NSUserDefaults standardUserDefaults] setValue:strAnniversary forKey:LOGIN_USER_ANNIVERSARY];
		}
        if (strGender.length > 0) {
			[[NSUserDefaults standardUserDefaults] setValue:strGender forKey:LOGIN_USER_GENDER];
		}
        if (strProfile.length > 0) {
            [[NSUserDefaults standardUserDefaults] setBool:[strProfile boolValue] forKey:IsPrivate];
        }
        if (strIsQuietModeOff.length > 0) {
            [[NSUserDefaults standardUserDefaults] setBool:[strIsQuietModeOff boolValue] forKey:IS_QUIETMODE_ON];
        }

        [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:IS_SAVE_TO_GALLERY];
		[[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:IS_LOGIN];
		[[NSUserDefaults standardUserDefaults] synchronize];
		
		NSLog(@"%@",[NSNumber numberWithBool:[[NSUserDefaults standardUserDefaults] boolForKey:IS_APNS_OFF]]);
		strUserName = nil;
		strUserId = nil;
		strEmail = nil;
		strFBID = nil;
		strDisplayName = nil;
		strPhone = nil;
		strPhoto = nil;
		strKey = nil;
		strIsAPNS_Off = nil;
	}
}
/*
-(void)setMatTrackingForRegisterAndLogin:(NSDictionary*)response index:(int)index{
    NSString *strUserName = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:USER_NAME]]];
    NSString *strUserId = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:USER_ID]]];
    NSString *strEmail = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:EMAIL]]];
    NSString *strFBID = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[response valueForKey:FB_ID]]];
    
    
    [MobileAppTracker setUserEmail:strEmail];
    [MobileAppTracker setUserName:strUserName];
    [MobileAppTracker setUserId:strUserId];
    
    if (strFBID.length !=0) {
        [MobileAppTracker setFacebookUserId:strFBID];
    }
    
    if (index==0) {
        [MobileAppTracker measureEventName:@"registration"];
    }
    else{
        [MobileAppTracker measureEventName:@"login"];
    }
}

-(void)setMatTrackingForSearch:(NSString*)searchStr{
//    MATEventItem *item1 = [MATEventItem eventItemWithName:@"deluxe room" unitPrice:129.99 quantity:1 revenue:129.99 attribute1:@"double" attribute2:@"free wifi" attribute3:@"view" attribute4:@"gym" attribute5:nil];
//    MATEventItem *item1 = [MATEventItem eventItemWithName:<#(NSString *)#> unitPrice:<#(float)#> quantity:<#(int)#>]
//    NSArray *eventItems = @[item1];
    
    [MobileAppTracker setUserId:[[NSUserDefaults standardUserDefaults] objectForKey:USER_ID]];
    if ([DataValidation checkNullString:[[NSUserDefaults standardUserDefaults] objectForKey:FB_ID]].length!=0) {
        [MobileAppTracker setFacebookUserId:[[NSUserDefaults standardUserDefaults] objectForKey:FB_ID]];
    }
    
    
    MATEvent *event = [MATEvent eventWithName:@"search"];
//    event.currencyCode = @"USD";
    event.searchString = searchStr;
    event.date1 = [NSDate date];
    event.date2 = [NSDate dateWithTimeIntervalSinceNow:86400];
    event.quantity = 1;
//    event.eventItems = eventItems;
    
    [MobileAppTracker measureEvent:event];
}
*/ 
-(BOOL)setOverlayFlags:(int)selOverlay{
    NSLog(@"IS_FROM_SIGN_UP %@",[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_FROM_SIGN_UP]]);
    if ([[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_FROM_SIGN_UP]] boolValue]) {
        NSLog(@"IS_FROM_SIGN_UP done %@",[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_FROM_SIGN_UP]]);
    }
    else{
        NSLog(@"IS_FROM_SIGN_UP not done %@",[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_FROM_SIGN_UP]]);
    }
    if (![[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_FROM_SIGN_UP]] boolValue]) {
        BOOL flag;
        switch (selOverlay) {
            case 1:{
                if ([[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_OVERLAY_VIEWED_CONVOS]] boolValue]) {
                    flag = NO;
                }
                else{
                    flag = YES;
                }
                [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_CONVOS];
            }
                break;
            case 2:{
                if ([[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_OVERLAY_VIEWED_FRIENDLIST]] boolValue]) {
                    flag = NO;
                }
                else{
                    flag = YES;
                }
                [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_FRIENDLIST];
            }
                break;
            case 3:{
                if ([[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_OVERLAY_VIEWED_REMINDER]] boolValue]) {
                    flag = NO;
                }
                else{
                    flag = YES;
                }
                [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_REMINDER];
            }
                break;
            case 4:
                if ([[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_OVERLAY_VIEWED_SETTING]] boolValue]) {
                    flag = NO;
                }
                else{
                    flag = YES;
                }
                [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_SETTING];
                break;
            case 5:{
                if ([[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_OVERLAY_VIEWED_SENDBLAB]] boolValue]) {
                    flag = NO;
                }
                else{
                    flag = YES;
                }
                [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_SENDBLAB];
            }
                break;
            case 6:{
                if ([[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_OVERLAY_VIEWED_FRIEND_REMINDER]] boolValue]) {
                    flag = NO;
                }
                else{
                    flag = YES;
                }
                [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_OVERLAY_VIEWED_FRIEND_REMINDER];
            }
                break;
            default:
                break;
        }
        [[NSUserDefaults standardUserDefaults] synchronize];
        return flag;
    }
    else{
        return NO;
    }
}
-(void)DisableScreenLockWhilePlaying:(BOOL)isDisable{
    if (isDisable) {
        [UIApplication sharedApplication].idleTimerDisabled = YES;
        [UIApplication sharedApplication].idleTimerDisabled = NO;
    }
    else{
        [UIApplication sharedApplication].idleTimerDisabled = NO;
//        [UIApplication sharedApplication].idleTimerDisabled = YES;
    }
}
#pragma mark	loader message

-(UIView *)showPullToRefreshLoaderInView:(UIRefreshControl *)refreshControl{
    self.viewPullToRefresh = [[UIView alloc] initWithFrame:refreshControl.bounds];
    self.viewPullToRefresh.backgroundColor = [UIColor clearColor];
    
    // Create the graphic image views
    self.imgLoading = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon_yapeey_logo.png"]];
   // self.imgLoading.frame = CGRectMake(0, 0, 40, 40);
    CGRect refreshBounds = refreshControl.bounds;
    
    // Distance the table has been pulled >= 0
    CGFloat pullDistance = MAX(0.0, - refreshControl.frame.origin.y);
    
    // Half the width of the table
    CGFloat midX = refreshControl.frame.size.width / 2.0;
    
    CGFloat spinnerHeight = Validation.imgLoading.bounds.size.height;
    CGFloat spinnerHeightHalf = spinnerHeight / 2.0;
    
    CGFloat spinnerWidth = Validation.imgLoading.bounds.size.width;
    CGFloat spinnerWidthHalf = spinnerWidth / 2.0;
    
    // Calculate the pull ratio, between 0.0-1.0
    CGFloat pullRatio = MIN( MAX(pullDistance, 0.0), 100.0) / 100.0;
    
    CGFloat spinnerY = pullDistance / 2.0 - spinnerHeightHalf;
    
    CGFloat spinnerX = (midX - spinnerWidth - spinnerWidthHalf) + (spinnerWidth * pullRatio);
    
    // If the graphics have overlapped or we are refreshing, keep them together
    CGRect spinnerFrame = Validation.imgLoading.frame;
    spinnerFrame.origin.x = spinnerX;
    spinnerFrame.origin.y = spinnerY;
    
    self.imgLoading.frame = spinnerFrame;
    
    // Set the encompassing view's frames
    refreshBounds.size.height = pullDistance;
    
    self.viewPullToRefresh.frame = refreshBounds;
    
    [self.viewPullToRefresh addSubview:self.imgLoading];
     self.viewPullToRefresh.clipsToBounds = YES;
    
    return self.viewPullToRefresh;
    
}

-(void)showLoadingIndicator{
	[self hideLoadingIndicator];
	
	self.toast = [[ToastMessageView alloc] initWithFrame:CGRectMake(0, 0, DEVICE_WIDTH, DEVICE_HEIGHT)];
	UIWindow* window = [UIApplication sharedApplication].keyWindow;
	if (!window)
		window = [[UIApplication sharedApplication].windows objectAtIndex:0];
	[[[window subviews] objectAtIndex:0] addSubview:self.toast];

	[self.toast ShowLoader];
}

-(void)showLoadingIndicatorInView:(id)view{
	if ([view isKindOfClass:[UITableView class]]) {
		UITableView *v = (UITableView *)view;
		self.toast = [[ToastMessageView alloc] initWithFrame:CGRectMake(0, 0, DEVICE_WIDTH, v.frame.size.height)];
	}
	else if ([view isKindOfClass:[UITableViewHeaderFooterView class]]){
		UITableViewHeaderFooterView *v = (UITableViewHeaderFooterView *)view;
		self.toast = [[ToastMessageView alloc] initWithFrame:CGRectMake(0, 0, DEVICE_WIDTH, v.frame.size.height)];
	}
    else if ([view isKindOfClass:[UIView class]]){
        UIView *v = (UIView *)view;
        self.toast = [[ToastMessageView alloc] initWithFrame:CGRectMake(0, 0, DEVICE_WIDTH, v.frame.size.height)];
    }
	[view addSubview:self.toast];
	//[self.toast ShowLoader];
	[self.toast ShowTableLoader];
	
	//[self.toast.viewUserNotTouchable setBackgroundColor:[UIColor whiteColor]];
}
/*
-(void)showAudioPlayIndicator{
	
	if (self.toastAPNS != nil) {
		[self.toastAPNS removeFromSuperview];
		[self hideAudioLoader];
	}
	else{
		self.toastAPNS = [[ToastMessageView alloc] initWithFrame:CGRectMake(0, 0, DEVICE_WIDTH, DEVICE_HEIGHT)];
	}
//	UIWindow* window = [UIApplication sharedApplication].keyWindow;
//	if (!window)
//		window = [[UIApplication sharedApplication].windows objectAtIndex:0];
//	[[[window subviews] objectAtIndex:0] addSubview:self.toastAPNS];
	[self.toastAPNS ShowLoader];
}

-(void)hideAudioLoader{
	[self.toastAPNS hideAudioLoader];
	[self.toastAPNS removeFromSuperview];
	[self.toastAPNS release];
	self.toastAPNS = nil;
}
*/

-(void)hideLoadingIndicator{
	[self.toast hideLoader];
	
	if (self.toast !=  nil) {
		[self.toast removeFromSuperview];
//		[self.toast release];
		self.toast = nil;
	}
}

- (BOOL) isKeyboardOnScreen
{
    BOOL isKeyboardShown = NO;
	
    NSArray *windows = [UIApplication sharedApplication].windows;
    if (windows.count > 1) {
        NSArray *wSubviews =  [windows[1]  subviews];
        if (wSubviews.count) {
            CGRect keyboardFrame = [wSubviews[0] frame];
            CGRect screenFrame = [windows[1] frame];
            if (keyboardFrame.origin.y+keyboardFrame.size.height == screenFrame.size.height) {
                isKeyboardShown = YES;
            }
        }
    }
	
    return isKeyboardShown;
}
-(void)showToastMessage:(NSString *)msg displayDuration:(float)duration{
	
	[self hideLoadingIndicator];
	
	self.toast = [[ToastMessageView alloc] initWithFrame:CGRectMake(0, 0, DEVICE_WIDTH, ([self isKeyboardOnScreen])?320:DEVICE_HEIGHT)];
	[self.toast LoadWithMessage:msg];
	self.toast.alpha = 0;
	UIWindow* window = [UIApplication sharedApplication].keyWindow;
	if (!window)
		window = [[UIApplication sharedApplication].windows objectAtIndex:0];
	
    if (self.isAPNS_Visible) {
        [[[window subviews] objectAtIndex:0] insertSubview:self.toast belowSubview:self.apnsPopUp];
    }
    else{
        [[[window subviews] objectAtIndex:0] addSubview:self.toast];
    }
    

	
	[self fadeInToast];
	[self performSelector:@selector(fadeOutToast) withObject:0 afterDelay:duration];
}
-(void)showToastMessageBigText:(NSString *)msg displayDuration:(float)duration{
    
    [self hideLoadingIndicator];
    
    self.toast = [[ToastMessageView alloc] initWithFrame:CGRectMake(0, 0, DEVICE_WIDTH, ([self isKeyboardOnScreen])?320:DEVICE_HEIGHT)];
    [self.toast LoadWithBigMessage:msg];
    self.toast.alpha = 0;
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    if (!window)
        window = [[UIApplication sharedApplication].windows objectAtIndex:0];
    
    if (self.isAPNS_Visible) {
        [[[window subviews] objectAtIndex:0] insertSubview:self.toast belowSubview:self.apnsPopUp];
    }
    else{
        [[[window subviews] objectAtIndex:0] addSubview:self.toast];
    }
    
    
    
    [self fadeInToast];
    [self performSelector:@selector(fadeOutToast) withObject:0 afterDelay:duration];
}
-(void)fadeInToast{
	[UIView beginAnimations:@"showToast" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.5];
	self.toast.alpha = 1;
	[UIView commitAnimations];
}

-(void)fadeOutToast{
	[UIView beginAnimations:@"hideToast" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.5];
	[UIView setAnimationDidStopSelector:@selector(removeToastFromMemory)];
	[UIView setAnimationDelegate:self];
	self.toast.alpha = 0;
	[UIView commitAnimations];
}

-(void)removeToastFromMemory{
	[self.toast removeToastControls];
	[self.toast removeFromSuperview];
//	[self.toast release];
	self.toast = nil;
}

#pragma mark	Cartoon Character

-(void)removeCartoonCharAnimation{
	
	[self.imgCartoon stopAnimating];
	[self.imgCartoon removeFromSuperview];
//	[self.imgCartoon release];
	self.imgCartoon = nil;
}

-(void)showCarttonCharacterAnimation{
	
	self.imgCartoon = [[UIImageView alloc] initWithFrame:CGRectMake((DEVICE_WIDTH-500)/2, (DEVICE_HEIGHT-400)/2, 500, 400)];
	UIWindow* window = [UIApplication sharedApplication].keyWindow;
	if (!window)
		window = [[UIApplication sharedApplication].windows objectAtIndex:0];
	[[[window subviews] objectAtIndex:0] addSubview:self.imgCartoon];
	
	
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	
	for (int i=1; i<30; i++) {
		[arr addObject:[UIImage imageNamed:[NSString stringWithFormat:@"sample_%d.png",i]]];
	//	NSLog(@"i = %d",i);
	}
	self.imgCartoon.animationImages = arr;
	self.imgCartoon.animationDuration = AnimationDuration;
//	self.imgCartoon.animationRepeatCount = 1;
	[self.imgCartoon startAnimating];
//	[arr release];
	arr = nil;
	
	[self performSelector:@selector(setCartoonImageAfterAnimation) withObject:nil afterDelay:AnimationDuration-0.1];
	
}

-(void)setCartoonImageAfterAnimation{
	[self.imgCartoon stopAnimating];
	[self.imgCartoon setImage:[UIImage imageNamed:@"sample_29.png"]];
}
-(void)HidingCartoonChar{
	
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	for (int i=29; i>=1; i--) {
		[arr addObject:[UIImage imageNamed:[NSString stringWithFormat:@"sample_%d.png",i]]];
	}
	self.imgCartoon.animationImages = arr;
	self.imgCartoon.animationDuration = AnimationDuration;
	self.imgCartoon.animationRepeatCount = 1;
	[self.imgCartoon startAnimating];
	
//	[arr release];
	arr = nil;
	
	[self performSelector:@selector(removeCartoonCharAnimation) withObject:nil afterDelay:AnimationDuration-0.1];
}

#pragma mark UIImage related Methods
-(NSData *)compressImage:(UIImage *)img{
	NSLog(@"%d",(int)[UIImageJPEGRepresentation(img, 1) length]);
	NSData *imageData = UIImageJPEGRepresentation(img, 0.25);
    NSLog(@"%d",(int)[imageData length]);
	return  imageData;
}
-(void)setCorners:(id)img {
	
	if ([img isKindOfClass:[UIImageView class]]) {
		UIImageView *imgNew = (UIImageView *)img;
//		imgNew.layer.cornerRadius = (imgNew.frame.size.height*0.47);
		imgNew.layer.cornerRadius = (imgNew.frame.size.height*0.5);
		imgNew.layer.masksToBounds = YES;
	}
	else if ([img isKindOfClass:[UILabel class]]){
		UILabel *lblNew = (UILabel *)img;
		lblNew.layer.cornerRadius = (lblNew.frame.size.height*0.5);
		lblNew.layer.masksToBounds = YES;
	}
    else if ([img isKindOfClass:[UIView class]]){
        UIView *view = (UIView *)img;
        view.layer.cornerRadius = (view.frame.size.height*0.5);
        view.layer.masksToBounds = YES;
    }
    else if ([img isKindOfClass:[UIButton class]]){
        UIButton *btn = (UIButton *)img;
        btn.layer.cornerRadius = (btn.frame.size.height*0.5);
        btn.layer.masksToBounds = YES;
    }
}

#pragma mark	UIColor
-(UIColor *)getColor:(NSString*)col{
	
	SEL selColor = NSSelectorFromString(col);
	UIColor *color = nil;
	if ( [UIColor respondsToSelector:selColor] == YES) {
		
		color = [UIColor performSelector:selColor];
	}
    return color;
}

-(UIColor*)DarkColorWithHexString:(NSString*)strCharacter
{
	NSString *hex = [self.arrColor valueForKey:[strCharacter lowercaseString]];
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
	
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor grayColor];
	
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
	
    if ([cString length] != 6) return  [UIColor grayColor];
	
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
	
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
	
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
	
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
	
    return 	[self darkerColorForColor:[UIColor colorWithRed:((float) r / 255.0f)
													  green:((float) g / 255.0f)
													   blue:((float) b / 255.0f)
													  alpha:1.0f]];
}

- (UIColor *)lighterColorForColor:(UIColor *)c
{
    CGFloat r, g, b, a;
    if ([c getRed:&r green:&g blue:&b alpha:&a])
        return [UIColor colorWithRed:MIN(r + 0.2, 1.0)
                               green:MIN(g + 0.2, 1.0)
                                blue:MIN(b + 0.2, 1.0)
                               alpha:a];
    return nil;
}

- (UIColor *)darkerColorForColor:(UIColor *)c
{
    CGFloat r, g, b, a;
    if ([c getRed:&r green:&g blue:&b alpha:&a])
        return [UIColor colorWithRed:MAX(r - 0.2, 0.0)
                               green:MAX(g - 0.2, 0.0)
                                blue:MAX(b - 0.2, 0.0)
                               alpha:a];
    return nil;
}

-(UIColor *)getColorForAlphabet:(NSString *)strCharacter{
	strCharacter = [strCharacter stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	strCharacter = [strCharacter substringToIndex:1];
	
	unsigned int outVal;
    
    NSScanner* scanner = nil;
    
    BOOL isSpecialChar = [self checkSpecialChar:[strCharacter lowercaseString]];
    
    if (isSpecialChar) {
        NSLog(@"special Char = %d",isSpecialChar);
        scanner = [NSScanner scannerWithString:@"0X000000"];
    }
    else{
        scanner = [NSScanner scannerWithString:[self.arrColor valueForKey:[strCharacter lowercaseString]]];
    }

	[scanner scanHexInt:&outVal];
	UIColor *fontColor = UIColorFromRGB(outVal);
	if (fontColor == nil) {
		return [UIColor blackColor];
	}
	return fontColor;
}

-(BOOL)checkSpecialChar:(NSString *)str{
 //   NSLog(@"check special Char = %@",str);
    NSCharacterSet * set = [[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789#"] invertedSet];
    
    if ([str rangeOfCharacterFromSet:set].location != NSNotFound) {
      //  NSLog(@"This string contains illegal characters");
        return TRUE;
    }
    return FALSE;
//    return [str rangeOfCharacterFromSet:[NSCharacterSet symbolCharacterSet]].location != NSNotFound;
}

-(void)setArrayOfColor{
	NSArray * colorKeys = [NSArray arrayWithObjects:@"a", @"b", @"c", @"d", @"e", @"f", @"g", @"h", @"i", @"j", @"k", @"l", @"m", @"n", @"o", @"p", @"q", @"r", @"s", @"t", @"u", @"v", @"w", @"x", @"y", @"z", @"0", @"1", @"2", @"3", @"4", @"5", @"6", @"7", @"8", @"9",@"#", nil];
	NSArray * colorValues = [NSArray arrayWithObjects:@"0X00c2d9",@"0Xff5252", @"0X43a047", @"0Xfcb732", @"0X5064aa", @"0Xad4ee3", @"0Xfd6631", @"0X008984", @"0X5c54e4", @"0X1b9af7", @"0Xa5de37", @"0Xed4694", @"0X7b72e9", @"0Xfeae1b", @"0X00bfa5", @"0Xd32f2f", @"0Xde6e00", @"0X2979ff", @"0Xfbc02d", @"0X689f38", @"0X3f51b5", @"0Xff5722", @"0X7e57c2", @"0Xff9e00", @"0X2196f3", @"0Xec407a", @"0X00c853", @"0Xff6d00", @"0Xab47bc", @"0Xb71c1c", @"0X01579b", @"0X4caf50", @"0X8e24aa", @"0Xf58d40", @"0X00a5ae", @"0Xe7528a", @"0X4e5462", nil];
	
	self.arrColor = [NSMutableDictionary dictionaryWithObjects:colorValues forKeys:colorKeys];
}

#pragma mark	Contact List

+(NSArray *)getAllContacts
{
    CFErrorRef *error = nil;
    ABAddressBookRef addressBook = ABAddressBookCreateWithOptions(NULL, error);
	
    __block BOOL accessGranted = NO;
    if (ABAddressBookRequestAccessWithCompletion != NULL) { // we're on iOS 6
        dispatch_semaphore_t sema = dispatch_semaphore_create(0);
        ABAddressBookRequestAccessWithCompletion(addressBook, ^(bool granted, CFErrorRef error) {
			accessGranted = granted;
			dispatch_semaphore_signal(sema);
        });
        dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
		
    }
    else { // we're on iOS 5 or older
        accessGranted = YES;
    }
	
    if (accessGranted) {
		
#ifdef DEBUG
        NSLog(@"Fetching contact info ----> ");
#endif
		CFArrayRef allPeople = ABAddressBookCopyArrayOfAllPeople(addressBook);

        CFIndex nPeople = ABAddressBookGetPersonCount(addressBook);
        NSMutableArray* items = [[NSMutableArray alloc] init] ;
		
		
        for (int i = 0; i < nPeople; i++)
        {
            ABRecordRef person = CFArrayGetValueAtIndex(allPeople, i);

           ABMultiValueRef multiPhones = ABRecordCopyValue(person, kABPersonPhoneProperty);
			NSLog(@"%@",multiPhones);
			
			NSString *phoneNumber = @"";
            for(CFIndex i=0;i<ABMultiValueGetCount(multiPhones);i++) {
				
				NSString  *phoneNumberRef = (__bridge NSString *)ABMultiValueCopyLabelAtIndex(multiPhones, i);
				
				if ([phoneNumberRef isEqualToString:(__bridge NSString *)kABPersonPhoneMobileLabel] ) {
					phoneNumber = [[(__bridge NSString *)ABMultiValueCopyValueAtIndex(multiPhones, i) componentsSeparatedByCharactersInSet:
											  [[NSCharacterSet decimalDigitCharacterSet] invertedSet]]
											 componentsJoinedByString:@""];
					
					break;
				}
				else if ([phoneNumberRef isEqualToString:(__bridge NSString *)kABPersonPhoneIPhoneLabel]){
					phoneNumber = [[(__bridge NSString *)ABMultiValueCopyValueAtIndex(multiPhones, i) componentsSeparatedByCharactersInSet:
									[[NSCharacterSet decimalDigitCharacterSet] invertedSet]]
								   componentsJoinedByString:@""];
					
					break;
				}
            }
			if ([self checkNullString:phoneNumber].length>0) {
				[items addObject: phoneNumber];
			}
			
			CFRelease(person);
        }
		CFRelease(addressBook);
        return items;
				
    } else {
		[AlertHandler alertTitle:MESSAGE message:@"You have not shared your contact list with Blabeey. Please go to settings-> Privacy -> Contacts -> Blabeey and enable your sharing." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
		
#ifdef DEBUG
        NSLog(@"Cannot fetch Contacts :( ");
#endif
        return nil;     //return NO;
    }
}

- (NSDictionary*)parseURLParams:(NSString *)query {
    NSArray *pairs = [query componentsSeparatedByString:@"&"];
    NSMutableDictionary *params = [[NSMutableDictionary alloc] init] ;
    for (NSString *pair in pairs) {
        NSArray *kv = [pair componentsSeparatedByString:@"="];
        NSString *val =
        [kv[1] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        params[kv[0]] = val;
    }
    return params;
}

- (ShowiAdsView *) sharedBannerView
{
    if (self.adView == nil)
    {
        Class classAdBannerView = NSClassFromString(@"ShowiAdsView");
		
        if (classAdBannerView != nil)
        {
            self.adView = [[ShowiAdsView alloc] initWithFrame:CGRectMake(0, DEVICE_HEIGHT-50, 320, 50)];
			self.adView.backgroundColor = [UIColor clearColor];
            // pre 4.2 doesn't have the new AdBannerSize constants.
			//            if (&ADBannerContentSizeIdentifierPortrait != NULL)
			//            {
			//                [_sharedBannerView setRequiredContentSizeIdentifiers:[NSSet setWithObjects:ADBannerContentSizeIdentifierPortrait, ADBannerContentSizeIdentifierLandscape, nil]];
			//            }
			//            else
			//            {
			//                [_sharedBannerView setRequiredContentSizeIdentifiers:[NSSet setWithObjects:ADBannerContentSizeIdentifier320x50, ADBannerContentSizeIdentifier480x32, nil]];
			//            }
        }
    }
	
    [self.adView setDelegateToAdView];
	
    return self.adView;
}

-(void)decreaseTableSize{
	
    self.adView.frame = CGRectMake(0, DEVICE_HEIGHT-50, 320, 50);
    
	int height = DEVICE_HEIGHT;
	[UIView beginAnimations:@"setTblFrame" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.5];
	
    
	if ([appDelegate.currentVc isKindOfClass:[NotificationVC class]]) {
		NotificationVC *obj = (NotificationVC *)appDelegate.currentVc;
		float yStart = obj.tblData.frame.origin.y;
		obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, height-yStart-50);
	}
	else if ([appDelegate.currentVc isKindOfClass:[SearchFriendVC class]]){
		SearchFriendVC *obj = (SearchFriendVC *)appDelegate.currentVc;
		float yStart = obj.tblData.frame.origin.y;
		obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, height-yStart-50);
//        self.adView.frame = CGRectMake(0, obj.tblData.frame.origin.y+obj.tblData.frame.size.height, 320, 50);
	}
    else if ([appDelegate.currentVc isKindOfClass:[LocationVC class]]){
		LocationVC *obj = (LocationVC *)appDelegate.currentVc;
        //		float yStart = obj.tblData.frame.origin.y;
        //		obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, height-yStart-50);
        //self.adView.frame = CGRectMake(0, obj.tblData.frame.origin.y+obj.tblData.frame.size.height-50, 320, 50);
        self.adView.frame = CGRectMake(0, obj.tblData.frame.origin.y+obj.tblData.frame.size.height, 320, 50);
	}
	else if ([appDelegate.currentVc isKindOfClass:[OtherFriendNotifListVC class]]){
		OtherFriendNotifListVC *obj = (OtherFriendNotifListVC *)appDelegate.currentVc;
		float yStart = obj.tblData.frame.origin.y;
		obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, height-yStart-50);
	}
	else if ([appDelegate.currentVc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
		AddFriendFromExistingFriendListVC *obj = (AddFriendFromExistingFriendListVC *)appDelegate.currentVc;
		float yStart = obj.tblData.frame.origin.y;
		obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, height-yStart-50);
	}
//    else if ([appDelegate.currentVc isKindOfClass:[SettingsVC class]]){
//        SettingsVC *obj = (SettingsVC *)appDelegate.currentVc;
//        float yStart = obj.tblData.frame.origin.y;
//        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, height-yStart-50);
//    }
    else if ([appDelegate.currentVc isKindOfClass:[NotifOptionVC class]]){
        NotifOptionVC *obj = (NotifOptionVC *)appDelegate.currentVc;
        float yStart = obj.tblData.frame.origin.y;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, height-yStart-50);
    }
    else if ([appDelegate.currentVc isKindOfClass:[CategoryListForUploadVC class]]){
        CategoryListForUploadVC *obj = (CategoryListForUploadVC *)appDelegate.currentVc;
        float yStart = obj.tblData.frame.origin.y;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, height-yStart-50);
    }
    else if ([appDelegate.currentVc isKindOfClass:[FavoritesVC class]]){
        FavoritesVC *obj = (FavoritesVC *)appDelegate.currentVc;
        float yStart = obj.tblData.frame.origin.y;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, height-yStart-50);
    }
    else if ([appDelegate.currentVc isKindOfClass:[GroupListVC class]]){
        GroupListVC *obj = (GroupListVC *)appDelegate.currentVc;
        float yStart = obj.tblData.frame.origin.y;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, height-yStart-50);
    }
    else if ([appDelegate.currentVc isKindOfClass:[UserListVC class]]){
        UserListVC *obj = (UserListVC *)appDelegate.currentVc;
        float yStart = obj.tblData.frame.origin.y;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, height-yStart-50);
    }
    else if ([appDelegate.currentVc isKindOfClass:[RecordingOptionVC class]]){
        //there is no table
    }
    else if ([appDelegate.currentVc isKindOfClass:[RecrodingVC class]]){
        RecrodingVC *obj = (RecrodingVC *)appDelegate.currentVc;
        float yStart = obj.scrlView.frame.origin.y;
        obj.scrlView.frame = CGRectMake(0, obj.scrlView.frame.origin.y, DEVICE_WIDTH, height-yStart-50);
    }
    else if ([appDelegate.currentVc isKindOfClass:[AlarmMainVC class]]){
        AlarmMainVC *obj = (AlarmMainVC *)appDelegate.currentVc;
        float yStart = obj.tblData.frame.origin.y;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, height-yStart-50);
    }
    else if ([appDelegate.currentVc isKindOfClass:[AlarmRequestListVC class]]){
        AlarmRequestListVC *obj = (AlarmRequestListVC *)appDelegate.currentVc;
        float yStart = obj.tblData.frame.origin.y;
        obj.tblData.frame = CGRectMake(0, obj.tblData.frame.origin.y, DEVICE_WIDTH, height-yStart-50);
    }
    else if ([appDelegate.currentVc isKindOfClass:[ShowItemListForSelectedStoreVC class]]){
        ShowItemListForSelectedStoreVC *obj = (ShowItemListForSelectedStoreVC *)appDelegate.currentVc;
        float yStart = obj.collectionView.frame.origin.y;
        obj.collectionView.frame = CGRectMake(0, obj.collectionView.frame.origin.y, DEVICE_WIDTH, height-yStart-50);
    }
    else if ([appDelegate.currentVc isKindOfClass:[GroupUserListVC class]]){
        GroupUserListVC *obj = (GroupUserListVC *)appDelegate.currentVc;
        float yStart = obj.tblData.frame.origin.y;
        obj.tblData.frame = CGRectMake(0, obj.tblData.frame.origin.y, DEVICE_WIDTH, height-yStart-50);
        
        if (obj.objUserListVC != nil) {
            obj.objUserListVC.view.frame = CGRectMake(0, 68, 320, height-(68+1+50));
            obj.objUserListVC.tblData.frame = CGRectMake(0, ([obj.objUserListVC.lblInfo isHidden])?0:18, 320, obj.objUserListVC.view.frame.size.height-18);
        }
    }
    
	[UIView commitAnimations];
}

-(void)increaseTableSize{
	int height = DEVICE_HEIGHT;
	[UIView beginAnimations:@"setTblFrame" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.5];
	
	if ([appDelegate.currentVc isKindOfClass:[NotificationVC class]]) {
		NotificationVC *obj = (NotificationVC *)appDelegate.currentVc;
		obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
	}
	else if ([appDelegate.currentVc isKindOfClass:[SearchFriendVC class]]){
		SearchFriendVC *obj = (SearchFriendVC *)appDelegate.currentVc;
		obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
	}
    else if ([appDelegate.currentVc isKindOfClass:[LocationVC class]]){
//		LocationVC *obj = (LocationVC *)appDelegate.currentVc;
//        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
	}
	else if ([appDelegate.currentVc isKindOfClass:[OtherFriendNotifListVC class]]){
		OtherFriendNotifListVC *obj = (OtherFriendNotifListVC *)appDelegate.currentVc;
		obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
	}
	else if ([appDelegate.currentVc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
		AddFriendFromExistingFriendListVC *obj = (AddFriendFromExistingFriendListVC *)appDelegate.currentVc;
		obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
	}
//	else if ([appDelegate.currentVc isKindOfClass:[SettingsVC class]]){
//		SettingsVC *obj = (SettingsVC *)appDelegate.currentVc;
//		obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
//	}
    else if ([appDelegate.currentVc isKindOfClass:[NotifOptionVC class]]){
        NotifOptionVC *obj = (NotifOptionVC *)appDelegate.currentVc;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
    }
    else if ([appDelegate.currentVc isKindOfClass:[CategoryListForUploadVC class]]){
        CategoryListForUploadVC *obj = (CategoryListForUploadVC *)appDelegate.currentVc;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
    }
    else if ([appDelegate.currentVc isKindOfClass:[FavoritesVC class]]){
        FavoritesVC *obj = (FavoritesVC *)appDelegate.currentVc;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
    }
    else if ([appDelegate.currentVc isKindOfClass:[GroupListVC class]]){
        GroupListVC *obj = (GroupListVC *)appDelegate.currentVc;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
    }
    else if ([appDelegate.currentVc isKindOfClass:[UserListVC class]]){
        UserListVC *obj = (UserListVC *)appDelegate.currentVc;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
    }
/*    else if ([appDelegate.currentVc isKindOfClass:[RecrodingVC class]]){
        RecrodingVC *obj=  (RecrodingVC *)appDelegate.currentVc;
        obj.scrlView.frame = CGRectMake(obj.scrlView.frame.origin.x, obj.scrlView.frame.origin.y, obj.scrlView.frame.size.width, height-obj.scrlView.frame.origin.y);
    }
*/    else if ([appDelegate.currentVc isKindOfClass:[AlarmMainVC class]]){
        AlarmMainVC *obj = (AlarmMainVC *)appDelegate.currentVc;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
    }
    else if ([appDelegate.currentVc isKindOfClass:[AlarmRequestListVC class]]){
        AlarmRequestListVC *obj = (AlarmRequestListVC *)appDelegate.currentVc;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
    }
    else if ([appDelegate.currentVc isKindOfClass:[ShowItemListForSelectedStoreVC class]]){
        ShowItemListForSelectedStoreVC *obj = (ShowItemListForSelectedStoreVC *)appDelegate.currentVc;
        obj.collectionView.frame = CGRectMake(obj.collectionView.frame.origin.x, obj.collectionView.frame.origin.y, obj.collectionView.frame.size.width, (height-obj.collectionView.frame.origin.y));
    }
    else if ([appDelegate.currentVc isKindOfClass:[GroupUserListVC class]]){
        GroupUserListVC *obj = (GroupUserListVC *)appDelegate.currentVc;
        obj.tblData.frame = CGRectMake(obj.tblData.frame.origin.x, obj.tblData.frame.origin.y, obj.tblData.frame.size.width, (height-obj.tblData.frame.origin.y));
        
        if (obj.objUserListVC != nil) {
            obj.objUserListVC.view.frame = CGRectMake(obj.objUserListVC.view.frame.origin.x, obj.objUserListVC.view.frame.origin.y, obj.objUserListVC.view.frame.size.width, height-(68+1));
            obj.objUserListVC.tblData.frame = CGRectMake(0, obj.objUserListVC.tblData.frame.origin.y, 320, obj.objUserListVC.view.frame.size.height-18);

        }
        
    }

	[UIView commitAnimations];
}

-(void)ResizeViewForAds{
	if (appDelegate.isBannerVisible) {
		
		[self decreaseTableSize];
	}
	else{
		[self increaseTableSize];
	}
}

-(void)removeAdviewFromSuperView{
	[self.adView removeFromSuperview];
}

#pragma mark	APNS popup

-(void)initiateAPNSPopup{
    
	if (self.apnsPopUp == nil) {
		self.apnsPopUp = [[ApnsPopupView alloc] initWithFrame:CGRectMake(0, 0, 320, APNS_POPUP_HEIGHT)];
	}
}

-(void)showAPNS_ReplyPopUp:(NSDictionary *)dic forId:(int)tagID{
	
	[self hideAPNS_ReplyPopup];
	
	UIWindow* window = [UIApplication sharedApplication].keyWindow;
	if (!window)
		window = [[UIApplication sharedApplication].windows objectAtIndex:0];

    BOOL isImageAttached = NO;
    if ([DataValidation checkNullString:[dic valueForKey:ImagePath]].length > 0) {
        isImageAttached = YES;
    }
    
    if (self.apnsReplyPopUp == nil) {
        self.apnsReplyPopUp = [[ApnsPopupView alloc]  initReplyPopUpWithFrame:[UIScreen mainScreen].bounds isWithImage:isImageAttached];
    }
	
    
    [self.apnsReplyPopUp setReplyPopUpControlsWithAttachedImage:isImageAttached];
	[self.apnsReplyPopUp showNotifWithReply:dic andNotifId:tagID];

    if([appDelegate.currentVc isKindOfClass:[UserConversationChatVC class]]){
        UserConversationChatVC *obj = (UserConversationChatVC *)appDelegate.currentVc;
        if (!obj.viewContainerTextView.isHidden) {
            [obj btnKeyBoardCancel_Clicked:nil];
        }
        [obj btnCloseImageClicked:nil];
    }
    if([appDelegate.currentVc isKindOfClass:[HBlabConversation class]]){
        HBlabConversation *obj = (HBlabConversation *)appDelegate.currentVc;
        if (!obj.viewContainerTextView.isHidden) {
            [obj btnKeyBoardCancel_Clicked:nil];
        }
        [obj btnCloseImageClicked:nil];
    }
	[[[window subviews] objectAtIndex:0] addSubview:self.apnsReplyPopUp];
}

-(void)hideAPNS_ReplyPopup{
    UILabel *lbl = (UILabel *)[self.apnsReplyPopUp viewWithTag:123];
    if (lbl != nil) {
        [lbl removeFromSuperview];
        lbl = nil;
    }
    UILabel *lbl1 = (UILabel *)[self.apnsReplyPopUp viewWithTag:124];
    if (lbl1 != nil) {
        [lbl1 removeFromSuperview];
        lbl1 = nil;
    }
    [self.apnsReplyPopUp stopPlayingVideo];
    [self.apnsReplyPopUp removeFromSuperview];
    
//    if (self.apnsReplyPopUp != nil) {
//		[self.apnsReplyPopUp removeFromSuperview];
//		[self.apnsReplyPopUp release];
//		self.apnsReplyPopUp = nil;
//	}
}

-(void)showAPNS_PopUp:(NSDictionary *)dic forId:(int)tagID{

	[self.apnsPopUp removeFromSuperview];
	if (self.isAPNS_Visible) {
		[NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideAPNS_PopUp) object:nil];
		[self hideAPNS_PopUp];
	}
	
    NSLog(@"showAPNS_PopUp:(NSDictionary *)dic forId:(int)tagID");
	[self.apnsPopUp showNotifWithParams:dic andNotifId:tagID];

	AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);

	UIWindow* window = [UIApplication sharedApplication].keyWindow;
    NSLog(@"add to window");
	if (!window)
		window = [[UIApplication sharedApplication].windows objectAtIndex:0];
	[[[window subviews] objectAtIndex:0] addSubview:self.apnsPopUp];
	
	if (!self.isAPNS_Visible) {
		[UIView beginAnimations:@"Slide Popup down" context:nil];
        [UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.3];
		[self slideAPNSPopupDown];
		[UIView commitAnimations];
		self.isAPNS_Visible = YES;
		[self performSelector:@selector(hideAPNS_PopUp) withObject:nil afterDelay:6];
	}
}

-(void)hideAPNS_PopUp{
	if (self.isAPNS_Visible) {
		[UIView beginAnimations:@"Slide Popup up" context:nil];
        [UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.3];
		[self slideAPNSPopupUp];
		[UIView commitAnimations];
	}
}
-(void)ShowAlarm_PopUp:(NSDictionary *)dic forId:(int)tagID{
    [self hideAPNS_ReplyPopup];
    
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    if (!window)
        window = [[UIApplication sharedApplication].windows objectAtIndex:0];
    
    if (self.apnsReplyPopUp == nil) {
        self.apnsReplyPopUp = [[ApnsPopupView alloc]  initReplyPopUpWithFrame:[UIScreen mainScreen].bounds isWithImage:NO];
    }
    
    
    //[self.apnsReplyPopUp setReplyPopUpControlsWithAttachedImage:NO];
    [self.apnsReplyPopUp setReminderControls];
    [self.apnsReplyPopUp showReminderWithParams:dic andNotifId:tagID];
    
    [[[window subviews] objectAtIndex:0] addSubview:self.apnsReplyPopUp];
}
-(void)slideAPNSPopupDown{
    self.apnsPopUp.hidden = FALSE;

	self.apnsPopUp.frame = CGRectMake(0, 0, self.apnsPopUp.frame.size.width, APNS_POPUP_HEIGHT);
	self.isAPNS_Visible = YES;
}

-(void)slideAPNSPopupUp{
    self.apnsPopUp.hidden = TRUE;

	self.apnsPopUp.frame = CGRectMake(0, -(APNS_POPUP_HEIGHT), self.apnsPopUp.frame.size.width, APNS_POPUP_HEIGHT);
	self.isAPNS_Visible = NO;
}
/*
-(void)cleanNotifcationRelatedDicData{
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:CapturedImage];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:ImageCaption];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:SelectedIds];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:IS_GroupNotif];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:IS_NotifSendToAll];
    
    NSString *strSoundPath = [self applicationDocumentsDirectory];
    NSFileManager *fm = [NSFileManager defaultManager];
    
    if ([fm fileExistsAtPath:strSoundPath]) {
        [fm removeItemAtPath:strSoundPath error:nil];
    }
    appDelegate.dic_NotificationReleatedData = nil;
}
*/
-(void)cleanNotifcationRelatedDicData{
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:CapturedImage];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:ImageCaption];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:SelectedIds];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:IS_GroupNotif];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:IS_NotifSendToAll];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:Is_Create_Direct_Group];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:Selected_Friends_For_Creating_Group];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:IsPublicImg];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:RequestedKeepStatus];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:SelectedBlabDic];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:BlabType];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:@"TypeID"];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:TOTAL_FRIENDS];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:@"HashConversationID"];
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:REPLY_TO_ONE_BLAB_ID];
    
    NSString *strSoundPath = [self applicationDocumentsDirectory];
    NSFileManager *fm = [NSFileManager defaultManager];
    
    if ([fm fileExistsAtPath:strSoundPath]) {
        [fm removeItemAtPath:strSoundPath error:nil];
    }
    
    if ([fm fileExistsAtPath:[appDelegate.dic_NotificationReleatedData valueForKey:CapturedVideo]]) {
        [fm removeItemAtPath:[appDelegate.dic_NotificationReleatedData valueForKey:CapturedVideo] error:nil];
    }
    
    [appDelegate.dic_NotificationReleatedData setValue:nil forKey:CapturedVideo];
    
    if ([fm fileExistsAtPath:VIDEO_RECORDING_FOLDER]) {
        [fm removeItemAtPath:VIDEO_RECORDING_FOLDER error:nil];
    }
    
    appDelegate.dic_NotificationReleatedData = nil;
}
-(NSString*)applicationDocumentsDirectory
{
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:RECORDING_FOLDER])
	{
		[fm createDirectoryAtPath:RECORDING_FOLDER
      withIntermediateDirectories:YES
                       attributes:nil
                            error:NULL];
	}

    NSString *basePath = [RECORDING_FOLDER stringByAppendingPathComponent:@"MySound.m4a"];
    
    if ([fm fileExistsAtPath:basePath]) {
        [fm removeItemAtPath:basePath error:nil];
    }
    return basePath;
}

-(NSString *)createAlramFolder{
//    NSFileManager *fm = [NSFileManager defaultManager];
//    if (![fm fileExistsAtPath:ALARM_RECORDINGS_FOLDER])
//    {
//        NSLog(@"*****************   ALARM_RECORDINGS_FOLDER Does not exists");
//        [fm createDirectoryAtPath:ALARM_RECORDINGS_FOLDER
//      withIntermediateDirectories:YES
//                       attributes:nil
//                            error:NULL];
//    }
    
    NSString *strFilePath = [[[NSArray arrayWithArray:(NSArray *)ALARM_RECORDINGS_FOLDER] objectAtIndex:0] stringByAppendingString:@"/AlarmRecordings"];
    if (![[NSFileManager defaultManager] fileExistsAtPath:strFilePath])
    {
        [[NSFileManager defaultManager] createDirectoryAtPath:strFilePath
                                  withIntermediateDirectories:YES
                                                   attributes:nil
                                                        error:NULL];
    }
    return  strFilePath;
}

-(NSString*)getAlarmRcordingFilePath
{
    NSString *strAlertPAth = [self createAlramFolder];
    NSFileManager *fm = [NSFileManager defaultManager];

    NSDate *date = [NSDate date];
    NSDateFormatter *formater = [[NSDateFormatter alloc] init];
    [formater setDateFormat:@"DDMMYYhhmmss"];
    
    NSString *strDate = [formater stringFromDate:date];
    NSLog(@"strDate %@",strDate);
    
    NSString *basePath = [strAlertPAth stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.m4a",strDate]];
    NSLog(@"------------------------>>>>>  %@",basePath);
    
    if ([fm fileExistsAtPath:basePath]) {
        [fm removeItemAtPath:basePath error:nil];
    }
    return basePath;
}
/*
-(void)removeViewControllersFromStack:(NSArray *)arrVC{
   // NSArray *arr = appDelegate.navigationController.viewControllers;
    for (id vc in arrVC){
		if ([vc isKindOfClass:[FavoritesVC class]]) {
			[self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
		}
        else if ([vc isKindOfClass:[SearchFriendVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[OtherFriendNotifListVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[SettingsVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[NotifOptionVC class]]){
           [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[CategoryListForUploadVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[GroupListVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[UserListVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
	}

}

-(void)removeFromNavigationController:(UIViewController *)controller animated:(BOOL)animated WithVCArray:(NSArray *)arrVC {
    
    NSMutableArray *allViewControllers = [NSMutableArray arrayWithArray:arrVC];
    [allViewControllers removeObjectIdenticalTo:controller];
    appDelegate.navigationController.viewControllers = allViewControllers;
	
}
*/

#pragma mark	ASIHttp Request Cancle

-(void)CancelOnGoingRequests:(id)request{
    
	[self hideLoadingIndicator];
	
    if (request != nil) {
		if ([request isKindOfClass:[ASIHTTPRequest class]]) {
			ASIHTTPRequest *req = (ASIHTTPRequest *)request;
			[req cancel];
			[req clearDelegatesAndCancel];
			req = nil;
			request = nil;
		}
		else if ([request isKindOfClass:[ASIFormDataRequest class]]) {
			ASIFormDataRequest *req = (ASIFormDataRequest *)request;
			[req cancel];
			[req clearDelegatesAndCancel];
			req = nil;
			request = nil;
		}
	}
}

#pragma mark GetLocation

-(void)getCurrentLocation{
    
    self.locationManager = [[CLLocationManager alloc] init] ;
    self.locationManager.delegate = self;
    self.locationManager.distanceFilter = 100.0; // Will notify the LocationManager every 100 meters
    self.locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
    if ([self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [self.locationManager requestWhenInUseAuthorization];
    }
    [self.locationManager startUpdatingLocation];
}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    if (error.code == kCLErrorDenied) {
        if ([appDelegate.currentVc isKindOfClass:[SearchFilterSelectionVC class]]) {
            
            SearchFilterSelectionVC *obj = (SearchFilterSelectionVC *)appDelegate.currentVc;
            obj.isLoationServiceOn = FALSE;
            
//            UIAlertView *errorAlert = [[UIAlertView alloc]
//                                       initWithTitle:MESSAGE message:@"You might not have enable your location service for Blabeey.\nPlease go to Settings -> Privacy -> Location Services -> Blabeey and enable your location services." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//            [errorAlert show];
        }
    }
    else{
        NSLog(@"didFailWithError: %@", error);
        UIAlertView *errorAlert = [[UIAlertView alloc]
                                   initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [errorAlert show];
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    [self.locationManager stopUpdatingLocation];

    if (currentLocation != nil) {
        NSLog(@"%.8f", currentLocation.coordinate.longitude);
        NSLog(@"%.8f", currentLocation.coordinate.latitude);
    }
    if ([appDelegate.currentVc isKindOfClass:[SearchFilterSelectionVC class]]) {
        
        SearchFilterSelectionVC *obj = (SearchFilterSelectionVC *)appDelegate.currentVc;
        obj.isLoationServiceOn = TRUE;
    }
    
    appDelegate.UserCurrentLatitude = currentLocation.coordinate.latitude;
    appDelegate.UserCurrentLongitude = currentLocation.coordinate.longitude;
    
    if ([appDelegate.currentVc isKindOfClass:[NotificationVC class]]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self SetUserLatitude:currentLocation.coordinate.latitude andLongitude:currentLocation.coordinate.longitude];
        });
    }
    
    
}

-(void)SetUserLatitude:(double)latValue andLongitude:(double)longValue{
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithDouble:latValue],KeyValue,@"Lat",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithDouble:longValue],KeyValue,@"Lng",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"50",KeyValue,@"Distance",KeyName, nil],@"4",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:SET_USER_LAT_LONG withParameters:nil];
	[WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
	strUrl = nil;
}
-(UIColor*)getColorFromHex:(NSString *)strHex{
	
	unsigned int outVal;
    
    NSScanner* scanner = nil;
    
    scanner = [NSScanner scannerWithString:strHex];
    
	[scanner scanHexInt:&outVal];
	UIColor *fontColor = UIColorFromRGB(outVal);
	if (fontColor == nil) {
		return [UIColor blackColor];
	}
	return fontColor;
}
@end