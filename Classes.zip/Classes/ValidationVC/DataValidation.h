//
//  DataValidation.h
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ToastMessageView.h"
#import <iAd/iAd.h>
#import "ShowiAdsView.h"
#import "ApnsPopupView.h"
#import <CoreLocation/CoreLocation.h>
#import "UILoadingView.h"

@interface DataValidation : NSObject <CLLocationManagerDelegate>

@property (nonatomic, strong) ToastMessageView	*toast;
@property (nonatomic, strong) UIImageView		*imgCartoon;
@property (nonatomic, strong) NSString			*strTimeT1;
@property (nonatomic, strong) UIImageView		*imgBorderBox;
@property (nonatomic, strong) NSMutableDictionary		*arrColor;
@property (nonatomic, strong)ShowiAdsView				*adView;
@property (nonatomic, strong) ApnsPopupView		*apnsPopUp;
@property (nonatomic, strong) ApnsPopupView		*apnsReplyPopUp;
@property (nonatomic, readwrite) BOOL			isAPNS_Visible;
@property (nonatomic, strong) NSDictionary      *dicNotifCount;
@property (nonatomic, strong) CLLocationManager *locationManager;

@property (nonatomic, strong) UIView            *viewPullToRefresh;
@property (nonatomic, strong) UIImageView       *imgLoading;
@property (nonatomic, strong) UILoadingView	*loadingView;

-(void)setArrayOfColor;
-(BOOL)checkInternetConnection;
//-(BOOL)CheckFirstChar_IS_ALPHABET:(NSString *)str;
//-(BOOL)CheckAlphaNumericOnly:(NSString *)str;
//-(BOOL)CheckClipTitleOnly:(NSString *)str;
+(BOOL)validateEmailWithString:(NSString *)email;
+(NSString *)checkNullString : (NSString *)str;
+(BOOL)CompareString:(NSString *)str1 withString:(NSString *)str2;
+(BOOL)CheckNumericOnly:(NSString *)str;
//-(NSString *)encapsulateStringForURL:(NSString *)str;
-(void)showToastMessage:(NSString *)msg displayDuration:(float)duration;
-(void)showToastMessageBigText:(NSString *)msg displayDuration:(float)duration;
-(void)removeToastFromMemory;
- (void) showLoadingView:(BOOL)show;

-(UIView *)showPullToRefreshLoaderInView:(UIRefreshControl *)refreshControl;
-(void)hideLoadingIndicator;
-(void)showLoadingIndicator;
-(void)showLoadingIndicatorInView:(id)view;

-(void)getCurrentLocation;

-(void)showCarttonCharacterAnimation;
-(void)HidingCartoonChar;
-(void)removeCartoonCharAnimation;

-(NSString *)GetUTCDate;
-(NSString *)GetUTCDateFromDate:(NSDate *)date;
-(NSDate *)GetCombineDate:(NSString *)strDate time:(NSString *)strTime;
-(NSString *)getCurrentTimeZoneDateFromUtcDate:(NSString*)strDate;

-(NSString *)getEncryptedTextForString:(NSString *)strToEncrypt isGeneral:(BOOL)isGeneralKey;
-(NSString *)getDecryptedTextForString:(NSString *)strToDecrypt isGeneral:(BOOL)isGeneralKey;
-(NSString *)encodeString:(NSString *)strUrl;

-(NSString *)getEncryptedShareUrlId:(NSString *)str;


-(void)highLightTextField:(id)tf inView:(id)view;
-(void)resetTextFieldBorderColor;
-(NSArray *)SortArrayFromArray:(NSArray *)arrayToBeSorted throughKey:(NSString *)keyName;

-(void)clearImageCache;
-(void)setAudioPropertyForRecording;
-(void)setAllKeyValueFromData:(id)response;
-(void)setMatTrackingForRegisterAndLogin:(NSDictionary*)response index:(int)index;//index 0 means register 1 means login
-(void)setMatTrackingForSearch:(NSString*)searchStr;
-(void)removeAllKeyValue;

-(NSData *)compressImage:(UIImage *)img;
-(void)setCorners:(id)img ;
-(UIColor *)getColorForAlphabet:(NSString *)strCharacter;
-(UIColor*)DarkColorWithHexString:(NSString*)strCharacter;
+(NSArray *)getAllContacts;

//-(void)showAudioPlayIndicator;
//-(void)hideAudioLoader;

- (NSDictionary*)parseURLParams:(NSString *)query;

-(void)CancelOnGoingRequests:(id)request;

#pragma mark	APNS Popup

-(void)initiateAPNSPopup;
-(void)showAPNS_ReplyPopUp:(NSDictionary *)dic forId:(int)tagID;
-(void)hideAPNS_ReplyPopup;
-(void)showAPNS_PopUp:(NSDictionary *)dic forId:(int)tagID;
-(void)hideAPNS_PopUp;
-(void)slideAPNSPopupDown;
-(void)slideAPNSPopupUp;

-(void)cleanNotifcationRelatedDicData;
-(NSString*)applicationDocumentsDirectory;
-(NSString*)getAlarmRcordingFilePath;
-(NSString *)createAlramFolder;

#pragma iAds

- (ShowiAdsView *) sharedBannerView;
-(void)ResizeViewForAds;
-(void)increaseTableSize;
-(void)decreaseTableSize;
-(void)removeAdviewFromSuperView;

-(void)animateYpoint:(int)yPoint viewToAnimate:(UIView *)viewToAni;
-(UIColor*)getColorFromHex:(NSString *)strHex;

-(BOOL)setOverlayFlags:(int)selOverlay;
-(void)DisableScreenLockWhilePlaying:(BOOL)isDisable;
-(void)ShowAlarm_PopUp:(NSDictionary *)dic forId:(int)tagID;
@end
