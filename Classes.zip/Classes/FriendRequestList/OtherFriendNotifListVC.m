//
//  OtherFriendNotifListVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 8/8/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "OtherFriendNotifListVC.h"
#import "UserCell.h"
#import "MBProgressHUD.h"

@interface OtherFriendNotifListVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
    NSMutableArray *arrSentRequest;
    BOOL isRefresing;
    int currentlyPlaingIndex;
}
@property (nonatomic,strong) NSMutableArray *arrSentRequest;
@end

@implementation OtherFriendNotifListVC
@synthesize arrSentRequest;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	
    
	self.arrData = [[NSMutableArray alloc] init];
	appDelegate.currentVc = self;
	[self performSelector:@selector(LoadViewSetting)];
	self.pageCounter = 1;
	
	[self.tblData registerNib:[UINib nibWithNibName:@"UserCell" bundle:nil] forCellReuseIdentifier:@"cellIdentifier"];

	
	//pull to refresh
	self.refresh = [[UIRefreshControl alloc] init];
	
	self.refresh.attributedTitle = [[NSAttributedString alloc] initWithString:@""];
	self.refresh.tintColor = TWITTER_BLUE_COLOR;
	[self.refresh setAutoresizingMask:(UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleLeftMargin)];
	
	[[self.refresh.subviews objectAtIndex:0] setFrame:CGRectMake(-5, 10, 20, 30)];
	[self.refresh addTarget:self action:@selector(loadNewData) forControlEvents:UIControlEventValueChanged];
	[self.tblData addSubview:self.refresh];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
	
}

-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
    
    NSLog(@"ViewControllers = %@",self.navigationController.viewControllers);
    
	[self.lbl_NoDataAvailable setHidden:YES];
	self.pageCounter = 1;
	self.isDataNull = NO;
	appDelegate.currentVc = self;
    
    //set menu image
//    [self.btnMenu removeTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
//	[self.btnMenu addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];

    [self.btnMenu addTarget:self action:@selector(btnBack_Clicked:) forControlEvents:UIControlEventTouchUpInside];
	
	[Validation removeAdviewFromSuperView];
	[self.view addSubview:[Validation sharedBannerView]];
	[Validation ResizeViewForAds];
	[self.arrData removeAllObjects];
    [HUD show:YES];
	[self performSelectorInBackground:@selector(getRequestList) withObject:nil];

   // [appDelegate checkForNotification];
}
-(void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
	[Validation increaseTableSize];
    appDelegate.isShouldShowReplyPopUp = NO;
}
-(IBAction)btnBack_Clicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark

-(void)get_NptofCount{
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_REQUEST_COUNT withParameters:nil];
	
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }
//	self.request.delegate = self;
//	self.request.tag = 2;
	strUrl = nil;
}


-(void)loadNewData{
    if (!isRefresing) {
        isRefresing = YES;
        [HUD show:YES];
        
        self.pageCounter = 1;
        self.isDataNull = NO;
        
        if (self.tblData.tag==101) {
            [self.arrData removeAllObjects];
            [self getRequestList];
        }
        else{
            [self.arrSentRequest removeAllObjects];
            [self getSendRequestList];
        }
    }
}

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    [self.lbl_NoDataAvailable setTextColor:TWITTER_BLUE_COLOR];
    [self.lbl_NoDataAvailable setShadowColor:[UIColor clearColor]];
}

-(IBAction)btnBackClicked:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}

-(void)getRequestList{
	if (self.request !=nil) {
		self.request = nil;
	}
	//[Validation showLoadingIndicator];
    
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_REQUEST_LIST withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//	self.request.delegate = self;
//	self.request.tag = 1;
	strUrl = nil;
	
}
-(void)getSendRequestList{
    if (self.request !=nil) {
        self.request = nil;
    }
    //[Validation showLoadingIndicator];
    
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_SENT_REQUEST_LIST withParameters:nil];
    self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:4];
    }
    //	self.request.delegate = self;
    //	self.request.tag = 1;
    strUrl = nil;
    
}
-(IBAction)btnRecSentClicked:(id)sender{
    UIButton *btn = (UIButton *)sender;
    
    if (btn.tag == 1) {

        [self.btnReceived setBackgroundImage:[UIImage imageNamed:btn_Blue_Selected] forState:UIControlStateNormal];
        [self.btnSent setBackgroundImage:[UIImage imageNamed:btn_White_DeSelected] forState:UIControlStateNormal];
        [self.btnReceived setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.btnSent setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
        if (self.arrData.count == 0) {
            self.lbl_NoDataAvailable.hidden = FALSE;
        }
        else{
            self.lbl_NoDataAvailable.hidden = TRUE;
        }
        self.tblData.tag = 101;
        [self.tblData reloadData];
    }
    else{

        [self.btnReceived setBackgroundImage:[UIImage imageNamed:btn_White_DeSelected] forState:UIControlStateNormal];
        [self.btnSent setBackgroundImage:[UIImage imageNamed:btn_Blue_Selected] forState:UIControlStateNormal];
        [self.btnSent setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.btnReceived setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
        if (self.arrSentRequest.count == 0) {
            self.lbl_NoDataAvailable.hidden = FALSE;
        }
        else{
            self.lbl_NoDataAvailable.hidden = TRUE;
        }
        if (self.arrSentRequest==nil) {
            [HUD show:YES];
            self.arrSentRequest = [NSMutableArray new];
            self.tblData.tag = 102;
            [self getSendRequestList];
        }
        else{
            self.tblData.tag = 102;
            [self.tblData reloadData];
        }
    }
    
}
-(void)btnAcceptFriendRequest:(id)sender{
	//[Validation showLoadingIndicator];
    [appDelegate ClosePopUpWithoutUIFromFrienRequest];
    [self removeAnimationFromSuperView];
    [HUD show:YES];
    
	if (self.request !=nil) {
		self.request = nil;
	}
	self.selectedIndex = (int)((UIButton *)sender).tag;
    
    
    
    NSString *strRequestId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:REQUESTER_ID]];
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"IsFriend",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:ACCEPT_REJECT_FRND_REQ withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:3];
    }
//	self.request.delegate = self;
//	self.request.tag = 3;
	strUrl = nil;
	
    //--
    
//    [self.arrData removeObjectAtIndex:self.selectedIndex];
//    [self.tblData reloadData];
	
    //--
}

-(void)btnRejectFriendRequest:(id)sender{
    [appDelegate ClosePopUpWithoutUIFromFrienRequest];
    [self removeAnimationFromSuperView];
    [HUD show:YES];
    
	if (self.request !=nil) {
		self.request = nil;
	}
	self.selectedIndex = (int)((UIButton *)sender).tag;
    
    
    
	NSString *strRequestId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:REQUESTER_ID]];
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"IsFriend",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:ACCEPT_REJECT_FRND_REQ withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:3];
    }
//	self.request.delegate = self;
//	self.request.tag = 3;
	strUrl = nil;
    
    //--
    
//    [self.arrData removeObjectAtIndex:self.selectedIndex];
//    [self.tblData reloadData];
    
    //--
}

#pragma mark  UITableViewDelegate

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 90;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	//return self.arrData.count;
    if (tableView.tag==101) {
        return self.arrData.count;
    }
    else{
        return self.arrSentRequest.count;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
//	NSString *cellId = [NSString stringWithFormat:@"%d%@",(int)indexPath.row,[[self.arrData objectAtIndex:indexPath.row] valueForKey:USER_ID]];
	
//	UserCell *cell = (UserCell *)[tableView dequeueReusableCellWithIdentifier:cellId];
//    cell.isUserSelectionInView = YES;
	UserCell *cell = (UserCell *)[tableView dequeueReusableCellWithIdentifier:@"cellIdentifier"];
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
//	if (cell == nil) {
//		cell = [[UserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        cell.isUserSelectionInView = YES;

    if (isRefresing) {
        return cell;
    }
        if (tableView.tag==101) {
            if (self.arrData!=0) {
                [cell setBoxValuesWithData:[self.arrData objectAtIndex:indexPath.row]];
                
                //check if isFriend
                
                [cell.imgFriendshipStatus setHidden:TRUE];
                
                [cell.btnReqDeny setImage:[UIImage imageNamed:Btn_Reject_Request] forState:UIControlStateNormal];
                [cell.btnReqStatus setImage:[UIImage imageNamed:Btn_Accept_Request] forState:UIControlStateNormal];
                
                [cell.btnReqDeny setHidden:FALSE];
                [cell.btnReqStatus setHidden:FALSE];
                cell.btnUnfriend.hidden = YES;
                
                [cell.btnReqStatus addTarget:self action:@selector(btnAcceptFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
                [cell.btnReqDeny addTarget:self action:@selector(btnRejectFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
                
                cell.btnReqDeny.tag = indexPath.row;
                cell.btnReqStatus.tag = indexPath.row;
                cell.lblDisplayName.backgroundColor = [UIColor clearColor];
                cell.lblUserName.backgroundColor = [UIColor clearColor];
                
                cell.lblDisplayName.font = [UIFont fontWithName:Font_OpneSans_SemiBol size:20];
                cell.lblUserName.font = [UIFont fontWithName:Font_OpneSans_Light size:16];
                cell.lblDisplayName.frame = CGRectMake(cell.lblDisplayName.frame.origin.x, cell.lblDisplayName.frame.origin.y, cell.lblDisplayName.frame.size.width-40 , cell.lblDisplayName.frame.size.height);
                
                if ([DataValidation checkNullString:[[self.arrData objectAtIndex:indexPath.row] valueForKey:@"FilePath"]].length!=0) {
                    cell.btnPlayPause.hidden = NO;
                    cell.btnPlayPause.frame = CGRectMake(cell.btnReqStatus.frame.origin.x-10, cell.btnReqStatus.frame.origin.y+cell.btnReqStatus.frame.size.height, cell.btnPlayPause.frame.size.width, cell.btnPlayPause.frame.size.height);
                    cell.btnPlayPause.tag = indexPath.row;
                    [cell.btnPlayPause addTarget:self action:@selector(btnPlayFileClicked:) forControlEvents:UIControlEventTouchUpInside];
                    
                }
                else{
                    cell.btnPlayPause.hidden = YES;
                }
                
                
            }
        }
        else{
            if (self.arrSentRequest!=0) {
                [cell setBoxValuesWithData:[self.arrSentRequest objectAtIndex:indexPath.row]];
                [cell.btnReqStatus removeTarget:self action:@selector(btnAcceptFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
                [cell.btnReqDeny removeTarget:self action:@selector(btnRejectFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
                cell.btnReqDeny.hidden = YES;
                cell.btnReqStatus.hidden = YES;
                cell.btnUnfriend.hidden = YES;
                cell.btnUserBlocked.hidden = YES;
                
                if ([DataValidation checkNullString:[[self.arrSentRequest objectAtIndex:indexPath.row] valueForKey:@"FilePath"]].length!=0) {
                    cell.btnPlayPause.hidden = NO;
                    cell.btnPlayPause.imageView.image=[UIImage imageNamed:@"icn_play.png"];
                    cell.btnPlayPause.frame = CGRectMake(cell.lblDisplayName.frame.origin.x+cell.lblDisplayName.frame.size.width-10, 20, cell.btnPlayPause.frame.size.width, cell.btnPlayPause.frame.size.height);
                    cell.btnPlayPause.tag = indexPath.row;
                    [cell.btnPlayPause addTarget:self action:@selector(btnPlayFileClicked:) forControlEvents:UIControlEventTouchUpInside];
                    
                }
                else{
                    cell.btnPlayPause.hidden = YES;
                }
            }
        }
    
//	}
	
	
    
//  paging is not implemented yet
    
//	if (indexPath.row == self.arrData.count-1) {
//		if (self.isDataNull == NO) {
//			self.pageCounter++;
//			//[Validation showLoadingIndicator];
//            [HUD show:YES];
//            
//			[self performSelectorInBackground:@selector(getRequestList) withObject:nil];
//		}
//	}
	
	return cell;
}

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	
	NSError *error = nil;
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData] options:0 error:&error];
	NSLog(@"dictionary = %@",request.responseString);
	
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [self.refresh endRefreshing];
            [appDelegate callLogOutService];
            
        }
        else{
            if (request.tag == 1) {
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil && ((NSArray*)response).count > 0) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            
                            [self.arrData addObjectsFromArray:arr];
                            
                            arr = nil;
                            [self.lbl_NoDataAvailable setHidden:YES];
                            [self.tblData reloadData];
                        }
                        if (self.arrData.count == 0 && self.pageCounter==1) {
                            [self.tblData reloadData];
                            [self.lbl_NoDataAvailable setHidden:NO];
                            [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                        }
                    }
                }
                else{
                    if (self.arrData.count == 0 && self.pageCounter==1) {
                        [self.tblData reloadData];
                        [self.lbl_NoDataAvailable setHidden:NO];
                        [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                    }
                }
                [HUD hide:YES];
                [self.refresh endRefreshing];
                isRefresing = NO;
            }
            else if (request.tag == 2) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            NSString *strFR = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_FRIENDS_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strNotif = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_UNREAD_NOTIF]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strKeepReq = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_KEEP_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strTotalCount = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_NOTIF_COUNT]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strARCount = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_ALARM_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            
                            Validation.dicNotifCount = [NSDictionary
                                                        dictionaryWithObjectsAndKeys:
                                                        strFR,TOTAL_FRIENDS_REQUEST,
                                                        strNotif,TOTAL_UNREAD_NOTIF,
                                                        strKeepReq,TOTAL_KEEP_REQUEST,
                                                        strTotalCount, TOTAL_NOTIF_COUNT,
                                                        strARCount,TOTAL_ALARM_REQUEST,
                                                        nil];
                            
                            strFR = nil;
                            strNotif = nil;
                        }
                        
                    }
                    else{
                        Validation.dicNotifCount = [NSDictionary
                                                    dictionaryWithObjectsAndKeys:
                                                    @"",TOTAL_FRIENDS_REQUEST,
                                                    @"",TOTAL_UNREAD_NOTIF,
                                                    @"",TOTAL_KEEP_REQUEST,
                                                    @"",TOTAL_NOTIF_COUNT,
                                                    @"",TOTAL_ALARM_REQUEST,
                                                    nil];
                    }
                }
                [HUD hide:YES];
            }
            else if (request.tag == 3){
//                [self.arrData removeObjectAtIndex:self.selectedIndex];
//                [self.tblData reloadData];
                if (self.arrData.count == 0) {
                    [self.lbl_NoDataAvailable setHidden:NO];
                    [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                }
                self.pageCounter = 1;
                self.isDataNull = NO;
                [self.arrData removeAllObjects];
                [self performSelectorInBackground:@selector(getRequestList) withObject:nil];
            }
            else if (request.tag == 4) {
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil && ((NSArray*)response).count > 0) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            
                            [self.arrSentRequest addObjectsFromArray:arr];
                            
                            arr = nil;
                            [self.lbl_NoDataAvailable setHidden:YES];
                            [self.tblData reloadData];
                        }
                        if (self.arrSentRequest.count == 0 && self.pageCounter==1) {
                            [self.tblData reloadData];
                            [self.lbl_NoDataAvailable setHidden:NO];
                            [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                        }
                    }
                }
                else{
                    if (self.arrSentRequest.count == 0 && self.pageCounter==1) {
                        [self.tblData reloadData];
                        [self.lbl_NoDataAvailable setHidden:NO];
                        [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                    }
                }
                [HUD hide:YES];
                [self.refresh endRefreshing];
                isRefresing = NO;
            }
        }
    }
    else{
        [HUD hide:YES];
    }
	
	
	self.request = nil;
}

- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

-(void)btnPlayFileClicked:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    
    //self.selectedPlayIndex = (int)btn.tag;
    if (self.isPlaying) {
//        self.isStoppedForceFully = TRUE;
        self.isPlaying = NO;
//        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:currentlyPlaingIndex inSection:0];
//        UserCell *cell = (UserCell *)[self.tblData cellForRowAtIndexPath:indexPath];
//        appDelegate.imgPlayAnimation = cell.btnPlayPause.imageView;
        [appDelegate ClosePopUpWithoutUIFromFrienRequest];
        [self removeAnimationFromSuperView];
//        [btn setImage:[UIImage imageNamed:@"icn_play.png"] forState:UIControlStateNormal];
//        self.isPlayAll = FALSE;
    }
    else{
        btn.imageView.image = nil;
        [self playSelectedFileAtIndex:(int)btn.tag];
    }
}
-(void)removeAnimationFromSuperView{
//    [imgViewPlayAni removeFromSuperview];
    self.isPlaying = NO;
//    [imgViewPlayAni stopAnimating];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:currentlyPlaingIndex inSection:0];
    UserCell *cell = (UserCell *)[self.tblData cellForRowAtIndexPath:indexPath];
    [cell.btnPlayPause.imageView stopAnimating];
    cell.btnPlayPause.imageView.image=[UIImage imageNamed:@"icn_play.png"];
//    [imgViewPlayAni setHidden:YES];
}
-(void)playSelectedFileAtIndex:(int)index{
    int section = 1;
    if (self.isDataNull) {
        section = 0;
    }
    self.isPlaying = YES;
    currentlyPlaingIndex = index;
    NSMutableDictionary *dic;
    if (self.tblData.tag==101) {
        dic = [self.arrData objectAtIndex:index];
    }
    else{
        dic = [self.arrSentRequest objectAtIndex:index];
    }
//    self.selectedPlayID = [[NSString stringWithFormat:@"%@",[dic valueForKey:MESSAGE_CHAT_ID]] intValue];

    
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
    if ([self.tblData.indexPathsForVisibleRows containsObject:indexPath]) {
        UserCell *cell = (UserCell *)[self.tblData cellForRowAtIndexPath:indexPath];

//        cell.imgPlayAnimation.hidden = NO;
//        [cell.contentView bringSubviewToFront:cell.imgPlayAnimation];
        [self setImageViewInview:cell.btnPlayPause];
        
    }
    [appDelegate playSoundWithoutUIForURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:@"FilePath"]]]];
    
}
-(void)setImageViewInview:(id)viewToPlayAnimationIn{
    
    
    if ([viewToPlayAnimationIn isKindOfClass:[UIImageView class]]) {
        
        UIImageView *img = (UIImageView *)viewToPlayAnimationIn;
        [self initializeAnimationArray:img];
        [img startAnimating];
    }
    if ([viewToPlayAnimationIn isKindOfClass:[UIButton class]]) {
        
        UIButton *btn = (UIButton *)viewToPlayAnimationIn;
//        appDelegate.imgPlayAnimation = btn.imageView;
        [self initializeAnimationArray:btn.imageView];
        [btn.imageView startAnimating];
    }
}
-(void)initializeAnimationArray:(UIImageView*)imgViewPlayAni{
    
    NSMutableArray *arrAnimation = [[NSMutableArray alloc] init];
    for (int i = 1 ; i<=28; i++) {
        [arrAnimation addObject:[UIImage imageNamed:[NSString stringWithFormat:@"player_loader_%d.png",i]]];
    }
    
    imgViewPlayAni.animationImages = arrAnimation;
    imgViewPlayAni.animationRepeatCount = 0;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
