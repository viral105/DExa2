//
//  OtherFriendNotifListVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/8/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OtherFriendNotifListVC : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) IBOutlet  UIButton            *btnMenu;
@property (nonatomic, strong) ASIHTTPRequest				*request;

@property (nonatomic, retain) IBOutlet UILabel				*lbl_NoDataAvailable;
@property (nonatomic, readwrite) int						selectedIndex;

@property (nonatomic, strong) UIRefreshControl				*refresh;
@property (strong, nonatomic) IBOutlet UIButton *btnReceived;
@property (strong, nonatomic) IBOutlet UIButton *btnSent;
@property (nonatomic, assign) BOOL isPlaying;
-(void)removeAnimationFromSuperView;
-(void)getRequestList;
@end
