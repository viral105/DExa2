//
//  SocialShareVC.h
//  WWHHAAZZAAPP
//
//  Created by Nivid Jain on 9/25/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Pinterest/Pinterest.h>

@protocol SocialShareVCDelegate;

@protocol SocialShareVCDelegate <NSObject>
- (void)removeSocialShareContainerFromParentVC;

@end

@interface SocialShareVC : UIViewController

@property (nonatomic, strong) NSMutableArray        *arrMediaList;
@property (nonatomic, strong) IBOutlet UIView       *viewContainer;
@property (nonatomic, retain) IBOutlet UIImageView  *img_ShareSeparator;
@property (nonatomic, retain) IBOutlet UIImageView  *img_CancelSeparator;
@property (nonatomic, retain) IBOutlet UILabel      *lblShare;
@property (nonatomic, strong) IBOutlet UIButton     *btn_Cancel;


@property (nonatomic, retain) Pinterest*  pinterest;

@property (nonatomic ,assign) id <SocialShareVCDelegate>       delegate;


@end
