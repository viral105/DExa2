//
//  SocialShareView.m
//  WWHHAAZZAAPP
//
//  Created by Nivid Jain on 9/25/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "SocialShareView.h"
#define ICON_WIDTH       60


@implementation SocialShareView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(void)initiateShareView{
    
    UIImageView *imgBg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    imgBg.backgroundColor = [UIColor blackColor];
    imgBg.alpha = 0.5;
    [self addSubview:imgBg];
    
    UIView *viewContainer = [[UIView alloc] initWithFrame:CGRectMake(0, DEVICE_HEIGHT-250, 320, 250)];
    viewContainer.backgroundColor = [UIColor whiteColor];
    [self addSubview:viewContainer];
    viewContainer = nil;
    
    self.xStart = 5;
    self.yStart = 10;
    
    UILabel *lblShare = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
    lblShare.textAlignment = NSTextAlignmentCenter;
    [lblShare setFont:[UIFont fontWithName:Font_Montserrat_Bold size:22]];
    lblShare.textColor = UIColorFromRGB(0X00c2d9);
    [self addSubview:lblShare];
    lblShare = nil;
    
    
    
    self.btnFacebook = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btnFacebook.frame = CGRectMake(self.xStart, self.yStart, ICON_WIDTH, ICON_WIDTH);
//    [self.btnFacebook setTitle:@"FB" forState:UIControlStateNormal];
    [self.btnFacebook setImage:[UIImage imageNamed:BTN_FB_SHARE] forState:UIControlStateNormal];
    [self addSubview:self.btnFacebook];
    
    self.xStart += (ICON_WIDTH+8);
    
    [self checkFor_xPosition];
    
    self.btnTwitter = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btnTwitter.frame = CGRectMake(self.xStart, self.yStart, ICON_WIDTH, ICON_WIDTH);
//    [self.btnTwitter setTitle:@"Twit" forState:UIControlStateNormal];
    [self.btnTwitter setImage:[UIImage imageNamed:BTN_TWITTER_SHARE] forState:UIControlStateNormal];
    [self addSubview:self.btnTwitter];
    
    
    /*
    xStart += (width+8);

    self.btnPinterest = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btnPinterest.frame = CGRectMake(xStart, yStart, width, width);
    [self.btnPinterest setTitle:@"PIN" forState:UIControlStateNormal];
    [self.btnPinterest setImage:[UIImage imageNamed:BtnNotifReplayResend] forState:UIControlStateNormal];
    [self addSubview:self.btnPinterest];
    
    xStart += (width+8);
    
    self.btnGooglePlus = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btnGooglePlus.frame = CGRectMake(xStart, yStart, width, width);
    [self.btnGooglePlus setTitle:@"G+" forState:UIControlStateNormal];
    [self.btnGooglePlus setImage:[UIImage imageNamed:BtnNotifReplayResend] forState:UIControlStateNormal];
    [self addSubview:self.btnGooglePlus];
     */
}

-(void)checkFor_xPosition{
    if ((self.xStart+ICON_WIDTH+5)>=320) {
        self.xStart += (ICON_WIDTH+5);
        self.xStart = 5;
    }
}

@end
