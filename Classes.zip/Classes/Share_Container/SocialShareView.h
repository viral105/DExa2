//
//  SocialShareView.h
//  WWHHAAZZAAPP
//
//  Created by Nivid Jain on 9/25/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SocialShareView : UIView

@property (nonatomic, retain) UIButton *btnFacebook;
@property (nonatomic, retain) UIButton *btnPinterest;
@property (nonatomic, retain) UIButton *btnTwitter;
@property (nonatomic, retain) UIButton *btnGooglePlus;

@property (nonatomic, readwrite) float  xStart;
@property (nonatomic, readwrite) float  yStart;

-(void)initiateShareView;
@end
