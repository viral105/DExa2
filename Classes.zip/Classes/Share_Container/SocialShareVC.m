//
//  SocialShareVC.m
//  WWHHAAZZAAPP
//
//  Created by Nivid Jain on 9/25/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "SocialShareVC.h"
#define PINTEREST_CLIENT_ID     @"1440415"
#define ICON_WIDTH              65
#define ImageName               @"imgName"
#define Btn_Tag                 @"tag"

@interface SocialShareVC ()

@end

@implementation SocialShareVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.arrMediaList = [[NSMutableArray alloc] init];
    [self.arrMediaList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"icn_share_fb.png",ImageName,@"1",Btn_Tag, nil]];
    [self.arrMediaList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"icn_share_twitter.png",ImageName,@"2",Btn_Tag, nil]];
    [self.arrMediaList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"icn_share_email.png",ImageName,@"3",Btn_Tag, nil]];
    [self.arrMediaList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"icn_share_message.png",ImageName,@"4",Btn_Tag, nil]];
    
    [self LoadViewSetting];
    [self AddButtonsInView];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
    self.viewContainer.frame = CGRectMake(0, DEVICE_HEIGHT-175, 320, 175);
    [UIView commitAnimations];
}

-(void)LoadViewSetting{
    self.lblShare.font = [UIFont fontWithName:Font_Montserrat_Regular size:15];
    [self.btn_Cancel.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:12]];
    self.img_ShareSeparator.frame = CGRectMake(0, self.img_ShareSeparator.frame.origin.y, 320, 0.5);
    self.img_CancelSeparator.frame = CGRectMake(0, self.btn_Cancel.frame.origin.y-1, 320, 0.5);
}

-(void)AddButtonsInView{
 
    float xStart = 8;
    float yStart = 53;
    
    for (int i = 0; i< self.arrMediaList.count; i++) {
        NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrMediaList objectAtIndex:i]];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(xStart, yStart, ICON_WIDTH, ICON_WIDTH);
        [btn setImage:[UIImage imageNamed:[dic valueForKey:ImageName]] forState:UIControlStateNormal];
        btn.tag = [[dic valueForKey:Btn_Tag] intValue];
        [self.viewContainer addSubview:btn];
        xStart = [self checkFor_xPosition:xStart];
    }
}

-(float)checkFor_xPosition:(float)xStart{
    
    if ((xStart+ICON_WIDTH+5)>=320) {
      //  xStart += (ICON_WIDTH+8);
        xStart = 8;
    }
    else{
        xStart += (ICON_WIDTH+8);
    }
    return xStart;
}

-(IBAction)btnCancelClicked:(id)sender{
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
    self.viewContainer.frame = CGRectMake(0, DEVICE_HEIGHT, 320, 175);
    [UIView commitAnimations];

    [self performSelector:@selector(removeViewAfterAnimation) withObject:nil afterDelay:0.5];

}

-(void)removeViewAfterAnimation{
    [self.delegate removeSocialShareContainerFromParentVC];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)shareWithPinterest{
    self.pinterest = [[Pinterest alloc] initWithClientId:PINTEREST_CLIENT_ID urlSchemeSuffix:@"Blabeey"];
    //    NSData* data = [[NSData alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Icon144x144" ofType:@"png"]];
    NSURL* aURL = [NSURL URLWithString:@"http://2.bp.blogspot.com/-nfTQ21VEfqQ/USaEix1WiQI/AAAAAAAATcs/n4Kk1pp8QtI/s1600/Colored-pencils-pencils-22186659-1600-1200.jpg"];
    NSData* data = [[NSData alloc] initWithContentsOfURL:aURL];
    UIImage* sampleImage = [UIImage imageWithData:data];
    UIImageView* sampleImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
    [sampleImageView setImage:sampleImage];
    [sampleImageView setFrame:CGRectMake((320-200)/2, 64, 200, 200)];
    [self.view addSubview:sampleImageView];
    
    // Setup PinIt Button
    UIButton* pinItButton = [Pinterest pinItButton];
    [pinItButton setFrame:CGRectMake((320-72)/2, 330, 72, 32)];
    [pinItButton addTarget:self
                    action:@selector(pinIt:)
          forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:pinItButton];
    
}
- (void)pinIt:(id)sender
{
    [_pinterest createPinWithImageURL:[NSURL URLWithString:@"http://2.bp.blogspot.com/-nfTQ21VEfqQ/USaEix1WiQI/AAAAAAAATcs/n4Kk1pp8QtI/s1600/Colored-pencils-pencils-22186659-1600-1200.jpg"]
                            sourceURL:[NSURL URLWithString:@"www.yapeey.com"]
                          description:@"Pinning it from Blabeey"];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
