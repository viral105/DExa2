//
//  SubCat_CollectionCell.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 17/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubCat_CollectionCell : UICollectionViewCell

@property (nonatomic, strong) IBOutlet AsyncImageView	*imgProfile;
@property (nonatomic, retain) IBOutlet	UILabel         *lblSubCatTitle;
@property (nonatomic, strong) IBOutlet UIImageView		*imgFriendshipStatus;

-(void)setCollectionViewForindex:(NSInteger)index forDictionary:(NSDictionary *)dic;
-(void)setCollectionViewForInterestIndex:(NSInteger)index forDictionary:(NSDictionary *)dic;
@end
