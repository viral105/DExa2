//
//  NotifFileOptionCell.h
//  WWHHAAZZAAPP
//
//  Created by s on 9/15/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotifFileOptionCell : UITableViewCell

@property (nonatomic, retain) IBOutlet	UILabel         *lblSubCatTitle;
@property (nonatomic, retain) IBOutlet	AsyncImageView	*imgProfile;
@property (nonatomic, retain) IBOutlet  UIImageView     *imgSelectionStatus;

@end
