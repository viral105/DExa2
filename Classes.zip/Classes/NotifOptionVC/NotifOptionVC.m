//
//  NotifOptionVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 8/9/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "NotifOptionVC.h"
#import "QBFlatButton.h"
#import "NotificationVC.h"
#import "NotifFileOptionCell.h"
#import "AFTableViewCell.h"
#import "SubCat_CollectionCell.h"
#import "MBProgressHUD.h"
#import "UserConversationChatVC.h"

#define PageSize			20


@interface NotifOptionVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation NotifOptionVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
	[super viewDidLoad];
    
    // Do any additional setup after loading the view.
    NSArray *array = [self.navigationController viewControllers];
    for (int i=0;i<array.count;i++) {
        if ([[array objectAtIndex:i] isKindOfClass:[CreateHBlabVC class]]) {
            NSLog(@"going in loop");
            self.childController = [array objectAtIndex:i];
            self.delegate = self.childController;
        }
        
    }
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
    
    self.arrSelectedIds = [NSArray arrayWithArray:(NSArray *)[appDelegate.dic_NotificationReleatedData valueForKey:SelectedIds]];
    self.isGroupNotif = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue];
    self.isNotifSendToAll = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_NotifSendToAll] boolValue];
    
	self.arrData = [[NSMutableArray alloc] init];
    self.contentOffsetDictionary = [NSMutableDictionary dictionary];

	[self performSelector:@selector(LoadViewSetting)];
}

-(void)viewWillAppear:(BOOL)animated{
	self.pageCounter = 1;
    appDelegate.currentVc = self;
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
    
    self.selectedRowIndex = -1;
    
    NSLog(@"%@",appDelegate.dic_NotificationReleatedData);
    [HUD show:YES];

    [self getNotifOptionList];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    appDelegate.isShouldShowReplyPopUp = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
}

-(IBAction)btnBackClicked:(id)sender{
	[self.navigationController popViewControllerAnimated:NO];
}

-(void)getNotifOptionList{
    
	if (self.request !=nil) {
		self.request = nil;
	}
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Name",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Descript",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue, @"PageSize",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"6",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_ALLMY_CAT_SUBCAT withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURLWithImg:strUrl WithDic:dic isAddHeader:TRUE forLoader:HUD];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }

    strUrl = nil;
}

-(void)getSubCatList{
    
    if (self.arrSubCat== nil) {
        self.arrSubCat = [[NSMutableArray alloc] init] ;
    }
    
    [self.arrSubCat addObjectsFromArray:[NSArray arrayWithArray:[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"SoundSubMaster"]]];

    [self.tblData reloadData];
    
    if (self.arrSubCat.count > 0) {
        [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:self.selectedSection] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
}

-(void)sendNotifMsgAtIndexForVidiBlabAtIndex{
  
    NSArray *arrSelectedIds = [NSArray arrayWithArray:(NSArray *)[appDelegate.dic_NotificationReleatedData valueForKey:SelectedIds]];
    BOOL isGroupNotif = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue];
 //   BOOL isNotifSendToAll = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_NotifSendToAll] boolValue];
    NSString *strCaption = [NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:ImageCaption]];
    
    NSString *strPath = [appDelegate.dic_NotificationReleatedData valueForKey:CapturedVideo];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    
    if ([fm fileExistsAtPath:strPath]) {
        NSLog(@"file exist");
    }
    NSMutableData *data;
    if(![self.delegate respondsToSelector:@selector(passBlabDataForHBlab:)]) {
        
        data = [NSMutableData dataWithContentsOfFile:strPath];
    }
    
    [HUD show:YES];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:(isGroupNotif)?@"":[NSString stringWithFormat:@"%@",[arrSelectedIds componentsJoinedByString:@"|"]],KeyValue,@"ReceiverIDs",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"ID"]],KeyValue,@"Ctype",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:(isGroupNotif)?[NSString stringWithFormat:@"%@",[arrSelectedIds componentsJoinedByString:@"|"]]:@"0",KeyValue,@"GroupIDs",KeyName, nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",(self.selectedRowIndex != -1)?[[self.arrSubCat objectAtIndex:self.selectedRowIndex] valueForKey:@"ID"]:@"0"],KeyValue,@"SubCatID",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"6",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",(self.isNotifSendToAll)?@"true":@"false"],KeyValue,@"AllFriend",KeyName, nil],@"7",
                         [NSDictionary dictionaryWithObjectsAndKeys:((data!= nil)?data:@""),KeyValue,@"VideoData",KeyName, nil],@"8",
                         [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:strCaption].length > 0)?strCaption:@"",KeyValue,@"Caption",KeyName, nil],@"9",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:IsPublicImg]],KeyValue, IsPublicImg,KeyName, nil],@"10",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:RequestedKeepStatus]],KeyValue, RequestedKeepStatus, KeyName, nil],@"11",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:BlabType]],KeyValue, BlabType, KeyName, nil],@"12",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"13",
                         nil];
    
    //only @"ID" represents notif If that we want to forward, in this screen it will be 0 as we arent forwarding any notif
    if([self.delegate respondsToSelector:@selector(passBlabDataForHBlab:)]) {
        [self.delegate passBlabDataForHBlab:dic];
        [HUD hide:YES];
        [self popToCreateHBlab];
        return;
    }
    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];       //SEND_TEST_MSG     //SEND_NOTIF_MSG
    
    AFNetworkingDataTransaction *request = [AFNetworkingDataTransaction sharedManager];
    //[request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    [request SetCallForURLWithImg:strUrl WithDic:dic isAddHeader:TRUE forLoader:HUD];
    
    if (request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:2];
        HUD.mode = MBProgressHUDModeDeterminate;
        HUD.delegate = self;
        HUD.labelText = @"Sending blab";
        
        [request._currentRequest setUploadProgressBlock:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) {
            double percentDone = (double)totalBytesWritten / (double)totalBytesExpectedToWrite;
            //Upload Progress bar here
            NSLog(@"progress updated(percentDone) : %f", percentDone);
            [HUD setProgress:percentDone];
            if (percentDone == 1.0) {
           //     [self.timer invalidate];
                HUD.mode = MBProgressHUDModeIndeterminate;
                HUD.labelText = @"";
            }
        }];
    }
}

-(void)sendNotifMsgAtIndex:(int)index isFromSubCat:(BOOL)isFromSubCat{
	if (self.request !=nil) {
		self.request = nil;
	}
	
    HUD.mode = MBProgressHUDModeIndeterminate;
    HUD.labelText = @"";
    NSLog(@"dic_NotificationReleatedData %@",appDelegate.dic_NotificationReleatedData);
    UIImage *img = [appDelegate.dic_NotificationReleatedData valueForKey:CapturedImage];
    
    NSString *strCaption = [NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:ImageCaption]];
//    NSString *goodValue;
    if ([DataValidation checkNullString:strCaption].length>0) {
//        NSData *data = [strCaption dataUsingEncoding:NSNonLossyASCIIStringEncoding];
//        NSData *data = [strCaption dataUsingEncoding:NSUTF8StringEncoding];
//        goodValue = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
//        goodValue = [strCaption stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    }
    [HUD show:YES];
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:(self.isGroupNotif)?@"":[NSString stringWithFormat:@"%@",[self.arrSelectedIds componentsJoinedByString:@"|"]],KeyValue,@"ReceiverIDs",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"ID"]],KeyValue,@"Ctype",KeyName, nil],@"3",
						 [NSDictionary dictionaryWithObjectsAndKeys:(self.isGroupNotif)?[NSString stringWithFormat:@"%@",[self.arrSelectedIds componentsJoinedByString:@"|"]]:@"0",KeyValue,@"GroupIDs",KeyName, nil],@"4",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",(isFromSubCat)?[[self.arrSubCat objectAtIndex:index] valueForKey:@"ID"]:@"0"],KeyValue,@"SubCatID",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"6",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",(self.isNotifSendToAll)?@"true":@"false"],KeyValue,@"AllFriend",KeyName, nil],@"7",
                         [NSDictionary dictionaryWithObjectsAndKeys:((img!= nil)?img:@""),KeyValue,@"ImgData",KeyName, nil],@"8",
                         [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:strCaption].length > 0)?strCaption:@"",KeyValue,@"Caption",KeyName, nil],@"9",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:IsPublicImg]],KeyValue, IsPublicImg,KeyName, nil],@"10",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:RequestedKeepStatus]],KeyValue, RequestedKeepStatus, KeyName, nil],@"11",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:BlabType]],KeyValue, BlabType, KeyName, nil],@"12",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"13",

						 nil];
    if([self.delegate respondsToSelector:@selector(passBlabDataForHBlab:)]) {
        [self.delegate passBlabDataForHBlab:dic];
        [HUD hide:YES];
        [self popToCreateHBlab];
        return;
    }
    //only @"ID" represents notif If that we want to forward, in this screen it will be 0 as we arent forwarding any notif
    NSLog(@"send notif dic---> %@",dic);
	NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];       //SEND_TEST_MSG     //SEND_NOTIF_MSG
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURLWithImg:strUrl WithDic:dic isAddHeader:TRUE forLoader:HUD];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }

  	strUrl = nil;
}



-(NSArray*) indexPathsForSection:(int)section withNumberOfRows:(int)numberOfRows {
    
    NSMutableArray* indexPaths = [NSMutableArray new];
    
    for (int i = 0; i < numberOfRows; i++) {
        NSIndexPath* indexPath = [NSIndexPath indexPathForRow:i inSection:section];
        [indexPaths addObject:indexPath];
    }
    
    return indexPaths;
}

-(IBAction)btnShowSubCategoriesClicked:(id)sender{
	
	UIButton *btn = ((UIButton *)sender);
    if ([[[self.arrData objectAtIndex:btn.tag] objectForKey:@"SoundSubMaster"] count]>0) {
        if (self.isShowSubCategories) {
            
            self.isShowFooter = NO;
            self.isShowSubCategories = NO;
            int numOfRows = (int)[self.tblData numberOfRowsInSection:self.selectedSection];
            NSArray* indexPaths = [self indexPathsForSection:self.selectedSection withNumberOfRows:numOfRows];
            [self.tblData deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationNone];
            
            CGRect rect = [self.tblData rectForSection:(int)btn.tag];
            
            [self.tblData scrollRectToVisible:rect animated:NO];
            
            if (self.selectedSection != btn.tag) {
                [self btnShowSubCategoriesClicked:sender];
            }
            else{
                [UIView setAnimationsEnabled:NO];
                [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:self.selectedSection] withRowAnimation:UITableViewRowAnimationFade];
                [UIView setAnimationsEnabled:YES];
            }
        }
        else{
            
            self.isShowSubCategories = YES;
            
            self.selectedSection = (int)btn.tag;
            
            if (self.selectedSection == self.arrData.count-1) {
                self.isShowFooter = YES;
            }
            else{
                self.isShowFooter = NO;
            }
            
            if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedSection] valueForKey:IS_CAT_HAS_SUBCATS]]].length > 0) {
                
                if ([[[self.arrData objectAtIndex:self.selectedSection] valueForKey:IS_CAT_HAS_SUBCATS] boolValue]) {
                    
                    //call web service
                    
                    if (self.arrSubCat != nil) {
                        if (self.arrSubCat.count > 0) {
                            [self.arrSubCat removeAllObjects];
                        }
                    }
                    [self getSubCatList];
                }
                else{
                    //initiate notif
                    //				self.isShowSubCategories = NO;
                    //				[self btnNotifSelected:nil];
                    self.isShowSubCategories = NO;
                    [Validation removeAdviewFromSuperView];
                    [self.tblData reloadData];
                }
            }
            else{
                //initiate notif
                //			self.isShowSubCategories = NO;
                //			[self btnNotifSelected:nil];
                self.isShowSubCategories = NO;
                [Validation removeAdviewFromSuperView];
                [self.tblData reloadData];
            }
        }
    }
    else{
        //this category does not have sub category
        self.selectedSection = (int)btn.tag;
        self.isShowSubCategories = NO;
        [self btnNotifSelected:nil];
    }

}

#pragma mark
#pragma mark web service method

- (void)successResponseWithData:(id)request withTag:(int)tag{
    //	NSError *error = nil;
    
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    //NSLog(@"dictionary = %@",dicResponse);
    if (appDelegate.currentVc == self) {
        if (dicResponse != nil) {
            if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                NSLog(@"dic = %@",dicResponse);
                [HUD hide:YES];
                [appDelegate callLogOutService];
            }
            else{
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        if (tag == 1) {
                            //get cat list
                            id response = [dicResponse objectForKey:RESPONSE];
                            if (response != nil) {
                                
                                NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                                [self.arrData addObjectsFromArray:arr];
                                
                                if (arr.count < PageSize) {
                                    self.isDataNull = YES;
                                }
                                arr = nil;
                            }
                            [self.tblData reloadData];
                            response = nil;
                            [HUD hide:YES];
                        }
                        else if (tag == 2){
                            //send notification
                            
                            // [HUD hide:YES];
                            NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
                            self.isNotifSentMsgVisible = YES;
                            // [Validation showToastMessage:@"Sent" displayDuration:3];
                            __block UIImageView *imageView;
                            UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                            imageView = [[UIImageView alloc] initWithImage:image];
                            
                            HUD.customView = imageView;
                            HUD.mode = MBProgressHUDModeText;
                            HUD.labelText = @"Sent";
                            imageView = nil;
                            [self performSelector:@selector(popToNotifListScreen:) withObject:[NSNumber numberWithBool:NO] afterDelay:3];
                        }
                    }
                    else{
                        if (tag==2) {
                            if ([[dicResponse objectForKey:RESPONSE] isKindOfClass:[NSArray class]]) {
                                
                                //[Validation showToastMessage:[[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] displayDuration:ERROR_MSG_DURATION];
                                HUD.mode = MBProgressHUDModeText;
                                HUD.delegate = self;
                                HUD.detailsLabelFont = [UIFont boldSystemFontOfSize:16];
                                HUD.detailsLabelText = [[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] ;
                                [self performSelector:@selector(popToNotifListScreen:) withObject:[NSNumber numberWithBool:YES] afterDelay:4];
                            }
                            else{
                                [HUD hide:YES];
                            }
                        }
                        else{
                            [HUD hide:YES];
                        }
                    }
                    self.request = nil;
                }
                else{
                    [HUD hide:YES];
                    
                }
                
                dicResponse = nil;
            }
            
        }
        else{
            [HUD hide:YES];
        }
    }
    
    dicResponse = nil;
}


- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}

- (void)requestFinished:(ASIHTTPRequest *)request{
    
	NSError *error = nil;
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];
    
    if (dicResponse != nil){
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if (request.tag == 1) {
                        //get cat list
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            [self.arrData addObjectsFromArray:arr];
                            
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            arr = nil;
                        }
                        [self.tblData reloadData];
                        response = nil;
                        [HUD hide:YES];
                    }
                    else if (request.tag == 2){
                        //send notification
                        
                       // [HUD hide:YES];
                        NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
                        self.isNotifSentMsgVisible = YES;
                       // [Validation showToastMessage:@"Sent" displayDuration:3];
                        __block UIImageView *imageView;
                        UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                        imageView = [[UIImageView alloc] initWithImage:image];
                        
                        HUD.customView = imageView;
                        HUD.mode = MBProgressHUDModeText;
                        HUD.labelText = @"Sent";
                        imageView = nil;
                        [self performSelector:@selector(popToNotifListScreen:) withObject:[NSNumber numberWithBool:NO] afterDelay:3];
                    }
                    if (request.tag == 3) {
                        //get sub-cat list
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            if (arr.count >0) {
                                if (self.arrSubCat== nil) {
                                    self.arrSubCat = [[NSMutableArray alloc] init];
                                }
                                [self.arrSubCat addObjectsFromArray:arr];
                                
                                [self.tblData reloadData];
                            }
                            
                            [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:self.selectedSection] atScrollPosition:UITableViewScrollPositionTop animated:NO];
                            
                            arr = nil;
                        }
                        //[self.tblData reloadData];
                        response = nil;
                        [HUD hide:YES];
                    }
                }
            }
            else{
                [HUD hide:YES];
                if (self.arrData.count == 0) {
                    [AlertHandler alertTitle:MESSAGE message:@"No Blabeey found under this category.\nPlease try another category." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];   
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
	
	self.request = nil;
	dicResponse = nil;
}

- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
-(void)popToCreateHBlab{
    
//    [Validation cleanNotifcationRelatedDicData];
    
    [HUD hide:YES];
    
//    self.isNotifSentMsgVisible = NO;
//    [self.request CancleOngoingRequest];
//    self.request = nil;
    
    NSArray *arr = [self.navigationController viewControllers];
//    BOOL isGotPopViewController = FALSE;
    
    
//    [self removeFilesFromDir];
    
    for (UIViewController *v in arr) {

        if ([v isKindOfClass:[CreateHBlabVC class]]) {
            [self.navigationController popToViewController:v animated:YES];
            break;
        }
    }
    
}
-(void)popToNotifListScreen:(NSNumber*)isBlabSendFail{
    
    [Validation cleanNotifcationRelatedDicData];
    
	[HUD hide:YES];
    
    self.isNotifSentMsgVisible = NO;
    [self.request CancleOngoingRequest];
    self.request = nil;
    
    NSArray *arr = [self.navigationController viewControllers];
    BOOL isGotPopViewController = FALSE;
    
    
    [self removeFilesFromDir];
    
    for (UIViewController *v in arr) {
        if ([isBlabSendFail boolValue]) {
            if ([v isKindOfClass:[NotificationVC class]]) {
                isGotPopViewController = TRUE;
                [self.navigationController popToViewController:v animated:YES];
                break;
            }
        }
        else{
        if ([v isKindOfClass:[UserConversationChatVC class]]) {
            isGotPopViewController = TRUE;
            [self.navigationController popToViewController:v animated:YES];
            break;
        }
        }
    }
    
    
    if (!isGotPopViewController) {
        
        [self removeViewControllersFromStack];
        
        if (appDelegate.selectedMenuIndex>0) {
            appDelegate.selectedMenuIndex = 0;
         }
        SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
        
        [UIView transitionWithView:self.navigationController.view
                          duration:0.5
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.navigationController pushViewController:ivc animated:NO];
                        }
                        completion:nil];
    }

}

-(void)removeViewControllersFromStack{
  //   NSArray *arrVC = self.navigationController.viewControllers;
    for (id vc in self.navigationController.viewControllers){
		if ([vc isKindOfClass:[FavoritesVC class]]) {
			[self removeFromNavigationController:vc animated:NO];
		}
        else if ([vc isKindOfClass:[SearchFriendVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[OtherFriendNotifListVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[SettingsVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[CategoryListForUploadVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[GroupListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[UserListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[RecordingOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
	}
    
}

-(void)removeFromNavigationController:(UIViewController *)controller animated:(BOOL)animated {
    
    NSMutableArray *allViewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];;
    [allViewControllers removeObjectIdenticalTo:controller];
    self.navigationController.viewControllers = allViewControllers;
	
}

-(void)removeFilesFromDir{
    NSError *error = nil;
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *arrPath = [fm contentsOfDirectoryAtPath:VIDEO_RECORDING_FOLDER error:&error];
    for (int i=0; i<arrPath.count; i++) {
        [fm removeItemAtPath:[VIDEO_RECORDING_FOLDER stringByAppendingPathComponent:[arrPath objectAtIndex:i]] error:&error];
    }
}

#pragma mark  UITableViewDelegate



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return self.arrData.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	return 130;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
	if (self.isShowFooter) {
		if (section == self.arrData.count-1) {
			return 40;
		}
		
	}
	return 0;
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
	UIView *viewFooterContainer = [[UIView alloc] init] ;
	viewFooterContainer.backgroundColor = [UIColor clearColor];
	return viewFooterContainer;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
	UIView *viewHeaderContainer = [[UIView alloc] init];
	
	AsyncImageView *catImg = [[AsyncImageView alloc] init];
	UILabel *lblTitle = [[UILabel alloc] init];
	UILabel *lblDesc = [[UILabel alloc] init];
	UIButton *btnCategories = [UIButton buttonWithType:UIButtonTypeCustom];
	UIImageView     *imgSubCategory = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icn_circle_plus.png"]];
    
    
	btnCategories.backgroundColor = [UIColor clearColor];
	
	lblTitle.numberOfLines = 0;
	lblDesc.numberOfLines = 0;
	lblDesc.lineBreakMode = NSLineBreakByWordWrapping;
	lblTitle.lineBreakMode = NSLineBreakByWordWrapping;
	
	catImg.layer.borderColor = [UIColor whiteColor].CGColor;
	catImg.layer.borderWidth = 2;
	
	if (section % 2==0) {
		lblDesc.textAlignment = NSTextAlignmentLeft;
		lblTitle.textAlignment = NSTextAlignmentLeft;
		
		catImg.frame = CGRectMake(5, 15, 100, 100);
		
		lblTitle.frame = CGRectMake(110, 8, tableView.frame.size.width-120, 35);
		lblDesc.frame = CGRectMake(110, 40, tableView.frame.size.width-120, 80);
        
        imgSubCategory.frame = CGRectMake(5, 105, 20, 20);
	}
	else{
		lblDesc.textAlignment = NSTextAlignmentRight;
		lblTitle.textAlignment = NSTextAlignmentRight;
		
		catImg.frame = CGRectMake(tableView.frame.size.width-100-5, 15, 100, 100);
		
		lblTitle.frame = CGRectMake(5, 8, tableView.frame.size.width-120, 35);
		lblDesc.frame = CGRectMake(5, 40, tableView.frame.size.width-120, 80);
        
        imgSubCategory.frame = CGRectMake(tableView.frame.size.width-25, 105, 20, 20);
	}
		
    imgSubCategory.hidden = YES;
    if ([[[self.arrData objectAtIndex:section] objectForKey:@"SoundSubMaster"] count]>0) {
        imgSubCategory.hidden = NO;
        if (self.isShowSubCategories && (self.selectedSection == section)) {
            [imgSubCategory setImage:[UIImage imageNamed:@"icn_circle_minus.png"]];
        }
        else{
            [imgSubCategory setImage:[UIImage imageNamed:@"icn_circle_plus.png"]];
        }
    }
    
//	lblTitle.font = [UIFont fontWithName:Font_Montserrat_Bold size:26];
//	lblDesc.font = [UIFont fontWithName:Font_Montserrat_Regular size:16];
	lblTitle.font = [UIFont fontWithName:Font_Montserrat_Bold size:20];
	lblDesc.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
	
	lblDesc.adjustsFontSizeToFitWidth = YES;
	lblTitle.adjustsFontSizeToFitWidth = YES;
	
	[catImg setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:CATEGORY_PHOTO_PATH]]]];
	[Validation setCorners:catImg];
	
	lblTitle.textColor = [UIColor whiteColor];
	[lblTitle setText:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:NAME]]];
	
	lblDesc.textColor = [UIColor colorWithRed:0.2 green:0.2 blue:0.2 alpha:0.8];
	lblDesc.text = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:DESCRIPTION]];
	NSString *strChar = [[[self.arrData objectAtIndex:section] valueForKey:NAME] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	viewHeaderContainer.backgroundColor = [Validation getColorForAlphabet:[NSString stringWithFormat:@"%@",strChar]];
	viewHeaderContainer.frame = CGRectMake(0, 0, tableView.frame.size.width, 130);
	
	btnCategories.frame = viewHeaderContainer.frame;
	[btnCategories addTarget:self action:@selector(btnShowSubCategoriesClicked:) forControlEvents:UIControlEventTouchUpInside];
	btnCategories.tag = section;
	
	
	[viewHeaderContainer addSubview:catImg];
	[viewHeaderContainer addSubview:lblTitle];
	[viewHeaderContainer addSubview:lblDesc];
	[viewHeaderContainer addSubview:btnCategories];
	[viewHeaderContainer addSubview:imgSubCategory];
    
//	[lblTitle release];
	lblTitle = nil;
	
///	[lblDesc release];
	lblDesc = nil;
	
//	[catImg release];
	catImg = nil;
    
    imgSubCategory = nil;
    
    if (section == self.arrData.count-1) {
        if (!self.isDataNull) {
          //  [Validation showLoadingIndicator];
            [HUD show:YES];
            
            self.pageCounter ++;
            [self performSelectorInBackground:@selector(getNotifOptionList) withObject:nil];
        }
    }
    
	return viewHeaderContainer;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 120;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	//return self.arrData.count;
	if (section == self.selectedSection) {
		if (self.isShowSubCategories) {
            NSLog(@"%f",ceil([self.arrSubCat count]/2.0));
            int rows = (int)(ceil([self.arrSubCat count]/2.0));
			return rows;
		}
	}
	return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
//	NSString *cellIdentifier = @"CellIdentifier";
    static NSString *CellIdentifier = @"CellIdentifier";
    
    AFTableViewCell *cell = (AFTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    [cell clearsContextBeforeDrawing];
    
    if (!cell)
    {
        cell = [[AFTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    [cell.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:CollectionViewCellIdentifier];

    NSString *strChar = [[[self.arrData objectAtIndex:self.selectedSection] valueForKey:NAME] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	cell.collectionView.backgroundColor = [Validation getColorForAlphabet:[NSString stringWithFormat:@"%@",strChar]];

    cell.collectionView.dataSource = self;
    cell.collectionView.delegate = self;
    
    return cell;
    
//	NotifFileOptionCell *cell = (NotifFileOptionCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
//	
//	cell.lblSubCatTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:20];
//	[cell.lblSubCatTitle setText:[NSString stringWithFormat:@"%@",[[self.arrSubCat objectAtIndex:indexPath.row] valueForKey:NAME]]];
//	
//    cell.lblSubCatTitle.textColor = [Validation getColorForAlphabet:cell.lblSubCatTitle.text];
//	[cell.imgProfile setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[self.arrSubCat objectAtIndex:indexPath.row] valueForKey:SUBCATEGORY_LOGO_PATH]]]];
//    cell.imgProfile.layer.borderColor = [UIColor whiteColor].CGColor;
//    cell.imgProfile.layer.borderWidth = 2;
//    [Validation setCorners:cell.imgProfile];
    
    
	//return cell;
}

//-(void)tableView:(UITableView *)tableView willDisplayCell:(AFTableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
-(void)tableView:(UITableView *)tableView willDisplayCell:(AFTableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setCollectionViewDataSourceDelegate:self index:indexPath.row forDictionary:[self.arrSubCat objectAtIndex:indexPath.row]];
    
    NSInteger index = cell.collectionView.tag;
    
    CGFloat horizontalOffset = [self.contentOffsetDictionary[[@(index) stringValue]] floatValue];
    [cell.collectionView setContentOffset:CGPointMake(horizontalOffset, 0)];
}


#pragma mark - UICollectionViewDataSource Methods

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
     int rowIndex = (int)collectionView.tag+1;
    if (self.isShowSubCategories) {
        if ((rowIndex*2) > self.arrSubCat.count) {
            return 1;
        }
        return  2;
    }
    
   // NSLog(@"section = %d",(int)collectionView.tag);
   // if (section == self.selectedSection) {
//		if (self.isShowSubCategories) {
//			return  2;
//		}
//	}
	return 0;
}
    
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"Cell";
    
    SubCat_CollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    [cell clearsContextBeforeDrawing];
    
    cell.imgProfile.image = nil;
    cell.imgProfile.imageURL = nil;
 
    int count = ((int)collectionView.tag+1)*2;         //by multiples of 2
    int index = 0;
    
    if (indexPath.row == 0) {
        index = count - 2;
    }
    else{
        index = count - 1;
    }
    NSLog(@"index = %d",index);
    
    cell.layer.borderColor = [UIColor whiteColor].CGColor;
    cell.layer.borderWidth = 0.5;
    
    if (index < (int)self.arrSubCat.count) {
        cell.backgroundColor = [Validation getColorForAlphabet:[[self.arrSubCat objectAtIndex:index] valueForKey:NAME]];
        cell.layer.borderColor = [UIColor whiteColor].CGColor;
        cell.layer.borderWidth = 0.5;
        [cell setCollectionViewForindex:indexPath.row forDictionary:[self.arrSubCat objectAtIndex:index]];
    }
    else{
        cell.imgProfile.hidden = YES;
        [cell.imgProfile setImage:nil];
        cell.imgFriendshipStatus.hidden = YES;
        cell.lblSubCatTitle.textColor = [UIColor whiteColor];
        [cell.lblSubCatTitle setText:@""];
        cell.lblSubCatTitle.hidden = YES;
        NSString *strChar = [[[self.arrData objectAtIndex:self.selectedSection] valueForKey:NAME] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        cell.backgroundColor = [Validation getColorForAlphabet:[NSString stringWithFormat:@"%@",strChar]];
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    int count = ((int)collectionView.tag+1)*2;         //by multiples of 2
    int index = 0;
    
    if (indexPath.row == 0) {
        index = count - 2;
    }
    else{
        index = count - 1;
    }
    NSLog(@"index = %d",index);
    self.selectedRowIndex = index;
    
    if (index < self.arrSubCat.count) {
        
        //check message type
        if ([[appDelegate.dic_NotificationReleatedData valueForKey:BlabType] isEqualToString:@"2"]) {
            //vidiblab
            [HUD show:YES];
            NSString *strPath = @"";
            
            if ([[[self.arrData objectAtIndex:self.selectedSection] objectForKey:@"SoundSubMaster"] count]>0) {
                //has subcategory, so use sub-category random url
                strPath = [[[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"SoundSubMaster"] objectAtIndex:self.selectedRowIndex] valueForKey:@"RandomSoundURL"];
                NSLog(@"File to download = %@",[[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"SoundSubMaster"] valueForKey:@"RandomSoundURL"]);
            }
            else{
                //category isnot having sub category, so use category random url
                strPath = [[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"RandomSoundURL"];
                NSLog(@"File to download = %@",[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"RandomSoundURL"]);
            }
            [self downloadSoundFileAtPath:strPath];
        }
        else{
            //it is either image or simple blab
            [self sendNotifMsgAtIndex:index isFromSubCat:YES];
        }
    }
}

-(void)downloadSoundFileAtPath:(NSString *)strPath{
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    
    NSFileManager *fm = [NSFileManager defaultManager];

    NSURL *URL = [NSURL URLWithString:strPath];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    NSURL *documentsDirectoryURL = [fm URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
    
    NSURL *urlFilePath = [documentsDirectoryURL URLByAppendingPathComponent:@"music.mp3"];
    if ([fm fileExistsAtPath:[urlFilePath absoluteString]]) {
        [fm removeItemAtPath:[urlFilePath absoluteString] error:NULL];
    }
    
    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:nil destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
        return urlFilePath;
    } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
        NSLog(@"File downloaded to: %@", response);
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory1 = [paths objectAtIndex:0];
        
        NSString *strDownloadAudioFilePath= [documentsDirectory1 stringByAppendingPathComponent:@"music.mp3"];
        NSString *strMoveAudioFileAtPath = [VIDEO_RECORDING_FOLDER stringByAppendingString:@"/music.mp3"];
        
        if ([fm fileExistsAtPath:strDownloadAudioFilePath]) {
            NSLog(@"file exists");
            {
                if ([fm fileExistsAtPath:strMoveAudioFileAtPath]) {
                    [fm removeItemAtPath:strMoveAudioFileAtPath error:NULL];
                }
                BOOL fileCopied = [fm moveItemAtPath:strDownloadAudioFilePath toPath:strMoveAudioFileAtPath error:&error];
                (fileCopied)?[self mergeRecording_AudioFileAtPath:strMoveAudioFileAtPath]:[Validation showToastMessage:@"failed to copy" displayDuration:ERROR_MSG_DURATION];
            }
        }
        else{
            NSLog(@"file does not download");
            [HUD hide:YES];
            [Validation showToastMessage:@"File download failed." displayDuration:ERROR_MSG_DURATION];
        }
    }];
    [downloadTask resume];
    
}

-(void)mergeRecording_AudioFileAtPath:(NSString *)strAudioPath{
    
    AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
    // 2 - Video track
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSURL* sourceMovieURL = [NSURL fileURLWithPath:[appDelegate.dic_NotificationReleatedData valueForKey:CapturedVideo]];
    NSError *error = nil;
    //------ create Audio and Video Assets
    
    AVURLAsset *VideoAsset = [[AVURLAsset alloc]initWithURL:sourceMovieURL options:nil];
    AVURLAsset* audioAsset = [[AVURLAsset alloc]initWithURL:[NSURL fileURLWithPath:strAudioPath] options:nil];

    //------
    
    //1 ---- add external audio - Soundtrack
    
    AVMutableCompositionTrack *AudioOfSoundTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
    
    [AudioOfSoundTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, VideoAsset.duration) ofTrack:([audioAsset tracksWithMediaType:AVMediaTypeAudio].count > 0)?[[audioAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
    //------
    
    //2 ---- video
    
    AVMutableCompositionTrack *VideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo preferredTrackID:kCMPersistentTrackID_Invalid];
    
    [VideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, VideoAsset.duration)
                        ofTrack:([VideoAsset tracksWithMediaType:AVMediaTypeVideo].count >0)?[[VideoAsset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
    //------
    
//    //3	----- url of first path - audio of video
//    AVMutableCompositionTrack *VideoAudioTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
//    
//    [VideoAudioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, VideoAsset.duration) ofTrack:([VideoAsset tracksWithMediaType:AVMediaTypeAudio].count > 0)?[[VideoAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
    //-------
    
    //---- ------- ------- ------- ------
    //----
    AVMutableVideoCompositionInstruction *instruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
    instruction.timeRange = CMTimeRangeMake(kCMTimeZero, [mixComposition duration]);
    AVAssetTrack *videoTrack = [[mixComposition tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
    AVMutableVideoCompositionLayerInstruction* layerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoTrack];
    
    instruction.layerInstructions = [NSArray arrayWithObject:layerInstruction];
    
    //---- ------- ------- ------- ------
    
    AVAssetExportSession* _assetExport = [[AVAssetExportSession alloc] initWithAsset:mixComposition presetName:AVAssetExportPresetMediumQuality];
    
    NSString *strPath = [VIDEO_RECORDING_FOLDER stringByAppendingPathComponent:@"newMergedMovie111.mp4"];
    
    if ([fileManager fileExistsAtPath:strPath]) {
        [fileManager removeItemAtPath:strPath error:nil];
    }
    
    NSURL *exportURL = [NSURL fileURLWithPath:strPath];
    _assetExport.outputURL = exportURL;
    _assetExport.shouldOptimizeForNetworkUse = YES;
    _assetExport.outputFileType = @"com.apple.quicktime-movie";
    
    [_assetExport exportAsynchronouslyWithCompletionHandler:^{
        switch ([ _assetExport status]) {
                
            case AVAssetExportSessionStatusFailed:{
                [HUD hide:YES];
                [Validation showToastMessage:@"merging failed" displayDuration:SUCCESS_MSG_DURATION];
            }
                break;
            case AVAssetExportSessionStatusCancelled:{
                [HUD hide:YES];
                [Validation showToastMessage:@"merging cancelled" displayDuration:SUCCESS_MSG_DURATION];
            }
                break;
            case AVAssetExportSessionStatusCompleted:{
               // [HUD hide:YES];
                [appDelegate.dic_NotificationReleatedData setValue:strPath forKey:CapturedVideo];
                [self sendMergedFileToServer];
            }
                break;
            default:{
                [HUD hide:YES];
            }
                break;
        }
    }];
}

-(void)sendMergedFileToServer{
    dispatch_sync(dispatch_get_main_queue(), ^{
        [HUD show:YES];
        [self sendNotifMsgAtIndexForVidiBlabAtIndex];
    });
}

#pragma mark - UIScrollViewDelegate Methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
    self.selectedRowIndex = -1;
    
    if ([[appDelegate.dic_NotificationReleatedData valueForKey:BlabType] isEqualToString:@"2"]) {
        //vidiblab
        NSString *strPath = @"";
        [HUD show:YES];
        if ([[[self.arrData objectAtIndex:self.selectedSection] objectForKey:@"SoundSubMaster"] count]>0) {
            //has subcategory, so use sub-category random url
            strPath = [[[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"SoundSubMaster"] objectAtIndex:indexPath.row] valueForKey:@"RandomSoundURL"];
            NSLog(@"File to download = %@",[[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"SoundSubMaster"] valueForKey:@"RandomSoundURL"]);
        }
        else{
            //category isnot having sub category, so use category random url
            strPath = [[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"RandomSoundURL"];
            NSLog(@"File to download = %@",[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"RandomSoundURL"]);
        }
        [self downloadSoundFileAtPath:strPath];
    }
    else{
        [self sendNotifMsgAtIndex:(int)indexPath.row isFromSubCat:YES];
    }
}

-(void)btnNotifSelected:(id)sender{
    self.selectedRowIndex = -1;
    if ([[appDelegate.dic_NotificationReleatedData valueForKey:BlabType] isEqualToString:@"2"]) {
        //vidiblab
        NSString *strPath = @"";
        [HUD show:YES];
//        if ([[[self.arrData objectAtIndex:self.selectedSection] objectForKey:@"SoundSubMaster"] count]>0) {
//            //has subcategory, so use sub-category random url
//            strPath = [[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"SoundSubMaster"] valueForKey:@"RandomSoundURL"];
//            NSLog(@"File to download = %@",[[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"SoundSubMaster"] valueForKey:@"RandomSoundURL"]);
//        }
//        else{
            //category isnot having sub category, so use category random url
            strPath = [[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"RandomSoundURL"];
            NSLog(@"File to download = %@",[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"RandomSoundURL"]);
//        }
        [self downloadSoundFileAtPath:strPath];
    }
    else{
        [self sendNotifMsgAtIndex:self.selectedSection isFromSubCat:NO];
    }
	//[self sendNotifMsgAtIndex:self.selectedSection isFromSubCat:NO];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
