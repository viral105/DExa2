//
//  CustomCameraVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 24/12/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "CustomCameraVC.h"

@interface CustomCameraVC ()

@end

@implementation CustomCameraVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.isFlashOn = FALSE;
    self.isFrontCamera = FALSE;
    self.picker= [[UIImagePickerController alloc] init];
    self.picker.delegate = self;
    
    self.picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    self.picker.showsCameraControls = FALSE;

    if ([UIScreen mainScreen].bounds.size.height==480) {// Done by viral for ipad campatible screen as client wants it to give demo to others
        self.picker.view.frame = CGRectMake(0, 50, 320, 250);
    }
    else{
        self.picker.view.frame = CGRectMake(0, 50, 320, 320);
    }
    [self.view addSubview:self.picker.view];
        
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark    Methods

-(IBAction)btnCameraClickClicked:(id)sender{
	[self.picker takePicture];
}

-(IBAction)btnCancelClicked:(id)sender{
    [self.picker.view removeFromSuperview];
    self.picker = nil;

    [self.delegate cancelButtonPressed];
}

-(IBAction)btnCameraModeClicked:(id)sender{
    
    if (!self.isFrontCamera) {
		self.picker.cameraDevice = UIImagePickerControllerCameraDeviceFront;
        self.isFrontCamera = TRUE;
        [self.btnFrontCamera setImage:[UIImage imageNamed:BTN_CAMERA_FRONT_SELECTED] forState:UIControlStateNormal];
	}
	else{
        self.isFrontCamera = FALSE;
		self.picker.cameraDevice = UIImagePickerControllerCameraDeviceRear;
        [self.btnFrontCamera setImage:[UIImage imageNamed:BTN_CAMERA_FRONT_DESELECTED] forState:UIControlStateNormal];
	}
}

-(IBAction)btnFlashModeClicked:(id)sender{
    
    if (!self.isFlashOn) {
        [self.btnFlash setImage:[UIImage imageNamed:BTN_CAMERA_FLASH_SELECTED] forState:UIControlStateNormal];
        [self.picker setCameraFlashMode:UIImagePickerControllerCameraFlashModeOn];
        self.isFlashOn = TRUE;
    }
    else{
        [self.btnFlash setImage:[UIImage imageNamed:BTN_CAMERA_FLASH_DESELECTED] forState:UIControlStateNormal];
        [self.picker setCameraFlashMode:UIImagePickerControllerCameraFlashModeOff];
        self.isFlashOn = FALSE;
    }
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage *image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];

    CGSize imageSize = image.size;
    CGFloat scaleWidth = imageSize.width / 320;
    CGFloat scaleHeight = imageSize.height / 320;

    CGImageRef imageRef = CGImageCreateWithImageInRect([image CGImage], CGRectMake(0, 0, 320*scaleWidth, 320*scaleHeight));
    UIImage *result = [UIImage imageWithCGImage:imageRef scale:1 orientation:image.imageOrientation];
    UIImageWriteToSavedPhotosAlbum(result, NULL, NULL, NULL);

    [self.delegate SetSelectedImage:result];
    
    [self.picker.view removeFromSuperview];
    self.picker = nil;
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{

    [self.picker.view removeFromSuperview];
    self.picker = nil;
    
    [self.delegate cancelButtonPressed];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
