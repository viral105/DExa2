//
//  CustomCameraVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 24/12/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CustomCameraVCDelegate <NSObject>
- (void)SetSelectedImage:(UIImage *)image;
- (void)cancelButtonPressed;

@end

@interface CustomCameraVC : UIViewController <UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@property (nonatomic, strong) UIImagePickerController       *picker;
@property (nonatomic, strong) IBOutlet UIButton             *btnClick;
@property (nonatomic, strong) IBOutlet UIButton             *btnCancel;
@property (nonatomic, strong) IBOutlet UIButton             *btnFrontCamera;
@property (nonatomic, strong) IBOutlet UIButton             *btnFlash;

@property (nonatomic, readwrite) BOOL                       isFrontCamera;
@property (nonatomic, readwrite) BOOL                       isFlashOn;

@property (nonatomic ,assign) id <CustomCameraVCDelegate>       delegate;


@end
