//
//  CaptureImageVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 18/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "CaptureImageVC.h"
#import "ALAssetsLibrary+CustomPhotoAlbum.h"
#define TextViewPlaceHolder         @"Add caption"

#define degreesToRadians(x) (M_PI * x / 180.0)
#define radiansToDegrees(x) (180.0 * x / M_PI)


@interface CaptureImageVC ()

@end

@implementation CaptureImageVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.selectedPrivacy = 2;
    self.selectedTimePeriod = 2;
    self.isKeyboardHidden = YES;
    [self LoadViewSetting];
    self.library = [[ALAssetsLibrary alloc] init];
    [self.library addAssetsGroupAlbumWithName:AlbumName
                                  resultBlock:^(ALAssetsGroup *group) {
                                      NSLog(@"added album:%@", AlbumName);
                                  }
                                 failureBlock:^(NSError *error) {
                                     NSLog(@"error adding album");
                                 }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    appDelegate.currentVc = self;

    if ([self.btnNext isHidden]) {
        self.scrollContainer.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-64-50);
        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        [Validation ResizeViewForAds];
    }
    else{
        self.scrollContainer.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-64-50);
        [Validation removeAdviewFromSuperView];
        [Validation ResizeViewForAds];


    }
}

#pragma mark    Custom Methods

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    self.lblAddPictureFrom.numberOfLines = 0;
    self.lblAddPictureFrom.text = @"Add Picture From\n\n\n";
    self.lblAddPictureFrom.textColor = UIColorFromRGB(0X616161);
    self.lblAddPictureFrom.font = [UIFont fontWithName:Font_Montserrat_Regular size:15];
    
    self.pickedImg.backgroundColor = UIColorFromRGB(0Xe2e2e2);
    self.pickedImg.image = nil;
    
    self.tv_caption.textColor = UIColorFromRGB(0X757575);
    self.tv_caption.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
    
    self.tv_caption.text = TextViewPlaceHolder;
    
    self.btnNext.hidden = TRUE;
    
    self.lblPrivacy.textColor = UIColorFromRGB(0X616161);
    self.lblPrivacy.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    self.lblSetTimePeriod.textColor = UIColorFromRGB(0X616161);
    self.lblSetTimePeriod.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    self.lblRecipientCanOnly.textColor = UIColorFromRGB(0X616161);
    self.lblRecipientCanOnly.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    
    self.lblCharCounter.font = [UIFont fontWithName:Font_Montserrat_Regular size:10];
    
    [self resetPrivacy];
    [self resetTimePeriod];
    
    if ([[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue]) {
        [self hidePrivacyView];
    }
    else{
        [self showPrivacyView];
        if (self.selectedPrivacy == 1) {
            [self showTimePeriodView];
        }
        else{
            [self.btnPublic setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
            [self hideTimePeriodView];
        }
    }
}

-(IBAction)btnImageOptionClicked:(id)sender{
    
    UIButton *btn = ((UIButton *) sender);
    
    [self.tv_caption resignFirstResponder];
    
    if (btn.tag == 0){
        //camera
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            self.objCustomCamera = [MainStoryboard instantiateViewControllerWithIdentifier:CUSTOM_CAMERA_VC];
            self.objCustomCamera.delegate = self;
            self.objCustomCamera.view.frame = CGRectMake(0, 0, 320, DEVICE_HEIGHT);
            [self.view addSubview:self.objCustomCamera.view];
            [self.objCustomCamera didMoveToParentViewController:self];
            [self addChildViewController:self.objCustomCamera];
        }
    }
    else if (btn.tag == 1){
        //library
        self.picker = [[UIImagePickerController alloc]init];
        self.picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        self.picker.delegate = self;
        [self presentViewController:self.picker animated:YES completion:NULL];
    }
}

- (void)SetSelectedImage:(UIImage *)image{
    self.pickedImg.image = image;
    self.btnNext.hidden = FALSE;
    [Validation removeAdviewFromSuperView];
    [Validation ResizeViewForAds];

    
   // self.objCustomCamera = nil;
    [self cancelButtonPressed];
}

- (void)cancelButtonPressed{
    self.objCustomCamera.delegate = nil;
    [self.objCustomCamera.view removeFromSuperview];
    [self.objCustomCamera removeFromParentViewController];
    self.objCustomCamera = nil;
}

-(IBAction)btnBackClicked:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)showPrivacyView{
    
    self.viewPrivacyContianer.hidden = FALSE;
    [self.btnPublic setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    self.selectedPrivacy = 2;
}

-(void)hidePrivacyView{
    
    self.viewPrivacyContianer.hidden = TRUE;
    float yStart = self.lblAddPictureFrom.frame.origin.y;
    yStart += self.lblAddPictureFrom.frame.size.height+30;

    self.ViewDescriptionContainer.frame = CGRectMake(0, yStart, 320, self.ViewDescriptionContainer.frame.size.height);
    float height = yStart+self.ViewDescriptionContainer.frame.size.height+10;
    self.scrollContainer.contentSize  = CGSizeMake(self.scrollContainer.contentSize.width,  (height <DEVICE_HEIGHT)?DEVICE_HEIGHT:height);
}

-(void)showTimePeriodView{
    
    float yStart = self.viewPrivacyContianer.frame.origin.y;
    yStart += self.viewPrivacyContianer.frame.size.height+20;

    
    self.ViewSetTimePeriod.hidden = FALSE;
    [self.btnNever setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];

    yStart += self.ViewSetTimePeriod.frame.size.height+20;
    
    self.ViewDescriptionContainer.frame = CGRectMake(0, yStart, 320, self.ViewDescriptionContainer.frame.size.height);
    self.scrollContainer.contentSize  = CGSizeMake(self.scrollContainer.contentSize.width, yStart+self.ViewDescriptionContainer.frame.size.height+10);
}

-(void)hideTimePeriodView{
    
    self.ViewSetTimePeriod.hidden = TRUE;
    float yStart = self.viewPrivacyContianer.frame.origin.y;
    yStart += self.viewPrivacyContianer.frame.size.height+20;
    
    self.ViewDescriptionContainer.frame = CGRectMake(0, yStart, 320, self.ViewDescriptionContainer.frame.size.height);
    self.scrollContainer.contentSize  = CGSizeMake(self.scrollContainer.contentSize.width,  yStart+self.ViewDescriptionContainer.frame.size.height+10);
}

-(IBAction)btnPrivacyClicked:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    [self resetPrivacy];
    
    if (btn.tag == 1) {
        [self.btnPrivate setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        self.selectedPrivacy  = 1;
        [self showTimePeriodView];
    }
    else {
        [self.btnPublic setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        self.selectedPrivacy  = 2;
        [self hideTimePeriodView];
    }
}

-(void)resetPrivacy{
    
    [self.btnPrivate setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnPublic setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
}

-(void)resetTimePeriod{
    
    [self.btnOnce setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnNever setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnNever setTitle:[NSString stringWithFormat:@"Keep but\nnot Share"] forState:UIControlStateNormal];
}

-(IBAction)btnTimePeriodClicked:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    [self resetTimePeriod];
    if (btn.tag == 1) {
        [self.btnOnce setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        self.selectedTimePeriod = 1;
    }
    else {
        [self.btnNever setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        self.selectedTimePeriod = 2;
    }
}

-(IBAction)btnNextClicked:(id)sender{
    
    NSString *strCaption = [self.tv_caption.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if ([strCaption isEqualToString:TextViewPlaceHolder]) {
        strCaption = @"";
    }
    if (self.pickedImg.image == nil) {
        [Validation showToastMessage:@"Please select picture." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        /*
         public enum MessageKeepStatus
         {
         Once = 1,
         NeverGo = 2
         }
         
         public enum MessageType
         {
         Sound = 0,
         stickr = 1,
         Video = 2
         }
         */

        [appDelegate.dic_NotificationReleatedData setValue:@"0" forKey:BlabType];
        [appDelegate.dic_NotificationReleatedData setValue:self.pickedImg.image forKey:CapturedImage];
        [appDelegate.dic_NotificationReleatedData setValue:strCaption forKey:ImageCaption];
        [appDelegate.dic_NotificationReleatedData setValue:(self.selectedPrivacy == 1)?@"false":@"true" forKeyPath:IsPublicImg];
        [appDelegate.dic_NotificationReleatedData setValue:[NSString stringWithFormat:@"%d",self.selectedTimePeriod] forKeyPath:RequestedKeepStatus];
        
        if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_SAVE_TO_GALLERY]) {
            void (^completion)(NSURL *, NSError *) = ^(NSURL *assetURL, NSError *error) {
                if (error) {
                    NSLog(@"%s: Write the image data to the assets library (camera roll): %@",
                          __PRETTY_FUNCTION__, [error localizedDescription]);
                }
                
                NSLog(@"%s: Save image with asset url %@ (absolute path: %@), type: %@", __PRETTY_FUNCTION__,
                      assetURL, [assetURL absoluteString], [assetURL class]);
                
            };
            
            void (^failure)(NSError *) = ^(NSError *error) {
                if (error) NSLog(@"%s: Failed to add the asset to the custom photo album: %@",
                                 __PRETTY_FUNCTION__, [error localizedDescription]);
            };
            
            [self.library saveImage:self.pickedImg.image
                            toAlbum:AlbumName
                         completion:completion
                            failure:failure];
            
        }
        
        
        [self performSegueWithIdentifier:RECORD_OPTION_VC sender:nil];
    }
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
     UITouch *touch = [[event allTouches] anyObject];
    if (![touch.view isKindOfClass:[UITextView class]]) {
        if (self.isKeyboardHidden == NO) {
            [self.tv_caption resignFirstResponder];
            self.isKeyboardHidden = YES;
        }
    }
}
/*
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView == self.scrollContainer) {
        if (self.isKeyboardHidden == NO) {
            self.isKeyboardHidden = YES;

            [self.tv_caption resignFirstResponder];
        }
    }
}

#pragma mark UITextView Delegate 

-(void)textViewDidBeginEditing:(UITextView *)textView{

    self.scrollContainer.contentSize = CGSizeMake(self.scrollContainer.contentSize.width, self.ViewDescriptionContainer.frame.origin.y+self.ViewDescriptionContainer.frame.size.height+10);
    
    self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, self.scrollContainer.contentSize.height-400);
    
    float ver = [[[UIDevice currentDevice] systemVersion] floatValue];
    
    if (ver >= 8.0) {
        self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, self.scrollContainer.contentOffset.y+45);
    }

//    [self.scrollContainer setFrame:CGRectMake(self.scrollContainer.frame.origin.x, self.scrollContainer.frame.origin.y, self.scrollContainer.frame.size.width, self.scrollContainer.frame.size.height-216)];
    if ([textView.text isEqualToString:TextViewPlaceHolder]) {
        textView.text = @"";
    }
 
    self.lblCharCounter.text = [NSString stringWithFormat:@"%d/100",(int)(textView.text.length)];

    self.isKeyboardHidden = NO;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        
        self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, 0);
        return FALSE;
    }
    else if ([text isEqualToString:@""]){
        if (textView.text.length == 0) {
            return FALSE;
        }
        
        self.lblCharCounter.text = [NSString stringWithFormat:@"%d/100",(int)(textView.text.length-1)];
        return TRUE;
    }
    else if ([text isEqualToString:@" "]){
        if (textView.text.length == 0) {
            return FALSE;
        }
        else if ((textView.text.length+1)>100) {
                return FALSE;
        }
    }
    else if ((textView.text.length+1)>100) {
        return FALSE;
        
    }
    self.lblCharCounter.text = [NSString stringWithFormat:@"%d/100",(int)(textView.text.length+1)];
    return TRUE;
}

- (void)textViewDidEndEditing:(UITextView *)textView{
    if ([DataValidation checkNullString:textView.text].length == 0) {
        self.tv_caption.text = TextViewPlaceHolder;
        if ([textView.text isEqualToString:TextViewPlaceHolder]) {
            self.lblCharCounter.text = [NSString stringWithFormat:@"0/100"];
        }
        else{
            self.lblCharCounter.text = [NSString stringWithFormat:@"%d/100",(int)(textView.text.length-1)];
        }

        self.scrollContainer.contentSize  = CGSizeMake(self.scrollContainer.contentSize.width,  self.ViewDescriptionContainer.frame.origin.y+self.ViewDescriptionContainer.frame.size.height+10);
        [self.scrollContainer setContentOffset:CGPointZero animated:NO];

    }
}
*/
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView == self.scrollContainer) {
        if (self.isKeyboardHidden == NO) {
            self.isKeyboardHidden = YES;
            
            [self.tv_caption resignFirstResponder];
        }
    }
}
-(void)textViewDidBeginEditing:(UITextView *)textView{
    
    self.scrollContainer.contentSize = CGSizeMake(self.scrollContainer.contentSize.width, self.ViewDescriptionContainer.frame.origin.y+self.ViewDescriptionContainer.frame.size.height+10+216);
    
    
    float ver = [[[UIDevice currentDevice] systemVersion] floatValue];
    
    if (ver >= 8.0) {
        self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, self.scrollContainer.contentOffset.y+216+45);
    }
    else{
        self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, self.scrollContainer.contentOffset.y+216);
    }
    
    if ([textView.text isEqualToString:TextViewPlaceHolder]) {
        textView.text = @"";
    }
    
    self.lblCharCounter.text = [NSString stringWithFormat:@"%d/100",(int)(textView.text.length)];
    
    self.isKeyboardHidden = NO;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    
    if ([text isEqualToString:@"\n"]) {
        self.isKeyboardHidden = NO;
        [textView resignFirstResponder];
        self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, 0);
        return FALSE;
    }
    else if ([text isEqualToString:@""]){
        if (textView.text.length == 0) {
            return FALSE;
        }
        
        self.lblCharCounter.text = [NSString stringWithFormat:@"%d/100",(int)(textView.text.length-1)];
        return TRUE;
    }
    else if ([text isEqualToString:@" "]){
        if (textView.text.length == 0) {
            return FALSE;
        }
        else if ((textView.text.length+1)>100) {
            return FALSE;
        }
    }
    else if ((textView.text.length+1)>100) {
        return FALSE;
        
    }
    self.lblCharCounter.text = [NSString stringWithFormat:@"%d/100",(int)(textView.text.length+1)];
    return TRUE;
}

- (void)textViewDidEndEditing:(UITextView *)textView{
    if ([DataValidation checkNullString:textView.text].length == 0) {
        self.tv_caption.text = TextViewPlaceHolder;
        if ([textView.text isEqualToString:TextViewPlaceHolder]) {
            self.lblCharCounter.text = [NSString stringWithFormat:@"0/100"];
        }
        else{
            self.lblCharCounter.text = [NSString stringWithFormat:@"%d/100",(int)(textView.text.length-1)];
        }
    }
    self.scrollContainer.contentSize  = CGSizeMake(self.scrollContainer.contentSize.width,  self.ViewDescriptionContainer.frame.origin.y+self.ViewDescriptionContainer.frame.size.height+10);
    [self.scrollContainer setContentOffset:CGPointZero animated:NO];
}

-(IBAction)btnHelpVideo_Clicked:(id)sender{
    self.viewVideoContainer.hidden = NO;
    self.moviePlayer = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:@"http://upload.blabeey.com//HelpVideo/3HWDUS3NI1747386_Video_1.mp4"]];
    
    self.moviePlayer.moviePlayer.shouldAutoplay = YES;
    
    [self.moviePlayer.moviePlayer prepareToPlay];
    
    self.moviePlayer.view.frame = CGRectMake(0, 0, DEVICE_WIDTH, DEVICE_HEIGHT);
    self.moviePlayer.moviePlayer.controlStyle = MPMovieControlStyleNone;
    
    [self.moviePlayer.moviePlayer play];
    self.moviePlayer.moviePlayer.scalingMode = MPMovieScalingModeAspectFit;
    [self.viewVideoContainer addSubview:self.moviePlayer.view];
    [self.viewVideoContainer bringSubviewToFront:self.btnClose];
    [self.view bringSubviewToFront:self.viewVideoContainer];
}
-(IBAction)btnCloseVideo_Clicked:(id)sender{
    if (self.moviePlayer) {
        [self.moviePlayer.moviePlayer stop];
        [self.moviePlayer.view removeFromSuperview];
        self.moviePlayer = nil;
    }
    self.viewVideoContainer.hidden = YES;
}
# pragma mark -
# pragma mark GKImagePicker Delegate Methods

- (UIImage *)fixrotation:(UIImage *)image{
    CGAffineTransform transform = CGAffineTransformIdentity;
 
    NSLog(@"%@",NSStringFromCGSize(image.size));
    
 /*   if (appDelegate.isRecordingFromCamera) {
        if (appDelegate.CameraOrientationForVideo == 4) {
            //dont rotate
            //PBJCameraOrientationPortrait
            NSLog(@"PBJCameraOrientationPortrait");
            
            transform = CGAffineTransformIdentity;
        }
        else if (appDelegate.CameraOrientationForVideo == 1){
            //                PBJCameraOrientationPortraitUpsideDown
            NSLog(@"PBJCameraOrientationPortraitUpsideDown");
            
            transform = CGAffineTransformTranslate(transform, DEVICE_HEIGHT, 0);
            
            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
            transform = CGAffineTransformTranslate(transform, 300, 210);
            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
        }
        else if (appDelegate.CameraOrientationForVideo == 3){
            //                PBJCameraOrientationLandscapeLeft
            NSLog(@"PBJCameraOrientationLandscapeLeft");
            
            transform = CGAffineTransformTranslate(transform, 0, 300);
            transform = CGAffineTransformRotate(transform, degreesToRadians(-90.0));
            
        }
        else if (appDelegate.CameraOrientationForVideo == 2){
            //                PBJCameraOrientationLandscapeRight
            NSLog(@"PBJCameraOrientationLandscapeRight");
            transform = CGAffineTransformTranslate(transform, 360, 0);
            
            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
            transform = CGAffineTransformScale(transform, 1, 1);
        }
    }
    else{
   */     if (image.imageOrientation == UIImageOrientationUp) {    // - done
            //dont rotate
            //PBJCameraOrientationPortrait
            NSLog(@"PBJCameraOrientationPortrait");
            
            transform = CGAffineTransformIdentity;
        }
        else if (image.imageOrientation == UIImageOrientationDown){
            //                PBJCameraOrientationPortraitUpsideDown
            NSLog(@"PBJCameraOrientationPortraitUpsideDown");
            transform = CGAffineTransformRotate(transform, degreesToRadians(-90.0));
            transform = CGAffineTransformTranslate(transform, -image.size.width, (image.size.height/2));
            transform = CGAffineTransformRotate(transform, degreesToRadians(-90.0));
            transform = CGAffineTransformTranslate(transform, -(image.size.width/1.6), (image.size.height/3.0));
        }
        else if (image.imageOrientation == UIImageOrientationLeft){
            //                PBJCameraOrientationLandscapeLeft
            NSLog(@"PBJCameraOrientationLandscapeLeft");
            
//            transform = CGAffineTransformTranslate(transform, 0, image.size.width);
            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
            transform = CGAffineTransformTranslate(transform, 0, -image.size.height);
        }
        else if (image.imageOrientation == UIImageOrientationRight){        //DONE
            //                PBJCameraOrientationLandscapeRight
            NSLog(@"PBJCameraOrientationLandscapeRight");
            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
            transform = CGAffineTransformTranslate(transform, 0, -image.size.height);
            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
            transform = CGAffineTransformTranslate(transform, 0, -image.size.height);
            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
            transform = CGAffineTransformTranslate(transform, 0, -image.size.height);
//            transform = CGAffineTransformTranslate(transform, 360, 0);
//            
//            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
//            transform = CGAffineTransformScale(transform, 1, 1);
        }
        
  //  }

    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, image.size.width, image.size.height,
                                             CGImageGetBitsPerComponent(image.CGImage), 0,
                                             CGImageGetColorSpace(image.CGImage),
                                             CGImageGetBitmapInfo(image.CGImage));
    CGContextConcatCTM(ctx, transform);
    CGContextDrawImage(ctx, CGRectMake(0,0,image.size.width,image.size.height), image.CGImage);
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
  //  UIImageWriteToSavedPhotosAlbum(img, nil, nil, nil);
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
}

- (UIImage *)fixrotation1:(UIImage *)image{
    
    if (image.imageOrientation == UIImageOrientationUp) return image;
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    switch (image.imageOrientation) {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.width, image.size.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.width, 0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, image.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationUpMirrored:
            break;
    }
    
    switch (image.imageOrientation) {
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.width, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
            
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.height, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationDown:
        case UIImageOrientationLeft:
        case UIImageOrientationRight:
            break;
    }
    
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, image.size.width, image.size.height,
                                             CGImageGetBitsPerComponent(image.CGImage), 0,
                                             CGImageGetColorSpace(image.CGImage),
                                             CGImageGetBitmapInfo(image.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (image.imageOrientation) {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,image.size.height,image.size.width), image.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,image.size.width,image.size.height), image.CGImage);
            break;
    }
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
}

#pragma mark    UIImagePickerDelegate

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{

    UIImage *image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    
    CGSize imageSize = image.size;
    CGFloat scaleWidth = imageSize.width / 320;
    CGFloat scaleHeight = imageSize.height / 320;
    
    CGImageRef imageRef = CGImageCreateWithImageInRect([image CGImage], CGRectMake(0, 0, 320*scaleWidth, 320*scaleHeight));
    UIImage *result = [UIImage imageWithCGImage:imageRef scale:1 orientation:image.imageOrientation];

    self.pickedImg.image = [self fixrotation:result];
    self.btnNext.hidden = FALSE;
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:NULL];
}
//bhavik 13-Feb-2015
#pragma mark - Photo Selected Status bar Color not Change

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
