//
//  SubCat_CollectionCell.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 17/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "SubCat_CollectionCell.h"

@implementation SubCat_CollectionCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/


-(void)setCollectionViewForindex:(NSInteger)index forDictionary:(NSDictionary *)dic
{
    self.imgProfile.image = nil;
    self.imgProfile.imageURL = nil;
    
    self.imgProfile.hidden = NO;
    self.lblSubCatTitle.hidden = NO;
    
    self.imgProfile.layer.borderWidth = 2;
    self.imgProfile.layer.borderColor = TWITTER_BLUE_COLOR.CGColor;
    
    [self.imgProfile setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:SUBCATEGORY_LOGO_PATH]]]];
    [Validation setCorners:self.imgProfile];
    self.lblSubCatTitle.textColor = [UIColor whiteColor];
    [self.lblSubCatTitle setText:[NSString stringWithFormat:@"%@",[dic valueForKey:NAME]]];
    NSLog(@"%@",[dic valueForKey:NAME]);
/*    if (self.lblSubCatTitle.text.length > 10) {
        self.lblSubCatTitle.numberOfLines = 2;
        self.lblSubCatTitle.lineBreakMode = NSLineBreakByWordWrapping;
        self.lblSubCatTitle.frame = CGRectMake(self.lblSubCatTitle.frame.origin.x, self.lblSubCatTitle.frame.origin.y, self.lblSubCatTitle.frame.size.width, 50);
    }
*/
    self.lblSubCatTitle.numberOfLines = 2;
    self.lblSubCatTitle.lineBreakMode = NSLineBreakByWordWrapping;
    self.lblSubCatTitle.frame = CGRectMake(self.lblSubCatTitle.frame.origin.x, self.lblSubCatTitle.frame.origin.y, self.lblSubCatTitle.frame.size.width, 50);
    if (![[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
        //so deselect it
        [self.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication]];
    }
    else{
        [self.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
    }
    
    
}

-(void)setCollectionViewForInterestIndex:(NSInteger)index forDictionary:(NSDictionary *)dic
{
    self.lblSubCatTitle.hidden = NO;
    [self.lblSubCatTitle setText:[NSString stringWithFormat:@"%@",[dic valueForKey:NAME]]];
    [self.lblSubCatTitle setTextColor:[Validation getColorForAlphabet:self.lblSubCatTitle.text]];
    
    [self.lblSubCatTitle setFont:[UIFont fontWithName:Font_Montserrat_Regular size:18] ];
}

@end
