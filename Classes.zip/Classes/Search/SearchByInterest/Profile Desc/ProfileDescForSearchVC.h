//
//  ProfileDescForSearchVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/17/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ProfileDescForSearchVCDelegate <NSObject>
- (void)setSelectedProfileDesc:(NSArray *)interests AndSubInterest:(NSArray *)subInterests;

@end@interface ProfileDescForSearchVC : UIViewController<UITableViewDataSource, UITableViewDelegate,UICollectionViewDataSource, UICollectionViewDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, strong) NSMutableArray				*arrSubCat;

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) ASIFormDataRequest			*request;
@property (nonatomic, strong) IBOutlet  UIButton            *btnNext;

@property (nonatomic, readwrite) BOOL						isShowSubCategories;
@property (nonatomic, readwrite) BOOL						isShowFooter;
@property (nonatomic, readwrite) int						selectedSection;
@property (nonatomic, readwrite) int						selectedRow;
@property (nonatomic, readwrite) int                        pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;

@property (nonatomic, strong) NSMutableDictionary           *contentOffsetDictionary;

@property (nonatomic ,assign) id <ProfileDescForSearchVCDelegate>       delegate;

@end
