//
//  ProfileDescForSearchVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/17/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "ProfileDescForSearchVC.h"
#import "UserCell.h"
#import "ProfileVC.h"
#import "MBProgressHUD.h"
#import "UserListingByInterestVC.h"
#import "AFTableViewCell.h"
#import "SubCat_CollectionCell.h"

#define PageSize			20
//#define Section_Height      94
#define Section_Height      130
@interface ProfileDescForSearchVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation ProfileDescForSearchVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:[[UIApplication sharedApplication] keyWindow]];
	[[[UIApplication sharedApplication] keyWindow] addSubview:HUD];
    
	
    
    self.arrData = [[NSMutableArray alloc] init] ;
	appDelegate.currentVc = self;
	
	[self performSelector:@selector(LoadViewSetting)];
    [self performSelectorInBackground:@selector(getInterestList) withObject:nil];
}
-(void)viewWillAppear:(BOOL)animated{
    
	[super viewWillAppear:animated];
	appDelegate.currentVc = self;
    self.pageCounter = 1;
    
    //[Validation showLoadingIndicator];
    //  [HUD show:YES];
    
}
-(void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
	
    if (self.request) {
        [self.request setDelegate:nil];
        self.request = nil;
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark

-(void)LoadViewSetting{
    self.btnNext.hidden = NO;
    
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
}

-(IBAction)btnBackClicked:(id)sender{
    //	[self.navigationController popViewControllerAnimated:YES];
    [self dismissViewControllerAnimated:YES completion:NULL];
}

-(void)getInterestList{
	if (self.request !=nil) {
		self.request = nil;
	}
    
    //pass user id as 0 to get all cat-sub cate that is not based on user id
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         //                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
                         nil];
    
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_ALL_DESC_SUBDESC withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//	self.request.delegate = self;
//	self.request.tag = 1;
	strUrl = nil;
    
    /*
     Response =     (
     {
     CreateBy = 1;
     CreateDate = "2014-10-16T05:24:55.89";
     DeleteBy = "<null>";
     DeleteDate = "<null>";
     Description = Sports;
     ID = 1;
     IsActive = 1;
     IsDelete = 0;
     Name = Sports;
     UpdateBy = 0;
     UpdateDate = "2014-10-21T03:37:47";
     },
     {
     CreateBy = 1;
     CreateDate = "2014-10-16T21:57:34.95";
     DeleteBy = "<null>";
     DeleteDate = "<null>";
     Description = Funny;
     ID = 3;
     IsActive = 1;
     IsDelete = 0;
     Name = Funny;
     UpdateBy = 1;
     UpdateDate = "2014-10-21T03:50:36.94";
     },
     {
     CreateBy = 1;
     CreateDate = "2014-10-16T21:57:52.873";
     DeleteBy = "<null>";
     DeleteDate = "<null>";
     Description = Motivational;
     ID = 4;
     IsActive = 1;
     IsDelete = 0;
     Name = Motivational;
     UpdateBy = 1;
     UpdateDate = "2014-10-21T03:49:45.57";
     },
     {
     CreateBy = 1;
     CreateDate = "2014-10-16T21:58:15.463";
     DeleteBy = "<null>";
     DeleteDate = "<null>";
     Description = Jokes;
     ID = 5;
     IsActive = 1;
     IsDelete = 0;
     Name = Jokes;
     UpdateBy = 1;
     UpdateDate = "2014-10-21T03:50:09.127";
     }
     );
     Status = 1;
     UserStatus =     {
     IsActive = 1;
     IsDelete = 0;
     Msg = success;
     status = 1;
     };
     }
     
     
     */
}

-(void)getUserInterestList{
    if (self.request !=nil) {
		self.request = nil;
	}
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         nil];
    
    
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_USER_INTEREST withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }
//	self.request.delegate = self;
//	self.request.tag = 2;
	strUrl = nil;
}

-(void)getSelectedInterestIds{
    
    NSArray *arr = [self.arrData valueForKey:IS_ADDED_TO_MY_INTEREST];
    NSString *strSelectedIds = @"";
    NSString *strSelectedSubInterest = @"";
    
    for (int i= 0; i<(int)arr.count; i++) {
        
        if ([[NSString stringWithFormat:@"%@",[arr objectAtIndex:i]] isEqualToString:@"1"]) {
            
            NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:i]];
            
            if (strSelectedIds.length == 0) {
                strSelectedIds = [NSString stringWithFormat:@"%@",[dic valueForKey:@"ID"]];
            }
            else{
                strSelectedIds = [strSelectedIds stringByAppendingFormat:@"|%@",[dic valueForKey:@"ID"]];
            }
            
            if ([[dic valueForKey:@"UserSubDesc"] count] > 0) {
                NSArray *arrSub = [dic valueForKey:@"UserSubDesc"];
                
                for (int y= 0; y<(int)arrSub.count; y++) {
                    NSDictionary *dic1 = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[arrSub objectAtIndex:y]];
                    if ([[NSString stringWithFormat:@"%@",[dic1 valueForKey:IS_ADDED_TO_MY_INTEREST]] isEqualToString:@"1"]) {
                        if (strSelectedSubInterest.length == 0) {
                            strSelectedSubInterest = [NSString stringWithFormat:@"%@",[[arrSub objectAtIndex:y] valueForKey:@"ID"]];
                        }
                        else{
                            strSelectedSubInterest = [strSelectedSubInterest stringByAppendingFormat:@"|%@",[[arrSub objectAtIndex:y] valueForKey:@"ID"]];
                        }
                    }
                }
            }
        }
    }
    if (strSelectedIds.length == 0) {
        [Validation showToastMessage:@"Please select your interest." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        [self EditSaveInterest:strSelectedIds andSubInterests:strSelectedSubInterest];
    }
}
-(void)EditSaveInterest:(NSString *)strSelectedIds andSubInterests:(NSString *)strSubInterests{
    
    // [Validation showLoadingIndicator];
    [HUD show:YES];
    if (self.request !=nil) {
        self.request = nil;
    }
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:strSelectedIds,KeyValue,@"InterestIDs",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:strSubInterests,KeyValue,@"SubInterestIDs",KeyName,nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"1",KeyValue,@"PageNo",KeyName,nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"20",KeyValue,@"PageSize",KeyName,nil],@"5",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:SEARCH_USER_BY_INTEREST withParameters:nil];
    self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:3];
    }
//    self.request.delegate = self;
//    self.request.tag = 3;
    strUrl = nil;
    
}

-(IBAction)btnDoneClicked:(id)sender{
    [self.delegate setSelectedProfileDesc:self.arrData AndSubInterest:self.arrSubCat];
    
    [self dismissViewControllerAnimated:YES completion:NULL];
}

-(NSArray*) indexPathsForSection:(int)section withNumberOfRows:(int)numberOfRows {
    
    NSMutableArray* indexPaths = [NSMutableArray new];
    for (int i = 0; i < numberOfRows; i++) {
        NSIndexPath* indexPath = [NSIndexPath indexPathForRow:i inSection:section];
        [indexPaths addObject:indexPath];
    }
    return indexPaths;
}

-(void)getSubCatList{
    
    if (self.arrSubCat== nil) {
        self.arrSubCat = [[NSMutableArray alloc] init] ;
    }
    
    [self.arrSubCat addObjectsFromArray:[NSArray arrayWithArray:[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"UserSubDesc"]]];
    
    [self.tblData reloadData];
    
    if (self.arrSubCat.count > 0) {
        
        [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:self.selectedSection] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
}
/*
-(IBAction)btnShowSubCategoriesClicked:(id)sender{
	
	UIButton *btn = ((UIButton *)sender);
    
	if (self.isShowSubCategories) {
		self.isShowFooter = NO;
		self.isShowSubCategories = NO;
		int numOfRows = (int)[self.tblData numberOfRowsInSection:self.selectedSection];
		NSArray* indexPaths = [self indexPathsForSection:self.selectedSection withNumberOfRows:numOfRows];
		[self.tblData deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationFade];
		
        CGRect rect = [self.tblData rectForSection:(int)btn.tag];
        
        [self.tblData scrollRectToVisible:rect animated:NO];
        
        if (self.selectedSection != btn.tag) {
            [self btnShowSubCategoriesClicked:sender];
        }
        else{
            [UIView setAnimationsEnabled:NO];
            [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:self.selectedSection] withRowAnimation:UITableViewRowAnimationFade];
            [UIView setAnimationsEnabled:YES];
        }
	}
	else{
        
		self.isShowSubCategories = YES;
		self.selectedSection = (int)btn.tag;
        
		if (self.selectedSection == self.arrData.count-1) {
			self.isShowFooter = YES;
		}
		else{
			self.isShowFooter = NO;
		}
        if ([[[self.arrData objectAtIndex:self.selectedSection] objectForKey:@"UserSubDesc"] count]>0) {
            //call web service
            if (self.arrSubCat != nil) {
                if (self.arrSubCat.count > 0) {
                    [self.arrSubCat removeAllObjects];
                }
            }
            [self getSubCatList];
        }
        else{
            //initiate notif
            self.isShowSubCategories = NO;
            [Validation removeAdviewFromSuperView];
            [self.tblData reloadData];
        }
	}
}
 */

-(IBAction)btnShowSubCategoriesClicked:(id)sender{
    
    UIButton *btn = ((UIButton *)sender);
    
    if (self.isShowSubCategories) {
        self.isShowFooter = NO;
        self.isShowSubCategories = NO;
        int numOfRows = (int)[self.tblData numberOfRowsInSection:self.selectedSection];
        NSArray* indexPaths = [self indexPathsForSection:self.selectedSection withNumberOfRows:numOfRows];
        [self.tblData deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationFade];
        
        CGRect rect = [self.tblData rectForSection:(int)btn.tag];
        
        [self.tblData scrollRectToVisible:rect animated:NO];
        
        if (self.selectedSection != btn.tag) {
            [self btnShowSubCategoriesClicked:sender];
        }
        else{
            [UIView setAnimationsEnabled:NO];
            [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:self.selectedSection] withRowAnimation:UITableViewRowAnimationFade];
            [UIView setAnimationsEnabled:YES];
            
        }
    }
    else{
        //        self.selectedSection = (int)btn.tag;
        
        self.isShowSubCategories = YES;
        self.selectedSection = (int)btn.tag;
        /*		if (self.selectedSection == self.arrData.count-1) {
         self.isShowFooter = NO;
         }
         else{
         */			self.isShowFooter = NO;
        //		}
        if ([[[self.arrData objectAtIndex:self.selectedSection] objectForKey:@"UserSubDesc"] count]>0) {
            //call web service
            if (self.arrSubCat != nil) {
                if (self.arrSubCat.count > 0) {
                    [self.arrSubCat removeAllObjects];
                }
            }
            [self getSubCatList];
        }
        else{
            //initiate notif
            self.isShowSubCategories = NO;
            [Validation removeAdviewFromSuperView];
            [self.tblData reloadData];
        }
    }
}

/*
-(IBAction)btnShowSubCategoriesClicked:(id)sender{
    
    UIButton *btn = ((UIButton *)sender);
    
    if (self.isShowSubCategories) {
        self.isShowFooter = NO;
        self.isShowSubCategories = NO;
        int numOfRows = (int)[self.tblData numberOfRowsInSection:self.selectedSection];
        NSArray* indexPaths = [self indexPathsForSection:self.selectedSection withNumberOfRows:numOfRows];
        [self.tblData deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationFade];
        
        CGRect rect = [self.tblData rectForSection:(int)btn.tag];
        
        [self.tblData scrollRectToVisible:rect animated:NO];
        
        if (self.selectedSection != btn.tag) {
            [self btnShowSubCategoriesClicked:sender];
        }
        else{
            [UIView setAnimationsEnabled:NO];
            [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:self.selectedSection] withRowAnimation:UITableViewRowAnimationFade];
            [UIView setAnimationsEnabled:YES];
        }
    }
    else{
        
        self.isShowSubCategories = YES;
        self.selectedSection = (int)btn.tag;
        
        self.isShowFooter = NO;
        
        if ([[[self.arrData objectAtIndex:self.selectedSection] objectForKey:@"UserSubDesc"] count]>0) {
            //call web service
            if (self.arrSubCat != nil) {
                if (self.arrSubCat.count > 0) {
                    [self.arrSubCat removeAllObjects];
                }
            }
            [self getSubCatList];
        }
        else{
            //initiate notif
            self.isShowSubCategories = NO;
            [Validation removeAdviewFromSuperView];
            [self.tblData reloadData];
        }
    }
}
*/
#pragma mark  UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return self.arrData.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	return Section_Height;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
	if (self.isShowFooter) {
		if (section == self.arrData.count-1) {
			return 40;
		}
	}
	return 0;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
	UIView *viewFooterContainer = [[UIView alloc] init] ;
	viewFooterContainer.backgroundColor = [UIColor clearColor];
	return viewFooterContainer;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
	UIView *viewHeaderContainer = [[UIView alloc] init] ;
	
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:section]];
    
    AsyncImageView *catImg = [[AsyncImageView alloc] init];
	UILabel *lblTitle = [[UILabel alloc] init];
	UIButton *btnCategories = [UIButton buttonWithType:UIButtonTypeCustom];
    UIButton *imgSelectCategory = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImageView     *imgSubCategory = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icn_circle_plus.png"]];
    
    
    btnCategories.backgroundColor = [UIColor clearColor];
	
	lblTitle.numberOfLines = 0;
	lblTitle.lineBreakMode = NSLineBreakByWordWrapping;
	
	catImg.layer.borderColor = [UIColor whiteColor].CGColor;
	catImg.layer.borderWidth = 2;
	
	if (section % 2==0) {
		lblTitle.textAlignment = NSTextAlignmentLeft;
		
		catImg.frame = CGRectMake(5, 15, 100, 100);
		
		lblTitle.frame = CGRectMake(110, (Section_Height-35)/2, tableView.frame.size.width-120, 35);
        
        [imgSelectCategory setFrame:CGRectMake(tableView.frame.size.width-40, 5, 29, 30)];
        
        imgSubCategory.frame = CGRectMake(5, 105, 20, 20);
        
    }
	else{
		lblTitle.textAlignment = NSTextAlignmentRight;
		
		catImg.frame = CGRectMake(tableView.frame.size.width-100-5, 15, 100, 100);
		
		lblTitle.frame = CGRectMake(5, (Section_Height-35)/2, tableView.frame.size.width-120, 35);
        
        [imgSelectCategory setFrame:CGRectMake(5, 5, 29, 30)];
        
        imgSubCategory.frame = CGRectMake(tableView.frame.size.width-25, 105, 20, 20);
        
	}
    
    imgSubCategory.hidden = YES;
    if ([[[self.arrData objectAtIndex:section] objectForKey:@"UserSubDesc"] count]>0) {
        imgSubCategory.hidden = NO;
        if (self.isShowSubCategories && (self.selectedSection == section)) {
            [imgSubCategory setImage:[UIImage imageNamed:@"icn_circle_minus.png"]];
        }
        else{
            [imgSubCategory setImage:[UIImage imageNamed:@"icn_circle_plus.png"]];
        }
    }
    
	lblTitle.font = [UIFont fontWithName:Font_Montserrat_Bold size:20];
	
	lblTitle.adjustsFontSizeToFitWidth = YES;
	
	[catImg setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:CATEGORY_PHOTO_PATH]]]];
	[Validation setCorners:catImg];
	
	lblTitle.textColor = [UIColor whiteColor];
	[lblTitle setText:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:NAME]]];
	
	NSString *strChar = [[[self.arrData objectAtIndex:section] valueForKey:NAME] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	viewHeaderContainer.backgroundColor = [Validation getColorForAlphabet:[NSString stringWithFormat:@"%@",strChar]];
	viewHeaderContainer.frame = CGRectMake(0, 0, tableView.frame.size.width, 130);
	
	btnCategories.frame = viewHeaderContainer.frame;
	[btnCategories addTarget:self action:@selector(btnShowSubCategoriesClicked:) forControlEvents:UIControlEventTouchUpInside];
	btnCategories.tag = section;
    
    if ([[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
        [imgSelectCategory setImage:[UIImage imageNamed:Btn_selectedUserIndication] forState:UIControlStateNormal];
    }
    else{
        [imgSelectCategory setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication] forState:UIControlStateNormal];
    }
    [imgSelectCategory addTarget:self action:@selector(btnInterestSelectedDeselected:) forControlEvents:UIControlEventTouchUpInside];
    imgSelectCategory.tag = section;
    btnCategories.backgroundColor = [UIColor clearColor];
    btnCategories.tag = section;
    
    [viewHeaderContainer addSubview:catImg];
	[viewHeaderContainer addSubview:lblTitle];
	[viewHeaderContainer addSubview:btnCategories];
    [viewHeaderContainer addSubview:imgSelectCategory];
    [viewHeaderContainer addSubview:imgSubCategory];
    
	lblTitle = nil;
	
	catImg = nil;
    
    imgSubCategory = nil;
    
    
    if (section == self.arrData.count-1) {
        if (!self.isDataNull) {
            [HUD show:YES];
            self.pageCounter ++;
            [self performSelectorInBackground:@selector(getInterestList) withObject:nil];
        }
    }
	return viewHeaderContainer;
}
/*
-(void)btnInterestSelectedDeselected:(id)sender{
    
    UIButton *btn = ((UIButton *)sender);
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    if ([[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
        //so deselect it
        [dic setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
        NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)[dic valueForKey:@"UserSubDesc"]];
        
        if (arr.count > 0) {
            for (int i=0; i<(int)arr.count; i++){
                NSMutableDictionary *dicSub = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arr objectAtIndex:i]];
                [dicSub setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
                [arr replaceObjectAtIndex:i withObject:dicSub];
                dicSub = nil;
            }
            [dic setObject:arr forKey:@"UserSubDesc"];
        }
        
        [self.arrData replaceObjectAtIndex:btn.tag withObject:dic];
        
        self.isShowFooter = NO;
		self.isShowSubCategories = NO;
        arr = nil;
        
        //        [self.tblData reloadData];
        //       CGRect rect = [self.tblData rectForSection:(int)btn.tag];
        
        //   [self.tblData scrollRectToVisible:rect animated:NO];
        [UIView setAnimationsEnabled:NO];
        [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:btn.tag] withRowAnimation:UITableViewRowAnimationFade];
        [UIView setAnimationsEnabled:YES];
        
        
        dic = nil;
        
        //        arr = nil;
        
        //        if (self.isShowSubCategories) {
        //            [self.tblData beginUpdates];
        //            self.isShowFooter = NO;
        //            self.isShowSubCategories = NO;
        //
        //            [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:self.selectedSection] withRowAnimation:UITableViewRowAnimationNone];
        //            [self.tblData endUpdates];
        //
        //            self.selectedSection = (int)btn.tag;
        //        }
        //        else{
        //            [self.tblData reloadData];
        //        }
        //        dic = nil;
    }
    else{
        [dic setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
        NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)[dic valueForKey:@"UserSubDesc"]];
        
        if (arr.count > 0) {
            for (int i=0; i<(int)arr.count; i++){
                NSMutableDictionary *dicSub = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arr objectAtIndex:i]];
                [dicSub setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
                [arr replaceObjectAtIndex:i withObject:dicSub];
                
                dicSub = nil;
            }
            self.arrSubCat = [NSMutableArray arrayWithArray:(NSArray *)arr];
            [dic setObject:arr forKey:@"UserSubDesc"];
        }
        
        [self.arrData replaceObjectAtIndex:btn.tag withObject:dic];
        
        //    [self btnShowSubCategoriesClicked:sender];
        //        CGRect rect = [self.tblData rectForSection:(int)btn.tag];
        
        // [self.tblData scrollRectToVisible:rect animated:NO];
        [UIView setAnimationsEnabled:NO];
        [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:btn.tag] withRowAnimation:UITableViewRowAnimationFade];
        [UIView setAnimationsEnabled:YES];
        
        
        dic = nil;
    }
    
    NSArray *arr = [NSArray arrayWithArray:[(NSArray *)self.arrData valueForKey:IS_ADDED_TO_MY_INTEREST]];
    
    int index = (int)[arr indexOfObject:@"1"];
    
    if (index > -1 && index< (int)self.arrData.count) {
        [Validation removeAdviewFromSuperView];
        self.btnNext.hidden = FALSE;
    }
    else{
    }
    
    
    //    NSArray *arr = [NSArray arrayWithArray:[(NSArray *)self.arrData valueForKey:IS_ADDED_TO_MY_INTEREST]];
    
    //   int index = (int)[arr indexOfObject:@"1"];
    
    //    if (index > -1 && index< (int)self.arrData.count) {
    //        [Validation removeAdviewFromSuperView];
    //        self.btnNext.hidden = FALSE;
    //    }
    //    else{
    //        [self.view addSubview:[Validation sharedBannerView]];
    //        [Validation ResizeViewForAds];
    //        self.btnNext.hidden = TRUE;
    //    }
    
}
*/

-(void)btnInterestSelectedDeselected:(id)sender{
    
    UIButton *btn = ((UIButton *)sender);
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    if ([[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
        //so deselect it
        [dic setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
        NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)[dic valueForKey:@"UserSubDesc"]];
        
        if (arr.count > 0) {
            for (int i=0; i<(int)arr.count; i++){
                NSMutableDictionary *dicSub = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arr objectAtIndex:i]];
                [dicSub setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
                [arr replaceObjectAtIndex:i withObject:dicSub];
                dicSub = nil;
            }
            [dic setObject:arr forKey:@"UserSubDesc"];
        }
        
        [self.arrData replaceObjectAtIndex:btn.tag withObject:dic];
        if ([[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
            [btn setImage:[UIImage imageNamed:Btn_selectedUserIndication] forState:UIControlStateNormal];
        }
        else{
            [btn setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication] forState:UIControlStateNormal];
        }
        
        
        self.isShowFooter = NO;
        self.isShowSubCategories = NO;
        arr = nil;
        
        //  [self.tblData reloadData];
        if (self.selectedSection != btn.tag) {
            //  [self btnShowSubCategoriesClicked:sender];
        }
        else{
            [UIView setAnimationsEnabled:NO];
            [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:btn.tag] withRowAnimation:UITableViewRowAnimationFade];
            [UIView setAnimationsEnabled:YES];
        }
        
        dic = nil;
    }
    else{
        [dic setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
        NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)[dic valueForKey:@"UserSubDesc"]];
        
        if (arr.count > 0) {
            for (int i=0; i<(int)arr.count; i++){
                NSMutableDictionary *dicSub = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arr objectAtIndex:i]];
                [dicSub setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
                [arr replaceObjectAtIndex:i withObject:dicSub];
                
                dicSub = nil;
            }
            self.arrSubCat = [NSMutableArray arrayWithArray:(NSArray *)arr];
            [dic setObject:arr forKey:@"UserSubDesc"];
        }
        
        [self.arrData replaceObjectAtIndex:btn.tag withObject:dic];
        
        
        if ([[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
            [btn setImage:[UIImage imageNamed:Btn_selectedUserIndication] forState:UIControlStateNormal];
        }
        else{
            [btn setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication] forState:UIControlStateNormal];
        }
        
        if (self.isShowSubCategories && self.selectedSection == btn.tag) {
            [UIView setAnimationsEnabled:NO];
            [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:btn.tag] withRowAnimation:UITableViewRowAnimationFade];
            [UIView setAnimationsEnabled:YES];
        }
        
        //  [self btnShowSubCategoriesClicked:sender];
        
        
        
        //        [UIView setAnimationsEnabled:NO];
        //        [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:self.selectedSection] withRowAnimation:UITableViewRowAnimationFade];
        //        [UIView setAnimationsEnabled:NO];
        
        //        [UIView setAnimationsEnabled:NO];
        //        [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:btn.tag] withRowAnimation:UITableViewRowAnimationFade];
        //        [UIView setAnimationsEnabled:YES];
        
        dic = nil;
    }
    
    NSArray *arr = [NSArray arrayWithArray:[(NSArray *)self.arrData valueForKey:IS_ADDED_TO_MY_INTEREST]];
    
    int index = (int)[arr indexOfObject:@"1"];
    
    if (index > -1 && index< (int)self.arrData.count) {
        [Validation removeAdviewFromSuperView];
        self.btnNext.hidden = FALSE;
    }
    else{
    }
    
}

/*
-(void)btnInterestSelectedDeselected:(id)sender{
    
    UIButton *btn = ((UIButton *)sender);
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    if ([[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
        //so deselect it
        [dic setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
        NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)[dic valueForKey:@"UserSubDesc"]];
        
        if (arr.count > 0) {
            for (int i=0; i<(int)arr.count; i++){
                NSMutableDictionary *dicSub = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arr objectAtIndex:i]];
                [dicSub setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
                [arr replaceObjectAtIndex:i withObject:dicSub];
                dicSub = nil;
            }
            [dic setObject:arr forKey:@"UserSubDesc"];
        }
        
        [self.arrData replaceObjectAtIndex:btn.tag withObject:dic];
        
        if ([[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
            [btn setImage:[UIImage imageNamed:Btn_selectedUserIndication] forState:UIControlStateNormal];
        }
        else{
            [btn setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication] forState:UIControlStateNormal];
        }
        
        
        self.isShowFooter = NO;
        self.isShowSubCategories = NO;
        arr = nil;
        
        if (self.selectedSection != btn.tag) {
        }
        else{
            [UIView setAnimationsEnabled:NO];
            [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:btn.tag] withRowAnimation:UITableViewRowAnimationFade];
            [UIView setAnimationsEnabled:YES];
        }
        
        dic = nil;
    }
    else{
        [dic setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
        NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)[dic valueForKey:@"UserSubDesc"]];
        
        if (arr.count > 0) {
            for (int i=0; i<(int)arr.count; i++){
                NSMutableDictionary *dicSub = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arr objectAtIndex:i]];
                [dicSub setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
                [arr replaceObjectAtIndex:i withObject:dicSub];
                
                dicSub = nil;
            }
            self.arrSubCat = [NSMutableArray arrayWithArray:(NSArray *)arr];
            [dic setObject:arr forKey:@"UserSubDesc"];
        }
        
        [self.arrData replaceObjectAtIndex:btn.tag withObject:dic];
        
        if ([[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
            [btn setImage:[UIImage imageNamed:Btn_selectedUserIndication] forState:UIControlStateNormal];
        }
        else{
            [btn setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication] forState:UIControlStateNormal];
        }
        
        if (self.isShowSubCategories && self.selectedSection == btn.tag) {
            [UIView setAnimationsEnabled:NO];
            [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:btn.tag] withRowAnimation:UITableViewRowAnimationFade];
            [UIView setAnimationsEnabled:YES];
        }
        dic = nil;
    }
    
    NSArray *arr = [NSArray arrayWithArray:[(NSArray *)self.arrData valueForKey:IS_ADDED_TO_MY_INTEREST]];
    
    int index = (int)[arr indexOfObject:@"1"];
    
    if (index > -1 && index< (int)self.arrData.count) {
        [Validation removeAdviewFromSuperView];
        self.btnNext.hidden = FALSE;
    }
    else{
    }
}
 */
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 120;         //60
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	//return self.arrData.count;
	if (section == self.selectedSection) {
		if (self.isShowSubCategories) {
            NSLog(@"%f",ceil([self.arrSubCat count]/2.0));
            int rows = (int)(ceil([self.arrSubCat count]/2.0));
			return rows;
		}
	}
	return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"CellIdentifier";
    
    AFTableViewCell *cell = (AFTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!cell)
    {
        cell = [[AFTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    [cell.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:CollectionViewCellIdentifier];
    
    NSString *strChar = [[[self.arrData objectAtIndex:self.selectedSection] valueForKey:NAME] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	cell.collectionView.backgroundColor = [Validation getColorForAlphabet:[NSString stringWithFormat:@"%@",strChar]];
    
    cell.collectionView.dataSource = self;
    cell.collectionView.delegate = self;
    
    
    if ([[[self.arrSubCat objectAtIndex:indexPath.row] valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
        [cell.imgFriendshipStatus setImage:[UIImage imageNamed:btn_Checkbox_Selected] ];
        [cell.imgFriendshipStatus setHidden:FALSE];
    }
    
    return cell;
    
    
    /*
     static NSString *CellIdentifier = @"CellIdentifier";
     
     UserCell *cell = (UserCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
     
     cell.selectionStyle = UITableViewCellSelectionStyleNone;
     [cell clearsContextBeforeDrawing];
     
     cell.btnUnfriend.hidden = YES;
     if (cell == nil) {
     cell = [[UserCell alloc] initWithStyleForInterest:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
     }
     [cell setValueForInterestBox:[self.arrSubCat objectAtIndex:indexPath.row]];
     
     if ([[[self.arrSubCat objectAtIndex:indexPath.row] valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
     [cell.imgFriendshipStatus setImage:[UIImage imageNamed:btn_Checkbox_Selected] ];
     [cell.imgFriendshipStatus setHidden:FALSE];
     }
     
     return cell;
     */
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(AFTableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setCollectionViewDataSourceDelegate:self index:indexPath.row forDictionary:[self.arrSubCat objectAtIndex:indexPath.row]];
    
    NSInteger index = cell.collectionView.tag;
    
    CGFloat horizontalOffset = [self.contentOffsetDictionary[[@(index) stringValue]] floatValue];
    [cell.collectionView setContentOffset:CGPointMake(horizontalOffset, 0)];
}

#pragma mark - UICollectionViewDataSource Methods

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSLog(@"%d",(int)section);
    NSLog(@"section = %d",(int)collectionView.tag);
    int rowIndex = (int)collectionView.tag+1;
    // if (section == self.selectedSection) {
    if (self.isShowSubCategories) {
        if ((rowIndex*2) > self.arrSubCat.count) {
            return 1;
        }
        return  2;
    }
    //	}
	return 0;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"Cell";
    
    SubCat_CollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
    int count = ((int)collectionView.tag+1)*2;         //by multiples of 2
    int index = 0;
    
    if (indexPath.row == 0) {
        index = count - 2;
    }
    else{
        index = count - 1;
    }
    NSLog(@"index = %d",index);
    cell.layer.borderColor = [UIColor whiteColor].CGColor;
    cell.layer.borderWidth = 0.5;
    
    if (index < (int)self.arrSubCat.count) {
        cell.backgroundColor = [Validation getColorForAlphabet:[[self.arrSubCat objectAtIndex:index] valueForKey:NAME]];
        [cell setCollectionViewForindex:indexPath.row forDictionary:[self.arrSubCat objectAtIndex:index]];
    }
    else{
        cell.imgProfile.hidden = YES;
        [cell.imgProfile setImage:nil];
        cell.imgFriendshipStatus.hidden = YES;
        cell.lblSubCatTitle.textColor = [UIColor whiteColor];
        [cell.lblSubCatTitle setText:@""];
        cell.lblSubCatTitle.hidden = YES;
        NSString *strChar = [[[self.arrData objectAtIndex:self.selectedSection] valueForKey:NAME] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        cell.backgroundColor = [Validation getColorForAlphabet:[NSString stringWithFormat:@"%@",strChar]];
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    int count = ((int)collectionView.tag+1)*2;         //by multiples of 2
    int index = 0;
    
    if (indexPath.row == 0) {
        index = count - 2;
    }
    else{
        index = count - 1;
    }
    NSLog(@"index = %d",index);
    
    self.selectedRow = (int)collectionView.tag;
    
    NSLog(@"index = %d",self.selectedRow);
    
    if (index < self.arrSubCat.count) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrSubCat objectAtIndex:index]];
        NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.selectedSection]];
        
        
        if ([[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
            //so deselect it
            [dic setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
        }
        else{
            [dic setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
            
            if (![[[self.arrData objectAtIndex:self.selectedSection] valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
                [dic1 setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
            }
        }
        
        [self.arrSubCat replaceObjectAtIndex:index withObject:dic];
        
        
        NSArray *arr = [NSArray arrayWithArray:self.arrSubCat];
        [dic1 setObject:arr forKey:@"UserSubDesc"];
        NSLog(@"%@,",[arr valueForKey:IS_ADDED_TO_MY_INTEREST]);
        
        BOOL isSelectedSubInterestFound = FALSE;
        
        NSLog(@"%@",NSStringFromClass([[arr valueForKey:IS_ADDED_TO_MY_INTEREST] class]));
        NSLog(@"%d",(int)[[arr valueForKey:IS_ADDED_TO_MY_INTEREST] indexOfObject:@"1"]);
        arr = [arr valueForKey:IS_ADDED_TO_MY_INTEREST];
        
        for (int i = 0; i<arr.count; i++) {
            if ([[NSString stringWithFormat:@"%@",[arr objectAtIndex:i]] isEqualToString:@"1"]) {
                isSelectedSubInterestFound = TRUE;
                break;
            }
        }
        
        NSLog(@"%@",[NSNumber numberWithBool:isSelectedSubInterestFound]);
        if (!isSelectedSubInterestFound) {
            [dic1 setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
        }
        
        arr = nil;
        [self.arrData replaceObjectAtIndex:self.selectedSection withObject:dic1];
        
        
        dic = nil;
        
        [UIView setAnimationsEnabled:NO];
        [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:self.selectedSection] withRowAnimation:UITableViewRowAnimationFade];
        [UIView setAnimationsEnabled:YES];
        
        
        dic1 = nil;
        
        [Validation removeAdviewFromSuperView];
        
        //        NSArray *arr = [NSArray arrayWithArray:self.arrSubCat];
        //        [dic1 setObject:arr forKey:@"UserSubDesc"];
        //        arr = nil;
        //        [self.arrData replaceObjectAtIndex:self.selectedSection withObject:dic1];
        //
        //
        //        dic = nil;
        //
        //        [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:self.selectedSection] withRowAnimation:UITableViewRowAnimationNone];
        //
        //
        //        [Validation removeAdviewFromSuperView];
        //        self.btnNext.hidden = NO;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //  UserCell *cell = (UserCell *)[tableView cellForRowAtIndexPath:indexPath];
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrSubCat objectAtIndex:indexPath.row]];
    NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indexPath.section]];
    
    
    NSLog(@"dic - %@",dic);
    if ([[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
        //so deselect it
        [dic setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
        //      [cell.imgFriendshipStatus setImage:[UIImage imageNamed:btn_Checkbox_Deselected]];
    }
    else{
        [dic setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
        //       [cell.imgFriendshipStatus setImage:[UIImage imageNamed:btn_Checkbox_Selected]];
        
        if (![[[self.arrData objectAtIndex:indexPath.section] valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
            [dic1 setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
        }
    }
    
    [self.arrSubCat replaceObjectAtIndex:indexPath.row withObject:dic];
    
    NSArray *arr = [NSArray arrayWithArray:self.arrSubCat];
    [dic1 setObject:arr forKey:@"UserSubDesc"];
    if (![[arr valueForKey:IS_ADDED_TO_MY_INTEREST] containsObject:@"1"]) {
        [dic1 setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
    }
    arr = nil;
    [self.arrData replaceObjectAtIndex:indexPath.section withObject:dic1];
    
    
    dic = nil;
    
    [UIView setAnimationsEnabled:NO];
    [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:self.selectedSection] withRowAnimation:UITableViewRowAnimationFade];
    [UIView setAnimationsEnabled:YES];
    
}

/*
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
	NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrSubCat objectAtIndex:indexPath.row]];
    NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indexPath.section]];
    
    
    NSLog(@"dic - %@",dic);
    if ([[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
        //so deselect it
        [dic setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
    }
    else{
        [dic setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
        
        if (![[[self.arrData objectAtIndex:indexPath.section] valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
            [dic1 setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
        }
    }
    
    [self.arrSubCat replaceObjectAtIndex:indexPath.row withObject:dic];
    
    NSArray *arr = [NSArray arrayWithArray:self.arrSubCat];
    [dic1 setObject:arr forKey:@"UserSubDesc"];
    if (![[arr valueForKey:IS_ADDED_TO_MY_INTEREST] containsObject:@"1"]) {
        [dic1 setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
    }
    arr = nil;
    [self.arrData replaceObjectAtIndex:indexPath.section withObject:dic1];
    
    
    dic = nil;
    
    [UIView setAnimationsEnabled:NO];
    [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:self.selectedSection] withRowAnimation:UITableViewRowAnimationFade];
    [UIView setAnimationsEnabled:YES];
    
    
    
    //	[tableView deselectRowAtIndexPath:indexPath animated:NO];
    //    self.selectedRow = (int)indexPath.row;
    
}
 */
/*
 - (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
 
 UserCell *cell = (UserCell *)[tableView cellForRowAtIndexPath:indexPath];
 
 NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrSubCat objectAtIndex:indexPath.row]];
 NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indexPath.section]];
 
 
 NSLog(@"dic - %@",dic);
 if ([[dic valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
 //so deselect it
 [dic setValue:@"0" forKey:IS_ADDED_TO_MY_INTEREST];
 [cell.imgFriendshipStatus setImage:[UIImage imageNamed:btn_Checkbox_Deselected]];
 }
 else{
 [dic setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
 [cell.imgFriendshipStatus setImage:[UIImage imageNamed:btn_Checkbox_Selected]];
 
 if (![[[self.arrData objectAtIndex:indexPath.section] valueForKey:IS_ADDED_TO_MY_INTEREST] boolValue]) {
 [dic1 setValue:@"1" forKey:IS_ADDED_TO_MY_INTEREST];
 }
 }
 
 [self.arrSubCat replaceObjectAtIndex:indexPath.row withObject:dic];
 
 
 NSArray *arr = [NSArray arrayWithArray:self.arrSubCat];
 [dic1 setObject:arr forKey:@"UserSubDesc"];
 arr = nil;
 [self.arrData replaceObjectAtIndex:indexPath.section withObject:dic1];
 
 
 dic = nil;
 
 [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationNone];
 }
 */

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
 {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	
	[HUD hide:YES];
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];;
	NSLog(@"response =%@",dicResponse);
    
    /*
     
     (
     {
     CreateBy = 1;
     CreateDate = "2014-10-16T05:24:55.89";
     DeleteBy = "<null>";
     DeleteDate = "<null>";
     Description = Sports;
     ID = 1;
     IsActive = 1;
     IsAdded = 0;
     IsDelete = 0;
     IsSubInterest = "<null>";
     Name = Sports;
     UpdateBy = 0;
     UpdateDate = "2014-10-21T03:37:47";
     UserSubDesc =             (
     );
     },
     {
     CreateBy = 1;
     CreateDate = "2014-10-16T21:57:52.873";
     DeleteBy = "<null>";
     DeleteDate = "<null>";
     Description = Motivational;
     ID = 4;
     IsActive = 1;
     IsAdded = 0;
     IsDelete = 0;
     IsSubInterest = "<null>";
     Name = Motivational;
     UpdateBy = 1;
     UpdateDate = "2014-10-21T03:49:45.57";
     UserSubDesc =             (
     );
     },
     {
     CreateBy = 1;
     CreateDate = "2014-10-16T21:58:15.463";
     DeleteBy = "<null>";
     DeleteDate = "<null>";
     Description = Jokes;
     ID = 5;
     IsActive = 1;
     IsAdded = 0;
     IsDelete = 0;
     IsSubInterest = 1;
     Name = Jokes;
     UpdateBy = 1;
     UpdateDate = "2014-10-27T04:02:31.52";
     UserSubDesc =             (
     {
     CreateBy = 1;
     CreateDate = "2014-10-27T04:03:02.55";
     Description = Funny;
     ID = 1;
     IsActive = 1;
     IsAdded = 0;
     Name = Funny;
     UpdateBy = 1;
     UpdateDate = "2014-10-27T23:32:43.413";
     UserInterestID = 5;
     UserInterestName = "<null>";
     }
     );
     }
     );
     Status = 1;
     UserStatus =     {
     IsActive = 1;
     IsDelete = 0;
     Msg = success;
     status = 1;
     };
     }
     */
    if (dicResponse != nil){
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [appDelegate callLogOutService];
        }
        else{
            if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if (request.tag == 1) {
                        //get all interest list
                        
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            [self.arrData addObjectsFromArray:arr];
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            
                            arr = nil;
                        }
                        [self.tblData reloadData];
                        response = nil;
                        [HUD hide:YES];
                    }
                    else if (request.tag == 2){
                        //get user interest
                        //not called so this block will never be checked
                        
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            [self.arrData arrayByAddingObjectsFromArray:arr];
                            arr = nil;
                        }
                        [self.tblData reloadData];
                        response = nil;
                        [HUD hide:YES];
                    }
                    else if (request.tag == 3){
                        //set user interest
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            if ([response isKindOfClass:[NSArray class]]) {
                            }
                        }
                        
                        response = nil;
                        [HUD hide:YES];
                    }
                }
            }
            else{
                if (self.arrData.count == 0) {
                    [AlertHandler alertTitle:MESSAGE message:@"No Interests found." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
	
	self.request = nil;
	dicResponse = nil;
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
