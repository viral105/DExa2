//
//  UserListingByInterestVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 10/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "UserCell.h"
#import <CoreLocation/CoreLocation.h>
#import "UserListingByInterestCatSubcatCell.h"
#import "RecrodingFriendRequestVC.h"
@interface UserListingByInterestVC : UIViewController <UITableViewDataSource, UITableViewDelegate,MKMapViewDelegate,UIActionSheetDelegate,UserCellDelegate,AFNetworkingDataTransactionDelegate,CLLocationManagerDelegate,UserProfileVCDelegate,RecrodingFriendRequestVCDelegate>

@property (nonatomic, strong) IBOutlet UITableView   *tblData;
@property (nonatomic, strong) NSMutableArray         *arrData;
@property (nonatomic, strong) NSMutableArray         *arrSelected;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, retain) IBOutlet UILabel				*lbl_NoDataAvailable;

@property (nonatomic, strong) NSDictionary           *dicFilterData;
@property (nonatomic, readwrite) BOOL                is_GeoLocation;

@property (strong, nonatomic) IBOutlet MKMapView     *mapView;
@property (readwrite, nonatomic) BOOL                isUserLocationAddedToAnnotationList;
@property (nonatomic, strong) MKUserLocation         *UserLocation;

@property (nonatomic, readwrite) int                 pageCounter;

@property (nonatomic, strong) IBOutlet UILabel		 *lblTitle;

@property (nonatomic, strong) IBOutlet UIButton      *btnNext;

@property (nonatomic, strong) UIActivityIndicatorView		*activityLoading;
@property (strong, nonatomic) IBOutlet UIView *viewUserPopupMain;
@property (strong, nonatomic) IBOutlet UIView *viewUserPopupSub1;
@property (strong, nonatomic) IBOutlet UIView *viewUserPopupSub2;
@property (strong, nonatomic) IBOutlet UIImageView *imgViewUserPopupSmall;
@property (strong, nonatomic) IBOutlet UILabel *lblPopupName;
@property (strong, nonatomic) IBOutlet UILabel *lblPopupUserName;
@property (strong, nonatomic) IBOutlet UILabel *lblPopupAge;
@property (strong, nonatomic) IBOutlet UITableView *tblPopupCatSubCat;
//@property (strong, nonatomic) IBOutlet UITextView *tvPopupProfileDesc;
//@property (strong, nonatomic) IBOutlet UITextView *tvPopupInterest;
@property (strong, nonatomic) IBOutlet UIImageView *imgViewPopupUserFull;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *activityIndiView;
//@property (strong, nonatomic) IBOutlet UILabel *lblInterest;


@end