//
//  UserListingByInterestVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 10/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "UserListingByInterestVC.h"
#import "UserCell.h"
#import "MultipleAnnotationLocation.h"
#import "TextBlabVC.h"
#define IS_OS_8_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)


#define IS_GEOLOCATION              @"is_geoLocation"
#define SELECTED_INTEREST_ID        @"selectedInterestIds"
#define SELECTED_SUB_INTEREST_ID    @"selectedSubInterestIds"
#define SELECTED_INTEREST_NAME      @"selectedInterestName"
#define SELECTED_PROFILEDESC_NAME   @"selectedProfileDescName" 
#define SELECT_INTEREST             @"Select Profile Description"
#define SEARCH_AGE_FROM             @"ageFrom"
#define SEARCH_AGE_TO               @"ageTo"
#define SEARCH_GENDER               @"gender"
#define SEARCH_GEO_RADIOUS          @"geo_radious"
#define SEARCH_INTEREST             @"interest"
#define SEARCH_PROFILE_DESC         @"profiledesc"
#define SEARCH_SUB_INTEREST         @"sub_interest"
#define SEARCH_SUB_PROFILEDESC      @"sub_profiledesc"

#define IS_SELECTED         @"is_selected"

#define PageSize	10

@interface UserListingByInterestVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
    CLLocationManager *locManager;
    NSMutableArray *arrCatInt;
    NSMutableArray *arrSubcatInt;
    NSMutableArray *arrCatProfileDesc;
    NSMutableArray *arrSubcatProfileDesc;
    UserProfileVC *objUserProfileVC;
}
@property (nonatomic, strong) NSMutableArray *arrCatInt;
@property (nonatomic, strong) NSMutableArray *arrSubcatInt;
@property (nonatomic, strong) NSMutableArray *arrCatProfileDesc;
@property (nonatomic, strong) NSMutableArray *arrSubcatProfileDesc;
@property (nonatomic, strong) UserProfileVC *objUserProfileVC;
@end

@implementation UserListingByInterestVC
@synthesize arrCatInt;
@synthesize arrSubcatInt;
@synthesize arrCatProfileDesc;
@synthesize arrSubcatProfileDesc;
@synthesize objUserProfileVC;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSLog(@"dictionary - filter = %@",self.dicFilterData);
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureViewUserPopupMain:)];
    [tapGesture setNumberOfTapsRequired:1];
    [self.viewUserPopupSub2 addGestureRecognizer:tapGesture];
    tapGesture = nil;

    self.arrData = [[NSMutableArray alloc] init];
    self.arrSelected = [[NSMutableArray alloc] init];
    self.arrCatInt = [NSMutableArray new];
    self.arrSubcatInt = [NSMutableArray new];
    self.arrCatProfileDesc = [NSMutableArray new] ;
    self.arrSubcatProfileDesc = [NSMutableArray new];
    self.isDataNull = YES;
    
    [self.tblData registerNib:[UINib nibWithNibName:@"UserCell" bundle:nil] forCellReuseIdentifier:@"cellIdentifier"];
    self.is_GeoLocation = [[NSString stringWithFormat:@"%@",[self.dicFilterData valueForKey:IS_GEOLOCATION]] boolValue];
    self.pageCounter = 1;
    
    [self LoadViewSetting];

    [Validation removeAdviewFromSuperView];
	[self.view addSubview:[Validation sharedBannerView]];
	[Validation ResizeViewForAds];

    if (self.is_GeoLocation) {
        CGRect frame = self.lbl_NoDataAvailable.frame;
        frame.origin.y = frame.origin.y + 100;
        self.lbl_NoDataAvailable.frame = frame;

//        #ifdef __IPHONE_8_0
        if(IS_OS_8_OR_LATER) {
        self.mapView = [[MKMapView alloc] init];
        self.mapView.delegate=self;
        self.mapView.showsUserLocation = YES;
            
            locManager = [[CLLocationManager alloc] init];
            locManager.delegate = self;
            [locManager requestWhenInUseAuthorization];
             [locManager requestAlwaysAuthorization];
//            [locManager startUpdatingLocation];
        }
        else{
            self.mapView = [[MKMapView alloc] init];
            self.mapView.delegate=self;
            self.mapView.showsUserLocation = YES;
        }
//        #endif
//        [self.mapView setShowsUserLocation:YES];
        [locManager startUpdatingLocation];
//        self.mapView.showsUserLocation = YES;
/*
        self.mapView = [[MKMapView alloc] init];
        self.mapView.delegate=self;
        self.mapView.showsUserLocation = YES;
*/
    }
    else{
        [self SearchFUserBasedOnFilterList];
    }
}
/*
-(void)requestAlwaysAuth{
    CLAuthorizationStatus status = [CLLocationManager authorizationStatus];
    if (status==kCLAuthorizationStatusAuthorizedWhenInUse || status == kCLAuthorizationStatusDenied) {
        NSString*title;
        title=(status == kCLAuthorizationStatusDenied) ? @"Location Services Are Off" : @"Background use is not enabled";
        NSString *message = @"Go to settings";
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:title message:message delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Settings", nil];
        [alert show];
    }else if (status==kCLAuthorizationStatusNotDetermined)
    {[locManager requestAlwaysAuthorization];}
}*/
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    appDelegate.currentVc = self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark    Custom methods

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    [self.lbl_NoDataAvailable setTextColor:TWITTER_BLUE_COLOR];
    [self.lbl_NoDataAvailable setShadowColor:[UIColor clearColor]];
    
    self.btnNext.hidden = TRUE;
}

-(IBAction)btnBackClicked:(id)sender{
   // [self dismissViewControllerAnimated:YES completion:NULL];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)SearchFUserBasedOnFilterList{
    
   // [HUD show:YES];
//	if (self.request !=nil) {
//		self.request = nil;
//	}
    [HUD show:YES];
    NSString *strFromAge = [self.dicFilterData valueForKey:SEARCH_AGE_FROM];
    NSString *strToAge = [self.dicFilterData valueForKey:SEARCH_AGE_TO];
    NSString *strGender = [self.dicFilterData valueForKey:SEARCH_GENDER];
    NSString *strDistance = [self.dicFilterData valueForKey:SEARCH_GEO_RADIOUS];
    NSString *strInterestIds = [self.dicFilterData valueForKey:SEARCH_INTEREST];
    NSString *strSubInterest = [self.dicFilterData valueForKey:SEARCH_SUB_INTEREST];
    NSString *strProfileDescIds = [self.dicFilterData valueForKey:SEARCH_PROFILE_DESC];
    NSString *strSubProfileDesc = [self.dicFilterData valueForKey:SEARCH_SUB_PROFILEDESC];
    
   
    /*
     public enum Gender
     {
     NotToDisclose = 0,
     Male = 1,
     Female = 2
     }
     */
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Name",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:strFromAge,KeyValue,@"FromAge",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:strToAge,KeyValue,@"ToAge",KeyName, nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:strGender,KeyValue,@"Gender",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithDouble:appDelegate.UserCurrentLatitude],KeyValue,@"Lat",KeyName, nil],@"6",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithDouble:appDelegate.UserCurrentLongitude],KeyValue,@"Lng",KeyName, nil],@"7",
                         [NSDictionary dictionaryWithObjectsAndKeys:strDistance,KeyValue,@"Distance",KeyName, nil],@"8",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"-1",KeyValue,@"Private",KeyName, nil],@"9",
                         [NSDictionary dictionaryWithObjectsAndKeys:strInterestIds,KeyValue,@"InterestIDs",KeyName, nil],@"10",
                         [NSDictionary dictionaryWithObjectsAndKeys:strSubInterest,KeyValue,@"SubInterestIDs",KeyName, nil],@"11",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"12",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"13",
                         [NSDictionary dictionaryWithObjectsAndKeys:strProfileDescIds,KeyValue,@"UserDescriptIDs",KeyName, nil],@"14",
                         [NSDictionary dictionaryWithObjectsAndKeys:strSubProfileDesc,KeyValue,@"UserSubDescriptionIDs",KeyName, nil],@"15",
						 
						 nil];
	NSLog(@"dic search filter %@",dic);
	NSString *strUrl = [WebServiceContainer getServiceURL:SEARCH_BY_FILTER withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
 //   [AlertHandler alertTitle:@"list user" message:[NSString stringWithFormat:@"%@",dic] delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:1];
    }
//	request.delegate = self;
//	request.tag = 1;
	strUrl = nil;
}

-(IBAction)btnNextClicked:(id)sender{
    [self showYapOptions];
}

-(void)showYapOptions{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Select" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:Only_Yap,Yap_With_Image,Yap_With_Video,Text_Blab, nil];
    [action showInView:self.view];
    action.delegate = self;
}

-(void)btnAddFriendClicked:(id)sender{

    UIButton*btn = ((UIButton *)sender);
    
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    if ([[dicData valueForKey:IS_USER_BLOCKED] boolValue]) {
        [Validation showToastMessage:@"You cannot send friend request to a blocked user." displayDuration:ERROR_MSG_DURATION];
    }
    else{

        if (![[NSString stringWithFormat:@"%@",[dicData valueForKey:IS_FRND_REQ_SENT]] boolValue]) {
/*            [dicData setValue:@"1" forKey:IS_FRND_REQ_SENT];
            [self.arrData replaceObjectAtIndex:btn.tag withObject:dicData];
            
            int indexToReload = (self.is_GeoLocation)?((int)(btn.tag+1)):((int)btn.tag);
            NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indexToReload inSection:0]];
            [self.tblData beginUpdates];
            [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
            [self.tblData endUpdates];
*/
            NSString *strRequestId = [NSString stringWithFormat:@"%@",[dicData valueForKey:USER_ID]];
            
            NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                                 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                                 [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
                                 nil];
            
            RecrodingFriendRequestVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:@"RecrodingFriendRequestVC"];
            obj.delegateFriendReq = self;
            obj.indexSelected = (int)btn.tag;
            obj.dicToSendFriendRequest = dic;
            [self.navigationController pushViewController:obj animated:YES];
/*
            NSString *strUrl = [WebServiceContainer getServiceURL:ADD_FRIEND withParameters:nil];
            ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
            if (request == nil) {
                [HUD hide:YES];
            }
            else{
                [request setDelegate:self];
                [request setTag:2];
            }
//        request.delegate = self;
//        request.tag = 2;
            strUrl = nil;
*/
        }
        else{
            [Validation showToastMessage:@"Friend request already sent." displayDuration:ERROR_MSG_DURATION];
        }
    }
    dicData = nil;
}
-(void)btnAddFriendFromPopup_Clicked:(NSDictionary *)dicOld{
    NSLog(@"arrData indexOfObject %d",(int)[self.arrData indexOfObject:dicOld]);
    if ([self.arrData containsObject:dicOld]) {
        NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:[self.arrData indexOfObject:dicOld]]];
        NSString *strRequestId = [NSString stringWithFormat:@"%@",[dicData valueForKey:USER_ID]];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
                             nil];
        
        RecrodingFriendRequestVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:@"RecrodingFriendRequestVC"];
        obj.delegateFriendReq = self;
        obj.indexSelected = (int)[self.arrData indexOfObject:dicOld];
        obj.dicToSendFriendRequest = dic;
        [self.navigationController pushViewController:obj animated:YES];
    }
    
}
-(void)btnAcceptFriendRequest:(id)sender{
 
    UIButton*btn = ((UIButton *)sender);

    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    if ([[dicData valueForKey:IS_USER_BLOCKED] boolValue]) {
        [Validation showToastMessage:@"You cannot send friend request to a blocked user." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        
   //     [HUD show:YES];
        
        [dicData setValue:@"1" forKey:IS_FRIEND];
        [self.arrData replaceObjectAtIndex:btn.tag withObject:dicData];
        
        int indexToReload = (self.is_GeoLocation)?((int)(btn.tag+1)):((int)btn.tag);
        NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indexToReload inSection:0]];
        [self.tblData beginUpdates];
        [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
        [self.tblData endUpdates];
        
//        if (self.request !=nil) {
//            self.request = nil;
//        }
//        self.selectedIndex = (int)((UIButton *)sender).tag;
        NSString *strRequestId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:USER_ID]];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
                             [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"IsFriend",KeyName, nil],@"3",
                             nil];
        
        NSString *strUrl = [WebServiceContainer getServiceURL:ACCEPT_REJECT_FRND_REQ withParameters:nil];
        ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
        if (request == nil) {
            [HUD hide:YES];
        }
        else{
            [request setDelegate:self];
            [request setTag:3];
        }
//        request.delegate = self;
//        request.tag = 3;
        strUrl = nil;
    }
    dicData = nil;
}

-(void)btnRejectFriendRequest:(id)sender{
	//[Validation showLoadingIndicator];
    
    UIButton*btn = ((UIButton *)sender);
    
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    if ([[dicData valueForKey:IS_USER_BLOCKED] boolValue]) {
        [Validation showToastMessage:@"You cannot send friend request to a blocked user." displayDuration:ERROR_MSG_DURATION];
    }
    else{
   //     [HUD show:YES];
        [dicData setValue:@"0" forKey:IS_FRIEND];
        [self.arrData replaceObjectAtIndex:btn.tag withObject:dicData];
        
        int indexToReload = (self.is_GeoLocation)?((int)(btn.tag+1)):((int)btn.tag);
        NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indexToReload inSection:0]];
        [self.tblData beginUpdates];
        [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
        [self.tblData endUpdates];

        //	if (self.request !=nil) {
        //		self.request = nil;
        //	}
        //	self.selectedIndex = (int)((UIButton *)sender).tag;
        NSString *strRequestId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:USER_ID]];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
                             [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"IsFriend",KeyName, nil],@"3",
                             nil];
        
        NSString *strUrl = [WebServiceContainer getServiceURL:ACCEPT_REJECT_FRND_REQ withParameters:nil];
        ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
        if (request == nil) {
            [HUD hide:YES];
        }
        else{
            [request setDelegate:self];
            [request setTag:4];
        }
//        request.delegate = self;
//        request.tag = 4;
        strUrl = nil;
    }
}

-(void)btnUnfriendClicked:(id)sender{
    
    UIButton*btn = ((UIButton *)sender);
    
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    [dicData setValue:@"0" forKey:IS_FRIEND];
    [self.arrData replaceObjectAtIndex:btn.tag withObject:dicData];
    
    int indexToReload = (self.is_GeoLocation)?((int)(btn.tag+1)):((int)btn.tag);
    NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indexToReload inSection:0]];
    [self.tblData beginUpdates];
    [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
    [self.tblData endUpdates];
    
//    if (self.request !=nil) {
//		self.request = nil;
//	}
	NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dicData valueForKey:USER_ID] ],KeyValue,@"FriendID",KeyName, nil],@"2",
                          nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:UNFRIEND_A_FRIEND withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:5];
    }
//	request.delegate = self;
//	request.tag = 5;
	strUrl = nil;
    
}
-(void)getUserDetail:(NSDictionary*)dic{
    
    NSDictionary *dicNew = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[dic valueForKey:@"ID"],KeyValue,@"UserID",KeyName, nil],@"1",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_USER_ALL_DETAIL withParameters:nil];
    
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dicNew isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:1];
    }
//    [obj setDelegate:self];
//    [obj setTag:1];
    strUrl = nil;

}
-(void)updateUserData:(int)indSel{

    NSLog(@"indSel %d",indSel);
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indSel]];
    
    [dicData setValue:@"1" forKey:IS_FRND_REQ_SENT];
    [self.arrData replaceObjectAtIndex:indSel withObject:dicData];
    if (self.objUserProfileVC != nil) {
        [self.objUserProfileVC.dicUserDetail setObject:@"1" forKey:IS_FRND_REQ_SENT];
        [self.objUserProfileVC LoadViewSetting];
    }
    NSArray *indexPathArray;
    if (self.is_GeoLocation) {
        indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indSel+1 inSection:0]];
    }
    else{
        indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indSel inSection:0]];
    }
    
    [self.tblData beginUpdates];
    [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
    [self.tblData endUpdates];
}
#pragma mark  UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (tableView==self.tblData) {
        return 1;
    }
    else{
        if (self.arrCatProfileDesc.count==0 && self.arrCatInt.count==0) {
            return 0;
        }
        else if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            return 2;
        }
        else{
            return 1;
        }
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (tableView==self.tblData) {
        return 0;
    }
    else{
        return 30;
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (tableView==self.tblData) {
        return nil;
    }
    else{
        UILabel *lblHeader = [[UILabel alloc] init];
        [lblHeader setFrame:CGRectMake(0, 0, self.tblPopupCatSubCat.frame.size.width, 30)];
        lblHeader.numberOfLines = 1;
        [lblHeader setFont:[UIFont boldSystemFontOfSize:16]];
        [lblHeader setBackgroundColor:[UIColor whiteColor]];
        [lblHeader setTextColor:[UIColor colorWithRed:98/255.0 green:106/255.0 blue:119/255.0 alpha:1]];
        [lblHeader setTextAlignment:NSTextAlignmentCenter];
        
        if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            if (section==0) {
                [lblHeader setText:@"PROFILE DESCRIPTION"];
            }
            else{
                [lblHeader setText:@"INTEREST"];
            }
        }
        else if(self.arrCatInt.count==0 && self.arrCatProfileDesc.count!=0){
            [lblHeader setText:@"PROFILE DESCRIPTION"];
        }
        else if(self.arrCatInt.count!=0 && self.arrCatProfileDesc.count==0){
            [lblHeader setText:@"INTEREST"];
        }
        return lblHeader;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView==self.tblData) {
        if (indexPath.row == 0) {
            if (self.is_GeoLocation) {
                return 200;
            }
        }
        if (self.is_GeoLocation) {
            return 105;
        }
        else{
            return 90;
        }
    }
    else{
        int height = 28;
        if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            if (indexPath.section==0) {
                CGSize rect = [self getHeightForSection:[self.arrSubcatProfileDesc objectAtIndex:indexPath.row]];
                NSLog(@"pro desc height %d ipath %d",(int)rect.height,(int)indexPath.row);
//                if ((int)rect.height>16) {
                    height+=(int)rect.height;
//                }
            }
            else{
                CGSize rect = [self getHeightForSection:[self.arrSubcatInt objectAtIndex:indexPath.row]];
                NSLog(@"interest height %d ipath %d",(int)rect.height,(int)indexPath.row);
//                if ((int)rect.height>16) {
                    height+=(int)rect.height;
//                }
            }
        }
        else if(self.arrCatInt.count==0 && self.arrCatProfileDesc.count!=0){
            CGSize rect = [self getHeightForSection:[self.arrSubcatProfileDesc objectAtIndex:indexPath.row]];
            NSLog(@"pro desc height %d ipath %d",(int)rect.height,(int)indexPath.row);
//            if ((int)rect.height>16) {
                height+=(int)rect.height;
//            }
        }
        else if(self.arrCatInt.count!=0 && self.arrCatProfileDesc.count==0){
            CGSize rect = [self getHeightForSection:[self.arrSubcatInt objectAtIndex:indexPath.row]];
            NSLog(@"interest height %d ipath %d",(int)rect.height,(int)indexPath.row);
//            if ((int)rect.height>16) {
                height+=(int)rect.height;
//            }
        }
        return height;
    }
}
-(CGSize)getHeightForSection:(NSString *)strText{
//    NSString *strText = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:NAME]];
    if (strText.length==0) {
        return CGSizeMake(0, 0);
    }
    NSMutableParagraphStyle * paragraphStyle = [[NSMutableParagraphStyle defaultParagraphStyle] mutableCopy];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    CGRect text = [strText boundingRectWithSize:CGSizeMake(self.tblPopupCatSubCat.frame.size.width-10, 1000)
                                        options:NSStringDrawingUsesLineFragmentOrigin
                                     attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14],NSParagraphStyleAttributeName:paragraphStyle}
                                        context:nil];
    strText = nil;
    return text.size;
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	//return self.arrData.count;
    if (tableView==self.tblData) {
        if (!self.isDataNull && self.arrData.count>=PageSize) {
            if (self.is_GeoLocation) {
                return self.arrData.count+2;
            }
            else{
                return self.arrData.count+1;
            }
        }
        else{
            if (self.is_GeoLocation) {
                return self.arrData.count+1;
            }
            else{
                return self.arrData.count;
            }
        }
    }
    else{
        if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            if (section==0) {
                return self.arrCatProfileDesc.count;
            }
            else{
                return self.arrCatInt.count;
            }
        }
        else if(self.arrCatInt.count==0 && self.arrCatProfileDesc.count!=0){
            return self.arrCatProfileDesc.count;
        }
        else if(self.arrCatInt.count!=0 && self.arrCatProfileDesc.count==0){
            return self.arrCatInt.count;
        }
        else{
            return 0;
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView==self.tblData) {
        NSString *cellId = [NSString stringWithFormat:@"%d",(int)indexPath.row];
        BOOL isLoadNewData = NO;
        if (indexPath.row == 0) {
            if (self.is_GeoLocation) {
                cellId = [cellId stringByAppendingFormat:@"MAP"];
            }
            else{
                if (indexPath.row != self.arrData.count) {
                    cellId = [cellId stringByAppendingFormat:@"%@",[[self.arrData objectAtIndex:indexPath.row] valueForKey:USER_ID]];
                }
                else{
                    if (!self.isDataNull) {
                        isLoadNewData = YES;
                    }
                }
            }
        }
        else{
            if (self.is_GeoLocation) {
                if (indexPath.row-1 < self.arrData.count) {
                    cellId = [cellId stringByAppendingFormat:@"%@",[[self.arrData objectAtIndex:indexPath.row-1] valueForKey:USER_ID]];
                }
                else{
                    if (!self.isDataNull) {
                        isLoadNewData = YES;
                    }
                }
            }
            else{
                if (indexPath.row != self.arrData.count) {
                    cellId = [cellId stringByAppendingFormat:@"%@",[[self.arrData objectAtIndex:indexPath.row] valueForKey:USER_ID]];
                }
                else{
                    if (!self.isDataNull) {
                        isLoadNewData = YES;
                    }
                }
            }
        }
        
        UserCell *cell = (UserCell *)[tableView dequeueReusableCellWithIdentifier:cellId];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell clearsContextBeforeDrawing];
        
        if (isLoadNewData){
            
            if (!self.isDataNull) {
                cell = [[UserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
                cell.cellBg.hidden = YES;
                cell.ProfileImg.hidden = YES;
                cell.btnNotificationProfile.hidden = NO;
                cell.lblDisplayName.hidden = YES;
                cell.lblUserName.hidden = YES;
                cell.imgFriendshipStatus.hidden = YES;
                cell.btnReqStatus.hidden = YES;
                cell.btnReqDeny.hidden = YES;
                cell.btnUnfriend.hidden = YES;
                cell.isShowUserDetailPopup = NO;
                cell.imgViewFriendType.hidden = YES;
                cell.lblMaidenName.hidden = YES;
                cell.imgViewIsNewFriend.hidden = YES;
                cell.btnPlayPause.hidden = YES;
                
                if (self.activityLoading != nil) {
                    [self.activityLoading removeFromSuperview];
                    self.activityLoading = nil;
                }
                self.activityLoading = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                self.activityLoading.center = cell.contentView.center;
                self.activityLoading.frame = cell.contentView.frame;
                self.activityLoading.hidesWhenStopped = TRUE;
                [self.activityLoading startAnimating];
                [cell.contentView addSubview:self.activityLoading];
                
                self.pageCounter++;
                [self performSelectorInBackground:@selector(SearchFUserBasedOnFilterList) withObject:nil];
                
                return cell;
            }
        }
        else{
            
            if (cell == nil) {
                cell = [[UserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
            }
            
            
            if (indexPath.row == 0 && self.is_GeoLocation) {
                cell.delegate =self;
                cell.cellBg.hidden = YES;
                cell.ProfileImg.hidden = YES;
                cell.btnNotificationProfile.hidden = NO;
                cell.lblDisplayName.hidden = YES;
                cell.lblUserName.hidden = YES;
                cell.imgFriendshipStatus.hidden = YES;
                cell.btnReqStatus.hidden = YES;
                cell.btnReqDeny.hidden = YES;
                cell.btnUnfriend.hidden = YES;
                cell.isShowUserDetailPopup = YES;
                cell.btnPlayPause.hidden = YES;
                
                
                [self.mapView removeFromSuperview];
                self.mapView.frame = CGRectMake(0, 0, 320, 200);
                [cell.contentView addSubview:self.mapView];
                
                return cell;
            }
            else{
                int indexRow = (int)indexPath.row;
                if (self.is_GeoLocation) {
                    indexRow = ((int)indexPath.row)-1;
                }
                
                NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indexRow]];
                cell.delegate = self;
                cell.isShowUserDetailPopup = YES;
                
                [cell setBoxValuesWithData:dic];
                
                //check if isFriend
                NSString *isFriend = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IS_FRIEND]]];
                NSString *isFriendReqRec = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IS_FRND_REQ_REC]]];
                NSString *isFriendReqSent = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IS_FRND_REQ_SENT]]];
                
                [cell.imgFriendshipStatus setHidden:TRUE];
                [cell.btnReqDeny setHidden:TRUE];
                [cell.btnReqStatus setHidden:TRUE];
                cell.btnUnfriend.hidden = YES;
                if (isFriend.length>0 && [isFriend isEqualToString:@"1"]) {
                    //frined
                    [cell.btnReqDeny setImage:[UIImage imageNamed:@"btn_unfriend_user.png"] forState:UIControlStateNormal];
                    cell.btnReqDeny.frame = cell.imgFriendshipStatus.frame;
                    [cell.btnReqDeny removeTarget:self  action:@selector(btnRejectFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
                    [cell.btnReqDeny addTarget:self action:@selector(btnUnfriendClicked:) forControlEvents:UIControlEventTouchUpInside];
                    cell.btnReqDeny.tag = indexRow;
                    cell.btnReqDeny.hidden = FALSE;
                    //			[cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_Accept_Request]];
                    //			[cell.imgFriendshipStatus setHidden:FALSE];
                }
                else{
                    //1. friend req sent
                    if (isFriendReqSent.length > 0 && [isFriendReqSent isEqualToString:@"1"]) {
                        //yes sent
                        [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_Waiting_For_Response]];
                        [cell.imgFriendshipStatus setHidden:FALSE];
                        
                    }
                    else if (isFriendReqRec.length > 0 && [isFriendReqRec isEqualToString:@"1"]){
                        //yes rec
                        //either accept or reject
                        [cell.btnReqDeny setImage:[UIImage imageNamed:Btn_Reject_Request] forState:UIControlStateNormal];
                        [cell.btnReqStatus setImage:[UIImage imageNamed:Btn_Accept_Request] forState:UIControlStateNormal];
                        
                        [cell.btnReqDeny setHidden:FALSE];
                        [cell.btnReqStatus setHidden:FALSE];
                        
                        //remove old targets
                        [cell.btnReqDeny removeTarget:self action:@selector(btnRejectFriendRequest:) forControlEvents:UIControlEventTouchDragInside];
                        [cell.btnReqStatus removeTarget:self action:@selector(btnAddFriendClicked:) forControlEvents:UIControlEventTouchUpInside];
                        
                        
                        
                        //add new target
                        [cell.btnReqStatus addTarget:self action:@selector(btnAcceptFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
                        [cell.btnReqDeny addTarget:self action:@selector(btnRejectFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
                        
                        cell.btnReqDeny.tag = indexRow;
                        cell.btnReqStatus.tag = indexRow;
                        
                    }
                    else{
                        //not a friend, so send req
                        [cell.btnReqStatus setImage:[UIImage imageNamed:Btn_AddFriend] forState:UIControlStateNormal];
                        [cell.btnReqStatus setHidden:FALSE];
                        
                        //remove old targets
                        [cell.btnReqStatus removeTarget:self action:@selector(btnAcceptFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
                        
                        //add new target
                        [cell.btnReqStatus addTarget:self action:@selector(btnAddFriendClicked:) forControlEvents:UIControlEventTouchUpInside];
                        cell.btnReqStatus.tag = indexRow;
                    }
                }
                if ([[dic valueForKey:IS_USER_BLOCKED] boolValue]) {
                    cell.btnUserBlocked.hidden = NO;
                }
                else{
                    cell.btnUserBlocked.hidden = YES;
                }
                
                if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
                    if (![cell.btnUnfriend isHidden]) {
                        cell.imgSelected.frame = CGRectMake(cell.imgSelected.frame.origin.x-40, cell.imgSelected.frame.origin.y, 29, 20);
                    }
                    [cell.imgSelected setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
                    [cell.imgSelected setHidden:FALSE];
                }
                
                if (self.is_GeoLocation) {
                    cell.cellBg.frame = CGRectMake(cell.cellBg.frame.origin.x, cell.cellBg.frame.origin.y, cell.cellBg.frame.size.width, cell.cellBg.frame.size.height+15);
                    
                    int yPoint = 10;
                    
                    
                    cell.lblDisplayName.frame = CGRectMake(cell.lblDisplayName.frame.origin.x, yPoint, cell.lblDisplayName.frame.size.width, cell.lblDisplayName.frame.size.height);
                    cell.btnDisplayName.frame = CGRectMake(cell.lblDisplayName.frame.origin.x, yPoint, cell.lblDisplayName.frame.size.width, cell.lblDisplayName.frame.size.height);
                    yPoint+=cell.lblDisplayName.frame.size.height-3;
                    
                    cell.lblUserName.frame = CGRectMake(cell.lblUserName.frame.origin.x, yPoint, cell.lblUserName.frame.size.width, 15);
                    cell.lblUserName.font = [UIFont fontWithName:Font_OpneSans_Regular size:12];
                    yPoint+=cell.lblUserName.frame.size.height+2;
                    
                    //        cell.lblUserName.backgroundColor = [UIColor redColor];
                    //        cell.lblDisplayName.backgroundColor = [UIColor greenColor];
                    cell.btnFriendCount.hidden = NO;
                    cell.btnFriendCount.frame = CGRectMake(cell.lblUserName.frame.origin.x, yPoint, cell.lblUserName.frame.size.width,cell.lblUserName.frame.size.height);
                    cell.btnFriendCount.backgroundColor = [UIColor clearColor];
                    //        [cell.btnFriendCount.titleLabel setFont:];
                    cell.btnFriendCount.titleLabel.font = [UIFont fontWithName:Font_OpneSans_Regular size:12];
                    [cell.btnFriendCount setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
                    cell.btnFriendCount.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
                    //        [cell.btnFriendCount.titleLabel setText:[NSString stringWithFormat:@"30"]];
                    [cell.btnFriendCount setTitle:[NSString stringWithFormat:@"%@ Friends",[dic valueForKey:@"TotalFriend"]] forState:UIControlStateNormal];

                    yPoint+=cell.btnFriendCount.frame.size.height+2;
                    
                    cell.lblDistance.hidden = NO;
                    cell.lblDistance.frame = CGRectMake(cell.lblUserName.frame.origin.x, yPoint, cell.lblUserName.frame.size.width, cell.lblUserName.frame.size.height);
                    cell.lblDistance.font = [UIFont fontWithName:Font_OpneSans_Regular size:12];
                    cell.lblDistance.backgroundColor = [UIColor clearColor];
                    [cell.lblDistance setTextColor:UIColorFromRGB(0X727478)];
                    float Dist = [[NSString stringWithFormat:@"%@",[dic valueForKey:@"Distance"]] floatValue];
                    //                float Dist = 2.0;
                    if (Dist<1.0) {
                        cell.lblDistance.text = @"Less than 1 mile away";
                    }
                    else{
                        cell.lblDistance.text = [NSString stringWithFormat:@"%.2f miles away",Dist];
                    }
                }
                else{
                    int yPoint = 10;
                    
                    
                    cell.lblDisplayName.frame = CGRectMake(cell.lblDisplayName.frame.origin.x, yPoint, cell.lblDisplayName.frame.size.width, cell.lblDisplayName.frame.size.height);
                    cell.btnDisplayName.frame = CGRectMake(cell.lblDisplayName.frame.origin.x, yPoint, cell.lblDisplayName.frame.size.width, cell.lblDisplayName.frame.size.height);
                    yPoint+=cell.lblDisplayName.frame.size.height-3;
                    
                    cell.lblUserName.frame = CGRectMake(cell.lblUserName.frame.origin.x, yPoint, cell.lblUserName.frame.size.width, 15);
                    cell.lblUserName.font = [UIFont fontWithName:Font_OpneSans_Regular size:12];
                    yPoint+=cell.lblUserName.frame.size.height+2;
                    
                    //        cell.lblUserName.backgroundColor = [UIColor redColor];
                    //        cell.lblDisplayName.backgroundColor = [UIColor greenColor];
                    cell.btnFriendCount.hidden = NO;
                    cell.btnFriendCount.frame = CGRectMake(cell.lblUserName.frame.origin.x, yPoint, cell.lblUserName.frame.size.width,cell.lblUserName.frame.size.height);
                    cell.btnFriendCount.backgroundColor = [UIColor clearColor];
                    //        [cell.btnFriendCount.titleLabel setFont:];
                    cell.btnFriendCount.titleLabel.font = [UIFont fontWithName:Font_OpneSans_Regular size:12];
                    [cell.btnFriendCount setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
                    cell.btnFriendCount.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
                    [cell.btnFriendCount setTitle:[NSString stringWithFormat:@"%@ Friends",[dic valueForKey:@"TotalFriend"]] forState:UIControlStateNormal];
                    
                }
                return cell;
            }
            
        }
        return nil;
    }
    else{
        UserListingByInterestCatSubcatCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
        if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            if (indexPath.section==0) {
                cell.strCat = [self.arrCatProfileDesc objectAtIndex:indexPath.row];
                cell.strSubcat = [self.arrSubcatProfileDesc objectAtIndex:indexPath.row];
            }
            else{
                cell.strCat = [self.arrCatInt objectAtIndex:indexPath.row];
                cell.strSubcat = [self.arrSubcatInt objectAtIndex:indexPath.row];
            }
        }
        else if(self.arrCatInt.count==0 && self.arrCatProfileDesc.count!=0){
            cell.strCat = [self.arrCatProfileDesc objectAtIndex:indexPath.row];
            cell.strSubcat = [self.arrSubcatProfileDesc objectAtIndex:indexPath.row];
        }
        else if(self.arrCatInt.count!=0 && self.arrCatProfileDesc.count==0){
            cell.strCat = [self.arrCatInt objectAtIndex:indexPath.row];
            cell.strSubcat = [self.arrSubcatInt objectAtIndex:indexPath.row];
        }
        [cell setUI];
        return cell;
    }
	
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    int indexRow = (int)indexPath.row;
    
    BOOL isReactTouch = YES;
    if (self.is_GeoLocation) {
        if (indexPath.row == 0) {
            isReactTouch = NO;
        }
        else{
            indexRow = ((int)indexPath.row)-1;
        }
        
    }
    if (isReactTouch) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indexRow]];
        
        if (![[dic valueForKey:IS_USER_BLOCKED] boolValue]) {
            
            if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
                [dic setValue:@"0" forKey:IS_SELECTED];
            }
            else{
                [dic setValue:@"1" forKey:IS_SELECTED];
            }
            
            [self.arrData replaceObjectAtIndex:indexRow withObject:dic];
            
            
            
            //[tableView reloadData];
            NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:(self.is_GeoLocation)?(indexRow+1):indexRow inSection:indexPath.section]];
            [self.tblData beginUpdates];
            [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
            [self.tblData endUpdates];
            
            BOOL isShowAd = FALSE;
            int index = -1;
            if (self.arrSelected.count > 0) {
                NSArray *arr = [self.arrSelected valueForKey:USER_ID];
                
                 index = (int)[arr indexOfObject:[dic valueForKey:USER_ID]];
                
                if (index > -1 && index<arr.count) {
//                    [Validation removeAdviewFromSuperView];
//                    self.btnNext.hidden = FALSE;
                    isShowAd = NO;
                }
                else{
//                    [self.view addSubview:[Validation sharedBannerView]];
//                    [Validation ResizeViewForAds];
//                    self.btnNext.hidden = TRUE;
                    isShowAd = YES;
                }
                
            }
            
            //add to selected user array
            
            if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"0"]) {
                //so deselect it
                if (index > -1 && index < self.arrData.count) {
                    [self.arrSelected removeObjectAtIndex:index];
                    if (self.arrSelected.count == 0) {
                        isShowAd = YES;
                    }
                }
            }
            else{
                [self.arrSelected addObject:dic];
                isShowAd = NO;
            }
            if (isShowAd) {
                [self.view addSubview:[Validation sharedBannerView]];
                [Validation ResizeViewForAds];
                self.btnNext.hidden = TRUE;
            }
            else{
                [Validation removeAdviewFromSuperView];
                self.btnNext.hidden = FALSE;
            }
        }
        else{
            [Validation showToastMessage:@"You cannot send Blab to a blocked user." displayDuration:ERROR_MSG_DURATION];
        }
        dic = nil;
        
        
    }
}
-(void)btnUserProfileImageClicked:(NSDictionary *)dic{
    NSLog(@"Profile Image Clicked %@ %@",[dic valueForKey:USER_PHOTO_PATH],dic);
    [self showHideAd:NO];
    
    self.imgViewPopupUserFull.imageURL = [NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]];
    self.viewUserPopupMain.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, self.viewUserPopupMain.frame.size.width, self.viewUserPopupMain.frame.size.height);
    
    self.viewUserPopupMain.hidden = NO;
    self.imgViewPopupUserFull.hidden = NO;
    [Validation animateYpoint:0 viewToAnimate:self.viewUserPopupMain];
    self.viewUserPopupSub1.layer.cornerRadius = 5.0;
    self.imgViewPopupUserFull.layer.cornerRadius = 50.0;
    self.viewUserPopupSub1.hidden = YES;
    self.imgViewUserPopupSmall.hidden = YES;
    self.lblPopupName.hidden = YES;
    self.lblPopupAge.hidden = YES;
    self.lblPopupUserName.hidden = YES;
    self.tblPopupCatSubCat.hidden = YES;
    
}
-(void)btnUserDisplayNameTap:(NSDictionary *)dic{
    [self.view setUserInteractionEnabled:NO];
    [self showHideAd:NO];
    [self.activityIndiView startAnimating];
    
    self.viewUserPopupMain.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, self.viewUserPopupMain.frame.size.width, self.viewUserPopupMain.frame.size.height);
    self.viewUserPopupMain.hidden = NO;
    [Validation animateYpoint:0 viewToAnimate:self.viewUserPopupMain];
    self.imgViewPopupUserFull.hidden = YES;
    
    self.viewUserPopupSub1.layer.cornerRadius = 5.0f;
    self.imgViewUserPopupSmall.hidden = NO;
    self.viewUserPopupSub1.hidden = NO;
    [Validation setCorners:self.imgViewUserPopupSmall];
    self.lblPopupName.hidden = NO;
    self.lblPopupAge.hidden = NO;
    self.lblPopupUserName.hidden = NO;
    self.tblPopupCatSubCat.hidden = NO;
    
    self.lblPopupAge.text = @"";
    self.lblPopupUserName.text = @"";
    [self.arrCatInt removeAllObjects];
    [self.arrCatProfileDesc removeAllObjects];
    [self.arrSubcatInt removeAllObjects];
    [self.arrSubcatProfileDesc removeAllObjects];
    [self.tblPopupCatSubCat reloadData];

    

//    self.tvPopupInterest.textColor = [UIColor colorWithRed:80/255.0 green:195/255.0 blue:217/255.0 alpha:1];
//    self.tvPopupProfileDesc.textColor= [UIColor colorWithRed:80/255.0 green:195/255.0 blue:217/255.0 alpha:1];
//    self.lblInterest.textColor = [UIColor colorWithRed:98/255.0 green:106/255.0 blue:119/255.0 alpha:1];
    
    self.lblPopupName.text = [DataValidation checkNullString:[dic valueForKey:NAME]];
    self.imgViewUserPopupSmall.imageURL = [NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]];
    
    [self.lblPopupName setTextColor:[Validation getColorForAlphabet:self.lblPopupName.text]];
    self.lblPopupName.text = [HASHTAG_CHARACTER stringByAppendingFormat:@"%@",self.lblPopupName.text];
    [self getUserDetail:dic];
}
-(void)btnBlabCreatorName_Clicked:(NSDictionary *)dic{
    NSLog(@"dic in btnBlabCreatorName_Clicked %@",dic);
    if (self.objUserProfileVC == nil) {
        for (UIView *view in [self.view subviews]) {
            if ([view isKindOfClass:[UIButton class]]) {
                UIButton *btn = (UIButton *)view;
                btn.enabled = NO;
            }
            else if ([view isKindOfClass:[UITableView class]]){
                UITableView *tbl = (UITableView *)view;
                [tbl setUserInteractionEnabled:NO];
            }
        }
        self.objUserProfileVC = [self.storyboard instantiateViewControllerWithIdentifier:@"UserProfileVC"];
        self.objUserProfileVC.delegate = self;
        CGRect frame = self.view.frame;
        frame.origin.y = [UIScreen mainScreen].bounds.size.height;
        self.objUserProfileVC.view.frame = frame;
        self.objUserProfileVC.view.backgroundColor = [UIColor clearColor];
        [self.objUserProfileVC willMoveToParentViewController:self];
        [self.view addSubview:self.objUserProfileVC.view];
        [self addChildViewController:self.objUserProfileVC];
        [self.objUserProfileVC didMoveToParentViewController:self];
        self.objUserProfileVC.dicSelected = dic;
        self.objUserProfileVC.strUserID = [NSString stringWithFormat:@"%@",[dic valueForKey:@"ID"]];
        self.objUserProfileVC.selType = 2;  //  2 means display user data
        [self.objUserProfileVC updateUserInfo];
        [Validation animateYpoint:0 viewToAnimate:self.objUserProfileVC.view];
    }
}
-(void)btnBlabCreatorImage_Clicked:(NSDictionary *)dic{
    NSLog(@"dic in btnBlabCreatorImage_Clicked %@",dic);
    if (self.objUserProfileVC == nil) {
        for (UIView *view in [self.view subviews]) {
            if ([view isKindOfClass:[UIButton class]]) {
                UIButton *btn = (UIButton *)view;
                btn.enabled = NO;
            }
            else if ([view isKindOfClass:[UITableView class]]){
                UITableView *tbl = (UITableView *)view;
                [tbl setUserInteractionEnabled:NO];
            }
        }
        self.objUserProfileVC = [self.storyboard instantiateViewControllerWithIdentifier:@"UserProfileVC"];
        self.objUserProfileVC.delegate = self;
        CGRect frame = self.view.frame;
        frame.origin.y = [UIScreen mainScreen].bounds.size.height;
        self.objUserProfileVC.view.frame = frame;
        self.objUserProfileVC.view.backgroundColor = [UIColor clearColor];
        [self.objUserProfileVC willMoveToParentViewController:self];
        [self.view addSubview:self.objUserProfileVC.view];
        [self addChildViewController:self.objUserProfileVC];
        [self.objUserProfileVC didMoveToParentViewController:self];
        self.objUserProfileVC.dicSelected = dic;
        self.objUserProfileVC.strUserID = [NSString stringWithFormat:@"%@",[dic valueForKey:@"ID"]];
        self.objUserProfileVC.selType = 1;  //  1 means display user big image
        [self.objUserProfileVC updateUserInfo];
        [Validation animateYpoint:0 viewToAnimate:self.objUserProfileVC.view];
    }
}
-(void)updateUserInfoFromPopup:(NSDictionary *)dic updatedInfo:(NSMutableDictionary *)updatedInfo{
    if ([self.arrData containsObject:dic]) {
        NSLog(@"having object %d",(int)[self.arrData indexOfObject:dic]);
        NSMutableDictionary *dicToChange = [NSMutableDictionary dictionaryWithDictionary:dic];
        [dicToChange setObject:[updatedInfo valueForKey:IS_USER_BLOCKED] forKey:IS_USER_BLOCKED];
        [dicToChange setObject:[updatedInfo valueForKey:IS_FRIEND] forKey:IS_FRIEND];
        [dicToChange setObject:[updatedInfo valueForKey:IS_FRND_REQ_SENT] forKey:IS_FRND_REQ_SENT];
        [dicToChange setObject:[updatedInfo valueForKey:IS_Follow] forKey:IS_Follow];
        [self.arrData replaceObjectAtIndex:[self.arrData indexOfObject:dic] withObject:dicToChange];
        
        [self.tblData beginUpdates];
        [self.tblData reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:[self.arrData indexOfObject:dic] inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
        [self.tblData endUpdates];
        //        NSMutableDictionary *dicUpdate = [NSMutableDictionary dictionaryWithDictionary:dic];
        //        [dicUpdate setValue:<#(id)#> forKey:<#(NSString *)#>]
    }
    else{
        NSLog(@"not having object");
    }
}
-(void)hideUserProfileVC{
    for (UIView *view in [self.view subviews]) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *btn = (UIButton *)view;
            btn.enabled = YES;
        }
        else if ([view isKindOfClass:[UITableView class]]){
            UITableView *tbl = (UITableView *)view;
            [tbl setUserInteractionEnabled:YES];
        }
    }
    self.objUserProfileVC = nil;
}
-(void)showHideAd:(BOOL)isShow{
    if (isShow) {
        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        [Validation ResizeViewForAds];
    }
    else{
        [Validation removeAdviewFromSuperView];
        [Validation ResizeViewForAds];
    }
}
-(void)tapGestureViewUserPopupMain:(UIGestureRecognizer *)ges{
//    if (ges.view.tag == 101) {
//        self.viewUserPopupMain.hidden = YES;
    [Validation animateYpoint:[UIScreen mainScreen].bounds.size.height viewToAnimate:self.viewUserPopupMain];
    [self showHideAd:YES];
//    }
    
}
#pragma mark Map Methods

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    if (!self.isUserLocationAddedToAnnotationList) {
        
        self.UserLocation = userLocation;
        appDelegate.UserCurrentLatitude = userLocation.coordinate.latitude;
        appDelegate.UserCurrentLongitude = userLocation.coordinate.longitude;

        dispatch_async(dispatch_get_main_queue(),^{
            [self SearchFUserBasedOnFilterList];
            
            [self setUserCoordinates];
        });
    }
}
- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation{
    NSLog(@"didUpdateToLocation fromLocation");
     [locManager stopUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager
     didUpdateLocations:(NSArray *)locations{
    NSLog(@"didUpdateLocations");
    [locManager stopUpdatingLocation];
}
/*
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    // We only need to start updating location for iOS 8 -- iOS 7 users should have already
    // started getting location updates
    NSLog(@"didChangeAuthorizationStatus");
    if (status == kCLAuthorizationStatusAuthorizedAlways ||
        status == kCLAuthorizationStatusAuthorizedWhenInUse) {
        [manager startUpdatingLocation];
    }
}*/
- (void)mapView:(MKMapView *)mapView didFailToLocateUserWithError:(NSError *)error {
    NSLog(@"error.description map %@",error.description);
}
-(void)setUserCoordinates{
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(self.UserLocation.coordinate, 1,1);
    
    region.center.latitude = self.mapView.userLocation.coordinate.latitude;
    region.center.longitude = self.mapView.userLocation.coordinate.longitude;
   // region.span = MKCoordinateSpanMake(10, 20);
    region.span = MKCoordinateSpanMake(0.05, 0.05);
    
    [self.mapView setRegion:[self.mapView regionThatFits:region] animated:YES];
    
    //        // Add an annotation
    MKPointAnnotation *point = [[MKPointAnnotation alloc] init] ;
    point.coordinate = self.UserLocation.coordinate;
    [self.mapView addAnnotation:point];
    
    self.isUserLocationAddedToAnnotationList = YES;
    
}
-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation{
    
    //if its just user location , just return nil
    if ([annotation isKindOfClass:[MKUserLocation class]]) {
        return nil;
    }
    
    //try to dequeue an existing pinview first
    static NSString *strAnnotationId =  @"AnnotationId";
    MKPinAnnotationView *pinView = (MKPinAnnotationView*)
    [self.mapView dequeueReusableAnnotationViewWithIdentifier:strAnnotationId];
    if (pinView == nil) {
        pinView = [[MKPinAnnotationView alloc]
                   initWithAnnotation:annotation reuseIdentifier:strAnnotationId] ;
    }
    pinView.animatesDrop = YES;
    pinView.canShowCallout = YES;
    pinView.pinColor = MKPinAnnotationColorPurple;
    
    MultipleAnnotationLocation *newAnnotation = nil;
    if ([annotation isKindOfClass:[MultipleAnnotationLocation class]]) {
        newAnnotation = (MultipleAnnotationLocation *)annotation;
        //  NSLog(@"index = %d",newAnnotation.annotationIndex);
    }
    NSLog(@"annotationIndex = %d",newAnnotation.annotationIndex);
    
    if (newAnnotation != nil) {
        if (newAnnotation.annotationIndex == 0) {
            UIImageView *userAvatar = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
            [userAvatar setImage:[self GetAnnotationImgFromURL:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]]]];
            userAvatar.layer.cornerRadius = 15.0;
            userAvatar.layer.masksToBounds = YES;
            userAvatar.layer.borderColor = [[UIColor blackColor] CGColor];
            userAvatar.layer.borderWidth = 1;
            UIImageWriteToSavedPhotosAlbum(userAvatar.image, nil, nil, nil);
            pinView.leftCalloutAccessoryView = userAvatar;
        }
    }
    
    if (self.arrData.count > 0) {
        UIImageView *userAvatar = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
        if (newAnnotation != nil) {
            NSString *strPhotoPath = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:newAnnotation.annotationIndex] valueForKey:USER_PHOTO_PATH]];
            [userAvatar setImage:[self GetAnnotationImgFromURL:strPhotoPath]];
        }
        else{
            [userAvatar setImage:[UIImage imageNamed:btnMenu_Frnd_Request]];
        }
        userAvatar.layer.cornerRadius = 15.0;
        userAvatar.layer.masksToBounds = YES;
        userAvatar.layer.borderColor = [[UIColor blackColor] CGColor];
        userAvatar.layer.borderWidth = 1;
        UIImageWriteToSavedPhotosAlbum(userAvatar.image, nil, nil, nil);
        pinView.leftCalloutAccessoryView = userAvatar;
    }
    return pinView;
}

-(UIImage *)GetAnnotationImgFromURL:(NSString *)url{
    NSData *imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:url]];
    
    CGDataProviderRef dataProvider = CGDataProviderCreateWithCFData((__bridge CFDataRef)imageData);
    CGImageRef imageRef = ([[url pathExtension] isEqualToString:@"png"])?CGImageCreateWithPNGDataProvider(dataProvider, NULL, NO, kCGRenderingIntentDefault):CGImageCreateWithJPEGDataProvider(dataProvider, NULL, NO, kCGRenderingIntentDefault);
    UIImage *image = [UIImage imageWithCGImage:imageRef ];
    
    CGDataProviderRelease(dataProvider);
    CGImageRelease(imageRef);
    
    return image;
}
- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    
    
    
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.lblPopupAge.text = [NSString stringWithFormat:@"%d years old",[[[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"Age"] intValue]];
                            self.lblPopupUserName.text = [[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"UserName"];
                            [self.lblPopupAge setTextColor:[Validation getColorForAlphabet:self.lblPopupUserName.text]];
                            [self.lblPopupUserName setTextColor:[Validation getColorForAlphabet:self.lblPopupUserName.text]];
                            
                            self.lblPopupUserName.text = [[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"UserName"];//[HASHTAG_CHARACTER stringByAppendingFormat:@"%@",[[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"UserName"]];

//                            NSLog(@"arr obj UserDescriptions %@ UserInterests %@",[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"],[[[[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] objectAtIndex:0] valueForKey:@"UserSubInterest"] objectAtIndex:0] valueForKey:@"Name"]);
                            
//                            NSString *strInterest = @"";
//                            NSString *strProfileDesc = @"";
                            for (int i=0; i<[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] count]; i++) {
                                [self.arrCatInt addObject:[[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] objectAtIndex:i] valueForKey:@"Name"]];
                                NSString *strInterest = @"";
                                for (int j=0; j<[[[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] objectAtIndex:i] valueForKey:@"UserSubInterest"] count]; j++) {
                                    strInterest = [strInterest stringByAppendingFormat:@"%@, ",[[[[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] objectAtIndex:i] valueForKey:@"UserSubInterest"] objectAtIndex:j] valueForKey:@"Name"]];
                                }
                                if (strInterest.length==0) {
                                    [self.arrSubcatInt addObject:@""];
                                }
                                else{
                                    strInterest = [strInterest substringToIndex:strInterest.length-2];
                                    [self.arrSubcatInt addObject:strInterest];
                                }
                            }
                            NSLog(@"final strInterest %@ %@",self.arrCatInt,self.arrSubcatInt);

                            for (int i=0; i<[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] count]; i++) {
                                [self.arrCatProfileDesc addObject:[[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] objectAtIndex:i] valueForKey:@"Name"]];
                                NSString *strProfileDesc = @"";// [strProfileDesc stringByAppendingFormat:@"%@, ",[[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] objectAtIndex:i] valueForKey:@"Name"]];
                                for (int j=0; j<[[[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] objectAtIndex:i] valueForKey:@"UserSubDesc"] count]; j++) {
                                    strProfileDesc = [strProfileDesc stringByAppendingFormat:@"%@, ",[[[[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] objectAtIndex:i] valueForKey:@"UserSubDesc"] objectAtIndex:j] valueForKey:@"Name"]];
                                }
                                if (strProfileDesc.length==0) {
                                    [self.arrSubcatProfileDesc addObject:@""];
                                }
                                else{
                                    strProfileDesc = [strProfileDesc substringToIndex:strProfileDesc.length-2];
                                    [self.arrSubcatProfileDesc addObject:strProfileDesc];
                                }
                            }
                            NSLog(@"final strProfileDesc %@ %@",self.arrCatProfileDesc,self.arrSubcatProfileDesc);
//                            NSLog(@"final strProfileDesc %d %d",(int)self.arrCatProfileDesc.count,(int)self.arrSubcatProfileDesc.count);
                            [self.tblPopupCatSubCat reloadData];
                            /*
                            if (strInterest.length!=0) {
                                self.lblInterest.hidden=NO;
                                strInterest = [strInterest substringToIndex:strInterest.length-1];
                            }
                            self.tvPopupInterest.text = strInterest;
                            if (strProfileDesc.length!=0) {
                                strProfileDesc = [strProfileDesc substringToIndex:strProfileDesc.length-1];
                            }
                            
                            self.tvPopupProfileDesc.text = strProfileDesc;
                             */
                            [self.view setUserInteractionEnabled:YES];
                            [self.activityIndiView stopAnimating];

                            arr = nil;
                        }
                    }
                }
                
            }
        }
    }
    else{
        [HUD hide:YES];
    }
}
- (void)requestFinished:(ASIHTTPRequest *)request{
	
	NSError *error = nil;

	if (self.activityLoading != nil) {
		[self.activityLoading removeFromSuperview];
		self.activityLoading = nil;
	}

	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData] options:0 error:&error];
	
	//[HUD hide:YES];
	[Validation removeToastFromMemory];
    
    NSLog(@"LocationVC - data received==3 %@",dicResponse);
    
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (request.tag == 1) {
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil && ((NSArray*)response).count > 0) {
                            
                            NSArray *arr = [NSArray arrayWithArray:(NSArray *)response];
                            
                            self.isDataNull = NO;
                            if (arr.count < PageSize) {
                                [self.lbl_NoDataAvailable setHidden:YES];
                                self.isDataNull = YES;
                            }

                            if (arr.count>0) {
                                
//                                dispatch_async(dispatch_get_main_queue(),^{
//                                    
//                                });
                                [self setDataInArray:arr];
                                if (self.is_GeoLocation) {
                                    //[self performSelectorInBackground:@selector(addNewAnnotationsToArray:) withObject:arr];
                               //     [self performSelector:@selector(addNewAnnotationsToArray:) withObject:arr afterDelay:0.5];
                                }
                            }
                            arr = nil;
                        }
                        else {
                            if (self.arrData.count == 0) {
                                self.lbl_NoDataAvailable.hidden = NO;
                            }
                            else{
                                self.lbl_NoDataAvailable.hidden = YES;
                            }
                            self.isDataNull = YES;
                        }
                    }
                }
                else{
                    
                }
                [HUD hide:YES];
            }
            else if (request.tag == 2){
                //req sent
                [HUD hide:YES];
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                 //   [Validation showToastMessage:@"Request Sent" displayDuration:SUCCESS_MSG_DURATION];
                }
                
            }
            else if (request.tag == 3 || request.tag == 4){
                //req accept reject
                [HUD hide:YES];
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    NSLog(@"dic = %@",[dicResponse valueForKey:STATUS]);
                    if (request.tag == 3) {
                     //    [Validation showToastMessage:@"User added to your friend list." displayDuration:SUCCESS_MSG_DURATION];
                    }

                    else if (request.tag == 4) {
                      //  [Validation showToastMessage:@"Friend request rejected." displayDuration:SUCCESS_MSG_DURATION];
                    }
                }
            }
            else if (request.tag == 5){
                //req sent
                [HUD hide:YES];
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    
                }
            }

        }
    }
    else{
        [HUD hide:YES];
    }
	
	request = nil;
	[Validation ResizeViewForAds];
}

- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}
-(void)setDataInArray:(NSArray *)arr{
    for (int i =0; i<(int)arr.count; i++) {
        
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arr objectAtIndex:i]];
        [dic setValue:@"0" forKey:IS_SELECTED];
        [self.arrData addObject:dic];
        
        dic = nil;
    }
    
    if (self.arrData.count == 0) {
        self.lbl_NoDataAvailable.hidden = NO;
    }
    else{
        self.lbl_NoDataAvailable.hidden = YES;
    }
    [self.tblData reloadData];
    
}

-(void)addNewAnnotationsToArray:(NSArray *)arr{
    NSMutableArray* annotations = [[NSMutableArray alloc] init] ;
    
    for (int i =0; i<(int)arr.count; i++) {
        
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arr objectAtIndex:i]];
        
        if (([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:@"lat"]]].length>0)) {
            CLLocationCoordinate2D theCoordinate1;
            double lat = [[dic valueForKey:@"lat"] doubleValue];
            double longi = [[dic valueForKey:@"lng"] doubleValue];
            theCoordinate1.latitude = lat;
            theCoordinate1.longitude = longi;
            
            MultipleAnnotationLocation* myAnnotation1 = [[MultipleAnnotationLocation alloc] init] ;
            
            myAnnotation1.coordinate=theCoordinate1;
            myAnnotation1.title=[NSString stringWithFormat:@"%@",[dic valueForKey:NAME]];
            myAnnotation1.subTitle=[NSString stringWithFormat:@"%@",[dic valueForKey:USER_NAME]];
            myAnnotation1.annotationIndex = i;
            NSLog(@"addNewAnnotationsToArray ----> annotaion Index = %d",i);
            [self.mapView addAnnotation:myAnnotation1];
            [annotations addObject:myAnnotation1];
        }
        dic = nil;
    }
   // [self setPositionsOnMap:annotations];
}

-(void)setPositionsOnMap:(NSArray *)annotations{
    // Append this code at the end of viewDidLoad method to concentratet the Map
    // Walk the list of overlays and annotations and create a MKMapRect that
    // bounds all of them and store it into flyTo.
    MKMapRect flyTo = MKMapRectNull;
    for (MultipleAnnotationLocation *annotation in annotations) {
        NSLog(@"fly to on");
        MKMapPoint annotationPoint = MKMapPointForCoordinate(annotation.coordinate);
        MKMapRect pointRect = MKMapRectMake(annotationPoint.x, annotationPoint.y, 0, 0);
        if (MKMapRectIsNull(flyTo)) {
            flyTo = pointRect;
        } else {
            flyTo = MKMapRectUnion(flyTo, pointRect);
        }
    }
    
    // Position the map so that all overlays and annotations are visible on screen.
    self.mapView.visibleMapRect = flyTo;
}

#pragma mark    UIActionsheet Delegate

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"button index = %d",(int)buttonIndex);
    
    if (buttonIndex == actionSheet.cancelButtonIndex) {
        
    }
    else if (buttonIndex == 0){
        //only yap
        [self performSegueWithIdentifier:RECORD_OPTION_VC sender:nil];
    }
    else if (buttonIndex == 1){
        //yap with image
        [self performSegueWithIdentifier:CAPTURE_IMAGE_VC sender:nil];
    }
    else if (buttonIndex == 2){
        //yap with video
        if ([[NSFileManager defaultManager] fileExistsAtPath:VIDEO_RECORDING_FOLDER]) {
            //when folder exists
            NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
            if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
                [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
            }
        }
        [self performSegueWithIdentifier:SET_VIDEO_PRIVACY_VC sender:nil];
    }
    else if (buttonIndex == 3){
        TextBlabVC *objVc = [self.storyboard instantiateViewControllerWithIdentifier:@"TextBlabVC"];
        objVc.isGroupMessage = FALSE;
        NSLog(@"%@",[[self.arrSelected objectAtIndex:0] valueForKey:USER_ID]);
        if (self.arrSelected.count==1) {
            objVc.strReceiverId = [[self.arrSelected objectAtIndex:0] valueForKey:USER_ID];
        }
        else{
            objVc.strReceiverId = [NSString stringWithFormat:@"%@",[[self.arrSelected valueForKey:USER_ID] componentsJoinedByString:@"|"]];
        }
        [self.navigationController pushViewController:objVc animated:YES];
    }
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:RECORD_OPTION_VC] || [segue.identifier isEqualToString:CAPTURE_IMAGE_VC] || [segue.identifier isEqualToString:SET_VIDEO_PRIVACY_VC]) {
        if (appDelegate.dic_NotificationReleatedData != nil) {
            appDelegate.dic_NotificationReleatedData = nil;
        }
        
        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    [self.arrSelected valueForKey:USER_ID],SelectedIds,
                                                    [NSNumber numberWithBool:FALSE],IS_GroupNotif,
                                                    [NSNumber numberWithBool:NO],IS_NotifSendToAll,
                                                    @"0",BlabType,
                                                    nil];
	}
    
    [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
    [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];


}


@end
