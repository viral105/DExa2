//
//  UserListingByInterestCatSubcatCell.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 2/16/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "UserListingByInterestCatSubcatCell.h"

@implementation UserListingByInterestCatSubcatCell

- (void)awakeFromNib {
    // Initialization code
    [lblCat setTextColor:[UIColor colorWithRed:80/255.0 green:195/255.0 blue:217/255.0 alpha:1]];
    [lblSubcat setTextColor:[UIColor colorWithRed:98/255.0 green:106/255.0 blue:119/255.0 alpha:1]];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setUI{
    lblCat.text = self.strCat;
    lblSubcat.text = self.strSubcat;
    if (self.strSubcat.length!=0) {
        CGSize rect = [self getHeightForSection:self.strSubcat];
        NSLog(@"rect.height %f",rect.height);
        if (rect.height>16) {
            [lblSubcat setFrame:CGRectMake(lblSubcat.frame.origin.x, lblSubcat.frame.origin.y, lblSubcat.frame.size.width, rect.height)];
        }
        else{
            [lblSubcat setFrame:CGRectMake(lblSubcat.frame.origin.x, lblSubcat.frame.origin.y, lblSubcat.frame.size.width, 16)];
        }
        [lblSubcat setNeedsDisplayInRect:lblSubcat.frame];
    }
}
-(CGSize)getHeightForSection:(NSString *)strText{
    //    NSString *strText = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:NAME]];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    NSLog(@"************* again %f",self.contentView.frame.size.width);
    CGRect text = [strText boundingRectWithSize:CGSizeMake(lblSubcat.frame.size.width, 10000)
                                        options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading
                                     attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14],NSParagraphStyleAttributeName:paragraphStyle}
                                        context:nil];
    strText = nil;
    return text.size;
    
}
@end
