//
//  UserListingByInterestCatSubcatCell.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 2/16/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserListingByInterestCatSubcatCell : UITableViewCell{
    IBOutlet UILabel *lblCat;
    IBOutlet UILabel *lblSubcat;
}
@property (nonatomic, strong) NSString *strCat;
@property (nonatomic, strong) NSString *strSubcat;
-(void)setUI;
@end
