//
//  SearchFriendVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 8/8/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "SearchFriendVC.h"
#import "UserCell.h"
#import "MBProgressHUD.h"
#import "SearchFilterSelectionVC.h"
#import "HashBlabSearchVC.h"


#define PageSize	15
@interface SearchFriendVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
    NSMutableArray *arrCatInt;
    NSMutableArray *arrSubcatInt;
    NSMutableArray *arrCatProfileDesc;
    NSMutableArray *arrSubcatProfileDesc;
    UserProfileVC *objUserProfileVC;
    HashBlabSearchVC *objHashBlabSearchVC;

    int currentlyPlaingIndex;
}
@property (nonatomic,strong) NSMutableArray *arrCatInt;
@property (nonatomic,strong) NSMutableArray *arrSubcatInt;
@property (nonatomic,strong) NSMutableArray *arrCatProfileDesc;
@property (nonatomic,strong) NSMutableArray *arrSubcatProfileDesc;
@property (nonatomic,strong) UserProfileVC *objUserProfileVC;
@property (nonatomic,strong) HashBlabSearchVC *objHashBlabSearchVC;
@end

@implementation SearchFriendVC
@synthesize arrCatInt;
@synthesize arrSubcatInt;
@synthesize arrCatProfileDesc;
@synthesize arrSubcatProfileDesc;
@synthesize objUserProfileVC;
@synthesize objHashBlabSearchVC;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureViewUserPopupMain:)];
    [tapGesture setNumberOfTapsRequired:1];
    [self.viewUserPopupSub2 addGestureRecognizer:tapGesture];
    tapGesture = nil;
    
	self.arrData = [[NSMutableArray alloc] init];
    self.arrDataChannels = [[NSMutableArray alloc] init];
    self.arrCatInt = [NSMutableArray new];
    self.arrSubcatInt = [NSMutableArray new];
    self.arrCatProfileDesc = [NSMutableArray new] ;
    self.arrSubcatProfileDesc = [NSMutableArray new];
    
    self.isFirstTimeLoadChannelSearch = YES;
    
	appDelegate.currentVc = self;
	[self.tblData registerNib:[UINib nibWithNibName:@"UserCell" bundle:nil] forCellReuseIdentifier:@"cellIdentifier"];

	
	[self performSelector:@selector(LoadViewSetting)];
    self.tblData.tag = 101;
    self.pageCounter = 1;
    [self callGetRecommandedUsers];

    
}
-(void)viewWillAppear:(BOOL)animated{
    
	[super viewWillAppear:animated];
	appDelegate.currentVc = self;
	//[Validation increaseTableSize];
	
    //set menu image
    [self.btnMenu removeTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
	[self.btnMenu addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
	[self.lbl_NoDataAvailable setHidden:YES];
//	self.pageCounter = 1;
//	self.isDataNull = NO;
//	[Validation ResizeViewForAds];
    
    if (self.objUserProfileVC!=nil) {
        [Validation removeAdviewFromSuperView];
        [self.view insertSubview:[Validation sharedBannerView] belowSubview:self.objUserProfileVC.view];
        [Validation ResizeViewForAds];
    }
    else{
        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        [Validation ResizeViewForAds];
    }

}

-(void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
	//[Validation increaseTableSize];
    appDelegate.isShouldShowReplyPopUp = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark CUSTOM Methods

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    [self.lbl_NoDataAvailable setTextColor:TWITTER_BLUE_COLOR];
    [self.lbl_NoDataAvailable setShadowColor:[UIColor clearColor]];
}

-(IBAction)btnBackClicked:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnFilterClicked:(id)sender{
//    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SearchFilterSelectionVC *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:SEARCH_FILTER_SELECTION_VC];

    CATransition* transition = [CATransition animation];
    transition.duration = 0.3;
    transition.type = kCATransitionFade;
    transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:ivc animated:NO];

}

-(void)SearchForText{
	if (self.request !=nil) {
		self.request = nil;
	}
    NSDictionary *dic;
    NSString *strUrl;
    if (self.tblData.tag==103) {
        dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"userid",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:[[NSString stringWithFormat:@"%@",self.tfSearch.text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]], KeyValue,@"name",KeyName,nil],@"2",
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"pageno",KeyName, nil],@"3",
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"pagesize",KeyName, nil],@"4",
                             nil];
        strUrl = [WebServiceContainer getServiceURL:HASH_BLAB_SEARCH withParameters:nil];
    }
    else{
        dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",self.tfSearch.text],KeyValue,@"Name",KeyName, nil],@"2",
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"3",
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"4",
                             nil];
        strUrl = [WebServiceContainer getServiceURL:SEARCH_USER withParameters:nil];
    }
	
	
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//	self.request.delegate = self;
//	self.request.tag = 1;
	strUrl = nil;
	
}
-(void)callGetRecommandedUsers{
    [HUD show:YES];
    if (self.request !=nil) {
        self.request = nil;
    }
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:RECOMMENDED_USER withParameters:nil];
    self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:5];
    }
//    self.request.delegate = self;
//    self.request.tag = 5;
    strUrl = nil;
}
-(void)btnAddFriendClicked:(id)sender{
	//[Validation showLoadingIndicator];
    UIButton *btn = (UIButton *)sender;
    
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    if ([[dicData valueForKey:IS_USER_BLOCKED] boolValue]) {
        [Validation showToastMessage:@"You cannot send friend request to a blocked user." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        //    [HUD show:YES];
        
        // self.selectedIndex = (int)((UIButton *)sender).tag;
        if (![[NSString stringWithFormat:@"%@",[dicData valueForKey:IS_FRND_REQ_SENT]] boolValue]) {
/*            [dicData setValue:@"1" forKey:IS_FRND_REQ_SENT];
            [self.arrData replaceObjectAtIndex:btn.tag withObject:dicData];
            
            
            NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:btn.tag inSection:0]];
            [self.tblData beginUpdates];
            [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
            [self.tblData endUpdates];
*/
            if (self.request !=nil) {
                self.request = nil;
            }
            self.selectedIndex = (int)((UIButton *)sender).tag;
            
            NSString *strRequestId = [NSString stringWithFormat:@"%@",[dicData valueForKey:USER_ID]];
            
            NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                                 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                                 [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
                                 nil];
            
            RecrodingFriendRequestVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:@"RecrodingFriendRequestVC"];
            obj.delegateFriendReq = self;
            obj.indexSelected = (int)btn.tag;
            obj.dicToSendFriendRequest = dic;
            [self.navigationController pushViewController:obj animated:YES];
            
/*
            NSString *strUrl = [WebServiceContainer getServiceURL:ADD_FRIEND withParameters:nil];
            self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
            if (self.request == nil) {
                [HUD hide:YES];
            }
            else{
                [self.request setDelegate:self];
                [self.request setTag:2];
            }
    //        self.request.delegate = self;
    //        self.request.tag = 2;
            strUrl = nil;
 */
        }
        else{
            [Validation showToastMessage:@"Friend request already sent." displayDuration:ERROR_MSG_DURATION];
        }
        
    }
    
    dicData = nil;
}
-(void)btnAddFriendFromPopup_Clicked:(NSDictionary *)dicOld{
    NSLog(@"arrData indexOfObject %d",(int)[self.arrData indexOfObject:dicOld]);
    if ([self.arrData containsObject:dicOld]) {
        NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:[self.arrData indexOfObject:dicOld]]];
        NSString *strRequestId = [NSString stringWithFormat:@"%@",[dicData valueForKey:USER_ID]];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
                             nil];
        
        RecrodingFriendRequestVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:@"RecrodingFriendRequestVC"];
        obj.delegateFriendReq = self;
        obj.indexSelected = (int)[self.arrData indexOfObject:dicOld];
        obj.dicToSendFriendRequest = dic;
        [self.navigationController pushViewController:obj animated:YES];
    }
    
}

-(void)btnAcceptFriendRequest:(id)sender{
//	[Validation showLoadingIndicator];
    
    UIButton*btn = ((UIButton *)sender);
    
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    if ([[dicData valueForKey:IS_USER_BLOCKED] boolValue]) {
        [Validation showToastMessage:@"You cannot send friend request to a blocked user." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        
        //     [HUD show:YES];
        
        [dicData setValue:@"1" forKey:IS_FRIEND];
        [self.arrData replaceObjectAtIndex:btn.tag withObject:dicData];
        
        NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:btn.tag inSection:0]];
        [self.tblData beginUpdates];
        [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
        [self.tblData endUpdates];
        
        if (self.request !=nil) {
            self.request = nil;
        }
        self.selectedIndex = (int)((UIButton *)sender).tag;
        NSString *strRequestId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:USER_ID]];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
                             [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"IsFriend",KeyName, nil],@"3",
                             nil];
        
        NSString *strUrl = [WebServiceContainer getServiceURL:ACCEPT_REJECT_FRND_REQ withParameters:nil];
        self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
        if (self.request == nil) {
            [HUD hide:YES];
        }
        else{
            [self.request setDelegate:self];
            [self.request setTag:3];
        }
//        self.request.delegate = self;
//        self.request.tag = 3;
        strUrl = nil;
    }
    dicData = nil;
}

-(void)btnRejectFriendRequest:(id)sender{
	//[Validation showLoadingIndicator];
    UIButton*btn = ((UIButton *)sender);
    
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    if ([[dicData valueForKey:IS_USER_BLOCKED] boolValue]) {
        [Validation showToastMessage:@"You cannot send friend request to a blocked user." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        //     [HUD show:YES];
        [dicData setValue:@"0" forKey:IS_FRIEND];
        [dicData setValue:@"0" forKey:IS_FRND_REQ_REC];
        [self.arrData replaceObjectAtIndex:btn.tag withObject:dicData];
        
        NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:btn.tag inSection:0]];
        [self.tblData beginUpdates];
        [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
        [self.tblData endUpdates];
        
        
        if (self.request !=nil) {
            self.request = nil;
        }
        self.selectedIndex = (int)((UIButton *)sender).tag;
        NSString *strRequestId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:USER_ID]];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
                             [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"IsFriend",KeyName, nil],@"3",
                             nil];
        
        NSString *strUrl = [WebServiceContainer getServiceURL:ACCEPT_REJECT_FRND_REQ withParameters:nil];
        self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
        if (self.request == nil) {
            [HUD hide:YES];
        }
        else{
            [self.request setDelegate:self];
            [self.request setTag:4];
        }
//        self.request.delegate = self;
//        self.request.tag = 4;
        strUrl = nil;
    }
}
-(void)getUserDetail:(NSDictionary*)dic{
    
    NSDictionary *dicNew = [NSDictionary dictionaryWithObjectsAndKeys:
                            [NSDictionary dictionaryWithObjectsAndKeys:[dic valueForKey:@"ID"],KeyValue,@"UserID",KeyName, nil],@"1",
                            nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_USER_ALL_DETAIL withParameters:nil];
    
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dicNew isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:1];
    }
//    [obj setDelegate:self];
//    [obj setTag:1];
    strUrl = nil;
    
}
-(void)updateUserData:(int)indSel{
    NSLog(@"indSel %d",indSel);
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indSel]];
    
    [dicData setValue:@"1" forKey:IS_FRND_REQ_SENT];
    [self.arrData replaceObjectAtIndex:indSel withObject:dicData];
    if (self.objUserProfileVC != nil) {
        [self.objUserProfileVC.dicUserDetail setObject:@"1" forKey:IS_FRND_REQ_SENT];
        [self.objUserProfileVC LoadViewSetting];
    }
     
    NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indSel inSection:0]];
    [self.tblData beginUpdates];
    [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
    [self.tblData endUpdates];
}
-(IBAction)btnUser_Clicked:(id)sender{
    self.tblData.tag = 101;
    
    if (self.imgViewRecommended.isHidden) {
        self.tblData.frame = CGRectMake(self.tblData.frame.origin.x, self.tblData.frame.origin.y+40, self.tblData.frame.size.width, self.tblData.frame.size.height-40);
    }
    
    self.tfSearch.text = @"";
    self.imgViewRecommended.hidden = NO;
    [self.arrData removeAllObjects];
    [self.tblData reloadData];
    self.pageCounter = 1;
    [self callGetRecommandedUsers];
    
    [self.btnUser setBackgroundImage:[UIImage imageNamed:btn_Blue_Selected] forState:UIControlStateNormal];
    [self.btnChannels setBackgroundImage:[UIImage imageNamed:btn_White_DeSelected] forState:UIControlStateNormal];
    [self.btnUser setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.btnChannels setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
/*
    self.isFirstTimeLoadChannelSearch = NO;
    [self.arrDataChannels removeAllObjects];
    [self.arrDataChannels addObjectsFromArray:self.objHashBlabSearchVC.arrActiveHBlab];
    self.strPrevChannelsSearch = self.objHashBlabSearchVC.tfSearch.text;
    self.isDataNullChannels = self.objHashBlabSearchVC.isDataNull;
    self.isRecommendChannel = self.objHashBlabSearchVC.isRecommendChannel;
*/
    [self.objHashBlabSearchVC willMoveToParentViewController:nil];  // 1
    
    [self.objHashBlabSearchVC.view removeFromSuperview];            // 2
    
    [self.objHashBlabSearchVC removeFromParentViewController];      // 3
    
    self.objHashBlabSearchVC = nil;

}

-(IBAction)btnChannels_Clicked:(id)sender{
//    self.tblData.tag = 103;
//    [self.arrData removeAllObjects];
//    [self.tblData reloadData];
    [self.view endEditing:YES];
    [self.btnUser setBackgroundImage:[UIImage imageNamed:btn_White_DeSelected] forState:UIControlStateNormal];
    [self.btnChannels setBackgroundImage:[UIImage imageNamed:btn_Blue_Selected] forState:UIControlStateNormal];
    [self.btnChannels setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.btnUser setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
//    if (!self.imgViewRecommended.isHidden) {
//        [self.tblData setContentOffset:CGPointMake(0, 0)];
//        self.imgViewRecommended.hidden = YES;
//        self.tblData.frame = CGRectMake(self.tblData.frame.origin.x, self.tblData.frame.origin.y-40, self.tblData.frame.size.width, self.tblData.frame.size.height+40);
//    }
    self.objHashBlabSearchVC = [self.storyboard instantiateViewControllerWithIdentifier:@"HashBlabSearchVC"];
//    self.objUserProfileVC.delegate = self;
//    CGRect frame = self.view.frame;
//    frame.origin.y = [UIScreen mainScreen].bounds.size.height;
    self.objHashBlabSearchVC.isChildView = YES;
    
    if (self.isFirstTimeLoadChannelSearch){
        self.objHashBlabSearchVC.isRecommendChannel = YES;
    }
    else{
        self.objHashBlabSearchVC.isRecommendChannel = self.isRecommendChannel;
    }
    
    self.objHashBlabSearchVC.view.frame = CGRectMake(0, self.btnChannels.frame.origin.y+self.btnChannels.frame.size.height+7, DEVICE_WIDTH, DEVICE_HEIGHT-(self.btnChannels.frame.origin.y+self.btnChannels.frame.size.height+7)-50);
    NSLog(@"%@",NSStringFromCGRect(self.objHashBlabSearchVC.view.frame));
//    self.objHashBlabSearchVC.view.backgroundColor = [UIColor redColor];
    [self.objHashBlabSearchVC willMoveToParentViewController:self];
    [self.view addSubview:self.objHashBlabSearchVC.view];
    [self addChildViewController:self.objHashBlabSearchVC];
    [self.objHashBlabSearchVC didMoveToParentViewController:self];
/*
    if (!self.isFirstTimeLoadChannelSearch && !self.isRecommendChannel) {
        [self.objHashBlabSearchVC.arrActiveHBlab removeAllObjects];
        [self.objHashBlabSearchVC.arrActiveHBlab addObjectsFromArray:self.arrDataChannels];
        [self.objHashBlabSearchVC.tblActiveHBlab reloadData];
        self.objHashBlabSearchVC.tfSearch.text = self.strPrevChannelsSearch;
        self.objHashBlabSearchVC.isDataNull = self.isDataNullChannels;
        self.objHashBlabSearchVC.isRecommendChannel = self.isRecommendChannel;
    }
*/
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
}
#pragma mark  UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (tableView==self.tblData) {
        return 1;
    }
    else{
        if (self.arrCatProfileDesc.count==0 && self.arrCatInt.count==0) {
            return 0;
        }
        else if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            return 2;
        }
        else{
            return 1;
        }
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (tableView==self.tblData) {
        return 0;
    }
    else{
        return 30;
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (tableView==self.tblData) {
        return nil;
    }
    else{
        UILabel *lblHeader = [[UILabel alloc] init];
        [lblHeader setFrame:CGRectMake(0, 0, self.tblPopupCatSubCat.frame.size.width, 30)];
        lblHeader.numberOfLines = 1;
        [lblHeader setFont:[UIFont boldSystemFontOfSize:16]];
        [lblHeader setBackgroundColor:[UIColor whiteColor]];
        [lblHeader setTextColor:[UIColor colorWithRed:98/255.0 green:106/255.0 blue:119/255.0 alpha:1]];
        [lblHeader setTextAlignment:NSTextAlignmentCenter];
        
        if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            if (section==0) {
                [lblHeader setText:@"PROFILE DESCRIPTION"];
            }
            else{
                [lblHeader setText:@"INTEREST"];
            }
        }
        else if(self.arrCatInt.count==0 && self.arrCatProfileDesc.count!=0){
            [lblHeader setText:@"PROFILE DESCRIPTION"];
        }
        else if(self.arrCatInt.count!=0 && self.arrCatProfileDesc.count==0){
            [lblHeader setText:@"INTEREST"];
        }
        return lblHeader;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView==self.tblData) {
        if (self.tblData.tag==103) {
            return 115;
        }
        else{
            return 100;
        }
    }
    else{
        int height = 28;
        if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            if (indexPath.section==0) {
                CGSize rect = [self getHeightForSection:[self.arrSubcatProfileDesc objectAtIndex:indexPath.row]];
                NSLog(@"pro desc height %d ipath %d",(int)rect.height,(int)indexPath.row);
                //                if ((int)rect.height>16) {
                height+=(int)rect.height;
                //                }
            }
            else{
                CGSize rect = [self getHeightForSection:[self.arrSubcatInt objectAtIndex:indexPath.row]];
                NSLog(@"interest height %d ipath %d",(int)rect.height,(int)indexPath.row);
                //                if ((int)rect.height>16) {
                height+=(int)rect.height;
                //                }
            }
        }
        else if(self.arrCatInt.count==0 && self.arrCatProfileDesc.count!=0){
            CGSize rect = [self getHeightForSection:[self.arrSubcatProfileDesc objectAtIndex:indexPath.row]];
            NSLog(@"pro desc height %d ipath %d",(int)rect.height,(int)indexPath.row);
            //            if ((int)rect.height>16) {
            height+=(int)rect.height;
            //            }
        }
        else if(self.arrCatInt.count!=0 && self.arrCatProfileDesc.count==0){
            CGSize rect = [self getHeightForSection:[self.arrSubcatInt objectAtIndex:indexPath.row]];
            NSLog(@"interest height %d ipath %d",(int)rect.height,(int)indexPath.row);
            //            if ((int)rect.height>16) {
            height+=(int)rect.height;
            //            }
        }
        return height;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	//return self.arrData.count;
    if (tableView==self.tblData) {
        if (!self.isDataNull) {
            if (self.arrData.count>PageSize-1) {
                return self.arrData.count+1;
            }
            else{
                return self.arrData.count;
            }
        }
        return self.arrData.count;
    }
    else{
        if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            if (section==0) {
                return self.arrCatProfileDesc.count;
            }
            else{
                return self.arrCatInt.count;
            }
        }
        else if(self.arrCatInt.count==0 && self.arrCatProfileDesc.count!=0){
            return self.arrCatProfileDesc.count;
        }
        else if(self.arrCatInt.count!=0 && self.arrCatProfileDesc.count==0){
            return self.arrCatInt.count;
        }
        else{
            return 0;
        }
    }

}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	if (tableView==self.tblData) {
        if (self.tblData.tag==101 || self.tblData.tag==102) {
            NSString *cellId = [NSString stringWithFormat:@"%d",(int)indexPath.row];
            
            if (indexPath.row < self.arrData.count) {
                cellId = [cellId stringByAppendingFormat:@"%@",[[self.arrData objectAtIndex:indexPath.row] valueForKey:USER_ID]];
            }
            
            UserCell *cell = [[UserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
            
            //        UserCell *cell = (UserCell *)[tableView dequeueReusableCellWithIdentifier:@"cellIdentifier"];
            cell.delegate = self;
            cell.isShowUserDetailPopup = YES;
            //UserCell *cell = (UserCell *)[tableView dequeueReusableCellWithIdentifier:@"cellIdentifier"];
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            [cell clearsContextBeforeDrawing];
            
            
            if (!self.isDataNull && (indexPath.row == (self.arrData.count) || indexPath.row == self.arrData.count)){
                
                if (!self.isDataNull) {
                    cell = [[UserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
                    cell.cellBg.hidden = YES;
                    cell.ProfileImg.hidden = YES;
                    cell.btnNotificationProfile.hidden = YES;
                    cell.lblDisplayName.hidden = YES;
                    cell.lblUserName.hidden = YES;
                    cell.imgFriendshipStatus.hidden = YES;
                    cell.btnReqStatus.hidden = YES;
                    cell.btnReqDeny.hidden = YES;
                    cell.btnUnfriend.hidden = YES;
                    cell.btnFriendCount.hidden = YES;
                    cell.imgViewFriendType.hidden = YES;
                    cell.lblMaidenName.hidden = YES;
                    cell.imgViewIsNewFriend.hidden = YES;
                    cell.btnPlayPause.hidden = YES;
                    if (self.activityLoading != nil) {
                        [self.activityLoading removeFromSuperview];
                        self.activityLoading = nil;
                    }
                    self.activityLoading = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                    self.activityLoading.center = cell.contentView.center;
                    self.activityLoading.frame = cell.contentView.frame;
                    self.activityLoading.hidesWhenStopped = TRUE;
                    [self.activityLoading startAnimating];
                    [cell.contentView addSubview:self.activityLoading];
                    
                    self.pageCounter++;
                    if (self.tblData.tag==102) {
                        [self performSelectorInBackground:@selector(SearchForText) withObject:nil];
                    }
                    else{
                        [self performSelectorInBackground:@selector(callGetRecommandedUsers) withObject:nil];
                    }
                }
            }
            else{
                //		if (cell == nil) {
                //			cell = [[UserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
                cell.delegate = self;
                cell.isShowUserDetailPopup = YES;
                //			[cell setBoxValuesWithData:[self.arrData objectAtIndex:indexPath.row]];
                //		}
                NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indexPath.row]];
                
                [cell setBoxValuesWithData:[self.arrData objectAtIndex:indexPath.row]];
                
                //check if isFriend
                NSString *isFriend = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IS_FRIEND]]];
                NSString *isFriendReqRec = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IS_FRND_REQ_REC]]];
                NSString *isFriendReqSent = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IS_FRND_REQ_SENT]]];
                
                [cell.imgFriendshipStatus setHidden:TRUE];
                [cell.btnReqDeny setHidden:TRUE];
                [cell.btnReqStatus setHidden:TRUE];
                cell.btnUnfriend.hidden = YES;
                [cell.contentView bringSubviewToFront:cell.imgViewFriendType];
                cell.btnPlayPause.hidden = YES;
                /*
                 if ([DataValidation checkNullString:[[self.arrData objectAtIndex:indexPath.row] valueForKey:@"FilePath"]].length!=0) {
                 cell.btnPlayPause.hidden = NO;
                 
                 //            cell.btnPlayPause.frame = CGRectMake(cell.btnReqStatus.frame.origin.x-10, cell.btnReqStatus.frame.origin.y+cell.btnReqStatus.frame.size.height, cell.btnPlayPause.frame.size.width, cell.btnPlayPause.frame.size.height);
                 cell.btnPlayPause.tag = indexPath.row;
                 [cell.btnPlayPause addTarget:self action:@selector(btnPlayFileClicked:) forControlEvents:UIControlEventTouchUpInside];
                 }
                 else{
                 cell.btnPlayPause.hidden = YES;
                 }
                 */
                if (isFriend.length>0 && [isFriend isEqualToString:@"1"]) {
                    //frined
                    [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_Accept_Request]];
                    [cell.imgFriendshipStatus setHidden:FALSE];
                    cell.imgViewFriendType.hidden = NO;
                    
                    switch ([[dic valueForKey:@"FriendType"] intValue]) {
                        case 0:
                            cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_blabeey.png"];
                            break;
                        case 1:
                            cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_fb.png"];
                            break;
                        case 2:
                            cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_contacts.png"];
                            break;
                            
                        default:
                            break;
                    }
                }
                else{
                    //1. friend req sent
                    if (isFriendReqSent.length > 0 && [isFriendReqSent isEqualToString:@"1"]) {
                        //yes sent
                        [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_Waiting_For_Response]];
                        [cell.imgFriendshipStatus setHidden:FALSE];
                        
                        //                cell.btnPlayPause.frame = CGRectMake(cell.imgFriendshipStatus.frame.origin.x-10, cell.imgFriendshipStatus.frame.origin.y+cell.imgFriendshipStatus.frame.size.height, cell.btnPlayPause.frame.size.width, cell.btnPlayPause.frame.size.height);
                        
                    }
                    else if (isFriendReqRec.length > 0 && [isFriendReqRec isEqualToString:@"1"]){
                        //yes rec
                        //either accept or reject
                        [cell.btnReqDeny setImage:[UIImage imageNamed:Btn_Reject_Request] forState:UIControlStateNormal];
                        [cell.btnReqStatus setImage:[UIImage imageNamed:Btn_Accept_Request] forState:UIControlStateNormal];
                        cell.lblDisplayName.frame = CGRectMake(cell.lblDisplayName.frame.origin.x, cell.lblDisplayName.frame.origin.y, cell.lblDisplayName.frame.size.width-30, cell.lblDisplayName.frame.size.height);
                        
                        [cell.btnReqDeny setHidden:FALSE];
                        [cell.btnReqStatus setHidden:FALSE];
                        
                        //remove old targets
                        [cell.btnReqDeny removeTarget:self action:@selector(btnRejectFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
                        [cell.btnReqStatus removeTarget:self action:@selector(btnAddFriendClicked:) forControlEvents:UIControlEventTouchUpInside];
                        
                        
                        
                        //add new target
                        [cell.btnReqStatus addTarget:self action:@selector(btnAcceptFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
                        [cell.btnReqDeny addTarget:self action:@selector(btnRejectFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
                        
                        cell.btnReqDeny.tag = indexPath.row;
                        cell.btnReqStatus.tag = indexPath.row;
                        
                        
                        
                        //                if ([DataValidation checkNullString:[[self.arrData objectAtIndex:indexPath.row] valueForKey:@"FilePath"]].length!=0) {
                        
                        
                        //                }
                        
                    }
                    else{
                        //not a friend, so send req
                        cell.btnReqDeny.hidden = YES;
                        [cell.btnReqStatus setImage:[UIImage imageNamed:Btn_AddFriend] forState:UIControlStateNormal];
                        [cell.btnReqStatus setHidden:FALSE];
                        
                        //remove old targets
                        [cell.btnReqStatus removeTarget:self action:@selector(btnAcceptFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
                        
                        //add new target
                        [cell.btnReqStatus addTarget:self action:@selector(btnAddFriendClicked:) forControlEvents:UIControlEventTouchUpInside];
                        cell.btnReqStatus.tag = indexPath.row;
                    }
                }
                if ([[dic valueForKey:IS_USER_BLOCKED] boolValue]) {
                    cell.btnUserBlocked.hidden = NO;
                    
                    //            cell.btnPlayPause.frame = CGRectMake(cell.btnUserBlocked.frame.origin.x-60, cell.btnUserBlocked.frame.origin.y-10, cell.btnPlayPause.frame.size.width, cell.btnPlayPause.frame.size.height);
                }
                else{
                    cell.btnUserBlocked.hidden = YES;
                    //            cell.btnPlayPause.frame = CGRectMake(270, cell.btnUserBlocked.frame.origin.y-10, cell.btnPlayPause.frame.size.width, cell.btnPlayPause.frame.size.height);
                }
                
                int yPoint = 10;
                
                cell.cellBg.frame = CGRectMake(cell.cellBg.frame.origin.x, cell.cellBg.frame.origin.y, cell.cellBg.frame.size.width, cell.cellBg.frame.size.height);
                cell.lblDisplayName.frame = CGRectMake(cell.lblDisplayName.frame.origin.x, yPoint, cell.lblDisplayName.frame.size.width, cell.lblDisplayName.frame.size.height);
                cell.btnDisplayName.frame = CGRectMake(cell.lblDisplayName.frame.origin.x, yPoint, cell.lblDisplayName.frame.size.width, cell.lblDisplayName.frame.size.height);
                yPoint+=cell.lblDisplayName.frame.size.height-3;
                
                
                cell.lblUserName.frame = CGRectMake(cell.lblUserName.frame.origin.x, yPoint, cell.lblUserName.frame.size.width, 15);
                cell.lblUserName.font = [UIFont fontWithName:Font_OpneSans_Regular size:12];
                yPoint+=cell.lblUserName.frame.size.height;
                
                //        cell.lblUserName.backgroundColor = [UIColor redColor];
                //        cell.lblDisplayName.backgroundColor = [UIColor greenColor];
                if ([DataValidation checkNullString:[dic valueForKey:LOGIN_USER_MAIDEN_NAME]].length!=0) {
                    cell.lblMaidenName.hidden = NO;
                    [cell.lblMaidenName setFont:[UIFont fontWithName:Font_OpneSans_Regular size:12]];
                    [cell.lblMaidenName setTextColor:UIColorFromRGB(0X727478)];
                    [cell.lblMaidenName setFrame:CGRectMake(cell.lblUserName.frame.origin.x, yPoint, cell.lblUserName.frame.size.width,cell.lblUserName.frame.size.height)];
                    cell.lblMaidenName.text = @"abc";
                    [cell.lblMaidenName setText:[dic valueForKey:@"MaidenName"]];
                    yPoint+=cell.lblMaidenName.frame.size.height+2;
                }
                cell.btnFriendCount.hidden = NO;
                cell.btnFriendCount.frame = CGRectMake(cell.lblUserName.frame.origin.x, yPoint, cell.lblUserName.frame.size.width,cell.lblUserName.frame.size.height);
                cell.btnFriendCount.backgroundColor = [UIColor clearColor];
                //        [cell.btnFriendCount.titleLabel setFont:];
                cell.btnFriendCount.titleLabel.font = [UIFont fontWithName:Font_OpneSans_Regular size:12];
                [cell.btnFriendCount setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
                cell.btnFriendCount.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
                //        [cell.btnFriendCount.titleLabel setText:[NSString stringWithFormat:@"30"]];
                [cell.btnFriendCount setTitle:[NSString stringWithFormat:@"%@ Friends",[dic valueForKey:@"TotalFriend"]] forState:UIControlStateNormal];
                
                
                
            }
            return cell;
        }
        else{
            ActiveHBlabCell *cell = [tableView dequeueReusableCellWithIdentifier:@"activehblab"];
            
            cell.imgViewHBlab.image = nil;
            cell.imgViewHBlab.imageURL = nil;
            cell.imgViewUser.image = nil;
            cell.imgViewUser.imageURL = nil;
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            if (!self.isDataNull && (indexPath.row == (self.arrData.count+1) || indexPath.row == self.arrData.count-1)){
                self.pageCounter ++;
                [self performSelectorInBackground:@selector(SearchForText) withObject:nil];
            }
            cell.dicSel = [self.arrData objectAtIndex:indexPath.row];
            
            [cell setUI];
            
            return cell;
        }
    }
    else{
        UserListingByInterestCatSubcatCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
        if(self.arrCatProfileDesc.count!=0 && self.arrCatInt.count!=0){
            if (indexPath.section==0) {
                cell.strCat = [self.arrCatProfileDesc objectAtIndex:indexPath.row];
                cell.strSubcat = [self.arrSubcatProfileDesc objectAtIndex:indexPath.row];
            }
            else{
                cell.strCat = [self.arrCatInt objectAtIndex:indexPath.row];
                cell.strSubcat = [self.arrSubcatInt objectAtIndex:indexPath.row];
            }
        }
        else if(self.arrCatInt.count==0 && self.arrCatProfileDesc.count!=0){
            cell.strCat = [self.arrCatProfileDesc objectAtIndex:indexPath.row];
            cell.strSubcat = [self.arrSubcatProfileDesc objectAtIndex:indexPath.row];
        }
        else if(self.arrCatInt.count!=0 && self.arrCatProfileDesc.count==0){
            cell.strCat = [self.arrCatInt objectAtIndex:indexPath.row];
            cell.strSubcat = [self.arrSubcatInt objectAtIndex:indexPath.row];
        }
        [cell setUI];
        return cell;
    }
    return nil;
}
-(CGSize)getHeightForSection:(NSString *)strText{
    //    NSString *strText = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:NAME]];
    if (strText.length==0) {
        return CGSizeMake(0, 0);
    }
    NSMutableParagraphStyle * paragraphStyle = [[NSMutableParagraphStyle defaultParagraphStyle] mutableCopy];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    CGRect text = [strText boundingRectWithSize:CGSizeMake(self.tblPopupCatSubCat.frame.size.width-10, 1000)
                                        options:NSStringDrawingUsesLineFragmentOrigin
                                     attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14],NSParagraphStyleAttributeName:paragraphStyle}
                                        context:nil];
    strText = nil;
    return text.size;
    
}
-(void)btnUserProfileImageClicked:(NSDictionary *)dic{
    NSLog(@"Profile Image Clicked %@ %@",[dic valueForKey:USER_PHOTO_PATH],dic);
    [self showHideAd:NO];
    
    self.imgViewPopupUserFull.contentMode = UIViewContentModeScaleAspectFit;
    [self.imgViewPopupUserFull setImageURL:[NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]] ];
    
    NSLog(@"%@",NSStringFromCGSize(self.imgViewPopupUserFull.image.size));
    if ((self.imgViewPopupUserFull.image.size.width > self.imgViewPopupUserFull.frame.size.width) || (self.imgViewPopupUserFull.image.size.height > self.imgViewPopupUserFull.frame.size.height)){
        [self.imgViewPopupUserFull setContentMode:UIViewContentModeScaleAspectFit];
    }
    else if ((self.imgViewPopupUserFull.image.size.width < self.imgViewPopupUserFull.frame.size.width) || (self.imgViewPopupUserFull.image.size.height < self.imgViewPopupUserFull.frame.size.height)){
        
        self.imgViewPopupUserFull.contentMode = UIViewContentModeCenter;
        CGSize size = self.imgViewPopupUserFull.image.size;
        
        self.imgViewPopupUserFull.frame = CGRectMake((self.viewUserPopupMain.frame.size.width-size.width)/2, (self.viewUserPopupMain.frame.size.height-size.height)/2, size.width, size.height);
        
    }
    
    
    self.viewUserPopupMain.backgroundColor = [UIColor clearColor];
    self.viewUserPopupMain.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, self.viewUserPopupMain.frame.size.width, self.viewUserPopupMain.frame.size.height);
    
    self.viewUserPopupMain.hidden = NO;
    self.imgViewPopupUserFull.hidden = NO;
    [Validation animateYpoint:0 viewToAnimate:self.viewUserPopupMain];
    self.viewUserPopupSub1.layer.cornerRadius = 5.0;
    self.imgViewPopupUserFull.layer.cornerRadius = 50.0;
    self.viewUserPopupSub1.hidden = YES;
    self.imgViewUserPopupSmall.hidden = YES;
    self.lblPopupName.hidden = YES;
    self.lblPopupAge.hidden = YES;
    self.lblPopupUserName.hidden = YES;
    self.tblPopupCatSubCat.hidden = YES;
    
}
-(void)btnUserDisplayNameTap:(NSDictionary *)dic{
    [self.view setUserInteractionEnabled:NO];
    [self showHideAd:NO];
    [self.activityIndiView startAnimating];
    
    self.viewUserPopupMain.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, self.viewUserPopupMain.frame.size.width, self.viewUserPopupMain.frame.size.height);
    self.viewUserPopupMain.hidden = NO;
    [Validation animateYpoint:0 viewToAnimate:self.viewUserPopupMain];
    self.imgViewPopupUserFull.hidden = YES;
    
    self.viewUserPopupSub1.layer.cornerRadius = 5.0f;
    self.imgViewUserPopupSmall.hidden = NO;
    self.viewUserPopupSub1.hidden = NO;
    [Validation setCorners:self.imgViewUserPopupSmall];
    self.lblPopupName.hidden = NO;
    self.lblPopupAge.hidden = NO;
    self.lblPopupUserName.hidden = NO;
    self.tblPopupCatSubCat.hidden = NO;
    
    self.lblPopupAge.text = @"";
    self.lblPopupUserName.text = @"";
    [self.arrCatInt removeAllObjects];
    [self.arrCatProfileDesc removeAllObjects];
    [self.arrSubcatInt removeAllObjects];
    [self.arrSubcatProfileDesc removeAllObjects];
    [self.tblPopupCatSubCat reloadData];
    
    
    
    //    self.tvPopupInterest.textColor = [UIColor colorWithRed:80/255.0 green:195/255.0 blue:217/255.0 alpha:1];
    //    self.tvPopupProfileDesc.textColor= [UIColor colorWithRed:80/255.0 green:195/255.0 blue:217/255.0 alpha:1];
    //    self.lblInterest.textColor = [UIColor colorWithRed:98/255.0 green:106/255.0 blue:119/255.0 alpha:1];
    
    self.lblPopupName.text = [DataValidation checkNullString:[dic valueForKey:NAME]];
    self.imgViewUserPopupSmall.imageURL = [NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]];
    
    [self.lblPopupName setTextColor:[Validation getColorForAlphabet:self.lblPopupName.text]];
    self.lblPopupName.text = [HASHTAG_CHARACTER stringByAppendingFormat:@"%@",self.lblPopupName.text];
    [self getUserDetail:dic];
}
-(void)btnBlabCreatorName_Clicked:(NSDictionary *)dic{
    [self.tfSearch resignFirstResponder];
    NSLog(@"dic in btnBlabCreatorName_Clicked %@",dic);
    if (self.objUserProfileVC == nil) {
        for (UIView *view in [self.view subviews]) {
            if ([view isKindOfClass:[UIButton class]]) {
                UIButton *btn = (UIButton *)view;
                btn.enabled = NO;
            }
            else if ([view isKindOfClass:[UITableView class]]){
                UITableView *tbl = (UITableView *)view;
                [tbl setUserInteractionEnabled:NO];
            }
        }
        self.objUserProfileVC = [self.storyboard instantiateViewControllerWithIdentifier:@"UserProfileVC"];
        self.objUserProfileVC.delegate = self;
        CGRect frame = self.view.frame;
        frame.origin.y = [UIScreen mainScreen].bounds.size.height;
        self.objUserProfileVC.view.frame = frame;
        self.objUserProfileVC.view.backgroundColor = [UIColor clearColor];
        [self.objUserProfileVC willMoveToParentViewController:self];
        [self.view addSubview:self.objUserProfileVC.view];
        [self addChildViewController:self.objUserProfileVC];
        [self.objUserProfileVC didMoveToParentViewController:self];
        self.objUserProfileVC.dicSelected = dic;
        self.objUserProfileVC.strUserID = [NSString stringWithFormat:@"%@",[dic valueForKey:@"ID"]];
        self.objUserProfileVC.selType = 2;  //  2 means display user data
        [self.objUserProfileVC updateUserInfo];
        [Validation animateYpoint:0 viewToAnimate:self.objUserProfileVC.view];
    }
}
-(void)btnBlabCreatorImage_Clicked:(NSDictionary *)dic{
    [self.tfSearch resignFirstResponder];
    NSLog(@"dic in btnBlabCreatorImage_Clicked %@",dic);
    if (self.objUserProfileVC == nil) {
        for (UIView *view in [self.view subviews]) {
            if ([view isKindOfClass:[UIButton class]]) {
                UIButton *btn = (UIButton *)view;
                btn.enabled = NO;
            }
            else if ([view isKindOfClass:[UITableView class]]){
                UITableView *tbl = (UITableView *)view;
                [tbl setUserInteractionEnabled:NO];
            }
        }
        self.objUserProfileVC = [self.storyboard instantiateViewControllerWithIdentifier:@"UserProfileVC"];
        self.objUserProfileVC.delegate = self;
        CGRect frame = self.view.frame;
        frame.origin.y = [UIScreen mainScreen].bounds.size.height;
        self.objUserProfileVC.view.frame = frame;
        self.objUserProfileVC.view.backgroundColor = [UIColor clearColor];
        [self.objUserProfileVC willMoveToParentViewController:self];
        [self.view addSubview:self.objUserProfileVC.view];
        [self addChildViewController:self.objUserProfileVC];
        [self.objUserProfileVC didMoveToParentViewController:self];
        self.objUserProfileVC.dicSelected = dic;
        self.objUserProfileVC.strUserID = [NSString stringWithFormat:@"%@",[dic valueForKey:@"ID"]];
        self.objUserProfileVC.selType = 1;  //  1 means display user big image
        [self.objUserProfileVC updateUserInfo];
        [Validation animateYpoint:0 viewToAnimate:self.objUserProfileVC.view];
    }
}
-(void)updateUserInfoFromPopup:(NSDictionary *)dic updatedInfo:(NSMutableDictionary *)updatedInfo{
    if ([self.arrData containsObject:dic]) {
        NSLog(@"having object %d",(int)[self.arrData indexOfObject:dic]);
        NSMutableDictionary *dicToChange = [NSMutableDictionary dictionaryWithDictionary:dic];
        [dicToChange setObject:[updatedInfo valueForKey:IS_USER_BLOCKED] forKey:IS_USER_BLOCKED];
        [dicToChange setObject:[updatedInfo valueForKey:IS_FRIEND] forKey:IS_FRIEND];
        [dicToChange setObject:[updatedInfo valueForKey:IS_FRND_REQ_SENT] forKey:IS_FRND_REQ_SENT];
        [dicToChange setObject:[updatedInfo valueForKey:IS_Follow] forKey:IS_Follow];
        [self.arrData replaceObjectAtIndex:[self.arrData indexOfObject:dic] withObject:dicToChange];
        
        [self.tblData beginUpdates];
        [self.tblData reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:[self.arrData indexOfObject:dic] inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
        [self.tblData endUpdates];
//        NSMutableDictionary *dicUpdate = [NSMutableDictionary dictionaryWithDictionary:dic];
//        [dicUpdate setValue:<#(id)#> forKey:<#(NSString *)#>]
    }
    else{
        NSLog(@"not having object");
    }
}
-(void)hideUserProfileVC{
    for (UIView *view in [self.view subviews]) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *btn = (UIButton *)view;
            btn.enabled = YES;
        }
        else if ([view isKindOfClass:[UITableView class]]){
            UITableView *tbl = (UITableView *)view;
            [tbl setUserInteractionEnabled:YES];
        }
    }
    self.objUserProfileVC = nil;
}
-(void)showHideAd:(BOOL)isShow{
    if (isShow) {
        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        [Validation ResizeViewForAds];
    }
    else{
        [Validation removeAdviewFromSuperView];
        [Validation ResizeViewForAds];
    }
}
-(void)tapGestureViewUserPopupMain:(UIGestureRecognizer *)ges{
    //    if (ges.view.tag == 101) {
    //        self.viewUserPopupMain.hidden = YES;
    [Validation animateYpoint:[UIScreen mainScreen].bounds.size.height viewToAnimate:self.viewUserPopupMain];
    [self showHideAd:YES];
    //    }
    
}
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    [self.view endEditing:YES];
    
    //    UITableView *tblRegister = (UITableView*) [self.view viewWithTag:kSignUpTableViewTag];
    //    [tblRegister setContentOffset:CGPointMake(0, 0) animated:YES];
}
#pragma mark
#pragma mark UITextField method
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField==self.tfSearchAtText) {
        [self.tfSearchAtText resignFirstResponder];
        return NO;
    }
    else{
        return YES;
    }
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (textField==self.tfSearchAtText) {
        [self.tfSearchAtText resignFirstResponder];
        return NO;
    }
    else{
        return YES;
    }
}
-(void)textFieldDidBeginEditing:(UITextField *)textField{
	[self.lbl_NoDataAvailable setHidden:YES];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
	if ([DataValidation checkNullString:textField.text].length>0) {
		[self.arrData removeAllObjects];
		[HUD hide:YES];
	//	[Validation showLoadingIndicatorInView:self.tblData];
        [HUD show:YES];
        
		self.pageCounter = 1;
        [Validation setMatTrackingForSearch:self.tfSearch.text];
		[self SearchForText];
	}
	[textField resignFirstResponder];
	return TRUE;
}

#pragma mark
#pragma mark web service method
- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    
    
    
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.lblPopupAge.text = [NSString stringWithFormat:@"%d years old",[[[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"Age"] intValue]];
                            self.lblPopupUserName.text = [[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"UserName"];
                            [self.lblPopupAge setTextColor:[Validation getColorForAlphabet:self.lblPopupUserName.text]];
                            [self.lblPopupUserName setTextColor:[Validation getColorForAlphabet:self.lblPopupUserName.text]];
                            
                            self.lblPopupUserName.text = [[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"UserName"];//[HASHTAG_CHARACTER stringByAppendingFormat:@"%@",[[[arr objectAtIndex:0] valueForKey:@"UserDetail"] valueForKey:@"UserName"]];
                            
                            //                            NSLog(@"arr obj UserDescriptions %@ UserInterests %@",[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"],[[[[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] objectAtIndex:0] valueForKey:@"UserSubInterest"] objectAtIndex:0] valueForKey:@"Name"]);
                            
                            //                            NSString *strInterest = @"";
                            //                            NSString *strProfileDesc = @"";
                            for (int i=0; i<[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] count]; i++) {
                                [self.arrCatInt addObject:[[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] objectAtIndex:i] valueForKey:@"Name"]];
                                NSString *strInterest = @"";
                                for (int j=0; j<[[[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] objectAtIndex:i] valueForKey:@"UserSubInterest"] count]; j++) {
                                    strInterest = [strInterest stringByAppendingFormat:@"%@, ",[[[[[[arr objectAtIndex:0] valueForKey:@"UserInterests"] objectAtIndex:i] valueForKey:@"UserSubInterest"] objectAtIndex:j] valueForKey:@"Name"]];
                                }
                                if (strInterest.length==0) {
                                    [self.arrSubcatInt addObject:@""];
                                }
                                else{
                                    strInterest = [strInterest substringToIndex:strInterest.length-2];
                                    [self.arrSubcatInt addObject:strInterest];
                                }
                            }
                            NSLog(@"final strInterest %@ %@",self.arrCatInt,self.arrSubcatInt);
                            
                            for (int i=0; i<[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] count]; i++) {
                                [self.arrCatProfileDesc addObject:[[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] objectAtIndex:i] valueForKey:@"Name"]];
                                NSString *strProfileDesc = @"";// [strProfileDesc stringByAppendingFormat:@"%@, ",[[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] objectAtIndex:i] valueForKey:@"Name"]];
                                for (int j=0; j<[[[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] objectAtIndex:i] valueForKey:@"UserSubDesc"] count]; j++) {
                                    strProfileDesc = [strProfileDesc stringByAppendingFormat:@"%@, ",[[[[[[arr objectAtIndex:0] valueForKey:@"UserDescriptions"] objectAtIndex:i] valueForKey:@"UserSubDesc"] objectAtIndex:j] valueForKey:@"Name"]];
                                }
                                if (strProfileDesc.length==0) {
                                    [self.arrSubcatProfileDesc addObject:@""];
                                }
                                else{
                                    strProfileDesc = [strProfileDesc substringToIndex:strProfileDesc.length-2];
                                    [self.arrSubcatProfileDesc addObject:strProfileDesc];
                                }
                            }
                            NSLog(@"final strProfileDesc %@ %@",self.arrCatProfileDesc,self.arrSubcatProfileDesc);
                            //                            NSLog(@"final strProfileDesc %d %d",(int)self.arrCatProfileDesc.count,(int)self.arrSubcatProfileDesc.count);
                            [self.tblPopupCatSubCat reloadData];
                            /*
                             if (strInterest.length!=0) {
                             self.lblInterest.hidden=NO;
                             strInterest = [strInterest substringToIndex:strInterest.length-1];
                             }
                             self.tvPopupInterest.text = strInterest;
                             if (strProfileDesc.length!=0) {
                             strProfileDesc = [strProfileDesc substringToIndex:strProfileDesc.length-1];
                             }
                             
                             self.tvPopupProfileDesc.text = strProfileDesc;
                             */
                            [self.view setUserInteractionEnabled:YES];
                            [self.activityIndiView stopAnimating];
                            
                            arr = nil;
                        }
                    }
                }
                
            }
        }
    }
    else{
        [HUD hide:YES];
    }
}
- (void)requestFinished:(ASIHTTPRequest *)request{
	
	NSError *error = nil;
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData] options:0 error:&error];
//	NSLog(@"dictionary = %@",request.responseString);
	
	[HUD hide:YES];
	[Validation removeToastFromMemory];
	if (self.activityLoading != nil) {
		[self.activityLoading removeFromSuperview];
		self.activityLoading = nil;
	}

    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [appDelegate callLogOutService];
        }
        else{
            if (request.tag == 1) {
                if (self.tblData.tag==103) {
                    self.lbl_NoDataAvailable.text = @"No channel available with this search name";
                }
                else{
                    self.lbl_NoDataAvailable.text = @"No user available with this                       search username";
                }
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil && ((NSArray*)response).count > 0) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.isDataNull = NO;
                            if (arr.count < PageSize) {
                                [self.lbl_NoDataAvailable setHidden:YES];
                                self.isDataNull = YES;
                            }
                            if (arr.count>0) {
                                [self.arrData addObjectsFromArray:arr];
                                
                                //	[self.tblData reloadData];
                            }
                            
                            arr = nil;
                        }
                        if (!self.imgViewRecommended.isHidden) {
                            [self.tblData setContentOffset:CGPointMake(0, 0)];
                            self.tblData.tag = 102;
                            self.imgViewRecommended.hidden = YES;
                            self.tblData.frame = CGRectMake(self.tblData.frame.origin.x, self.tblData.frame.origin.y-40, self.tblData.frame.size.width, self.tblData.frame.size.height+40);
                        }
                        if (self.arrData.count == 0 && self.pageCounter==1) {
                            [self.lbl_NoDataAvailable setHidden:NO];
                            [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                        }
                        else{
                            if (((NSArray*)response).count < PageSize) {
                                [self.lbl_NoDataAvailable setHidden:YES];
                                self.isDataNull = YES;
                            }
                        }
                    }
                }
                else{
                    if (self.arrData.count == 0 && self.pageCounter==1) {
                        [self.lbl_NoDataAvailable setHidden:NO];
                        self.isDataNull = YES;
                        [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                    }
                }
                [self.tblData reloadData];
                [HUD hide:YES];
            }
            else if (request.tag == 2){
                //req sent
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    NSLog(@"dic = %@",[dicResponse valueForKey:STATUS]);
//                    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:self.selectedIndex]];
//                    [dic setValue:@"1" forKey:IS_FRND_REQ_SENT];
//                    [self.arrData replaceObjectAtIndex:self.selectedIndex withObject:dic];
//                    [Validation showToastMessage:@"Request Sent" displayDuration:SUCCESS_MSG_DURATION];
//                    [self.tblData reloadData];
//                    dic = nil;
                }
            }
            else if (request.tag == 3 || request.tag == 4){
                //req accept reject
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    NSLog(@"dic = %@",[dicResponse valueForKey:STATUS]);
//                    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:self.selectedIndex]];
//                    if (request.tag == 3) {
//                        //accepted so isFriend = true
//                        [dic setValue:@"1" forKey:IS_FRIEND];
//                    }
//                    else{
//                        [dic setValue:@"0" forKey:IS_FRND_REQ_REC];
//                    }
//                    [self.arrData replaceObjectAtIndex:self.selectedIndex withObject:dic];
//                    
//                    dic = nil;
//                    
//                    [self.tblData reloadData];
                }
            }
            else if (request.tag == 5){
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil && ((NSArray*)response).count > 0) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.isDataNull = NO;
                            if (arr.count < PageSize) {
                                [self.lbl_NoDataAvailable setHidden:YES];
                                self.isDataNull = YES;
                            }
                            if (arr.count>0) {
                                [self.arrData addObjectsFromArray:arr];
                                //	[self.tblData reloadData];
                            }
                            arr = nil;
                        }
                        if (self.arrData.count == 0 && self.pageCounter==1) {
                            [self.lbl_NoDataAvailable setHidden:NO];
                            [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                        }
                        else{
                            if (((NSArray*)response).count < PageSize) {
                                [self.lbl_NoDataAvailable setHidden:YES];
                                self.isDataNull = YES;
                            }
                        }
                    }
                }
                else{
                    if (self.arrData.count == 0 && self.pageCounter==1) {
                        [self.lbl_NoDataAvailable setHidden:NO];
                        self.isDataNull = YES;
                        [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                    }
                }
                [self.lbl_NoDataAvailable setHidden:YES];
                [self.tblData reloadData];
                [HUD hide:YES];
            }
        }
    }
    else{
        [HUD hide:YES];
    }
	
	self.request = nil;
	[Validation ResizeViewForAds];
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}
#pragma mark UITouch Methods

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [[event allTouches] anyObject];
    if (![touch.view isKindOfClass:[UITextField class]]) {
        [self.tfSearch resignFirstResponder];
    }
}
-(void)btnPlayFileClicked:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    
    //self.selectedPlayIndex = (int)btn.tag;
    if (self.isPlaying) {
        //        self.isStoppedForceFully = TRUE;
        self.isPlaying = NO;
        //        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:currentlyPlaingIndex inSection:0];
        //        UserCell *cell = (UserCell *)[self.tblData cellForRowAtIndexPath:indexPath];
        //        appDelegate.imgPlayAnimation = cell.btnPlayPause.imageView;
        [appDelegate ClosePopUpWithoutUIFromFrienRequest];
        [self removeAnimationFromSuperView];
        //        [btn setImage:[UIImage imageNamed:@"icn_play.png"] forState:UIControlStateNormal];
        //        self.isPlayAll = FALSE;
    }
    else{
        btn.imageView.image = nil;
        [self playSelectedFileAtIndex:(int)btn.tag];
    }
}
-(void)removeAnimationFromSuperView{
    //    [imgViewPlayAni removeFromSuperview];
    self.isPlaying = NO;
    //    [imgViewPlayAni stopAnimating];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:currentlyPlaingIndex inSection:0];
    UserCell *cell = (UserCell *)[self.tblData cellForRowAtIndexPath:indexPath];
    [cell.btnPlayPause.imageView stopAnimating];
    cell.btnPlayPause.imageView.image=[UIImage imageNamed:@"icn_play.png"];
    //    [imgViewPlayAni setHidden:YES];
}
-(void)playSelectedFileAtIndex:(int)index{
    int section = 1;
    if (self.isDataNull) {
        section = 0;
    }
    self.isPlaying = YES;
    currentlyPlaingIndex = index;
    NSMutableDictionary *dic;
//    if (self.tblData.tag==101) {
        dic = [self.arrData objectAtIndex:index];
/*    }
    else{
        dic = [self.arrSentRequest objectAtIndex:index];
    }
*/    //    self.selectedPlayID = [[NSString stringWithFormat:@"%@",[dic valueForKey:MESSAGE_CHAT_ID]] intValue];
    
    
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
    if ([self.tblData.indexPathsForVisibleRows containsObject:indexPath]) {
        UserCell *cell = (UserCell *)[self.tblData cellForRowAtIndexPath:indexPath];
        
        //        cell.imgPlayAnimation.hidden = NO;
        //        [cell.contentView bringSubviewToFront:cell.imgPlayAnimation];
        [self setImageViewInview:cell.btnPlayPause];
        
    }
    [appDelegate playSoundWithoutUIForURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:@"FilePath"]]]];
    
}
-(void)setImageViewInview:(id)viewToPlayAnimationIn{
    
    
    if ([viewToPlayAnimationIn isKindOfClass:[UIImageView class]]) {
        
        UIImageView *img = (UIImageView *)viewToPlayAnimationIn;
        [self initializeAnimationArray:img];
        [img startAnimating];
    }
    if ([viewToPlayAnimationIn isKindOfClass:[UIButton class]]) {
        
        UIButton *btn = (UIButton *)viewToPlayAnimationIn;
        //        appDelegate.imgPlayAnimation = btn.imageView;
        [self initializeAnimationArray:btn.imageView];
        [btn.imageView startAnimating];
    }
}
-(void)initializeAnimationArray:(UIImageView*)imgViewPlayAni{
    
    NSMutableArray *arrAnimation = [[NSMutableArray alloc] init];
    for (int i = 1 ; i<=28; i++) {
        [arrAnimation addObject:[UIImage imageNamed:[NSString stringWithFormat:@"player_loader_%d.png",i]]];
    }
    
    imgViewPlayAni.animationImages = arrAnimation;
    imgViewPlayAni.animationRepeatCount = 0;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
