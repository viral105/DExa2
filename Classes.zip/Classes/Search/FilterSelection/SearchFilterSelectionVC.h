//
//  SearchFilterSelectionVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 11/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "V8HorizontalPickerView.h"
#import "ProfileDescForSearchVC.h"
#import "Slider/ui/range-slider/FCYRangeSlider.h"

@class V8HorizontalPickerView;

@interface SearchFilterSelectionVC : UIViewController <UITableViewDataSource, UITableViewDelegate,V8HorizontalPickerViewDelegate, V8HorizontalPickerViewDataSource,UITextFieldDelegate,ProfileDescForSearchVCDelegate>

@property (nonatomic, strong) IBOutlet UITableView  *tblData;
@property (nonatomic, strong) IBOutlet UILabel      *lblTitle;
@property (nonatomic, strong) NSMutableDictionary   *dicFilter;

@property (nonatomic, strong) NSMutableArray        *arrAge;
@property (nonatomic, strong) V8HorizontalPickerView          *pkrAge;

@property (nonatomic, strong) UIButton              *btnMale;
@property (nonatomic, strong) UIButton              *btnFeMale;
@property (nonatomic, strong) UIButton              *btnDoNotDisclose;          //currently working as all
//@property (nonatomic, strong) UIButton              *btnDoneWithKeyboard;
@property (nonatomic, strong) UITextField           *tfMiles;

@property (nonatomic, readwrite) int                selectedGender;
@property (nonatomic, readwrite)CGRect              tblRect;
@property (nonatomic, readwrite) BOOL               isKeyBoardHide;

@property (nonatomic, strong) NSString              *strSelectedInterests;
@property (nonatomic, strong) NSString              *strSelectedProfileDesc;

@property (nonatomic, strong) UIFont                *font;

@property (nonatomic) FCYRangeSlider                *slider;
@property (nonatomic, strong) UILabel               *lblMinAge;
@property (nonatomic, strong) UILabel               *lblMaxAge;

@property (nonatomic, readwrite) BOOL               isLoationServiceOn;
@end
