//
//  SearchFilterSelectionVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 11/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "SearchFilterSelectionVC.h"
#import "MBProgressHUD.h"
#import "QBFlatButton.h"
#import "FilterCell/FilterCell.h"
#import "InterestListForSearchVC.h"
#import "UserListingByInterestVC.h"
#import "ProfileDescForSearchVC.h"

#define SELECTED_INTEREST_ID        @"selectedInterestIds"
#define SELECTED_SUB_INTEREST_ID    @"selectedSubInterestIds"
#define SELECTED_INTEREST_NAME      @"selectedInterestName"
#define SELECTED_PROFILEDESC_NAME   @"selectedProfileDescName"
#define SELECT_INTEREST             @"Select Interest"
#define SELECT_PROFILE_DESC         @"Select Profile Description"
#define SEARCH_AGE_FROM             @"ageFrom"
#define SEARCH_AGE_TO               @"ageTo"
#define SEARCH_GENDER               @"gender"
#define SEARCH_GEO_RADIOUS          @"geo_radious"
#define SEARCH_INTEREST             @"interest"
#define SEARCH_PROFILE_DESC         @"profiledesc"
#define SEARCH_SUB_INTEREST         @"sub_interest"
#define SEARCH_SUB_PROFILEDESC      @"sub_profiledesc"
#define is_GeoLocation              @"is_geoLocation"


@interface SearchFilterSelectionVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}


@end

@implementation SearchFilterSelectionVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
//	[self.navigationController.view addSubview:HUD];
	
    self.dicFilter = [[NSMutableDictionary alloc] init];
    self.arrAge = [[NSMutableArray alloc] init];
    self.isLoationServiceOn = YES;

    [self LoadViewSetting];
    appDelegate.currentVc = self;
    [Validation getCurrentLocation];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
	
    appDelegate.currentVc = self;
    
    [self.pkrAge scrollToElement:5 animated:NO];
    [ [NSNotificationCenter defaultCenter] addObserver: self selector: @selector(keyboardWillShow:)
                                                  name: UIKeyboardWillShowNotification object: nil];
    [ [NSNotificationCenter defaultCenter] addObserver: self selector: @selector(keyboardWillHide:)
                                                  name: UIKeyboardWillHideNotification object: nil];
    self.isKeyBoardHide = YES;
}

- (void) viewWillDisappear: (BOOL) animated {
    [super viewWillDisappear: animated];
    
    [ [NSNotificationCenter defaultCenter] removeObserver: self name: UIKeyboardDidShowNotification object: nil];
    [ [NSNotificationCenter defaultCenter] removeObserver: self name: UIKeyboardWillHideNotification object: nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark CUSTOM Methods

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
	self.tblRect = self.tblData.frame;
    
    self.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
    
	self.lblTitle.font = self.font;
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    //range selector
    
    
    self.lblMinAge = [[UILabel alloc] initWithFrame:CGRectMake(10, 8, 35, 20)];
    self.lblMaxAge = [[UILabel alloc] initWithFrame:CGRectMake(DEVICE_WIDTH-40, 8, 35, 20)];
    
    self.lblMinAge.backgroundColor = [UIColor clearColor];
    self.lblMaxAge.backgroundColor = [UIColor clearColor];
    
    self.lblMinAge.font = [UIFont fontWithName:Font_Montserrat_Regular size:13];
    self.lblMaxAge.font = [UIFont fontWithName:Font_Montserrat_Regular size:13];
    
    self.lblMinAge.text = @"18";
    self.lblMaxAge.text = @"100";
    
    self.lblMinAge.textAlignment = NSTextAlignmentCenter;
    self.lblMaxAge.textAlignment = NSTextAlignmentCenter;
    
    self.slider = [[FCYRangeSlider alloc] initWithFrame:CGRectMake(10, 25, DEVICE_WIDTH-20, 25)];
    self.slider.rangeValue = FCYRangeSliderValueMake(3, 6);

    [self.slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    //============= gender
    
    self.selectedGender = -1;
    
    self.btnMale = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.btnMale setTitle:GenderMale forState:UIControlStateNormal];
    [self.btnMale.titleLabel setFont:self.font];
    [self.btnMale setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    self.btnMale.tag = 1;
    
    
    self.btnFeMale = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.btnFeMale setTitle:GenderFemale forState:UIControlStateNormal];
    [self.btnFeMale.titleLabel setFont:self.font];
    [self.btnFeMale setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    self.btnFeMale.tag = 2;
    
    self.btnDoNotDisclose = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.btnDoNotDisclose setTitle:GenderDoesNotMatter forState:UIControlStateNormal];
    [self.btnDoNotDisclose.titleLabel setFont:self.font];
    [self.btnDoNotDisclose setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    self.btnDoNotDisclose.tag = 3;
    
    [self.btnMale addTarget:self action:@selector(GenderSelected:) forControlEvents:UIControlEventTouchUpInside];
    [self.btnFeMale addTarget:self action:@selector(GenderSelected:) forControlEvents:UIControlEventTouchUpInside];
    [self.btnDoNotDisclose addTarget:self action:@selector(GenderSelected:) forControlEvents:UIControlEventTouchUpInside];
    
    float xStart = 10;
    float yStart = 7;
    float height = 50;
    
    self.btnMale.frame = CGRectMake(xStart, yStart, 73, height);    xStart += 78;
    self.btnFeMale.frame = CGRectMake(xStart, yStart, 73, height);  xStart += 78;
    self.btnDoNotDisclose.frame = CGRectMake(xStart, yStart, 140, height);
    
    self.btnMale.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.btnFeMale.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.btnDoNotDisclose.titleLabel.textAlignment = NSTextAlignmentCenter;
    
    self.btnMale.backgroundColor = [UIColor clearColor];
    self.btnFeMale.backgroundColor = [UIColor clearColor];
    self.btnDoNotDisclose.backgroundColor = [UIColor clearColor];
    
    self.selectedGender = -1;
    [self.btnDoNotDisclose setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    
    //================= Geo Location in MILES
    
    self.tfMiles = [[UITextField alloc] initWithFrame:CGRectMake(10, 7, 300, 50)];
    self.tfMiles.placeholder = @"e.g 50";
    [self.tfMiles setValue:UIColorFromRGB(0X8a8a8a)	forKeyPath:@"_placeholderLabel.textColor"];
    [self.tfMiles setFont:self.font];
	[self.tfMiles setTextColor:TWITTER_BLUE_COLOR];
    self.tfMiles.delegate = self;
    self.tfMiles.keyboardType = UIKeyboardTypeNumberPad;
    self.tfMiles.textAlignment = NSTextAlignmentCenter;
}

-(void)resetBtnColor{
    [self.btnMale setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnFeMale setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnDoNotDisclose setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
}

-(void)GenderSelected:(id)sender{
    [self resetBtnColor];
    UIButton *btn = (UIButton *)sender;
    if ((int)btn.tag == 3) {
        self.selectedGender = -1;
    }
    else{
        self.selectedGender = (int)btn.tag;
    }
    [btn setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
//    if (self.selectedGender != (int)btn.tag) {
//        if ((int)btn.tag == 3) {
//            self.selectedGender = -1;
//        }
//        else{
//            self.selectedGender = (int)btn.tag;
//        }
//        [btn setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
//    }
//    else{
//        self.selectedGender = -1;
//    }
}

- (IBAction)sliderValueChanged:(FCYRangeSlider *)sender {
    self.lblMinAge.text = [NSString stringWithFormat:@"%d", (int)sender.rangeValue.start];
    self.lblMinAge.center = CGPointMake(self.slider.StartThumb_X_Position.x+8, self.slider.StartThumb_X_Position.y);
    
    self.lblMaxAge.text = [NSString stringWithFormat:@"%d", (int)sender.rangeValue.end];
    self.lblMaxAge.center = CGPointMake(self.slider.EndThumb_X_Position.x+7, self.slider.EndThumb_X_Position.y);
}

-(IBAction)btnBackClicked:(id)sender{

    CATransition* transition = [CATransition animation];
    transition.duration = 0.3;
    transition.type = kCATransitionFade;
    transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnApplyClicked:(id)sender{
    [self.dicFilter setValue:self.lblMinAge.text forKey:SEARCH_AGE_FROM];
    [self.dicFilter setValue:self.lblMaxAge.text forKey:SEARCH_AGE_TO];
    
    if (self.selectedGender != 0) {
         [self.dicFilter setValue:[NSString stringWithFormat:@"%d",self.selectedGender] forKey:SEARCH_GENDER];
    }
    if ([DataValidation checkNullString:self.tfMiles.text].length > 0) {
        [self.dicFilter setValue:self.tfMiles.text forKey:SEARCH_GEO_RADIOUS];
        [self.dicFilter setValue:@"1" forKey:is_GeoLocation];
    }
    else{
        [self.dicFilter setValue:@"0" forKey:SEARCH_GEO_RADIOUS];
        [self.dicFilter setValue:@"0" forKey:is_GeoLocation];
    }
    
    [self performSegueWithIdentifier:USER_LIST_BY_INTEREST sender:NULL];
    NSLog(@"%@",self.dicFilter);
}

#pragma mark UITableViewDataSource UITableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 5;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 40;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [[UIView alloc] initWithFrame:CGRectZero];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 30)];
    [lblTitle setFont:self.font];
    [lblTitle setTextAlignment:NSTextAlignmentCenter];
    [lblTitle setTextColor:UIColorFromRGB(0X616161)];
    lblTitle.backgroundColor = UIColorFromRGB(0Xefefef);//[UIColor clearColor];
    switch (section) {
        case 0:
            lblTitle.text = @"Age";
            break;
        case 1:
            lblTitle.text = @"Gender";
            break;
        case 2:
            lblTitle.text = @"Geo-Location(Miles)";
            break;
        case 3:
            lblTitle.text = @"Interest";
            break;
        case 4:
            lblTitle.text = @"Profile Description";
            break;
        default:
            break;
    }
    return lblTitle;
}

-(int)getHeightForRow:(int)index{
    
    CGSize size = CGSizeMake(self.tblData.frame.size.width-20, 2000);
    CGRect textRectDate;
    
    if (index == 3) {
        //interest
        NSString *strValue = [self.dicFilter valueForKey:SELECTED_INTEREST_NAME];
        if ([DataValidation checkNullString:strValue].length == 0) {
            textRectDate = CGRectMake(10, 0, self.tblData.frame.size.width-20, 56);
        }
        else{
            textRectDate = [strValue boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:self.font} context:nil];
            if (textRectDate.size.height<56) {
                textRectDate = CGRectMake(10, 0, textRectDate.size.width-20, 56);
            }
        }
    }
    else{
        textRectDate = CGRectMake(10, 0, self.tblData.frame.size.width-20, 56);
    }
    
	size = textRectDate.size;
    return size.height;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    int height = [self getHeightForRow:(int)indexPath.section];
    
    [self.dicFilter setValue:[NSNumber numberWithInt:height] forKey:[NSString stringWithFormat:@"Height%d",(int)indexPath.section]];
    
    return height;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *CellIdentifier = [NSString stringWithFormat:@"%d",(int)indexPath.section];
    
//    FilterCell *cell = (FilterCell *)[tableView dequeueReusableCellWithIdentifier:@"CellIdentifier"];
    FilterCell *cell = (FilterCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[FilterCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.backgroundColor = [UIColor clearColor];
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
	[cell SetBackGroundImageHieght:[[self.dicFilter valueForKey:[NSString stringWithFormat:@"Height%d",(int)indexPath.section]] intValue]];
    
    switch (indexPath.section) {
        case 0:{
//            [self.pkrAge removeFromSuperview];
//            
//            [cell.contentView bringSubviewToFront:self.pkrAge];
//            [cell.contentView addSubview:self.pkrAge];
            
            [self.lblMinAge removeFromSuperview];
            [self.lblMaxAge removeFromSuperview];
            
            [cell.contentView addSubview:self.lblMinAge];
            [cell.contentView addSubview:self.lblMaxAge];
            
            [self.slider removeFromSuperview];
            self.slider.acceptOnlyPositiveRanges = YES;
            [cell.contentView addSubview:self.slider];
        }
            break;
        case 1:{
            [self.btnMale removeFromSuperview];
            [self.btnFeMale removeFromSuperview];
            [self.btnDoNotDisclose removeFromSuperview];

            [cell.contentView addSubview:self.btnMale];
            [cell.contentView addSubview:self.btnFeMale];
            [cell.contentView addSubview:self.btnDoNotDisclose];
        }
            break;
        case 2:{
            [self.tfMiles removeFromSuperview];
            [cell.contentView addSubview:self.tfMiles];
        }
            break;
        case 3:{
            if (self.strSelectedInterests.length ==0) {
                [cell.btnBg setTitle:SELECT_INTEREST forState:UIControlStateNormal];
                [cell.btnBg setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
            }
            else{
                [cell.btnBg setTitle:self.strSelectedInterests forState:UIControlStateNormal];
            }
            cell.btnBg.titleLabel.numberOfLines = 0;
            [cell.btnBg removeTarget:self action:@selector(btnInterestClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnBg addTarget:self action:@selector(btnInterestClicked:) forControlEvents:UIControlEventTouchUpInside];
        }
            break;
        case 4:{
            if (self.strSelectedProfileDesc.length ==0) {
                [cell.btnBg setTitle:SELECT_PROFILE_DESC forState:UIControlStateNormal];
                [cell.btnBg setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
            }
            else{
                [cell.btnBg setTitle:self.strSelectedProfileDesc forState:UIControlStateNormal];
            }
            cell.btnBg.titleLabel.numberOfLines = 0;
            [cell.btnBg removeTarget:self action:@selector(btnProfileDescClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnBg addTarget:self action:@selector(btnProfileDescClicked:) forControlEvents:UIControlEventTouchUpInside];
        }
            break;
        default:
            break;
    }
    return cell;
}

-(void)btnInterestClicked:(id)sender{
    
//    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    InterestListForSearchVC *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:INTRESTLIST_FOR_SEARCH_VC];
    ivc.delegate = self;
    [self presentViewController:ivc animated:YES completion:nil];
}
-(void)btnProfileDescClicked:(id)sender{
    
    //    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ProfileDescForSearchVC *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:PROFILE_DESCFOR_SEARCHVC];
    ivc.delegate = self;
    [self presentViewController:ivc animated:YES completion:nil];
}
- (void)setSelectedInterests:(NSArray *)interests AndSubInterest:(NSArray *)subInterests{
    
    self.strSelectedInterests = @"";
    NSArray *arr = [interests valueForKey:IS_ADDED_TO_MY_INTEREST];
    NSString *strSelectedIds = @"";
    NSString *strSelectedSubInterest = @"";
    
    for (int i= 0; i<(int)arr.count; i++) {
        
        if ([[NSString stringWithFormat:@"%@",[arr objectAtIndex:i]] isEqualToString:@"1"]) {
            
            NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[interests objectAtIndex:i]];
            
            if (strSelectedIds.length == 0) {
                strSelectedIds = [NSString stringWithFormat:@"%@",[dic valueForKey:@"ID"]];
                self.strSelectedInterests = [NSString stringWithFormat:@"%@",[dic valueForKey:NAME]];
            }
            else{
                strSelectedIds = [strSelectedIds stringByAppendingFormat:@"|%@",[dic valueForKey:@"ID"]];
                self.strSelectedInterests = [self.strSelectedInterests stringByAppendingFormat:@", %@",[dic valueForKey:NAME]];
            }
            
            if ([[dic valueForKey:@"UserSubInterest"] count] > 0) {
                NSArray *arrSub = [dic valueForKey:@"UserSubInterest"];
                
                for (int y= 0; y<(int)arrSub.count; y++) {
                    NSDictionary *dic1 = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[arrSub objectAtIndex:y]];
                    if ([[NSString stringWithFormat:@"%@",[dic1 valueForKey:IS_ADDED_TO_MY_INTEREST]] isEqualToString:@"1"]) {
                        if (strSelectedSubInterest.length == 0) {
                            strSelectedSubInterest = [NSString stringWithFormat:@"%@",[[arrSub objectAtIndex:y] valueForKey:@"ID"]];
                        }
                        else{
                            strSelectedSubInterest = [strSelectedSubInterest stringByAppendingFormat:@"|%@",[[arrSub objectAtIndex:y] valueForKey:@"ID"]];
                        }
                    }
                }
            }
        }
    }
    if (strSelectedIds.length == 0) {
      //  [Validation showToastMessage:@"Please select your interest." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        [self.dicFilter setValue:strSelectedIds forKey:SEARCH_INTEREST];
        if (strSelectedSubInterest.length != 0) {
            [self.dicFilter setValue:strSelectedSubInterest forKey:SEARCH_SUB_INTEREST];
        }
    }
  
    [self.dicFilter setValue:self.strSelectedInterests forKey:SELECTED_INTEREST_NAME];
    [self.tblData reloadData];
}
- (void)setSelectedProfileDesc:(NSArray *)interests AndSubInterest:(NSArray *)subInterests{
    
    self.strSelectedProfileDesc = @"";
    NSArray *arr = [interests valueForKey:IS_ADDED_TO_MY_INTEREST];
    NSString *strSelectedIds = @"";
    NSString *strSelectedSubInterest = @"";
    
    for (int i= 0; i<(int)arr.count; i++) {
        
        if ([[NSString stringWithFormat:@"%@",[arr objectAtIndex:i]] isEqualToString:@"1"]) {
            
            NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[interests objectAtIndex:i]];
            
            if (strSelectedIds.length == 0) {
                strSelectedIds = [NSString stringWithFormat:@"%@",[dic valueForKey:@"ID"]];
                self.strSelectedProfileDesc = [NSString stringWithFormat:@"%@",[dic valueForKey:NAME]];
            }
            else{
                strSelectedIds = [strSelectedIds stringByAppendingFormat:@"|%@",[dic valueForKey:@"ID"]];
                self.strSelectedProfileDesc = [self.strSelectedProfileDesc stringByAppendingFormat:@", %@",[dic valueForKey:NAME]];
            }
            
            if ([[dic valueForKey:@"UserSubDesc"] count] > 0) {
                NSArray *arrSub = [dic valueForKey:@"UserSubDesc"];
                
                for (int y= 0; y<(int)arrSub.count; y++) {
                    NSDictionary *dic1 = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[arrSub objectAtIndex:y]];
                    if ([[NSString stringWithFormat:@"%@",[dic1 valueForKey:IS_ADDED_TO_MY_INTEREST]] isEqualToString:@"1"]) {
                        if (strSelectedSubInterest.length == 0) {
                            strSelectedSubInterest = [NSString stringWithFormat:@"%@",[[arrSub objectAtIndex:y] valueForKey:@"ID"]];
                        }
                        else{
                            strSelectedSubInterest = [strSelectedSubInterest stringByAppendingFormat:@"|%@",[[arrSub objectAtIndex:y] valueForKey:@"ID"]];
                        }
                    }
                }
            }
        }
    }
    if (strSelectedIds.length == 0) {
        //  [Validation showToastMessage:@"Please select your interest." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        [self.dicFilter setValue:strSelectedIds forKey:SEARCH_PROFILE_DESC];
        if (strSelectedSubInterest.length != 0) {
            [self.dicFilter setValue:strSelectedSubInterest forKey:SEARCH_SUB_PROFILEDESC];
        }
    }
    
    [self.dicFilter setValue:self.strSelectedProfileDesc forKey:SELECTED_PROFILEDESC_NAME];
    [self.tblData reloadData];
}

#pragma mark -
#pragma mark UITextField Methods

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == self.tfMiles) {
        if (!self.isLoationServiceOn) {
            UIAlertView *errorAlert = [[UIAlertView alloc]
                                       initWithTitle:MESSAGE message:@"You might not have enable your location service for Blabeey.\nPlease go to Settings -> Privacy -> Location Services -> Blabeey and enable your location services." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [errorAlert show];
        }
    }
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    if (textField == self.tfMiles) {
        if (!self.isLoationServiceOn) {
            UIAlertView *errorAlert = [[UIAlertView alloc]
                                       initWithTitle:MESSAGE message:@"You might not have enable your location service for Blabeey.\nPlease go to Settings -> Privacy -> Location Services -> Blabeey and enable your location services." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [errorAlert show];
            return FALSE;
        }
    }
    if ([string isEqualToString:@""]) {
        return TRUE;
    }
    else if (textField.text.length >=5) {
        return FALSE;
    }
    
    return TRUE;
}

- (void) keyboardWillShow: (NSNotification *) notification {
    
    if (self.isKeyBoardHide) {
        CGRect keyboardFrame = [ [ [notification userInfo] objectForKey: UIKeyboardFrameBeginUserInfoKey] CGRectValue];
        
        self.tblData.contentOffset = CGPointMake(self.tblData.contentOffset.x, self.tblData.contentOffset.y+20);
        self.tblData.frame = CGRectMake(self.tblData.frame.origin.x, self.tblData.frame.origin.y, self.tblData.frame.size.width,
                                        self.view.frame.size.height - self.tblData.frame.origin.y - keyboardFrame.size.height-50);
        
        
        UIView *viewToolBar = [[UIView alloc] initWithFrame:CGRectMake(0, DEVICE_HEIGHT-keyboardFrame.size.height-50, DEVICE_WIDTH, 50)];
        viewToolBar.backgroundColor = [UIColor colorWithRed:247/255.0 green:247/255.0 blue:247/255.0 alpha:1];
        viewToolBar.alpha = 1;
        viewToolBar.tag = 1112;
        [self.view addSubview:viewToolBar];
        
        UIView *viewBorder = [[UIView alloc] initWithFrame:CGRectMake(0, 0, viewToolBar.frame.size.width, 0.5)];
        [viewBorder setBackgroundColor:[UIColor lightGrayColor]];
        [viewToolBar addSubview:viewBorder];
        
        UIButton *btnDoneWithKeyboard = [UIButton buttonWithType:UIButtonTypeCustom];
        btnDoneWithKeyboard.frame = CGRectMake(260,0 ,50, 50);
        btnDoneWithKeyboard.tag = 1113;
        [btnDoneWithKeyboard setTitleColor:[UIColor colorWithRed:0 green:0.478431 blue:1.0 alpha:1.0] forState:UIControlStateNormal];
        [btnDoneWithKeyboard addTarget:self action:@selector(geoLocationDoneBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [btnDoneWithKeyboard setTitle:@"Done" forState:UIControlStateNormal];
        [viewToolBar addSubview:btnDoneWithKeyboard];
        self.isKeyBoardHide = NO;
    }
}

- (void) keyboardWillHide: (NSNotification *) notification {
    self.tblData.frame = self.tblRect;
    UIView *viewToolBr = (UIView *)[self.view viewWithTag:1112];
    UIButton *btnDoneWithKeyboard = (UIButton *)[viewToolBr viewWithTag:1113];
    [btnDoneWithKeyboard removeFromSuperview];
    btnDoneWithKeyboard = nil;
    
    [viewToolBr removeFromSuperview];
    viewToolBr = nil;
    
    self.isKeyBoardHide = YES;
}
-(void)geoLocationDoneBtnClicked:(id)sender{
    [self.tfMiles resignFirstResponder];
}

#pragma mark -
#pragma mark Picker View Methods

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)thePickerView {
    
    return 1;
}

- (NSInteger)numberOfElementsInHorizontalPickerView:(V8HorizontalPickerView *)picker {
	return [self.arrAge count];
}
- (NSInteger) horizontalPickerView:(V8HorizontalPickerView *)picker widthForElementAtIndex:(NSInteger)index {
	NSString *text = [self.arrAge objectAtIndex:index];
    CGRect textRectDate = [text boundingRectWithSize:CGSizeMake(MAXFLOAT, MAXFLOAT)  options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:self.font}  context:nil];

	return textRectDate.size.width + 40.0f; // 20px padding on each side
}


- (NSString *)horizontalPickerView:(V8HorizontalPickerView *)picker titleForElementAtIndex:(NSInteger)index {
	return [self.arrAge objectAtIndex:index];
}

- (void)horizontalPickerView:(V8HorizontalPickerView *)picker didSelectElementAtIndex:(NSInteger)index {
    
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    if ([segue.identifier isEqualToString:USER_LIST_BY_INTEREST]) {
        UserListingByInterestVC *obj = segue.destinationViewController;
        obj.dicFilterData = self.dicFilter;
        
    }
}


@end
