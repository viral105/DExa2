//
//  FilterCell.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 11/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QBFlatButton.h"

@interface FilterCell : UITableViewCell

@property (nonatomic, strong) IBOutlet QBFlatButton     *btnBg;

-(void)SetBackGroundImageHieght:(int)height;
@end
