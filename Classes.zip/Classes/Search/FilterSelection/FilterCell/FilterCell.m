//
//  FilterCell.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 11/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "FilterCell.h"

@implementation FilterCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.btnBg = [[QBFlatButton alloc] initWithFrame:CGRectMake(10, 5, 300, 56)];
        [self.contentView addSubview:self.btnBg];
        
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)SetBackGroundImageHieght:(int)height{
    self.btnBg.frame = CGRectMake(10, 5, 300, height);
    self.btnBg.surfaceColor = UIColorFromRGB(0Xffffff);
    self.btnBg.sideColor = UIColorFromRGB(0Xdcdcdc);
    self.btnBg.cornerRadius = 5.0;
    self.btnBg.height = 3.0;
    self.btnBg.depth = 4.0;

    [self.btnBg setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    [self.btnBg.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:17]];
    [self.btnBg.titleLabel setTextAlignment:NSTextAlignmentCenter];
    [self.btnBg setTitle:@"" forState:UIControlStateNormal];
}

@end
