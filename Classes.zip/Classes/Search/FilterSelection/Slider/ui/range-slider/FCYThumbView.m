
#import "FCYThumbView.h"
#import "FCYGeometry.h"

#define THUMB_WIDTH 24.0f
#define THUMB_HEIGHT 24.0f
#define UIColorFromRGB(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

@implementation FCYThumbView {
    UIImageView *_imageView;
}

@synthesize highlighted = _highlighted;

+ (CGSize)size {
    return CGSizeMake(THUMB_WIDTH, THUMB_WIDTH);
}

- (id)init {
    self = [self initWithFrame:CGRectMake(0, 0, THUMB_WIDTH, THUMB_HEIGHT)];
    return self;
}


- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:FCYCGRectSetSize(frame, [FCYThumbView size])];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = NO;
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    if (!_imageView) {
        [self drawDefaultThumb];
    }
}

- (void)setFrame:(CGRect)newFrame {
    [super setFrame:FCYCGRectSetSize(newFrame, [FCYThumbView size])];
}

- (UIImage *)image {
    return [_imageView image];
}

- (void)setImage:(UIImage *)image {
    if (image && image != [self image]) {
        [[self imageView] setImage:image];
    }
}

- (void)setHighlighted:(BOOL)highlighted {
    _highlighted = highlighted;
    if (_imageView) {
        _imageView.highlighted = highlighted;
    }
    [self setNeedsDisplay];
}

- (UIImage *)highlightedImage {
    return [_imageView highlightedImage];
}

- (void)setHighlightedImage:(UIImage *)highlightedImage {
    if (highlightedImage && highlightedImage != [self highlightedImage]) {
        [[self imageView] setHighlightedImage:highlightedImage];
    }
}

#pragma mark -
#pragma mark Private Methods

- (UIImageView *)imageView {
    if (!_imageView) {
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, THUMB_WIDTH, THUMB_HEIGHT)];
        _imageView.contentMode = UIViewContentModeCenter;
        _imageView.highlighted = _highlighted;
        [self addSubview:_imageView];
        [self setNeedsDisplay];
    }
    return _imageView;
}

- (void)drawDefaultThumb {
    //// General Declarations
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = UIGraphicsGetCurrentContext();

    //// Color Declarations
//    UIColor* innerStrokeColor = [UIColor colorWithRed: 0.93 green: 0.93 blue: 0.93 alpha: 1];

    //// Gradient Declarations
//    NSArray* insideGradientColors = [NSArray arrayWithObjects:
//        (__bridge id)UIColorFromRGB(0X616161).CGColor,
//        (__bridge id)[UIColor colorWithRed: 0.8 green: 0.8 blue: 0.8 alpha: 1].CGColor,
//        (__bridge id)[UIColor redColor].CGColor, nil];
    NSArray* insideGradientColors = [NSArray arrayWithObjects:
                                     (__bridge id)UIColorFromRGB(0X616161).CGColor,
                                     (__bridge id)UIColorFromRGB(0X616161).CGColor,
                                     (__bridge id)UIColorFromRGB(0X616161).CGColor, nil];
    CGFloat insideGradientLocations[] = {0, 0.4, 1};
    CGGradientRef insideGradient = CGGradientCreateWithColors(colorSpace, (__bridge CFArrayRef)insideGradientColors, insideGradientLocations);


    //// Oval Drawing
    UIBezierPath* ovalPath = [UIBezierPath bezierPathWithOvalInRect: CGRectMake(0.5, 0.5, 23, 23)];
    CGContextSaveGState(context);
    [ovalPath addClip];
    CGContextDrawLinearGradient(context, insideGradient, CGPointMake(12, 0.5), CGPointMake(12, 23.5), 0);
    CGContextRestoreGState(context);

//    [[UIColor darkGrayColor] setStroke];
//    ovalPath.lineWidth = 0.5;
//    [ovalPath stroke];


    //// Oval 2 Drawing
//    UIBezierPath* oval2Path = [UIBezierPath bezierPathWithOvalInRect: CGRectMake(1, 1, 22, 22)];
//    [innerStrokeColor setStroke];
//    oval2Path.lineWidth = 0.5;
//    [oval2Path stroke];

    //// Cleanup
    CGGradientRelease(insideGradient);
    CGColorSpaceRelease(colorSpace);
}

@end