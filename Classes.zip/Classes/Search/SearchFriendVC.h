//
//  SearchFriendVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/8/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserCell.h"
#import "UserListingByInterestCatSubcatCell.h"
#import "RecrodingFriendRequestVC.h"

@interface SearchFriendVC : UIViewController <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate,AFNetworkingDataTransactionDelegate,UserCellDelegate,UserProfileVCDelegate,RecrodingFriendRequestVCDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, strong) NSMutableArray				*arrDataChannels;
@property (nonatomic, strong) NSString                      *strPrevUserSearch;
@property (nonatomic, strong) NSString                      *strPrevChannelsSearch;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) int						pageCounterChannels;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, readwrite) BOOL						isDataNullChannels;
@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;
@property (nonatomic, assign) BOOL                          isRecommendChannel;
@property (nonatomic, assign) BOOL                          isFirstTimeLoadChannelSearch;

@property (nonatomic, strong) IBOutlet  UIButton            *btnMenu;
@property (nonatomic, strong) IBOutlet  UIButton            *btnUser;
@property (nonatomic, strong) IBOutlet  UIButton            *btnChannels;

@property (nonatomic, strong) IBOutlet UITextField			*tfSearch;
@property (nonatomic, strong) IBOutlet UITextField			*tfSearchAtText; // tf for @ text
@property (nonatomic, strong) ASIFormDataRequest			*request;

@property (nonatomic, retain) IBOutlet UILabel				*lbl_NoDataAvailable;
@property (nonatomic, readwrite) int						selectedIndex;
@property (nonatomic, strong) UIActivityIndicatorView		*activityLoading;

@property (strong, nonatomic) IBOutlet UIView *viewUserPopupMain;
@property (strong, nonatomic) IBOutlet UIView *viewUserPopupSub1;
@property (strong, nonatomic) IBOutlet UIView *viewUserPopupSub2;
@property (strong, nonatomic) IBOutlet UIImageView *imgViewUserPopupSmall;
@property (strong, nonatomic) IBOutlet UILabel *lblPopupName;
@property (strong, nonatomic) IBOutlet UILabel *lblPopupUserName;
@property (strong, nonatomic) IBOutlet UILabel *lblPopupAge;
@property (strong, nonatomic) IBOutlet UITableView *tblPopupCatSubCat;
//@property (strong, nonatomic) IBOutlet UITextView *tvPopupProfileDesc;
//@property (strong, nonatomic) IBOutlet UITextView *tvPopupInterest;
@property (strong, nonatomic) IBOutlet AsyncImageView *imgViewPopupUserFull;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *activityIndiView;
@property (nonatomic, strong) IBOutlet UIImageView *imgViewRecommended;
@property (nonatomic, assign) BOOL isPlaying;
@end