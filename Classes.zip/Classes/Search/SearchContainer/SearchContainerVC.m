//
//  SearchContainerVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 01/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "SearchContainerVC.h"
#import "SearchFriendVC.h"
#import "LocationVC.h"
#import "InterestListForSearchVC.h"

@interface SearchContainerVC ()<ViewPagerDataSource, ViewPagerDelegate>

@property (nonatomic) NSUInteger numberOfTabs;

@end

@implementation SearchContainerVC

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.dataSource = self;
    self.delegate = self;
    
    [self performSelector:@selector(loadContent) withObject:nil afterDelay:0.2];
    
    // Keeps tab bar below navigation bar on iOS 7.0+
    // if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
    //     self.edgesForExtendedLayout = UIRectEdgeNone;
    // }
}
- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.btnMenu removeTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
	[self.btnMenu addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Setters
- (void)setNumberOfTabs:(NSUInteger)numberOfTabs {
    
    // Set numberOfTabs
    _numberOfTabs = numberOfTabs;
    
    // Reload data
    [self reloadData];
    
}

#pragma mark - Helpers
- (void)selectTabWithNumberFive {
    [self selectTabAtIndex:5];
}
- (void)loadContent {
    self.view.backgroundColor = UIColorFromRGB(0Xefefef);
    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];

    self.numberOfTabs = 3;
}

#pragma mark - Interface Orientation Changes
- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    
    // Update changes after screen rotates
    [self performSelector:@selector(setNeedsReloadOptions) withObject:nil afterDelay:duration];
}

#pragma mark - ViewPagerDataSource
- (NSUInteger)numberOfTabsForViewPager:(ViewPagerController *)viewPager {
    return self.numberOfTabs;
}
- (UIView *)viewPager:(ViewPagerController *)viewPager viewForTabAtIndex:(NSUInteger)index {
    
    UILabel *label = [UILabel new];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    if (index == 0) {
        label.text = @"By Name";
        
    }
    else if (index == 1) {
        label.text = @"By Geo-location";
    }
    else if (index == 2) {
        label.text = @"By Profile Description";
    }
    
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = TWITTER_BLUE_COLOR;
    [label sizeToFit];
    
    return label;
}

- (UIViewController *)viewPager:(ViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index {
    NSLog(@"contentViewControllerForTabAtIndex");
    
    if (index == 0) {
        SearchFriendVC *cvc = [self.storyboard instantiateViewControllerWithIdentifier:SEARCH_NEW_FRIEND_FROM_WHAZUP_VC];
        return cvc;
    }
    else if (index == 1) {
        LocationVC *cvc = [self.storyboard instantiateViewControllerWithIdentifier:USER_LOCATION_VC];
        return cvc;
    }
    else if (index == 2) {
        InterestListForSearchVC *cvc = [self.storyboard instantiateViewControllerWithIdentifier:@"InterestListForSearchVC"];
        return cvc;
    }

    return nil;
}

#pragma mark - ViewPagerDelegate
- (CGFloat)viewPager:(ViewPagerController *)viewPager valueForOption:(ViewPagerOption)option withDefault:(CGFloat)value {
    
    switch (option) {
        case ViewPagerOptionStartFromSecondTab:
            return 0.0;
        case ViewPagerOptionCenterCurrentTab:
            return 1.0;
        case ViewPagerOptionTabLocation:
            return 0.0;
        case ViewPagerOptionTabHeight:
            return 49.0;
        case ViewPagerOptionTabOffset:
            return 36.0;
        case ViewPagerOptionTabWidth:{
//            return UIInterfaceOrientationIsLandscape(self.interfaceOrientation) ? 128.0 : 96.0;
            return UIInterfaceOrientationIsLandscape(self.interfaceOrientation) ? 128.0 : (self.view.frame.size.width/self.numberOfTabs);
        }
        case ViewPagerOptionFixFormerTabsPositions:
            return 1.0;
        case ViewPagerOptionFixLatterTabsPositions:
            return 1.0;
        default:
            return value;
    }
}
- (UIColor *)viewPager:(ViewPagerController *)viewPager colorForComponent:(ViewPagerComponent)component withDefault:(UIColor *)color {

    switch (component) {
        case ViewPagerIndicator:
            return [[UIColor clearColor] colorWithAlphaComponent:0.64];
        case ViewPagerTabsView:
            return [[UIColor whiteColor] colorWithAlphaComponent:0.32];
        case ViewPagerContent:
            return [[UIColor darkGrayColor] colorWithAlphaComponent:0.32];
        default:
            return color;
    }

    
//    switch (component) {
//        case ViewPagerIndicator:
//            return [[UIColor redColor] colorWithAlphaComponent:0.64];
//        case ViewPagerTabsView:
//            return [[UIColor lightGrayColor] colorWithAlphaComponent:0.32];
//        case ViewPagerContent:
//            return [[UIColor darkGrayColor] colorWithAlphaComponent:0.32];
//        default:
//            return color;
//    }
}
@end
