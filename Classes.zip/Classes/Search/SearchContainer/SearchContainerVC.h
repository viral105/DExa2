//
//  SearchContainerVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 01/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "ViewPagerController.h"

@interface SearchContainerVC : ViewPagerController

@property (nonatomic, strong) IBOutlet  UIButton            *btnMenu;
@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@end
