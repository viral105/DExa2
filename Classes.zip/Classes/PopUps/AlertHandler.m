//
//  AlertHandler.m
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "AlertHandler.h"

@implementation AlertHandler

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

+(void)alertTitle:(NSString *)title message:(NSString *)msg delegate:(id)delegate tag:(int)tag cancelButtonTitle:(NSString *)cancelButtonTitle
	OKButtonTitle:(NSString*)OKButtonTitle otherButtonTitle:(NSString *)otherButtonTitle{
	
    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:title message:msg delegate:delegate cancelButtonTitle:cancelButtonTitle otherButtonTitles:OKButtonTitle,otherButtonTitle, nil];
    alertView.tag = tag;
    [alertView show];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
