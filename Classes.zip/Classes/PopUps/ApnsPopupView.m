//
//  ApnsPopupView.m
//  WWHHAAZZAAPP
//
//  Created by s on 9/16/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "ApnsPopupView.h"

@implementation ApnsPopupView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
		self.backgroundColor = [UIColor whiteColor];
		
		self.imgBgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
		self.imgBgView.backgroundColor = UIColorFromRGB(0X00c2d9);
		//self.imgBgView.alpha = 0.5;
        self.imgBgView.userInteractionEnabled = NO;
		[self addSubview:self.imgBgView];
		
        UIImageView *imgLogo = [[UIImageView alloc] init] ;
        [imgLogo setImage:[UIImage imageNamed:@"app_logo.png"]];
        imgLogo.frame = CGRectMake(10, 20, 80, 36);
        [self addSubview:imgLogo];
        
        
		self.lblMSG = [[UILabel alloc] initWithFrame:CGRectMake(10, 36+5+20, self.frame.size.width-30, 20)];
		self.lblMSG.font = [UIFont fontWithName:Font_Montserrat_Regular size:16];
		self.lblMSG.backgroundColor = [UIColor clearColor];
		self.lblMSG.textColor = [UIColor whiteColor];
		[self addSubview:self.lblMSG];

		self.btnClose = [UIButton buttonWithType:UIButtonTypeCustom];
		self.btnClose.frame = CGRectMake(self.frame.size.width-100, self.frame.size.height-45, 40, 40);
		[self.btnClose setImage:[UIImage imageNamed:Btn_Apns_Close] forState:UIControlStateNormal];
		[self addSubview:self.btnClose];
		
		
		self.btnPlay = [UIButton buttonWithType:UIButtonTypeCustom];
		self.btnPlay.frame = CGRectMake(self.frame.size.width-50, self.frame.size.height-45, 40, 40);
		[self.btnPlay setImage:[UIImage imageNamed:Btn_Apns_Play] forState:UIControlStateNormal];
		[self addSubview:self.btnPlay];
    }
    return self;
}

-(void)setReplyPopUpControlsWithAttachedImage:(BOOL)isContainImage{
    self.isImageAttached = isContainImage;
    float width = DEVICE_WIDTH-20;
    float height = 180;
    float xStart = (DEVICE_WIDTH-width)/2;
    float yStart = (DEVICE_HEIGHT-200)/2;
    
    if (self.isImageAttached) {
        height = (height+((width*2)/3)+20);           //230 for height and 30 for description
        yStart = (DEVICE_HEIGHT-(height-20))/2;
        yStart += 20;
    }
    
    self.imgBgView.frame = CGRectMake(xStart, yStart, width, height);

    self.imgProfile.frame = CGRectMake((DEVICE_WIDTH-70)/2, yStart-33, 70, 70);
    
    yStart = self.imgBgView.frame.origin.y+38;

    self.lblMSG.frame = CGRectMake(xStart, yStart, width, 20);

    
    yStart += 33;
    
    self.lblCategory.frame = CGRectMake(xStart, yStart, DEVICE_WIDTH-15, 20);
    
    yStart += 30;
    
    if (self.imgAttached) {
        [self.imgAttached removeFromSuperview];
        [self.lblDescription removeFromSuperview];
        self.imgAttached = nil;
        self.lblDescription = nil;
    }
    
    if (self.isImageAttached) {
        self.imgAttached = [[AsyncImageView alloc] initWithFrame:CGRectMake(xStart, yStart, width, (width*2)/3)];
        self.imgAttached.backgroundColor = [UIColor blackColor];
        self.imgAttached.layer.borderColor = [UIColor blackColor].CGColor;
        self.imgAttached.layer.borderWidth = 2;
        [self addSubview:self.imgAttached];
        
        yStart += (self.imgAttached.frame.size.height+5);
        
        self.lblDescription = [[UILabel alloc] initWithFrame:CGRectMake(xStart+5, yStart, width-10, 30)];        //here it is user name
        self.lblDescription.font = [UIFont fontWithName:Font_OpneSans_SemiBol size:14];
        self.lblDescription.backgroundColor = [UIColor clearColor];
        self.lblDescription.textAlignment = NSTextAlignmentLeft;
        self.lblDescription.textColor = UIColorFromRGB(0X00aa00);
        self.lblDescription.numberOfLines = 0;
        self.lblDescription.lineBreakMode = NSLineBreakByTruncatingTail;
        [self addSubview:self.lblDescription];
        
        yStart += 5;
    }
    yStart += 20;
    
    if (self.isImageAttached) {
        yStart += 20;
    }
    yStart += 10;
    
    
    xStart = self.imgBgView.frame.origin.x;
    
    //self.btnPlay = [UIButton buttonWithType:UIButtonTypeCustom];
//    self.btnPlay.frame = CGRectMake(xStart, yStart, width/3, 40);
//    [self.btnPlay setImage:[UIImage imageNamed:BtnNotifReplayResend] forState:UIControlStateNormal];
//    [self.btnPlay setTitle:@" Reply" forState:UIControlStateNormal];
//    [self.btnPlay setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
//    [self.btnPlay.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Light size:12]];
//    
//    [self addSubview:self.btnPlay];
    
    
    self.btnPlay.frame = CGRectMake(xStart, yStart, width/3, 40);
    
    xStart += self.btnPlay.frame.size.width;
    
//    self.btnPlayPause = [UIButton buttonWithType:UIButtonTypeCustom];
//    self.btnPlayPause.frame = CGRectMake(xStart, yStart, width/3, 40);
//    [self.btnPlayPause setImage:[UIImage imageNamed:BtnNotifUnRead] forState:UIControlStateNormal];
//    [self addSubview:self.btnPlayPause];
    
    self.btnPlayPause.frame = CGRectMake(xStart, yStart, width/3, 40);
    self.btnPlayPause.hidden = TRUE;
    
    self.imgPlayAnimation.frame = CGRectMake(xStart+((self.btnPlayPause.frame.size.width-40)/2), yStart, 40, 40);
    
//    self.imgPlayAnimation = [[UIImageView alloc] initWithFrame:CGRectMake(xStart+((self.btnPlayPause.frame.size.width-40)/2), yStart, 40, 40)];
//    self.imgPlayAnimation.hidden = YES;
//    [self addSubview:self.imgPlayAnimation];
    
    
    
    xStart += self.btnPlayPause.frame.size.width;

    self.btnClose.frame = CGRectMake(xStart, yStart, width/3, 40);
    
//    self.btnClose = [UIButton buttonWithType:UIButtonTypeCustom];
//    self.btnClose.frame = CGRectMake(xStart, yStart, width/3, 40);
//    [self.btnClose setImage:[UIImage imageNamed:BtnNotifDelete] forState:UIControlStateNormal];
//    [self.btnClose setTitle:@" Close" forState:UIControlStateNormal];
//    [self.btnClose setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
//    [self.btnClose.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Light size:13]];
//    
//    [self addSubview:self.btnClose];

    self.activityView.frame = self.btnPlayPause.frame;
    [self.activityView setHidden:NO];
    [self.activityView startAnimating];
    
//    self.activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
//    self.activityView.frame = self.btnPlayPause.frame;
//    self.activityView.hidesWhenStopped = YES;
//    [self addSubview:self.activityView];
//    [self.activityView setHidden:NO];
//    [self.activityView startAnimating];
    
}

- (id)initReplyPopUpWithFrame:(CGRect)frame isWithImage:(BOOL)isContainImage
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
		self.backgroundColor = [UIColor clearColor];
			
		UIImageView *imgBgTransparent = [[UIImageView alloc] initWithFrame:self.frame];
		imgBgTransparent.alpha = 0.8;
		imgBgTransparent.backgroundColor = [UIColor blackColor];
		[self addSubview:imgBgTransparent];
		imgBgTransparent = nil;

		
        self.imgBgView = [[UIImageView alloc] init];
        self.imgBgView.backgroundColor = [UIColor whiteColor];
        self.imgBgView.layer.cornerRadius = 4;
        [self addSubview:self.imgBgView];

        self.imgProfile = [[AsyncImageView alloc] init];
		self.imgProfile.backgroundColor = [UIColor clearColor];
		[self addSubview:self.imgProfile];
		

        self.lblMSG = [[UILabel alloc] init];        //here it is user name
		self.lblMSG.font = [UIFont fontWithName:Font_OpneSans_SemiBol size:19];
		self.lblMSG.backgroundColor = [UIColor clearColor];
		self.lblMSG.textAlignment = NSTextAlignmentCenter;
		[self addSubview:self.lblMSG];
		

        self.lblCategory = [[UILabel alloc] init];
		self.lblCategory.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
		self.lblCategory.backgroundColor = [UIColor clearColor];
		self.lblCategory.textColor = [UIColor whiteColor];
		self.lblCategory.textAlignment = NSTextAlignmentCenter;
		[self addSubview:self.lblCategory];

    
        self.btnPlay = [UIButton buttonWithType:UIButtonTypeCustom];
		[self.btnPlay setImage:[UIImage imageNamed:BtnNotifReplayResend] forState:UIControlStateNormal];
		[self.btnPlay setTitle:@" Reply" forState:UIControlStateNormal];
		[self.btnPlay setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
		[self.btnPlay.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Light size:12]];

		[self addSubview:self.btnPlay];

//		xStart += self.btnPlay.frame.size.width;
        
        self.btnPlayPause = [UIButton buttonWithType:UIButtonTypeCustom];
//		self.btnPlayPause.frame = CGRectMake(xStart, yStart, width/3, 40);
		[self.btnPlayPause setImage:[UIImage imageNamed:BtnNotifUnRead] forState:UIControlStateNormal];
		[self addSubview:self.btnPlayPause];
        self.btnPlayPause.hidden = TRUE;

//        self.imgPlayAnimation = [[UIImageView alloc] initWithFrame:CGRectMake(xStart+((self.btnPlayPause.frame.size.width-40)/2), yStart, 40, 40)];
        self.imgPlayAnimation = [[UIImageView alloc] init];
        self.imgPlayAnimation.hidden = YES;
        [self addSubview:self.imgPlayAnimation];
        

        
   //     xStart += self.btnPlayPause.frame.size.width;
		
		self.btnClose = [UIButton buttonWithType:UIButtonTypeCustom];
//		self.btnClose.frame = CGRectMake(xStart, yStart, width/3, 40);
		[self.btnClose setImage:[UIImage imageNamed:BtnNotifDelete] forState:UIControlStateNormal];
		[self.btnClose setTitle:@" Close" forState:UIControlStateNormal];
		[self.btnClose setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
		[self.btnClose.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Light size:13]];

		[self addSubview:self.btnClose];

        self.activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
//        self.activityView.frame = self.btnPlayPause.frame;
        self.activityView.hidesWhenStopped = YES;
        [self addSubview:self.activityView];
  //      [self.activityView setHidden:NO];
//        [self.activityView startAnimating];
        
        
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void)showNotifWithParams:(NSDictionary *)dic andNotifId:(int)tagId{
	
    if (tagId>1) {
     self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, self.frame.size.height-30);   
    }
    
    
	CGSize size = CGSizeMake(self.frame.size.width-40, 1000);
    /*
 User Info = {
 ContentID = 117;
 ID = "<null>";
 SoundPath = "http://wwhhaazzuupp.com/Sound/chillin_17.mp3";
 TypeID = 1;
 UserID = 8;
 aps =     {
 alert = "Your friend 1shreya is Yap'n with you about Chilling";
 badge = 1;
 sound = default;
 };
 }
 */
	NSString *strMsg = [NSString stringWithFormat:@"%@",[[dic valueForKey:@"aps"] valueForKey:@"alert"]] ;
	NSLog(@"apns = msg ---->> %@",strMsg);
	
    if (tagId !=404 && (tagId >3 && tagId<6)) {
        //4= birthday
        //5= annivarsary
        strMsg = [strMsg stringByAppendingFormat:@"\nWould you like to wish him/her?"];
    }
    
	CGRect textRectDate = [strMsg boundingRectWithSize:size
											options:NSStringDrawingUsesLineFragmentOrigin
										 attributes:@{NSFontAttributeName:self.lblMSG.font}
											context:nil];
	
	size = textRectDate.size;
	
	self.lblMSG.frame = CGRectMake(self.lblMSG.frame.origin.x, self.lblMSG.frame.origin.y, self.frame.size.width-40, size.height);
	self.lblMSG.numberOfLines = 0;
	self.lblMSG.text = strMsg;
	
	self.frame = CGRectMake(0, -self.frame.size.height, self.frame.size.width, self.frame.size.height);
    [self.btnPlay setTitle:@"" forState:UIControlStateNormal];
    [self.btnClose setTitle:@"" forState:UIControlStateNormal];
    
    if (tagId == 404) {
        //internet connection msg
        self.btnPlay.hidden = YES;
        self.btnPlayPause.hidden = YES;
        self.btnClose.hidden = NO;
        
         self.btnClose.frame = CGRectMake(self.frame.size.width-50, self.frame.size.height-10, 40, 40);
    }
    else{
        if (tagId >1) {
            
            if (tagId==4 || tagId == 5) {
                //4= birthday
                //5= annivarsary
                self.btnPlay.hidden = NO;
                self.btnClose.hidden = NO;
                
                [self.btnPlay setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
                [self.btnClose setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
                [self.btnPlay setTitle:YES_BUTTON_TITLE forState:UIControlStateNormal];
                [self.btnClose setTitle:NO_BUTTON_TITLE forState:UIControlStateNormal];
                
                self.btnClose.frame = CGRectMake(self.frame.size.width-100, self.frame.size.height-10, 40, 40);
                self.btnPlay.frame = CGRectMake(self.frame.size.width-50, self.frame.size.height-10, 40, 40);
            }
            else if (tagId == 2){
                //rec friend request or alarm request
                self.btnPlay.hidden = NO;
                self.btnClose.hidden = NO;
                [self.btnPlay setImage:[UIImage imageNamed:btnMenu_Frnd_Request_selected] forState:UIControlStateNormal];
                
                self.btnClose.frame = CGRectMake(self.frame.size.width-100, self.frame.size.height-17, 40, 40);
                self.btnPlay.frame = CGRectMake(self.frame.size.width-50, self.frame.size.height-17, 40, 40);
            }
            else if (tagId == 3){
                //Your friend request has been accepted by ajjjjaayy
                self.btnPlay.hidden = NO;
                self.btnClose.hidden = NO;
                [self.btnPlay setImage:[UIImage imageNamed:btnMenu_Home_Selected] forState:UIControlStateNormal];
                
                self.btnClose.frame = CGRectMake(self.frame.size.width-100, self.frame.size.height-14, 40, 40);
                self.btnPlay.frame = CGRectMake(self.frame.size.width-50, self.frame.size.height-17, 40, 40);
            }
            else if (tagId == 10){
                //rec friend request or alarm request
                self.btnPlay.hidden = NO;
                self.btnClose.hidden = NO;
                [self.btnPlay setImage:[UIImage imageNamed:btnMenu_Alarm_Selected] forState:UIControlStateNormal];
                
                self.btnClose.frame = CGRectMake(self.frame.size.width-100, self.frame.size.height-17, 40, 40);
                self.btnPlay.frame = CGRectMake(self.frame.size.width-50, self.frame.size.height-17, 40, 40);
            }
            else{
                //tagid = 6,7,8,10,11,14,16,17,18,19
                self.btnPlay.hidden = YES;
                self.btnClose.hidden = NO;
                self.btnClose.frame = CGRectMake(self.frame.size.width-50, self.frame.size.height-45, 40, 40);
                
            }
        }
        else{
            ///tagid = 1
            self.btnClose.frame = CGRectMake(self.frame.size.width-100, self.frame.size.height-45, 40, 40);
            self.btnPlay.frame = CGRectMake(self.frame.size.width-50, self.frame.size.height-45, 40, 40);
            
            [self.btnPlay setImage:[UIImage imageNamed:Btn_Apns_Play] forState:UIControlStateNormal];
            //[self.btnPlay setTitle:@" Reply" forState:UIControlStateNormal];
            [self.btnPlay setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            [self.btnPlay.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Light size:12]];
            [self.btnPlay setBackgroundColor:[UIColor clearColor]];
            
            self.btnPlay.hidden = NO;
            self.btnClose.hidden = NO;
        }
    }
}

-(void)showNotifWithReply:(NSDictionary *)dic andNotifId:(int)tagId{
	self.imgProfile.image =  nil;
	[self.imgProfile setImageURL:[NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]]];
    
    appDelegate.isShouldShowReplyPopUp = YES;
    
    if (self.isImageAttached) {
        self.imgAttached.contentMode = UIViewContentModeScaleAspectFit;
        self.imgAttached.image =  nil;
        [self.imgAttached setImageURL:[NSURL URLWithString:[dic valueForKey:ImagePath]]];
        self.imgAttached.clipsToBounds = YES;
    }
    if ([DataValidation checkNullString:[dic valueForKey:VideoPath]].length>0) {
        
//        AVAudioSession *session = [AVAudioSession sharedInstance];
//        [session setCategory:AVAudioSessionCategoryPlayback error:nil];
        
        [self MoviePlayerRemoveObserver];
        
        self.moviePlayer = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:[dic valueForKey:VideoPath]]];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(moviePlayBackDidFinish:)
                                                     name:MPMoviePlayerPlaybackDidFinishNotification
                                                   object:self.moviePlayer.moviePlayer];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(moviePlayBackDidFinish:)
                                                     name:MPMoviePlayerDidExitFullscreenNotification
                                                   object:self.moviePlayer.moviePlayer];

        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(MPMovieDurationAvailable:)
                                                     name:MPMovieDurationAvailableNotification
                                                   object:self.moviePlayer.moviePlayer];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(MPMoviePlayerPlaybackStateDidChange:)
                                                     name:MPMoviePlayerPlaybackStateDidChangeNotification
                                                   object:self.moviePlayer.moviePlayer];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(MPMoviewPlayerLoadStateDidChange:)
                                                     name:MPMoviePlayerLoadStateDidChangeNotification
                                                   object:self.moviePlayer.moviePlayer];
        

        self.moviePlayer.moviePlayer.shouldAutoplay = YES;
        
        [self.moviePlayer.moviePlayer prepareToPlay];
        
        self.moviePlayer.view.frame = self.imgAttached.frame;
        self.moviePlayer.moviePlayer.controlStyle = MPMovieControlStyleNone;
        
        [self.moviePlayer.moviePlayer play];
        self.moviePlayer.moviePlayer.scalingMode = MPMovieScalingModeAspectFit;
        [self addSubview:self.moviePlayer.view];
        
        self.btnPlayPause.hidden = YES;
        [self.activityView stopAnimating];
        [self.activityView setHidden:YES];

    }
    
	[Validation setCorners:self.imgProfile];
	
	NSString *strMsg = [NSString stringWithFormat:@"%@",[dic valueForKey:NAME]] ;
    if ([strMsg isEqualToString:TXT_ALARM]) {
        strMsg = @"Reminder";
        
    }
	CGSize size = CGSizeMake(self.imgBgView.frame.size.width, 1000);

	CGRect textRectDate = [strMsg boundingRectWithSize:size
											   options:NSStringDrawingUsesLineFragmentOrigin
											attributes:@{NSFontAttributeName:self.lblMSG.font}
											   context:nil];
	
	size = textRectDate.size;
	
	self.lblMSG.frame = CGRectMake((DEVICE_WIDTH-(size.width+5))/2, self.lblMSG.frame.origin.y, size.width+5, size.height);
	self.lblMSG.text = strMsg;
	[self.lblMSG setTextColor:[Validation getColorForAlphabet:self.lblMSG.text]];
	
	//cateogry
	strMsg = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_Category]];
    strMsg = (([[DataValidation checkNullString:strMsg] length] == 0)?@"Private":strMsg);
	size = CGSizeMake(self.imgBgView.frame.size.width, 15);
	textRectDate = [strMsg boundingRectWithSize:size
							 options:NSStringDrawingUsesLineFragmentOrigin
						  attributes:@{NSFontAttributeName:self.lblCategory.font}
							 context:nil];
	
	size = textRectDate.size;
	self.lblCategory.frame = CGRectMake((DEVICE_WIDTH-(size.width+5))/2, self.lblCategory.frame.origin.y, size.width+4, self.lblCategory.frame.size.height);
	self.lblCategory.text = strMsg;
	[self.lblCategory setBackgroundColor:[Validation getColorForAlphabet:self.lblCategory.text]];

    self.lblDescription.text = @"";
    if ([DataValidation checkNullString:[dic valueForKey:CaptionForImage]].length > 0) {
        self.lblDescription.text = [NSString stringWithFormat:@"%@",[dic valueForKey:CaptionForImage]];
        
        //------ calculate height
        
        size = CGSizeMake(self.lblDescription.frame.size.width, 1000);
        
        textRectDate = [self.lblDescription.text boundingRectWithSize:size
                                                              options:NSStringDrawingUsesLineFragmentOrigin
                                                           attributes:@{NSFontAttributeName:self.lblDescription.font}
                                                              context:nil];
        
        size = textRectDate.size;
        
        self.lblDescription.frame = CGRectMake(self.lblDescription.frame.origin.x, self.lblDescription.frame.origin.y, size.width, size.height);
        self.lblDescription.numberOfLines = 0;
        self.lblDescription.lineBreakMode = NSLineBreakByWordWrapping;
    }
	
}

-(void)stopPlayingVideo{
    if (self.moviePlayer==nil) {
        NSLog(@"MPMoviePlayerViewController obj is nil-->");
    }
    else{
        NSLog(@"MPMoviePlayerViewController obj is not nil-->");
    }
    [self MoviePlayerRemoveObserver];
    self.moviePlayer.moviePlayer.fullscreen = NO;
    self.moviePlayer.moviePlayer.contentURL = nil;
    self.moviePlayer.moviePlayer.shouldAutoplay = NO;
        [self.moviePlayer.moviePlayer stop];
        [self.moviePlayer.view removeFromSuperview];
    self.moviePlayer = nil;

}
-(void)MPMovieDurationAvailable:(NSNotification *)notification{
    
    if (self.moviePlayer !=nil) {
        if (![self.moviePlayer.view isHidden]) {
            if (self.moviePlayer.moviePlayer.duration > 0.00000) {
                
                if (!self.moviePlayer) {
                    [self.moviePlayer.moviePlayer stop];
                }
            }
        }
        else{
            NSLog(@"self.moviePlayer gettin nil here---->");
            [self.moviePlayer.moviePlayer stop];
            [self.moviePlayer.view removeFromSuperview];
            self.moviePlayer = nil;
        }
    }
}

-(void)MPMoviewPlayerLoadStateDidChange:(NSNotification *)notification{
    
    if (self.moviePlayer != nil) {
        if (self.moviePlayer.moviePlayer.loadState == MPMovieLoadStatePlaythroughOK) {
//            [self.activity stopAnimating];
        }
        else if (self.moviePlayer.moviePlayer.loadState == MPMovieLoadStateStalled){
//            [self.activity startAnimating];
        }
    }
}
- (void)MPMoviePlayerPlaybackStateDidChange:(NSNotification *)notification{
    
    if (self.moviePlayer != nil) {
        if (self.moviePlayer.moviePlayer.playbackState == MPMoviePlaybackStatePlaying) {
            
//            [self.activity stopAnimating];
            
            [self.moviePlayer.moviePlayer play];
        }
        else if (self.moviePlayer.moviePlayer.playbackState == MPMoviePlaybackStatePaused){     //|| self.moviePlayer.moviePlayer.playbackState == MPMoviePlaybackStateInterrupted){
            //[self.activity startAnimating];
        }
    }
}

- (void)moviePlayBackDidFinish:(NSNotification *)notification {
/*
    if (!self.isPlayAll) {
        if (self.isStoppedForceFully) {
            [self.activity removeFromSuperview];
            self.activity = nil;
            
        }else{
            [self.activity stopAnimating];
            [self.moviePlayer.moviePlayer play];
        }
        
        
        //        if (notification.object == self.moviePlayer) {
        //            NSInteger reason = [[notification.userInfo objectForKey:MPMoviePlayerPlaybackDidFinishReasonUserInfoKey] integerValue];
        //            if (reason == MPMovieFinishReasonPlaybackEnded)
        //            {
        //                [self.moviePlayer.moviePlayer play];
        //            }
        //        }
    }
    else{
        [self MoviePlayerRemoveObserver];
        [self.activity removeFromSuperview];
        self.activity = nil;
        self.viewFullImageContainer.hidden = YES;
        self.isFullScreenClicked = NO;
        //        self.isStoppedForceFully = YES;
        self.moviePlayer.moviePlayer.shouldAutoplay = NO;
        [self.moviePlayer.view removeFromSuperview];
        self.moviePlayer = nil;
        [self removeAnimationFromSuperView];
    }
*/
    if (self.moviePlayer==nil) {
        NSLog(@"MPMoviePlayerViewController obj is nil 2-->");
    }
    else{
        NSLog(@"MPMoviePlayerViewController obj is not nil 2-->");
    }
    [self.moviePlayer.moviePlayer play];
    
}
-(void)MoviePlayerRemoveObserver{
    if (self.moviePlayer==nil) {
        NSLog(@"MPMoviePlayerViewController obj is nil 3-->");
    }
    else{
        NSLog(@"MPMoviePlayerViewController obj is not nil 3-->");
    }
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerDidExitFullscreenNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerDidEnterFullscreenNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackStateDidChangeNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerLoadStateDidChangeNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMovieDurationAvailableNotification object:self.moviePlayer.moviePlayer];
    
    
}
-(void)showReminderWithParams:(NSDictionary *)dic andNotifId:(int)tagId{
    
    //------>> creator's profile image
    self.imgProfile.image =  nil;
    [self.imgProfile setImageURL:[NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]]];
    
    appDelegate.isShouldShowReplyPopUp = YES;
    
    [Validation setCorners:self.imgProfile];
    
    [self.imgAttached removeFromSuperview];
    self.imgAttached = nil;
    
    //------>>  creator's name
    NSString *strMsg = [NSString stringWithFormat:@"%@",[dic valueForKey:@"Createdby"]] ;
    
    CGSize size = CGSizeMake(self.imgBgView.frame.size.width, 1000);
    
    CGRect textRectDate = [strMsg boundingRectWithSize:size
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                            attributes:@{NSFontAttributeName:self.lblMSG.font}
                                               context:nil];
    
    size = textRectDate.size;
    
    self.lblMSG.frame = CGRectMake((DEVICE_WIDTH-(size.width+5))/2, self.lblMSG.frame.origin.y, size.width+5, size.height);
    self.lblMSG.text = strMsg;
    [self.lblMSG setTextColor:[Validation getColorForAlphabet:self.lblMSG.text]];
     self.lblMSG.backgroundColor = [UIColor clearColor];
    
    //------>>  Reminder Text
    
    
    UILabel *lblReminder = [[UILabel alloc] initWithFrame:CGRectMake(20, self.lblMSG.frame.origin.y+40, self.imgBgView.frame.size.width, 20)];
    
    lblReminder.textAlignment = NSTextAlignmentCenter;
    lblReminder.text = @"REMINDER";
    lblReminder.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    [self addSubview:lblReminder];
    lblReminder.tag = 123;
    
    
    
    //------>> Reminder subject name
    
    strMsg = [NSString stringWithFormat:@"%@",[dic valueForKey:@"Alarmname"]];
    size = CGSizeMake(self.imgBgView.frame.size.width, 15);
    self.lblCategory.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    textRectDate = [strMsg boundingRectWithSize:size
                                        options:NSStringDrawingUsesLineFragmentOrigin
                                     attributes:@{NSFontAttributeName:self.lblCategory.font}
                                        context:nil];
    
    size = textRectDate.size;
    self.lblCategory.frame = CGRectMake((DEVICE_WIDTH-(size.width+5))/2, lblReminder.frame.origin.y+30, size.width+4, self.lblCategory.frame.size.height);
    self.lblCategory.textColor = TWITTER_BLUE_COLOR;
    self.lblCategory.backgroundColor = [UIColor clearColor];
    self.lblCategory.text = strMsg;
    
    lblReminder = nil;
    
    //------>> show date n time to play reminder
    
    self.lblDescription.text = @"";
    self.lblDescription.text = [NSString stringWithFormat:@"%@",[dic valueForKey:@"Alarmdate"]];
    self.lblDescription.text = [self.lblDescription.text stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
    self.lblDescription.text = [self.lblDescription.text stringByAppendingFormat:@" - %@",[dic valueForKey:@"Alarmtime"]];
    self.lblDescription.textAlignment = NSTextAlignmentCenter;
    
    //------ calculate height
    
    size = CGSizeMake(self.lblDescription.frame.size.width, 1000);
    
    textRectDate = [self.lblDescription.text boundingRectWithSize:size
                                                          options:NSStringDrawingUsesLineFragmentOrigin
                                                       attributes:@{NSFontAttributeName:self.lblDescription.font}
                                                          context:nil];
    
    size = textRectDate.size;
    
    self.lblDescription.frame = CGRectMake((DEVICE_WIDTH-(size.width))/2, self.lblCategory.frame.origin.y+25, size.width, size.height);
    
    //------->> reminder Accept Status'
    
    int statusType = [[NSString stringWithFormat:@"%@",[dic valueForKey:USER_REMINDER_REQUEST_STATUS]] intValue];
    
    if (statusType != 404) {
        
        UILabel *lblReminderStatus = [[UILabel alloc] init];
        lblReminderStatus.tag = 124;
        lblReminderStatus.textAlignment = NSTextAlignmentCenter;
        lblReminderStatus.font = [UIFont fontWithName:Font_Montserrat_Regular size:9];
        
        lblReminderStatus.layer.cornerRadius = 12;
        lblReminderStatus.layer.borderWidth = 0.7;
        switch (statusType) {
            case 0:
                //pending
                lblReminderStatus.text = @"Pending";
                lblReminderStatus.layer.borderColor = UIColorFromRGB(0Xa0a5a6).CGColor;
                lblReminderStatus.textColor = UIColorFromRGB(0Xa0a5a6);
                break;
            case 1:{
                //Accepted
                lblReminderStatus.text = @"Accepted";
                lblReminderStatus.layer.borderColor = UIColorFromRGB(0X43a047).CGColor;
                lblReminderStatus.textColor = UIColorFromRGB(0X43a047);
            }
                break;
            case 2:
                //pending
                lblReminderStatus.text = @"Rejected";
                lblReminderStatus.layer.borderColor = UIColorFromRGB(0Xff5252).CGColor;
                lblReminderStatus.textColor = UIColorFromRGB(0Xff5252);
                break;
            default:
                break;
        }
        
        size = CGSizeMake(self.imgBgView.frame.size.width, 1000);
        
        textRectDate = [lblReminderStatus.text boundingRectWithSize:size
                                                            options:NSStringDrawingUsesLineFragmentOrigin
                                                         attributes:@{NSFontAttributeName:lblReminderStatus.font}
                                                            context:nil];
        
        size = textRectDate.size;
        
        lblReminderStatus.frame = CGRectMake((DEVICE_WIDTH-(size.width+20))/2, self.lblDescription.frame.origin.y+30, size.width+20, 25);
        [self addSubview:lblReminderStatus];
        
        lblReminderStatus = nil;
    }
    
}
-(void)setReminderControls{
    float width = DEVICE_WIDTH-40;
    float height = 250;
    float xStart = (DEVICE_WIDTH-width)/2;
    float yStart = (DEVICE_HEIGHT-200)/2;
    
    self.imgBgView.frame = CGRectMake(xStart, yStart, width, height);
    
    self.imgProfile.frame = CGRectMake((DEVICE_WIDTH-70)/2, yStart-33, 70, 70);
    
    yStart = self.imgBgView.frame.origin.y+45;
    
    self.lblMSG.frame = CGRectMake(xStart, yStart, width, 20);      //creator's name
    
    
    yStart += 33;
    
    yStart += 40;       //for reminder text title
    
    self.lblCategory.frame = CGRectMake(xStart, yStart, DEVICE_WIDTH-15, 20);   //Alert Subject text
    self.lblCategory.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    
    yStart += 35;
    
    
    if (self.lblDescription != nil) {
        [self.lblDescription removeFromSuperview];
        self.lblDescription = nil;
    }
    
    self.lblDescription = [[UILabel alloc] initWithFrame:CGRectMake(xStart+5, yStart, width-10, 20)];        //Alert time
    self.lblDescription.font = [UIFont fontWithName:Font_Montserrat_Regular size:10];
    self.lblDescription.backgroundColor = [UIColor clearColor];
    self.lblDescription.textAlignment = NSTextAlignmentLeft;
    self.lblDescription.textColor = [UIColor blackColor];
    [self addSubview:self.lblDescription];
    
    yStart += 5;
    yStart += 20;
    
    
    yStart += 30;           //for showing status;
    
    xStart = self.imgBgView.frame.origin.x;
    
    self.btnPlay.frame = CGRectMake(xStart, yStart, width/3, 40);
    
    xStart += self.btnPlay.frame.size.width;
    
    self.btnPlayPause.frame = CGRectMake(xStart, yStart, width/3, 40);
    self.btnPlayPause.hidden = TRUE;
    
    self.imgPlayAnimation.frame = CGRectMake(xStart+((self.btnPlayPause.frame.size.width-40)/2), yStart, 40, 40);
    
    
    xStart += self.btnPlayPause.frame.size.width;
    
    self.btnClose.frame = CGRectMake(xStart, yStart, width/3, 40);
    
    self.activityView.frame = self.btnPlayPause.frame;
    [self.activityView setHidden:NO];
    [self.activityView startAnimating];
    
}
-(void)removeObjectsFromView{
    
    self.imgAttached.image = nil;
    self.imgProfile.image = nil;
    if (self.imgBgView != nil) {
        [self.imgBgView removeFromSuperview];
        self.imgBgView = nil;
    }
    if (self.imgProfile != nil) {
        [self.imgProfile removeFromSuperview];
        self.imgProfile = nil;
    }
    
    if (self.lblMSG != nil) {
        [self.lblMSG removeFromSuperview];
        self.lblMSG = nil;
    }
    
    if (self.lblCategory != nil) {
        [self.lblCategory removeFromSuperview];
        self.lblCategory = nil;
    }

    if (self.isImageAttached) {
        if (self.imgAttached != nil) {
            [self.imgAttached removeFromSuperview];
            self.imgAttached = nil;
        }
        

        if (self.lblDescription != nil) {
            [self.lblDescription removeFromSuperview];
            self.lblDescription = nil;
        }
    }
    self.btnPlay = nil;
    self.btnPlayPause = nil;
    
    if (self.imgPlayAnimation != nil) {
        [self.imgPlayAnimation removeFromSuperview];
        self.imgPlayAnimation = nil;
    }
    
    self.btnClose = nil;
    
    if (self.activityView != nil) {
        [self.activityView removeFromSuperview];
        self.activityView = nil;
    }
}
@end
