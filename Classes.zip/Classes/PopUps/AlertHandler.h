//
//  AlertHandler.h
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlertHandler : UIAlertView

+(void)alertTitle:(NSString *)title message:(NSString *)msg delegate:(id)delegate tag:(int)tag cancelButtonTitle:(NSString *)cancelButtonTitle
	OKButtonTitle:(NSString*)OKButtonTitle otherButtonTitle:(NSString *)otherButtonTitle;

@end
