//
//  ToastMessageView.m
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "ToastMessageView.h"
#define Spacing			30


@implementation ToastMessageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
	}
    return self;
}
-(void)LoadWithMessage:(NSString *)str{
	
	self.viewContainer = [[UIView alloc] init];
	self.imgContainerBg = [[UIImageView alloc] init];
	self.lblMessage = [[UILabel alloc] init];
	
	self.lblMessage.font = [UIFont fontWithName:Font_Montserrat_Bold size:12];
	self.lblMessage.textColor = [UIColor whiteColor];
	self.lblMessage.textAlignment = NSTextAlignmentCenter;
	
	self.imgContainerBg.backgroundColor = TWITTER_BLUE_COLOR;
	self.imgContainerBg.alpha = 0.89;
	self.imgContainerBg.layer.cornerRadius = 5;
	self.imgContainerBg.image = [self blur:self.imgContainerBg.image];
	self.imgContainerBg.layer.borderColor = [UIColor whiteColor].CGColor;
	self.imgContainerBg.layer.borderWidth = 0.5;
	
	
	[self addSubview:self.viewContainer];
	[self.viewContainer addSubview:self.imgContainerBg];
	[self.viewContainer addSubview:self.lblMessage];
		
	CGSize size = CGSizeMake(300, 1000);
	
	CGRect textRectDate = [str boundingRectWithSize:size
											options:NSStringDrawingUsesLineFragmentOrigin
										 attributes:@{NSFontAttributeName:[UIFont fontWithName:Font_Montserrat_Bold size:12]}
											context:nil];
	
	size = textRectDate.size;
	
	self.lblMessage.frame = CGRectMake(15, 15, size.width, size.height);
	self.lblMessage.numberOfLines = 0;
	self.lblMessage.text = str;
	
	self.imgContainerBg.frame = CGRectMake(0, 0, size.width+Spacing, size.height+Spacing);
	
	self.viewContainer.frame = CGRectMake((self.frame.size.width-self.imgContainerBg.frame.size.width)/2, (self.frame.size.height-(size.height+Spacing))/2, size.width+Spacing, size.height+Spacing);
	
}
-(void)LoadWithBigMessage:(NSString *)str{
    
    self.viewContainer = [[UIView alloc] init];
    self.imgContainerBg = [[UIImageView alloc] init];
    self.lblMessage = [[UILabel alloc] init];
    
    self.lblMessage.font = [UIFont fontWithName:Font_Montserrat_Bold size:15];
    self.lblMessage.textColor = [UIColor whiteColor];
    self.lblMessage.textAlignment = NSTextAlignmentCenter;
    
    self.imgContainerBg.backgroundColor = TWITTER_BLUE_COLOR;
    self.imgContainerBg.alpha = 0.89;
    self.imgContainerBg.layer.cornerRadius = 5;
    self.imgContainerBg.image = [self blur:self.imgContainerBg.image];
    self.imgContainerBg.layer.borderColor = [UIColor whiteColor].CGColor;
    self.imgContainerBg.layer.borderWidth = 0.5;
    
    
    [self addSubview:self.viewContainer];
    [self.viewContainer addSubview:self.imgContainerBg];
    [self.viewContainer addSubview:self.lblMessage];
    
    CGSize size = CGSizeMake(300, 1000);
    
    CGRect textRectDate = [str boundingRectWithSize:size
                                            options:NSStringDrawingUsesLineFragmentOrigin
                                         attributes:@{NSFontAttributeName:[UIFont fontWithName:Font_Montserrat_Bold size:15]}
                                            context:nil];
    
    size = textRectDate.size;
    
    self.lblMessage.frame = CGRectMake(15, 15, size.width, size.height);
    self.lblMessage.numberOfLines = 0;
    self.lblMessage.text = str;
    
    self.imgContainerBg.frame = CGRectMake(0, 0, size.width+Spacing, size.height+Spacing);
    
    self.viewContainer.frame = CGRectMake((self.frame.size.width-self.imgContainerBg.frame.size.width)/2, (self.frame.size.height-(size.height+Spacing))/2, size.width+Spacing, size.height+Spacing);
    
}
-(void)removeToastControls{
    if (self.imgContainerBg != nil) {
        [self.imgContainerBg removeFromSuperview];
     //   [self.imgContainerBg release];
        self.imgContainerBg = nil;
    }
    if (self.lblMessage != nil) {
        [self.lblMessage removeFromSuperview];
//        [self.lblMessage release];
        self.lblMessage = nil;
    }
	
    if (self.viewContainer != nil) {
        [self.viewContainer removeFromSuperview];
  //      [self.viewContainer release];
        self.viewContainer = nil;
    }
}

-(void)ShowAudioLoader{
	
	self.viewContainer = [[UIView alloc] init];
	self.imgContainerBg = [[UIImageView alloc] init];
	self.activityLoader = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
	self.imgContainerBg.backgroundColor = TWITTER_BLUE_COLOR;
	self.imgContainerBg.alpha = 0.89;
	self.imgContainerBg.layer.cornerRadius = 5;
//	self.imgContainerBg.image = [self blur:self.imgContainerBg.image];
	[self addSubview:self.viewContainer];
	[self.viewContainer addSubview:self.imgContainerBg];
	
	self.imgContainerBg.frame = CGRectMake(0, 0, 50, 50);
	
	self.viewContainer.frame = CGRectMake((self.frame.size.width-self.imgContainerBg.frame.size.width)/2, (self.frame.size.height-self.imgContainerBg.frame.size.height)/2, 50, 50);
	
	
	
    [self.activityLoader setColor:UIColorFromRGB(0x3156a6)];
    self.activityLoader.frame = CGRectMake((self.imgContainerBg.frame.size.width-30)/2, (self.imgContainerBg.frame.size.height-30)/2, 30, 30);
	self.activityLoader.center = self.imgContainerBg.center;
	self.activityLoader.hidesWhenStopped = YES;
	[self.viewContainer addSubview:self.activityLoader];
	
	[self.activityLoader startAnimating];
}

-(void)ShowLoader{

	self.viewUserNotTouchable = [[UIView alloc] initWithFrame:self.frame];
	self.viewContainer = [[UIView alloc] init];
	self.imgContainerBg = [[UIImageView alloc] init];
	self.activityLoader = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
	
	self.viewUserNotTouchable.backgroundColor = [UIColor blackColor];
	self.viewUserNotTouchable.alpha = 0.7;
	self.viewUserNotTouchable.userInteractionEnabled = NO;
	[self addSubview:self.viewUserNotTouchable];
	
	self.imgContainerBg.backgroundColor = TWITTER_BLUE_COLOR;
	self.imgContainerBg.alpha = 0.89;
	self.imgContainerBg.layer.cornerRadius = 5;
	self.imgContainerBg.image = [self blur:self.imgContainerBg.image];
	[self addSubview:self.viewContainer];
	[self.viewContainer addSubview:self.imgContainerBg];
	
	self.imgContainerBg.frame = CGRectMake(0, 0, 50, 50);
	
	self.viewContainer.frame = CGRectMake((self.frame.size.width-self.imgContainerBg.frame.size.width)/2, (self.frame.size.height-self.imgContainerBg.frame.size.height)/2, 50, 50);

	
	//self.activityLoader.tintColor = TWITTER_BLUE_COLOR;
   [self.activityLoader setColor:[UIColor whiteColor]];
    self.activityLoader.frame = CGRectMake((self.imgContainerBg.frame.size.width-30)/2, (self.imgContainerBg.frame.size.height-30)/2, 30, 30);
	self.activityLoader.center = self.imgContainerBg.center;
	self.activityLoader.hidesWhenStopped = YES;
	[self.viewContainer addSubview:self.activityLoader];
	
	[self.activityLoader startAnimating];
}

-(void)ShowTableLoader{
	
	self.viewUserNotTouchable = [[UIView alloc] initWithFrame:self.frame];
	self.viewContainer = [[UIView alloc] init];
	self.imgContainerBg = [[UIImageView alloc] init];
	self.activityLoader = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
	
	self.viewUserNotTouchable.backgroundColor = [UIColor blackColor];
	self.viewUserNotTouchable.alpha = 0.7;
	self.viewUserNotTouchable.userInteractionEnabled = NO;
	[self addSubview:self.viewUserNotTouchable];
	
	self.imgContainerBg.backgroundColor = [UIColor whiteColor];
	self.imgContainerBg.alpha = 0.89;
	self.imgContainerBg.layer.cornerRadius = 5;
	self.imgContainerBg.image = [self blur:self.imgContainerBg.image];
	[self addSubview:self.viewContainer];
	[self.viewContainer addSubview:self.imgContainerBg];
	
	self.imgContainerBg.frame = CGRectMake(0, 0, 50, 50);
	
	self.viewContainer.frame = CGRectMake((self.frame.size.width-self.imgContainerBg.frame.size.width)/2, (self.frame.size.height-self.imgContainerBg.frame.size.height)/2, 50, 50);
	
	[self.activityLoader setColor:TWITTER_BLUE_COLOR];
    self.activityLoader.frame = CGRectMake((self.imgContainerBg.frame.size.width-30)/2, (self.imgContainerBg.frame.size.height-30)/2, 30, 30);
	self.activityLoader.center = self.imgContainerBg.center;
	self.activityLoader.hidesWhenStopped = YES;
	[self.viewContainer addSubview:self.activityLoader];
	
	[self.activityLoader startAnimating];
}


-(void)hideLoader{
	
	[self.activityLoader stopAnimating];
	
	if (self.viewUserNotTouchable != nil) {
		[self.viewUserNotTouchable removeFromSuperview];
//		[self.viewUserNotTouchable release];
		self.viewUserNotTouchable = nil;
	}
	
	[self.imgContainerBg removeFromSuperview];
	[self.activityLoader removeFromSuperview];
	[self.viewContainer removeFromSuperview];
	
	
//	[self.imgContainerBg release];
	self.imgContainerBg = nil;
	
//	[self.activityLoader release];
	self.activityLoader = nil;
	
//	[self.viewContainer release];
	self.viewContainer = nil;
}

-(void)hideAudioLoader{
	[self hideLoader];
}

- (UIImage*) blur:(UIImage*)theImage
{
    // ***********If you need re-orienting (e.g. trying to blur a photo taken from the device camera front facing camera in portrait mode)
    // theImage = [self reOrientIfNeeded:theImage];
	
    // create our blurred image
    CIContext *context = [CIContext contextWithOptions:nil];
    CIImage *inputImage = [CIImage imageWithCGImage:theImage.CGImage];
	
    // setting up Gaussian Blur (we could use one of many filters offered by Core Image)
    CIFilter *filter = [CIFilter filterWithName:@"CIGaussianBlur"];
    [filter setValue:inputImage forKey:kCIInputImageKey];
    [filter setValue:[NSNumber numberWithFloat:15.0f] forKey:@"inputRadius"];
    CIImage *result = [filter valueForKey:kCIOutputImageKey];
	
    // CIGaussianBlur has a tendency to shrink the image a little,
    // this ensures it matches up exactly to the bounds of our original image
    CGImageRef cgImage = [context createCGImage:result fromRect:[inputImage extent]];
	
    UIImage *returnImage = [UIImage imageWithCGImage:cgImage];//create a UIImage for this function to "return" so that ARC can manage the memory of the blur... ARC can't manage CGImageRefs so we need to release it before this function "returns" and ends.
    CGImageRelease(cgImage);//release CGImageRef because ARC doesn't manage this on its own.
	
    return returnImage;
	
    // *************** if you need scaling
    // return [[self class] scaleIfNeeded:cgImage];
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
