//
//  ApnsPopupView.h
//  WWHHAAZZAAPP
//
//  Created by s on 9/16/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"
@interface ApnsPopupView : UIView

@property (nonatomic, strong) UIImageView	*imgBgView;
@property (nonatomic, strong) UILabel		*lblMSG;
@property (nonatomic, strong) UIButton		*btnPlay;
@property (nonatomic, strong) UIButton		*btnClose;

@property (nonatomic, strong) AsyncImageView	*imgProfile;
@property (nonatomic, strong) UILabel		*lblCategory;
@property (nonatomic, strong) UIButton		*btnPlayPause;
@property (nonatomic, strong) UIActivityIndicatorView       *activityView;
@property (nonatomic, strong) AsyncImageView    *imgAttached;
@property (nonatomic, strong) UILabel		*lblDescription;
@property (nonatomic, readwrite) BOOL       isImageAttached;
@property (nonatomic, strong) UIImageView   *imgPlayAnimation;

@property (nonatomic, strong) MPMoviePlayerViewController   *moviePlayer;


- (id)initReplyPopUpWithFrame:(CGRect)frame isWithImage:(BOOL)isContainImage;
-(void)showNotifWithParams:(NSDictionary *)dic andNotifId:(int)tagId;
-(void)showNotifWithReply:(NSDictionary *)dic andNotifId:(int)tagId;
-(void)setReplyPopUpControlsWithAttachedImage:(BOOL)isContainImage;
-(void)removeObjectsFromView;

-(void)setReminderControls;
-(void)showReminderWithParams:(NSDictionary *)dic andNotifId:(int)tagId;
-(void)stopPlayingVideo;
@end
