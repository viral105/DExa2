//
//  ToastMessageView.h
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ToastMessageView : UIView

@property (nonatomic, strong) UIView					*viewUserNotTouchable;
@property (nonatomic, strong) UIView					*viewContainer;
@property (nonatomic, strong) UILabel					*lblMessage;
@property (nonatomic, strong) UIImageView				*imgContainerBg;
@property (nonatomic, strong) UIActivityIndicatorView	*activityLoader;

-(void)LoadWithMessage:(NSString *)str;
-(void)LoadWithBigMessage:(NSString *)str;
-(void)removeToastControls;
-(void)ShowLoader;
-(void)hideLoader;
-(void)ShowAudioLoader;
-(void)hideAudioLoader;
-(void)ShowTableLoader;
@end
