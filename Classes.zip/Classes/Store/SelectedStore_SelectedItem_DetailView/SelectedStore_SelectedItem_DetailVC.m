//
//  SelectedStore_SelectedItem_DetailVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 04/02/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "SelectedStore_SelectedItem_DetailVC.h"
#import "StoreItemCollectionViewCell.h"
#import "RageIAPHelper.h"
#import "IAPHelper.h"


@interface SelectedStore_SelectedItem_DetailVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}
//@property (nonatomic, strong) MBProgressHUD *HUD;
@property (nonatomic, strong) UICollectionView          *collectionView;

@end


static NSString *ItemIdentifier = @"ItemIdentifier";


@implementation SelectedStore_SelectedItem_DetailVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
  //  self.arrData = [[NSMutableArray alloc] init];
    
    NSLog(@"%@",self.dicData);
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];

    if ([[self.dicData valueForKey:IS_PAID] intValue]==0) {
        self.btnBuyFullPack.hidden = YES;
        [HUD hide:YES];
    }
    else if(([[self.dicData valueForKey:IS_PURCHASED] intValue]==1)&&([[self.dicData valueForKey:IS_PAID] intValue]==1)) {
        self.btnBuyFullPack.hidden = YES;
        [HUD hide:YES];
    }

    
    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    [self.lblTitle setText:[self.dicData valueForKey:NAME]];
    
    
    if (self.selectedStore == 1) {
        [self.btnBuyFullPack setTitle:[NSString stringWithFormat:@"Buy Full Pack - $ %@",[self.dicData valueForKey:@"Amount"]] forState:UIControlStateNormal];
           [self getAllSubCategoryById];
//        self.arrData = [NSMutableArray arrayWithArray:(NSArray *)[self.dicData valueForKey:@"SoundSubMaster"]];

    }
    else{
        [self.btnBuyFullPack setTitle:[NSString stringWithFormat:@"Buy - $ %@",[self.dicData valueForKey:@"Amount"]] forState:UIControlStateNormal];
    }
    
    self.CellLayout = [[StoreItemCollectionFlowLayout alloc] init];
    
    self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:self.CellLayout];
    [self.collectionView registerClass:[StoreItemCollectionViewCell class] forCellWithReuseIdentifier:ItemIdentifier];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-64-44);
    self.collectionView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    self.collectionView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.collectionView];
    
    appDelegate.currentVc = self;

    if (self.selectedStore == 2) {
        //call service for getting stickers list
//        api/Sticker/GetStickerDetailByID
        [HUD show:YES];
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                                   [NSDictionary dictionaryWithObjectsAndKeys:[self.dicData valueForKey:@"ID"],KeyValue,@"MasterStickrID",KeyName, nil],@"1",
                                   nil];

        NSString *strUrl = [WebServiceContainer getServiceURL:GET_STICKERLIST_BY_STICKER_ID withParameters:nil];
        self.request = [AFNetworkingDataTransaction sharedManager];
        [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
        if (self.request._currentRequest == nil) {
            [HUD hide:YES];
        }
        else{
            [self.request setDelegate:self];
            [self.request setTag:1];
        }
//        [self.request setDelegate:self];
//        [self.request setTag:1];
        
        strUrl = nil;
        NSLog(@"call initiated");
    }
    [self GetProductIdentifier];
}

-(void)viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
    
    if ([self.btnBuyFullPack isHidden]) {
        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        [Validation ResizeViewForAds];
    }
    else{
        [Validation removeAdviewFromSuperView];
        [Validation ResizeViewForAds];
    }
    
    
}

#pragma mark - GetAllSubCategoryBYID

-(void)getAllSubCategoryById{
    
    /*long UserID
     long SoundMasterID*/
    [HUD show:YES];
    NSLog(@"%@",self.dicData);
    
    NSDictionary *dic = nil;
    NSString *strUrl = @"";
    
    if (self.selectedStore == 1) {
        dic = [NSDictionary dictionaryWithObjectsAndKeys:
               [NSDictionary dictionaryWithObjectsAndKeys:[self.dicData valueForKey:@"ID"],KeyValue,@"SoundMasterID",KeyName, nil],@"1",
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"2",
               nil];
        
        strUrl = [WebServiceContainer getServiceURL:GET_ALL_PAID_SUBCATEGORYBYID withParameters:nil];
    }
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:2];
    
    strUrl = nil;
    NSLog(@"call initiated");
}

-(void)GetProductIdentifier{
    self.arrProducts = nil;
    [[RageIAPHelper sharedInstance] requestProductsWithCompletionHandler:^(BOOL success, NSArray *products) {
        if (success) {
            self.arrProducts = products;
        }
    }];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark    UICollectionView Delegate And Data Source methos
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.arrData.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    StoreItemCollectionViewCell *cell = (StoreItemCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:ItemIdentifier forIndexPath:indexPath];
    
    cell.imgItem.image = nil;
    cell.imgItem.imageURL = nil;
    
    
    
    NSLog(@"%lu",(unsigned long)self.arrData.count);
    //[cell setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%d.jpg", indexPath.item % 4]]];
    if (self.selectedStore == 1) {
        [cell.imgItem setImageURL:[NSURL URLWithString:[[self.arrData objectAtIndex:indexPath.row] valueForKey:CATEGORY_PHOTO_PATH]]];

        [cell.lblName setText: [[self.arrData objectAtIndex:indexPath.row] valueForKey:NAME]];
        
        int PriceCheck = [[[self.arrData objectAtIndex:indexPath.row] valueForKey:@"Amount"] intValue];
        
        int freeOrPaid = [[[self.arrData objectAtIndex:indexPath.row] valueForKey:IS_PAID] intValue];
        
        int PurchaseCheck = [[[self.arrData objectAtIndex:indexPath.row] valueForKey:IS_PURCHASED] intValue];
        
        if ((PriceCheck==0)&&(freeOrPaid==0)) {
            [cell.lblAmount setText:@"Free"];
        }
        else if((PurchaseCheck==1)&&(freeOrPaid==1)){
            [cell.lblAmount setText:@"Purchased"];
            cell.lblAmount.frame =CGRectMake(cell.lblAmount.frame.origin.x, cell.lblAmount.frame.origin.y, 75, cell.lblAmount.frame.size.height);

        }
        else{
            [cell.lblAmount setText:[NSString stringWithFormat:@"$%@",[[self.arrData objectAtIndex:indexPath.row] valueForKey:@"Amount"]]];
        }
        
        cell.lblName.numberOfLines = 2;
        cell.lblName.lineBreakMode = NSLineBreakByWordWrapping;
        
        cell.lblAmount.layer.cornerRadius = 10;
        cell.lblAmount.layer.masksToBounds = YES;
        
        
        
        CGSize size = CGSizeMake(cell.lblAmount.frame.size.width, 2000);
        
        
        
        CGRect textRectDate = [cell.lblAmount.text boundingRectWithSize:size
                                                                options:NSStringDrawingUsesLineFragmentOrigin
                                                             attributes:@{NSFontAttributeName:cell.lblAmount.font}
                                                                context:nil];
        
        size = textRectDate.size;
        size = CGSizeMake((size.width<50)?50:(size.width+10), size.height);
        
        cell.lblAmount.frame = CGRectMake((80-size.width)/2, cell.lblAmount.frame.origin.y,(size.width<50)?50:(size.width), 20);
    }
    else{
        [cell.imgItem setImageURL:[NSURL URLWithString:[[self.arrData objectAtIndex:indexPath.row] valueForKey:@"StickerPath"]]];

        cell.lblName.hidden = YES;
        cell.lblAmount.hidden = YES;
        cell.imgItem.frame = CGRectMake(cell.imgItem.frame.origin.x, cell.imgItem.frame.origin.y, 80, 100);
        cell.imgItem.layer.cornerRadius = 0;
        cell.imgItem.layer.borderWidth = 0;
        cell.imgItem.layer.borderColor = [UIColor clearColor].CGColor;
    }
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"selected Item Index = %ld",(long)indexPath.row);
    
     NSLog(@"ARRAY DATA =%@",self.arrData);
    if (self.selectedStore == 1) {
        if ([[[self.arrData objectAtIndex:indexPath.row] valueForKey:IS_PAID] intValue]==1 &&[[[self.arrData objectAtIndex:indexPath.row] valueForKey:IS_PURCHASED] intValue]==1) {
            [AlertHandler alertTitle:MESSAGE message:@"You have already purchased this sub category" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        }
        else{
            [HUD show:YES];
            
            self.selectedIndex = indexPath.row;
            
//            NSLog(@"self.selectedIndex =%ld",self.selectedIndex);
            
            self.strCategoryId = [self.dicData valueForKey:@"ID"];
            self.strSubCategoryId = [[self.arrData objectAtIndex:indexPath.row] valueForKey:@"ID"];
            self.strSubCategoryName = [[self.arrData objectAtIndex:indexPath.row] valueForKey:@"Name"];
            self.strSubCategoryAmount = [[self.arrData objectAtIndex:indexPath.row] valueForKey:@"Amount"];
            
             NSLog(@"Amount =%@",[[self.arrData objectAtIndex:indexPath.row] valueForKey:@"Amount"]);
            
            [appDelegate InitiatePurchaseFromProdutIds:self.arrProducts andPrice:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:indexPath.row] valueForKey:@"Amount"]]];

        }
    }
}

#pragma mark CustomMethods

-(IBAction)btnBackClicked{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnBuyFullPackCliced:(id)sender{
    NSLog(@"%@",[self.dicData valueForKey:@"Amount"]);
    
//    LOAD_LOADER(self.view);
    
    NSLog(@"%@",[self.dicData valueForKey:IS_PAID]);
    NSLog(@"%@",[self.dicData valueForKey:IS_PURCHASED]);
    
    if ([[self.dicData valueForKey:IS_PAID] intValue]==1 &&[[self.dicData valueForKey:IS_PURCHASED] intValue]==1) {
            [AlertHandler alertTitle:MESSAGE message:@"You have already purchased this package" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
    else{
        [HUD show:YES];
        
        NSLog(@"self.selectedStore-%d",self.selectedStore);
        
        if (self.selectedStore == 2){
            [appDelegate InitiatePurchaseFromProdutIds:self.arrProducts andPrice:[NSString stringWithFormat:@"%@",[self.dicData valueForKey:@"Amount"]]];
        }
        else{
             NSLog(@"IsPaid-%@",[self.dicData valueForKey:IS_PAID]);
            if ([[self.dicData valueForKey:IS_PAID] intValue]==0) {
                self.btnBuyFullPack.hidden = YES;
                [HUD hide:YES];
            }
            else{
                self.strCategoryId = [self.dicData valueForKey:@"ID"];
                self.strSubCategoryId = @"0";
                [appDelegate InitiatePurchaseFromProdutIds:self.arrProducts andPrice:[NSString stringWithFormat:@"%@",[self.dicData valueForKey:@"Amount"]]];
            }
        }
    }

}

-(void)Hideloader{
    [HUD hide:YES];
}

#pragma mark
#pragma mark web service method


- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    if ([appDelegate.currentVc isKindOfClass:[self class]]) {
        
        NSLog(@"tag = %d",tag);
        
        NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
        
        if (dicResponse != nil) {
            
            if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                [UIView beginAnimations:nil context:nil];
                [UIView setAnimationDuration:0.2];
                Validation.viewPullToRefresh.alpha = 0;
                [UIView commitAnimations];
                NSLog(@"dic = %@",dicResponse);
                [HUD hide:YES];
                [appDelegate callLogOutService];
            }
            else{
                if (tag == 1) {
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        
                        if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                            
                            //received
                            id response = [dicResponse objectForKey:RESPONSE];
                            if (response != nil) {
                                
                                
                                
                                NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                                
                                if (arr.count>0) {
                                    if (self.arrData == nil) {
                                        self.arrData = [[NSMutableArray alloc]  init];
                                    }
                                    [self.arrData addObjectsFromArray:arr];
                                    
                                    [self.collectionView reloadData];
                                }
                                
                                arr = nil;
                            }
                            
                            response = nil;
                            [HUD hide:YES];
                        }
                        else if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]){
                            [self.collectionView reloadData];
                            [HUD hide:YES];
                        }
                        else{
                            [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                            [HUD hide:YES];
                        }
                    }
                    else{
                        [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                        [HUD hide:YES];
                    }
                }
                else if (tag == 2){
                    //favorite response
                    
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                            
                            self.arrData = [NSMutableArray arrayWithArray:(NSArray *)[dicResponse valueForKey:RESPONSE]];
                            NSLog(@"ArrData:%@",self.arrData);
                            [self.collectionView reloadData];
                            
                            [HUD hide:YES];
                        }
                        else{
                            [HUD hide:YES];
                        }
                    }
                    else{
                        [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                        [HUD hide:YES];
                    }
                }
                else if (tag == 3){
                    
                    if(self.selectedStore==2){
                        
//                        NSMutableDictionary *dictTemp =[NSMutableDictionary dictionaryWithDictionary:(NSDictionary*)[self.arrData objectAtIndex:self.selectedIndex]];
//                        [self.dicData setValue:@"1" forKey:IS_PAID];
                        [self.dicData setValue:@"1" forKey:IS_PURCHASED];
                        self.btnBuyFullPack.hidden = YES;
//                        [self.arrData replaceObjectAtIndex:self.selectedIndex withObject:dictTemp];
                        [self.collectionView reloadData];
                        [HUD hide:YES];

                    }
                    else{
                        
                        NSMutableDictionary *dictTemp =[NSMutableDictionary dictionaryWithDictionary:(NSDictionary*)[self.arrData objectAtIndex:self.selectedIndex]];
                        [dictTemp setValue:@"1" forKey:IS_PAID];
                        [dictTemp setValue:@"1" forKey:IS_PURCHASED];
                        [self.arrData replaceObjectAtIndex:self.selectedIndex withObject:dictTemp];
                        [self.collectionView reloadData];
                        [HUD hide:YES];

                    }
                }
            }
        }
        else{
            [HUD hide:YES];
        }
        request = nil;
    }
}

-(void)SoundtrackPurchaseCancelled{
    HIDE_LOADER;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:FAILURE message:@"Could not finish your transaction.\nPlease try again later." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}


- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}

-(void)setSoundtrackPurchasable:(SKPaymentTransaction *)transaction{
//    [self callAdd_inAppDetailThroughFillOrderDetailIOSServiceWithURL:proId andTransId:transactionId];
    NSLog(@"SUCCESS");
 
    [HUD hide:YES];
    [HUD show:YES];
    
    
    /*
     long UserID (required)
     long CatID (required) = StickerMasterID
     string OrderID
     int PaymentStatus (required)
     string TransactionID (required)
     string PackageName
     string ProductId
     string PurchaseTime
     string DeveloperPayload
     string PurchaseToken
     decimal Amount (required)
     string OS (required)
     string DeviceRegID (required)
     int TypeID --pass 2 for stickers --
     
     //---------------------------------
     
     public enum PaymentStatus
     {
     Success = 0,
     Fail = 1,
     Refund = 2
     }
     
     */
    NSDictionary *dic = nil;
    NSString *strUrl = @"";
    NSString *strTransactioStatus = @"0";
    
    switch (transaction.transactionState)
    {
        case SKPaymentTransactionStatePurchased:
            strTransactioStatus = @"0"; // success
            break;
        case SKPaymentTransactionStateFailed:
            strTransactioStatus = @"1"; // fail
            break;
        case SKPaymentTransactionStateRestored:
            strTransactioStatus = @"2"; // restore
        default:
            break;
    }

    NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init] ;
    [dateFormatter1 setDateFormat:@"M/d/yyyy hh:mm:ss a"];
    [dateFormatter1 setAMSymbol:@"AM"];
    [dateFormatter1 setPMSymbol:@"PM"];
    NSTimeInterval seconds = [transaction.transactionDate timeIntervalSinceReferenceDate];
    double milliseconds = seconds*1000;
    
    NSLog(@"double miliseconds = %f",milliseconds);
    NSString *strMilisecond = [NSString stringWithFormat:@"%f",milliseconds];
    
    NSLog(@"miliseconds = %@",strMilisecond);

    if (self.selectedStore == 1) {
        //category
        dic = [NSDictionary dictionaryWithObjectsAndKeys:
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicData valueForKey:@"ID"]],KeyValue,@"CatID",KeyName, nil],@"2",
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",self.strSubCategoryId],KeyValue,@"SubCatID",KeyName, nil],@"3",
               [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"OrderID",KeyName, nil],@"4",
               [NSDictionary dictionaryWithObjectsAndKeys:strTransactioStatus,KeyValue,@"PaymentStatus",KeyName, nil],@"5",
               [NSDictionary dictionaryWithObjectsAndKeys:transaction.transactionIdentifier,KeyValue,@"TransactionID",KeyName, nil],@"6",
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",self.strSubCategoryName],KeyValue,@"PackageName",KeyName, nil],@"7",
               [NSDictionary dictionaryWithObjectsAndKeys:transaction.payment.productIdentifier,KeyValue,@"ProductId",KeyName, nil],@"8",
//               [NSDictionary dictionaryWithObjectsAndKeys:[dateFormatter1 stringFromDate:transaction.transactionDate],KeyValue,@"PurchaseTime",KeyName, nil],@"9",
               [NSDictionary dictionaryWithObjectsAndKeys:strMilisecond,KeyValue,@"PurchaseTime",KeyName, nil],@"9",
               [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"DeveloperPayload",KeyName, nil],@"10",
               [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"PurchaseToken",KeyName, nil],@"11",
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",self.strSubCategoryAmount],KeyValue,@"Amount",KeyName, nil],@"12",
               [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue,@"OS",KeyName, nil],@"13",
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]],KeyValue,@"DeviceRegID",KeyName, nil],@"14",
               [NSDictionary dictionaryWithObjectsAndKeys:@"1",KeyValue,@"TypeID",KeyName, nil],@"15",
               nil];
        
        strUrl = [WebServiceContainer getServiceURL:SEND_CATEGORY_PAYMENT_RESPONSE_VALUES withParameters:nil];
    }
    else{
        dic = [NSDictionary dictionaryWithObjectsAndKeys:
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicData valueForKey:@"ID"]],KeyValue,@"CatID",KeyName, nil],@"2",
               [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"OrderID",KeyName, nil],@"3",
               [NSDictionary dictionaryWithObjectsAndKeys:strTransactioStatus,KeyValue,@"PaymentStatus",KeyName, nil],@"4",
               [NSDictionary dictionaryWithObjectsAndKeys:transaction.transactionIdentifier,KeyValue,@"TransactionID",KeyName, nil],@"5",
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicData valueForKey:NAME]],KeyValue,@"PackageName",KeyName, nil],@"6",
               [NSDictionary dictionaryWithObjectsAndKeys:transaction.payment.productIdentifier,KeyValue,@"ProductId",KeyName, nil],@"7",
//               [NSDictionary dictionaryWithObjectsAndKeys:[dateFormatter1 stringFromDate:transaction.transactionDate],KeyValue,@"PurchaseTime",KeyName, nil],@"8",
               [NSDictionary dictionaryWithObjectsAndKeys:strMilisecond,KeyValue,@"PurchaseTime",KeyName, nil],@"9",
               [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"DeveloperPayload",KeyName, nil],@"9",
               [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"PurchaseToken",KeyName, nil],@"10",
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicData valueForKey:@"Amount"]],KeyValue,@"Amount",KeyName, nil],@"11",
               [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue,@"OS",KeyName, nil],@"12",
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]],KeyValue,@"DeviceRegID",KeyName, nil],@"13",
               [NSDictionary dictionaryWithObjectsAndKeys:@"2",KeyValue,@"TypeID",KeyName, nil],@"14",
               nil];
        
        strUrl = [WebServiceContainer getServiceURL:SEND_STICKER_PAYMENT_RESPONSE_VALUES withParameters:nil];
        
    }
    
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:3];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:3];
    
    strUrl = nil;
    NSLog(@"call initiated");
}

-(void)setSubscriptionPackagedPurchased:(NSString *)proId andTransId:(NSString *)transactionId{
    HIDE_LOADER;
//    [self callAdd_inAppDetailThroughFillOrderDetailIOSServiceWithURL:proId andTransId:transactionId
//     ];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
