//
//  SelectedStore_SelectedItem_DetailVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 04/02/15.
//  Copyright (c) 2015 s. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>
#import "StoreItemCollectionFlowLayout.h"
#import "AFNetworkingDataTransaction.h"


@interface SelectedStore_SelectedItem_DetailVC : UIViewController <UICollectionViewDataSource, UICollectionViewDelegate,AFNetworkingDataTransactionDelegate>

@property (nonatomic, strong) NSMutableDictionary           *dicData;
@property (nonatomic, readwrite)    int                     selectedStore;
//s@property (nonatomic, strong)       IBOutlet    UITableView *tblData;
@property (nonatomic, strong)   NSMutableArray              *arrData;

//@property (nonatomic, readwrite) int						pageCounter;
//@property (nonatomic, readwrite) BOOL						isDataNull;

@property (nonatomic, strong) AFNetworkingDataTransaction   *request;

//show items
@property (nonatomic, strong) StoreItemCollectionFlowLayout *CellLayout;

@property (nonatomic, strong) NSArray							*arrProducts;

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;
@property (nonatomic, strong) IBOutlet UIButton             *btnBuyFullPack;

@property (nonatomic, strong)  NSString				*strCategoryId;
@property (nonatomic, strong)  NSString				*strSubCategoryId;
@property (nonatomic, strong)  NSString				*strSubCategoryName;
@property (nonatomic, strong)  NSString				*strSubCategoryAmount;

@property (nonatomic, readwrite)    NSInteger                     selectedIndex;

-(void)GetProductIdentifier;

-(void)Hideloader;

-(void)setSoundtrackPurchasable:(SKPaymentTransaction *)transaction;
-(void)setSubscriptionPackagedPurchased:(NSString *)proId andTransId:(NSString *)transactionId;

-(void)getAllSubCategoryById;

@end
