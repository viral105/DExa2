//
//  SelectStoreVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 04/02/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "SelectStoreVC.h"
#import "ShowItemListForSelectedStoreVC.h"

@interface SelectStoreVC ()

@end

@implementation SelectStoreVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self LoadViewSettings];
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    //set menu image
    
    [self.btnMenu removeTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
	[self.btnMenu addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
    appDelegate.currentVc = self;
    appDelegate.isForwarded = NO;
    //bhavik 13-Feb-2015
    appDelegate.selectedMenuIndex = 7;
    
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark    Custom Methods

-(void)LoadViewSettings{
    
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
    [self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
//	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:30];
//	[self.lblTitle setTextColor:UIColorFromRGB(0Xccf5ff)];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnCategoryStoreClicked:(id)sender {
    
    ShowItemListForSelectedStoreVC *obj =  [MainStoryboard instantiateViewControllerWithIdentifier:SHOW_ITEMLIST_FOR_SELECTED_STORE_VC];
    obj.selectedStore = 1;
    [self.navigationController pushViewController:obj animated:YES];
}

- (IBAction)btnStickerStoreClicked:(id)sender {
    
    ShowItemListForSelectedStoreVC *obj =  [MainStoryboard instantiateViewControllerWithIdentifier:SHOW_ITEMLIST_FOR_SELECTED_STORE_VC];
    obj.selectedStore = 2;
    [self.navigationController pushViewController:obj animated:YES];
}

@end
