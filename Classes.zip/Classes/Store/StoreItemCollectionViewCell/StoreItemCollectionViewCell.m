//
//  StoreItemCollectionViewCell.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 04/02/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "StoreItemCollectionViewCell.h"

@interface StoreItemCollectionViewCell ()


@end

@implementation StoreItemCollectionViewCell

- (id)initWithFrame:(CGRect)frame
{
    if (!(self = [super initWithFrame:frame])) return nil;
    
    float xStart = 2;
    
    self.imgItem = [[AsyncImageView alloc] initWithFrame:CGRectInset(CGRectMake(2, 2, CGRectGetWidth(frame), CGRectGetWidth(frame)), 5, 5)];
    self.imgItem.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
//    [Validation setCorners:self.imgItem];
    self.imgItem.layer.borderColor = TWITTER_BLUE_COLOR.CGColor;
    self.imgItem.layer.borderWidth = 1;
    [self.contentView addSubview:self.imgItem];
    
    xStart += (CGRectGetWidth(frame));
    
    self.lblName = [[UILabel alloc] initWithFrame:CGRectMake(2, xStart, CGRectGetWidth(frame)-5, 40)];
    self.lblName.backgroundColor = [UIColor clearColor];
    self.lblName.text = @"hello";
    self.lblName.font = [UIFont fontWithName:Font_Montserrat_Regular size:15];
    self.lblName.textColor = TWITTER_BLUE_COLOR;
    self.lblName.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:self.lblName];
    
    xStart += 40;
    
    self.lblAmount = [[UILabel alloc] initWithFrame:CGRectMake(2, xStart, CGRectGetWidth(frame)-5, 20)];
    self.lblAmount.backgroundColor = UIColorFromRGB(0X43a047);
    self.lblAmount.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    self.lblAmount.textColor = [UIColor whiteColor];
    self.lblAmount.textAlignment = NSTextAlignmentCenter;
    self.lblAmount.text = @"$12";
    [self.contentView addSubview:self.lblAmount];
    
    xStart += 15;
    NSLog(@"%f",xStart);
    
    self.backgroundColor = [UIColor clearColor];
    
    return self;
}

-(void)prepareForReuse
{
    [self.imgItem setImage:nil];
}

-(void)setImage:(UIImage *)image
{
    self.imgItem.image = image;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
