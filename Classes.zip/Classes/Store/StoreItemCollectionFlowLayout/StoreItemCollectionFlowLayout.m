//
//  StoreItemCollectionFlowLayout.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 04/02/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "StoreItemCollectionFlowLayout.h"

@implementation StoreItemCollectionFlowLayout

-(id)init
{
    if (!(self = [super init])) return nil;
    
    self.itemSize = CGSizeMake(80, 145);
    self.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    self.minimumInteritemSpacing = 10.0f;
    self.minimumLineSpacing = 10.0f;
    
    return self;
}

@end
