//
//  ShowItemListForSelectedStoreVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 04/02/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StoreItemCollectionFlowLayout.h"
#import "AFNetworkingDataTransaction.h"


@interface ShowItemListForSelectedStoreVC : UIViewController <UICollectionViewDataSource, UICollectionViewDelegate,AFNetworkingDataTransactionDelegate>


@property (nonatomic, readwrite)    int                     selectedStore;
//s@property (nonatomic, strong)       IBOutlet    UITableView *tblData;
@property (nonatomic, strong)   NSMutableArray              *arrData;

@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;

@property (nonatomic, strong) AFNetworkingDataTransaction   *request;

//show items
@property (nonatomic, strong) StoreItemCollectionFlowLayout *CellLayout;

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;
@property (nonatomic, strong) UICollectionView          *collectionView;


@end
