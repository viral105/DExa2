//
//  ActivityViewCustomActivity.m
//  WWHHAAZZAAPP
//
//  Created by Nivid Jain on 9/23/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "ActivityViewCustomActivity.h"

@implementation ActivityViewCustomActivity

-(id)initWithActivityWithId:(int)idForActivity{
    self = [super init];
    if (self) {
        self.idForActivity = idForActivity;
    }
    return self;
}

- (NSString *)activityType
{
    switch (self.idForActivity) {
        case 0:{
            //instagram
            return @"com.instagram.exclusivegram";
        }
            break;
        case 1:{
            return @"com.instagram.exclusivegram";
        }
            break;
        default:
            break;
    }
    return @"";
}

- (NSString *)activityTitle
{
   // return @"Instagram";
    switch (self.idForActivity) {
        case 0:{
            //instagram
            return @"Instagram";
        }
            break;
        case 1:{
            return @"Flickr";
        }
            break;
        default:
            break;
    }
    return @"";
}

- (UIImage *)activityImage
{
    // Note: These images need to have a transparent background and I recommend these sizes:
    // iPadShare@2x should be 126 px, iPadShare should be 53 px, iPhoneShare@2x should be 100
    // px, and iPhoneShare should be 50 px. I found these sizes to work for what I was making.
    
//    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
//    {
//        return [UIImage imageNamed:@"Icon58x58.png"];
//    }
//    else
//    {
//        return [UIImage imageNamed:@"iconAlert-info.png"];
//    }
    switch (self.idForActivity) {
        case 0:{
            //instagram
            return [UIImage imageNamed:@"iconAlert-info.png"];;
        }
            break;
        case 1:{
            return [UIImage imageNamed:@"iconAlert-info.png"];;
        }
            break;
        default:
            break;
    }
    return [UIImage imageNamed:@""];;
}

- (BOOL)canPerformWithActivityItems:(NSArray *)activityItems
{
    NSLog(@"%s", __FUNCTION__);
    return YES;
}

- (void)prepareWithActivityItems:(NSArray *)activityItems
{
    NSLog(@"%s",__FUNCTION__);
}

- (UIViewController *)activityViewController
{
    NSLog(@"%s",__FUNCTION__);
    return nil;
}

- (void)performActivity
{
    // This is where you can do anything you want, and is the whole reason for creating a custom
    // UIActivity
    
    switch (self.idForActivity) {
        case 0:{
            //instagram
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"itms-apps://ax.itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?type=Purple+Software&id=yourappid"]];
        }
            break;
        case 1:{
            //[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://app.facebook.com"]];
        }
            break;
        default:
            break;
    }
    
        [self activityDidFinish:YES];
}

@end
