//
//  ActivityViewCustomActivity.h
//  WWHHAAZZAAPP
//
//  Created by Nivid Jain on 9/23/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActivityViewCustomActivity : UIActivity

@property (nonatomic, readwrite) int idForActivity;
-(id)initWithActivityWithId:(int)idForActivity;
@end
