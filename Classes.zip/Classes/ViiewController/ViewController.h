//
//  ViewController.h
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <FBLoginViewDelegate>

@property (nonatomic, strong) IBOutlet UIButton		*btnSignIn;
@property (nonatomic, strong) IBOutlet UIButton		*btnSignUP;
@property (nonatomic, strong) IBOutlet UIButton		*btnFacebook;
@property (nonatomic, strong) IBOutlet UILabel		*lblOrSignInWith;
@property (nonatomic, strong) ASIHTTPRequest		*request;
@property (nonatomic, strong) NSMutableDictionary	*dicFbData;
//@property (nonatomic, strong) IBOutlet FBLoginView	*loginView;

@end
