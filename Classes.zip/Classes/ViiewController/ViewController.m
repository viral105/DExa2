//
//  ViewController.m
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "ViewController.h"
#import "SignUpVC.h"
#import "ProfileVC.h"
#import "SWRevealViewController.h"
#import "MBProgressHUD.h"

@interface ViewController () <MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation ViewController

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	
    
	self.dicFbData = nil;
	[Validation performSelectorInBackground:@selector(initiateAPNSPopup) withObject:nil];
		
	
	if (FBSession.activeSession.isOpen) {
		[FBSession.activeSession closeAndClearTokenInformation];
	}

	if (appDelegate.is_Login) {
        appDelegate.selectedMenuIndex = 0;
//        [self performSegueWithIdentifier:NOTIFICATION_VC sender:nil];
 //       UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
        
        [UIView transitionWithView:self.navigationController.view
                          duration:0.5
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.navigationController pushViewController:ivc animated:NO];
                        }
                        completion:nil];
	}
}

-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
	appDelegate.currentVc = self;
	if (!appDelegate.is_Login) {
		[self performSelector:@selector(LoadViewSettings)];
	}
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark	Methods

-(void)LoadViewSettings{
	

	self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:Blue_BG]];
	
	[self.btnSignIn setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
	[self.btnSignUP setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
	[self.btnFacebook setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	
	[self.btnSignIn.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnSignUP.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnFacebook.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	
	[self.btnSignIn setAdjustsImageWhenHighlighted:NO];
	[self.btnSignUP setAdjustsImageWhenHighlighted:NO];
	[self.btnFacebook setAdjustsImageWhenHighlighted:NO];
	
	self.lblOrSignInWith.font = [UIFont fontWithName:Font_Montserrat_Regular size:11];
/*	if (self.loginView == nil) {
		self.loginView = [[FBLoginView alloc] initWithReadPermissions:@[@"public_profile", @"email", @"user_friends"]];
		
		// Align the button in the center horizontally
		//loginView.frame = CGRectOffset(self.btnFacebook.frame, (self.view.center.x - (self.btnFacebook.frame.size.width / 2)), 5);
		self.loginView.frame = self.btnFacebook.frame;
				
		self.loginView.delegate = self;
		[self.view addSubview:self.loginView];
		
		for (id obj in self.loginView.subviews)
		{
			if ([obj isKindOfClass:[UIButton class]])
			{
				UIButton * loginButton =  obj;
				self.btnFacebook = loginButton;
				[self.btnFacebook addTarget:self action:@selector(btnFaceBookClicked:) forControlEvents:UIControlEventTouchDown];
				break;
			}
		}
	}
	for (id obj in self.loginView.subviews)
	{
		if ([obj isKindOfClass:[UIButton class]])
		{
			UIButton * loginButton =  obj;
			UIImage *loginImage = [UIImage imageNamed:@"btn_fb_signin.png"];
			[loginButton setImage:loginImage forState:UIControlStateNormal];
			//			loginButton.frame = CGRectMake(0, 0, self.btnFacebook.frame.size
			//										   .width, self.btnFacebook.frame.size
			//										   .height);
			// [loginButton sendActionsForControlEvents:UIControlEventTouchUpInside];
			[loginButton setBackgroundImage:nil forState:UIControlStateSelected];
			[loginButton setBackgroundImage:nil forState:UIControlStateHighlighted];
			//	[loginButton sizeToFit];
		}
		if ([obj isKindOfClass:[UILabel class]])
		{
			UILabel * loginLabel =  obj;
			loginLabel.text = @"FACEBOOK";
			[loginLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
			[loginLabel setTextColor:TWITTER_BLUE_COLOR ];
			loginLabel.textAlignment = NSTextAlignmentCenter;
			loginLabel.frame = CGRectMake(0, 0, self.btnFacebook.frame.size.width, self.btnFacebook.frame.size.height);
		}
	}
*/
//	[Validation showCarttonCharacterAnimation];
//	[self performSelector:@selector(hideAnimation) withObject:nil afterDelay:10];
}

-(void)hideAnimation{
	[Validation HidingCartoonChar];
}
-(IBAction)btnSignInClicked:(id)sender{
	[Validation CancelOnGoingRequests:self.request];
	[self performSegueWithIdentifier:LOGIN_VC sender:nil];
}

-(IBAction)btnSignUpClicked:(id)sender{
	UIStoryboard *storyboard = [UIStoryboard storyboardWithName:STORYBOARD bundle:nil];
	SignUpVC *ivc = [storyboard instantiateViewControllerWithIdentifier:SIGNUP_VC];
	[self.navigationController pushViewController:ivc animated:NO];
}


-(IBAction)btnFaceBookClicked:(id)sender{
	NSLog(@"fb btn pressed");
	//[Validation showLoadingIndicator];
    [HUD show:YES];


	if (!FBSession.activeSession.isOpen) {
        // if the session is closed, then we open it here, and establish a handler for state changes
        [FBSession openActiveSessionWithReadPermissions:@[@"public_profile", @"email", @"user_friends,"]
                                           allowLoginUI:YES
                                      completionHandler:^(FBSession *session,
														  FBSessionState state,
														  NSError *error) {
										  if (error) {
                                              [HUD hide:YES];
											  UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
																								  message:@"Could not get your Facebook data.\nPlease check you internet connectivity or try later."
																								 delegate:nil
																						cancelButtonTitle:@"OK"
																						otherButtonTitles:nil];
											  [alertView show];
										  } else if (session.isOpen) {
											 // [self pickFriendsButtonClick:sender];
											  NSLog(@"facebook login");
											  [self GetUserData];
										  }
									  }];
        return;
    }
	else if (FBSession.activeSession.isOpen) {
		// [self pickFriendsButtonClick:sender];
		NSLog(@"facebook login");
		[self GetUserData];
	}
 
}

- (void)loginViewFetchedUserInfo:(FBLoginView *)loginView
                            user:(id<FBGraphUser>)user {
	//self.profilePictureView.profileID = user.id;
//	self.nameLabel.text = user.name;
	NSLog(@"user= %@",user);
	if (self.request !=nil) {
		self.request = nil;
	}
	if (self.dicFbData == nil) {
		self.dicFbData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)user];
		if ([DataValidation checkNullString:[self.dicFbData valueForKey:@"email"]].length > 0) {
			/*
			 Printing description of result:
			 {
			 email = "shreya@huskerit.com";
			 "first_name" = Shreya;
			 gender = female;
			 id = 100004489536064;
			 "last_name" = Shreya;
			 link = "https://www.facebook.com/shreya.shreya.18";
			 locale = "en_US";
			 location =     {
			 id = 115440481803904;
			 name = "Ahmedabad, India";
			 };
			 name = "Shreya Shreya";
			 timezone = "5.5";
			 "updated_time" = "2013-01-23T08:27:10+0000";
			 username = "shreya.shreya.18";
			 verified = 1;
			 }
			 */
			NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
								  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"emailID",KeyName, nil],@"1",
								  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"userName",KeyName, nil],@"2",
								  [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:[self.dicFbData valueForKey:@"id"] isGeneral:YES],KeyValue,@"facebookID",KeyName, nil],@"3",
								  [NSDictionary dictionaryWithObjectsAndKeys:@"-1",KeyValue,@"IsActive",KeyName, nil],@"4",
								  
								  nil];
			
			NSString *strUrl = [WebServiceContainer getServiceURL:CHECK_USER_EXIST withParameters:nil];
			self.request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:FALSE];
            if (self.request == nil) {
                [HUD hide:YES];
            }
            else{
                [self.request setDelegate:self];
                [self.request setTag:1];
            }
//			self.request.delegate = self;
//			self.request.tag = 1;
			strUrl = nil;
		}
	}
}
-(void)fetchNewDataWithCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler{
        NSLog(@"No new data found.");
    
    
}
-(void)GetUserData{
	[[FBRequest requestForMe] startWithCompletionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
		//result contains a dictionary of your user, including Facebook ID.
        
        
        
		NSLog(@"result=  %@",result);
         NSString *userImageURL = [NSString stringWithFormat:@"https://graph.facebook.com/%@/picture?type=large", [result objectID]];
        NSLog(@"fb userImageURL=  %@",userImageURL);
		/*
		 Printing description of result:
		 {
		 email = "shreya@huskerit.com";
		 "first_name" = Shreya;
		 gender = female;
		 id = 100004489536064;
		 "last_name" = Shreya;
		 link = "https://www.facebook.com/shreya.shreya.18";
		 locale = "en_US";
		 location =     {
		 id = 115440481803904;
		 name = "Ahmedabad, India";
		 };
		 name = "Shreya Shreya";
		 timezone = "5.5";
		 "updated_time" = "2013-01-23T08:27:10+0000";
		 username = "shreya.shreya.18";
		 verified = 1;
		 }
		 */
		//check user exist with fbID
//		if (self.dicFbData == nil) {
			self.dicFbData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)result];
        [self.dicFbData setObject:userImageURL forKey:@"PhotoPath"];
//			FBProfilePictureView *profileImage = [[FBProfilePictureView alloc] initWithProfileID:[self.dicFbData valueForKey:@"id"] pictureCropping:FBProfilePictureCroppingOriginal];
//			profileImage.frame = CGRectMake(100 , 100, 100, 100);
//			[self.view addSubview:profileImage];
			
		if (self.request !=nil) {
			self.request = nil;
		}
			if ([DataValidation checkNullString:[self.dicFbData valueForKey:@"id"]].length > 0) {
				
				NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
									  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"emailID",KeyName, nil],@"1",
									  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"userName",KeyName, nil],@"2",
									  [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:[self.dicFbData valueForKey:@"id"] isGeneral:YES],KeyValue,@"facebookID",KeyName, nil],@"3",
									  [NSDictionary dictionaryWithObjectsAndKeys:@"-1",KeyValue,@"IsActive",KeyName, nil],@"4",
									  
									  nil];
				
				NSString *strUrl = [WebServiceContainer getServiceURL:CHECK_USER_EXIST withParameters:nil];
				self.request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:FALSE];
                if (self.request == nil) {
                    [HUD hide:YES];
                }
                else{
                    [self.request setDelegate:self];
                    [self.request setTag:1];
                }
//				self.request.delegate = self;
//				self.request.tag = 1;
				strUrl = nil;
				
			}
//		}
	}];
}

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{

	NSLog(@"response =%@",[request responseString]);
	
	NSError *error = nil;
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];;
	
	NSLog(@"dictionary = %@",dicResponse);
	
	[Validation resetTextFieldBorderColor];
	
	if ([dicResponse objectForKey:RESPONSE] != nil) {
		
		if (([[dicResponse valueForKey:STATUS] intValue] != 0) && ([[dicResponse valueForKey:STATUS] intValue] != -1) ) {
			id response = [dicResponse objectForKey:RESPONSE];
			
			if (request.tag == 1) {
				if ([response isKindOfClass:[NSDictionary class]]) {
					if (((NSDictionary *)response).count>0) {
						//so call login service
						NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
											  [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:[self.dicFbData valueForKey:@"id"] isGeneral:YES],KeyValue,@"facebookID",KeyName, nil],@"1",
											  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]],KeyValue,@"RegID",KeyName, nil],@"2",
											  [NSDictionary dictionaryWithObjectsAndKeys:APPLICATION_OS,KeyValue,@"OS",KeyName, nil],@"3",
											  
											  
											  nil];
						
						if (self.request != nil) {
							self.request = nil;
						}
						
						NSString *strUrl = [WebServiceContainer getServiceURL:LOGIN_WITH_FB withParameters:nil];
						self.request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:FALSE];
                        if (self.request == nil) {
                            [HUD hide:YES];
                        }
                        else{
                            [self.request setDelegate:self];
                            [self.request setTag:2];
                        }
//						self.request.delegate = self;
//						self.request.tag = 2;
						strUrl = nil;
					}
					//					else{
					//						//go for sign up
					//					}
				}
				else if ([response isKindOfClass:[NSArray class]]){
					if (((NSArray *)response).count > 0) {
						//so call login service
						NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
											  [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:[self.dicFbData valueForKey:@"id"] isGeneral:YES],KeyValue,@"facebookID",KeyName, nil],@"1",
											  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]],KeyValue,@"RegID",KeyName, nil],@"2",
											  [NSDictionary dictionaryWithObjectsAndKeys:APPLICATION_OS,KeyValue,@"OS",KeyName, nil],@"3",
											  
											  
											  nil];
						if (self.request != nil) {
							self.request = nil;
						}

						NSString *strUrl = [WebServiceContainer getServiceURL:LOGIN_WITH_FB withParameters:nil];
						self.request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:FALSE];
                        if (self.request == nil) {
                            [HUD hide:YES];
                        }
                        else{
                            [self.request setDelegate:self];
                            [self.request setTag:2];
                        }
//						self.request.delegate = self;
//						self.request.tag = 2;
						strUrl = nil;
						
					}
					//					else{
					//						//go for sign up
					//					}
				}
			}
			else if (request.tag == 2){
				//its login response
				NSMutableDictionary *dic = nil;
				
				if ([response isKindOfClass:[NSDictionary class]]) {
					if (((NSDictionary *)response).count>0) {
						dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)response];
					}
				}
				else if ([response isKindOfClass:[NSArray class]]){
					if (((NSArray *)response).count > 0) {
						dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[response objectAtIndex:0]];
					}
				}
				[dic setValue:[Validation getDecryptedTextForString:[dic valueForKey:@"Pwd"] isGeneral:TRUE] forKey:LOGIN_USER_KEY];
				[Validation setAllKeyValueFromData:dic];
                [Validation setMatTrackingForRegisterAndLogin:dic index:1];
				[Validation CancelOnGoingRequests:self.request];
                appDelegate.selectedMenuIndex = 0;
                //[self performSegueWithIdentifier:NOTIFICATION_VC sender:nil];
                //        [self performSegueWithIdentifier:NOTIFICATION_VC sender:nil];
 //               UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
                
                [UIView transitionWithView:self.navigationController.view
                                  duration:0.5
                                   options:UIViewAnimationOptionTransitionCrossDissolve
                                animations:^{
                                    [self.navigationController pushViewController:ivc animated:NO];
                                }
                                completion:nil];

			}
			response = nil;
		}
		else if ([[dicResponse valueForKey:STATUS] intValue] == 0){
			//it means user does not exists
			//go for sign up
			if (request.tag == 1) {
				[[NSUserDefaults standardUserDefaults] setValue:[DataValidation checkNullString:[NSString stringWithFormat:@"%@",[self.dicFbData valueForKey:@"id"]]] forKey:FB_ID];
                [[NSUserDefaults standardUserDefaults] setValue:[DataValidation checkNullString:[NSString stringWithFormat:@"%@",[self.dicFbData valueForKey:@"PhotoPath"]]] forKey:LOGIN_USER_PHOTOPATH];
				[[NSUserDefaults standardUserDefaults] synchronize];
				[Validation CancelOnGoingRequests:self.request];
				[self performSegueWithIdentifier:SIGNUP_VC sender:nil];
			}
			else if (request.tag == 2){
				//login failed
			}
		}
		else{
			[Validation showToastMessage:@"Request Failure" displayDuration:ERROR_MSG_DURATION];
		}
	}

	[HUD hide:YES];
	
	
	dicResponse = nil;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
	if (self.request != nil) {
		self.request = nil;
	}
}

@end
