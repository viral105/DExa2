//
//  RecordingOptionHBlabVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/15/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "RecordingOptionHBlabVC.h"
#import "MBProgressHUD.h"
#import "UserConversationChatVC.h"
#import "ASIFormDataRequest.h"
#import "SetVideoAndPrivacyVC.h"

@interface RecordingOptionHBlabVC ()<MBProgressHUDDelegate> {
    MBProgressHUD *HUD;
}

@end

@implementation RecordingOptionHBlabVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSArray *array = [self.navigationController viewControllers];
    for (int i=0;i<array.count;i++) {
        if ([[array objectAtIndex:i] isKindOfClass:[CreateHBlabVC class]]) {
            NSLog(@"going in loop");
            self.childController = [array objectAtIndex:i];
            self.delegate = self.childController;
        }
        
    }
    NSLog(@"%@",appDelegate.dic_NotificationReleatedData);
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    
    
    self.arrData = [[NSArray alloc] init];
    [self LoadViewSetting];
    [self get_BannerListWithUsers];
    
    if ([[self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count-2] isKindOfClass:[CaptureImageHBlabVC class]] || [[self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count-2] isKindOfClass:[SetVideoAndPrivacyHBlabVC class]]) {
        self.btnHelpVideo.hidden = YES;
    }
}
-(void)viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
    [super viewWillAppear:animated];
    [self.tblData reloadData];
    
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    if ([self.timer isValid]) {
        [self.timer invalidate];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)LoadViewSetting{
    
    self.view.backgroundColor = UIColorFromRGB(0Xefefef);
    
    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
    [self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    self.tblData.showsVerticalScrollIndicator = NO;
    self.tblData.showsHorizontalScrollIndicator = NO;
    self.tblData.transform = CGAffineTransformMakeRotation(-M_PI * 0.5);
    self.tblData.backgroundColor = [UIColor whiteColor];
    
    //temporary commented
    //    if ([UIScreen mainScreen].bounds.size.height == 480) {// Done by viral for ipad campatible screen as client wants it to give demo to others
    //        [self.tblData setFrame:CGRectMake(0, 64+155+10+25,320, 100)];
    //    }
    //    else{
    //        [self.tblData setFrame:CGRectMake(0, 64+155+10+25,320, 160)];
    //    }
    
    if ([UIScreen mainScreen].bounds.size.height == 480) {
        [self.tblData setFrame:CGRectMake(0, 110, 320, 100)];
    }
    else{
        [self.tblData setFrame:CGRectMake(0, 110, 320, 160)];
    }
    
    self.tblData.pagingEnabled = YES;
    
    NSLog(@"%@",appDelegate.dic_NotificationReleatedData);
    
    if ([[appDelegate.dic_NotificationReleatedData valueForKey:BlabType] isEqualToString:@"2"]) {
        //vidiBlab
        [self.btnRecord setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        [self.btnRecord.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Bold size:20]];
        //[self.btnRecord setTitle:@"Recroded Video" forState:UIControlStateNormal];
        //        [self.btnRecord setImage:[UIImage imageNamed:@"btn_original_video.png"] forState:UIControlStateNormal];
        self.btnRecord.tag = 2;
        self.btnVidiBlaboverAudio.hidden = NO;
        [self.btnPreRecordedCategory setImage:[UIImage imageNamed:@"btn_sendBlab_From_category_small.png"] forState:UIControlStateNormal];
        [self.btnRecord setImage:[UIImage imageNamed:@"btn_original_video_small.png"] forState:UIControlStateNormal];
        [self.btnVidiBlaboverAudio setImage:[UIImage imageNamed:@"btn_vidi_blabover_small.png"] forState:UIControlStateNormal];
        
        int yPoint = self.btnPreRecordedCategory.frame.origin.y;
        [self.btnPreRecordedCategory setFrame:CGRectMake(self.btnPreRecordedCategory.frame.origin.x, yPoint, self.btnPreRecordedCategory.frame.size.width, 64)];
        yPoint+=64+10;
        
        [self.btnRecord setFrame:CGRectMake(self.btnRecord.frame.origin.x, yPoint, self.btnRecord.frame.size.width, 64)];
        yPoint+=64+10;
        
        [self.btnVidiBlaboverAudio setFrame:CGRectMake(self.btnVidiBlaboverAudio.frame.origin.x, yPoint, self.btnVidiBlaboverAudio.frame.size.width, 64)];
    }
}

-(void)get_BannerListWithUsers{
    
    [self.view setUserInteractionEnabled:NO];
    NSString *strUrl = [WebServiceContainer getServiceURL:FEATURED_BANNER_LIST withParameters:nil];
    self.requestAFNetworking = [AFNetworkingDataTransaction sharedManager];
    [self.requestAFNetworking SetCallForURL:strUrl WithDic:nil isAddHeader:TRUE];
    if (self.requestAFNetworking._currentRequest == nil) {
        [self.view setUserInteractionEnabled:YES];
        [HUD hide:YES];
    }
    else{
        [self.requestAFNetworking setDelegate:self];
        [self.requestAFNetworking setTag:1];
    }
    //    [self.requestAFNetworking setDelegate:self];
    //    [self.requestAFNetworking setTag:1];
    
    strUrl = nil;
    NSLog(@"call initiated");
}

- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
    
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    NSLog(@"successResponseWithData in = %@",dicResponse);
    if (appDelegate.currentVc == self) {
        if (dicResponse != nil) {
            
            if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                [UIView beginAnimations:nil context:nil];
                [UIView setAnimationDuration:0.2];
                Validation.viewPullToRefresh.alpha = 0;
                [UIView commitAnimations];
                NSLog(@"dic = %@",dicResponse);
                [HUD hide:YES];
                [appDelegate callLogOutService];
            }
            else{
                if (tag == 1) {
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        
                        if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                            
                            //received
                            id response = [dicResponse objectForKey:RESPONSE];
                            if (response != nil) {
                                NSArray *arr = [NSArray arrayWithArray:(NSArray *)response];
                                self.arrData = arr;
                            }
                            response = nil;
                            [self.tblData reloadData];
                        }
                    }
                    [self.view setUserInteractionEnabled:YES];
                }
                else if (tag == 2) {
                    //send notification
                    
                    // [HUD hide:YES];
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        
                        if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                            NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
                            // [Validation showToastMessage:@"Sent" displayDuration:3];
                            __block UIImageView *imageView;
                            UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                            imageView = [[UIImageView alloc] initWithImage:image];
                            [self.timer1 invalidate];
                            HUD.customView = imageView;
                            HUD.mode = MBProgressHUDModeText;
                            HUD.labelText = @"Sent";
                            imageView = nil;
                            [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
                            
                        }
                        else{
                            
                            if ([[dicResponse objectForKey:RESPONSE] isKindOfClass:[NSArray class]]) {
                                
                                //[Validation showToastMessage:[[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] displayDuration:ERROR_MSG_DURATION];
                                HUD.mode = MBProgressHUDModeText;
                                HUD.delegate = self;
                                HUD.detailsLabelFont = [UIFont boldSystemFontOfSize:16];
                                HUD.detailsLabelText = [[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] ;
                                [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:4];
                            }
                            else{
                                [HUD hide:YES];
                                
                            }
                            
                        }
                    }
                }
                
                request = nil;
            }
        }
    }
    
}

- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}

#pragma mark    UIButton methods

-(IBAction)btnOwnRecordClicked:(id)sender{
    if (self.btnRecord.tag == 2) {
        //vidi blab
        [self sendNotifMsgAtIndex];
    }
    else{
        if ([self isHeadsetPluggedIn]) {
            [self getMicePermission];
        }
        [self performSegueWithIdentifier:RECORD_HBLAB_VC sender:nil];
    }
}
-(void)getMicePermission{
    
    NSError *error;
    [[AVAudioSession sharedInstance] setCategory:
     AVAudioSessionCategoryPlayAndRecord error:&error];
    [[AVAudioSession sharedInstance] requestRecordPermission:^(BOOL response){
        if (!response) {
            //	NSLog(@"Microphone mute");
        }
    }];
}

- (BOOL)isHeadsetPluggedIn {
    AVAudioSessionRouteDescription* route = [[AVAudioSession sharedInstance] currentRoute];
    for (AVAudioSessionPortDescription* desc in [route outputs]) {
        if ([[desc portType] isEqualToString:AVAudioSessionPortHeadphones])
            return YES;
    }
    [Validation setAudioPropertyForRecording];
    return NO;
    
}
-(IBAction)btnStoreClicked:(id)sender{
    
    [self performSegueWithIdentifier:NOTIF_OPTION_HBLAB_VC sender:nil];
}

-(IBAction)btnBackClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return tableView.frame.size.width;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    // return self.arrData.count;
    if (![self.timer isValid] && self.arrData.count>0) {
        [self performSelector:@selector(startTimer) withObject:nil afterDelay:1];
    }
    return ((int)self.arrData.count)*100;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellIdentifier = @"cellIdentifier";
    
    RecordOptionBannerCell *cell = (RecordOptionBannerCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    NSUInteger actualRow = indexPath.row % ((int)self.arrData.count);
    NSLog(@"indexPath = %d",(int)actualRow);
    [cell clearsContextBeforeDrawing];
    [cell setBannerControlls:[self.arrData objectAtIndex:actualRow]];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self btnStoreClicked:nil];
}

-(void)startTimer{
    
    if ([self.timer isValid]) {
        [self.timer invalidate];
    }
    
    self.timer = [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(showCellAtIndex) userInfo:nil repeats:YES];
}

-(void)showCellAtIndex{
    if ([appDelegate.currentVc isKindOfClass:[self class]]) {
        NSArray *arr = [self.tblData indexPathsForVisibleRows];
        if (arr.count>1) {
            //        NSIndexPath
            NSIndexPath *path = [arr lastObject];
            //     NSLog(@"%@", path);
            if (path.row+1 < (((int)self.arrData.count)*100)) {
                [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:path.row+1 inSection:path.section] atScrollPosition:UITableViewScrollPositionTop animated:YES];
            }
        }
        else{
            NSIndexPath *path = [arr objectAtIndex:0];
            //        NSLog(@"%@", path);
            if (path.row+1 < (((int)self.arrData.count)*100)) {
                [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:path.row+1 inSection:path.section] atScrollPosition:UITableViewScrollPositionTop animated:YES];
            }
        }
    }
}

-(void)sendNotifMsgAtIndex  {
    
    NSString *strCaption = [NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:ImageCaption]];
    
    NSString *strHashId = [appDelegate.dic_NotificationReleatedData valueForKey:@"HashConversationID"];
    
    NSString *strPath = [appDelegate.dic_NotificationReleatedData valueForKey:CapturedVideo];
    
    NSString *strReplyToOneBlabId = [NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:REPLY_TO_ONE_BLAB_ID]];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    
    if ([fm fileExistsAtPath:strPath]) {
        NSLog(@"file exist");
    }
    NSMutableData *data;
    if(![self.delegate respondsToSelector:@selector(passBlabDataForHBlab:)]) {
        
        data = [NSMutableData dataWithContentsOfFile:strPath];
    }
    
    [HUD show:YES];
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                [NSDictionary dictionaryWithObjectsAndKeys:(strHashId.length>0)?[appDelegate.dic_NotificationReleatedData valueForKey:@"HashConversationID"]:@"0",KeyValue,@"HashConversationID",KeyName, nil],@"1",
                                [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"2",
                                [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"CategoryID",KeyName, nil],@"3",
                                [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SubCategoryID",KeyName, nil],@"4",
                                [NSDictionary dictionaryWithObjectsAndKeys:@"2",KeyValue, BlabType, KeyName, nil],@"5",
                                [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:strCaption].length > 0)?strCaption:@"",KeyValue,@"Caption",KeyName, nil],@"6",
                                [NSDictionary dictionaryWithObjectsAndKeys:((data!= nil)?data:@""),KeyValue,@"VideoData",KeyName, nil],@"7",
                                [NSDictionary dictionaryWithObjectsAndKeys:((strReplyToOneBlabId.length == 0)?@"":strReplyToOneBlabId),KeyValue,@"ReplyID",KeyName, nil],@"8",
                                [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"9",
                                nil];
    
    if([self.delegate respondsToSelector:@selector(passBlabDataForHBlab:)]) {
        [dic setObject:[NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"VideoData",KeyName, nil] forKey:@"7"];
        [self.delegate passBlabDataForHBlab:dic];
        [HUD hide:YES];
        [self popToCreateHBlab];
        return;
    }
    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_HASH_MESSAGE withParameters:nil];       //SEND_TEST_MSG     //SEND_NOTIF_MSG
    
    AFNetworkingDataTransaction *request = [AFNetworkingDataTransaction sharedManager];
    //[request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    [request SetCallForURLWithImg:strUrl WithDic:dic isAddHeader:TRUE forLoader:HUD];
    
    if (request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:2];
        HUD.mode = MBProgressHUDModeDeterminate;
        HUD.delegate = self;
        HUD.labelText = @"Sending blab";
        
        [request._currentRequest setUploadProgressBlock:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) {
            double percentDone = (double)totalBytesWritten / (double)totalBytesExpectedToWrite;
            //Upload Progress bar here
            NSLog(@"progress updated(percentDone) : %f", percentDone);
            [HUD setProgress:percentDone];
            if (percentDone == 1.0) {
                [self.timer invalidate];
                HUD.mode = MBProgressHUDModeIndeterminate;
                HUD.labelText = @"";
            }
        }];
        
        
        
        
        //     ASIFormDataRequest *requestData = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
        //     if (requestData == nil) {
        //         [HUD hide:YES];
        //     }
        //     else{
        //     [requestData setDelegate:self];
        //     [requestData setTag:1];
        //
        //     }
        //-----------------------
    }
}

-(void)sendNotifMsgAtIndex1  {
    
    HUD.mode = MBProgressHUDModeDeterminate;
    HUD.delegate = self;
    HUD.labelText = @"Sending blab";
    self.progress = [[UIProgressView alloc] initWithFrame:CGRectZero] ;
    [self.progress setProgressViewStyle: UIProgressViewStyleBar];
    
    [self.progress setFrame:CGRectMake(([[UIScreen mainScreen]bounds].size.height-160)/2,181,160,10)];
    [self.view addSubview:self.progress];
    
    
    NSArray *arrSelectedIds = [NSArray arrayWithArray:(NSArray *)[appDelegate.dic_NotificationReleatedData valueForKey:SelectedIds]];
    BOOL isGroupNotif = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue];
    BOOL isNotifSendToAll = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_NotifSendToAll] boolValue];
    NSString *strCaption = [NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:ImageCaption]];
    
    [HUD show:YES];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];           //SEND_NOTIF_MSG
    
    ASIFormDataRequest *requestData1 = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
    
    [requestData1 setDelegate:self];
    
    [requestData1 addRequestHeader:@"userid" value:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]];
    NSString *strT1 = [Validation GetUTCDate];
    [requestData1 addRequestHeader:@"T1" value:strT1];
    [requestData1 addRequestHeader:@"T2" value:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE]];
    
    [requestData1 setPostValue:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]] forKey:@"SenderID"];
    [requestData1 setPostValue:(isGroupNotif)?@"":[NSString stringWithFormat:@"%@",[arrSelectedIds componentsJoinedByString:@"|"]] forKey:@"ReceiverIDs"];
    [requestData1 setPostValue:@"0" forKey:@"Ctype"];
    [requestData1 setPostValue:(isGroupNotif)?[NSString stringWithFormat:@"%@",[arrSelectedIds componentsJoinedByString:@"|"]]:@"0" forKey:@"GroupIDs"];
    [requestData1 setPostValue:@"0" forKey:@"SubCatID"];
    [requestData1 setPostValue:@"0" forKey:@"ID"];
    [requestData1 setPostValue:@"IOS" forKey:@"OS"];
    
    [requestData1 setPostValue:[NSString stringWithFormat:@"%@",(isNotifSendToAll)?@"true":@"false"] forKey:@"AllFriend"];
    [requestData1 setPostValue:([DataValidation checkNullString:strCaption].length > 0)?strCaption:@"" forKey:@"Caption"];
    [requestData1 setPostValue:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:IsPublicImg]] forKey:IsPublicImg];
    [requestData1 setPostValue:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:RequestedKeepStatus]] forKey:RequestedKeepStatus];
    [requestData1 setPostValue:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:BlabType]] forKey:BlabType];
    
    NSString *strPath = [appDelegate.dic_NotificationReleatedData valueForKey:CapturedVideo];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    
    if ([fm fileExistsAtPath:strPath]) {
        NSLog(@"file exist");
    }
    NSMutableData *data = [NSMutableData dataWithContentsOfFile:strPath];
    [requestData1 addData:data withFileName:@"userSound.mp4" andContentType:@"multipart/form-data" forKey:@"VideoData"];
    
    self.progress.progress = 0.0;
    self.progress.hidden = YES;
    [requestData1 setUploadProgressDelegate:self.progress];
    [requestData1 setShouldContinueWhenAppEntersBackground:YES];
    
    requestData1.tag = 1;
    [requestData1 startAsynchronous];
    
    strUrl = nil;
    
    self.timer1 = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(setProgressFORHUD:) userInfo:nil repeats:YES];
    
    //-----------------------
    
}

- (void)setProgressFORHUD:(float)progress {
    //   NSLog(@"actual progress = %f",self.progress.progress);
    // int prog = (round(self.progress.progress*100));
    [HUD setProgress:self.progress.progress];
    if (self.progress.progress == 1.0) {
        [self.timer invalidate];
        HUD.mode = MBProgressHUDModeIndeterminate;
        HUD.labelText = @"";
    }
}
-(IBAction)btnHelpVideo_Clicked:(id)sender{
    self.viewVideoContainer.hidden = NO;
    self.moviePlayer = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:@"http://upload.blabeey.com//HelpVideo/NGP17AE4C1614691_Video_1.mp4"]];
    
    self.moviePlayer.moviePlayer.shouldAutoplay = YES;
    
    [self.moviePlayer.moviePlayer prepareToPlay];
    
    self.moviePlayer.view.frame = CGRectMake(0, 0, DEVICE_WIDTH, DEVICE_HEIGHT);
    self.moviePlayer.moviePlayer.controlStyle = MPMovieControlStyleNone;
    
    [self.moviePlayer.moviePlayer play];
    self.moviePlayer.moviePlayer.scalingMode = MPMovieScalingModeAspectFit;
    [self.viewVideoContainer addSubview:self.moviePlayer.view];
    [self.viewVideoContainer bringSubviewToFront:self.btnClose];
    [self.view bringSubviewToFront:self.viewVideoContainer];
}
-(IBAction)btnCloseVideo_Clicked:(id)sender{
    if (self.moviePlayer) {
        [self.moviePlayer.moviePlayer stop];
        [self.moviePlayer.view removeFromSuperview];
        self.moviePlayer = nil;
    }
    self.viewVideoContainer.hidden = YES;
}

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
    
    NSError *error = nil;
    
    NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
                                                                 options:0
                                                                   error:&error];
    
    if (dicResponse != nil){
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if (request.tag == 1) {
                        //send notification
                        
                        // [HUD hide:YES];
                        NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
                        // [Validation showToastMessage:@"Sent" displayDuration:3];
                        __block UIImageView *imageView;
                        UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                        imageView = [[UIImageView alloc] initWithImage:image];
                        [self.timer1 invalidate];
                        HUD.customView = imageView;
                        HUD.mode = MBProgressHUDModeText;
                        HUD.labelText = @"Sent";
                        imageView = nil;
                        [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
                        
                    }
                }
            }
            else{
                [HUD hide:YES];
                if (self.arrData.count == 0) {
                    [AlertHandler alertTitle:MESSAGE message:@"No Blabeey found under this category.\nPlease try another category." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
    
    self.requestAFNetworking = nil;
    dicResponse = nil;
}

- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
-(void)popToCreateHBlab{
    
    //    [Validation cleanNotifcationRelatedDicData];
    
    [HUD hide:YES];
    
    //    self.isNotifSentMsgVisible = NO;
    //    [self.request CancleOngoingRequest];
    //    self.request = nil;
    
    NSArray *arr = [self.navigationController viewControllers];
    //    BOOL isGotPopViewController = FALSE;
    
    
    //    [self removeFilesFromDir];
    
    for (UIViewController *v in arr) {
        
        if ([v isKindOfClass:[CreateHBlabVC class]]) {
            [self.navigationController popToViewController:v animated:YES];
            break;
        }
    }
    
}
-(void)popToNotifListScreen{
    
    [Validation cleanNotifcationRelatedDicData];
    
    [HUD hide:YES];
    
    
//    NSArray *arr = [self.navigationController viewControllers];
    BOOL isGotPopViewController = FALSE;
    
    //remove recorded file
    if ([[NSFileManager defaultManager] fileExistsAtPath:[appDelegate.vedioURL absoluteString]]) {
        [[NSFileManager defaultManager] removeItemAtPath:[appDelegate.vedioURL absoluteString] error:NULL];
    }
    
    NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
        [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
    }
    
/*
    for (UIViewController *v in arr) {
        if ([v isKindOfClass:[HBlabConversation class]]) {
            isGotPopViewController = TRUE;
            [self.navigationController popToViewController:v animated:YES];
            break;
        }
        
    }
*/
    if ([[self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count-2] isKindOfClass:[CaptureImageHBlabVC class]] || [[self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count-2] isKindOfClass:[SetVideoAndPrivacyHBlabVC class]]) {
        isGotPopViewController = TRUE;
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count-3] animated:YES];
    }
    else{
        isGotPopViewController = TRUE;
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count-2] animated:YES];
    }
    
    if (!isGotPopViewController) {
        
        if (appDelegate.selectedMenuIndex>0) {
            appDelegate.selectedMenuIndex = 0;
        }
        
        SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
        
        [UIView transitionWithView:self.navigationController.view
                          duration:0.5
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.navigationController pushViewController:ivc animated:NO];
                        }
                        completion:^(BOOL finished){[self removeViewControllersFromStack];}];
    }
    
}

-(void)removeViewControllersFromStack{
    //   NSArray *arrVC = self.navigationController.viewControllers;
    for (id vc in self.navigationController.viewControllers){
        if ([vc isKindOfClass:[FavoritesVC class]]) {
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[SearchFriendVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[OtherFriendNotifListVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[SettingsVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[CategoryListForUploadVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[GroupListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[UserListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[RecordingOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[SetVideoAndPrivacyVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
    }
    
}

-(void)removeFromNavigationController:(UIViewController *)controller animated:(BOOL)animated {
    
    NSMutableArray *allViewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];;
    [allViewControllers removeObjectIdenticalTo:controller];
    self.navigationController.viewControllers = allViewControllers;
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
