//
//  HashBlabHomeVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 5/11/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HashBlabHomeCVCell.h"
#import "HBlabConversation.h"

@interface HashBlabHomeVC : UIViewController<AFNetworkingDataTransactionDelegate,UICollectionViewDataSource,UICollectionViewDelegate,UIActionSheetDelegate,HBlabConversationDelegate>{
    IBOutlet UICollectionView *cvFeatured;
    IBOutlet UICollectionView *cvRecommanded;
}

@property (nonatomic, strong) IBOutlet UIButton             *btnMenu;
@property (nonatomic, strong) IBOutlet UILabel             *lblTitle;
@property (nonatomic, assign) BOOL isLoadChannelFromNotif;
@property (nonatomic, strong) IBOutlet UIView *viewVideoContainer;
@property (nonatomic, strong) IBOutlet UIButton *btnClose;
@property (nonatomic,strong)MPMoviePlayerViewController *moviePlayer;
-(void)showNotificationChannel;
-(void)callGetFeatured;
@end
