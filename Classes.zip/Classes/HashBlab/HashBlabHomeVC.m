//
//  HashBlabHomeVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 5/11/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "HashBlabHomeVC.h"
#define PageSize 10

@interface HashBlabHomeVC ()<MBProgressHUDDelegate> {
    MBProgressHUD *HUD;
    NSMutableArray *arrFeatured;
    NSMutableArray *arrRecommanded;
    int pageCounterFeatured;
    int pageCounterRecommended;
    BOOL isDataNullFeatured;
    BOOL isDataNullRecommended;
}
@property (nonatomic, strong) NSMutableArray *arrFeatured;
@property (nonatomic, strong) NSMutableArray *arrRecommanded;
@property (nonatomic, assign) BOOL isDataNullFeatured;
@property (nonatomic, assign) BOOL isDataNullRecommended;
@end

@implementation HashBlabHomeVC
@synthesize arrFeatured,arrRecommanded,isDataNullFeatured,isDataNullRecommended;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    pageCounterFeatured = 1;
    pageCounterRecommended = 1;
    self.arrFeatured = [NSMutableArray new];
    self.arrRecommanded = [NSMutableArray new];
    [self LoadViewSetting];
    [self callGetFeatured];
}
- (void)viewWillAppear:(BOOL)animated{
    [self.btnMenu removeTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    [self.btnMenu addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
    appDelegate.currentVc = self;
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];

}
-(void)viewWillDisappear:(BOOL)animated{
    self.isLoadChannelFromNotif = NO;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)updateList:(NSMutableDictionary*)dicConversationDetail indexOfObj:(int)indexOfObj cntArr:(int)cntArr{
    if (cntArr==0) {
        [self.arrFeatured replaceObjectAtIndex:indexOfObj withObject:dicConversationDetail];
    }
    else if (cntArr==1) {
        [self.arrRecommanded replaceObjectAtIndex:indexOfObj withObject:dicConversationDetail];
    }
}
-(void)showNotificationChannel{
    HBlabConversation *obj = [self.storyboard instantiateViewControllerWithIdentifier:@"HBlabConversation"];
    obj.cntArr = 2;
    NSArray *arrapnsTags = [appDelegate.arrAPNS valueForKey:apnsTag];
    
    int index = (int)[arrapnsTags indexOfObject:[NSNumber numberWithInt:(int)appDelegate.validation.apnsPopUp.btnPlay.tag]];
    NSDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[appDelegate.arrAPNS objectAtIndex:index]];

    obj.strConvoIdFromNotif = [NSString stringWithFormat:@"%@",[dic valueForKey:@"ConversationID"]];
//    [obj.dicConversationDetail setObject:[dic valueForKey:@"ConversationID"] forKey:@"ID"];
    
    [HUD hide:YES];
    [self.navigationController pushViewController:obj animated:YES];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"SGHBlabConversation"]) {

        NSArray *arr = (NSArray*)sender;
        HBlabConversation *obj = segue.destinationViewController;
        if ([[arr objectAtIndex:1] intValue]==0){
            obj.dicConversationDetail = [NSMutableDictionary dictionaryWithDictionary:[self.arrFeatured objectAtIndex:[[arr objectAtIndex:0] intValue]]];
            obj.cntArr = 0;
        }
        else{
            obj.dicConversationDetail = [NSMutableDictionary dictionaryWithDictionary:[self.arrRecommanded objectAtIndex:[[arr objectAtIndex:0] intValue]]];
            obj.cntArr = 1;
        }
        obj.delegate = self;
        obj.indexOfObj = [[arr objectAtIndex:0] intValue];
        
    }

    if ([segue.identifier isEqualToString:@"SGActiveHBlab"]) {
        ActiveHBlabVC *objVc = [segue destinationViewController];
        objVc.isFromHomeScreen = NO;
    }
}

-(void)LoadViewSetting{
    self.view.backgroundColor = UIColorFromRGB(0Xefefef);
//    [self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    // [self.btnDelete setBackgroundColor:UIColorFromRGB(0Xff5252)];
    
    //-----
//    self.tblData.allowsMultipleSelectionDuringEditing = YES;
//    [self.tblData setValue:[UIColor grayColor] forKeyPath:@"multiselectCheckmarkColor"];
    //-----
    
    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
    [self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
//    [self.lbl_NoDataAvailable setTextColor:TWITTER_BLUE_COLOR];
//    [self.lbl_NoDataAvailable setShadowColor:[UIColor clearColor]];
//    
//    self.strLoggedInUserId = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]];
}

#pragma mark Web Service Call

-(void)callGetFeatured{
    [HUD show:YES];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",pageCounterFeatured],KeyValue,@"PageNo",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
                         nil];
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_ALL_FEATURED_HASHBLAB withParameters:nil];
    AFNetworkingDataTransaction   *request = [AFNetworkingDataTransaction sharedManager];
    [request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:1];
    }
    
    
    strUrl = nil;
}
-(void)callGetRecommanded{
    [HUD show:YES];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",pageCounterRecommended],KeyValue,@"PageNo",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_ALL_RECOMMENDED_HASHBLAB withParameters:nil];
    AFNetworkingDataTransaction   *request = [AFNetworkingDataTransaction sharedManager];
    [request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:2];
    }
    
    
    strUrl = nil;
}
- (void)successResponseWithData:(id)request withTag:(int)tag{
        NSLog(@"tag = %d",tag);
        
        NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];

        
        if (dicResponse != nil) {
            
            if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]) {
                
                if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                    
                    NSLog(@"dic = %@",dicResponse);
                    [HUD hide:YES];
                    [appDelegate callLogOutService];
                }
                else{
                    if (tag == 1) {
                        //featured
                        if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                            
                            if ([dicResponse objectForKey:RESPONSE] != nil) {
                                id response = [dicResponse objectForKey:RESPONSE];
                                
                                NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                                [self.arrFeatured addObjectsFromArray:arr];
                                
                                self.isDataNullFeatured = NO;
                                if (arr.count < PageSize) {
                                    self.isDataNullFeatured = YES;
                                }
                                
                                [cvFeatured reloadData];
                                
                                if (pageCounterFeatured==1) {
                                    [self performSelectorInBackground:@selector(callGetRecommanded) withObject:nil];
                                }
                                else{
                                    [HUD hide:YES];
                                }
                                
                                arr = nil;
                                response = nil;
                                
                                
                            }
                            else{
                                [HUD hide:YES];
                            }
                        }
                        else{
                            self.isDataNullFeatured = YES;
                            [HUD hide:YES];
                            if (pageCounterFeatured==1) {
                                [HUD show:YES];
                                [self performSelectorInBackground:@selector(callGetRecommanded) withObject:nil];
                            }
                            
                        }
                    }
                    else if (tag == 2){
                        //recommended
                        
                        if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                            
                            if ([dicResponse objectForKey:RESPONSE] != nil) {
                                id response = [dicResponse objectForKey:RESPONSE];
                                
                                NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                                [self.arrRecommanded addObjectsFromArray:arr];
                                self.isDataNullRecommended = NO;
                                if (arr.count < PageSize) {
                                    self.isDataNullRecommended = YES;
                                }
                                
                                
                                [cvRecommanded reloadData];
                                [HUD hide:YES];
                                arr = nil;
                                response = nil;
                                if (self.isLoadChannelFromNotif) {
                                    [self showNotificationChannel];
                                }
                                
                            }
                            else{
                                [HUD hide:YES];
                            }
                        }
                        else{
                            self.isDataNullRecommended = YES;
                            [HUD hide:YES];
                        }
                    }
                }
            }
            else{
                NSLog(@"dic = %@",dicResponse);
                [HUD hide:YES];
                [appDelegate callLogOutService];
            }
        }
        else{
            [HUD hide:YES];
        }
        request = nil;


    //    [self performSelector:@selector(getTestNotif) withObject:nil afterDelay:10];
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}

#pragma mark IBAction

-(IBAction)btnMore_Clicked:(id)sender{
    NSLog(@"btnmore clicked");
    UIActionSheet *aSheet = [[UIActionSheet alloc] initWithTitle:@"Select" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"My Channels",@"Create new Channels",@"Search Channels",@"View followed Channels", nil];
    [aSheet showInView:self.view];
}
-(IBAction)btnHelpVideo_Clicked:(id)sender{
    self.viewVideoContainer.hidden = NO;
    self.moviePlayer = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:@"http://upload.blabeey.com//HelpVideo/XHQC6FO9V841479_Video_1.mp4"]];
    
    self.moviePlayer.moviePlayer.shouldAutoplay = YES;
    
    [self.moviePlayer.moviePlayer prepareToPlay];
    
    self.moviePlayer.view.frame = CGRectMake(0, 0, DEVICE_WIDTH, DEVICE_HEIGHT);
    self.moviePlayer.moviePlayer.controlStyle = MPMovieControlStyleNone;
    
    [self.moviePlayer.moviePlayer play];
    self.moviePlayer.moviePlayer.scalingMode = MPMovieScalingModeAspectFit;
    [self.viewVideoContainer addSubview:self.moviePlayer.view];
    [self.viewVideoContainer bringSubviewToFront:self.btnClose];
    [self.view bringSubviewToFront:self.viewVideoContainer];
}
-(IBAction)btnCloseVideo_Clicked:(id)sender{
    if (self.moviePlayer) {
        [self.moviePlayer.moviePlayer stop];
        [self.moviePlayer.view removeFromSuperview];
        self.moviePlayer = nil;
    }
    self.viewVideoContainer.hidden = YES;
}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"%d",(int)buttonIndex);
    if (buttonIndex==0) {
        [self performSegueWithIdentifier:@"SGActiveHBlab" sender:self];
    }
    else if (buttonIndex==1){
        ActiveHBlabVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:@"ActiveHBlabVC"];
        obj.isFromHomeScreen = YES;
        [self.navigationController pushViewController:obj animated:NO];
//        [self performSegueWithIdentifier:@"SGActiveHBlab" sender:self];
    }
    else if (buttonIndex==2){
        [self performSegueWithIdentifier:@"HashBlabSearchVC" sender:self];
    }
    else if (buttonIndex==3){
        [self performSegueWithIdentifier:@"FollowedChannelVC" sender:self];
    }
}
#pragma mark UICollectionView

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if (collectionView==cvFeatured) {
        return self.arrFeatured.count;
    }
    else{
        return self.arrRecommanded.count;
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    HashBlabHomeCVCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"hashblabhome" forIndexPath:indexPath];
    cell.imgViewHashBlab.image = nil;
    cell.imgViewHashBlab.imageURL = nil;
    [cell.timer invalidate];
    cell.timer = nil;
    cell.stepper = nil;
    cell.viewCircularProgressTime.progressTintColor = [UIColor clearColor];
    cell.viewCircularProgressTime.progress = 0;
    
    if (collectionView==cvFeatured) {
        if (!self.isDataNullFeatured && (indexPath.row == (self.arrFeatured.count+1) || indexPath.row == self.arrFeatured.count-1)){
            pageCounterFeatured ++;
            [self performSelectorInBackground:@selector(callGetFeatured) withObject:nil];
        }
        cell.dicSel = [self.arrFeatured objectAtIndex:indexPath.row];
    }
    else{
        if (!self.isDataNullRecommended && (indexPath.row == (self.arrRecommanded.count+1) || indexPath.row == self.arrRecommanded.count-1)){
            pageCounterRecommended ++;
            [self performSelectorInBackground:@selector(callGetRecommanded) withObject:nil];

        }
        cell.dicSel = [self.arrRecommanded objectAtIndex:indexPath.row];
    }
    
    [cell setUI];
    
//    cell.lblTime.text = [NSString stringWithFormat:@"%d",(int)indexPath.row];
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if (collectionView==cvFeatured) {
        NSArray *arr = [NSArray arrayWithObjects:[NSString stringWithFormat:@"%d",(int)indexPath.row],@"0", nil];
        [self performSegueWithIdentifier:@"SGHBlabConversation" sender:arr];
    }
    else{
        NSArray *arr = [NSArray arrayWithObjects:[NSString stringWithFormat:@"%d",(int)indexPath.row],@"1", nil];
        [self performSegueWithIdentifier:@"SGHBlabConversation" sender:arr];
    }
}
/*
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionView *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 4; // This is the minimum inter item spacing, can be more
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}
*/
@end
