//
//  ActiveHBlabCell.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/9/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "ActiveHBlabCell.h"
#define lblHblabCategory_width 150

@implementation ActiveHBlabCell

- (void)awakeFromNib {
    // Initialization code
    
    [Validation setCorners:self.imgViewUser];
    self.lblUserName.textColor = UIColorFromRGB(0X00c2d9);
    self.lblViews.textColor = UIColorFromRGB(0X727478);
    self.lblFollowers.textColor = UIColorFromRGB(0X727478);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setUI{
    self.lblRemainingTime.textColor = UIColorFromRGB(0X43a047);
    
    self.imgViewHBlab.imageURL = [NSURL URLWithString:[self.dicSel valueForKey:@"ImagePath"]];
    if ([[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"ActiveStatus"]] intValue]==0) {
        self.imgViewHBlab.frame = CGRectMake(5, 10, 66, 66);
        self.viewCircularProgress.hidden = YES;
        self.lblRemainingTime.hidden = YES;
    }
    else{
        self.imgViewHBlab.frame = CGRectMake(9, 15, 57, 57);
        self.viewCircularProgress.hidden = NO;
        self.lblRemainingTime.hidden = NO;
    }
    [Validation setCorners:self.imgViewHBlab];
    self.imgViewUser.imageURL = [NSURL URLWithString:[self.dicSel valueForKey:@"PhotoPath"]];
    self.lblHBlabName.text = [self.dicSel valueForKey:@"Name"];
    self.lblHblabCategory.text = [self.dicSel valueForKey:@"HashCategory"];
    self.lblRemainingTime.text = [self.dicSel valueForKey:@"RemainingTime"];
    self.lblUserName.text = [self.dicSel valueForKey:@"CreaterName"];
    self.lblViews.text = [NSString stringWithFormat:@"%@ Views",[self.dicSel valueForKey:@"TotalView"]];
    
    self.viewCircularProgress.progressTintColor = UIColorFromRGB(0X43a047);//green color
    self.viewCircularProgress.thicknessRatio = 0.15;
    self.viewCircularProgress.clockwiseProgress = 1;
    //    self.viewCircularProgressTime.progress = 1;
    
    if ([[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"RemainingPercentage"]] floatValue]<=2500.0) {
        self.viewCircularProgress.progressTintColor = UIColorFromRGB(0Xe53935);//red color
        self.lblRemainingTime.textColor = UIColorFromRGB(0Xe53935);
    }
    [self.viewCircularProgress setProgress:[[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"RemainingPercentage"]] floatValue]/10000];
    
    if ([DataValidation checkNullString:self.lblHBlabName.text].length > 0) {
        [self.lblHBlabName setTextColor:[Validation getColorForAlphabet:self.lblHBlabName.text]];
    }
    
    self.lblHBlabName.text = [HASHBLAB_CHARACTER stringByAppendingFormat:@"%@",self.lblHBlabName.text];
    
    //category Name
    NSString *str = self.lblHblabCategory.text;
    str = (([[DataValidation checkNullString:str] length] == 0)?@"Private":str);
    NSMutableParagraphStyle *paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.lineBreakMode = NSLineBreakByTruncatingTail;
    
    CGRect size = [str boundingRectWithSize:CGSizeMake(lblHblabCategory_width, self.lblHblabCategory.frame.size.height)
                             options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                          attributes:@{NSFontAttributeName:self.lblHblabCategory.font, NSParagraphStyleAttributeName: paragraph}
                             context:nil];
    

    self.lblHblabCategory.frame = CGRectMake(self.lblHblabCategory.frame.origin.x, self.lblHblabCategory.frame.origin.y, (size.size.width>lblHblabCategory_width)?lblHblabCategory_width:(size.size.width+4), self.lblHblabCategory.frame.size.height);
    self.lblHblabCategory.text = str;
    [self.lblHblabCategory setTextColor:[UIColor whiteColor]];
    [self.lblHblabCategory setBackgroundColor:[Validation getColorForAlphabet:self.lblHblabCategory.text]];
}
@end
