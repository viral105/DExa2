//
//  ActiveHBlabVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/9/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ActiveHBlabCell.h"
#import "HBlabConversation.h"
#import "EditActiveChannelVC.h"

@interface ActiveHBlabVC : UIViewController<UITableViewDataSource,UITableViewDelegate,AFNetworkingDataTransactionDelegate>

@property (strong, nonatomic) IBOutlet UITableView *tblActiveHBlab;
@property (strong, nonatomic) IBOutlet UIButton *btnDelete;
@property (assign, nonatomic) BOOL isEditing;
@property (nonatomic, strong) NSMutableSet					*selectedRows;
- (IBAction)btnBack_Clicked:(id)sender;
- (IBAction)btnAdd_Clicked:(id)sender;
@property (nonatomic,assign) BOOL isFromHomeScreen;
@end
