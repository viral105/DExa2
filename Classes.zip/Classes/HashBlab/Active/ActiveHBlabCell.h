//
//  ActiveHBlabCell.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/9/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DACircularProgressView.h"

@interface ActiveHBlabCell : UITableViewCell

@property (strong, nonatomic) IBOutlet DACircularProgressView *viewCircularProgress;
@property (strong, nonatomic) IBOutlet AsyncImageView *imgViewHBlab;
@property (strong, nonatomic) IBOutlet UILabel *lblHBlabName;
@property (strong, nonatomic) IBOutlet UILabel *lblHblabCategory;
@property (strong, nonatomic) IBOutlet UILabel *lblRemainingTime;
@property (strong, nonatomic) IBOutlet AsyncImageView *imgViewUser;
@property (strong, nonatomic) IBOutlet UILabel *lblUserName;
@property (strong, nonatomic) IBOutlet UILabel *lblViews;
@property (strong, nonatomic) IBOutlet UILabel *lblFollowers;
@property (strong, nonatomic) IBOutlet UIButton *btnDelete;
@property (strong, nonatomic) IBOutlet UIButton *btnEdit;
@property (strong, nonatomic) NSDictionary *dicSel;

-(void)setUI;
@end
