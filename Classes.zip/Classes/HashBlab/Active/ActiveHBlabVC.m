//
//  ActiveHBlabVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/9/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "ActiveHBlabVC.h"
#define PageSize 10

@interface ActiveHBlabVC ()<MBProgressHUDDelegate>{
    MBProgressHUD *HUD;
    NSMutableArray *arrActiveHBlab;
    int pageCounter;
    BOOL isDataNull;
    
    int selectedIndex;
    
}
@property (nonatomic,strong)NSMutableArray *arrActiveHBlab;
@property (nonatomic,assign)BOOL isDataNull;
@end

@implementation ActiveHBlabVC
@synthesize arrActiveHBlab,isDataNull;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self LoadViewSetting];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    
    self.arrActiveHBlab = [NSMutableArray new];
    self.selectedRows = [NSMutableSet new];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void) viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
    if (self.isFromHomeScreen) {
        [self performSegueWithIdentifier:@"SGCreateHBlab" sender:self];
        self.isFromHomeScreen = NO;
    }
    else{
        [self.arrActiveHBlab removeAllObjects];
        pageCounter = 1;
        [self callGetActiveHBlab];
    }
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
}
-(void)LoadViewSetting{
    self.view.backgroundColor = UIColorFromRGB(0Xefefef);
    self.tblActiveHBlab.allowsMultipleSelectionDuringEditing = YES;
    [self.tblActiveHBlab setValue:[UIColor grayColor] forKeyPath:@"multiselectCheckmarkColor"];
    //    [self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    // [self.btnDelete setBackgroundColor:UIColorFromRGB(0Xff5252)];
    
    //-----
    //    self.tblData.allowsMultipleSelectionDuringEditing = YES;
    //    [self.tblData setValue:[UIColor grayColor] forKeyPath:@"multiselectCheckmarkColor"];
    //-----
    
    
    //    [self.lbl_NoDataAvailable setTextColor:TWITTER_BLUE_COLOR];
    //    [self.lbl_NoDataAvailable setShadowColor:[UIColor clearColor]];
    //
    //    self.strLoggedInUserId = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"SGHBlabConversation"]) {
        HBlabConversation *obj = segue.destinationViewController;
        obj.dicConversationDetail = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrActiveHBlab objectAtIndex:selectedIndex]];
    }
    if ([segue.identifier isEqualToString:@"SGCreateHBlab"]) {
        CreateHBlabVC *obj = [segue destinationViewController];
        obj.isFromHomeScreen = YES;
    }
    if ([segue.identifier isEqualToString:@"EditActiveChannelVC"]) {
        EditActiveChannelVC *obj = [segue destinationViewController];
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary*)sender];
        obj.dicSelEditChannel = dic;
    }
}


- (IBAction)btnBack_Clicked:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (IBAction)btnAdd_Clicked:(id)sender {
}
-(void)btnDeleteClicked:(id)sender{

    if (self.selectedRows.count>0) {
        [self showDeleteBtn];
    }
    else{
        [self hideDeleteBtn];
    }

    if ([self.tblActiveHBlab isEditing]) {
        [self.selectedRows removeAllObjects];
        self.isEditing = NO;
        [self.tblActiveHBlab setEditing:NO animated:YES];
        
        [self hideDeleteBtn];
        [self.tblActiveHBlab reloadData];
    }
    else{
        self.isEditing = YES;
        [self.tblActiveHBlab setEditing:YES animated:YES];
        [self.tblActiveHBlab reloadData];
        
    }
}
-(void)showDeleteBtn{
    
    self.btnDelete.hidden = FALSE;
    [Validation removeAdviewFromSuperView];
    //self.tblData.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-(64)-(64));
}

-(void)hideDeleteBtn{
    
    [UIView beginAnimations:@"moveDown" context:nil];
    [UIView setAnimationDuration:0.5];
    //	self.tblData.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-64);
    self.btnDelete.hidden = TRUE;
    [UIView commitAnimations];
    
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
}
-(IBAction)btnDeleteSelected:(id)sender{
    
    //	[Validation showLoadingIndicator];
    [HUD show:YES];
    
//    if (self.request !=nil) {
//        self.request = nil;
//    }
    
    NSString *strIds = @"";
    for (NSNumber *num in self.selectedRows) {
        NSLog(@"%@",num);
        if (strIds.length == 0) {
            strIds = [NSString stringWithFormat:@"%@",[[self.arrActiveHBlab objectAtIndex:[num intValue]] valueForKey:@"ID"]];
        }
        else{
            strIds = [strIds stringByAppendingFormat:@"|%@",[[self.arrActiveHBlab objectAtIndex:[num intValue]] valueForKey:@"ID"]];
        }
    }
    
    //self.selectedIndex = (int)((UIButton *)sender).tag;
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:strIds,KeyValue,@"HashConvIDs",KeyName, nil],@"2",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:DELETE_HASH_CONVERSATION_BY_ID withParameters:nil];
    AFNetworkingDataTransaction *request = [AFNetworkingDataTransaction sharedManager];
    [request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:2];
    }
    //    [self.request setDelegate:self];
    //    [self.request setTag:2];
    
    //	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    //	self.request.delegate = self;
    //	self.request.tag = 2;
    strUrl = nil;
}
-(IBAction)btnEdit_Clicked:(id)sender{
    UIButton *btn = (UIButton*)sender;
    [self performSegueWithIdentifier:@"EditActiveChannelVC" sender:[self.arrActiveHBlab objectAtIndex:btn.tag]];
}
#pragma mark Web Service Call

-(void)callGetActiveHBlab{
    [HUD show:YES];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
//                         [NSDictionary dictionaryWithObjectsAndKeys:@"30446",KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
                         nil];
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_MY_HASH_CONTOS withParameters:nil];
    AFNetworkingDataTransaction   *request = [AFNetworkingDataTransaction sharedManager];
    [request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:1];
    }
    strUrl = nil;
}
- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    
    NSLog(@"tag = %d",tag);
    
    NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    
    if (dicResponse != nil) {
        
        if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]) {
            
            if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                
                NSLog(@"dic = %@",dicResponse);
                [HUD hide:YES];
                [appDelegate callLogOutService];
            }
            else{
                if (tag == 1) {
                    //featured
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        if ([dicResponse objectForKey:RESPONSE] != nil) {
                            id response = [dicResponse objectForKey:RESPONSE];
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            [self.arrActiveHBlab addObjectsFromArray:arr];
                            
                            self.isDataNull = NO;
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            
                            [self.tblActiveHBlab reloadData];
                            [HUD hide:YES];
                            
                            arr = nil;
                            response = nil;
                            
                            
                        }
                        else{
                            [HUD hide:YES];
                        }
                    }
                    else{
                        self.isDataNull = YES;
                        [self.tblActiveHBlab reloadData];
                        [HUD hide:YES];
                    }
                }
                else if (tag == 2){
                    //delte notif
                    BOOL is_NewServiceCall = FALSE;
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        
                        if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                            
                            //received
                            [HUD hide:YES];
                            [self.selectedRows removeAllObjects];
                            pageCounter = 1;
                            self.isDataNull = NO;
                            [self.arrActiveHBlab removeAllObjects];
                            self.isEditing = NO;
                            [self.tblActiveHBlab setEditing:NO];
                            
                            
                            [self.btnDelete setHidden:YES];
                            [HUD show:YES];
                            [self performSelectorInBackground:@selector(callGetActiveHBlab) withObject:nil];
                            is_NewServiceCall = YES;
                            
                        }
                    }
                    else{
                        [HUD hide:YES];
                    }
                    [self hideDeleteBtn];
                    if (self.arrActiveHBlab.count == 0 && is_NewServiceCall == FALSE) {
                        // self.lbl_NoDataAvailable.text = (self.isSentNotifList)?NO_SENT_NOTIF:NO_RECEIVED_NOTIF;
//                        self.lbl_NoDataAvailable.hidden = FALSE;
                        
                    }
                }
            }
        }
        else{
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
    }
    else{
        [HUD hide:YES];
    }
    request = nil;
    
    
    //    [self performSelector:@selector(getTestNotif) withObject:nil afterDelay:10];
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrActiveHBlab.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ActiveHBlabCell *cell = [tableView dequeueReusableCellWithIdentifier:@"activehblab"];
    
    cell.imgViewHBlab.image = nil;
    cell.imgViewHBlab.imageURL = nil;
    cell.imgViewUser.image = nil;
    cell.imgViewUser.imageURL = nil;
    
    if (!self.isEditing) {
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    else{
        [cell setSelectionStyle:UITableViewCellSelectionStyleGray];//.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    if (!self.isDataNull && (indexPath.row == (self.arrActiveHBlab.count+1) || indexPath.row == self.arrActiveHBlab.count-1)){
        pageCounter ++;
        [self performSelectorInBackground:@selector(callGetActiveHBlab) withObject:nil];
    }
    cell.dicSel = [self.arrActiveHBlab objectAtIndex:indexPath.row];
    
    [cell setUI];
    
    [cell.btnDelete addTarget:self action:@selector(btnDeleteClicked:) forControlEvents:UIControlEventTouchUpInside];
/*    if (self.isEditing) {
        UIView *bgColorView = [[UIView alloc] init];
        bgColorView.backgroundColor = [UIColor clearColor];
        [cell setSelectedBackgroundView:bgColorView];
        cell.multipleSelectionBackgroundView = bgColorView;
        cell.userInteractionEnabled = YES;
        [cell setEditing:YES animated:YES];
    }
*/
    cell.btnEdit.tag = (int)indexPath.row;
    [cell.btnEdit addTarget:self action:@selector(btnEdit_Clicked:) forControlEvents:UIControlEventTouchUpInside];

    return cell;
}
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    // Update the delete button's title based on how many items are selected.
    NSNumber *rowNsNum = [NSNumber numberWithUnsignedInt:(int)indexPath.row];
    
    if ( [self.selectedRows containsObject:rowNsNum] )
        [self.selectedRows removeObject:rowNsNum];
    
    if (self.selectedRows.count>0) {
        [self showDeleteBtn];
    }
    else{
        [self hideDeleteBtn];
        self.isEditing = NO;
        [self.tblActiveHBlab setEditing:NO animated:YES];
        
        [self.tblActiveHBlab reloadData];
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (!self.tblActiveHBlab.isEditing) {
        selectedIndex = (int)indexPath.row;
        [self performSegueWithIdentifier:@"SGHBlabConversation" sender:self];
    }
    else{
    NSNumber *rowNsNum = [NSNumber numberWithUnsignedInt:(int)indexPath.row];
    /*
     public enum UserType
     {
     Admin = 1,
     User = 2,
     AdminUser = 3
     }
     */
//    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:[self.arrActiveHBlab objectAtIndex:indexPath.row]];
//    int userType = [[NSString stringWithFormat:@"%@",[dic valueForKey:USERTYPE]] intValue];
    
//    if (userType == 2) {
        if ( [self.selectedRows containsObject:rowNsNum] )
            [self.selectedRows removeObject:rowNsNum];
        else
            [self.selectedRows addObject:rowNsNum];
        
//    }
    
    if (self.selectedRows.count>0) {
        [self showDeleteBtn];
    }
    else{
        [self hideDeleteBtn];
        self.isEditing = NO;
        [self.tblActiveHBlab setEditing:NO animated:YES];
        
        [self.tblActiveHBlab reloadData];
    }
    }
}
@end
