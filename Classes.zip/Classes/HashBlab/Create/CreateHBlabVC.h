//
//  CreateHBlabVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/10/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SelectHBlabCatSubCat.h"
#import "GeneralDelegate.h"
#import "CaptureImageHBlabVC.h"
#import "SetVideoAndPrivacyHBlabVC.h"
#import "ActiveHBlabVC.h"
#import "HashBlabHomeVC.h"
#import "FollowedChannelVC.h"

@interface CreateHBlabVC : UIViewController<UITextFieldDelegate,UITextViewDelegate,UIScrollViewDelegate,SelectHBlabCatSubCatDelegate,UIActionSheetDelegate,GeneralDelegate,AFNetworkingDataTransactionDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (strong, nonatomic) IBOutlet UIScrollView *scrlView;
@property (strong, nonatomic) IBOutlet UIView *viewContainer;
@property (strong, nonatomic) IBOutlet UIButton *btnImage;
@property (strong, nonatomic) IBOutlet UIButton *btnBannerImage;
@property (strong, nonatomic) IBOutlet UITextField *tfName;
@property (strong, nonatomic) IBOutlet UIButton *btnCategory;
@property (strong, nonatomic) IBOutlet UITextView *tvDescription;
@property (strong, nonatomic) NSMutableDictionary *dicSelAllData;
@property (strong, nonatomic) IBOutlet UIButton *btnCreate;
@property (strong, nonatomic) IBOutlet UIButton *btn24Hours;
@property (strong, nonatomic) IBOutlet UIButton *btnPermanent;
@property (nonatomic,assign) BOOL isFromHomeScreen;
@property (nonatomic, strong) UIImagePickerController	*imagePicker;

- (IBAction)btnBlabOption_Clicked:(id)sender;
- (IBAction)btnBack_Clicked:(id)sender;

@end
