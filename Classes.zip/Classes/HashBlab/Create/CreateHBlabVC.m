//
//  CreateHBlabVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/10/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "CreateHBlabVC.h"

@interface CreateHBlabVC ()<MBProgressHUDDelegate>{
    BOOL isKeyBoardOpen;
    MBProgressHUD *HUD;
    BOOL isBlabSelected;
    int timePeriod;// 0 means Permanent 1 means 24 hours
}

@end

@implementation CreateHBlabVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
    self.dicSelAllData = [NSMutableDictionary new];
    
//    [self.btnCategory setTitle:@"Blab Category" forState:UIControlStateNormal];
    [self.btnCategory setTitle:@"" forState:UIControlStateNormal];
    appDelegate.is90SecondsVideoRec = YES;
    self.scrlView.contentSize = CGSizeMake(self.viewContainer.frame.size.width, self.viewContainer.frame.size.height);
    timePeriod=1;
    
    //bhavik 14-Oct-2015
    self.btnBannerImage.imageView.contentMode = UIViewContentModeScaleAspectFill;
    self.btnBannerImage.clipsToBounds = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
    [self checkValidation];
    
    [self.viewContainer bringSubviewToFront:self.btnImage];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"SGSelectHBlabCatSubCat"]) {
//        [self hideOtherKeyboard];
//        [self hideDescriptionKeyBoard];
        [self hideOtherKeyboard];
        SelectHBlabCatSubCat *obj = [segue destinationViewController];
        obj.delegate = self;
    }
    else if ([segue.identifier isEqualToString:RECORD_OPTION_VC] || [segue.identifier isEqualToString:CAPTURE_IMAGE_VC] || [segue.identifier isEqualToString:SET_VIDEO_PRIVACY_VC]) {
        
        if (appDelegate.dic_NotificationReleatedData != nil) {
            appDelegate.dic_NotificationReleatedData = nil;
        }
        
        //  NSDictionary dic = [NSDictionary dictionaryWithDictionary:(NSDictionary )[self.arrData lastObject]];
        
        
/*        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    [NSArray arrayWithObjects:strReceiverId, nil],SelectedIds,
                                                    [NSNumber numberWithBool:isGroupMessage],IS_GroupNotif,
                                                    [NSNumber numberWithBool:NO],IS_NotifSendToAll,
                                                    @"0",BlabType,
                                                    nil];
*/
        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    @"0",BlabType,
                                                    @"true",IsPublicImg,
                                                    @"2",RequestedKeepStatus,
                                                    nil];
    }
}
#pragma mark    UIActionsheet Delegate

//-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
//    
//    
//}
- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if (actionSheet.tag==101) {
        NSLog(@"button index = %d",(int)buttonIndex);
        
        NSLog(@"clickedButtonAtIndex = %@", appDelegate.dic_NotificationReleatedData);
        if (buttonIndex == actionSheet.cancelButtonIndex) {
            
        }
        else if (buttonIndex == 0){
            //only blab
            appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                        @"0",BlabType,
                                                        @"true",IsPublicImg,
                                                        @"2",RequestedKeepStatus,
                                                        [NSNumber numberWithBool:YES],IS_GroupNotif,
                                                        nil];
            
            RecordingOptionHBlabVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:RECORD_OPTION_HBlab_VC];
            [self.navigationController pushViewController:obj animated:YES];
        }
        else if (buttonIndex == 1){
            //blab with image
            appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                        @"0",BlabType,
                                                        @"true",IsPublicImg,
                                                        @"2",RequestedKeepStatus,
                                                        [NSNumber numberWithBool:YES],IS_GroupNotif,
                                                        nil];
            
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:STORYBOARD bundle:nil];
            CaptureImageHBlabVC *ivc = [storyboard instantiateViewControllerWithIdentifier:CAPTURE_IMAGE_HBLAB_VC];
            [self.navigationController pushViewController:ivc animated:NO];
        }
        else if (buttonIndex == 2){
            //blab with Video
            if ([[NSFileManager defaultManager] fileExistsAtPath:VIDEO_RECORDING_FOLDER]) {
                //when folder exists
                NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
                if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
                    [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
                }
            }
            appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                        @"2",BlabType,
                                                        @"true",IsPublicImg,
                                                        @"2",RequestedKeepStatus,
                                                        [NSNumber numberWithBool:YES],IS_GroupNotif,
                                                        nil];
            
            
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:STORYBOARD bundle:nil];
            SetVideoAndPrivacyHBlabVC *ivc = [storyboard instantiateViewControllerWithIdentifier:SET_VIDEO_PRIVACY_HBLAB_VC];
            [self.navigationController pushViewController:ivc animated:NO];
        }
        
        NSLog(@"clickedButtonAtIndex = %@", appDelegate.dic_NotificationReleatedData);
    }
    else if (actionSheet.tag==102){
        if (buttonIndex == actionSheet.cancelButtonIndex) {
        }
        else{
            if (buttonIndex == 0) {
                //camera
                if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
                {
                    // code here
                    [self ShowCamera];
                }
                else{
                    [AlertHandler alertTitle:ALERT message:@"Camera not available." delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                }
            }
            else if (buttonIndex == 1){
                if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
                    //code here
                    [self ShowLibrary];
                }
                else{
                    [AlertHandler alertTitle:ALERT message:@"Library not available." delegate:self tag:2 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                }
            }
        }
    }
    
}
#pragma mark IBACTION

- (IBAction)btnBlabOption_Clicked:(id)sender {
    [self hideOtherKeyboard];
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Select" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:Only_Yap,Yap_With_Image,Yap_With_Video, nil];
    [action setTag:101];
    [action showInView:self.view];
}
- (IBAction)btnBack_Clicked:(id)sender{
    appDelegate.is90SecondsVideoRec = NO;
    if (self.isFromHomeScreen) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (IBAction)btnCreate_Clicked:(id)sender{
    [HUD show:YES];
    [self performSelectorInBackground:@selector(callCreateHashBlab) withObject:nil];
}
-(IBAction)btnSelectBanner_Clicked:(id)sender{
    UIActionSheet *actionCameraOption = [[UIActionSheet alloc] initWithTitle:@"Options" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:@"Camera",@"Library", nil];
    [actionCameraOption setTag:102];
    [actionCameraOption showInView:self.view];
}
-(IBAction)btnTimePeriod_Clicked:(id)sender{
    UIButton *btn = (UIButton*)sender;
    if(btn.tag==1){
        // permanent
        timePeriod=0;
        [self.btn24Hours setTitleColor:UIColorFromRGB(0X616161) forState:UIControlStateNormal];
        [self.btnPermanent setTitleColor:UIColorFromRGB(0X00C2D9) forState:UIControlStateNormal];
    }
    else{
        // 24 hours
        timePeriod=1;
        [self.btn24Hours setTitleColor:UIColorFromRGB(0X00C2D9) forState:UIControlStateNormal];
        [self.btnPermanent setTitleColor:UIColorFromRGB(0X616161) forState:UIControlStateNormal];
    }
}
#pragma mark TextField Delegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self.tfName resignFirstResponder];
    [self checkValidation];
//    [self hideDescriptionKeyBoard];
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (textField==self.tfName) {
        if ([string isEqualToString:@""]) {
            return TRUE;
        }
        else if ((self.tfName.text.length+1)>50) {
            return FALSE;
        }
        else{
            return TRUE;
        }
    }
    else{
        return TRUE;
    }
}
#pragma mark TextView Delegate

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    if (textView==self.tvDescription) {
        UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardOutside_Tap:)];
        [tapGes setNumberOfTapsRequired:1];
        [self.scrlView setUserInteractionEnabled:YES];
        [self.scrlView addGestureRecognizer:tapGes];
        tapGes=nil;
    }
    
    return YES;
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if (textView==self.tvDescription) {
        if ([text isEqualToString:@"\n"]) {

            [self.tvDescription resignFirstResponder];
            [self checkValidation];
            return NO;
        }
        NSLog(@"%d",(int)(self.tvDescription.text.length+1));
        if ([text isEqualToString:@""]) {
            return TRUE;
        }
        else if ((self.tvDescription.text.length+1)>150) {
            return FALSE;
        }
        else{
            return TRUE;
        }
    }
    else{
        return TRUE;
    }
    return YES;
}

#pragma mark Other Delegate Methods

-(void)displayCatName:(NSDictionary*)dicSel{
    NSLog(@"%@",dicSel);
    [self.btnCategory setTitle:[dicSel valueForKey:@"Name"] forState:UIControlStateNormal];
    
    NSLog(@"self.btnCategory.titleLabel.text %@",self.btnCategory.currentTitle);
//    self.dicSelHBlabCatSubcat = dicSel;
    
    if ([dicSel objectForKey:@"HashSubCategory"] == nil) {
        NSLog(@"subcat");
        [self.dicSelAllData setValue:[dicSel valueForKey:@"CategoryID"] forKey:@"HashCatID"];
        [self.dicSelAllData setValue:[dicSel valueForKey:@"ID"] forKey:@"HashSubCatID"];
    }
    else{
        NSLog(@"category");
        [self.dicSelAllData setValue:[dicSel valueForKey:@"ID"] forKey:@"HashCatID"];
        [self.dicSelAllData setValue:@"0" forKey:@"HashSubCatID"];
    }
}
-(void)passBlabDataForHBlab:(NSDictionary *)dicSel{
    NSLog(@"%@",dicSel);
    isBlabSelected = YES;
    appDelegate.is90SecondsVideoRec = NO;
    [Validation setCorners:self.btnImage];
    NSLog(@"%d",(int)[dicSel allKeys].count);
    UIImage *img;
    for (int i=0; i<[dicSel allKeys].count; i++) {
        NSLog(@"%@",[dicSel valueForKey:[[dicSel allKeys] objectAtIndex:i]]);
        if ([[[dicSel valueForKey:[[dicSel allKeys] objectAtIndex:i]] valueForKey:@"keyName"] isEqualToString:@"ImgData"] && ![[[dicSel valueForKey:[[dicSel allKeys] objectAtIndex:i]] valueForKey:@"keyValue"] isEqual:@""]) {
            img = (UIImage *)[[dicSel valueForKey:[[dicSel allKeys] objectAtIndex:i]] valueForKey:@"keyValue"];
        }
        [self.dicSelAllData setValue:[[dicSel valueForKey:[[dicSel allKeys] objectAtIndex:i]] valueForKey:@"keyValue"] forKey:[[dicSel valueForKey:[[dicSel allKeys] objectAtIndex:i]] valueForKey:@"keyName"]];
    }
    
    if ([[NSString stringWithFormat:@"%@",[self.dicSelAllData valueForKey:BlabType]] isEqualToString:@"0"]&&img==nil) {
        [self.btnImage setImage:[UIImage imageNamed:@"#blab_simple_blab.png"] forState:UIControlStateNormal];
    }
    else if ([[NSString stringWithFormat:@"%@",[self.dicSelAllData valueForKey:BlabType]] isEqualToString:@"2"]) {
        [self.btnImage setImage:[appDelegate.dic_NotificationReleatedData valueForKey:CapturedImage] forState:UIControlStateNormal];
    }
    else{
        [self.btnImage setImage:img forState:UIControlStateNormal];
    }
 
//    if (img!=nil) {
//        [self.btnImage setImage:img forState:UIControlStateNormal];
//    }
//    self.dicSelBlab = dicSel;

}
- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}
-(void)ShowCamera{
    self.imagePicker = [[UIImagePickerController alloc] init];
    self.imagePicker.delegate = self;
    self.imagePicker.sourceType =
    UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:self.imagePicker
                       animated:YES completion:nil];
}
-(void)ShowLibrary{
    if ([ALAssetsLibrary authorizationStatus] == ALAuthorizationStatusDenied) {
        [AlertHandler alertTitle:MESSAGE message:ALERT_FOR_PHOTO_LIBRARY_ACCESS delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
    else{
        self.imagePicker = [[UIImagePickerController alloc] init];
        self.imagePicker.delegate = self;
        self.imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentViewController:self.imagePicker
                           animated:YES completion:nil];
    }
}
-(void)hideImagePicker{
    [self.imagePicker dismissViewControllerAnimated:YES completion:nil];
}
/*
-(void)hideDescriptionKeyBoard{
    isKeyBoardOpen = NO;
    
}
 */
#pragma  mark	UIImagePickerController Delegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    //bhavik 14-Oct-2015
    [self.btnBannerImage setTitle:@"" forState:UIControlStateNormal];
    
    [self.btnBannerImage setBackgroundImage:info[UIImagePickerControllerOriginalImage] forState:UIControlStateNormal];
    
    // [self.btnBannerImage setImage:info[UIImagePickerControllerEditedImage] forState:UIControlStateNormal];
    
    [self hideImagePicker];
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    
    [self hideImagePicker];
}
#pragma mark Keyboard Hide-Show Handle

-(void)hideOtherKeyboard{
    [self.tfName resignFirstResponder];
    [self.tvDescription resignFirstResponder];
}

-(void)keyboardOutside_Tap:(UIGestureRecognizer*)gesView{
    [self hideOtherKeyboard];
    [self checkValidation];
//    [self hideDescriptionKeyBoard];
}

- (void)keyboardWillBeHidden:(NSNotification*)notification
{
    //    [self animateYPoint:44 viewToAnimate:self.viewContainerTextView];
    isKeyBoardOpen = NO;
//    NSDictionary *info = [notification userInfo];
//    CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    for (UIGestureRecognizer *recognizer in self.viewContainer.gestureRecognizers) {
        [self.scrlView removeGestureRecognizer:recognizer];
    }
    self.scrlView.contentOffset = CGPointMake(0, 0);
    self.scrlView.contentSize = CGSizeMake(self.viewContainer.frame.size.width, self.viewContainer.frame.size.height);
    self.scrlView.frame = CGRectMake(self.scrlView.frame.origin.x, self.scrlView.frame.origin.y, self.scrlView.frame.size.width, DEVICE_HEIGHT-64-50);
    NSLog(@"Hide $$$$$ %@",NSStringFromCGRect(self.scrlView.frame));
}
- (void)keyboardWillShow:(NSNotification*)notification {
    NSDictionary *info = [notification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    if (!isKeyBoardOpen) {
        isKeyBoardOpen = YES;
    }
    else{
        return;
    }
        if ([self.tvDescription isFirstResponder]) {
            
            
            isKeyBoardOpen =YES;
            self.scrlView.frame = CGRectMake(self.scrlView.frame.origin.x, self.scrlView.frame.origin.y, self.scrlView.frame.size.width, self.scrlView.frame.size.height-kbSize.height+50);
            self.scrlView.contentOffset = CGPointMake(0, self.viewContainer.frame.size.height/2);
            self.scrlView.contentSize = CGSizeMake(self.viewContainer.frame.size.width, self.viewContainer.frame.size.height);
        }
        else if ([self.tfName isFirstResponder]){
            isKeyBoardOpen =YES;
            self.scrlView.frame = CGRectMake(self.scrlView.frame.origin.x, self.scrlView.frame.origin.y, self.scrlView.frame.size.width, self.scrlView.frame.size.height-kbSize.height+50);
            self.scrlView.contentOffset = CGPointMake(0, 0);
            self.scrlView.contentSize = CGSizeMake(self.viewContainer.frame.size.width, self.viewContainer.frame.size.height);
            NSLog(@"show $$$$$ %@",NSStringFromCGRect(self.scrlView.frame));
        }
    
    
    //    [self animateYPoint:200 viewToAnimate:self.viewContainerTextView];
}
#pragma mark Web Service Call
-(void)checkValidation{
    NSLog(@"self.btnCategory.titleLabel.text %@",self.btnCategory.currentTitle);
    if (!isBlabSelected) {
        NSLog(@"blab not selected");
        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        self.btnCreate.hidden = YES;
    }
    else if (self.tfName.text.length==0){
        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        self.btnCreate.hidden = YES;
    }
    else if ([self.btnCategory.currentTitle isEqualToString:@""]){
        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        self.btnCreate.hidden = YES;
    }
    else if (self.tvDescription.text.length==0){
        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        self.btnCreate.hidden = YES;
    }
    else{
        [Validation removeAdviewFromSuperView];
        self.btnCreate.hidden = NO;
    }
}
-(void)callCreateHashBlab{
    
    NSString *strCaption = [self.dicSelAllData valueForKey:CaptionForImage];
    NSString *strBlabType = [self.dicSelAllData valueForKey:BlabType];
    NSString *strCategoryId = [self.dicSelAllData valueForKey:@"CategoryID"];
    NSString *strSubCategoryId = [self.dicSelAllData valueForKey:@"SubCategoryID"];
    NSString *strNewSoundID = [self.dicSelAllData valueForKey:@"NewSoundID"];
    UIImage *img = (UIImage*)[appDelegate.dic_NotificationReleatedData valueForKey:CapturedImage];
    NSString *strVideoUrl = [appDelegate.dic_NotificationReleatedData valueForKey:CapturedVideo];
    //bhavik 14-Oct-2015
    UIImage *imgBanner = [self.btnBannerImage backgroundImageForState:UIControlStateNormal];
    
    if ([DataValidation checkNullString:strCaption].length==0) {
        strCaption=@"";
    }
    if ([DataValidation checkNullString:strBlabType].length==0) {
        strBlabType=@"";
    }
    if ([DataValidation checkNullString:strCategoryId].length==0) {
        strCategoryId=@"";
    }
    if ([DataValidation checkNullString:strSubCategoryId].length==0) {
        strSubCategoryId=@"";
    }
    if ([DataValidation checkNullString:strNewSoundID].length==0) {
        strNewSoundID=@"";
    }
    NSData *videoData = nil;
    NSData *imgData = nil;
    NSData *imgBannerData = nil;
    if ([DataValidation checkNullString:strVideoUrl].length!=0) {
        videoData = [NSMutableData dataWithContentsOfFile:strVideoUrl];
    }
    if ([strBlabType isEqualToString:@"0"]&&![img isEqual:@""] && img!=nil) {
        imgData = [Validation compressImage:img];
    }
    //bhavik 14-Oct-2015
    if(![imgBanner isEqual:@""] && imgBanner!=nil)
    {
        imgBannerData = [Validation compressImage:imgBanner];
    }
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"HashConversationID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[self.tfName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]],KeyValue,@"HashName",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:[self.tvDescription.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]],KeyValue,@"HashDescription",KeyName, nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:[self.dicSelAllData valueForKey:@"HashCatID"],KeyValue,@"HashCatID",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:[self.dicSelAllData valueForKey:@"HashSubCatID"],KeyValue,@"HashSubCatID",KeyName, nil],@"6",
                         [NSDictionary dictionaryWithObjectsAndKeys:strCaption,KeyValue,@"Caption",KeyName, nil],@"7",
                         [NSDictionary dictionaryWithObjectsAndKeys:strBlabType,KeyValue,@"MsgType",KeyName, nil],@"8",
                         [NSDictionary dictionaryWithObjectsAndKeys:strCategoryId,KeyValue,@"CategoryID",KeyName, nil],@"9",
                         [NSDictionary dictionaryWithObjectsAndKeys:strSubCategoryId,KeyValue,@"SubCategoryID",KeyName, nil],@"10",
                         [NSDictionary dictionaryWithObjectsAndKeys:strNewSoundID,KeyValue,@"NewSoundID",KeyName, nil],@"11",
                         [NSDictionary dictionaryWithObjectsAndKeys:((imgData!= nil)?imgData:@""),KeyValue,@"ImgData",KeyName, nil],@"12",
                         [NSDictionary dictionaryWithObjectsAndKeys:((videoData!= nil)?videoData:@""),KeyValue,@"VideoData",KeyName, nil],@"13",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",timePeriod],KeyValue,@"ActiveStatus",KeyName, nil],@"14",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"15",
                         [NSDictionary dictionaryWithObjectsAndKeys:((imgBannerData!= nil)?imgBannerData:@""),KeyValue,@"HashImageData",KeyName, nil],@"16",
                         nil];
    
//    NSLog(@"dic final create hblab %@",dic);
    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_HASH_MESSAGE withParameters:nil];
    AFNetworkingDataTransaction   *request = [AFNetworkingDataTransaction sharedManager];
    [request SetCallForURLWithImg:strUrl WithDic:dic isAddHeader:TRUE forLoader:HUD];
    if (request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:1];
        if ([strBlabType intValue]==2) {
            HUD.mode = MBProgressHUDModeDeterminate;
            HUD.delegate = self;
            HUD.labelText = @"Sending blab";
            
            [request._currentRequest setUploadProgressBlock:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) {
                double percentDone = (double)totalBytesWritten / (double)totalBytesExpectedToWrite;
                //Upload Progress bar here
                NSLog(@"progress updated(percentDone) : %f", percentDone);
                [HUD setProgress:percentDone];
                if (percentDone == 1.0) {
                    //     [self.timer invalidate];
                    HUD.mode = MBProgressHUDModeIndeterminate;
                    HUD.labelText = @"";
                }
            }];
        }
        
    }
    strUrl = nil;
}
- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    
    NSLog(@"tag = %d",tag);
    
    NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    
    if (dicResponse != nil) {
        
        if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]) {
            
            if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                
                NSLog(@"dic = %@",dicResponse);
                [HUD hide:YES];
                [appDelegate callLogOutService];
            }
            else{
                if (tag == 1) {
                    //featured
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        if ([dicResponse objectForKey:RESPONSE] != nil) {
                            id response = [dicResponse objectForKey:RESPONSE];
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            [HUD hide:YES];
                            
                            [self performSelector:@selector(popToActiveHBlab:) withObject:[NSNumber numberWithInt:0]];
                            arr = nil;
                            response = nil;
                            
                            
                        }
                        else{
                            [HUD hide:YES];
                        }
                    }
                    else{
                        [HUD hide:YES];
                    }
                }
                else if (tag == 2){
                    //recommended
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        if ([dicResponse objectForKey:RESPONSE] != nil) {
                            id response = [dicResponse objectForKey:RESPONSE];
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                        }
                        else{
                            [HUD hide:YES];
                        }
                    }
                    else{
                        
                        [HUD hide:YES];
                    }
                }
            }
        }
        else{
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
    }
    else{
        [HUD hide:YES];
    }
    request = nil;
    
    
    //    [self performSelector:@selector(getTestNotif) withObject:nil afterDelay:10];
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}

-(void)popToActiveHBlab:(NSNumber*)isBlabSendFail{
    
    [Validation cleanNotifcationRelatedDicData];
    
    [HUD hide:YES];
    
//    self.isNotifSentMsgVisible = NO;
//    [self.request CancleOngoingRequest];
//    self.request = nil;
    
    NSArray *arr = [self.navigationController viewControllers];
    BOOL isGotPopViewController = FALSE;
    
    
    [self removeFilesFromDir];
    
    for (UIViewController *v in arr) {
        if ([isBlabSendFail boolValue]) {
            if ([v isKindOfClass:[NotificationVC class]]) {
                isGotPopViewController = TRUE;
                [self.navigationController popToViewController:v animated:YES];
                break;
            }
        }
        else{
            if ([v isKindOfClass:[ActiveHBlabVC class]]) {
                isGotPopViewController = TRUE;
                [self.navigationController popToViewController:v animated:YES];
                break;
            }
        }
    }
    
    
    if (!isGotPopViewController) {
        
        [self removeViewControllersFromStack];
        
        if (appDelegate.selectedMenuIndex>0) {
            appDelegate.selectedMenuIndex = 0;
        }
        SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
        
        [UIView transitionWithView:self.navigationController.view
                          duration:0.5
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.navigationController pushViewController:ivc animated:NO];
                        }
                        completion:nil];
    }
    
}

-(void)removeViewControllersFromStack{
    //   NSArray *arrVC = self.navigationController.viewControllers;
    for (id vc in self.navigationController.viewControllers){
        if ([vc isKindOfClass:[FavoritesVC class]]) {
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[SearchFriendVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[OtherFriendNotifListVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[SettingsVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[CategoryListForUploadVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[GroupListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[UserListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[RecordingOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
    }
    
}

-(void)removeFromNavigationController:(UIViewController *)controller animated:(BOOL)animated {
    
    NSMutableArray *allViewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];;
    [allViewControllers removeObjectIdenticalTo:controller];
    self.navigationController.viewControllers = allViewControllers;
    
}

-(void)removeFilesFromDir{
    NSError *error = nil;
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *arrPath = [fm contentsOfDirectoryAtPath:VIDEO_RECORDING_FOLDER error:&error];
    for (int i=0; i<arrPath.count; i++) {
        [fm removeItemAtPath:[VIDEO_RECORDING_FOLDER stringByAppendingPathComponent:[arrPath objectAtIndex:i]] error:&error];
    }
}
@end
