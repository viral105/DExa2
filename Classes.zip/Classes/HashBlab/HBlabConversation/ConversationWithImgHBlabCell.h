//
//  ConversationWithImgHBlabCell.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/16/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ConversationWithImgHBlabCellDelegate <NSObject>

-(void)btnBlabCreatorName_Clicked:(NSDictionary *)dic;
-(void)btnBlabCreatorImage_Clicked:(NSDictionary *)dic;

@end

@interface ConversationWithImgHBlabCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UIButton         *btnPlay;
@property (nonatomic, retain) IBOutlet AsyncImageView   *imgImage;
@property (nonatomic, retain) IBOutlet UIImageView      *imgPlay;
@property (nonatomic, retain) IBOutlet UIImageView      *imgPlayAnimation;
@property (nonatomic, strong) IBOutlet UILabel          *lblReplyToOneBlabName;
@property (nonatomic, strong) IBOutlet UILabel          *lblReplyToOneBlabTitle;
@property (nonatomic, strong) IBOutlet UILabel          *lblCategoryName;
@property (nonatomic, strong) IBOutlet UILabel          *lblSubCategoryName;
@property (nonatomic, strong) IBOutlet UILabel          *lblDuration;
@property (nonatomic, retain) IBOutlet UIImageView      *imgTimer;
@property (nonatomic, strong) IBOutlet UIButton         *btnFullScreen;
@property (nonatomic, strong) IBOutlet UILabel          *lblDescription;
@property (nonatomic, strong) IBOutlet UILabel          *lblLoopCount;
@property (nonatomic, strong) IBOutlet UIImageView      *imgBgDescription;


@property (nonatomic, strong) IBOutlet UIView           *viewButtonContainer;
@property (nonatomic, strong) IBOutlet UIButton         *btnLike;
@property (nonatomic, strong) IBOutlet UIButton         *btnReportAbuse;
@property (nonatomic, strong) IBOutlet UIButton         *btnReplyToOneBlab;
@property (nonatomic, strong) IBOutlet UIButton         *btnInstagramShare;
@property (nonatomic, strong) IBOutlet UIImageView      *imgSelected;
@property (nonatomic, strong) IBOutlet UIImageView      *imgPrivate;
@property (nonatomic, strong) IBOutlet UILabel          *lblBlabCreatorName;
@property (nonatomic, strong) IBOutlet UIButton         *btnBlabCreatorName;
@property (nonatomic, strong) IBOutlet UIButton         *btnBlabCreatorImage;
@property (nonatomic, strong) IBOutlet UILabel          *lblBlabFullDesc;
@property (nonatomic, strong) IBOutlet UIView           *viewBlabFullDesc;

@property (nonatomic, retain) IBOutlet AsyncImageView   *imgUserThumb;
@property (nonatomic, retain) IBOutlet UIButton         *btnUserThumb;

@property (nonatomic, strong) NSDictionary          *dicSelected;
@property (nonatomic, strong) id<ConversationWithImgHBlabCellDelegate> delegate;
@property (nonatomic, readwrite) CGSize                 categorySize;

-(void)setControlsInCellWithDictionary:(NSDictionary *)dic withUserId:(NSString *)strUserId isEdit:(BOOL)isEdit CreaterID:(NSString*)CreaterID;

-(IBAction)btnBlabCreatorName_Clicked:(id)sender;
-(IBAction)btnBlabCreatorImage_Clicked:(id)sender;
@end
