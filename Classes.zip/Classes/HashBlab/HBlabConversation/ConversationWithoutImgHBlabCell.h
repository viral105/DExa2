//
//  ConversationWithoutImgHBlabCell.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/16/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ConversationWithoutImgHBlabCellDelegate <NSObject>

-(void)btnBlabCreatorName_Clicked:(NSDictionary *)dic;
-(void)btnBlabCreatorImage_Clicked:(NSDictionary *)dic;

@end

@interface ConversationWithoutImgHBlabCell : UITableViewCell

@property (nonatomic, retain) IBOutlet AsyncImageView      *imgPlayContainer;

@property (nonatomic, strong) IBOutlet UIButton         *btnPlayContainer;
@property (nonatomic, retain) IBOutlet UIImageView      *imgPlay;
@property (nonatomic, retain) IBOutlet UIImageView      *imgPlayAnimation;
@property (nonatomic, strong) IBOutlet UILabel          *lblCategoryName;
@property (nonatomic, strong) IBOutlet UILabel          *lblReplyToOneBlabName;
@property (nonatomic, strong) IBOutlet UILabel          *lblReplyToOneBlabTitle;
@property (nonatomic, strong) IBOutlet UILabel          *lblSubCategoryName;
@property (nonatomic, retain) IBOutlet UIImageView      *imgTimer;
@property (nonatomic, strong) IBOutlet UILabel          *lblDuration;

@property (nonatomic, strong) IBOutlet UIView           *viewButtonContainer;
@property (nonatomic, strong) IBOutlet UIButton         *btnLike;
@property (nonatomic, strong) IBOutlet UIButton         *btnReplyToOneBlab;
@property (nonatomic, strong) IBOutlet UIButton         *btnReportAbuse;
@property (nonatomic, strong) IBOutlet UIButton         *btnForward;
@property (nonatomic, strong) IBOutlet UIImageView      *imgSelected;
@property (nonatomic, strong) IBOutlet UIImageView      *imgPrivate;
@property (nonatomic, strong) IBOutlet UILabel          *lblBlabCreatorName;
@property (nonatomic, strong) IBOutlet UIButton          *btnBlabCreatorName;
@property (nonatomic, strong) IBOutlet UIButton         *btnBlabCreatorImage;
@property (nonatomic, strong) IBOutlet UILabel          *lblBlabFullDesc;
@property (nonatomic, strong) IBOutlet UIView           *viewBlabFullDesc;


@property (nonatomic, strong) NSDictionary          *dicSelected;
@property (nonatomic, strong) id<ConversationWithoutImgHBlabCellDelegate> delegate;

@property (nonatomic, readwrite) CGSize                 categorySize;


-(void)setControlsInCellWithDictionary:(NSDictionary *)dic withUserId:(NSString *)strUserId isEdit:(BOOL)isEdit CreaterID:(NSString*)CreaterID;
-(IBAction)btnBlabCreatorName_Clicked:(id)sender;
-(IBAction)btnBlabCreatorImage_Clicked:(id)sender;
@end
