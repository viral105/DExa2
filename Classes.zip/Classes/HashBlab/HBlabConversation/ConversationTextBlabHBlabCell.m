//
//  ConversationTextBlabHBlabCell.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/16/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "ConversationTextBlabHBlabCell.h"
#define WIDTH_DESC           170
#define WIDTH_LBLTEXT_MORE      15
#define HEIGHT_LBLTEXT_MORE      15
#define IS_SELECTED             @"is_selected"

@implementation ConversationTextBlabHBlabCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setRightSideControls{
    float yPoint=10;
    float xPointViewLblContaner;
    
    self.imgSelected.frame = CGRectMake(10, yPoint, 30, 30);
    
    if (lblText.frame.size.height<19) {
        viewLblContaner.frame = CGRectMake(self.contentView.frame.size.width-lblText.frame.size.width-30, yPoint+15, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
        yPoint+=15;
    }
    else{
        viewLblContaner.frame = CGRectMake(self.contentView.frame.size.width-lblText.frame.size.width-30, yPoint, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
    }
    viewLblContaner.frame = CGRectMake(self.contentView.frame.size.width-lblText.frame.size.width-30, yPoint, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
    lblText.frame = CGRectMake(9, 5, lblText.frame.size.width, lblText.frame.size.height);
    imgViewTextTail.frame = CGRectMake(viewLblContaner.frame.size.width+viewLblContaner.frame.origin.x-7, viewLblContaner.frame.origin.y+viewLblContaner.frame.size.height-5, 14, 7);
    yPoint+=viewLblContaner.frame.size.height+10;
    
    //    if (viewLblContaner.frame.size.width>viewButtonContainer.frame.size.width) {
    xPointViewLblContaner = viewLblContaner.frame.origin.x;
    /*    }
     else{
     xPointViewLblContaner = self.contentView.frame.size.width-viewButtonContainer.frame.size.width;
     }
     */
    
    lblBlabCreatorName.frame = CGRectMake(xPointViewLblContaner-lblBlabCreatorName.frame.size.width-10, viewLblContaner.frame.origin.y+viewLblContaner.frame.size.height-lblBlabCreatorName.frame.size.height, lblBlabCreatorName.frame.size.width, lblBlabCreatorName.frame.size.height);
    
    self.imgUserThumb.frame = CGRectMake(xPointViewLblContaner-self.imgUserThumb.frame.size.width-15, lblBlabCreatorName.frame.origin.y-self.imgUserThumb.frame.size.height-5, self.imgUserThumb.frame.size.width, self.imgUserThumb.frame.size.height);
    
    
    viewButtonContainer.frame = CGRectMake(self.contentView.frame.size.width-viewButtonContainer.frame.size.width-10, yPoint, viewButtonContainer.frame.size.width, viewButtonContainer.frame.size.height);
    
    imgTimer.frame = CGRectMake(viewButtonContainer.frame.origin.x-imgTimer.frame.size.width-10, viewButtonContainer.frame.origin.y+10, imgTimer.frame.size.width, imgTimer.frame.size.height);
    
    lblDuration.frame = CGRectMake(imgTimer.frame.origin.x-40-3, viewButtonContainer.frame.origin.y+10, 40, lblDuration.frame.size.height);
    
    if (lblText.frame.size.height<19) {
        self.lblReplyToOneBlabTitle.frame = CGRectMake(self.imgUserThumb.frame.origin.x, self.imgUserThumb.frame.origin.y-16, 60, 12);
        self.lblReplyToOneBlabName.frame = CGRectMake(xPointViewLblContaner+self.lblReplyToOneBlabTitle.frame.size.width-50, self.imgUserThumb.frame.origin.y-16, 60, 12);
    }
    else{
        self.lblReplyToOneBlabTitle.frame = CGRectMake(xPointViewLblContaner, viewLblContaner.frame.origin.y-16, 60, 12);
        self.lblReplyToOneBlabName.frame = CGRectMake(xPointViewLblContaner+self.lblReplyToOneBlabTitle.frame.size.width, viewLblContaner.frame.origin.y-16, 60, 12);
    }
}
-(void)setLeftSideControls{
    float yPoint=10;
    float xPointViewLblContaner;
    
    self.imgSelected.frame = CGRectMake(self.contentView.frame.size.width-40, yPoint, 30, 30);
    if (lblText.frame.size.height<19) {
        viewLblContaner.frame = CGRectMake(17, yPoint+15, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
        yPoint+=15;
    }
    else{
        viewLblContaner.frame = CGRectMake(17, yPoint, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
    }
    
    lblText.frame = CGRectMake(9, 5, lblText.frame.size.width, lblText.frame.size.height);
    imgViewTextTail.frame = CGRectMake(viewLblContaner.frame.origin.x-7, viewLblContaner.frame.origin.y+viewLblContaner.frame.size.height-5, 14, 7);
    
    yPoint+=viewLblContaner.frame.size.height+10;
    
    
    //    if (viewLblContaner.frame.size.width>viewButtonContainer.frame.size.width) {
    xPointViewLblContaner = viewLblContaner.frame.origin.x+viewLblContaner.frame.size.width+10;
    /*    }
     else{
     xPointViewLblContaner = viewButtonContainer.frame.size.width+20;
     }
     */
    
    NSLog(@"----====> %f %f %f",viewLblContaner.frame.size.width,viewButtonContainer.frame.size.width,xPointViewLblContaner);
    
    lblBlabCreatorName.frame = CGRectMake(xPointViewLblContaner, viewLblContaner.frame.origin.y+viewLblContaner.frame.size.height-lblBlabCreatorName.frame.size.height, lblBlabCreatorName.frame.size.width, lblBlabCreatorName.frame.size.height);
    
    self.imgUserThumb.frame = CGRectMake(xPointViewLblContaner-2, lblBlabCreatorName.frame.origin.y-self.imgUserThumb.frame.size.height, self.imgUserThumb.frame.size.width, self.imgUserThumb.frame.size.height);
    
    
    viewButtonContainer.frame = CGRectMake(10, yPoint, viewButtonContainer.frame.size.width, viewButtonContainer.frame.size.height);
    
    imgTimer.frame = CGRectMake(viewButtonContainer.frame.origin.x+viewButtonContainer.frame.size.width+10, viewButtonContainer.frame.origin.y+10, imgTimer.frame.size.width, imgTimer.frame.size.height);
    
    lblDuration.frame = CGRectMake(imgTimer.frame.origin.x+imgTimer.frame.size.width+3, viewButtonContainer.frame.origin.y+10, 40, lblDuration.frame.size.height);
    
    if (lblText.frame.size.height<19) {
        self.lblReplyToOneBlabTitle.frame = CGRectMake(viewLblContaner.frame.origin.x, self.imgUserThumb.frame.origin.y-16, 60, 12);
        self.lblReplyToOneBlabName.frame = CGRectMake(self.lblReplyToOneBlabTitle.frame.origin.x+self.lblReplyToOneBlabTitle.frame.size.width, self.imgUserThumb.frame.origin.y-16, 60, 12);
    }
    else{
        self.lblReplyToOneBlabTitle.frame = CGRectMake(viewLblContaner.frame.origin.x, viewLblContaner.frame.origin.y-16, 60, 12);
        self.lblReplyToOneBlabName.frame = CGRectMake(self.lblReplyToOneBlabTitle.frame.origin.x+self.lblReplyToOneBlabTitle.frame.size.width, viewLblContaner.frame.origin.y-16, 60, 12);
    }
    
}
-(void)setUI:(NSDictionary*)dic withUserId:(NSString *)strUserId isEdit:(BOOL)isEdit CreaterID:(NSString*)CreaterID{
    self.dicSelected = dic;
    NSLog(@"cap** %@", [dic valueForKey:CaptionForImage]);
    NSData *decodedData = [[NSData alloc] initWithBase64EncodedString:[dic valueForKey:CaptionForImage] options:0];
    NSString *decodedString = [[NSString alloc] initWithData:decodedData encoding:NSUTF8StringEncoding];
    NSLog(@"%@", decodedString);
    lblText.linkColor = UIColorFromRGB(0X0076ff);
    lblText.delegate = self;
    lblText.userInteractionEnabled = YES;
    lblText.text = decodedString;
    decodedData = nil;
    decodedString = nil;
    viewButtonContainer.layer.cornerRadius = 20;
    viewLblContaner.layer.cornerRadius = 10;
    viewLblContaner.backgroundColor = UIColorFromRGB(0X00c2d9);
    self.lblReplyToOneBlabName.font = [UIFont fontWithName:Font_OpneSans_Regular size:10];
    self.lblReplyToOneBlabTitle.font = [UIFont fontWithName:Font_OpneSans_Regular size:10];
    
    self.lblReplyToOneBlabName.textColor = UIColorFromRGB(0X00c2d9);
    self.lblReplyToOneBlabTitle.textColor = UIColorFromRGB(0X616161);
    
    self.lblReplyToOneBlabTitle.text = @"";
    self.lblReplyToOneBlabName.text = @"";
    
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"ReplyID"]] intValue]!=0) {
        self.lblReplyToOneBlabName.text = [dic valueForKey:@"ReplyName"];
        self.lblReplyToOneBlabTitle.text = @"\" in reply to";
    }
    
    //    viewLblContaner.backgroundColor = [UIColor whiteColor];
    //    lblText.backgroundColor = [UIColor lightGrayColor];
    //    self.contentView.backgroundColor = [UIColor whiteColor];
    [Validation setCorners:self.imgUserThumb];
    //    [Validation setCorners:viewButtonContainer];
    
    CGRect size = [self getHeight:lblText.text];
    lblText.frame = CGRectMake(lblText.frame.origin.x, lblText.frame.origin.y, ceilf(size.size.width), ceilf(size.size.height));
    
    NSArray *arrTemp1 = [lblText.text componentsSeparatedByString:@" "];
    
    NSCharacterSet *numbersSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    NSMutableString *strFinal = [[NSMutableString alloc] init];
    NSDataDetector* detector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingTypeLink error:nil];
    
    strFinal = (NSMutableString *)[strFinal stringByAppendingString:@""];
    for (int i=0; i<arrTemp1.count; i++) {
        NSArray* matches = [detector matchesInString:[arrTemp1 objectAtIndex:i] options:0 range:NSMakeRange(0, [[arrTemp1 objectAtIndex:i] length])];
        if ([[arrTemp1 objectAtIndex:i] rangeOfCharacterFromSet:numbersSet].location == NSNotFound && [DataValidation checkNullString:[arrTemp1 objectAtIndex:i]].length>=3){
            if (i==0) {
                strFinal = (NSMutableString *)[strFinal stringByAppendingString:[NSString stringWithFormat:@"^^+^^%@",[arrTemp1 objectAtIndex:i]]];
            }
            else{
                strFinal = (NSMutableString *)[strFinal stringByAppendingString:[NSString stringWithFormat:@" ^^+^^%@",[arrTemp1 objectAtIndex:i]]];
            }
        }
        else if (matches.count>0){
            NSLog(@"link detact %@",[arrTemp1 objectAtIndex:i]);
            if (i==0) {
                strFinal = (NSMutableString *)[strFinal stringByAppendingString:[NSString stringWithFormat:@"^^+^^%@",[arrTemp1 objectAtIndex:i]]];
            }
            else{
                strFinal = (NSMutableString *)[strFinal stringByAppendingString:[NSString stringWithFormat:@" ^^+^^%@",[arrTemp1 objectAtIndex:i]]];
            }
        }
        else{
            if (i==0) {
                strFinal = (NSMutableString *)[strFinal stringByAppendingString:[NSString stringWithFormat:@"%@",[arrTemp1 objectAtIndex:i]]];
            }
            else{
                strFinal = (NSMutableString *)[strFinal stringByAppendingString:[NSString stringWithFormat:@" %@",[arrTemp1 objectAtIndex:i]]];
            }
        }
    }
    if (arrTemp1.count==1 && [[arrTemp1 objectAtIndex:0] rangeOfCharacterFromSet:numbersSet].location == NSNotFound && [DataValidation checkNullString:[arrTemp1 objectAtIndex:0]].length>=3) {
    }
    lblText.text = strFinal;
    
    if ([[NSString stringWithFormat:@"%@",CreaterID] isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
        imgViewTextTail.image = [UIImage imageNamed:@"chat_tail_2.png"];
    }
    else{
        imgViewTextTail.image = [UIImage imageNamed:@"chat_tail.png"];
    }
    NSString *str;
    if ([strUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
        str = @"Me";
        self.imgUserThumb.imageURL = [NSURL URLWithString:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]];
        lblDuration.textAlignment = NSTextAlignmentRight;
    }
    else{
        str = [NSString stringWithFormat:@"%@",[dic valueForKey:NAME]];
        self.imgUserThumb.imageURL = [NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]];
        lblDuration.textAlignment = NSTextAlignmentLeft;
    }
    
    NSMutableParagraphStyle *paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.lineBreakMode = NSLineBreakByTruncatingTail;
    
    size = [str boundingRectWithSize:CGSizeMake(150, MAXFLOAT)
                             options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                          attributes:@{NSFontAttributeName:lblBlabCreatorName.font, NSParagraphStyleAttributeName: paragraph}
                             context:nil];
    //    size = text.size;
    lblBlabCreatorName.frame = CGRectMake(lblBlabCreatorName.frame.origin.x, lblBlabCreatorName.frame.origin.y, (size.size.width>150)?(150):(size.size.width+4), lblBlabCreatorName.frame.size.height);
    lblBlabCreatorName.text = str;
    [lblBlabCreatorName setTextColor:(str.length >0)?[Validation getColorForAlphabet:lblBlabCreatorName.text]:[UIColor blackColor]];
    
    
    //////////////////  Timer
    str = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_SENT_BEFORE]];
    lblDuration.text = str;
    
    /*    size = [str boundingRectWithSize:CGSizeMake(40, lblDuration.frame.size.height)
     options:NSStringDrawingUsesLineFragmentOrigin
     attributes:@{NSFontAttributeName:lblDuration.font}
     context:nil];
     */
    
    if ([[dic valueForKey:IS_SELECTED] boolValue]) {
        [self.imgSelected setHidden:NO];
        [self.imgSelected setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
    }
    else{
        if (isEdit) {
            [self.imgSelected setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication]];
        }
        else{
            [self.imgSelected setHidden:YES];
        }
    }
    
    if ([[NSString stringWithFormat:@"%@",CreaterID] isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
        //it is user, so show right side
        [self setRightSideControls];
    }
    else{
        [self setLeftSideControls];
    }
    
//    NSString *strGroupId = [NSString stringWithFormat:@"%@",[dic valueForKey:@"GroupIDs"]];
//    if ([DataValidation checkNullString:strGroupId].length >0 && ([strGroupId intValue]!=0)) {
        btnBlabCreatorName.hidden = NO;
        btnBlabCreatorImage.hidden = NO;
        btnBlabCreatorName.frame = lblBlabCreatorName.frame;
        btnBlabCreatorImage.frame = self.imgUserThumb.frame;
        
/*    }
    else{
        btnBlabCreatorName.hidden = YES;
        btnBlabCreatorImage.hidden = YES;
    }
*/
}
-(void)label:(GLTapLabel *)label didSelectedHotWord:(NSString *)word atIndex:(int)index withArray:(NSArray *)arr{
    NSLog(@"Hot word tap %@ --%d --%@",word,index,arr);
    NSDataDetector* detector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingTypeLink error:nil];
    NSArray* matches = [detector matchesInString:word options:0 range:NSMakeRange(0, [word length])];
    if (matches.count>0) {
        NSString *strUrl;
        if ([word hasPrefix:@"http://"] || [word hasPrefix:@"https://"]) {
            strUrl = word;
        }
        else{
            strUrl = [NSString stringWithFormat:@"http://%@",word];
        }
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:strUrl]];
    }
    else{
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",word]]];
    }
}
-(void)label:(GLTapLabel *)label{
    NSLog(@"Hot word tap");
}
-(void)label:(GLTapLabel *)label didSelectedHotWord:(NSString *)w
{
    //    word.text = w;
    NSLog(@"Hot word tap");
}
- (CGRect)getHeight:(NSString *)strText{
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    //    CGSize size = CGSizeMake(self.lblTime.frame.size.width+50, self.lbl.frame.size.height);
    CGRect size =  [strText boundingRectWithSize:CGSizeMake(WIDTH_DESC-5, 20000)
                                         options:NSStringDrawingUsesLineFragmentOrigin
                                      attributes:@{NSFontAttributeName:lblText.font,NSParagraphStyleAttributeName:paragraphStyle}
                                         context:nil];
    
    return size;
}
-(IBAction)btnBlabCreatorName_Clicked:(id)sender{
    [self.delegate btnBlabCreatorName_Clicked:self.dicSelected];
}
-(IBAction)btnBlabCreatorImage_Clicked:(id)sender{
    [self.delegate btnBlabCreatorImage_Clicked:self.dicSelected];
}
@end
