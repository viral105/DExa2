//
//  HashBlabHomeCVCell.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/6/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "HashBlabHomeCVCell.h"

@implementation HashBlabHomeCVCell

-(void)setUI{
    self.lblTime.textColor = UIColorFromRGB(0X43a047);

    if ([DataValidation checkNullString:[self.dicSel valueForKey:@"Name"]].length!=0) {
        self.lblTitle.text = [HASHBLAB_CHARACTER stringByAppendingString:[self.dicSel valueForKey:@"Name"]];
    }
    
    self.lblTime.text = [self.dicSel valueForKey:@"RemainingTime"];
    [Validation setCorners:self.imgViewHashBlab];
    self.viewCircularProgressTime.progressTintColor = UIColorFromRGB(0X43a047);//green color
    self.viewCircularProgressTime.thicknessRatio = 0.15;
    self.viewCircularProgressTime.clockwiseProgress = 1;
//    self.viewCircularProgressTime.progress = 1;
    if ([DataValidation checkNullString:[self.dicSel valueForKey:@"ImagePath"]].length!=0) {
        if ([[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"ActiveStatus"]] intValue]==0) {
            self.imgViewHashBlab.frame = CGRectMake(15, 0, 65, 65);
            self.viewCircularProgressTime.hidden = YES;
            self.lblTime.hidden = YES;
        }
        else{
            self.imgViewHashBlab.frame = CGRectMake(23, 5, 55, 55);
            self.viewCircularProgressTime.hidden = NO;
            self.lblTime.hidden = NO;
        }
        self.imgViewHashBlab.imageURL = [NSURL URLWithString:[self.dicSel valueForKey:@"ImagePath"]];
    }
    [Validation setCorners:self.imgViewHashBlab];
    if ([[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"RemainingPercentage"]] floatValue]<=2500.0) {
        self.viewCircularProgressTime.progressTintColor = UIColorFromRGB(0Xe53935);//red color
        self.lblTime.textColor = UIColorFromRGB(0Xe53935);
    }
    [self.viewCircularProgressTime setProgress:[[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"RemainingPercentage"]] floatValue]/10000];
//    [self startAnimation];
}
- (void)progressChange
{
    NSArray *progressViews = @[self.viewCircularProgressTime];
    for (DACircularProgressView *progressView in progressViews) {
        CGFloat progress = ![self.timer isValid] ? self.stepper.value / 10.0f : progressView.progress + 0.01f;
        [progressView setProgress:progress animated:YES];
        if (progressView.progress>=[[NSString stringWithFormat:@"0.%@",[self.dicSel valueForKey:@"RemainingPercentage"]] floatValue]) {
            [self stopAnimation];
        }
        if (progressView.progress >= 1.0f && [self.timer isValid]) {
            [progressView setProgress:0.f animated:YES];
        }
        
//        self.progressLabel.text = [NSString stringWithFormat:@"%.2f", progressView.progress];
    }
    
}

- (void)startAnimation
{
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.03
                                                  target:self
                                                selector:@selector(progressChange)
                                                userInfo:nil
                                                 repeats:YES];
//    self.continuousSwitch.on = YES;
}

- (void)stopAnimation
{
    [self.timer invalidate];
    self.timer = nil;
//    self.continuousSwitch.on = NO;
}
@end
