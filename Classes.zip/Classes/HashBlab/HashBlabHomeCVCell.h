//
//  HashBlabHomeCVCell.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/6/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DACircularProgressView.h"
@interface HashBlabHomeCVCell : UICollectionViewCell{
    

}
@property (nonatomic, strong) IBOutlet UILabel *lblTitle;
@property (nonatomic, strong) IBOutlet UILabel *lblTime;
@property (nonatomic, strong) IBOutlet DACircularProgressView *viewCircularProgressTime;
@property (nonatomic, strong) NSDictionary *dicSel;
@property (nonatomic, strong) IBOutlet AsyncImageView *imgViewHashBlab;
@property (strong, nonatomic) NSTimer *timer;
@property (strong, nonatomic) IBOutlet UIStepper *stepper;

-(void)setUI;

@end
