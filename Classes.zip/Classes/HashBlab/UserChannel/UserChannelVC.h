//
//  UserChannelVC.h
//  WWHHAAZZAAPP
//
//  Created by multicoreViral on 9/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ActiveHBlabCell.h"
#import "HBlabConversation.h"

@interface UserChannelVC : UIViewController<UITableViewDataSource,UITableViewDelegate,AFNetworkingDataTransactionDelegate>

@property (strong,nonatomic) NSDictionary *dicSel;
@property (strong, nonatomic) IBOutlet UITableView *tblActiveHBlab;
- (IBAction)btnBack_Clicked:(id)sender;
- (IBAction)btnAdd_Clicked:(id)sender;
@property (nonatomic,assign) BOOL isFromHomeScreen;
@end
