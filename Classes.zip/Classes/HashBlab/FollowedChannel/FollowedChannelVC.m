//
//  MyChannelsVC.m
//  WWHHAAZZAAPP
//
//  Created by multicoreViral on 9/25/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "FollowedChannelVC.h"
#define PageSize 10

@interface FollowedChannelVC ()<MBProgressHUDDelegate>{
    MBProgressHUD *HUD;
    NSMutableArray *arrActiveHBlab;
    int pageCounter;
    BOOL isDataNull;
    
    int selectedIndex;
    
}
@property (nonatomic,strong)NSMutableArray *arrActiveHBlab;
@property (nonatomic,assign)BOOL isDataNull;

@end

@implementation FollowedChannelVC
@synthesize arrActiveHBlab,isDataNull;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self LoadViewSetting];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    
    self.arrActiveHBlab = [NSMutableArray new];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void) viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
    if (self.isFromHomeScreen) {
        [self performSegueWithIdentifier:@"SGCreateHBlab" sender:self];
        self.isFromHomeScreen = NO;
    }
    else{
        [self.arrActiveHBlab removeAllObjects];
        pageCounter = 1;
        [self callGetActiveHBlab];
    }
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
}
-(void)LoadViewSetting{
    self.view.backgroundColor = UIColorFromRGB(0Xefefef);
    //    [self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    // [self.btnDelete setBackgroundColor:UIColorFromRGB(0Xff5252)];
    
    //-----
    //    self.tblData.allowsMultipleSelectionDuringEditing = YES;
    //    [self.tblData setValue:[UIColor grayColor] forKeyPath:@"multiselectCheckmarkColor"];
    //-----
    
    
    //    [self.lbl_NoDataAvailable setTextColor:TWITTER_BLUE_COLOR];
    //    [self.lbl_NoDataAvailable setShadowColor:[UIColor clearColor]];
    //
    //    self.strLoggedInUserId = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"SGHBlabConversation"]) {
        HBlabConversation *obj = segue.destinationViewController;
        obj.dicConversationDetail = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrActiveHBlab objectAtIndex:selectedIndex]];
    }
    if ([segue.identifier isEqualToString:@"SGCreateHBlab"]) {
        CreateHBlabVC *obj = [segue destinationViewController];
        obj.isFromHomeScreen = YES;
    }
}


- (IBAction)btnBack_Clicked:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (IBAction)btnAdd_Clicked:(id)sender {
}

#pragma mark Web Service Call

-(void)callGetActiveHBlab{
    [HUD show:YES];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         //                         [NSDictionary dictionaryWithObjectsAndKeys:@"30446",KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
                         nil];
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_ALL_HASHCONVOS withParameters:nil];
    AFNetworkingDataTransaction   *request = [AFNetworkingDataTransaction sharedManager];
    [request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:1];
    }
    strUrl = nil;
}
- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    
    NSLog(@"tag = %d",tag);
    
    NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    
    if (dicResponse != nil) {
        
        if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]) {
            
            if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                
                NSLog(@"dic = %@",dicResponse);
                [HUD hide:YES];
                [appDelegate callLogOutService];
            }
            else{
                if (tag == 1) {
                    //featured
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        if ([dicResponse objectForKey:RESPONSE] != nil) {
                            id response = [dicResponse objectForKey:RESPONSE];
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            [self.arrActiveHBlab addObjectsFromArray:arr];
                            
                            self.isDataNull = NO;
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            
                            [self.tblActiveHBlab reloadData];
                            [HUD hide:YES];
                            
                            arr = nil;
                            response = nil;
                            
                            
                        }
                        else{
                            [HUD hide:YES];
                        }
                    }
                    else{
                        self.isDataNull = YES;
                        [self.tblActiveHBlab reloadData];
                        [HUD hide:YES];
                    }
                }
                else if (tag == 2){
                    //recommended
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        if ([dicResponse objectForKey:RESPONSE] != nil) {
                            id response = [dicResponse objectForKey:RESPONSE];
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                        }
                        else{
                            [HUD hide:YES];
                        }
                    }
                    else{
                        
                        [HUD hide:YES];
                    }
                }
            }
        }
        else{
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
    }
    else{
        [HUD hide:YES];
    }
    request = nil;
    
    
    //    [self performSelector:@selector(getTestNotif) withObject:nil afterDelay:10];
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrActiveHBlab.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ActiveHBlabCell *cell = [tableView dequeueReusableCellWithIdentifier:@"activehblab"];
    
    cell.imgViewHBlab.image = nil;
    cell.imgViewHBlab.imageURL = nil;
    cell.imgViewUser.image = nil;
    cell.imgViewUser.imageURL = nil;
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (!self.isDataNull && (indexPath.row == (self.arrActiveHBlab.count+1) || indexPath.row == self.arrActiveHBlab.count-1)){
        pageCounter ++;
        [self performSelectorInBackground:@selector(callGetActiveHBlab) withObject:nil];
    }
    cell.dicSel = [self.arrActiveHBlab objectAtIndex:indexPath.row];
    
    [cell setUI];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    selectedIndex = (int)indexPath.row;
    [self performSegueWithIdentifier:@"SGHBlabConversation" sender:self];
}

@end
