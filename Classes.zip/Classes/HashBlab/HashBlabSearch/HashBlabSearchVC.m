//
//  HashBlabSearchVC.m
//  WWHHAAZZAAPP
//
//  Created by Nivid on 30/06/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "HashBlabSearchVC.h"
#define PageSize 10

@interface HashBlabSearchVC  ()<MBProgressHUDDelegate>{
    MBProgressHUD *HUD;
    
    
    int selectedIndex;
    
}

@end

@implementation HashBlabSearchVC
@synthesize arrActiveHBlab,isDataNull,pageCounter;

- (void)viewDidLoad {
    [super viewDidLoad];
    [self LoadViewSetting];
    
    self.tblActiveHBlab.tag=101;
    self.arrActiveHBlab = [NSMutableArray new];
    if (self.isChildView) {
        self.imgViewNavBar.hidden = YES;
        self.lblTitle.hidden = YES;
        self.btnBack.hidden = YES;
        CGRect frame;
        frame = self.imgSearchIcon.frame;
        frame.origin.y = frame.origin.y-64;
        self.imgSearchIcon.frame = frame;
        
        frame = self.lblHashChar.frame;
        frame.origin.y = frame.origin.y-64;
        self.lblHashChar.frame = frame;
        
        frame = self.tfSearch.frame;
        frame.origin.y = frame.origin.y-64;
        self.tfSearch.frame = frame;
        
        frame = self.imgViewRecommand.frame;
        frame.origin.y = frame.origin.y-64;
        self.imgViewRecommand.frame = frame;
        
        frame = self.tblActiveHBlab.frame;
        frame.origin.y = frame.origin.y-64;
        frame.size.height = self.view.frame.size.height-self.tblActiveHBlab.frame.origin.y+64;
        self.tblActiveHBlab.frame = frame;
        
        if (!self.isRecommendChannel) {
            self.imgViewRecommand.hidden = YES;
            CGRect frame = self.tblActiveHBlab.frame;
            frame.origin.y = frame.origin.y-40;
            frame.size.height = frame.size.height+40;
            self.tblActiveHBlab.frame =frame;
        }
        else{
            self.pageCounter = 1;
            [self callGetRecommandedChannels];
        }
 
    }
    else{
        HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
        [self.navigationController.view addSubview:HUD];
        
        self.pageCounter = 1;
        [self callGetRecommandedChannels];
    }
    
}

- (void)viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
    
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    
//    [self.arrActiveHBlab removeAllObjects];
//    pageCounter = 1;
   // [self callSearchHashBlab];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)LoadViewSetting{
    self.view.backgroundColor = UIColorFromRGB(0Xefefef);
}
-(void)updateList:(NSMutableDictionary*)dicConversationDetail indexOfObj:(int)indexOfObj cntArr:(int)cntArr{
    [self.arrActiveHBlab replaceObjectAtIndex:indexOfObj withObject:dicConversationDetail];
}
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    if ([segue.identifier isEqualToString:@"SGHBlabConversation"]) {
        HBlabConversation *obj = segue.destinationViewController;
        obj.dicConversationDetail = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrActiveHBlab objectAtIndex:selectedIndex]];
        obj.indexOfObj = selectedIndex;
        obj.cntArr = 0;
        obj.delegate = self;
    }
}

- (IBAction)btnBack_Clicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnAdd_Clicked:(id)sender {
}

#pragma mark Web Service Call

-(void)callSearchHashBlab{
    [HUD show:YES];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"userid",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[[NSString stringWithFormat:@"%@",self.tfSearch.text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]], KeyValue,@"name",KeyName,nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",pageCounter],KeyValue,@"pageno",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"pagesize",KeyName, nil],@"4",
                         nil];
    NSString *strUrl = [WebServiceContainer getServiceURL:HASH_BLAB_SEARCH withParameters:nil];
    AFNetworkingDataTransaction   *request = [AFNetworkingDataTransaction sharedManager];
    [request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:1];
    }
    strUrl = nil;
}
-(void)callGetRecommandedChannels{
    self.isRecommendChannel = YES;
    [HUD show:YES];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_ALL_RECOMMENDED_HASHBLAB withParameters:nil];
    AFNetworkingDataTransaction   *request = [AFNetworkingDataTransaction sharedManager];
    [request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:2];
    }
    //    self.request.delegate = self;
    //    self.request.tag = 5;
    strUrl = nil;
}
- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    
    NSLog(@"tag = %d",tag);
    
    NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    self.lbl_NoDataAvailable.hidden = TRUE;
    
    if (dicResponse != nil) {
        
        if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]) {
            
            if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                
                NSLog(@"dic = %@",dicResponse);
                [HUD hide:YES];
                [appDelegate callLogOutService];
            }
            else{
                if (tag == 1) {
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        if ([dicResponse objectForKey:RESPONSE] != nil) {
                            id response = [dicResponse objectForKey:RESPONSE];
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            [self.arrActiveHBlab addObjectsFromArray:arr];
                            
                            self.isDataNull = NO;
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            
                            [self.tblActiveHBlab reloadData];
                            [HUD hide:YES];
                            
                            arr = nil;
                            response = nil;
                        }
                        else{
                            [HUD hide:YES];
                        }
                    }
                    else{
                        self.isDataNull = YES;
                        [HUD hide:YES];
                    }
                    if (self.arrActiveHBlab.count == 0) {
                        self.lbl_NoDataAvailable.hidden = FALSE;
                    }
                }
                else if (tag == 2){
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        if ([dicResponse objectForKey:RESPONSE] != nil) {
                            id response = [dicResponse objectForKey:RESPONSE];
                            if (response != nil && ((NSArray*)response).count > 0) {
                                
                                NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                                self.isDataNull = NO;
                                if (arr.count < PageSize) {
                                    [self.lbl_NoDataAvailable setHidden:YES];
                                    self.isDataNull = YES;
                                }
                                if (arr.count>0) {
                                    [self.arrActiveHBlab addObjectsFromArray:arr];
                                    //	[self.tblData reloadData];
                                }
                                arr = nil;
                            }
                            if (self.arrActiveHBlab.count == 0 && self.pageCounter==1) {
                                [self.lbl_NoDataAvailable setHidden:NO];
                                [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                            }
                            else{
                                if (((NSArray*)response).count < PageSize) {
                                    [self.lbl_NoDataAvailable setHidden:YES];
                                    self.isDataNull = YES;
                                }
                            }
                        }
                    }
                    else{
                        if (self.arrActiveHBlab.count == 0 && self.pageCounter==1) {
                            [self.lbl_NoDataAvailable setHidden:NO];
                            self.isDataNull = YES;
                            [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                        }
                    }
                    [self.lbl_NoDataAvailable setHidden:YES];
                    [self.tblActiveHBlab reloadData];
                    [HUD hide:YES];
                }
            }
        }
        else{
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
    }
    else{
        [HUD hide:YES];
    }
    request = nil;
    
    
    //    [self performSelector:@selector(getTestNotif) withObject:nil afterDelay:10];
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSLog(@"%d",(int)self.arrActiveHBlab.count);
    return self.arrActiveHBlab.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ActiveHBlabCell *cell = [tableView dequeueReusableCellWithIdentifier:@"activehblab"];
    
    cell.imgViewHBlab.image = nil;
    cell.imgViewHBlab.imageURL = nil;
    cell.imgViewUser.image = nil;
    cell.imgViewUser.imageURL = nil;
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (!self.isDataNull && (indexPath.row == (self.arrActiveHBlab.count+1) || indexPath.row == self.arrActiveHBlab.count-1)){
        pageCounter ++;
        [self performSelectorInBackground:@selector(callSearchHashBlab) withObject:nil];
    }
    cell.dicSel = [self.arrActiveHBlab objectAtIndex:indexPath.row];
    
    [cell setUI];
    if (tableView.tag==101){
        cell.lblViews.frame = CGRectMake(80, 82, cell.lblViews.frame.size.width, cell.lblViews.frame.size.height);
        cell.lblFollowers.hidden = YES;
    }
    else{
//        cell.lblViews.frame = CGRectMake(80, 82, 50, 15);
        cell.lblFollowers.hidden = NO;
        cell.lblViews.frame = CGRectMake(cell.lblFollowers.frame.origin.x, 77, cell.lblFollowers.frame.size.width, cell.lblFollowers.frame.size.height);
        cell.lblFollowers.text = [NSString stringWithFormat:@"%@ Followers",[cell.dicSel valueForKey:@"TotalFollower"]];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    selectedIndex = (int)indexPath.row;
    [self performSegueWithIdentifier:@"SGHBlabConversation" sender:self];
}

#pragma mark UITextField Delegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if ([DataValidation checkNullString:textField.text].length>0) {
        [self.arrActiveHBlab removeAllObjects];
        [HUD hide:YES];
        [HUD show:YES];
        
        [self.tblActiveHBlab reloadData];
        pageCounter = 1;
        self.tblActiveHBlab.tag = 102;
        self.isRecommendChannel = NO;
        if (!self.imgViewRecommand.isHidden) {
            self.imgViewRecommand.hidden = YES;
            CGRect frame = self.tblActiveHBlab.frame;
            frame.origin.y = frame.origin.y-40;
            frame.size.height = frame.size.height+40;
            self.tblActiveHBlab.frame =frame;
        }
        [Validation setMatTrackingForSearch:self.tfSearch.text];
        [self callSearchHashBlab];
    }
    [textField resignFirstResponder];
    return TRUE;
}
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    [self.view endEditing:YES];
    
    //    UITableView *tblRegister = (UITableView*) [self.view viewWithTag:kSignUpTableViewTag];
    //    [tblRegister setContentOffset:CGPointMake(0, 0) animated:YES];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
