//
//  HashBlabSearchVC.h
//  WWHHAAZZAAPP
//
//  Created by Nivid on 30/06/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ActiveHBlabCell.h"
#import "HBlabConversation.h"


@interface HashBlabSearchVC : UIViewController<UITableViewDataSource,UITableViewDelegate,AFNetworkingDataTransactionDelegate,HBlabConversationDelegate>

@property (strong, nonatomic) IBOutlet UITableView *tblActiveHBlab;
@property (nonatomic, strong) IBOutlet UITextField			*tfSearch;
@property (nonatomic, retain) IBOutlet UILabel				*lbl_NoDataAvailable;

@property (nonatomic, strong) IBOutlet UIButton *btnBack;
@property (nonatomic, strong) IBOutlet UIImageView *imgViewNavBar;
@property (nonatomic, strong) IBOutlet UILabel *lblTitle;
@property (nonatomic, strong) IBOutlet UIImageView *imgSearchIcon;
@property (nonatomic, strong) IBOutlet UILabel *lblHashChar;
@property (nonatomic, strong) IBOutlet UIImageView *imgViewRecommand;
@property (nonatomic, assign) BOOL                          isRecommendChannel;


- (IBAction)btnBack_Clicked:(id)sender;
- (IBAction)btnAdd_Clicked:(id)sender;

@property (strong, nonatomic) NSMutableArray *arrActiveHBlab;
@property (assign, nonatomic) int pageCounter;
@property (assign, nonatomic) BOOL isDataNull;
@property (assign, nonatomic) BOOL isChildView;

@end
