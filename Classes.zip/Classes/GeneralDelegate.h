//
//  GeneralDelegate.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/29/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol GeneralDelegate <NSObject>

@optional
-(void)displayAlarmSoundName:(NSDictionary *)selDic;
-(void)displayAlarmRecordedSoundName:(NSString *)strAudioPath;
-(void)passBlabDataForHBlab:(NSDictionary *)dicSel;
-(void)updateUserData:(int)indSel;
@end
