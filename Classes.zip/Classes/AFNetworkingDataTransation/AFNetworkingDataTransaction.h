//
//  AFNetworkingDataTransaction.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 27/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "MBProgressHUD.h"

@protocol AFNetworkingDataTransactionDelegate <NSObject>
- (void)successResponseWithData:(id)request withTag:(int)tag;
- (void)FailurResponseWithErroe:(NSError *)error;

@end
@interface AFNetworkingDataTransaction : NSObject


@property (nonatomic ,assign) id <AFNetworkingDataTransactionDelegate>       delegate;

@property (nonatomic ,readwrite) int                                          tag;

@property (nonatomic ,readwrite) BOOL                                         isLongTimeOut;

@property (nonatomic, strong) AFHTTPRequestOperation *_currentRequest;

-(AFNetworkingDataTransaction *)SetCallForURL:(NSString *)strURL WithDic:(NSDictionary *)dic isAddHeader:(BOOL)isAddHeader;
-(AFHTTPRequestOperationManager *)SetCallForURLWithImg:(NSString *)strURL WithDic:(NSDictionary *)dic isAddHeader:(BOOL)isAddHeader forLoader:(MBProgressHUD *)hud;
-(void)CancleOngoingRequest;
+ (id)sharedManager;

@end
