//
//  AFNetworkingDataTransaction.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 27/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "AFNetworkingDataTransaction.h"
#import "AFNetworking.h"

static AFNetworkingDataTransaction *sharedDialog = nil;


//#define BASE_URL			@"http://wwhhaazzuupp.com/api/"
#define HEADER_USERNAME_KEY	@"userid"
#define HEADER_PWD_KEY		@"password"

@implementation AFNetworkingDataTransaction

+ (instancetype)sharedManager {
   
    if (!sharedDialog) {
        sharedDialog = [[AFNetworkingDataTransaction alloc] init];
    }
    return sharedDialog;
}

-(AFHTTPRequestOperationManager *)SetCallForURL:(NSString *)strURL WithDic:(NSDictionary *)dic isAddHeader:(BOOL)isAddHeader{
   
    
    if (![Validation checkInternetConnection]) {
        //[Validation hideLoadingIndicator];

        self._currentRequest = nil;
        return nil;
    }
    else{
        NSLog(@"SetCallForURL: ------->> Dictionary:\n %@",dic);
        AFHTTPRequestOperationManager *operationManager = [AFHTTPRequestOperationManager manager];
/*        if (self.isLongTimeOut) {
            operationManager.requestSerializer.timeoutInterval = 600.0;
        }
        else{
            operationManager.requestSerializer.timeoutInterval = 60.0;
        }
*/
        operationManager.requestSerializer.timeoutInterval = 60.0;
        operationManager.operationQueue.maxConcurrentOperationCount = 25;
        
        //headers
        if (isAddHeader) {
            NSString *strT1 = [Validation GetUTCDate];
            [operationManager.requestSerializer setValue:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL] forHTTPHeaderField:HEADER_USERNAME_KEY];
            [operationManager.requestSerializer setValue:strT1 forHTTPHeaderField:@"T1"];
            [operationManager.requestSerializer setValue:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE] forHTTPHeaderField:@"T2"];
            
        }
               //-----

        NSMutableDictionary *dicForPost = [[NSMutableDictionary alloc] init];
        if (dic != nil) {
            NSArray *arr = [dic allKeys];
            for (int i =0; i<dic.count; i++) {
                NSDictionary *dValue = [dic valueForKey:[NSString stringWithFormat:@"%@",[arr objectAtIndex:i]]];
                [dicForPost setValue:[NSString stringWithFormat:@"%@",[dValue valueForKey:KeyValue]] forKey:[dValue valueForKey:KeyName]];
            }
        }

        self._currentRequest = [operationManager POST:strURL parameters:dicForPost success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSLog(@"JSON: %@", NSStringFromClass([self class]));
            if (self.delegate!=nil) {
                
           // if ([self.delegate isKindOfClass:[appDelegate.currentVc class]]) {
                [self.delegate successResponseWithData:responseObject withTag:self.tag];
            }
        }
                                              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                                                  NSLog(@"Error: %@", [error description]);
                                                  if (self.delegate!=nil) {
                                                      [self.delegate FailurResponseWithErroe:error];
                                                  }
                                              }
                                ];
        
        return operationManager;
    }
}

-(AFHTTPRequestOperationManager *)SetCallForURLWithImg:(NSString *)strURL WithDic:(NSDictionary *)dic isAddHeader:(BOOL)isAddHeader forLoader:(MBProgressHUD *)hud{
    if (![Validation checkInternetConnection]) {
        //[Validation hideLoadingIndicator];
        
        self._currentRequest = nil;
        return nil;
    }
    else{
      //  NSLog(@"SetCallForURL: ------->> Dictionary:\n %@",dic);
        AFHTTPRequestOperationManager *operationManager = [AFHTTPRequestOperationManager manager];
        operationManager.requestSerializer.timeoutInterval = 60.0;
        operationManager.operationQueue.maxConcurrentOperationCount = 25;
        
        //headers
        if (isAddHeader) {
            NSString *strT1 = [Validation GetUTCDate];
            [operationManager.requestSerializer setValue:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL] forHTTPHeaderField:HEADER_USERNAME_KEY];
            [operationManager.requestSerializer setValue:strT1 forHTTPHeaderField:@"T1"];
            [operationManager.requestSerializer setValue:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE] forHTTPHeaderField:@"T2"];
            
        }
        NSMutableDictionary *dicForPost = [[NSMutableDictionary alloc] init];
        NSData *imageData = nil;
        NSMutableData *soundData = nil;
        NSMutableData *audioData = nil;
        NSData *videoData = nil;
        NSData *hashImageData = nil;
        
        if (dic != nil) {
            NSArray *arr = [dic allKeys];
            for (int i =0; i<dic.count; i++) {
                NSDictionary *dValue = [dic valueForKey:[NSString stringWithFormat:@"%@",[arr objectAtIndex:i]]];
                if ([[dValue valueForKey:KeyName] isEqualToString:@"ImgData"]) {
                    if ([[dValue valueForKey:KeyValue] isKindOfClass:[UIImage class]] ) {
                        imageData = [Validation compressImage:[dValue valueForKey:KeyValue]];
                    }
                    else if ([[dValue valueForKey:KeyValue] isKindOfClass:[NSData class]] ) {
                        imageData = [dValue valueForKey:KeyValue];
                    }
                }
                else if ([[dValue valueForKey:KeyName] isEqualToString:@"SoundData"]) {
                  //  NSFileManager *fm = [NSFileManager defaultManager];
                    if ([[dValue valueForKey:KeyValue] isKindOfClass:[NSString class]] ) {
                        soundData =  [NSMutableData dataWithContentsOfFile:[dValue valueForKey:KeyValue]];
                    }
                    else if ([[dValue valueForKey:KeyValue] isKindOfClass:[NSData class]] ) {
                        soundData = [dValue valueForKey:KeyValue];
                    }
//                    NSString *strPath = [NSString stringWithFormat:@"%@",[dValue valueForKey:KeyValue]];
//                    
//                    if ([fm fileExistsAtPath:strPath]) {
//                        NSLog(@"file exist");
//                    }
//                    soundData = [NSMutableData dataWithContentsOfFile:strPath];
                }
                else if ([[dValue valueForKey:KeyName] isEqualToString:@"AudioData"]) {
                    //  NSFileManager *fm = [NSFileManager defaultManager];
                    if ([[dValue valueForKey:KeyValue] isKindOfClass:[NSString class]] ) {
                        audioData =  [NSMutableData dataWithContentsOfFile:[dValue valueForKey:KeyValue]];
                    }
                    else if ([[dValue valueForKey:KeyValue] isKindOfClass:[NSData class]] ) {
                        audioData = [dValue valueForKey:KeyValue];
                    }
                    //                    NSString *strPath = [NSString stringWithFormat:@"%@",[dValue valueForKey:KeyValue]];
                    //
                    //                    if ([fm fileExistsAtPath:strPath]) {
                    //                        NSLog(@"file exist");
                    //                    }
                    //                    soundData = [NSMutableData dataWithContentsOfFile:strPath];
                }
                else if ([[dValue valueForKey:KeyName] isEqualToString:@"VideoData"]){
                    //video
                    if ([[dValue valueForKey:KeyValue] isKindOfClass:[NSData class]] ) {
                        videoData = [dValue valueForKey:KeyValue];
                       
                    }
                }
                else if ([[dValue valueForKey:KeyName] isEqualToString:@"HashImageData"]) {
                    if ([[dValue valueForKey:KeyValue] isKindOfClass:[UIImage class]] ) {
                        hashImageData = [Validation compressImage:[dValue valueForKey:KeyValue]];
                    }
                    else if ([[dValue valueForKey:KeyValue] isKindOfClass:[NSData class]] ) {
                        hashImageData = [dValue valueForKey:KeyValue];
                    }
                }
                else{
                    [dicForPost setValue:[NSString stringWithFormat:@"%@",[dValue valueForKey:KeyValue]] forKey:[dValue valueForKey:KeyName]];
                }
                
            }
        }
        
        self._currentRequest = [operationManager POST:strURL parameters:dicForPost constructingBodyWithBlock:^(id<AFMultipartFormData> formData){
            if (imageData.length > 0) {
                [formData appendPartWithFileData:imageData name:@"ImgData" fileName:@"photo.jpg" mimeType:@"multipart/form-data"];
            }
            if (soundData.length > 0) {
                 [formData appendPartWithFileData:soundData name:@"SoundData" fileName:@"userSound.m4a" mimeType:@"multipart/form-data"];
            }
            if (audioData.length > 0) {
                [formData appendPartWithFileData:audioData name:@"AudioData" fileName:@"userSound.m4a" mimeType:@"multipart/form-data"];
            }
            if (videoData.length > 0) {
                 [formData appendPartWithFileData:videoData name:@"VideoData" fileName:@"myVidi.mp4" mimeType:@"multipart/form-data"];
            }
            if (hashImageData.length > 0) {
                [formData appendPartWithFileData:hashImageData name:@"HashImageData" fileName:@"photo.jpg" mimeType:@"multipart/form-data"];
            }
                                }
                                              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                                    NSLog(@"Success: %@ ***** %@", operation.responseString, responseObject);
                                    NSLog(@"JSON: %@", NSStringFromClass([self class]));
                                    if (self.delegate!=nil) {
                                        
                                        // if ([self.delegate isKindOfClass:[appDelegate.currentVc class]]) {
                                        [self.delegate successResponseWithData:responseObject withTag:self.tag];
                                    }

                                }
                                              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                                    NSLog(@"Error: %@ ***** %@", operation.responseString, error);
                                    NSLog(@"Error: %@", [error description]);
                                    if (self.delegate!=nil) {
                                        [self.delegate FailurResponseWithErroe:error];
                                    }
                                }
                            
            ];
        
            return operationManager;
    }


}
-(void)CancleOngoingRequest{
    if(self._currentRequest) {
        [self._currentRequest cancel]; self._currentRequest = nil;
    }
}

@end
