//
//  LocationVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 20/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface LocationVC : UIViewController <MKMapViewDelegate,UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate>

@property (strong, nonatomic) IBOutlet MKMapView *mapView;
@property (readwrite, nonatomic) BOOL       isUserLocationAddedToAnnotationList;

@property (nonatomic, strong) IBOutlet  UITableView         *tblData;
@property (nonatomic, strong) NSMutableArray                *arrData;

@property (nonatomic, strong) ASIFormDataRequest			*request;
@property (nonatomic, readwrite) int						selectedIndex;

@property (nonatomic, strong) MKUserLocation                *UserLocation;

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) IBOutlet UIButton             *btnNext;
@property (nonatomic, strong) IBOutlet UIButton             *btnMenu;


@end
