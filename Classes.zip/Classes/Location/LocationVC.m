//
//  LocationVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 20/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "LocationVC.h"
#import "MultipleAnnotationLocation.h"
#import "UserCell.h"
#import "MBProgressHUD.h"


#define IS_SELECTED         @"is_selected"


@interface LocationVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation LocationVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
    [self LoadViewSetting];
    
    self.arrData = [[NSMutableArray alloc] init] ;
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];

    self.mapView.delegate=self;
    self.mapView.showsUserLocation = YES;
    
    [Validation removeAdviewFromSuperView];
	[self.view addSubview:[Validation sharedBannerView]];
	[Validation ResizeViewForAds];

}

-(void)viewWillAppear:(BOOL)animated{
    
    appDelegate.currentVc = self;
    [self.btnMenu removeTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
	[self.btnMenu addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark    Custom methods

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    self.btnNext.hidden = TRUE;
}

-(IBAction)btnBackClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)SearchForNearByUsersList{
    
    [HUD show:YES];
	if (self.request !=nil) {
		self.request = nil;
	}
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithDouble:self.UserLocation.coordinate.latitude],KeyValue,@"Lat",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithDouble:self.UserLocation.coordinate.longitude],KeyValue,@"Lng",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"50",KeyValue,@"Distance",KeyName, nil],@"4",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:SET_USER_LAT_LONG withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//	self.request.delegate = self;
//	self.request.tag = 1;
	strUrl = nil;
}

-(void)btnAddFriendClicked:(id)sender{
    
    [HUD show:YES];
    
	if (self.request !=nil) {
		self.request = nil;
	}
	self.selectedIndex = (int)((UIButton *)sender).tag;
	
	NSString *strRequestId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:USER_ID]];
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:ADD_FRIEND withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }
//	self.request.delegate = self;
//	self.request.tag = 2;
	strUrl = nil;
}

-(void)btnAcceptFriendRequest:(id)sender{
    
    [HUD show:YES];
    
	if (self.request !=nil) {
		self.request = nil;
	}
	self.selectedIndex = (int)((UIButton *)sender).tag;
	NSString *strRequestId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:USER_ID]];
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"IsFriend",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:ACCEPT_REJECT_FRND_REQ withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:3];
    }
//	self.request.delegate = self;
//	self.request.tag = 3;
	strUrl = nil;
}

-(void)btnRejectFriendRequest:(id)sender{
    
    [HUD show:YES];
    
	if (self.request !=nil) {
		self.request = nil;
	}
	self.selectedIndex = (int)((UIButton *)sender).tag;
	NSString *strRequestId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:USER_ID]];
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"IsFriend",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:ACCEPT_REJECT_FRND_REQ withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:4];
    }
//	self.request.delegate = self;
//	self.request.tag = 4;
	strUrl = nil;
}

-(IBAction)btnNextClicked:(id)sender{
    NSArray *arr = [self.arrData valueForKey:IS_SELECTED];
    
    int index = (int)[arr indexOfObject:@"1"];
    
    if (index > -1 && index<arr.count) {
        [self showYapOptions];
    }
    else{
        [AlertHandler alertTitle:MESSAGE message:@"Please select atleast one user." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
}

-(void)showYapOptions{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Select" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:Only_Yap,Yap_With_Image,Yap_With_Video, nil];
    [action showInView:self.view];
    action.delegate = self;
}

#pragma mark Map Methods

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    if (!self.isUserLocationAddedToAnnotationList) {
        
        self.UserLocation = userLocation;
        
        dispatch_async(dispatch_get_main_queue(),^{
            [self SearchForNearByUsersList];
            
            [self setUserCoordinates];
        });
    }
}

-(void)setUserCoordinates{
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(self.UserLocation.coordinate, 1,1);
    
    region.center.latitude = self.mapView.userLocation.coordinate.latitude;
    region.center.longitude = self.mapView.userLocation.coordinate.longitude;
//    region.span = MKCoordinateSpanMake(10, 20);
    region.span = MKCoordinateSpanMake(2.5, 2.5);
    
    [self.mapView setRegion:[self.mapView regionThatFits:region] animated:YES];
    
    //        // Add an annotation
    MKPointAnnotation *point = [[MKPointAnnotation alloc] init] ;
    point.coordinate = self.UserLocation.coordinate;
    [self.mapView addAnnotation:point];
    
    self.isUserLocationAddedToAnnotationList = YES;

}
-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation{
    
    //if its just user location , just return nil
    if ([annotation isKindOfClass:[MKUserLocation class]]) {
        return nil;
    }
    
    //try to dequeue an existing pinview first
    static NSString *strAnnotationId =  @"AnnotationId";
    MKPinAnnotationView *pinView = (MKPinAnnotationView*)
    [self.mapView dequeueReusableAnnotationViewWithIdentifier:strAnnotationId];
    if (pinView == nil) {
        pinView = [[MKPinAnnotationView alloc]
                           initWithAnnotation:annotation reuseIdentifier:strAnnotationId] ;
    }
    pinView.animatesDrop = YES;
    pinView.canShowCallout = YES;
    pinView.pinColor = MKPinAnnotationColorPurple;

    MultipleAnnotationLocation *newAnnotation = nil;
    if ([annotation isKindOfClass:[MultipleAnnotationLocation class]]) {
        newAnnotation = (MultipleAnnotationLocation *)annotation;
      //  NSLog(@"index = %d",newAnnotation.annotationIndex);
    }

    if (newAnnotation != nil) {
        if (newAnnotation.annotationIndex == 0) {
             UIImageView *userAvatar = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
            [userAvatar setImage:[self GetAnnotationImgFromURL:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]]]];
            userAvatar.layer.cornerRadius = 15.0;
            userAvatar.layer.masksToBounds = YES;
            userAvatar.layer.borderColor = [[UIColor blackColor] CGColor];
            userAvatar.layer.borderWidth = 1;
            UIImageWriteToSavedPhotosAlbum(userAvatar.image, nil, nil, nil);
            pinView.leftCalloutAccessoryView = userAvatar;
        }
    }
    
    if (self.arrData.count > 0) {
        UIImageView *userAvatar = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
        if (newAnnotation != nil) {
            [userAvatar setImage:[self GetAnnotationImgFromURL:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:newAnnotation.annotationIndex-1] valueForKey:USER_PHOTO_PATH]]]];
        }
        else{
            [userAvatar setImage:[UIImage imageNamed:btnMenu_Frnd_Request]];
        }
        userAvatar.layer.cornerRadius = 15.0;
        userAvatar.layer.masksToBounds = YES;
        userAvatar.layer.borderColor = [[UIColor blackColor] CGColor];
        userAvatar.layer.borderWidth = 1;
        UIImageWriteToSavedPhotosAlbum(userAvatar.image, nil, nil, nil);
        pinView.leftCalloutAccessoryView = userAvatar;
    }
    return pinView;
}

-(UIImage *)GetAnnotationImgFromURL:(NSString *)url{
    NSData *imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:url]];
    
    CGDataProviderRef dataProvider = CGDataProviderCreateWithCFData((__bridge CFDataRef)imageData);
    CGImageRef imageRef = ([[url pathExtension] isEqualToString:@"png"])?CGImageCreateWithPNGDataProvider(dataProvider, NULL, NO, kCGRenderingIntentDefault):CGImageCreateWithJPEGDataProvider(dataProvider, NULL, NO, kCGRenderingIntentDefault);
    UIImage *image = [UIImage imageWithCGImage:imageRef ];
    
    CGDataProviderRelease(dataProvider);
    CGImageRelease(imageRef);
    
    return image;
}

-(void)showDetails:(id)sender{
    NSLog(@"Annotation CLicked");
}

#pragma mark  UITableViewDelegate

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 90;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

	return self.arrData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
	NSString *cellId = [NSString stringWithFormat:@"%d",(int)indexPath.row];
	
	if (indexPath.row < self.arrData.count) {
		cellId = [cellId stringByAppendingFormat:@"%@",[[self.arrData objectAtIndex:indexPath.row] valueForKey:USER_ID]];
	}
    
	UserCell *cell = (UserCell *)[tableView dequeueReusableCellWithIdentifier:cellId];
	cell.isUserSelectionInView = YES;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	[cell clearsContextBeforeDrawing];
	
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indexPath.row]];
	
    if (cell == nil) {
        cell = [[UserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        [cell setBoxValuesWithData:dic];
    }
    [cell setBoxValuesWithData:dic];
    
    [cell.imgFriendshipStatus setHidden:TRUE];
    [cell.btnReqDeny setHidden:TRUE];
    [cell.btnReqStatus setHidden:TRUE];
    cell.btnUnfriend.hidden = YES;
    
    if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
        [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
        [cell.imgFriendshipStatus setHidden:FALSE];
    }
    dic = nil;
	return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indexPath.row]];

    if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
        [dic setValue:@"0" forKey:IS_SELECTED];
    }
    else{
        [dic setValue:@"1" forKey:IS_SELECTED];
    }
    
    [self.arrData replaceObjectAtIndex:indexPath.row withObject:dic];
    
    dic = nil;
    
    [tableView reloadData];

    NSArray *arr = [self.arrData valueForKey:IS_SELECTED];
    
    int index = (int)[arr indexOfObject:@"1"];
    
    if (index > -1 && index<arr.count) {
        [Validation removeAdviewFromSuperView];
         self.btnNext.hidden = FALSE;
    }
    else{
        [self.view addSubview:[Validation sharedBannerView]];
        [Validation ResizeViewForAds];
         self.btnNext.hidden = TRUE;
    }
}

#pragma mark    UIActionsheet Delegate

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"button index = %d",(int)buttonIndex);
    
    if (buttonIndex == actionSheet.cancelButtonIndex) {
        
    }
    else if (buttonIndex == 0){
        //only yap
        [self performSegueWithIdentifier:RECORD_OPTION_VC sender:nil];
    }
    else if (buttonIndex == 1){
        //yap with image
        [self performSegueWithIdentifier:CAPTURE_IMAGE_VC sender:nil];
    }
    else if (buttonIndex == 2){
        //yap with video
        if ([[NSFileManager defaultManager] fileExistsAtPath:VIDEO_RECORDING_FOLDER]) {
            //when folder exists
            NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
            if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
                [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
            }
        }
        [self performSegueWithIdentifier:SET_VIDEO_PRIVACY_VC sender:nil];
    }
}

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	
	NSError *error = nil;
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData] options:0 error:&error];
	
	[HUD hide:YES];
	[Validation removeToastFromMemory];

    NSLog(@"LocationVC - data received");
    
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [appDelegate callLogOutService];
        }
        else{
            if (request.tag == 1) {
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil && ((NSArray*)response).count > 0) {
                            
                            NSArray *arr = [NSArray arrayWithArray:(NSArray *)response];
                            if (arr.count>0) {

//                                [self performSelectorOnMainThread:@selector(setDataInArray:) withObject:arr waitUntilDone:NO];
//                                [self setDataInArray:arr];
                                [self addNewAnnotationsToArray:arr];
                                dispatch_async(dispatch_get_main_queue(),^{
                                    [self setDataInArray:arr];
                                    
                                });
                                
                            }
                            else{
                                
                            }
                            arr = nil;
                        }
                    }
                }
                else{
                    
                }
                [HUD hide:YES];
            }
            else if (request.tag == 2){
                //req sent
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    NSLog(@"dic = %@",[dicResponse valueForKey:STATUS]);
                    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:self.selectedIndex]];
                    [dic setValue:@"1" forKey:IS_FRND_REQ_SENT];
                    [self.arrData replaceObjectAtIndex:self.selectedIndex withObject:dic];
                    [Validation showToastMessage:@"Request Sent" displayDuration:SUCCESS_MSG_DURATION];
                    [self.tblData reloadData];
                    dic = nil;
                }
            }
            else if (request.tag == 3 || request.tag == 4){
                //req accept reject
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    NSLog(@"dic = %@",[dicResponse valueForKey:STATUS]);
                    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:self.selectedIndex]];
                    if (request.tag == 3) {
                        //accepted so isFriend = true
                        [dic setValue:@"1" forKey:IS_FRIEND];
                    }
                    else{
                        [dic setValue:@"0" forKey:IS_FRND_REQ_REC];
                    }
                    [self.arrData replaceObjectAtIndex:self.selectedIndex withObject:dic];
                    
                    dic = nil;
                    
                    [self.tblData reloadData];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
	
	self.request = nil;
	[Validation ResizeViewForAds];
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

-(void)setDataInArray:(NSArray *)arr{
    for (int i =0; i<(int)arr.count; i++) {
        
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arr objectAtIndex:i]];
        [dic setValue:@"0" forKey:IS_SELECTED];
        [self.arrData addObject:dic];
        
        dic = nil;
    }
    [self.tblData reloadData];
   
}

-(void)addNewAnnotationsToArray:(NSArray *)arr{
    NSMutableArray* annotations = [[NSMutableArray alloc] init] ;
    
    for (int i =0; i<(int)arr.count; i++) {
        
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arr objectAtIndex:i]];
        CLLocationCoordinate2D theCoordinate1;
        double lat = [[dic valueForKey:@"lat"] doubleValue];
        double longi = [[dic valueForKey:@"lng"] doubleValue];
        theCoordinate1.latitude = lat;
        theCoordinate1.longitude = longi;
        
        
        MultipleAnnotationLocation* myAnnotation1 = [[MultipleAnnotationLocation alloc] init] ;
        
        myAnnotation1.coordinate=theCoordinate1;
        myAnnotation1.title=[NSString stringWithFormat:@"%@",[dic valueForKey:NAME]];
        myAnnotation1.subTitle=[NSString stringWithFormat:@"%@",[dic valueForKey:USER_NAME]];
        myAnnotation1.annotationIndex = i+1;
        
        [self.mapView addAnnotation:myAnnotation1];
        [annotations addObject:myAnnotation1];
        
        dic = nil;
    }
    [self setPositionsOnMap:annotations];
}

-(void)setPositionsOnMap:(NSArray *)annotations{
    // Append this code at the end of viewDidLoad method to concentratet the Map
    // Walk the list of overlays and annotations and create a MKMapRect that
    // bounds all of them and store it into flyTo.
    MKMapRect flyTo = MKMapRectNull;
    for (MultipleAnnotationLocation *annotation in annotations) {
        NSLog(@"fly to on");
        MKMapPoint annotationPoint = MKMapPointForCoordinate(annotation.coordinate);
        MKMapRect pointRect = MKMapRectMake(annotationPoint.x, annotationPoint.y, 0, 0);
        if (MKMapRectIsNull(flyTo)) {
            flyTo = pointRect;
        } else {
            flyTo = MKMapRectUnion(flyTo, pointRect);
        }
    }
    
    // Position the map so that all overlays and annotations are visible on screen.
    self.mapView.visibleMapRect = flyTo;

}
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:RECORD_OPTION_VC] || [segue.identifier isEqualToString:CAPTURE_IMAGE_VC] || [segue.identifier isEqualToString:SET_VIDEO_PRIVACY_VC]) {

        
        if (appDelegate.dic_NotificationReleatedData != nil) {
            appDelegate.dic_NotificationReleatedData = nil;
        }
        
        NSMutableArray *arr = [[NSMutableArray alloc] init] ;
        for (int i = 0; i<self.arrData.count; i++) {
            if ([[[self.arrData objectAtIndex:i] valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
                [arr addObject:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:i] valueForKey:MAP_LIST_USER_ID]]];
            }
        }
        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    arr,SelectedIds,
                                                    [NSNumber numberWithBool:FALSE],IS_GroupNotif,
                                                    [NSNumber numberWithBool:NO],IS_NotifSendToAll,
                                                    nil];
	}
    
    [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
    [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];

}

@end
