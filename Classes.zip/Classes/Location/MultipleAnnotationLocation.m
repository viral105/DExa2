//
//  MultipleAnnotationLocation.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 20/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "MultipleAnnotationLocation.h"



@implementation MultipleAnnotationLocation

@end
