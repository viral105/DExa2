//
//  MultipleAnnotationLocation.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 20/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>


@interface MultipleAnnotationLocation : NSObject <MKAnnotation>
@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
@property (nonatomic, copy) NSString                 *title;
@property (nonatomic, copy) NSString                 *subTitle;
@property (nonatomic, assign) AsyncImageView         *imgProfile;
@property (nonatomic, readwrite) int                 annotationIndex;
@end
