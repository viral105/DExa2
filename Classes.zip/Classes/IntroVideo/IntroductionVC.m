//
//  IntroductionVC.m
//  WWHHAAZZAAPP
//
//  Created by Nivid Jain on 2/23/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "IntroductionVC.h"

@interface IntroductionVC ()

@end

@implementation IntroductionVC


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - View Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *btnSkip = (UIButton *)[self.view viewWithTag:110];
    
    [btnSkip.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [btnSkip setTitleColor:UIColorFromRGB(0Xffffff) forState:UIControlStateNormal];

    [self playIntroVideo];
}
- (void) viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
}
#pragma mark - Play Video

-(void)playIntroVideo
{
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *moviePath = [bundle pathForResource:@"Demo" ofType:@"mp4"]; //DemoCall
    NSURL *movieURL = [NSURL fileURLWithPath:moviePath];
    
    self.theMoviPlayer = [[MPMoviePlayerController alloc] initWithContentURL:movieURL];
    // Register this class as an observer instead
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(movieFinishedCallback:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:self.theMoviPlayer];
    self.theMoviPlayer.controlStyle = MPMovieControlStyleFullscreen;
    [self.theMoviPlayer.view setFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    [self.view addSubview:self.theMoviPlayer.view];
    [self.view sendSubviewToBack:self.theMoviPlayer.view];
    
    [self.theMoviPlayer prepareToPlay];
    [self.theMoviPlayer play];
    
}

#pragma mark - Click On Next Button

-(IBAction)clickOnSkip:(id)sender
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    [self.theMoviPlayer stop];
    self.theMoviPlayer = nil;
    
   // [self performSegueWithIdentifier:USER_INTEREST_VC sender:self];
    ProfileVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:PROFILE_VC];
    
    [self.navigationController pushViewController:obj animated:NO];

}
- (void)movieFinishedCallback:(NSNotification*)aNotification
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    [self.theMoviPlayer stop];
    self.theMoviPlayer = nil;
   // [self performSegueWithIdentifier:USER_INTEREST_VC sender:self];
    ProfileVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:PROFILE_VC];
    
    [self.navigationController pushViewController:obj animated:NO];
    //Move to Next Controller
}
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
//    if ([segue.identifier isEqualToString:USER_INTEREST_VC]) {
//        UserInterestList *ivc = segue.destinationViewController;
//        ivc.isFromRegister = self.isFromRegister;
//        ivc.strShowSkip = self.strShowSkip;
//    }
}
@end
