//
//  IntroductionVC.h
//  WWHHAAZZAAPP
//
//  Created by Nivid Jain on 2/23/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "UserInterestList.h"
#import "ProfileVC.h"

@interface IntroductionVC : UIViewController
{

}

@property (strong,nonatomic) MPMoviePlayerController *theMoviPlayer;
@property (assign,nonatomic) BOOL isFromRegister;
@property (nonatomic, strong) NSString *strShowSkip;

@end
