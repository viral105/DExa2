//
//  NotificationVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 8/6/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "NotificationVC.h"
#import "NotificationCell.h"
#import "FXBlurView.h"
#import "NotifOptionVC.h"
#import "AddFriendFromExistingFriendListVC.h"
#import "SocialShareView.h"
#import "UserInterestList.h"
#import "MBProgressHUD.h"
#import "UserConversationChatVC.h"

#define HEADER_USERNAME_KEY	@"userid"
#define HEADER_PWD_KEY		@"password"

#define kRateKey			 @"rate"
#define kStatusKey			 @"status"
#define kCurrentItemKey		 @"currentItem"
#define PageSize			10
#define CellHeight          115

#define NO_RECEIVED_NOTIF	@"No notifications in the list"
#define NO_SENT_NOTIF		@"No notifications in the list"

//#define BtnReplyTitle			@" Reply"			//@" Reply"
//#define BtnReSentTitle			@" Re-send"
#define BtnReplyTitle			@" Forward"			//@" Reply"
#define BtnReSentTitle			@" Forward"


@interface NotificationVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation NotificationVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSLog(@"notificationVc - viewDidLoad %@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]);
    
    /*
     The dispatch_get_current_queue function will return the current queue from which the block is dispatched and the dispatch_get_main_queue function will return the main queue where your UI is running.
     
     */
    
    // Do any additional setup after loading the view.
	self.arrData = [[NSMutableArray alloc] init];
	self.selectedRows = [[NSMutableSet alloc] init];
	
	appDelegate.currentVc = self;
	self.pageCounter = 1;
	self.isSentNotifList = FALSE;
	self.btnChangeNotifMode.tag = 1;
	self.isViewDidLoadCalled = TRUE;
	self.lbl_NoDataAvailable.hidden = TRUE;
	self.isDataNull = NO;
    self.tblData.tag = 101;

    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	
	// Regiser for HUD callbacks so we can remove it from the window at the right time
	HUD.delegate = self;

    dispatch_async(dispatch_get_main_queue(),^{
        
           [self LoadViewSetting];
           [self addRefreshObjectToTable];
    });
    
   [Validation getCurrentLocation];
    
    if ([Validation setOverlayFlags:1]) {
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
        [imgView setImage:[UIImage imageNamed:@"convos@2x.png"]];
        [imgView setUserInteractionEnabled:YES];
        
        UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(overlayImageTaped:)];
        [tapGes setNumberOfTapsRequired:1];
        [imgView addGestureRecognizer:tapGes];
        tapGes = nil;
        
        [[[UIApplication sharedApplication] keyWindow] addSubview:imgView];
    }
    
}

-(void)addRefreshObjectToTable{
    //pull to refresh
	self.refresh = [[UIRefreshControl alloc] init];
	
	self.refresh.attributedTitle = [[NSAttributedString alloc] initWithString:@""];
	self.refresh.tintColor = [UIColor clearColor];
    self.refresh.backgroundColor = [UIColor clearColor];
    [self.refresh addSubview:[Validation showPullToRefreshLoaderInView:self.refresh]];
    [self.refresh addTarget:self action:@selector(loadNewData) forControlEvents:UIControlEventValueChanged];
    
	[self.tblData addSubview:self.refresh];
}

-(void)setCountLabel{
    if ([appDelegate.currentVc isKindOfClass:[self class]]) {
        if ([[Validation.dicNotifCount valueForKey:TOTAL_NOTIF_COUNT] intValue] >0) {
            [self.lblTotalNotifCount setHidden:NO];
            if (appDelegate.isChannelStaticBadgeShow) {
                self.lblTotalNotifCount.text = [NSString stringWithFormat:@"%d",[[Validation.dicNotifCount valueForKey:TOTAL_NOTIF_COUNT] intValue]+1];
            }
            else{
                self.lblTotalNotifCount.text = [NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_NOTIF_COUNT]];
            }
            CGSize size = CGSizeMake(1000, 50);
            CGRect text = [self.lblTotalNotifCount.text boundingRectWithSize:size
                                                                     options:NSStringDrawingUsesLineFragmentOrigin
                                                                  attributes:@{NSFontAttributeName:self.lblTotalNotifCount.font}
                                                                     context:nil];
            
            self.lblTotalNotifCount.frame = CGRectMake(self.btnMenu.frame.origin.x+self.btnMenu.frame.size.width-10, self.btnMenu.frame.origin.y+5, text.size.width+10, text.size.height+7);
            
            self.lblTotalNotifCount.layer.cornerRadius = (text.size.width+5)/3;
            [UIApplication sharedApplication].applicationIconBadgeNumber = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_NOTIF_COUNT]] intValue];
        }
        else{
            [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
            [self.lblTotalNotifCount setHidden:YES];
        }
    }
}

-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
	
    NSLog(@"notificationVc - viewWillAppear");
    NSLog(@"ViewControllers = %@",self.navigationController.viewControllers);
    
    //set menu image
    [self.btnMenu removeTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
	[self.btnMenu addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
    appDelegate.currentVc = self;
    appDelegate.isForwarded = NO;
    appDelegate.selectedMenuIndex = 0;
	[Validation removeAdviewFromSuperView];
	[self.view addSubview:[Validation sharedBannerView]];
	//[Validation ResizeViewForAds];
	
    [self setCountLabel];
    
	
    
    if (appDelegate.isAppInActive) {
        
        appDelegate.isAppInActive = NO;
        [appDelegate handleAPNSWithDic:appDelegate.dic_APNS];
    }
    
    if (!self.isServiceWaitingForResponse) {
        
        if (self.pageCounter <= 1 && self.tblData.tag!=102) {
            [HUD show:YES];
            [self performSelector:@selector(get_ConversationListWithUsers) ];
        }
    }
    
    if (appDelegate.isLoadConversationFromNotif) {
        NSLog(@"**********************************************");
    }
    else{
        NSLog(@"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
    }
    //checking notif flow
 //   [appDelegate checkForNotification];
}

/*
-(void)removeAndReleaseSocialView{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
     self.objShareVC.view.alpha = 0;
    [UIView commitAnimations];
    
    [self performSelector:@selector(RemoveSocialViewFromSuperView) withObject:nil afterDelay:0.5];
}

- (void)removeSocialShareContainerFromParentVC{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
    self.objShareVC.view.alpha = 0;
    [UIView commitAnimations];
    
    [self performSelector:@selector(RemoveSocialViewFromSuperView) withObject:nil afterDelay:0.5];
}

-(void)RemoveSocialViewFromSuperView{
    [self.objShareVC.view removeFromSuperview];
    [self.objShareVC removeFromParentViewController];
    self.objShareVC = nil;
}
*/

-(void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
	
    if (self.request) {
        [self.request CancleOngoingRequest];
        [self.request setDelegate:nil];
        self.request = nil;
    }
    
	if ([self.tblData isEditing]) {
		self.isEditing = NO;
        [self.tblData setEditing:NO animated:YES];
        
		[self hideDeleteBtn];
        [self.tblData reloadData];
	}
		
	if (appDelegate.player !=nil) {
		[appDelegate.player pause];
	}
	
    [HUD hide:YES];
	self.isServiceWaitingForResponse = NO;
    appDelegate.isShouldShowReplyPopUp = NO;
    appDelegate.isLoadConversationFromNotif = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark	Methods

-(void)LoadViewSetting{
	
//	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    [self.view setBackgroundColor:UIColorFromRGB(0Xefefef)];
    [self.tblData setBackgroundColor:[UIColor clearColor]];
    //[self.btnDelete setBackgroundColor:UIColorFromRGB(0Xff5252)];
    [self.btnDelete setBackgroundImage:[UIImage imageNamed:BtnDeleteRed] forState:UIControlStateNormal];

    [self.lbl_NoDataAvailable setTextColor:TWITTER_BLUE_COLOR];
    [self.lbl_NoDataAvailable setShadowColor:[UIColor clearColor]];
	//-----
	self.tblData.allowsMultipleSelectionDuringEditing = YES;
	[self.tblData setValue:[UIColor grayColor] forKeyPath:@"multiselectCheckmarkColor"];
	//-----
	self.viewNotificationMenuContainer.frame = CGRectMake(0, (-NUMBER_OF_MENU_OPTION*MENU_BTN_HEIGHT)-64, 320, NUMBER_OF_MENU_OPTION*MENU_BTN_HEIGHT);
	
	[self.lblChangeNotifMode setFont:[UIFont fontWithName:Font_Montserrat_Regular size:17]];
    
    self.lblTotalNotifCount.backgroundColor = UIColorFromRGB(0Xfcc848);
    self.lblTotalNotifCount.textColor = [UIColor whiteColor];
    self.lblTotalNotifCount.font = [UIFont fontWithName:Font_Montserrat_Bold size:12];
    self.lblTotalNotifCount.layer.borderColor = [UIColor whiteColor].CGColor;
    self.lblTotalNotifCount.layer.borderWidth = 1;
    self.lblTotalNotifCount.clipsToBounds = YES;
    self.lblTotalNotifCount.textAlignment = NSTextAlignmentCenter;

    if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON]) {
        [self.btnQuietMode setBackgroundImage:[UIImage imageNamed:@"icn_topbar_quiet_on.png"] forState:UIControlStateNormal];
    }
    else{
        [self.btnQuietMode setBackgroundImage:[UIImage imageNamed:@"icn_topbar_quiet_off.png"] forState:UIControlStateNormal];
    }
}
-(void)overlayImageTaped:(UIGestureRecognizer *)gesRecognizer{
    [gesRecognizer.view removeFromSuperview];
}
/*
-(IBAction)btnChangeNotifModeClicked:(id)sender{
	UIButton *btn = (UIButton *)sender;
	[self hideMenu];
	if (btn.tag == 0) {

		[self showMenu];
		[self.btnChangeNotifMode setImage:[UIImage imageNamed:BtnNotifShowMenu] forState:UIControlStateNormal];
	}
	else{
		[self showMenu];
		[self.btnChangeNotifMode setImage:[UIImage imageNamed:BtnNotifHideMenu] forState:UIControlStateNormal];
	}
}
*/
-(IBAction)btnSettingsClicked:(id)sender{

//	[self.request cancel];
//	[self.request clearDelegatesAndCancel];
    
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
	self.request = nil;

	[self performSegueWithIdentifier:SETTINGS_VC sender:nil];
}

-(IBAction)btnNearByMeClicked:(id)sender{
    [Validation CancelOnGoingRequests:self.request];
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
	self.request = nil;

	[self performSegueWithIdentifier:USER_LOCATION_VC sender:nil];

}

-(IBAction)btnFriendsInvitationListClicked:(id)sender{
	[Validation CancelOnGoingRequests:self.request];
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
	self.request = nil;

	[self performSegueWithIdentifier:OTHER_FRNDREQ_NOTIF_LIST_VC sender:nil];
}

-(IBAction)btnSearchFriendsClicked:(id)sender{
	[Validation CancelOnGoingRequests:self.request];
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
	self.request = nil;

	[self performSegueWithIdentifier:SEARCH_CONTAINER_VC sender:nil];
}

-(IBAction)btnAddFriendsClicked:(id)sender{
	[Validation CancelOnGoingRequests:self.request];
    appDelegate.isForwarded = NO;
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
	self.request = nil;

	[self performSegueWithIdentifier:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC sender:nil];
}

- (void)killScroll {
    CGPoint offset = self.tblData.contentOffset;
    [self.tblData setContentOffset:offset animated:NO];
}

-(void)loadNewData{
	if ([self.refresh isRefreshing]) {
        
		self.pageCounter = 1;
		self.isDataNull = NO;

        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.2];
        Validation.viewPullToRefresh.alpha = 1;
        [UIView commitAnimations];

        [self performSelector:@selector(get_ConversationListWithUsers) ];
	}
}

- (void)animateRefreshView
{
    // Flag that we are animating
    [UIView animateWithDuration:0.3
                          delay:0
                        options:UIViewAnimationOptionCurveLinear
                     animations:^{
                         // Rotate the spinner by M_PI_2 = PI/2 = 90 degrees
                         [Validation.imgLoading setTransform:CGAffineTransformRotate(Validation.imgLoading.transform, M_PI_2)];
                     }
                     completion:^(BOOL finished) {
                         // If still refreshing, keep spinning, else reset
                         if (self.refresh.isRefreshing) {
                             [self animateRefreshView];
                         }else{
                             [UIView beginAnimations:nil context:nil];
                             [UIView setAnimationDuration:0.2];
                             Validation.viewPullToRefresh.alpha = 0;
                             [UIView commitAnimations];
                             [self.refresh endRefreshing];
                             self.isAnimationStarted = FALSE;
                         }
                     }];
}





-(void)playSoundForURL:(id)sender{
    
    UIButton *btn = ((UIButton *)sender);
    self.selectedIndex   = (int)btn.tag;
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
	self.request = nil;

    [self performSegueWithIdentifier:USER_CONVERSATION_CHAT_VC sender:NULL];
    //before it displays popup and play the selected Blab, now as this is a user detail with whome conversation has been created so it will go to next screen that shows conversation Blab chat
    
    
    
//    dispatch_async(dispatch_get_main_queue(),^{
//        
//        [self updateTableViewAtIndex:sender];
//        [self play:(int)btn.tag];
//    });
}

-(void)updateTableViewAtIndex:(id)sender {
    
    UIButton *btn = ((UIButton *)sender);
    int index = (int)btn.tag;
	[btn setImage:[UIImage imageNamed:BtnNotifRead] forState:UIControlStateNormal];
	NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    NotificationCell *cell = (NotificationCell *)[self.tblData cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
    cell.cellBg.image = [UIImage imageNamed:LilstBox_Bg_Notif];
    cell.img_user_unread_notif.hidden = YES;
    
    if (![[NSString stringWithFormat:@"%@",[dic valueForKey:IS_NOTIF_READ]] boolValue]) {
        [self performSelectorInBackground:@selector(setNotifAsReadForNotifId:) withObject:[[self.arrData objectAtIndex:index] valueForKey:NOTIF_ID]];
    }
    
    [dic setValue:@"1" forKey:IS_NOTIF_READ];
    [self.arrData replaceObjectAtIndex:index withObject:dic];
    
    dic = nil;
    
}
-(void)play:(int)index{
    
	self.selectedIndex = index;
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:index]];
    
    [Validation showAPNS_ReplyPopUp:dic forId:1];
    
    [Validation.apnsReplyPopUp.btnPlay setTitle:@"Reply" forState:UIControlStateNormal];
    [Validation.apnsReplyPopUp.btnClose addTarget:self action:@selector(closeReplyPopup:) forControlEvents:UIControlEventTouchUpInside];
    [Validation.apnsReplyPopUp.btnPlay addTarget:self action:@selector(apnsReplyToUser:) forControlEvents:UIControlEventTouchUpInside];
    [Validation.apnsReplyPopUp.btnPlayPause addTarget:self action:@selector(PlaySoundAtIndex:) forControlEvents:UIControlEventTouchUpInside];
    
    Validation.apnsReplyPopUp.btnClose.tag = index;
    Validation.apnsReplyPopUp.btnPlay.tag = index;
    Validation.apnsReplyPopUp.btnPlayPause.tag = index;
    NSString *strURL = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_AUDIO_PATH]];
    //NSError *error = nil;
    
    [appDelegate playSoundForURL:[NSURL URLWithString:strURL]];
    
}

-(void)closeReplyPopup:(id)sender{
    [appDelegate closeReplyPopup];
    [Validation hideAPNS_ReplyPopup];
}

-(void)apnsReplyToUser:(id)sender{
    [appDelegate closeReplyPopup];
    [self btnReplyClicked:sender];
}

-(void)PlaySoundAtIndex:(id)sender{
    NSString *strURL = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:NOTIF_AUDIO_PATH]];
    
    [appDelegate playSoundForURL:[NSURL URLWithString:strURL]];
}

-(void)btnDeleteClicked:(id)sender{

	if (self.selectedRows.count>0) {
		[self showDeleteBtn];
	}
	else{
		[self hideDeleteBtn];
	}
	
	if ([self.tblData isEditing]) {
		[self.selectedRows removeAllObjects];
		self.isEditing = NO;
        [self.tblData setEditing:NO animated:YES];
        
		[self hideDeleteBtn];
        [self.tblData reloadData];
	}
	else{
		self.isEditing = YES;
        [self.tblData setEditing:YES animated:YES];
        [self.tblData reloadData];
		
	}
}

-(void)btnForwardClicked:(id)sender{
    UIButton *btn = (UIButton *)sender;
    
    if (![[[self.arrData objectAtIndex:btn.tag] valueForKey:IS_PRIVATE] boolValue]) {
        self.selectedIndex = (int)btn.tag;
        [Validation CancelOnGoingRequests:self.request];
        appDelegate.isForwarded = YES;
        [self.request CancleOngoingRequest];
        [self.request setDelegate:nil];
        self.request = nil;

        [self performSegueWithIdentifier:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC sender:nil];
    }
    else{
        if (self.isSentNotifList) {
            self.selectedIndex = (int)btn.tag;
            [Validation CancelOnGoingRequests:self.request];
            appDelegate.isForwarded = YES;

            [self.request CancleOngoingRequest];
            [self.request setDelegate:nil];
            self.request = nil;

            [self performSegueWithIdentifier:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC sender:nil];
        }
        else{
            [Validation showToastMessage:@"You cannot forward a private Blabeey!!" displayDuration:ERROR_MSG_DURATION];
        }
    }
}


-(void)btnResentClicked:(id)sender{
	self.selectedIndex = (int)((UIButton *)sender).tag;
	[Validation CancelOnGoingRequests:self.request];
    appDelegate.isForwarded = NO;
    
    [self showYapOptions];
}

-(void)btnReplyClicked:(id)sender{
	self.selectedIndex = (int)((UIButton *)sender).tag;
	[Validation CancelOnGoingRequests:self.request];
    appDelegate.isForwarded = NO;
    [self showYapOptions];
}
-(IBAction)btnQuietMode_Clicked:(id)sender{
//    UIButton *btn = (UIButton *)sender;
    if (self.request) {
        self.request = nil;
    }
    [HUD show:YES];
    NSDictionary *dic;
    if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON]) {
        
        dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"QuietMode",KeyName, nil],@"2",
                             [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"OffNotification",KeyName, nil],@"3",
                             nil];
        
    }
    else{
        
        dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
               [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"QuietMode",KeyName, nil],@"2",
               [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"OffNotification",KeyName, nil],@"3",
               nil];
    }
    
    NSString *strUrl = [WebServiceContainer getServiceURL:UPDATE_USER_SETTING withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:6];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:6];
    
    strUrl = nil;
    NSLog(@"call initiated");
}
-(void)showYapOptions{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Select" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:Only_Yap,Yap_With_Image,Yap_With_Video, nil];
    [action showInView:self.view];
    action.delegate = self;
}
-(void)ShowFavoriteList{
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
	self.request = nil;

    [self performSegueWithIdentifier:FAVORITES_LIST_VC sender:nil];
}

-(void)btnFavoriteClicked:(id)sender{
    
    self.selectedIndex = (int)((UIButton *)sender).tag;
    [Validation CancelOnGoingRequests:self.request];
    appDelegate.isForwarded = NO;
//    dispatch_async(dispatch_get_main_queue(),^{
//        
//        [self SetSelectedNotifToFavorites];
//    });

    [self SetSelectedNotifToFavorites];
}

-(void)btnBlockUserClicked:(id)sender{
    [AlertHandler alertTitle:MESSAGE message:[NSString stringWithFormat:@"Are you sure you want to block %@?",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:NAME]] delegate:self tag:(int)((UIButton *)sender).tag cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
}

-(void)changeLikeButtonImageInListForDic:(NSMutableDictionary *)dic{
    
    BOOL isLike = [[NSString stringWithFormat:@"%@",[dic valueForKey:IS_LIKE]] boolValue];
    if (isLike) {
        [dic setValue:@"0" forKeyPath:IS_LIKE];
    }
    else{
        [dic setValue:@"1" forKeyPath:IS_LIKE];
    }
    
    [self.arrData replaceObjectAtIndex:self.selectedIndex withObject:dic];
    NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:self.selectedIndex inSection:0]];
    [self.tblData beginUpdates];
    [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
    [self.tblData endUpdates];
}

/*
-(IBAction)btnMainMenuClicked:(id)sender{
    
    [self hideMenu];
    
    if (self.objShareVC == nil) {
        UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        self.objMenuVC = [storyBoard instantiateViewControllerWithIdentifier:MENU_VC];
        self.objMenuVC.delegate = self;
        self.objMenuVC.view.frame = CGRectMake(0, 0, 320, self.view.frame.size.height);
        self.objMenuVC.tblMenu.frame = CGRectMake(-120, 0, 120, self.objMenuVC.view.frame.size.height);
        self.objMenuVC.btnMenu.frame = CGRectMake(-20, self.objMenuVC.btnMenu.frame.origin.y, self.objMenuVC.btnMenu.frame.size.width, self.objMenuVC.btnMenu.frame.size.height);
        [self.view addSubview:self.objMenuVC.view];
        [self.objShareVC didMoveToParentViewController:self];
        [self addChildViewController:self.objMenuVC];
        
        [UIView beginAnimations:@"ShowMenu" context:nil];
        [UIView setAnimationDuration:0.3];
        self.objMenuVC.tblMenu.frame = CGRectMake(0, 0, 120, self.objMenuVC.view.frame.size.height);
        self.objMenuVC.btnMenu.frame = CGRectMake(130, self.objMenuVC.btnMenu.frame.origin.y, self.objMenuVC.btnMenu.frame.size.width, self.objMenuVC.btnMenu.frame.size.height);
        [UIView commitAnimations];
    }
    else{
        [UIView beginAnimations:@"HideMenu" context:nil];
        [UIView setAnimationDuration:0.3];
        self.objMenuVC.tblMenu.frame = CGRectMake(-120, 0, 120, self.objMenuVC.view.frame.size.height);
        self.objMenuVC.btnMenu.frame = CGRectMake(-20, self.objMenuVC.btnMenu.frame.origin.y, self.objMenuVC.btnMenu.frame.size.width, self.objMenuVC.btnMenu.frame.size.height);
        [UIView commitAnimations];
        [self performSelector:@selector(removeMainMenu) withObject:nil afterDelay:1];
       
   }
}
*/

/*
-(void)removeMainMenu{
    [self.objMenuVC.view removeFromSuperview];
    [self.objMenuVC removeFromParentViewController];
    self.objMenuVC = nil;
    
     [self setCountLabel];
}

- (void)SetVc{
    int selectedIndex = [self.objMenuVC.strSelectedIndex intValue];
    [self removeMainMenu];
    switch (selectedIndex) {
        case 0:
            
            break;
        case 1:
            [self btnAddFriendsClicked:nil];
            break;
        case 2:
            [self btnFriendsInvitationListClicked:nil];
            break;
        case 3:
            [self btnSearchFriendsClicked:nil];
            break;
        case 4:
            [self ShowFavoriteList];
            break;
        case 5:
            [self btnNearByMeClicked:nil];
            break;
        case 6:
            [self btnSettingsClicked:nil];
            break;
        default:
            break;
    }
}
- (void)hideVC{
    
}
*/

#pragma mark  UITableViewDelegate

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
//    [self hideMenu];
    
    if ([self.refresh isRefreshing] && !self.isAnimationStarted) {
        CGRect refreshBounds = self.refresh.bounds;
        
        // Distance the table has been pulled >= 0
        CGFloat pullDistance = MAX(0.0, -self.refresh.frame.origin.y);
        
        // Half the width of the table
        CGFloat midX = self.refresh.frame.size.width / 2.0;
        
        CGFloat spinnerHeight = Validation.imgLoading.bounds.size.height;
        CGFloat spinnerHeightHalf = spinnerHeight / 2.0;
        
        CGFloat spinnerWidth = Validation.imgLoading.bounds.size.width;
        CGFloat spinnerWidthHalf = spinnerWidth / 2.0;
        
        // Calculate the pull ratio, between 0.0-1.0
        CGFloat pullRatio = MIN( MAX(pullDistance, 0.0), 100.0) / 100.0;
        
        CGFloat spinnerY = pullDistance / 2.0 - spinnerHeightHalf;
        
        CGFloat spinnerX = (midX - spinnerWidth - spinnerWidthHalf) + (spinnerWidth * pullRatio);
        
        // If the graphics have overlapped or we are refreshing, keep them together
        if (self.refresh.isRefreshing) {
            spinnerX = midX - spinnerWidthHalf;
        }

        CGRect spinnerFrame = Validation.imgLoading.frame;
        spinnerFrame.origin.x = spinnerX;
        spinnerFrame.origin.y = spinnerY;
        
        Validation.imgLoading.frame = spinnerFrame;
        
        // Set the encompassing view's frames
        refreshBounds.size.height = pullDistance;
        
        Validation.viewPullToRefresh.frame = refreshBounds;
        
        self.isAnimationStarted = TRUE;
        // If we're refreshing and the animation is not playing, then play the animation
        if (self.refresh.isRefreshing) {
            [self animateRefreshView];
        }
    }
}
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    [self.view endEditing:YES];
    
    //    UITableView *tblRegister = (UITableView*) [self.view viewWithTag:kSignUpTableViewTag];
    //    [tblRegister setContentOffset:CGPointMake(0, 0) animated:YES];
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *viewFooter = [[UIView alloc] initWithFrame:CGRectZero];
    viewFooter.backgroundColor = [UIColor clearColor];
    
    return viewFooter;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 44;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return CellHeight;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//	return 1;
	if (!self.isDataNull) {
		if (self.arrData.count>PageSize-1) {
			return self.arrData.count+1;
		}
		return self.arrData.count;
	}
	return self.arrData.count;
	
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
//	NSString *cellId = [NSString stringWithFormat:@"%d",(int)indexPath.row];
//	
//	if (indexPath.row < self.arrData.count) {
//		cellId = [cellId stringByAppendingFormat:@"%@",[[self.arrData objectAtIndex:indexPath.row] valueForKey:@"ID"]];
//	}
	
	NotificationCell *cell = (NotificationCell *)[tableView dequeueReusableCellWithIdentifier:@"cellIdentifier"];
	[cell clearsContextBeforeDrawing];
	if (!self.isDataNull && (indexPath.row == (self.arrData.count+1) || indexPath.row == self.arrData.count)){
	
		if (!self.isDataNull) {
			cell.cellBg.hidden = YES;
			cell.btnNotificationDelete.hidden= YES;
			cell.btnNotificationDetail.hidden = YES;
			cell.btnNotificationForward.hidden = YES;
			cell.btnNotificationProfile.hidden = YES;
			cell.lblUserName.hidden = YES;
			cell.lblCategory.hidden = YES;
			cell.lblDuration.hidden = YES;
			cell.ProfileImg.hidden = YES;
			cell.img_user_unread_notif.hidden = YES;
			cell.imgNotifTime.hidden = YES;
			cell.btnDelete.hidden = YES;
            cell.btnNotificationShare.hidden = YES;
            cell.btnNotificationShare.hidden = YES;
            cell.btnNotificationFavorites.hidden = YES;
			cell.btnNotificationWithImage.hidden = YES;
            cell.btnNotificationUserBlock.hidden = YES;
            cell.viewUnreadCount.hidden = YES;
            cell.lblUnreadCount.hidden = YES;
            
			if (self.activityLoading != nil) {
				[self.activityLoading removeFromSuperview];
				self.activityLoading = nil;
			}
			self.activityLoading = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
			self.activityLoading.center = cell.contentView.center;
			self.activityLoading.frame = cell.contentView.frame;
			self.activityLoading.hidesWhenStopped = TRUE;
			[self.activityLoading startAnimating];
			[cell.contentView addSubview:self.activityLoading];
			
			self.pageCounter ++;
			[self performSelectorInBackground:@selector(get_ConversationListWithUsers) withObject:nil];
		}
	}
    else{

        [cell.btnNotificationUserBlock removeTarget:self action:@selector(btnBlockUserClicked:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnNotificationConversation removeTarget:self action:@selector(playSoundForURL:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnNotificationDelete removeTarget:self action:@selector(btnDeleteClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:indexPath.row]];

        if (self.arrData.count >0) {
            if (self.isSentNotifList) {
             [dic setValue:@"1" forKey:IS_SENT_NOTIF_LIST];
            }
            
            [cell setBoxValuesForConversationUserListingWithData:dic];

        }
        /*
         public enum UserType
         {
         Admin = 1,
         User = 2,
         AdminUser = 3
         }

         */
        int userType = [[NSString stringWithFormat:@"%@",[dic valueForKey:USERTYPE]] intValue];

        if (userType == 2) {
            
            //UserType = 2, means it is user
            
            cell.btnNotificationDelete.hidden = NO;
            cell.btnNotificationUserBlock.hidden = NO;
            
            if (self.isEditing) {
                UIView *bgColorView = [[UIView alloc] init];
                bgColorView.backgroundColor = [UIColor clearColor];
                [cell setSelectedBackgroundView:bgColorView];
                cell.multipleSelectionBackgroundView = bgColorView;
                cell.userInteractionEnabled = YES;
                [cell setEditing:YES animated:YES];
            }
            
            NSString *strGroupId = [NSString stringWithFormat:@"%@",[dic valueForKey:@"GroupID"]];
            
            if ([DataValidation checkNullString:strGroupId].length >0 && ([strGroupId intValue]!=0)) {
                //its group message
                cell.btnNotificationUserBlock.hidden = YES;
                cell.btnNotificationDelete.hidden = YES;
                if (self.isEditing) {
                    cell.userInteractionEnabled = NO;
                }
                else{
                    cell.userInteractionEnabled = YES;
                }
            }
            
        }
        else{
            //admin either type 3 or 1
            cell.btnNotificationDelete.hidden = YES;
            cell.btnNotificationUserBlock.hidden = YES;
            if (self.isEditing) {
                cell.userInteractionEnabled = NO;
            }
            else{
                cell.userInteractionEnabled = YES;
            }
        }
        
        dic = nil;
        
        [cell.btnNotificationUserBlock addTarget:self action:@selector(btnBlockUserClicked:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnNotificationConversation addTarget:self action:@selector(playSoundForURL:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnNotificationDelete addTarget:self action:@selector(btnDeleteClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.btnNotificationDetail.hidden = FALSE;
        
        cell.btnNotificationDelete.tag = indexPath.row;
        cell.btnNotificationUserBlock.tag = indexPath.row;
        cell.btnNotificationDetail.tag = indexPath.row;
        cell.btnNotificationProfile.tag = indexPath.row;
        cell.btnNotificationConversation.tag = indexPath.row;
    }
	return cell;
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath{
    NotificationCell *cell = (NotificationCell *)[tableView cellForRowAtIndexPath:indexPath];
    if (tableView.isEditing) {
        cell.lblCategory.textColor = [UIColor whiteColor];
    }
    
    // Update the delete button's title based on how many items are selected.
	NSNumber *rowNsNum = [NSNumber numberWithUnsignedInt:(int)indexPath.row];
    
	if ( [self.selectedRows containsObject:rowNsNum] )
		[self.selectedRows removeObject:rowNsNum];
    
	if (self.selectedRows.count>0) {
		[self showDeleteBtn];
	}
	else{
		[self hideDeleteBtn];
		self.isEditing = NO;
        [self.tblData setEditing:NO animated:YES];
        
        [self.tblData reloadData];
	}
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
  //  [self hideMenu];
    
    NotificationCell *cell = (NotificationCell *)[tableView cellForRowAtIndexPath:indexPath];
    
    if (!tableView.isEditing) {
        [tableView deselectRowAtIndexPath:indexPath animated:NO];
        cell.lblCategory.textColor = [UIColor whiteColor];
        
    }
    else{
        cell.lblCategory.textColor = [UIColor blackColor];
//        UIView *bgColorView = [[UIView alloc] init];
//        bgColorView.backgroundColor = [UIColor clearColor];
//        [cell setSelectedBackgroundView:bgColorView];
//        cell.multipleSelectionBackgroundView = bgColorView;
//        bgColorView = nil;

        if (!cell.lblUnreadCount.hidden) {
            cell.lblUnreadCount.backgroundColor = UIColorFromRGB(0X00c2d9);
        }
        // Update the delete button's title based on how many items are selected.
        NSNumber *rowNsNum = [NSNumber numberWithUnsignedInt:(int)indexPath.row];
        /*
         public enum UserType
         {
         Admin = 1,
         User = 2,
         AdminUser = 3
         }
         */
        NSDictionary *dic = [NSDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:indexPath.row]];
        int userType = [[NSString stringWithFormat:@"%@",[dic valueForKey:USERTYPE]] intValue];

        if (userType == 2) {
            if ( [self.selectedRows containsObject:rowNsNum] )
                [self.selectedRows removeObject:rowNsNum];
            else
                [self.selectedRows addObject:rowNsNum];

        }
		
        if (self.selectedRows.count>0) {
            [self showDeleteBtn];
        }
        else{
            [self hideDeleteBtn];
            self.isEditing = NO;
            [self.tblData setEditing:NO animated:YES];
            
            [self.tblData reloadData];
        }
    }
}

-(void)showDeleteBtn{
    
	self.btnDelete.hidden = FALSE;
	[Validation removeAdviewFromSuperView];
	//self.tblData.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-(64)-(64));
}

-(void)hideDeleteBtn{

	[UIView beginAnimations:@"moveDown" context:nil];
	[UIView setAnimationDuration:0.5];
//	self.tblData.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-64);
	self.btnDelete.hidden = TRUE;
	[UIView commitAnimations];
	
	[Validation removeAdviewFromSuperView];
	[self.view addSubview:[Validation sharedBannerView]];
}

#pragma mark UIAlertview Delegate

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (!buttonIndex == alertView.cancelButtonIndex) {
        [self BlockSelectedUser:[self.arrData objectAtIndex:alertView.tag]];
    }
}

#pragma mark
#pragma mark web service method


- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    if ([appDelegate.currentVc isKindOfClass:[self class]]) {
    NSLog(@"tag = %d",tag);
    if (self.activityLoading != nil) {
		[self.activityLoading removeFromSuperview];
		self.activityLoading = nil;
	}
	
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    self.lbl_NoDataAvailable.hidden = TRUE;
    
    if (dicResponse != nil) {
        
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            self.isAnimationStarted = FALSE;
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.2];
            Validation.viewPullToRefresh.alpha = 0;
            [UIView commitAnimations];
            [self.refresh endRefreshing];
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else if (![appDelegate.currentVc isKindOfClass:[self class]]){
            [HUD hide:YES];
            NSLog(@"if not current class then dont reflact any response");
        }
        else{
            if (tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            if (self.pageCounter==1) {
                                [self.arrData removeAllObjects];
                            }
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.isDataNull = NO;
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            
                            if (arr.count>0) {
                                [self.arrData addObjectsFromArray:arr];
                                
                                    [self.tblData reloadData];
                                    
                                    for (NSNumber *num in self.selectedRows) {
                                        [self.tblData selectRowAtIndexPath:[NSIndexPath indexPathForRow:[num intValue] inSection:0] animated:NO scrollPosition:UITableViewScrollPositionNone];
                                    }
                                
                            }
                            
                            arr = nil;
                        }
                        
                        response = nil;
                    }
                    else if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]){
                        self.isDataNull = YES;
                        [self.tblData reloadData];
                        if (self.arrData.count == 0) {
                            self.lbl_NoDataAvailable.hidden = FALSE;
                            [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                        }
                    }
                }
                
                if (self.arrData.count == 0 && self.pageCounter == 1) {
                    //self.lbl_NoDataAvailable.text = (self.isSentNotifList)?NO_SENT_NOTIF:NO_RECEIVED_NOTIF;
                    self.lbl_NoDataAvailable.hidden = FALSE;
                    [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                }
                self.isAnimationStarted = FALSE;
                [UIView beginAnimations:nil context:nil];
                [UIView setAnimationDuration:0.2];
                Validation.viewPullToRefresh.alpha = 0;
                [UIView commitAnimations];
                [self.refresh endRefreshing];
                [HUD hide:YES];
                self.tblData.scrollEnabled = YES;
                if (appDelegate.isLoadConversationFromNotif) {
                    [self loadConversationFromNotif];
                }
                [self performSelectorInBackground:@selector(get_NptofCount) withObject:nil];
                
            }
            else if (tag == 2){
                //delte notif
                BOOL is_NewServiceCall = FALSE;
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        [HUD hide:YES];
                        [self.selectedRows removeAllObjects];
                        self.pageCounter = 1;
                        self.isDataNull = NO;
                        [self.arrData removeAllObjects];
                        self.isEditing = NO;
                        [self.tblData setEditing:NO];
                        

                        [self.btnDelete setHidden:YES];
                        [HUD show:YES];
                        [self performSelectorInBackground:@selector(get_ConversationListWithUsers) withObject:nil];
                        is_NewServiceCall = YES;
                        
                    }
                }
                else{
                    [HUD hide:YES];
                }
                [self hideDeleteBtn];
                if (self.arrData.count == 0 && is_NewServiceCall == FALSE) {
                    // self.lbl_NoDataAvailable.text = (self.isSentNotifList)?NO_SENT_NOTIF:NO_RECEIVED_NOTIF;
                    self.lbl_NoDataAvailable.hidden = FALSE;
                    
                }
            }
            else if (tag == 3){
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        NSLog(@"%@",dicResponse);
                    }
                }
                [HUD hide:YES];
            }
            else if (tag == 4){
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        [HUD hide:YES];
                    }
                }
            }
            else if (tag == 5){
                /*
                 {
                 Response =     (
                 {
                 BlockUserID = 52;
                 IsBlock = "<null>";
                 UserID = 20191;
                 }
                 );
                 Status = 1;
                 UserStatus =     {
                 IsActive = 1;
                 IsDelete = 0;
                 Msg = success;
                 status = 1;
                 };
                 }
                 */
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        [HUD hide:YES];
                        self.pageCounter = 1;
                        [self get_ConversationListWithUsers];
                        
                    }
                }
            }
            else if (tag == 6){
                
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        NSLog(@"%d",[[[[dicResponse valueForKey:RESPONSE] objectAtIndex:0] valueForKey:@"QuietMode"] intValue]);
                        if ([[[[dicResponse valueForKey:RESPONSE] objectAtIndex:0] valueForKey:@"QuietMode"] intValue]==0) {
//                            self.btnQuietMode.tag=1001;
                            [self.btnQuietMode setBackgroundImage:[UIImage imageNamed:@"icn_topbar_quiet_off.png"] forState:UIControlStateNormal];
                            [[NSUserDefaults standardUserDefaults] setBool:FALSE forKey:IS_QUIETMODE_ON];
                            [[NSUserDefaults standardUserDefaults] setBool:FALSE forKey:IS_APNS_OFF];
                            [[NSUserDefaults standardUserDefaults] synchronize];
                            [Validation showToastMessage:@"Quiet Mode - OFF" displayDuration:ERROR_MSG_DURATION];
                        }
                        else{
//                            self.btnQuietMode.tag=1002;
                            [self.btnQuietMode setBackgroundImage:[UIImage imageNamed:@"icn_topbar_quiet_on.png"] forState:UIControlStateNormal];
                            [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:IS_QUIETMODE_ON];
                            [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:IS_APNS_OFF];
                            [[NSUserDefaults standardUserDefaults] synchronize];
                            [Validation showToastMessage:@"Quiet Mode - ON" displayDuration:ERROR_MSG_DURATION];
                        }
                        [HUD hide:YES];
                        
                    }
                }
            }
            else if (tag == 7){
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil && ((NSArray*)response).count > 0) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.isDataNull = NO;
                            if (arr.count < PageSize) {
                                [self.lbl_NoDataAvailable setHidden:YES];
                                self.isDataNull = YES;
                            }
                            if (arr.count>0) {
                                [self.arrData addObjectsFromArray:arr];
                            }
                            arr = nil;
                        }
                        if (self.arrData.count == 0 && self.pageCounter==1) {
                            [self.lbl_NoDataAvailable setHidden:NO];
                            [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                        }
                        else{
                            if (((NSArray*)response).count < PageSize) {
                                [self.lbl_NoDataAvailable setHidden:YES];
                                self.isDataNull = YES;
                            }
                        }
                    }
                }
                else{
                    if (self.arrData.count == 0 && self.pageCounter==1) {
                        [self.lbl_NoDataAvailable setHidden:NO];
                        self.isDataNull = YES;
                        [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                    }
                }
                self.tblData.tag=102;
                [self.tblData reloadData];
                [HUD hide:YES];
            }
/*            else if (tag == 7){
                //get Notif Total Count
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            NSLog(@"rezponse = %@",[response objectAtIndex:0]);
                            NSString *strFR = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_FRIENDS_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strNotif = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_UNREAD_NOTIF]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strKeepReq = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_KEEP_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strTotalCount = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_NOTIF_COUNT]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strARCount = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_ALARM_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            
                            Validation.dicNotifCount = [NSDictionary
                                                        dictionaryWithObjectsAndKeys:
                                                        strFR,TOTAL_FRIENDS_REQUEST,
                                                        strNotif,TOTAL_UNREAD_NOTIF,
                                                        strKeepReq,TOTAL_KEEP_REQUEST,
                                                        strTotalCount, TOTAL_NOTIF_COUNT,
                                                        strARCount,TOTAL_ALARM_REQUEST,
                                                        nil];
                            
                            strFR = nil;
                            strNotif = nil;
                        }
                    }
                    else{
                        
                        Validation.dicNotifCount = [NSDictionary
                                                    dictionaryWithObjectsAndKeys:
                                                    @"",TOTAL_FRIENDS_REQUEST,
                                                    @"",TOTAL_UNREAD_NOTIF,
                                                    @"",TOTAL_KEEP_REQUEST,
                                                    @"",TOTAL_NOTIF_COUNT,
                                                    @"",TOTAL_ALARM_REQUEST,
                                                    nil];
                        
                    }
                    
                    [self setCountLabel];
                }
            }
*/
        }
    }
    else{
        [HUD hide:YES];
    }
    request = nil;
	self.isServiceWaitingForResponse = NO;
    }
//    [self performSelector:@selector(getTestNotif) withObject:nil afterDelay:10];
}
-(void)getTestNotif{
    [appDelegate checkForNotification];
}
- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	
	if (self.activityLoading != nil) {
		[self.activityLoading removeFromSuperview];
		self.activityLoading = nil;
	}
	
    
    NSLog(@"notification Response");
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];
    
//    Commented by Viral. Getting issue in displaying this label when no feed found.
//    self.lbl_NoDataAvailable.hidden = TRUE;
    
    if (dicResponse != nil) {
        
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            self.isAnimationStarted = FALSE;
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.2];
            Validation.viewPullToRefresh.alpha = 0;
            [UIView commitAnimations];
            [self.refresh endRefreshing];
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else if (![appDelegate.currentVc isKindOfClass:[self class]]){
            [HUD hide:YES];
            NSLog(@"if not current class then dont reflact any response");
        }
        else{
            if (request.tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            if (self.pageCounter==1) {
                                [self.arrData removeAllObjects];
                            }
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.isDataNull = NO;
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            
                            if (arr.count>0) {
                                [self.arrData addObjectsFromArray:arr];
                                
                                [self.tblData reloadData];
                                
                                for (NSNumber *num in self.selectedRows) {
                                    [self.tblData selectRowAtIndexPath:[NSIndexPath indexPathForRow:[num intValue] inSection:0] animated:NO scrollPosition:UITableViewScrollPositionNone];
                                }
                            }
                            
                            arr = nil;
                        }
                        response = nil;
                    }
                    else if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]){
                        self.isDataNull = YES;
                        [self.tblData reloadData];
                        if (self.arrData.count == 0) {
                            self.lbl_NoDataAvailable.hidden = FALSE;
                            [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                        }
                    }
                }
                
                if (self.arrData.count == 0 && self.pageCounter == 1) {
                    //self.lbl_NoDataAvailable.text = (self.isSentNotifList)?NO_SENT_NOTIF:NO_RECEIVED_NOTIF;
                    self.lbl_NoDataAvailable.hidden = FALSE;
                    [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                }
                self.isAnimationStarted = FALSE;
                [UIView beginAnimations:nil context:nil];
                [UIView setAnimationDuration:0.2];
                Validation.viewPullToRefresh.alpha = 0;
                [UIView commitAnimations];
                [self.refresh endRefreshing];
                [HUD hide:YES];
                self.tblData.scrollEnabled = YES;
            }
            else if (request.tag == 2){
                //delte notif
                BOOL is_NewServiceCall = FALSE;
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        [HUD hide:YES];
                        [self.selectedRows removeAllObjects];
                        self.pageCounter = 1;
                        self.isDataNull = NO;
                        [self.arrData removeAllObjects];
                        self.isEditing = NO;
                        [self.tblData setEditing:NO];
                        
                        [self.btnDelete setHidden:YES];
                        [HUD show:YES];
                        [self performSelectorInBackground:@selector(get_ConversationListWithUsers) withObject:nil];
                        is_NewServiceCall = YES;
                        
                    }
                }
                else{
                    [HUD hide:YES];
                }
                [self hideDeleteBtn];
                if (self.arrData.count == 0 && is_NewServiceCall == FALSE) {
                   // self.lbl_NoDataAvailable.text = (self.isSentNotifList)?NO_SENT_NOTIF:NO_RECEIVED_NOTIF;
                    self.lbl_NoDataAvailable.hidden = FALSE;
                    
                }
            }
            else if (request.tag == 3){
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        NSLog(@"%@",dicResponse);
                    }
                }
                [HUD hide:YES];
            }
            else if (request.tag == 4){
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {

                        [HUD hide:YES];
                    }
                }
            }
            else if (request.tag == 5){
                /*
                 {
                 Response =     (
                 {
                 BlockUserID = 52;
                 IsBlock = "<null>";
                 UserID = 20191;
                 }
                 );
                 Status = 1;
                 UserStatus =     {
                 IsActive = 1;
                 IsDelete = 0;
                 Msg = success;
                 status = 1;
                 };
                 }
                 */
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        [HUD hide:YES];
                        self.pageCounter = 1;
                        [self get_ConversationListWithUsers];
                    }
                }
            }
            else if (request.tag == 7){
                //get Notif Total Count
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            NSLog(@"rezponse = %@",[response objectAtIndex:0]);
                            NSString *strFR = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_FRIENDS_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strNotif = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_UNREAD_NOTIF]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strKeepReq = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_KEEP_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strTotalCount = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_NOTIF_COUNT]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strARCount = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_ALARM_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            
                            Validation.dicNotifCount = [NSDictionary
                                                        dictionaryWithObjectsAndKeys:
                                                        strFR,TOTAL_FRIENDS_REQUEST,
                                                        strNotif,TOTAL_UNREAD_NOTIF,
                                                        strKeepReq,TOTAL_KEEP_REQUEST,
                                                        strTotalCount, TOTAL_NOTIF_COUNT,
                                                        strARCount,TOTAL_ALARM_REQUEST,
                                                        nil];
                            
                            strFR = nil;
                            strNotif = nil;
                        }
                    }
                    else{
                        
                        Validation.dicNotifCount = [NSDictionary
                                                    dictionaryWithObjectsAndKeys:
                                                    @"",TOTAL_FRIENDS_REQUEST,
                                                    @"",TOTAL_UNREAD_NOTIF,
                                                    @"",TOTAL_KEEP_REQUEST,
                                                    @"",TOTAL_NOTIF_COUNT,
                                                    @"",TOTAL_ALARM_REQUEST,
                                                    nil];
                        
                    }
                    
                    [self setCountLabel];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
    self.request = nil;
	dicResponse = nil;
	self.isServiceWaitingForResponse = NO;
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}
#pragma mark    UIActionsheet Delegate

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"button index = %d",(int)buttonIndex);
    
    if (buttonIndex == actionSheet.cancelButtonIndex) {
        
    }
    else if (buttonIndex == 0){
        //only yap
        [self.request CancleOngoingRequest];
        [self.request setDelegate:nil];
        self.request = nil;

        [self performSegueWithIdentifier:RECORD_OPTION_VC sender:nil];
    }
    else if (buttonIndex == 1){
        //yap with image
        
        [self.request CancleOngoingRequest];
        [self.request setDelegate:nil];
        self.request = nil;

        [self performSegueWithIdentifier:CAPTURE_IMAGE_VC sender:nil];
    }
    else if (buttonIndex == 2){
        //yap with video
        [self.request CancleOngoingRequest];
        [self.request setDelegate:nil];
        self.request = nil;
        if ([[NSFileManager defaultManager] fileExistsAtPath:VIDEO_RECORDING_FOLDER]) {
            //when folder exists
            NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
            if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
                [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
            }
        }
        [self performSegueWithIdentifier:SET_VIDEO_PRIVACY_VC sender:nil];
    }
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
  /*  if ([segue.identifier isEqualToString:RECORD_OPTION_VC] || [segue.identifier isEqualToString:CAPTURE_IMAGE_VC]) {
        
        if (appDelegate.dic_NotificationReleatedData != nil) {
            appDelegate.dic_NotificationReleatedData = nil;
        }
        
        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    [NSArray arrayWithObjects:[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:(self.isSentNotifList)?RECEIVER_ID:SENDER_ID], nil],SelectedIds,
                                                    [NSNumber numberWithBool:FALSE],IS_GroupNotif,
                                                    [NSNumber numberWithBool:NO],IS_NotifSendToAll,
                                                    nil];
	}
    else
        */
    
    if ([segue.identifier isEqualToString:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC]){
        
        if (appDelegate.isForwarded) {
            AddFriendFromExistingFriendListVC *obj = segue.destinationViewController;
            obj.dicSelectedNotifToForward = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.selectedIndex] ];
        }
    }
    else if ([segue.identifier isEqualToString:USER_CONVERSATION_CHAT_VC]){
        if (appDelegate.isLoadConversationFromNotif) {
            UserConversationChatVC *obj = segue.destinationViewController;
            
            NSArray *arrapnsTags = [appDelegate.arrAPNS valueForKey:apnsTag];
            int index = (int)[arrapnsTags indexOfObject:[NSNumber numberWithInt:(int)appDelegate.validation.apnsPopUp.btnPlay.tag]];
            NSDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[appDelegate.arrAPNS objectAtIndex:index]];
            
            obj.dicConversationDetail = dic;
        }
        else{
            UserConversationChatVC *obj = segue.destinationViewController;
            obj.dicConversationDetail = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.selectedIndex]];
        }
    }
    
    [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
    [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];

}

#pragma mark        WebService Methods

-(void)get_NptofCount{
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_REQUEST_COUNT withParameters:nil];
    
    ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:7];
    }
//    request.delegate = self;
//    request.tag = 7;
    
    strUrl = nil;
}
-(void)loadConversationFromNotif{
    [self performSegueWithIdentifier:USER_CONVERSATION_CHAT_VC sender:self];
}
-(void)get_ConversationListWithUsers{
    
/*
    if (self.request) {
        self.request = nil;
    }
    if (self.isViewDidLoadCalled) {
		self.isViewDidLoadCalled = FALSE;
	}
    
	self.lbl_NoDataAvailable.hidden = YES;
	self.isServiceWaitingForResponse = YES;
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_CONVERSATIONLIST_WITH_USERS withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
    
    
	strUrl = nil;
    NSLog(@"call initiated");
*/
    NSString *url = [WebServiceContainer getServiceURL:GET_CONVERSATIONLIST_WITH_USERS withParameters:nil];

    
    AFHTTPRequestOperationManager *operationManager = [AFHTTPRequestOperationManager manager];

    NSString *strT1 = [Validation GetUTCDate];
    [operationManager.requestSerializer setValue:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL] forHTTPHeaderField:HEADER_USERNAME_KEY];
    [operationManager.requestSerializer setValue:strT1 forHTTPHeaderField:@"T1"];
    [operationManager.requestSerializer setValue:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE] forHTTPHeaderField:@"T2"];
    


    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],@"UserID",[NSString stringWithFormat:@"%d",self.pageCounter],@"PageNo",[NSString stringWithFormat:@"%d",PageSize],@"PageSize", nil];
    
    [operationManager GET:url parameters:dic1 success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"JSON: %@", responseObject);
//        successBlock(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
//        errorBlock(error);
    }];
    
}
-(void)SearchForText{
    if (self.request !=nil) {
        self.request = nil;
    }
    NSDictionary *dic;
    NSString *strUrl;
    
    dic = [NSDictionary dictionaryWithObjectsAndKeys:
           [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"userid",KeyName, nil],@"1",
           [NSDictionary dictionaryWithObjectsAndKeys:[[NSString stringWithFormat:@"%@",self.tfSearch.text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]], KeyValue,@"name",KeyName,nil],@"2",
           [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"1"],KeyValue,@"pageno",KeyName, nil],@"3",
           [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"0"],KeyValue,@"pagesize",KeyName, nil],@"4",
           nil];
    strUrl = [WebServiceContainer getServiceURL:SEARCH_MSG_CONVERSATION withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];

    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.refresh removeFromSuperview];
        self.refresh = nil;
        [self.request setDelegate:self];
        [self.request setTag:7];
    }
    //	self.request.delegate = self;
    //	self.request.tag = 1;
    strUrl = nil;
    
}
/*
 -(void)get_RecSent_NotifList{
 
 if (self.isViewDidLoadCalled) {
 
 self.isViewDidLoadCalled = FALSE;
 }
 //	if (self.request !=nil) {
 //		self.request = nil;
 //	}
 
 self.lbl_NoDataAvailable.hidden = YES;
 
 self.isServiceWaitingForResponse = YES;
 
 NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
 nil];
 
 NSString *strUrl = [WebServiceContainer getServiceURL:((self.isSentNotifList)?GET_SENT_NOTIF_LIST:GET_RECEIVED_NOTIF_LIST) withParameters:nil];
 
 self.request = [AFNetworkingDataTransaction sharedManager];
 [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
 [self.request setDelegate:self];
 [self.request setTag:1];
 
 //	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
 //	self.request.delegate = self;
 //	self.request.tag = 1;
 strUrl = nil;
 }
 */

-(void)setNotifAsReadForNotifId:(NSString *)notifId{
    //	if (self.request !=nil) {
    //		self.request = nil;
    //	}
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",notifId],KeyValue,@"MsgIDs",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:NOTIF_READ withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:3];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:3];
    
    
    //	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    //	self.request.delegate = self;
    //	self.request.tag = 3;
	strUrl = nil;
}

-(void)SetSelectedNotifToFavorites{
    
    
    NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.selectedIndex] ];
    BOOL isLike = [[NSString stringWithFormat:@"%@",[dic1 valueForKey:IS_LIKE]] boolValue];
    
    if (isLike) {
        isLike = FALSE;
    }
    else{
        isLike = TRUE;
    }
    
    dispatch_async(dispatch_get_main_queue(),^{
        
        [self changeLikeButtonImageInListForDic:dic1];
    });
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dic1 valueForKey:NOTIF_ID]],KeyValue,@"MsgID",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:(isLike)?@"true":@"false",KeyValue,@"IsLike",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:SET_NOTIF_LIKE_UNLIKE withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:4];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:4];
    
    
    //	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    //	request.delegate = self;
    //	request.tag = 4;
	strUrl = nil;
}

-(IBAction)btnDeleteSelected:(id)sender{
	
    //	[Validation showLoadingIndicator];
    [HUD show:YES];
    
	if (self.request !=nil) {
		self.request = nil;
	}
	
	NSString *strIds = @"";
	for (NSNumber *num in self.selectedRows) {
		NSLog(@"%@",num);
		if (strIds.length == 0) {
			strIds = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:[num intValue]] valueForKey:USER_CONVERSATION_ID]];
		}
		else{
			strIds = [strIds stringByAppendingFormat:@"|%@",[[self.arrData objectAtIndex:[num intValue]] valueForKey:USER_CONVERSATION_ID]];
		}
	}
	
	//self.selectedIndex = (int)((UIButton *)sender).tag;
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:strIds,KeyValue,@"ConversationIDs",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:DELETE_WHOLE_CONVERSATION_WITH_USERS withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:2];
    
    //	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    //	self.request.delegate = self;
    //	self.request.tag = 2;
	strUrl = nil;
}

-(void)BlockSelectedUser:(NSDictionary *)dicForSelectedUser{
	if (self.request !=nil) {
		self.request = nil;
	}
    [HUD show:YES];
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dicForSelectedUser valueForKey:USER_CONVERSATION_USERID]],KeyValue,@"BlockUserID",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"IsBlock",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:BLOCK_UNBLOCK_USER withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:5];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:5];
    
    
    //    AFNetworkingDataTransaction *obj = [[AFNetworkingDataTransaction sharedManager] SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    //    obj.delegate = self;
    //    obj.tag = 5;
    //	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    //	self.request.delegate = self;
    //	self.request.tag = 5 ;          //compulsary block this user
	strUrl = nil;
}
#pragma mark
#pragma mark UITextField method
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString *str;
    if ([string isEqualToString:@""]) {
        str = [self.tfSearch.text substringToIndex:self.tfSearch.text.length-1];
    }
    else{
        str = [self.tfSearch.text stringByAppendingString:string];
    }
    if (textField==self.tfSearchAtText) {
        [self.tfSearchAtText resignFirstResponder];
        return NO;
    }
    else if (textField==self.tfSearch && str.length==0){
        [HUD show:YES];
        self.pageCounter = 1;
        [self get_ConversationListWithUsers];
        return YES;
    }
    else{
        return YES;
    }
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (textField==self.tfSearchAtText) {
        [self.tfSearchAtText resignFirstResponder];
        return NO;
    }
    else{
        return YES;
    }
}
-(void)textFieldDidBeginEditing:(UITextField *)textField{
    [self.lbl_NoDataAvailable setHidden:YES];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if ([DataValidation checkNullString:textField.text].length>0) {
        [self.arrData removeAllObjects];
        [HUD hide:YES];
        //	[Validation showLoadingIndicatorInView:self.tblData];
        [HUD show:YES];
        
        self.pageCounter = 1;
        [self SearchForText];
    }
    [textField resignFirstResponder];
    return TRUE;
}
- (BOOL) textFieldShouldClear:(UITextField *)textField{
    if (textField==self.tfSearch) {
        [HUD show:YES];
        self.pageCounter = 1;
        [self get_ConversationListWithUsers];
    }
    [self performSelector:@selector(hideAllKeyboards) withObject:nil afterDelay:0.1];
    return YES;
}
-(void) hideAllKeyboards {
    [self.tfSearch resignFirstResponder];
}
@end
