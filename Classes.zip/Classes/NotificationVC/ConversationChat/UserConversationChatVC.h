//
//  UserConversationChatVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 14/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>
#import <MessageUI/MFMessageComposeViewController.h>
#import "ReportAbuseVC.h"
#import "ConversationCellWithImg/ConversationWithImgCell.h"
#import "ConversationCellWithOutImg/ConversationWithoutImgCell.h"
#import "ConversationTextBlabCell.h"
#import "UserProfileVC.h"
#import "ConversationCellWithStickerCell/ConversaionWithStickerCell.h"
#import <FBSDKShareKit/FBSDKShareKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import "HPGrowingTextView.h"


@interface UserConversationChatVC : UIViewController <UITableViewDataSource, UITableViewDelegate, MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate,SocialShareVCDelegate, UIActionSheetDelegate, UIAlertViewDelegate,ReportAbuseVCDelegate,AFNetworkingDataTransactionDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UIPageViewControllerDelegate,UIGestureRecognizerDelegate,ConversationWithImgCellDelegate,ConversationWithoutImgCellDelegate,UserProfileVCDelegate,ConversaionWithStickerCellDelegate,UIDocumentInteractionControllerDelegate,FBSDKSharingDelegate,UITextViewDelegate,ConversationTextBlabCellDelegate,HPGrowingTextViewDelegate,RecrodingFriendRequestVCDelegate>{
    HPGrowingTextView *textView;
}

@property (nonatomic, strong) NSDictionary                  *dicConversationDetail;

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, strong) NSMutableArray				*arrPlaySelectedBlabs;
@property (nonatomic, strong) NSMutableArray				*arrAnimation;
@property (nonatomic, strong) NSMutableSet					*selectedRows;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, readwrite) BOOL						isCallInitiated;
@property (nonatomic, retain) IBOutlet UILabel				*lbl_NoDataAvailable;
@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;
@property (nonatomic, strong) IBOutlet UIButton             *btnChatDetail;

@property (nonatomic, readwrite) int						selectedIndex;
@property (nonatomic, readwrite) int						selectedPlayID;


@property (nonatomic, strong) IBOutlet  UIView              *viewContainer_userInfo;
@property (nonatomic, strong) IBOutlet  AsyncImageView      *img_OtherUSerImg;
@property (nonatomic, strong) IBOutlet  UILabel             *lblOtherUSerName;


@property (nonatomic, strong) NSString                      *strLoggedInUserId;
@property (nonatomic, strong) UIButton                      *btnLoadMore;

@property (nonatomic, strong) NSTimer                       *timerImgLoad;
@property (nonatomic, strong) UIActivityIndicatorView       *activity;

@property (nonatomic, strong) IBOutlet UIButton             *btnReply;
@property (nonatomic, strong) IBOutlet UIButton             *btnEmoji;
@property (nonatomic, strong) IBOutlet UIButton             *btnDelete;
@property (nonatomic, strong) IBOutlet UIButton             *btnShare;
@property (nonatomic, strong) SocialShareVC                 *objShareVC;

@property (nonatomic, strong) NSString                      *strShareURL;
@property (nonatomic, strong) NSString                      *strShareImagePathURL;
@property (nonatomic, readwrite) int                        countOfPlay;
@property (nonatomic, readwrite) BOOL                       isPlayAll;
@property (nonatomic, readwrite) BOOL                       isPlaying;
@property (nonatomic, readwrite) BOOL                       isStoppedForceFully;

@property (nonatomic, strong) UIImageView                   *imgPlayAnimation;
@property (nonatomic, readwrite) int                        currentlyPlaingIndex;
@property (nonatomic, readwrite) BOOL                       isFullScreenClicked;
@property (nonatomic, readwrite) BOOL                       isShowKeepRequest;
@property (nonatomic, readwrite) BOOL                       isAdmin;
@property (nonatomic, readwrite) BOOL                       isShouldShowImage;
@property (nonatomic, readwrite) BOOL                       isShouldCallIsRead;

@property (nonatomic, strong) IBOutlet UIView               *viewFullImageContainer;
@property (nonatomic, strong) IBOutlet UIScrollView         *scrollFullImageContainer;
@property (nonatomic, strong) IBOutlet AsyncImageView       *imgFullScreenImage;
@property (nonatomic, strong) IBOutlet UIButton             *btnCloseImage;
@property (nonatomic, strong) IBOutlet UILabel              *lblCaption;
@property (nonatomic, strong) IBOutlet UIView               *viewBackCaption;

@property (nonatomic, strong) IBOutlet UIView               *viewReplyStickerContainer;
@property (nonatomic, strong) IBOutlet UIView               *viewShareDeleteContainer;
@property (nonatomic, strong) IBOutlet UIButton             *btnEditDone;

@property (nonatomic, strong) MPMoviePlayerViewController   *moviePlayer;
@property (nonatomic, readwrite) int                        videoPlayCounter;

@property (nonatomic, strong) IBOutlet UIView *viewContainerTextView;
@property (nonatomic, strong) IBOutlet UITextView *tvTextBlab;

//  Instagram
@property(nonatomic,retain)UIDocumentInteractionController *docFile;
- (void)loadCameraRollAssetToInstagram:(NSDictionary *)dic;
- (NSString*)urlencodedString;


-(void)startPlayLoop;
-(void)removeAnimationFromSuperView;
-(void)get_ConversationWithSelectedUser;
-(void)reloadChatViewForNewBlab;
-(void)setBlabvisibilityWithData:(NSDictionary *)dic;
-(void)btnPlayFileClicked:(id)sender;
-(void)btnCloseImageClicked:(id)sender;

//image zoom in/out

- (void)centerScrollViewContents;
- (void)scrollViewDoubleTapped:(UITapGestureRecognizer*)recognizer;
- (void)scrollViewTwoFingerTapped:(UITapGestureRecognizer*)recognizer;
-(IBAction)btnKeyBoardCancel_Clicked:(id)sender;

@end
