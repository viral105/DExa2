//
//  UserConversationChatVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 14/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "UserConversationChatVC.h"
#import "MBProgressHUD.h"
#import "ConversationCellWithImg/ConversationWithImgCell.h"
#import "ConversationCellWithOutImg/ConversationWithoutImgCell.h"
#import "ReportAbuseVC.h"
#import "ConversationGrpDetail/ConversationGrpDetailVC.h"
#import "StickerCell.h"
#import "ConversationCellWithStickerCell/ConversaionWithStickerCell.h"
#import "UserProfileVC.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <CoreTelephony/CTCallCenter.h>
#import <CoreTelephony/CTCall.h>
#import <AssetsLibrary/AssetsLibrary.h>

#define IS_SELECTED             @"is_selected"
#define URL_TO_PLAY             @"play_Item_With_URL"
#define URL_ITEM_ID             @"play_Item_With_ID"
#define WIDTH_DESC              250
#define WIDTH_DESC_TEXTBLAB     170

#define PageSize                        10
#define CellHeightWithOutImg            150
#define CellHeightWithSticker           120

#define CellHeightWithImg               270
#define CellHeightForLoadMore           50

#define KeyboardHeight                  216
#define BottomViewHeight                50
#define CategoryViewHeight              44

#define ScrollViewTag                   84578
#define StickerViewTag                  84579

void (^block)(CTCall*) = ^(CTCall* call) { NSLog(@"%@", call.callState); };

@interface UserConversationChatVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
    UICollectionView *_catCollectionView;
    UICollectionView *_subcatCollectionView;
    
    NSMutableArray *_arrCategory;
    NSMutableArray *_arrSubCategory;
    
    NSInteger selectedIndexPath;
    BOOL isStickiesKeyboardOpen;

    UserProfileVC *objUserProfileVC;
    
    NSDictionary *dicSelForSingleVideoImageShare;
    BOOL isPhoneCallGoingOn;
//    CTCallCenter *callCenter;
    int keyBoardHeight;
    
    int cntLine;
}
@property (nonatomic,strong)UserProfileVC *objUserProfileVC;
//@property (nonatomic,strong)CTCallCenter *callCenter;
@end

@implementation UserConversationChatVC
@synthesize objUserProfileVC;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
/*
- (void)viewWillLayoutSubviews{
    
    if (!self.callCenter) {
        self.callCenter =[[CTCallCenter alloc] init]; // get a CallCenter somehow; most likely as a global object or something similar?
        self.callCenter.callEventHandler = block;
    }
    __weak typeof(self) weakSelf = self;
    [self.callCenter setCallEventHandler:^(CTCall *call) {
        __strong typeof(self) strongSelf = weakSelf;
        dispatch_sync(dispatch_get_main_queue(), ^{
            if ([[call callState] isEqual:CTCallStateConnected] || [[call callState] isEqual:CTCallStateIncoming] || [[call callState] isEqual:CTCallStateDialing]) {
                NSLog(@"viewWillLayoutSubviews");
                //this call has just connected
            }
            else if ([[call callState] isEqualToString:CTCallStateDisconnected]){
                
                if (strongSelf.btnEditDone.tag==1) {
                    NSLog(@"call disconnected tag 1");
                                    strongSelf.viewShareDeleteContainer.frame = CGRectMake(0, strongSelf.view.frame.size.height+20, strongSelf.view.frame.size.width, 50);
                                    strongSelf.viewReplyStickerContainer.frame = CGRectMake(0, strongSelf.view.frame.size.height-30, strongSelf.view.frame.size.width, 50);
                }
                else{
                    NSLog(@"call disconnected tag 2");
                                    strongSelf.viewShareDeleteContainer.frame = CGRectMake(0, strongSelf.view.frame.size.height-30, strongSelf.view.frame.size.width, 50);
                                    strongSelf.viewReplyStickerContainer.frame = CGRectMake(0, strongSelf.view.frame.size.height+20, strongSelf.viewReplyStickerContainer.frame.size.width, 50);
                }
            }
        });
        
    }];
}
 
- (void)application:(UIApplication *)application didChangeStatusBarFrame:(CGRect)oldStatusBarFrame;
{
    NSLog(@"oldStatusBarFrame %@",NSStringFromCGRect(oldStatusBarFrame));
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:@"trigger" forKey:@"frame"];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"trigger"
                                                        object:self
                                                      userInfo:dict];
}
 */
- (void)dataReceivedNotification:(NSNotification*)notif
{

    NSString *str =  [[notif userInfo] valueForKey:@"height"];
    NSLog(@"str %@",str);
    // do something with data
    if ([str intValue]>20) {
        if (self.btnEditDone.tag==1) {
            NSLog(@"call disconnected tag 1");
            self.viewShareDeleteContainer.frame = CGRectMake(0, [[UIScreen mainScreen] bounds].size.height, [[UIScreen mainScreen] bounds].size.width, self.viewShareDeleteContainer.frame.size.height);
            self.viewReplyStickerContainer.frame = CGRectMake(0, [[UIScreen mainScreen] bounds].size.height-self.viewReplyStickerContainer.frame.size.height, [[UIScreen mainScreen] bounds].size.width, self.viewReplyStickerContainer.frame.size.height);
            self.viewShareDeleteContainer.hidden = YES;
            self.viewReplyStickerContainer.hidden = NO;
            
            [self.view bringSubviewToFront:self.viewReplyStickerContainer];
            
        }
        else{
            NSLog(@"call disconnected tag 2");
            self.viewShareDeleteContainer.frame = CGRectMake(0, [[UIScreen mainScreen] bounds].size.height-self.viewShareDeleteContainer.frame.size.height, [[UIScreen mainScreen] bounds].size.width, self.viewShareDeleteContainer.frame.size.height);
            self.viewReplyStickerContainer.frame = CGRectMake(0, [[UIScreen mainScreen] bounds].size.height, [[UIScreen mainScreen] bounds].size.width, self.viewReplyStickerContainer.frame.size.height);
            self.viewShareDeleteContainer.hidden = NO;
            self.viewReplyStickerContainer.hidden = YES;
            [self.view bringSubviewToFront:self.viewShareDeleteContainer];
        }
        
        if (!self.viewContainerTextView.isHidden) {
            CGRect frame = [self getStatusBarFrameViewRect:self.view];
            if (frame.size.height>20) {
                self.viewContainerTextView.frame = CGRectMake(self.viewContainerTextView.frame.origin.x, [UIScreen mainScreen].bounds.size.height-keyBoardHeight-self.viewContainerTextView.frame.size.height-20, self.viewContainerTextView.frame.size.width, self.viewContainerTextView.frame.size.height);
            }
            else{
                self.viewContainerTextView.frame = CGRectMake(self.viewContainerTextView.frame.origin.x, [UIScreen mainScreen].bounds.size.height-keyBoardHeight-self.viewContainerTextView.frame.size.height, self.viewContainerTextView.frame.size.width, self.viewContainerTextView.frame.size.height);
            }
            
        }
    }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"viewDidLoad");
    //self.automaticallyAdjustsScrollViewInsets = NO;
    
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
    NSLog(@"%@",self.dicConversationDetail);
    
    self.arrData = [[NSMutableArray alloc] init];
    [self LoadViewSetting];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(dataReceivedNotification:)
                                                 name:@"trigger"
                                               object:nil];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    NSLog(@"viewWillAppear");
    [super viewWillAppear:animated];
    [Validation DisableScreenLockWhilePlaying:YES];
    appDelegate.currentVc = self;
    
    [self.arrData removeAllObjects];
    self.pageCounter = 1;
    
    [self get_ConversationWithSelectedUser];
}

-(void)viewWillDisappear:(BOOL)animated{
    NSLog(@"viewWillDisappear");
    [super viewWillDisappear:animated];
    [Validation DisableScreenLockWhilePlaying:NO];
    //    [appDelegate ClosePopUpWithoutUI];
    
    self.isStoppedForceFully = TRUE;
    [appDelegate ClosePopUpWithoutUI];
    [self removeAnimationFromSuperView];
    self.isPlayAll = FALSE;
    self.isPlaying = FALSE;
}
#pragma mark Button Events

-(void)initializeAnimationArray{

    NSMutableArray *arrAnimation = [[NSMutableArray alloc] init];
    for (int i = 1 ; i<=28; i++) {
        [arrAnimation addObject:[UIImage imageNamed:[NSString stringWithFormat:@"player_loader_%d.png",i]]];
    }
    
    self.imgPlayAnimation.animationImages = arrAnimation;
    self.imgPlayAnimation.animationRepeatCount = 0;
}

-(void)setBlabvisibilityWithData:(NSDictionary *)dic{
    
    self.isStoppedForceFully = TRUE;
    [appDelegate ClosePopUpWithoutUI];
    [self removeAnimationFromSuperView ];
    self.isPlayAll = FALSE;

    NSString *strBlabId = [dic valueForKey:@"ContentID"];
    BOOL isVisible = [[dic valueForKey:@"requestStatus"] boolValue];
    
    NSUInteger index = [self.arrData indexOfObjectPassingTest:
                        ^BOOL(NSDictionary *dict, NSUInteger idx, BOOL *stop)
                        {
                            return [[NSString stringWithFormat:@"%@",[dict valueForKey:MESSAGE_CHAT_ID]] isEqualToString:strBlabId];
                        }
                        ];
    if (isVisible) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:index]];
        [dic setValue:@"2" forKey:RequestedKeepStatus];
        [self.arrData replaceObjectAtIndex:index withObject:dic];
        dic = nil;

        int section = 1;
        
        if (self.isDataNull) {
            section = 0;
        }
        
        NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:index inSection:section]];
        [self.tblData beginUpdates];
        [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
        [self.tblData endUpdates];
    }
    else{
        [self.arrData removeObjectAtIndex:index];
        [self.tblData reloadData];
    }
}

-(void)reloadChatViewForNewBlab{
    
    self.isStoppedForceFully = TRUE;
    self.isShowKeepRequest = NO;
    self.isShouldCallIsRead = NO;
    [appDelegate ClosePopUpWithoutUI];
    [self removeAnimationFromSuperView];
    self.isPlayAll = FALSE;
    self.pageCounter = 1;
    [self get_ConversationWithSelectedUser];
}

-(void)LoadViewSetting{
    
    self.viewShareDeleteContainer.frame = CGRectMake(0, [[UIScreen mainScreen] bounds].size.height, [[UIScreen mainScreen] bounds].size.width, 50);
    self.viewReplyStickerContainer.frame = CGRectMake(0, [[UIScreen mainScreen] bounds].size.height-50, [[UIScreen mainScreen] bounds].size.width, 50);
    self.viewShareDeleteContainer.hidden = YES;
    self.viewReplyStickerContainer.hidden = NO;
    
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:15];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    [self.lblTitle setText:[NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:NAME]]];
    
    [self.lbl_NoDataAvailable setTextColor:TWITTER_BLUE_COLOR];
    [self.lbl_NoDataAvailable setShadowColor:[UIColor clearColor]];
    
    [self.btnReply setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.btnReply.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Bold size:16]];
    
    self.lblOtherUSerName.font = [UIFont fontWithName:Font_Montserrat_Regular size:15];
	[self.lblOtherUSerName setTextColor:[UIColor whiteColor]];
    self.lblOtherUSerName.text = [NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:NAME]];
 
    self.viewContainer_userInfo.backgroundColor = [Validation getColorForAlphabet:self.lblOtherUSerName.text];
    
    self.btnLoadMore = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.btnLoadMore setTitle:@"Load More" forState:UIControlStateNormal];
    [self.btnLoadMore setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btnLoadMore.titleLabel setTextAlignment:NSTextAlignmentCenter];
    [self.btnLoadMore addTarget:self action:@selector(LoadMoreOldData) forControlEvents:UIControlEventTouchUpInside];
    [self.btnLoadMore setBackgroundColor:[UIColor clearColor]];
    
    [self.img_OtherUSerImg setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:USER_PHOTO_PATH]]]];
    [Validation setCorners:self.img_OtherUSerImg];
    
    self.strLoggedInUserId = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]];

    self.viewFullImageContainer.hidden = YES;
    
//    self.btnDelete.hidden = YES;
//    self.btnShare.hidden = YES;
    
    NSString *strGroupId = [NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:@"GroupID"]];
    
    if ([DataValidation checkNullString:strGroupId].length >0 && ([strGroupId intValue]!=0)) {
        //it is group message
        self.btnChatDetail.enabled = TRUE;
        self.btnChatDetail.hidden = NO;
    }
    else{
        self.btnChatDetail.enabled = FALSE;
        self.btnChatDetail.hidden = YES;
    }
    
    self.isAdmin = (![[NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:USERTYPE]] isEqualToString:@"2"]);
    if (self.isAdmin) {
        
        //type == 1|3, admin, subadmin
        self.btnReply.hidden = YES;
        self.btnEmoji.hidden = YES;
        self.btnEditDone.hidden = YES;
        self.viewReplyStickerContainer.hidden = YES;
    }
    else{
        //type == 2, user
        self.btnEditDone.hidden = NO;
        self.btnEditDone.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        [self.btnEditDone setTitle:[NSString stringWithFormat:@"Share /\nDelete"] forState:UIControlStateNormal];
    }

    self.viewContainerTextView.frame = CGRectMake(self.viewContainerTextView.frame.origin.x, DEVICE_HEIGHT-self.viewContainerTextView.frame.size.height, self.viewContainerTextView.frame.size.width, self.viewContainerTextView.frame.size.height);
    [self.tvTextBlab setFont:[UIFont fontWithName:Font_Montserrat_Regular size:18]];
    [self.tvTextBlab setTextColor:UIColorFromRGB(0Xa3a5a7)];
}

-(void)LoadMoreOldData{
    self.pageCounter++;
    
    [self get_ConversationWithSelectedUser];
}

-(void)showVideoFrom:(id)sender{
    if (!self.viewContainerTextView.isHidden) {
        [self btnKeyBoardCancel_Clicked:nil];
    }
    if (!self.isPlaying) {
        self.isFullScreenClicked = YES;
        NSLog(@"tag = %d",(int)((UIButton *)sender).tag);
        [self btnPlayFileClicked:sender];
    }
    else{
        NSMutableDictionary *dic = [self.arrData objectAtIndex:((UIButton *)sender).tag];
        
        if ([[dic valueForKey:IsPrivate] boolValue]) {
            if (![[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]] isEqualToString:self.strLoggedInUserId]) {
                if ([[NSString stringWithFormat:@"%@",[dic valueForKey:RequestedKeepStatus]] intValue] == 1) {
                    
                    NSString *strRequestSendStatus = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IsRequestSent]]];
                    strRequestSendStatus = (strRequestSendStatus.length >0)?strRequestSendStatus:@"false";
                    if (strRequestSendStatus.length > 0 && ![strRequestSendStatus boolValue]) {
                        self.isShowKeepRequest = YES;
                    }
                    if ([strRequestSendStatus boolValue]) {
                        self.isShouldShowImage = FALSE;
                    }
                }
            }
        }
    }
    if (self.isShouldShowImage) {
        
        
        NSMutableDictionary *dic = [self.arrData objectAtIndex:((UIButton *)sender).tag];
        
        NSString *str  = [dic valueForKey:VideoPath];
        str = [str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        if ([str length] > 0 && ![str isEqualToString:@"null"] && ![str isEqual:[NSNull null]] && ![str isEqualToString:@"<null>"] && ![str isEqualToString:@"(null)"]) {
            
            [self MoviePlayerRemoveObserver];
            
            if (self.moviePlayer != nil) {
                [self MoviePlayerRemoveObserver];
                [self.activity removeFromSuperview];
                self.activity = nil;
                self.viewFullImageContainer.hidden = YES;
                self.isFullScreenClicked = NO;
                self.moviePlayer.moviePlayer.shouldAutoplay = NO;
                [self.moviePlayer.view removeFromSuperview];
                self.moviePlayer = nil;
                [self removeAnimationFromSuperView];
            }
            
            AVAudioSession *session = [AVAudioSession sharedInstance];
            [session setCategory:AVAudioSessionCategoryPlayback error:nil];
            //        Try this: Set MPMoviePlayerController's property "useApplicationAudioSession" to "NO".
            
            self.viewFullImageContainer.hidden = FALSE;
            self.viewFullImageContainer.alpha = 1;
            
            
            
            self.moviePlayer = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:str]];
            
            [[NSNotificationCenter defaultCenter] addObserver:self
                                                     selector:@selector(moviePlayBackDidFinish:)
                                                         name:MPMoviePlayerPlaybackDidFinishNotification
                                                       object:self.moviePlayer.moviePlayer];
            
            [[NSNotificationCenter defaultCenter] addObserver:self
                                                     selector:@selector(moviePlayBackDidFinish:)
                                                         name:MPMoviePlayerDidExitFullscreenNotification
                                                       object:self.moviePlayer.moviePlayer];
            
            [[NSNotificationCenter defaultCenter] addObserver:self
                                                     selector:@selector(MPMovieDurationAvailable:)
                                                         name:MPMovieDurationAvailableNotification
                                                       object:self.moviePlayer.moviePlayer];
            
            [[NSNotificationCenter defaultCenter] addObserver:self
                                                     selector:@selector(MPMoviePlayerPlaybackStateDidChange:)
                                                         name:MPMoviePlayerPlaybackStateDidChangeNotification
                                                       object:self.moviePlayer.moviePlayer];
            [[NSNotificationCenter defaultCenter] addObserver:self
                                                     selector:@selector(MPMoviewPlayerLoadStateDidChange:)
                                                         name:MPMoviePlayerLoadStateDidChangeNotification
                                                       object:self.moviePlayer.moviePlayer];
            
            self.videoPlayCounter = 1;

            self.moviePlayer.moviePlayer.shouldAutoplay = YES;
            
            [self.moviePlayer.moviePlayer prepareToPlay];
            self.isPlaying = TRUE;
            self.moviePlayer.view.frame = CGRectMake(0, 0, DEVICE_WIDTH, DEVICE_HEIGHT);
            self.moviePlayer.moviePlayer.controlStyle = MPMovieControlStyleNone;
            
            [self.moviePlayer.moviePlayer play];
            self.moviePlayer.moviePlayer.scalingMode = MPMovieScalingModeAspectFit;
            [self.viewFullImageContainer addSubview:self.moviePlayer.view];
            
            self.btnCloseImage.frame = CGRectMake(self.view.frame.size.width-50, 25, 40, 40);
            [self.btnCloseImage addTarget:self action:@selector(btnCloseImageClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self.viewFullImageContainer bringSubviewToFront:self.btnCloseImage];
            
            self.isStoppedForceFully = NO;
            
            
            if (self.activity != nil) {
                [self.activity stopAnimating];
                [self.activity removeFromSuperview];
                self.activity = nil;
            }
            
            self.activity= [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
            self.activity.frame = CGRectMake(100, 100, 30, 30);
            
            self.activity.center = self.view.center;
            [self.viewFullImageContainer addSubview:self.activity];
            [self.viewFullImageContainer bringSubviewToFront:self.activity];
            [self.activity startAnimating];
            self.activity.hidesWhenStopped = TRUE;
            
        }
    }
}

-(void)MPMovieDurationAvailable:(NSNotification *)notification{
    
    if (self.moviePlayer !=nil) {
        if (![self.moviePlayer.view isHidden]) {
            if (self.moviePlayer.moviePlayer.duration > 0.00000) {
                
                if (!self.moviePlayer) {
                    [self.moviePlayer.moviePlayer stop];
                }
            }
        }
        else{
            [self.moviePlayer.moviePlayer stop];
            [self.moviePlayer.view removeFromSuperview];
            self.moviePlayer = nil;
        }
    }
}

-(void)MPMoviewPlayerLoadStateDidChange:(NSNotification *)notification{
 
    if (self.moviePlayer != nil) {
        if (self.moviePlayer.moviePlayer.loadState == MPMovieLoadStatePlaythroughOK) {
            [self.activity stopAnimating];
        }
        else if (self.moviePlayer.moviePlayer.loadState == MPMovieLoadStateStalled){
            [self.activity startAnimating];
        }
    }
}
- (void)MPMoviePlayerPlaybackStateDidChange:(NSNotification *)notification{
    
    if (self.moviePlayer != nil) {
        if (self.moviePlayer.moviePlayer.playbackState == MPMoviePlaybackStatePlaying) {
            
            [self.activity stopAnimating];
            self.isPlaying = TRUE;
            [self.moviePlayer.moviePlayer play];
        }
        else if (self.moviePlayer.moviePlayer.playbackState == MPMoviePlaybackStatePaused){     //|| self.moviePlayer.moviePlayer.playbackState == MPMoviePlaybackStateInterrupted){
            //[self.activity startAnimating];
        }
    }
}
- (void)moviePlayBackDidFinish:(NSNotification *)notification {
    
    if (!self.isPlayAll) {
        if (self.isStoppedForceFully) {
            [self.activity removeFromSuperview];
            self.activity = nil;
            
        }else{
            self.videoPlayCounter++;
            NSLog(@"Count = %d",self.videoPlayCounter);
            [self.activity stopAnimating];
            self.isPlaying = TRUE;
            [self.moviePlayer.moviePlayer play];
        }
    }
    else{
        self.isPlaying = FALSE;
        [self MoviePlayerRemoveObserver];
        [self.activity removeFromSuperview];
        self.activity = nil;
        self.viewFullImageContainer.hidden = YES;
        self.isFullScreenClicked = NO;
        //        self.isStoppedForceFully = YES;
        self.moviePlayer.moviePlayer.shouldAutoplay = NO;
        [self.moviePlayer.view removeFromSuperview];
        self.moviePlayer = nil;
        [self removeAnimationFromSuperView];
    }
    
}

-(void)MoviePlayerRemoveObserver{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerDidExitFullscreenNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerDidEnterFullscreenNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackStateDidChangeNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerLoadStateDidChangeNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMovieDurationAvailableNotification object:self.moviePlayer.moviePlayer];
    
    
}

-(void)showImageFrom:(id)sender{
    if (!self.viewContainerTextView.isHidden) {
        [self btnKeyBoardCancel_Clicked:nil];
    }
    if (!self.isPlaying) {
        self.isFullScreenClicked = YES;
        [self btnPlayFileClicked:sender];
    }
    else{
        NSMutableDictionary *dic = [self.arrData objectAtIndex:((UIButton *)sender).tag];
        
        if ([[dic valueForKey:IsPrivate] boolValue]) {
            if (![[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]] isEqualToString:self.strLoggedInUserId]) {
                if ([[NSString stringWithFormat:@"%@",[dic valueForKey:RequestedKeepStatus]] intValue] == 1) {
                    
                    NSString *strRequestSendStatus = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IsRequestSent]]];
                    strRequestSendStatus = (strRequestSendStatus.length >0)?strRequestSendStatus:@"false";
                    if (strRequestSendStatus.length > 0 && ![strRequestSendStatus boolValue]) {
                        self.isShowKeepRequest = YES;
                    }
                    if ([strRequestSendStatus boolValue]) {
                        self.isShouldShowImage = FALSE;
                    }
                }
            }
        }
    }
    if (self.isShouldShowImage) {
        
        self.imgFullScreenImage.image = nil;
        self.imgFullScreenImage.imageURL = nil;
        self.viewFullImageContainer.hidden = FALSE;
        self.viewFullImageContainer.alpha = 1.0;
//        self.viewFullImageContainer.backgroundColor = [UIColor redColor];
        [self.imgFullScreenImage setContentMode:UIViewContentModeScaleAspectFit];
        
        CGFloat minScale = 1;
        self.scrollFullImageContainer.minimumZoomScale = minScale;
        
        // 5
        self.scrollFullImageContainer.maximumZoomScale = 4.0f;
        self.scrollFullImageContainer.zoomScale = 1;
        
        // 6
        [self centerScrollViewContents];
        
        if (self.activity != nil) {
            [self.activity stopAnimating];
            [self.activity removeFromSuperview];
            self.activity = nil;
        }
        
        self.activity= [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        self.activity.frame = CGRectMake(100, 100, 30, 30);
        
        self.activity.center = self.view.center;
        [self.viewFullImageContainer addSubview:self.activity];
        [self.activity startAnimating];
        self.activity.hidesWhenStopped = TRUE;
        
        self.btnCloseImage.frame = CGRectMake(self.view.frame.size.width-50, 25, 40, 40);
        [self.btnCloseImage addTarget:self action:@selector(btnCloseImageClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self.viewFullImageContainer bringSubviewToFront:self.btnCloseImage];
        
        if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:CaptionForImage]]].length!=0) {
            self.lblCaption.hidden = NO;
            self.viewBackCaption.hidden = NO;
            self.lblCaption.text = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:CaptionForImage]];
            CGRect size = [self getHeightCaption:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:CaptionForImage]]];
            CGRect frame = self.lblCaption.frame;
            frame.size.height = size.size.height;
            if (size.size.height > 20) {
                frame.origin.y = DEVICE_HEIGHT - size.size.height;
            }
            else{
                frame.origin.y = DEVICE_HEIGHT - 20;
            }
            NSLog(@"lblcaption frame %@",NSStringFromCGRect(frame));
            self.lblCaption.frame = frame;
            frame.origin.x = 0;
            frame.size.width = DEVICE_WIDTH;
            self.viewBackCaption.frame = frame;
        }
        else{
            self.lblCaption.hidden = YES;
            self.viewBackCaption.hidden = YES;
        }
        
        [self.imgFullScreenImage setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:ImagePath]]]];
        
        [self fadeInView:self.viewFullImageContainer];
        self.timerImgLoad = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(hideActivityIndicatorAfterFadeIn) userInfo:nil repeats:YES];
        
    }
//    else{
//        [Validation showToastMessage:@"Please wait till user responds to your keep request" displayDuration:ERROR_MSG_DURATION];
//    }
}

- (void)centerScrollViewContents {
    CGSize boundsSize = self.scrollFullImageContainer.bounds.size;
    CGRect contentsFrame = self.imgFullScreenImage.frame;
    
    if (contentsFrame.size.width < boundsSize.width) {
        contentsFrame.origin.x = (boundsSize.width - contentsFrame.size.width) / 2.0f;
    } else {
        contentsFrame.origin.x = 0.0f;
    }
    
    if (contentsFrame.size.height < boundsSize.height) {
        contentsFrame.origin.y = (boundsSize.height - contentsFrame.size.height) / 2.0f;
    } else {
        contentsFrame.origin.y = 0.0f;
    }
    
    self.imgFullScreenImage.frame = contentsFrame;
}

- (IBAction)scrollViewDoubleTapped:(UITapGestureRecognizer*)recognizer {
    // 1
    CGPoint pointInView = [recognizer locationInView:self.imgFullScreenImage];
    
    // 2
    CGFloat newZoomScale = 0;
    if (self.scrollFullImageContainer.zoomScale > 1.0) {
        newZoomScale = 1;
    }else{
        newZoomScale = self.scrollFullImageContainer.zoomScale * 1.5f;
        newZoomScale = MIN(newZoomScale, self.scrollFullImageContainer.maximumZoomScale);
    }
    

    
    // 3
    CGSize scrollViewSize = self.scrollFullImageContainer.bounds.size;
    
    CGFloat w = scrollViewSize.width / newZoomScale;
    CGFloat h = scrollViewSize.height / newZoomScale;
    CGFloat x = pointInView.x - (w / 2.0f);
    CGFloat y = pointInView.y - (h / 2.0f);
    
    CGRect rectToZoomTo = CGRectMake(x, y, w, h);
    
    // 4
    [self.scrollFullImageContainer zoomToRect:rectToZoomTo animated:YES];
}

- (IBAction)scrollViewTwoFingerTapped:(UITapGestureRecognizer*)recognizer {
    // Zoom out slightly, capping at the minimum zoom scale specified by the scroll view
    CGFloat newZoomScale = self.scrollFullImageContainer.zoomScale / 1.5f;
    newZoomScale = MAX(newZoomScale, self.scrollFullImageContainer.minimumZoomScale);
    [self.scrollFullImageContainer setZoomScale:newZoomScale animated:YES];
}

- (UIView*)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    // Return the view that you want to zoom
    return self.imgFullScreenImage;
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView {
    // The scroll view has zoomed, so you need to re-center the contents
    [self centerScrollViewContents];
}

- (void)pinch:(UIPinchGestureRecognizer *)gesture {
    if (gesture.state == UIGestureRecognizerStateEnded
        || gesture.state == UIGestureRecognizerStateChanged) {
        NSLog(@"gesture.scale = %f", gesture.scale);
        
        CGFloat currentScale = self.imgFullScreenImage.frame.size.width / self.imgFullScreenImage.bounds.size.width;
        CGFloat newScale = currentScale * gesture.scale;
        
        if (newScale < 1) {
            newScale = 1;
        }
        if (newScale > 4) {
            newScale = 4;
        }
        
        CGAffineTransform transform = CGAffineTransformMakeScale(newScale, newScale);
        self.imgFullScreenImage.transform = transform;
        gesture.scale = 1;
    }
}

-(void)btnCloseImageClicked:(id)sender{
//    if (self.imgFullScreenImage.alpha == 1.0) {
    if (self.viewFullImageContainer.alpha == 1.0) {
        if (self.isPlaying) {
            
            if (!self.isPlayAll) {
                if (self.isShowKeepRequest) {
                    
                    if (self.moviePlayer) {
                        NSLog(@"videoPlayCounter = %d",self.videoPlayCounter);
                        [self callSetViewCountService];
                        self.viewFullImageContainer.hidden = YES;
                        self.isFullScreenClicked = NO;
                        self.isStoppedForceFully = YES;
                        [self.moviePlayer.moviePlayer stop];
                        [self.moviePlayer.view removeFromSuperview];
                        self.moviePlayer = nil;
                    }
                    [self fadeOutView:self.viewFullImageContainer];
                    self.isStoppedForceFully = TRUE;
                    
                    if (self.isPlaying) {
                        [appDelegate ClosePopUpWithoutUI];
                    }
                    //now no keep request is to be sent so directly delete view once blab.. - shreya    /*
                    //no, so delete that blab
                    [self deletePrivateMessage];
                    [self.arrData removeObjectAtIndex:self.currentlyPlaingIndex];
                    if (self.arrPlaySelectedBlabs.count > 0 && self.currentlyPlaingIndex < self.arrPlaySelectedBlabs.count){
                        [self.arrPlaySelectedBlabs removeObjectAtIndex:self.currentlyPlaingIndex];
                    }
                    
                    self.countOfPlay --;
                    self.currentlyPlaingIndex --;
                    [self.tblData reloadData];
                    
                    self.isPlaying = NO;
                    self.selectedPlayID = -1;
                    if (self.isPlayAll) {
                        [self startPlayLoop];
                    }
                }
                else{
                    self.isStoppedForceFully = TRUE;
                    if (self.moviePlayer) {
                        NSLog(@"videoPlayCounter = %d",self.videoPlayCounter);
                        [self callSetViewCountService];
                        self.viewFullImageContainer.hidden = YES;
                        self.isFullScreenClicked = NO;
                        self.isStoppedForceFully = YES;
                        [self.moviePlayer.moviePlayer stop];
                        [self.moviePlayer.view removeFromSuperview];
                        self.moviePlayer = nil;
                    }
                    [self fastFadeOutView:self.viewFullImageContainer];
                    if (self.isShouldCallIsRead) {
                        [self setNotifAsRead];
                    }
                }
            }
            else{
                if (self.moviePlayer) {
                    NSLog(@"videoPlayCounter = %d",self.videoPlayCounter);
                    [self callSetViewCountService];
                    self.viewFullImageContainer.hidden = YES;
                    self.isFullScreenClicked = NO;
                    self.isStoppedForceFully = YES;
                    [self.moviePlayer.moviePlayer stop];
                    [self.moviePlayer.view removeFromSuperview];
                    self.moviePlayer = nil;
                }
                [self fastFadeOutView:self.viewFullImageContainer];
                if (self.isShouldCallIsRead) {
                    [self setNotifAsRead];
                }
            }
            [appDelegate ClosePopUpWithoutUI];
            if ([self.imgPlayAnimation isAnimating]) {
                [self removeAnimationFromSuperView ];
            }
            
        }
        else{
//            [self fadeOutView:self.imgFullScreenImage];
            [self fadeOutView:self.viewFullImageContainer];
            if (self.isShowKeepRequest) {
                self.isStoppedForceFully = TRUE;
                
                if (self.isPlaying) {
                    [appDelegate ClosePopUpWithoutUI];
                }
                
                //now no keep request is to be sent so directly delete view once blab.. - shreya    /*
                //no, so delete that blab
                [self deletePrivateMessage];
                [self.arrData removeObjectAtIndex:self.currentlyPlaingIndex];
                if (self.arrPlaySelectedBlabs.count > 0 && self.currentlyPlaingIndex < self.arrPlaySelectedBlabs.count){
                    [self.arrPlaySelectedBlabs removeObjectAtIndex:self.currentlyPlaingIndex];
                }
                self.countOfPlay --;
                self.currentlyPlaingIndex --;
                [self.tblData reloadData];
                
                self.isPlaying = NO;
                self.selectedPlayID = -1;
                if (self.isPlayAll) {
                    [self startPlayLoop];
                }
            }
            else if (self.isShouldCallIsRead) {
                [self setNotifAsRead];
                self.isPlaying = NO;
                self.selectedPlayID = -1;
                if (self.isPlayAll) {
                    [self startPlayLoop];
                }
            }
        }
    }
}
-(void)fadeInView:(UIView *)view{
    
	view.userInteractionEnabled = YES;
	view.alpha = 0.0;
	[UIView beginAnimations:@"fadeInNewView" context:NULL];
	[UIView setAnimationDuration:1.0];
	view.alpha = 1.0f;
	[UIView commitAnimations];
}

-(void)fadeOutView:(UIView *)view{
	view.alpha = 1.0f;
	[UIView beginAnimations:@"fadeoutNewView" context:NULL];
	[UIView setAnimationDuration:1.0];
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDidStopSelector:@selector(removeFullImageView)];
	view.alpha = 0.1f;
	[UIView commitAnimations];
	
	[self hideActivityIndicatorAfterFadeIn];
}

-(void)fastFadeOutView:(UIView *)view{
  
    view.alpha = 0.1f;
    [self hideActivityIndicatorAfterFadeIn];
    [self removeFullImageView];
}

-(void)hideActivityIndicatorAfterFadeIn{
    
    if (self.imgFullScreenImage.image != nil) {
        [self.activity stopAnimating];
        [self.activity removeFromSuperview];
        self.activity = nil;
        if ([self.timerImgLoad isValid]) {
            [self.timerImgLoad invalidate];
        }
    }
    if (!self.isPlaying && self.imgFullScreenImage.image == nil)  {
        [self.activity stopAnimating];
        [self.activity removeFromSuperview];
        self.activity = nil;
        if ([self.timerImgLoad isValid]) {
            [self.timerImgLoad invalidate];
        }
    }

}

-(void)removeFullImageView{
//    self.imgFullScreenImage.image = nil;
//    [self.imgFullScreenImage removeFromSuperview];
//    self.imgFullScreenImage = nil;
    
    self.viewFullImageContainer.hidden = YES;
    self.isFullScreenClicked = NO;

    //    [self.btnCloseImage removeFromSuperview];
//    [self.btnCloseImage removeTarget:self action:@selector(btnCloseImageClicked:) forControlEvents:UIControlEventTouchUpInside];
//    self.btnCloseImage = nil;
    
    if (![self.timerImgLoad isValid]) {
        [self.activity stopAnimating];
        [self.activity removeFromSuperview];
        self.activity = nil;
    }
}
/*
-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];
    
    if (touch.view == self.imgFullScreenImage)
    {
        NSLog(@"i got you");
        if (self.imgFullScreenImage.alpha == 1.0) {
            if (self.isPlaying) {
                
                if (!self.isPlayAll) {
                    //                    [self fadeOutView:self.imgFullScreenImage];
                    //                    self.isStoppedForceFully = TRUE;
                    
                    if (self.isShowKeepRequest) {
                        
                        [self fadeOutView:self.imgFullScreenImage];
                        self.isStoppedForceFully = TRUE;
                        
                        if (self.isPlaying) {
                            [appDelegate ClosePopUpWithoutUI];
                        }
                        //now no keep request is to be sent so directly delete view once blab.. - shreya
                        //no, so delete that blab
                        [self deletePrivateMessage];
                        [self.arrData removeObjectAtIndex:self.currentlyPlaingIndex];
 if (self.arrPlaySelectedBlabs.count > 0 && self.currentlyPlaingIndex < self.arrPlaySelectedBlabs.count){
 [self.arrPlaySelectedBlabs removeObjectAtIndex:self.currentlyPlaingIndex];
 }
                        self.countOfPlay --;
                        [self.tblData reloadData];
                        
                        self.isPlaying = NO;
                        self.selectedPlayID = -1;
                        if (self.isPlayAll) {
                            [self startPlayLoop];
                        }
                        
//                        [AlertHandler alertTitle:MESSAGE message:KEEP_REQUEST_MESSAGE delegate:self tag:3 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
//
                        
                    }
                    else{
                        self.isStoppedForceFully = TRUE;
                        [self fastFadeOutView:self.imgFullScreenImage];
                        
                    }
                }
                else{
                    [self fastFadeOutView:self.imgFullScreenImage];
                }
                [appDelegate ClosePopUpWithoutUI];
                if ([self.imgPlayAnimation isAnimating]) {
                    [self removeAnimationFromSuperView ];
                }
                
            }
            else{
                [self fadeOutView:self.imgFullScreenImage];
                if (self.isShowKeepRequest) {
                    self.isStoppedForceFully = TRUE;
                    
                    if (self.isPlaying) {
                        [appDelegate ClosePopUpWithoutUI];
                    }
                    
                    //now no keep request is to be sent so directly delete view once blab.. - shreya    
                    //no, so delete that blab
                    [self deletePrivateMessage];
                    [self.arrData removeObjectAtIndex:self.currentlyPlaingIndex];
 if (self.arrPlaySelectedBlabs.count > 0 && self.currentlyPlaingIndex < self.arrPlaySelectedBlabs.count){
 [self.arrPlaySelectedBlabs removeObjectAtIndex:self.currentlyPlaingIndex];
 }
                    self.countOfPlay --;
                    [self.tblData reloadData];
                    
                    self.isPlaying = NO;
                    self.selectedPlayID = -1;
                    if (self.isPlayAll) {
                        [self startPlayLoop];
                    }
                    
//                    [AlertHandler alertTitle:MESSAGE message:KEEP_REQUEST_MESSAGE delegate:self tag:3 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
//
                    
                }
                
            }
        }
        //        self.isPlaying = NO;
        //        self.selectedPlayID = -1;
        //        if (self.isPlayAll) {
        //            [self startPlayLoop];
        //        }
    }
}
*/
-(IBAction)btnBackClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnGoToGroupDetialClicked:(id)sender{
    [self performSegueWithIdentifier:CONVERSATION_GRP_DETAIL_VC sender:nil];
}

-(IBAction)btnEditClicked:(id)sender{
    UIButton *btn = (UIButton *)sender;
    
    if (btn.tag == 1) {
        //edit
        btn.tag = 2;
        [btn setImage:nil forState:UIControlStateNormal];
        [btn setTitle:@"Done" forState:UIControlStateNormal];
        [UIView beginAnimations:@"showShareDeleteCotnainer" context:nil];
        self.viewShareDeleteContainer.hidden = NO;

        [UIView setAnimationDuration:0.5];
        self.viewShareDeleteContainer.frame = CGRectMake(0, [[UIScreen mainScreen] bounds].size.height-50, [[UIScreen mainScreen] bounds].size.width, 50);
        self.viewReplyStickerContainer.frame = CGRectMake(0, [[UIScreen mainScreen] bounds].size.height, self.viewReplyStickerContainer.frame.size.width, 50);
        [UIView commitAnimations];
        [self.tblData reloadData];
    }
    else{
        btn.tag = 1;
//        [btn setImage:[UIImage imageNamed:@"icon_topbar_more.png"] forState:UIControlStateNormal];
//        [btn setTitle:@"" forState:UIControlStateNormal];
        [btn setTitle:[NSString stringWithFormat:@"Share /\nDelete"] forState:UIControlStateNormal];
        self.viewReplyStickerContainer.hidden = NO;
        
        [UIView beginAnimations:@"hideShareDeleteCotnainer" context:nil];
        [UIView setAnimationDuration:0.5];
        self.viewShareDeleteContainer.frame = CGRectMake(0, [[UIScreen mainScreen] bounds].size.height, [[UIScreen mainScreen] bounds].size.width, 50);
        self.viewReplyStickerContainer.frame = CGRectMake(0, [[UIScreen mainScreen] bounds].size.height-50, [[UIScreen mainScreen] bounds].size.width, 50);
        [UIView commitAnimations];
        [self.arrPlaySelectedBlabs removeAllObjects];
        [self.arrData setValue:@"0" forKey:IS_SELECTED];
        [self.tblData reloadData];
    }
}


-(void)get_ConversationWithSelectedUser{
 
    [HUD show:YES];
    self.isCallInitiated = TRUE;
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:USER_CONVERSATION_ID]],KeyValue,USER_CONVERSATION_ID,KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"3",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"4",
						 nil];

	NSString *strUrl = [WebServiceContainer getServiceURL:GET_CONVERSATION_WITH_SELECTED_USER withParameters:nil];
	
//	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
//	request.delegate = self;
//	request.tag = 1;
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:1];
    }
//    [obj setDelegate:self];
//    [obj setTag:1];
	strUrl = nil;
}
-(IBAction)btnPictureBlab_Clicked{
    appDelegate.isForwarded = NO;
    
    self.isStoppedForceFully = TRUE;
    [appDelegate ClosePopUpWithoutUI];
    [self removeAnimationFromSuperView ];
    self.isPlayAll = FALSE;
    
    
    if(!isStickiesKeyboardOpen)
    {
        UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
        [UIView animateWithDuration:0.25 animations:^{
            stickiesView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, KeyboardHeight);
            isStickiesKeyboardOpen = YES;
            [self.tblData setFrame:CGRectMake(self.tblData.frame.origin.x,self.tblData.frame.origin.y, self.tblData.frame.size.width,[UIScreen mainScreen].bounds.size.height-self.tblData.frame.origin.y)];
        } completion:^(BOOL finished) {
            [self performSegueWithIdentifier:CAPTURE_IMAGE_VC sender:self];
        }];
    }
    
    else
    {
        [self performSegueWithIdentifier:CAPTURE_IMAGE_VC sender:self];
    }
    
}
-(IBAction)btnSimpleBlab_Clicked{
    appDelegate.isForwarded = NO;
    
    self.isStoppedForceFully = TRUE;
    [appDelegate ClosePopUpWithoutUI];
    [self removeAnimationFromSuperView ];
    self.isPlayAll = FALSE;
    
    
    if(!isStickiesKeyboardOpen)
    {
        UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
        [UIView animateWithDuration:0.25 animations:^{
            stickiesView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, KeyboardHeight);
            isStickiesKeyboardOpen = YES;
            [self.tblData setFrame:CGRectMake(self.tblData.frame.origin.x,self.tblData.frame.origin.y, self.tblData.frame.size.width,[UIScreen mainScreen].bounds.size.height-self.tblData.frame.origin.y)];
        } completion:^(BOOL finished) {
            [self performSegueWithIdentifier:RECORD_OPTION_VC sender:nil];
        }];
    }
    
    else
    {
        [self performSegueWithIdentifier:RECORD_OPTION_VC sender:nil];
    }
}
-(IBAction)btnVideoBlab_Clicked{
    if ([[NSFileManager defaultManager] fileExistsAtPath:VIDEO_RECORDING_FOLDER]) {
        //when folder exists
        NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
        if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
            [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
        }
    }
    
    appDelegate.isForwarded = NO;
    
    self.isStoppedForceFully = TRUE;
    [appDelegate ClosePopUpWithoutUI];
    [self removeAnimationFromSuperView ];
    self.isPlayAll = FALSE;
    
    
    if(!isStickiesKeyboardOpen)
    {
        UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
        [UIView animateWithDuration:0.25 animations:^{
            stickiesView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, KeyboardHeight);
            isStickiesKeyboardOpen = YES;
            [self.tblData setFrame:CGRectMake(self.tblData.frame.origin.x,self.tblData.frame.origin.y, self.tblData.frame.size.width,[UIScreen mainScreen].bounds.size.height-self.tblData.frame.origin.y)];
        } completion:^(BOOL finished) {
            [self performSegueWithIdentifier:SET_VIDEO_PRIVACY_VC sender:nil];
        }];
    }
    
    else
    {
        [self performSegueWithIdentifier:SET_VIDEO_PRIVACY_VC sender:nil];
    }
}
#pragma mark Text Blab


-(IBAction)btnKeyBoard_Clicked:(id)sender{
    cntLine = 1;
    self.viewContainerTextView.hidden = NO;
    
    if (!textView) {
        
        textView = [[HPGrowingTextView alloc] initWithFrame:CGRectMake(40, 5, 210, 40)];
        textView.isScrollable = YES;
        
        textView.contentInset = UIEdgeInsetsMake(0, 5, 0, 5);
        
        textView.minNumberOfLines = 1;
        textView.maxNumberOfLines = 9;
        // you can also set the maximum height in points with maxHeight
        // textView.maxHeight = 200.0f;
        textView.returnKeyType = UIReturnKeyDefault; //just as an example
        textView.font = [UIFont fontWithName:Font_Montserrat_Regular size:17.0f];
        textView.delegate = self;
        textView.internalTextView.scrollIndicatorInsets = UIEdgeInsetsMake(5, 0, 5, 0);
        textView.backgroundColor = [UIColor whiteColor];
        textView.textColor = UIColorFromRGB(0Xa3a5a7);
        //    textView.placeholder = @"Type to see the textView grow!";
        
        textView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [self.viewContainerTextView addSubview:textView];
        [textView.internalTextView becomeFirstResponder];
    }
    else{
        [textView.internalTextView becomeFirstResponder];
    }
}
- (void)growingTextView:(HPGrowingTextView *)growingTextView willChangeHeight:(float)height
{
    float diff = (growingTextView.frame.size.height - height);
    
    CGRect r = self.viewContainerTextView.frame;
    r.size.height -= diff;
    r.origin.y += diff;
    self.viewContainerTextView.frame = r;
    
}
-(IBAction)btnKeyBoardSend_Clicked:(id)sender{
    
    NSString *str = [textView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (str.length>0) {
//        self.viewContainerTextView.frame = CGRectMake(self.viewContainerTextView.frame.origin.x, DEVICE_HEIGHT-self.viewContainerTextView.frame.size.height, self.viewContainerTextView.frame.size.width, self.viewContainerTextView.frame.size.height);
//        [self.tvTextBlab resignFirstResponder];
//        self.viewContainerTextView.hidden = YES;
//        self.tblData.frame = CGRectMake(self.tblData.frame.origin.x,self.tblData.frame.origin.y, self.tblData.frame.size.width,[UIScreen mainScreen].bounds.size.height-self.tblData.frame.origin.y);
        [self sendTextBlab:str];
    }
    else{
        [Validation showToastMessage:@"Please enter text." displayDuration:ERROR_MSG_DURATION];
    }
}
-(IBAction)btnKeyBoardCancel_Clicked:(id)sender{
    self.viewContainerTextView.frame = CGRectMake(self.viewContainerTextView.frame.origin.x, DEVICE_HEIGHT-self.viewContainerTextView.frame.size.height, self.viewContainerTextView.frame.size.width, self.viewContainerTextView.frame.size.height);
    [textView.internalTextView resignFirstResponder];

    self.viewContainerTextView.hidden = YES;
    self.tblData.frame = CGRectMake(self.tblData.frame.origin.x,self.tblData.frame.origin.y, self.tblData.frame.size.width,[UIScreen mainScreen].bounds.size.height-self.tblData.frame.origin.y);
    if (textView.text.length!=0) {
        textView.text = @"";
    }
}
- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
//    [self animateYPoint:44 viewToAnimate:self.viewContainerTextView];
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
    return YES;
}
- (void)keyboardWillShow:(NSNotification*)notification {
    if ([textView.internalTextView isFirstResponder]) {
        NSDictionary *info = [notification userInfo];
        CGRect frame = [self getStatusBarFrameViewRect:self.view];
        NSLog(@"NSStringFromCGRect(frame %@",NSStringFromCGRect(frame));
        CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
        NSLog(@"self.viewContainerTextView.frame.origin.y-kbSize.height %f",DEVICE_HEIGHT-kbSize.height-self.viewContainerTextView.frame.size.height);
        if (frame.size.height>20) {
            [self animateYPoint:[UIScreen mainScreen].bounds.size.height-kbSize.height-self.viewContainerTextView.frame.size.height-20 viewToAnimate:self.viewContainerTextView];
        }
        else{
            [self animateYPoint:[UIScreen mainScreen].bounds.size.height-kbSize.height-self.viewContainerTextView.frame.size.height viewToAnimate:self.viewContainerTextView];
        }
        keyBoardHeight = kbSize.height;
    }
    
    //    [self animateYPoint:200 viewToAnimate:self.viewContainerTextView];
}
- (CGRect)getStatusBarFrameViewRect:(UIView*)view
{
    CGRect statusBarFrame = [[UIApplication sharedApplication] statusBarFrame];
    
    CGRect statusBarWindowRect = [view.window convertRect:statusBarFrame fromWindow: nil];
    
    CGRect statusBarViewRect = [view convertRect:statusBarWindowRect fromView: nil];
    
    return statusBarViewRect;
}
-(void)animateYPoint:(int)yPoint viewToAnimate:(UIView *)viewToAni{
    [UIView animateWithDuration:0.5 animations:^{
        
        CGRect frame;
        
        // move our subView to its new position
        frame=viewToAni.frame;
        frame.origin.y=yPoint;
        viewToAni.frame=frame;
        viewToAni.alpha=1.0;
        self.tblData.frame = CGRectMake(self.tblData.frame.origin.x, self.tblData.frame.origin.y, self.tblData.frame.size.width, yPoint-frame.size.height-20);
        
        [self scrollToBottom];
    }];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    
//    NSLog(@"textView.text %@",textView.text);

    
    return YES;
 
}
- (void)textViewDidChange:(UITextView *)textView
{
    NSLog(@"textView.text %@",textView.text);
/*
    CGFloat fixedWidth = textView.frame.size.width;
    CGSize newSize = [textView sizeThatFits:CGSizeMake(fixedWidth, MAXFLOAT)];
    CGRect newFrame = textView.frame;
    newFrame.size = CGSizeMake(fmaxf(newSize.width, fixedWidth), newSize.height);
    textView.frame = newFrame;
*/
/*
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    CGRect rect = [str
                   boundingRectWithSize:CGSizeMake(textView.frame.size.width, MAXFLOAT)
                   options:NSStringDrawingUsesLineFragmentOrigin
                   attributes:@{NSFontAttributeName: textView.font,NSParagraphStyleAttributeName:paragraphStyle}
                   context:nil];
*/

/* correct code
    CGFloat fixedWidth = textView.frame.size.width;
    CGSize newSize = [textView sizeThatFits:CGSizeMake(fixedWidth, MAXFLOAT)];
    
    NSLog(@"====-----> %@",NSStringFromCGSize(newSize));
    
    CGRect frame;
    if (newSize.height>=49 && cntLine==1) {
        cntLine=2;
//        [textView setScrollEnabled:NO];
        frame = self.viewContainerTextView.frame;
        frame.size.height += 20;
        frame.origin.y -= 20;
        self.viewContainerTextView.frame = frame;
        
        frame = self.tvTextBlab.frame;
        frame.size.height += 20;
        self.tvTextBlab.frame = frame;
    }
    else if (newSize.height>=66 && cntLine==2) {
        cntLine=3;
        frame = self.viewContainerTextView.frame;
        frame.size.height += 20;
        frame.origin.y -= 20;
        self.viewContainerTextView.frame = frame;
        
        frame = self.tvTextBlab.frame;
        frame.size.height += 20;
        self.tvTextBlab.frame = frame;
    }
*/
    
/*    else if (rect.size.height<=34 && cntLine==3) {
        cntLine=2;
        frame = self.viewContainerTextView.frame;
        frame.size.height += 20;
        frame.origin.y -= 20;
        self.viewContainerTextView.frame = frame;
        
        frame = self.tvTextBlab.frame;
        frame.size.height += 20;
        self.tvTextBlab.frame = frame;
    }
 */
}
-(void)sendTextBlab:(NSString*)strText{
    
    BOOL isGroupMessage = FALSE;
    //    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData lastObject]];
    //    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:self.dicConversationDetail];
    
    NSString *strReceiverId = @"";
    
    if ([[self.dicConversationDetail valueForKey:@"GroupID"] intValue]!=0) {
        //it is group message
        strReceiverId = [NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:@"GroupID"]];
        isGroupMessage = TRUE;
    }
    else{
        strReceiverId = [NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:USER_CONVERSATION_USERID]];
    }
    
    
    NSData *plainData = [strText dataUsingEncoding:NSUTF8StringEncoding];
    NSString *base64String = [plainData base64EncodedStringWithOptions:0];
    NSLog(@"%@", base64String);
    
    [self AddNewTextBlabInArr:strReceiverId isGroup:isGroupMessage strBase64:base64String];
    
    
    UIImage *img = nil;
    //------
    
    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"1",
                          [NSDictionary dictionaryWithObjectsAndKeys:(isGroupMessage)?@"":[NSString stringWithFormat:@"%@",strReceiverId],KeyValue,@"ReceiverIDs",KeyName, nil],@"2",
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",[[[_arrCategory objectAtIndex:selectedIndexPath] valueForKey:@"ID"] intValue]],KeyValue,@"Ctype",KeyName, nil],@"3",
                          [NSDictionary dictionaryWithObjectsAndKeys:(isGroupMessage)?[NSString stringWithFormat:@"%@",strReceiverId]:@"0",KeyValue,@"GroupIDs",KeyName, nil],@"4",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SubCatID",KeyName, nil],@"5",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"6",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"AllFriend",KeyName, nil],@"7",
                          [NSDictionary dictionaryWithObjectsAndKeys:((img!= nil)?img:@""),KeyValue,@"ImgData",KeyName, nil],@"8",
                          [NSDictionary dictionaryWithObjectsAndKeys:base64String,KeyValue,@"Caption",KeyName, nil],@"9",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue, IsPublicImg,KeyName, nil],@"10",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"2",KeyValue, RequestedKeepStatus, KeyName, nil],@"11",
                          // [NSDictionary dictionaryWithObjectsAndKeys:@"1",KeyValue,@"TypeID",KeyName, nil],@"13",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"3",KeyValue, BlabType, KeyName, nil],@"12",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"13",
                          nil];
    
    
    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];
    
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic1 isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:9];
    }
    //    [obj setDelegate:self];
    //    [obj setTag:9];
    strUrl = nil;
    
    [HUD show:YES];
    
}
-(void)AddNewTextBlabInArr:(NSString *)strReceiverId isGroup:(BOOL)isGroupMessage strBase64:(NSString*)base64string{
    NSDictionary *dicTempForNewSticker = [NSDictionary dictionaryWithObjectsAndKeys:
                                          (isGroupMessage)?[NSString stringWithFormat:@"%@",strReceiverId]:@"0",@"GroupIDs",
                                          [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_DISPLAY_NAME]],@"Name",
                                          (isGroupMessage)?@"":[NSString stringWithFormat:@"%@",strReceiverId],@"ReceiverID",
                                          [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],@"SenderID",
                                          [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]],USER_PHOTO_PATH,
                                          base64string,CaptionForImage,
                                          @"3",@"TypeID",
                                          @"1s",@"strDate",
                                          nil];
    [self.arrData addObject:dicTempForNewSticker];
    [self.tblData reloadData];
    
    self.tblData.scrollEnabled = YES;
    if (self.pageCounter == 1) {
        [self scrollToBottom];
    }
}
#pragma mark - Click On Sticker

-(IBAction)clickOnSticker:(id)sender
{
    UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
    
    if(stickiesView==nil)
    {
        //bhavik 24-Feb-2015
        [self performSelectorInBackground:@selector(get_AllMySticker) withObject:nil];
        [self createStickerView];
        self.tblData.userInteractionEnabled = NO;
//        [self get_AllMySticker];
    }
    else
    {
        if(isStickiesKeyboardOpen)
        {
            /*To unhide*/
            UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
            stickiesView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height-50, [UIScreen mainScreen].bounds.size.width, 0.0);
            isStickiesKeyboardOpen = NO;
            
            [UIView animateWithDuration:0.25 animations:^{
                stickiesView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height-KeyboardHeight-BottomViewHeight, [UIScreen mainScreen].bounds.size.width, KeyboardHeight);
                stickiesView.hidden = NO;
                [self.tblData setFrame:CGRectMake(self.tblData.frame.origin.x,self.tblData.frame.origin.y, self.tblData.frame.size.width,stickiesView.frame.origin.y-self.tblData.frame.origin.y)];
                [self scrollToBottom];
            } completion:^(BOOL finished) {
            }];
            
        }
        else
        {
            /*To hide*/
            UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
            [UIView animateWithDuration:0.25 animations:^{
                stickiesView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, KeyboardHeight);
                isStickiesKeyboardOpen = YES;
                [self.tblData setFrame:CGRectMake(self.tblData.frame.origin.x,self.tblData.frame.origin.y, self.tblData.frame.size.width,[UIScreen mainScreen].bounds.size.height-self.tblData.frame.origin.y)];
            } completion:^(BOOL finished) {
            }];
        }

    }
}

-(void)get_AllMySticker
{
    /*
     Long ID (Op.)
     Long UserID (Req.)
     Long PageNo
     Long PageSize
     */
    
    //[HUD show:YES];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,CATEGORY_ID,KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"4",nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_ALLMYSTICKER withParameters:nil];
    
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
        self.tblData.userInteractionEnabled = YES;
    }
    else{
        [obj setDelegate:self];
        [obj setTag:8];
    }
//    [obj setDelegate:self];
//    [obj setTag:8];
    strUrl = nil;
}

-(void)sendSelectedStickerAtIndex:(int)selectedStickerIndex{
    
    BOOL isGroupMessage = FALSE;
//    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData lastObject]];
//    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:self.dicConversationDetail];

    NSString *strReceiverId = @"";
    
    if ([[self.dicConversationDetail valueForKey:@"GroupID"] intValue]!=0) {
        //it is group message
        strReceiverId = [NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:@"GroupID"]];
        isGroupMessage = TRUE;
    }
    else{
        strReceiverId = [NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:USER_CONVERSATION_USERID]];
    }
    
    /*
     AllFriend = "<null>";
     CName = Chat;
     Caption = "";
     ConversationID = 1;
     CreateDate = "2015-02-05T02:58:35.183";
     Ctype = 10039;
     Date = "02/05/2015";
     GroupIDs = 0;
     ID = 181225;
     ImagePath = "http://upload.wwhhaazzuupp.com//StickerImages/SHUAEGUHR2926674_1_1.png";
     IsAbuse = 0;
     IsLike = 0;
     IsPrivate = 0;
     IsPublicImg = 1;
     IsRead = 0;
     IsRequestSent = "<null>";
     KeepStatus = 2;
     MsgID = "<null>";
     Name = Developer2;
     NewSoundID = "<null>";
     OS = "<null>";
     PhotoPath = "http://wwhhaazzuupp.com/Content/UserImages/20191_9CG22015602.jpg";
     ReceiverID = 20191;
     ReceiverIDs = "<null>";
     RegistrationID = "<null>";
     SBCName = "What's Up?";
     SenderID = 20190;
     SoundPath = "<null>";
     StickrID = "<null>";
     SubCatID = 0;
     TotalCount = 33;
     TypeID = 1;
     UnreadCount = 2;
     message = 4;
     strDate = 1m;
     */
     NSLog(@"%d",[[[_arrCategory objectAtIndex:selectedIndexPath] valueForKey:@"ID"] intValue]);
    [self AddNewStickerInArr:strReceiverId isGroup:isGroupMessage selectedIndex:selectedStickerIndex];
    
    UIImage *img = nil;
    //    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
    //                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"1",
    //                          [NSDictionary dictionaryWithObjectsAndKeys:(isGroupMessage)?@"":[NSString stringWithFormat:@"%@",strReceiverId],KeyValue,@"ReceiverIDs",KeyName, nil],@"2",
    //                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"Ctype",KeyName, nil],@"3",
    //                          [NSDictionary dictionaryWithObjectsAndKeys:(isGroupMessage)?[NSString stringWithFormat:@"%@",strReceiverId]:@"0",KeyValue,@"GroupIDs",KeyName, nil],@"4",
    //                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SubCatID",KeyName, nil],@"5",
    //                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"6",
    //                          [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"AllFriend",KeyName, nil],@"7",
    //                          [NSDictionary dictionaryWithObjectsAndKeys:((img!= nil)?img:@""),KeyValue,@"ImgData",KeyName, nil],@"8",
    //                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Caption",KeyName, nil],@"9",
    //                          [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue, IsPublicImg,KeyName, nil],@"10",
    //                          [NSDictionary dictionaryWithObjectsAndKeys:@"2",KeyValue, RequestedKeepStatus, KeyName, nil],@"11",
    //                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[[_arrSubCategory objectAtIndex:selectedIndexPath]objectAtIndex:selectedStickerIndex]valueForKey:@"ID"]], KeyValue,@"StickrID",KeyName, nil],@"12",
    //                          [NSDictionary dictionaryWithObjectsAndKeys:@"1",KeyValue,@"TypeID",KeyName, nil],@"13",
    //
    //                          nil];
    //
    //    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];
    //    ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    //    request.delegate = self;
    //    request.tag = 6;
    //    strUrl = nil;
    
    //------
    
    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"1",
                          [NSDictionary dictionaryWithObjectsAndKeys:(isGroupMessage)?@"":[NSString stringWithFormat:@"%@",strReceiverId],KeyValue,@"ReceiverIDs",KeyName, nil],@"2",
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",[[[_arrCategory objectAtIndex:selectedIndexPath] valueForKey:@"ID"] intValue]],KeyValue,@"Ctype",KeyName, nil],@"3",
                          [NSDictionary dictionaryWithObjectsAndKeys:(isGroupMessage)?[NSString stringWithFormat:@"%@",strReceiverId]:@"0",KeyValue,@"GroupIDs",KeyName, nil],@"4",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SubCatID",KeyName, nil],@"5",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"6",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"AllFriend",KeyName, nil],@"7",
                          [NSDictionary dictionaryWithObjectsAndKeys:((img!= nil)?img:@""),KeyValue,@"ImgData",KeyName, nil],@"8",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Caption",KeyName, nil],@"9",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue, IsPublicImg,KeyName, nil],@"10",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"2",KeyValue, RequestedKeepStatus, KeyName, nil],@"11",
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[[_arrSubCategory objectAtIndex:selectedIndexPath]objectAtIndex:selectedStickerIndex]valueForKey:@"ID"]], KeyValue,@"StickrID",KeyName, nil],@"12",
                         // [NSDictionary dictionaryWithObjectsAndKeys:@"1",KeyValue,@"TypeID",KeyName, nil],@"13",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"1",KeyValue, BlabType, KeyName, nil],@"13",
                        [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"14",
                          nil];
    
    
    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];
    
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic1 isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:9];
    }
//    [obj setDelegate:self];
//    [obj setTag:9];
    strUrl = nil;
    
    [HUD show:YES];
    
}
-(void)AddNewStickerInArr:(NSString *)strReceiverId isGroup:(BOOL)isGroupMessage selectedIndex:(int)selectedStickerIndex{
    NSDictionary *dicTempForNewSticker = [NSDictionary dictionaryWithObjectsAndKeys:
                                          (isGroupMessage)?[NSString stringWithFormat:@"%@",strReceiverId]:@"0",@"GroupIDs",
                                          [[[_arrSubCategory objectAtIndex:selectedIndexPath]objectAtIndex:selectedStickerIndex]valueForKey:@"StickerPath"],@"ImagePath",
                                          [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_DISPLAY_NAME]],@"Name",
                                          (isGroupMessage)?@"":[NSString stringWithFormat:@"%@",strReceiverId],@"ReceiverID",
                                          [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],@"SenderID",
                                          @"1",@"TypeID",
                                          @"1s",@"strDate",
                                          nil];
    [self.arrData addObject:dicTempForNewSticker];
    [self.tblData reloadData];
    
    self.tblData.scrollEnabled = YES;
    if (self.pageCounter == 1) {
        [self scrollToBottom];
    }
}

//  Bhavik 12-mar-2015  /*
-(IBAction)btnReplyClicked:(id)sender{
    appDelegate.isForwarded = NO;
    
    self.isStoppedForceFully = TRUE;
    [appDelegate ClosePopUpWithoutUI];
    [self removeAnimationFromSuperView ];
    self.isPlayAll = FALSE;

    
    if(!isStickiesKeyboardOpen)
    {
        UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
        [UIView animateWithDuration:0.25 animations:^{
            stickiesView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, KeyboardHeight);
            isStickiesKeyboardOpen = YES;
            [self.tblData setFrame:CGRectMake(self.tblData.frame.origin.x,self.tblData.frame.origin.y, self.tblData.frame.size.width,[UIScreen mainScreen].bounds.size.height-self.tblData.frame.origin.y)];
        } completion:^(BOOL finished) {
            [self showYapOptions];
        }];
    }
    
    else
    {
        [self showYapOptions];
    }
}
//*/

//bhavik added this in 13MAR2015, 10:42AM
-(void)StickerKeyboardHide
{
    if(!isStickiesKeyboardOpen)
    {
        UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
        [UIView animateWithDuration:0.25 animations:^{
            stickiesView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, KeyboardHeight);
            isStickiesKeyboardOpen = YES;
            [self.tblData setFrame:CGRectMake(self.tblData.frame.origin.x,self.tblData.frame.origin.y, self.tblData.frame.size.width,[UIScreen mainScreen].bounds.size.height-self.tblData.frame.origin.y)];
        } completion:^(BOOL finished) {
        }];
    }
}

-(void)showYapOptions{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Select" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:Only_Yap,Yap_With_Image,Yap_With_Video, nil];
    [action showInView:self.view];
    
    action.delegate = self;
}
/*  shreya 12-mar-2015
-(void)btnFavoriteClicked:(id)sender{
    
    self.selectedIndex = (int)((UIButton *)sender).tag;
    appDelegate.isForwarded = NO;
    
    [self SetSelectedNotifToFavorites];
}
*/
//  shreya 12-mar-2015  /*
-(void)btnFavoriteClicked:(id)sender{
    
    self.selectedIndex = (int)((UIButton *)sender).tag;
    appDelegate.isForwarded = NO;
    
//    self.isStoppedForceFully = TRUE;
//    [appDelegate ClosePopUpWithoutUI];
//    [self removeAnimationFromSuperView ];
//    self.isPlayAll = FALSE;

    
    NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.selectedIndex] ];
    if ([[dic1 valueForKey:IsPrivate] boolValue]) {
        if ([[NSString stringWithFormat:@"%@",[dic1 valueForKey:RequestedKeepStatus]] intValue] == 1) {
            //this is Private + once blab
            //so you cannot favorite this blab due to visibility of the blab matters here
            [Validation showToastMessage:CANNOT_FAVORITE_PRIVATE_BLAB displayDuration:INFO_MSG_DURATION];
        }
        else{
            // this is private + always blab
            [self SetSelectedNotifToFavorites];
        }
    }
    else{
        //this is Public blab
        [self SetSelectedNotifToFavorites];
    }
}
//  */
-(void)SetSelectedNotifToFavorites{
    
    NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.selectedIndex] ];
    BOOL isLike = [[NSString stringWithFormat:@"%@",[dic1 valueForKey:IS_LIKE]] boolValue];
    
    if (isLike) {
        isLike = FALSE;
    }
    else{
        isLike = TRUE;
    }
    
    dispatch_async(dispatch_get_main_queue(),^{
        
        [self changeLikeButtonImageInListForDic:dic1];
    });
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dic1 valueForKey:NOTIF_ID]],KeyValue,@"MsgID",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:(isLike)?@"true":@"false",KeyValue,@"IsLike",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:SET_NOTIF_LIKE_UNLIKE withParameters:nil];
//	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
//	request.delegate = self;
//	request.tag = 2;
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:2];
    }
//    [obj setDelegate:self];
//    [obj setTag:2];
	strUrl = nil;
}
/*
-(void)btnForwardClicked:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    if (![[dic valueForKey:IS_PRIVATE] boolValue]) {
        self.selectedIndex = (int)btn.tag;
        appDelegate.isForwarded = YES;
        [self performSegueWithIdentifier:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC sender:nil];
    }
    else{
        if ([self.strLoggedInUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
            self.selectedIndex = (int)btn.tag;
            appDelegate.isForwarded = YES;
            [self performSegueWithIdentifier:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC sender:nil];
        }
        else{
            [Validation showToastMessage:@"You cannot forward a private Blabeey!!" displayDuration:ERROR_MSG_DURATION];
        }
    }
}
 */

-(void)btnForwardClicked:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    BOOL CanForward = TRUE;
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_PAID]] boolValue]) {
        //it is paid audio category
        if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_PURCHASED]] boolValue]) {
            //logged in user has purchased it so he can forward it
        }
        else{
            //logged in user has not purchased this paid audio category.. so he can not forward it
            CanForward = FALSE;
        }
    }
    else{
        //this audio file is free, so logged in user can forward it
    }
    
    if (CanForward) {
        
        //now check if this blab is private or not
        
        if (![[dic valueForKey:IS_PRIVATE] boolValue]) {
            //it is public blab
            self.selectedIndex = (int)btn.tag;
            appDelegate.isForwarded = YES;
            [self performSegueWithIdentifier:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC sender:nil];
        }
        else{
            //it is private blab, now check if it is loggen-in user's blab or other user's blab
            if ([self.strLoggedInUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
                //it is private but it is my own blab so can forward it
                //now check if it is keeponce blab
                if ([[NSString stringWithFormat:@"%@",[dic valueForKey:RequestedKeepStatus]] intValue]==1) {
                    //it is once
                    [Validation showToastMessage:@"You cannot forward a private Blab!!" displayDuration:ERROR_MSG_DURATION];
                }
                else{
                    self.selectedIndex = (int)btn.tag;
                    appDelegate.isForwarded = YES;
                    [self performSegueWithIdentifier:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC sender:nil];
                }
            }
            else{
                //i cannot share other user's private blab
                [Validation showToastMessage:@"You cannot forward a private Blab!!" displayDuration:ERROR_MSG_DURATION];
            }
        }
    }
    else{
        [Validation showToastMessage:@"To forward this blab you will have to buy this Audio category." displayDuration:ERROR_MSG_DURATION];
    }
    
}

-(void)changeLikeButtonImageInListForDic:(NSMutableDictionary *)dic{
    BOOL isLike = [[NSString stringWithFormat:@"%@",[dic valueForKey:IS_LIKE]] boolValue];
    if (isLike) {
        [dic setValue:@"0" forKeyPath:IS_LIKE];
    }
    else{
        [dic setValue:@"1" forKeyPath:IS_LIKE];
    }
    
    int section = 1;
    
    if (self.isDataNull) {
        section = 0;
    }
    
    if ([appDelegate.currentVc isKindOfClass:[self class]]) {
        [self.arrData replaceObjectAtIndex:self.selectedIndex withObject:dic];
        NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:self.selectedIndex inSection:section]];
        [self.tblData beginUpdates];
        [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
        [self.tblData endUpdates];
    }
}

-(void)btnReportAbuseClicked:(id)sender{
    
    self.selectedIndex = (int)((UIButton *)sender).tag;
    
    [self btnKeyBoardCancel_Clicked:nil];
    self.isStoppedForceFully = TRUE;
    [appDelegate ClosePopUpWithoutUI];
    [self removeAnimationFromSuperView];
    self.isPlayAll = FALSE;
    

    
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:((UIButton *)sender).tag]];
    if ([[dic valueForKey:IS_REPORTED_FOR_ABUSE] boolValue]) {
        [Validation showToastMessage:@"You have already abused on this Blab" displayDuration:ERROR_MSG_DURATION];
    }
    else{
 //       UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ReportAbuseVC *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:REPORT_ABUSE_VC];
        ivc.dic = dic;
        ivc.reportAbuseFrom = 0;
        ivc.delegate = self;
        [self presentViewController:ivc animated:YES completion:nil];
    }
}

-(void)btnPlayFileClicked:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    [self StickerKeyboardHide];         //13MAR2015, 10:43AM
    
    //self.selectedPlayIndex = (int)btn.tag;
    if (self.isPlaying) {
        self.isStoppedForceFully = TRUE;
        [appDelegate ClosePopUpWithoutUI];
        [self removeAnimationFromSuperView ];
        self.isPlayAll = FALSE;
    }
    else{
        [self playSelectedFileAtIndex:(int)btn.tag];
    }
}
-(void)btnInstaShareClicked:(id)sender{
    UIButton *btn = (UIButton *)sender;
    NSLog(@"insta share for %d",(int)btn.tag);
    
    NSDictionary *dic = [self.arrData objectAtIndex:btn.tag];
/*
    BOOL CanForward = TRUE;
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_PAID]] boolValue]) {
        //it is paid audio category
        if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_PURCHASED]] boolValue]) {
            //logged in user has purchased it so he can forward it
        }
        else{
            //logged in user has not purchased this paid audio category.. so he can not forward it
            CanForward = FALSE;
        }
    }
    else{
        //this audio file is free, so logged in user can forward it
    }
*/
//    if (CanForward) {
        
        //now check if this blab is private or not
        
        if (![[dic valueForKey:IS_PRIVATE] boolValue]) {
            //it is public blab
            if ([DataValidation checkNullString:[dic valueForKey:VideoPath]].length!=0) {
//                NSURL*url=[NSURL URLWithString:[dic valueForKey:VideoPath]];
                [HUD show:YES];
                [self performSelectorInBackground:@selector(loadCameraRollAssetToInstagram:) withObject:dic];
//                [self performSelector:@selector(loadCameraRollAssetToInstagram:) withObject:dic];
//                [self loadCameraRollAssetToInstagram:url andMessage:@""];
            }
            else{
                [HUD show:YES];
                [self shareImageWithInstagram:dic];
            }
        }
        else{
            [Validation showToastMessage:CANNOT_SHARE_PRIVATE_BLAB displayDuration:ERROR_MSG_DURATION];
        }
/*        else{
            //it is private blab, now check if it is loggen-in user's blab or other user's blab
            if ([self.strLoggedInUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
                //it is private but it is my own blab so can forward it
                //now check if it is keeponce blab
                if ([[NSString stringWithFormat:@"%@",[dic valueForKey:RequestedKeepStatus]] intValue]==1) {
                    //it is once
                    [Validation showToastMessage:@"You cannot share a private Blab!!" displayDuration:ERROR_MSG_DURATION];
                }
                else{
                    if ([DataValidation checkNullString:[dic valueForKey:VideoPath]].length!=0) {
                        NSURL*url=[NSURL URLWithString:[dic valueForKey:VideoPath]];
                        [HUD show:YES];
                        [self loadCameraRollAssetToInstagram:url andMessage:@"Hi"];
                    }
                    else{
                        [self shareImageWithInstagram:dic];
                    }
                }
            }
            else{
                //i cannot share other user's private blab
                [Validation showToastMessage:@"You cannot share a private Blab!!" displayDuration:ERROR_MSG_DURATION];
            }
        }
*/
/*    }
    else{
        [Validation showToastMessage:@"To share this blab you will have to buy this Audio category." displayDuration:ERROR_MSG_DURATION];
    }
*/
    
    
}
- (void)loadCameraRollAssetToInstagram:(NSDictionary*)dic
{
    
    NSURL *instagramURL = [NSURL URLWithString:@"instagram://app"];
    if ([[UIApplication sharedApplication] canOpenURL:instagramURL])
    {
        
        NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[dic valueForKey:VideoPath]]];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        
        if (![fm fileExistsAtPath:INSTAGRAMVIDEO_FOLDER]){
            
            [fm createDirectoryAtPath:INSTAGRAMVIDEO_FOLDER
          withIntermediateDirectories:YES
                           attributes:nil
                                error:NULL];
        }
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:INSTAGRAMVIDEO_FOLDER]) {
            NSString *tempPath = [INSTAGRAMVIDEO_FOLDER stringByAppendingFormat:@"/test.mp4"];
            if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
                [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
            }
        }
        
        NSString *tempPath1 = [INSTAGRAMVIDEO_FOLDER stringByAppendingFormat:@"/test.mp4"];
        
        BOOL success = [imageData writeToFile:tempPath1 atomically:NO];
        NSLog(@"success=%d",success);
        
        
        NSString *tempPath = [INSTAGRAMVIDEO_FOLDER stringByAppendingFormat:@"/test.mp4"];
        NSURL *movieURL = [NSURL fileURLWithPath:tempPath];
        
        
        ALAssetsLibrary* library = [[ALAssetsLibrary alloc] init];
        [library writeVideoAtPathToSavedPhotosAlbum:movieURL
                                    completionBlock:^(NSURL *assetURL, NSError *error){
                                        /*notify of completion*/
                                        NSLog(@"assetURL=======%@",assetURL);
                                        NSURL *instagramURL = [NSURL URLWithString:[[NSString stringWithFormat:@"instagram://library?AssetPath=%@&InstagramCaption=#blabeey",assetURL] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
                                        [HUD hide:YES];
                                        if ([[UIApplication sharedApplication] canOpenURL:instagramURL]) {
                                            [[UIApplication sharedApplication] openURL:instagramURL];
                                        }
                                        
                                    }];
        
    }
    else
    {
        [HUD hide:YES];
        [AlertHandler alertTitle:ALERT message:@"Instagram not installed in this device!\nTo share video please install instagram." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
    
}
/*
 - (NSString*)urlencodedString
 {
 return [self stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]];
 }
 */

- (void) shareImageWithInstagram:(NSDictionary*)dicNew
{
    NSURL *instagramURL = [NSURL URLWithString:@"instagram://"];
    if ([[UIApplication sharedApplication] canOpenURL:instagramURL])
    {
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dicNew valueForKey:@"ID"]],KeyValue,@"MessageID",KeyName, nil],@"2",
                             [NSDictionary dictionaryWithObjectsAndKeys:[dicNew valueForKey:@"SoundPath"],KeyValue,@"SoundPath",KeyName, nil],@"3",
                             [NSDictionary dictionaryWithObjectsAndKeys:[dicNew valueForKey:@"ImagePath"],KeyValue,@"ImagePath",KeyName, nil],@"4",
                             nil];
        
        NSString *strUrl = MERGE_AUDIO_IMAGE;
        AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
        obj.isLongTimeOut = YES;
        [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
        if (obj._currentRequest == nil) {
            [HUD hide:YES];
        }
        else{
            [obj setDelegate:self];
            [obj setTag:11];
        }
        //    [obj setDelegate:self];
        //    [obj setTag:5];
        strUrl = nil;

/*
        NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[dic valueForKey:ImagePath]]];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        
        if (![fm fileExistsAtPath:INSTAGRAMIMAGE_FOLDER]){
            
            [fm createDirectoryAtPath:INSTAGRAMIMAGE_FOLDER
          withIntermediateDirectories:YES
                           attributes:nil
                                error:NULL];
        }
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:INSTAGRAMIMAGE_FOLDER]) {
            NSString *tempPath = [INSTAGRAMIMAGE_FOLDER stringByAppendingFormat:@"/test.igo"];
            if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
                [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
            }
        }
        
        NSString *tempPath1 = [INSTAGRAMIMAGE_FOLDER stringByAppendingFormat:@"/test.igo"];
        
        BOOL success = [imageData writeToFile:tempPath1 atomically:NO];
        NSLog(@"success=%d",success);
        
        
        NSString *tempPath = [INSTAGRAMIMAGE_FOLDER stringByAppendingFormat:@"/test.igo"];
        
        NSURL *igImageHookFile = [[NSURL alloc] initWithString:[[NSString alloc] initWithFormat:@"file://%@", tempPath]];
        
        
        self.docFile = [self setupControllerWithURL:igImageHookFile usingDelegate:self];
        self.docFile=[UIDocumentInteractionController interactionControllerWithURL:igImageHookFile];
        self.docFile.UTI = @"com.instagram.photo";
        self.docFile.annotation = [NSDictionary dictionaryWithObject:[NSString stringWithFormat:@"#blabeey"]
                                                              forKey:@"InstagramCaption"];
        
        [self.docFile presentOpenInMenuFromRect:self.view.frame inView:self.view animated:YES];
*/
    }
    else
    {
        [HUD hide:YES];
        [AlertHandler alertTitle:ALERT message:@"Instagram not installed in this device!\nTo share image please install instagram." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
}
/*
- (void)loadCameraRollAssetToInstagram:(NSURL*)assetsLibraryURL andMessage:(NSString*)message
{
    //    NSString *escapedString   = [assetsLibraryURL.absoluteString urlencodedString];
    //    NSString *escapedCaption  = [message urlencodedString];
    
    
    NSURL *instagramURL = [NSURL URLWithString:@"instagram://app"];
    if ([[UIApplication sharedApplication] canOpenURL:instagramURL])
    {
open comment here        NSURL *videoFilePath = [NSURL URLWithString:[NSString stringWithFormat:@"%@",assetsLibraryURL]]; // Your local path to the video
        //        NSString *caption = @"Some Preloaded Caption";
        ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
        [library writeVideoAtPathToSavedPhotosAlbum:videoFilePath completionBlock:^(NSURL *assetURL, NSError *error) {
            //            NSString *escapedString   = [self urlencodedString:videoFilePath.absoluteString];
            //            NSString *escapedCaption  = [self urlencodedString:caption];
            NSURL *instagramURL = [NSURL URLWithString:[NSString stringWithFormat:@"instagram://library?AssetPath=%@&InstagramCaption=%@",assetsLibraryURL.absoluteString,message]];
            if ([[UIApplication sharedApplication] canOpenURL:instagramURL]) {
                [[UIApplication sharedApplication] openURL:instagramURL];
            }
        }];
close comment here
        NSURL *instagramURL = [NSURL URLWithString:[NSString stringWithFormat:@"instagram://library?AssetPath=%@&InstagramCaption=%@",assetsLibraryURL.absoluteString,message]];
        if ([[UIApplication sharedApplication] canOpenURL:instagramURL]) {
            [[UIApplication sharedApplication] openURL:instagramURL];
        }
    }
    else
    {
        [AlertHandler alertTitle:ALERT message:@"Instagram not installed in this device!\nTo share video please install instagram." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
}

- (NSString*)urlencodedString:(NSString *)str
{
    return [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]];
}

- (void) shareImageWithInstagram:(NSDictionary*)dic
{
    NSURL *instagramURL = [NSURL URLWithString:@"instagram://"];
    if ([[UIApplication sharedApplication] canOpenURL:instagramURL])
    {
open comment here        NSURL *imgUrl = [NSURL URLWithString:[dic valueForKey:ImagePath]];
//        NSData* imageData = [NSData dataWithContentsOfURL:imgUrl];
//        NSString* imagePath = [UIUtils documentDirectoryWithSubpath:@"image.igo"];
//        [imageData writeToFile:imagePath atomically:NO];
//        NSURL* fileURL = [NSURL fileURLWithPath:[NSString stringWithFormat:@"file://%@",imagePath]];
        
        self.docFile = [self setupControllerWithURL:imgUrl usingDelegate:self];
        self.docFile.annotation = [NSDictionary dictionaryWithObject: @"This is a demo caption"
                                                              forKey:@"InstagramCaption"];
        self.docFile.UTI = @"com.instagram.photo";
close comment here
        NSURL *imgUrl = [NSURL URLWithString:[dic valueForKey:ImagePath]];
        NSString *escapedString   = [self urlencodedString:[imgUrl absoluteString]];
        NSString *escapedCaption  = [self urlencodedString:[imgUrl absoluteString]];
//        self.docFile = [self setupControllerWithURL:imgUrl usingDelegate:self];
        self.docFile.UTI = @"com.instagram.photo";
        //                NSURL *assetURL;
        
                NSURL *instagramURL = [NSURL URLWithString:[NSString stringWithFormat:@"instagram://library?AssetPath=%@&InstagramCaption=%@",escapedString,escapedCaption]];
                if ([[UIApplication sharedApplication] canOpenURL:instagramURL]) {
                    [[UIApplication sharedApplication] openURL:instagramURL];
                }
        
        // OPEN THE HOOK
        [self.docFile presentOpenInMenuFromRect:self.view.frame inView:self.view animated:YES];
    }
    else
    {
        [AlertHandler alertTitle:ALERT message:@"Instagram not installed in this device!\nTo share image please install instagram." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
}
*/
#pragma mark -- UIDocumentInteractionController delegate

- (UIDocumentInteractionController *) setupControllerWithURL:(NSURL*)fileURL
                                               usingDelegate: (id <UIDocumentInteractionControllerDelegate>) interactionDelegate
{
    UIDocumentInteractionController *interactionController = [UIDocumentInteractionController interactionControllerWithURL: fileURL];
    interactionController.delegate = interactionDelegate;
    
    return interactionController;
}

- (void)documentInteractionControllerWillPresentOpenInMenu:(UIDocumentInteractionController *)controller
{
    NSLog(@"OPEN");
    
//    ViewController *obj = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
//    [self.navigationController pushViewController:obj animated:YES];
}
-(void)playSelectedFileAtIndex:(int)index{
    int section = 1;
    if (self.isDataNull) {
        section = 0;
    }
    
    if ([self.activity isAnimating]) {
        [self.activity stopAnimating];
        [self.activity removeFromSuperview];
        self.activity = nil;
    }
    self.isPlaying = YES;
    self.currentlyPlaingIndex = index;
    NSMutableDictionary *dic = [self.arrData objectAtIndex:index];
    self.selectedPlayID = [[NSString stringWithFormat:@"%@",[dic valueForKey:MESSAGE_CHAT_ID]] intValue];
    
    self.isShowKeepRequest = NO;
    self.isShouldShowImage = TRUE;
    self.isShouldCallIsRead = NO;
    
    if ([[dic valueForKey:IsPrivate] boolValue]) {
        if (![[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]] isEqualToString:self.strLoggedInUserId]) {
            if ([[NSString stringWithFormat:@"%@",[dic valueForKey:RequestedKeepStatus]] intValue] == 1) {
                
                NSString *strRequestSendStatus = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IsRequestSent]]];
                strRequestSendStatus = (strRequestSendStatus.length >0)?strRequestSendStatus:@"false";
                if (strRequestSendStatus.length > 0 && ![strRequestSendStatus boolValue]) {
                    self.isShowKeepRequest = YES;
                }
                if ([strRequestSendStatus boolValue]) {
                    self.isShouldShowImage = FALSE;
                }
            }
            else{
                //private + always show
                //check if call is already sent or not
                if (![[NSString stringWithFormat:@"%@",[dic valueForKey:IsMsgReadNotifSent]] boolValue]) {
                    self.isShouldCallIsRead = YES;
                }
            }
        }
    }
    
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:section];
    
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"1"]) {
        //it is sticker
        self.countOfPlay++;
        [self startPlayLoop];
    }
    else if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"3"]) {
        //it is text blab
        self.countOfPlay++;
        [self startPlayLoop];
    }
    else if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"2"]) {
        //IT IS VIDEO
        [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:section] atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
        if (self.isShouldShowImage) {
            if ([DataValidation checkNullString:[dic valueForKey:VideoPath]].length > 0) {
                //it is image
                
                NSLog(@"it is video");
                
                if ([self.tblData.indexPathsForVisibleRows containsObject:indexPath]) {
                    ConversationWithImgCell *cell = (ConversationWithImgCell *)[self.tblData cellForRowAtIndexPath:indexPath];
                    
                    cell.imgPlayAnimation.hidden = NO;
                    [cell.contentView bringSubviewToFront:cell.imgPlayAnimation];
                    [self setImageViewInview:cell.imgPlayAnimation];
                    
                }
                
                if (!self.isFullScreenClicked) {
                    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
                    btn.tag = index;
                   // [self showImageFrom:btn];
                    [self showVideoFrom:btn];
                    btn = nil;
                }
                
             //   [appDelegate playSoundWithoutUIForURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_AUDIO_PATH]]]];
            }

            self.imgPlayAnimation.layer.cornerRadius = self.imgPlayAnimation.frame.size.height/2.0;
            self.imgPlayAnimation.hidden = NO;
            [self.imgPlayAnimation startAnimating];
            self.countOfPlay ++;
        }
    }
    else{
        [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:section] atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
        if (self.isShouldShowImage) {
            if ([DataValidation checkNullString:[dic valueForKey:ImagePath]].length > 0) {
                //it is image
                
                NSLog(@"it is image");
                
                if ([self.tblData.indexPathsForVisibleRows containsObject:indexPath]) {
                    ConversationWithImgCell *cell = (ConversationWithImgCell *)[self.tblData cellForRowAtIndexPath:indexPath];
                    
                    cell.imgPlayAnimation.hidden = NO;
                    [cell.contentView bringSubviewToFront:cell.imgPlayAnimation];
                    [self setImageViewInview:cell.imgPlayAnimation];
                    
                }
                
                if (!self.isFullScreenClicked) {
                    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
                    btn.tag = index;
                    [self showImageFrom:btn];
                    btn = nil;
                }
                
                [appDelegate playSoundWithoutUIForURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_AUDIO_PATH]]]];
            }
            else{
                
                NSLog(@"it is not an Image");
                if ([self.tblData.indexPathsForVisibleRows containsObject:indexPath]) {
                    ConversationWithoutImgCell *cell = (ConversationWithoutImgCell *)[self.tblData cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:section]];
                    cell.imgPlayAnimation.hidden = NO;
                    [cell.contentView bringSubviewToFront:cell.imgPlayAnimation];
                    [self setImageViewInview:cell.imgPlayAnimation];
                }
                [appDelegate playSoundWithoutUIForURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_AUDIO_PATH]]]];
            }
            
            
            self.imgPlayAnimation.layer.cornerRadius = self.imgPlayAnimation.frame.size.height/2.0;
            self.imgPlayAnimation.hidden = NO;
            [self.imgPlayAnimation startAnimating];
            self.countOfPlay ++;
        }
        else{
            //keep request already sent, so couldnot show this blab till opponent user responds to request
            [Validation showToastMessage:@"Please wait till user responds to your keep request" displayDuration:ERROR_MSG_DURATION];
        }
/*
        if ([DataValidation checkNullString:[dic valueForKey:ImagePath]].length > 0) {
            //it is image
            
            NSLog(@"it is image");
            
            if ([self.tblData.indexPathsForVisibleRows containsObject:indexPath]) {
                ConversationWithImgCell *cell = (ConversationWithImgCell *)[self.tblData cellForRowAtIndexPath:indexPath];
                
                cell.imgPlayAnimation.hidden = NO;
                [cell.contentView bringSubviewToFront:cell.imgPlayAnimation];
                [self setImageViewInview:cell.imgPlayAnimation];
                
            }
            
            if (!self.isFullScreenClicked) {
                UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
                btn.tag = index;
                [self showImageFrom:btn];
                btn = nil;
            }
            
            [appDelegate playSoundWithoutUIForURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_AUDIO_PATH]]]];
        }
        else{
            
            NSLog(@"it is not an Image");
            if ([self.tblData.indexPathsForVisibleRows containsObject:indexPath]) {
                ConversationWithoutImgCell *cell = (ConversationWithoutImgCell *)[self.tblData cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:section]];
                cell.imgPlayAnimation.hidden = NO;
                [cell.contentView bringSubviewToFront:cell.imgPlayAnimation];
                [self setImageViewInview:cell.imgPlayAnimation];
            }
            [appDelegate playSoundWithoutUIForURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_AUDIO_PATH]]]];
        }
        
        
        self.imgPlayAnimation.layer.cornerRadius = self.imgPlayAnimation.frame.size.height/2.0;
        self.imgPlayAnimation.hidden = NO;
        [self.imgPlayAnimation startAnimating];
        self.countOfPlay ++;
*/
    }
}

-(void)setImageViewInview:(id)viewToPlayAnimationIn{
    
    if (self.imgPlayAnimation == nil) {
        self.imgPlayAnimation = [[UIImageView alloc] init];
        self.imgPlayAnimation.backgroundColor = [UIColor whiteColor];
        self.imgPlayAnimation.layer.cornerRadius = self.imgPlayAnimation.frame.size.height/2.0;
        
        [self initializeAnimationArray];
    }
    
    [self.imgPlayAnimation stopAnimating];
    [self.imgPlayAnimation removeFromSuperview];
    
    if ([viewToPlayAnimationIn isKindOfClass:[UIImageView class]]) {
        UIImageView *img = (UIImageView *)viewToPlayAnimationIn;
        [self.imgPlayAnimation setFrame:CGRectMake(0, 0, img.frame.size.width,img.frame.size.height)];
        [img addSubview:self.imgPlayAnimation];
    }
    else if ([viewToPlayAnimationIn isKindOfClass:[UIButton class]]){
        UIButton *img = (UIButton *)viewToPlayAnimationIn;
        [self.imgPlayAnimation setFrame:CGRectMake(0, 0, img.frame.size.width,img.frame.size.height)];
        [img addSubview:self.imgPlayAnimation];
        [img bringSubviewToFront:self.imgPlayAnimation];
    }
    self.imgPlayAnimation.backgroundColor = [UIColor whiteColor];
    self.imgPlayAnimation.layer.cornerRadius = self.imgPlayAnimation.frame.size.height/2.0;
    
    self.imgPlayAnimation.hidden = NO;
    [self.imgPlayAnimation startAnimating];
}

-(void)startPlayLoop{
    
    if (self.countOfPlay < self.arrPlaySelectedBlabs.count) {
        NSString *strIdOfObject = [[self.arrPlaySelectedBlabs objectAtIndex:self.countOfPlay] valueForKey:MESSAGE_CHAT_ID];
        
        NSUInteger index = [self.arrData indexOfObjectPassingTest:
                            ^BOOL(NSDictionary *dict, NSUInteger idx, BOOL *stop)
                            {
                                return [[NSString stringWithFormat:@"%@",[dict valueForKey:MESSAGE_CHAT_ID]] isEqual:strIdOfObject];
                            }
                            ];
        if (index==-1 || index>self.arrData.count) {
            self.countOfPlay++;
            [self startPlayLoop];
        }
        else{
            [self playSelectedFileAtIndex:(int)index];
            
            //self.countOfPlay++;
        }
    }
    else{
        self.isPlayAll = FALSE;
    }
}

-(IBAction)btnPlayAllClicked:(id)sender{
    NSLog(@"%@",[self.arrData valueForKey:IS_SELECTED]);
    
    [self StickerKeyboardHide];         //13MAR2015, 10:43AM
    [self btnKeyBoardCancel_Clicked:nil];

    
    if (self.arrPlaySelectedBlabs == nil) {
        self.arrPlaySelectedBlabs = [[NSMutableArray alloc] init];
    }
    [self.arrPlaySelectedBlabs removeAllObjects];
    
     if (self.btnEditDone.tag == 1) {
        //play all loaded blabs
        for (int i=0; i<self.arrData.count; i++) {
            NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:i]];
            [self.arrPlaySelectedBlabs addObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dic valueForKey:MESSAGE_CHAT_ID]],MESSAGE_CHAT_ID, nil]];
        }
    }
    else{
        //play selected blabs
        for (int i=0; i<self.arrData.count; i++) {
            NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:i]];
            if ([[dic valueForKey:IS_SELECTED] boolValue]) {
                //[self.arrPlaySelectedBlabs addObject:[NSNumber numberWithInt:i]];
                [self.arrPlaySelectedBlabs addObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dic valueForKey:MESSAGE_CHAT_ID]],MESSAGE_CHAT_ID, nil]];
           }
        }
    }
    if (self.arrPlaySelectedBlabs.count == 0) {
        [Validation showToastMessage:@"Please select Blabs to Play" displayDuration:ERROR_MSG_DURATION];
    }
    else{
        self.isPlayAll = YES;
        self.countOfPlay = 0;
        self.isStoppedForceFully = NO;
        [self startPlayLoop];
    }

}

-(void)removeAnimationFromSuperView{
    [self.imgPlayAnimation removeFromSuperview];
    [self.imgPlayAnimation stopAnimating];
    [self.imgPlayAnimation setHidden:YES];

    
    if (self.arrData.count != 0) {
        NSLog(@"%d currentlyPlaingIndex %d",(int)self.arrData.count,self.currentlyPlaingIndex);
        if (self.currentlyPlaingIndex>=self.arrData.count) {
            return;
        }
        NSDictionary *dicPlaingBlab = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.currentlyPlaingIndex]];
        if (!self.isStoppedForceFully) {
            
            if ([[dicPlaingBlab valueForKey:IsPrivate] boolValue]) {
                if (![[NSString stringWithFormat:@"%@",[dicPlaingBlab valueForKey:SENDER_ID]] isEqualToString:self.strLoggedInUserId]) {
                    if ([[NSString stringWithFormat:@"%@",[dicPlaingBlab valueForKey:RequestedKeepStatus]] intValue] == 1) {
                        //its once
                        //ask for keep request
                        
    //                    NSString *strRequestSendStatus = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dicPlaingBlab valueForKey:IsRequestSent]]];
    //                    strRequestSendStatus = (strRequestSendStatus.length >0)?strRequestSendStatus:@"false";
    //                    if (strRequestSendStatus.length > 0 && ![strRequestSendStatus boolValue]) {
                        if (self.isShowKeepRequest) {
                            self.isShowKeepRequest = YES;
                            if (self.isPlayAll) {
                                if (self.imgFullScreenImage != nil) {
                                   
//                                    [self fastFadeOutView:self.imgFullScreenImage];
                                     [self fastFadeOutView:self.viewFullImageContainer];
                                    if (self.isPlaying) {
                                        [appDelegate ClosePopUpWithoutUI];
                                    }
                                }
                                //now no keep request is to be sent so directly delete view once blab.. - shreya        /*
                                //no, so delete that blab
                                [self deletePrivateMessage];
                                [self.arrData removeObjectAtIndex:self.currentlyPlaingIndex];
                                if (self.arrPlaySelectedBlabs.count > 0 && self.currentlyPlaingIndex < self.arrPlaySelectedBlabs.count){
                                    [self.arrPlaySelectedBlabs removeObjectAtIndex:self.currentlyPlaingIndex];
                                }
                                self.countOfPlay --;
                                self.currentlyPlaingIndex --;
                                [self.tblData reloadData];
                                
                                self.isPlaying = NO;
                                self.selectedPlayID = -1;
                                if (self.isPlayAll) {
                                    [self startPlayLoop];
                                }
                                
    //                            [AlertHandler alertTitle:MESSAGE message:KEEP_REQUEST_MESSAGE delegate:self tag:3 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
    //                              */
                            }
                            else if ([DataValidation checkNullString:[dicPlaingBlab valueForKey:ImagePath]].length == 0){
                                if (self.isPlaying) {
                                    [appDelegate ClosePopUpWithoutUI];
                                }
                                //now no keep request is to be sent so directly delete view once blab.. - shreya        /*
                                //no, so delete that blab
                                if (self.isShouldCallIsRead) {
                                    [self setNotifAsRead];
                                }
                                else{
                                    [self deletePrivateMessage];
                                }
//                                [self deletePrivateMessage];
                                [self.arrData removeObjectAtIndex:self.currentlyPlaingIndex];
                                if (self.arrPlaySelectedBlabs.count > 0 && self.currentlyPlaingIndex < self.arrPlaySelectedBlabs.count){
                                    [self.arrPlaySelectedBlabs removeObjectAtIndex:self.currentlyPlaingIndex];
                                }
                                self.countOfPlay --;
                                self.currentlyPlaingIndex --;
                                [self.tblData reloadData];
                                
                                self.isPlaying = NO;
                                self.selectedPlayID = -1;
                                if (self.isPlayAll) {
                                    [self startPlayLoop];
                                }
                                
    //                            [AlertHandler alertTitle:MESSAGE message:KEEP_REQUEST_MESSAGE delegate:self tag:3 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
    //                              */
                            }
                        }
                        else{
                            self.isShowKeepRequest = NO;
                            if (self.imgFullScreenImage != nil) {
//                                [self fastFadeOutView:self.imgFullScreenImage];
                                [self fastFadeOutView:self.viewFullImageContainer];
                                
                                //---
                                if (self.isPlaying) {
                                    [appDelegate ClosePopUpWithoutUI];
                                }
                            }
                            if (self.isShouldCallIsRead) {
                                [self setNotifAsRead];
                            }
                            self.isPlaying = NO;
                            self.selectedPlayID = -1;
                            if (self.isPlayAll) {
                                [self startPlayLoop];
                            }
                        }
                    }
                    else{
                        self.isShowKeepRequest = NO;
                        if (self.imgFullScreenImage != nil) {
                            
                            if (self.isPlayAll) {
//                                [self fastFadeOutView:self.imgFullScreenImage];
                                [self fastFadeOutView:self.viewFullImageContainer];
                            }
                            //------
                            if (self.isPlaying) {
                                [appDelegate ClosePopUpWithoutUI];
                            }
                        }
                        if (self.isShouldCallIsRead) {
                            [self setNotifAsRead];
                        }
                        self.isPlaying = NO;
                        self.selectedPlayID = -1;
                        if (self.isPlayAll) {
                            [self startPlayLoop];
                        }
                    }
                }
                else{
                    self.isShowKeepRequest = NO;
                    if (self.imgFullScreenImage != nil) {
                        if (self.isPlayAll) {
//                            [self fastFadeOutView:self.imgFullScreenImage];
                            [self fastFadeOutView:self.viewFullImageContainer];
                        }
                        //-----
                        if (self.isPlaying) {
                            [appDelegate ClosePopUpWithoutUI];
                        }
                    }
                    if (self.isShouldCallIsRead) {
                        [self setNotifAsRead];
                    }
                    self.isPlaying = NO;
                    self.selectedPlayID = -1;
                    if (self.isPlayAll) {
                        [self startPlayLoop];
                    }
                }
            }
            else{
                self.isShowKeepRequest = NO;
                if (self.imgFullScreenImage != nil) {
                    if (self.isPlayAll) {
//                        [self fastFadeOutView:self.imgFullScreenImage];
                        [self fastFadeOutView:self.viewFullImageContainer];
                    }
                    
                    
                    //-----
                    if (self.isPlaying) {
                        [appDelegate ClosePopUpWithoutUI];
                    }
                }
                
                if (self.isShouldCallIsRead) {
                    [self setNotifAsRead];
                }
                self.isPlaying = NO;
                self.selectedPlayID = -1;
                if (self.isPlayAll) {
                    [self startPlayLoop];
                }
            }
        }
        else{
            if ([[NSString stringWithFormat:@"%@",[dicPlaingBlab valueForKey:@"TypeID"]] isEqualToString:@"2"]) {
            }
            else{
                if ([DataValidation checkNullString:[dicPlaingBlab valueForKey:ImagePath]].length > 0) {
                    //it is image
                    
                    NSLog(@"it is image");
                }
                else{
                    NSLog(@"it is not an Image");
                    if (self.isShowKeepRequest) {
                        
                        if (self.isPlaying) {
                            [appDelegate ClosePopUpWithoutUI];
                        }
                        //now no keep request is to be sent so directly delete view once blab.. - shreya        /*
                        //no, so delete that blab
                        [self deletePrivateMessage];
                        [self.arrData removeObjectAtIndex:self.currentlyPlaingIndex];
                        if (self.arrPlaySelectedBlabs.count > 0 && self.currentlyPlaingIndex < self.arrPlaySelectedBlabs.count){
                            [self.arrPlaySelectedBlabs removeObjectAtIndex:self.currentlyPlaingIndex];
                        }
                        self.countOfPlay --;
                        self.currentlyPlaingIndex --;
                        [self.tblData reloadData];
                        
                        self.isPlaying = NO;
                        self.selectedPlayID = -1;
                        if (self.isPlayAll) {
                            [self startPlayLoop];
                        }
                        
                        //                [AlertHandler alertTitle:MESSAGE message:KEEP_REQUEST_MESSAGE delegate:self tag:3 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
                        //              */
                    }
                    else if (self.isShouldCallIsRead) {
                        [self setNotifAsRead];
                    }
                    self.isShowKeepRequest = NO;
                }
                
            }
            
            self.isPlaying = NO;
            //        self.isStoppedForceFully = FALSE;
            self.isStoppedForceFully = TRUE;

            
        }
    }
}

-(IBAction)btnDeleteClicked:(id)sender{
    
    if ([self getSelectedIds:YES].length == 0) {
        [AlertHandler alertTitle:MESSAGE message:@"Please select at least one blab to delete." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
    else{
        
        [AlertHandler alertTitle:CONFIRM message:@"Are you sure you want to delete the selected Blabs?" delegate:self tag:1 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
    }
}

-(IBAction)btnShareClicked:(id)sender{
    if ([self getSelectedIds:NO].length == 0) {
        [AlertHandler alertTitle:MESSAGE message:@"Please select at least one public blab to share." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
    else{
        [AlertHandler alertTitle:CONFIRM message:@"Are you sure you want to share the selected Blabs?  Blabs marked as Private cannot be shared." delegate:self tag:2 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
    }
}

-(NSString *)getSelectedIds:(BOOL)isDelete{
    NSString *strSelectedIds = @"";
    for (int i = 0; i<self.arrData.count; i++) {
        NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:i]];
        if ([[dic valueForKey:IS_SELECTED] boolValue]) {
            if (isDelete) {
                if (strSelectedIds.length == 0) {
                    
                    strSelectedIds = [NSString stringWithFormat:@"%@",[dic valueForKey:MESSAGE_CHAT_ID]];
                }
                else{
                    strSelectedIds = [strSelectedIds stringByAppendingFormat:@"|%@",[dic valueForKey:MESSAGE_CHAT_ID]];
                }
            }
            else{
                // not private and not sticker
//                if (![[dic valueForKey:IS_PRIVATE] boolValue] && ![[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"1"])  {
                if (![[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"3"] && ![[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"4"] && ![[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"5"]){
                    if (![[dic valueForKey:IS_PRIVATE] boolValue])  {
                            if (strSelectedIds.length == 0) {
                                
                                strSelectedIds = [NSString stringWithFormat:@"%@",[dic valueForKey:MESSAGE_CHAT_ID]];
                            }
                            else{
                                strSelectedIds = [strSelectedIds stringByAppendingFormat:@"|%@",[dic valueForKey:MESSAGE_CHAT_ID]];
                            }
                    }
                }
            }
        }
    }
    return strSelectedIds;
}

-(void)removeRowsFromArray{
    for (int i = 0; i<self.arrData.count; i++) {
        if ([[[self.arrData objectAtIndex:i] valueForKey:IS_SELECTED] boolValue]) {
            [self.arrData removeObjectAtIndex:i];
            i--;
        }
    }
    if ([self.arrData count]==0) {
        self.pageCounter = 1;
        
        [self get_ConversationWithSelectedUser];
    }
//    [self.tblData reloadData];
    [self hideLongPressEnabledBtns];
}
/*
-(void)callDeleteSelectedCellService{
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:USER_CONVERSATION_ID]],KeyValue,USER_CONVERSATION_ID,KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[self getSelectedIds:YES],KeyValue,@"MsgIDs",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:DELETE_SELECTED_CHAT_FROM_CONVERSATION withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
	request.delegate = self;
	request.tag = 4;
//    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
//    [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
//    [obj setDelegate:self];
//    [obj setTag:4];
	strUrl = nil;

    [self performSelectorInBackground:@selector(removeRowsFromArray) withObject:nil];
}
*/
-(void)setNotifAsRead{
    
    NSMutableDictionary *temp = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.currentlyPlaingIndex]];
    [temp setValue:@"1" forKey:IsMsgReadNotifSent];
    [self.arrData replaceObjectAtIndex:self.currentlyPlaingIndex withObject:temp];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[temp valueForKey:MESSAGE_CHAT_ID]],KeyValue,@"MsgID",KeyName, nil],@"2",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:NOTIF_READ withParameters:nil];
    ASIHTTPRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:14];
    }
//    request.delegate = self;
//    request.tag = 14;
    strUrl = nil;
    temp = nil;
}
-(void)callDeleteSelectedCellService{
    [HUD show:YES];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:USER_CONVERSATION_ID]],KeyValue,USER_CONVERSATION_ID,KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[self getSelectedIds:YES],KeyValue,@"MsgIDs",KeyName, nil],@"3",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:DELETE_SELECTED_CHAT_FROM_CONVERSATION withParameters:nil];
    
    ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:4];
    }
//    request.delegate = self;
//    request.tag = 4;
}
-(void)callShareSelectedCellService{
        //TypeID = 0 for blab, 1 for hashBlab
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:USER_CONVERSATION_ID]],KeyValue,USER_CONVERSATION_ID,KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[self getSelectedIds:NO],KeyValue,@"MsgIDs",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"TypeID",KeyName, nil],@"4",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:SHARE_SELECTED_CHAT withParameters:nil];
//	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
//	request.delegate = self;
//	request.tag = 5;
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:5];
    }
//    [obj setDelegate:self];
//    [obj setTag:5];
	strUrl = nil;
    [self hideLongPressEnabledBtns];
}
-(void)callSetViewCountService{
    
    /*
     public enum BlabType
     {
     NormalBlab = 0,
     HashBlab = 1
     }
     */
    
    NSDictionary *dicVideo = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.currentlyPlaingIndex]];
    NSLog(@"dicVideo = %@",dicVideo);
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.videoPlayCounter],KeyValue,@"ViewCount",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[dicVideo valueForKey:MESSAGE_CHAT_ID],KeyValue,@"MsgID",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"BlabType",KeyName, nil],@"3",
                         nil];
    
    NSLog(@"dic = %@",dic);
    NSString *strUrl = [WebServiceContainer getServiceURL:SET_VIDEO_VIEW_COUNT withParameters:nil];

    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:10];
    }

    strUrl = nil;
    [self hideLongPressEnabledBtns];
    
}
-(void)shareWithShareURL:(NSDictionary *)shareURL{
    self.strShareURL = [shareURL valueForKey:@"Url"];
    self.strShareImagePathURL = [shareURL valueForKey:@"ImagePath"];
    if (self.objShareVC == nil) {
//        UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        self.objShareVC = [MainStoryboard instantiateViewControllerWithIdentifier:SOCIAL_SHARE_VC];
        self.objShareVC.delegate = self;
        self.objShareVC.view.frame = self.view.frame;
        [self.view addSubview:self.objShareVC.view];
        [self.objShareVC didMoveToParentViewController:self];
        [self addChildViewController:self.objShareVC];
    }
    
    //fb
    UIButton *btnFb = (UIButton *)[self.objShareVC.viewContainer viewWithTag:1];      //fb
    [btnFb removeTarget:self action:@selector(shareWithFBClicked:) forControlEvents:UIControlEventTouchUpInside];
    [btnFb addTarget:self action:@selector(shareWithFBClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    //twitter
    UIButton *btnTwitter = (UIButton *)[self.objShareVC.viewContainer viewWithTag:2];      //twitter
    [btnTwitter removeTarget:self action:@selector(shareWithTwitterClicked:) forControlEvents:UIControlEventTouchUpInside];
    [btnTwitter addTarget:self action:@selector(shareWithTwitterClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    //mail
    UIButton *btnMail = (UIButton *)[self.objShareVC.viewContainer viewWithTag:3];      //twitter
    [btnMail removeTarget:self action:@selector(ShareThroughMail:) forControlEvents:UIControlEventTouchUpInside];
    [btnMail addTarget:self action:@selector(ShareThroughMail:) forControlEvents:UIControlEventTouchUpInside];
    
    //sms
    UIButton *btnMessage = (UIButton *)[self.objShareVC.viewContainer viewWithTag:4];      //twitter
    [btnMessage removeTarget:self action:@selector(ShareThroughSMS:) forControlEvents:UIControlEventTouchUpInside];
    [btnMessage addTarget:self action:@selector(ShareThroughSMS:) forControlEvents:UIControlEventTouchUpInside];
    
    if (dicSelForSingleVideoImageShare!=nil) {
        
    }
}

-(void)sendKeppRequestForIndex{
    
    NSMutableDictionary *dict1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.currentlyPlaingIndex]];
    [dict1 setValue:@"1" forKeyPath:IsRequestSent];
    [self.arrData replaceObjectAtIndex:self.currentlyPlaingIndex withObject:dict1];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.currentlyPlaingIndex] valueForKey:MESSAGE_CHAT_ID]],KeyValue,@"MsgID",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:SEND_KEEP_REQUEST withParameters:nil];
   
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:6];
    }
//    [obj setDelegate:self];
//    [obj setTag:6];
	strUrl = nil;
}

-(void)deletePrivateMessage{
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.currentlyPlaingIndex] valueForKey:MESSAGE_CHAT_ID]],KeyValue,@"MsgID",KeyName, nil],@"2",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:DELETE_CHAT_PRIVATE_MESSAGE withParameters:nil];
    
    ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:7];
    }
//    request.delegate = self;
//    request.tag = 7;
    
    
    //    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    //    [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    //    [obj setDelegate:self];
    //    [obj setTag:7];
    strUrl = nil;
}

#pragma mark  UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
//    return 56;
    if (section == 0) {
        if (!self.isDataNull) {
            return 0;
        }
    }
    else return 56;
    return 56;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *viewFooter = [[UIView alloc] init];
    viewFooter.backgroundColor = [UIColor clearColor];
    return viewFooter;
}
/*
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (self.arrData.count >0) {
        if (!self.isDataNull) {
            if (indexPath.section == 1) {
                if (indexPath.row<self.arrData.count) {
                    NSDictionary *dic = [self.arrData objectAtIndex: indexPath.row];
                    
                    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"1"]) {
                        
                        return CellHeightWithSticker;
                    }
                    else{
                        if ([DataValidation checkNullString:[dic valueForKey:ImagePath]].length > 0) {
                            return CellHeightWithImg;
                        }
                        else{
                            if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON]) {
                                return CellHeightWithOutImg+30;
                            }
                            else{
                                return CellHeightWithOutImg;
                            }
                        }
                    }
                }
                else return CellHeightWithOutImg;
            }
            else return 0;
        }
        else{
            if (indexPath.row<self.arrData.count) {
                NSDictionary *dic = [self.arrData objectAtIndex: indexPath.row];
                
                if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"1"]) {
                    
                    return CellHeightWithSticker;
                }
                else{
                    if ([DataValidation checkNullString:[dic valueForKey:ImagePath]].length > 0) {
                        return CellHeightWithImg;
                    }
                    else{
                        return CellHeightWithOutImg;
                    }
                }
            }
            else return 0;
        }
    }
    return 0;
}
*/
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (self.arrData.count >0) {
        if (!self.isDataNull) {
            if (indexPath.section == 1) {
                if (indexPath.row<self.arrData.count) {
                    NSDictionary *dic = [self.arrData objectAtIndex: indexPath.row];
                    
                    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"1"]) {
                        
                        return CellHeightWithSticker;
                    }
                    else if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"3"] || [[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"4"] || [[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"5"]) {
                        CGRect size = [self getHeightTextBlab:[dic valueForKey:CaptionForImage]];
//                        CGRect size = [self getHeightTextBlab:[NSString stringWithFormat:@"\n\n\n\n"]];
                        NSLog(@"*****---> %f",size.size.height);
                        if (size.size.height<19) {
                            
                            return 130;
                        }
                        else{
                            return 100+ceilf(size.size.height);
                        }
                    }
                    else{
                        if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"2"]) {
                            //vidi blab
                            if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON] && [DataValidation checkNullString:[dic valueForKey:FULL_DESCRIPTION]].length != 0) {
                                CGRect frameSize = [self getHeight:[dic valueForKey:FULL_DESCRIPTION]];
                                return CellHeightWithImg+frameSize.size.height+20;
                            }
                            else{
                                return CellHeightWithImg;
                            }
                        }
                        else{
                            if ([DataValidation checkNullString:[dic valueForKey:ImagePath]].length > 0) {
                                //image blab
                                if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON] && [DataValidation checkNullString:[dic valueForKey:FULL_DESCRIPTION]].length != 0) {
                                    CGRect frameSize = [self getHeight:[dic valueForKey:FULL_DESCRIPTION]];
                                    return CellHeightWithImg+frameSize.size.height+20;
                                }
                                else{
                                    return CellHeightWithImg;
                                }
                                
                            }
                            else{
                                //simple blab
                                if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON] && [DataValidation checkNullString:[dic valueForKey:FULL_DESCRIPTION]].length != 0) {
                                    CGRect frameSize = [self getHeight:[dic valueForKey:FULL_DESCRIPTION]];
                                    return CellHeightWithOutImg+frameSize.size.height+20;
                                }
                                else{
                                    return CellHeightWithOutImg;
                                }
                            }
                        }
                    }
                }
                else return CellHeightWithOutImg;
            }
            else return 0;
        }
        else{
            if (indexPath.row<self.arrData.count) {
                NSDictionary *dic = [self.arrData objectAtIndex: indexPath.row];
                
                if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"1"]) {
                    
                    return CellHeightWithSticker;
                }
                else if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"3"] || [[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"4"] || [[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"5"]) {
                    // Text blab
                    CGRect size = [self getHeightTextBlab:[dic valueForKey:CaptionForImage]];
//                    CGRect size = [self getHeightTextBlab:[NSString stringWithFormat:@"\n\n\n\n"]];
                    NSLog(@"*****---> %f",size.size.height);
                    if (size.size.height<19) {
                        
                        return 120;
                    }
                    else{
                        return 90+ceilf(size.size.height);
                    }
                }
                else{
                    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"2"]) {
                        //vidi blab
                        if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON] && [DataValidation checkNullString:[dic valueForKey:FULL_DESCRIPTION]].length != 0) {
                            CGRect frameSize = [self getHeight:[dic valueForKey:FULL_DESCRIPTION]];
                            return CellHeightWithImg+frameSize.size.height+20;
                        }
                        else{
                            return CellHeightWithImg;
                        }
                    }
                    else{
                        if ([DataValidation checkNullString:[dic valueForKey:ImagePath]].length > 0) {
                            if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON] && [DataValidation checkNullString:[dic valueForKey:FULL_DESCRIPTION]].length != 0) {
                                CGRect frameSize = [self getHeight:[dic valueForKey:FULL_DESCRIPTION]];
                                return CellHeightWithImg+frameSize.size.height+20;
                            }
                            else{
                                return CellHeightWithImg;
                            }
                        }
                        else{
                            if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON] && [DataValidation checkNullString:[dic valueForKey:FULL_DESCRIPTION]].length != 0) {
                                CGRect frameSize = [self getHeight:[dic valueForKey:FULL_DESCRIPTION]];
                                return CellHeightWithOutImg+frameSize.size.height+20;
                            }
                            else{
                                return CellHeightWithOutImg;
                            }
                        }
                    }
                }
            }
            else return 0;
        }
    }
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        if (!self.isDataNull) {
            return 64;
        }
    }
    else return 5;
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *viewLoadMore = [[UIView alloc] initWithFrame:CGRectMake(0, 0, DEVICE_WIDTH, 35)];
    viewLoadMore.backgroundColor = [UIColor clearColor];
    if (section == 0) {
        if (!self.isDataNull && self.arrData.count>0) {
            self.btnLoadMore.frame = CGRectMake(0, 0, DEVICE_WIDTH, 35);
            
            [self.btnLoadMore removeFromSuperview];
            [viewLoadMore addSubview:self.btnLoadMore];
        }
    }
    return viewLoadMore;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (!self.isDataNull) {
        return 2;
    }
    else return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    if (!self.isDataNull) {
        if (section == 1) {
            if (self.arrData.count>0) {
                return self.arrData.count;
            }
            else{
                return self.arrData.count;
            }
        }
        else return 0;
    }
    else{
        if (self.arrData.count>0) {
            return self.arrData.count;
        }
        else{
            return self.arrData.count;
        }
    }
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
   
  //  [self StickerKeyboardHide];         //13MAR2015, 10:43AM

    if(scrollView.tag!=ScrollViewTag)
    {
        if (self.tblData.contentOffset.y>(self.tblData.contentSize.height - self.tblData.bounds.size.height + 35)) {
            NSLog(@"<<<<<<<=====>>>>>>> %f %f",self.tblData.contentOffset.y,(self.tblData.contentSize.height - self.tblData.bounds.size.height + 35));
            //load new data
            if (!self.isCallInitiated) {
                self.isCallInitiated = TRUE;
                self.pageCounter = 1;
                [self get_ConversationWithSelectedUser];
            }
        }
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary *dic = [self.arrData objectAtIndex: indexPath.row];
    
    /*
     public enum MessageType
     {
     Sound = 0,
     stickr = 1,
     Video = 2,
     Text = 3
     }
     */
    
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"1"]) {
        //it is sticker
        
        ConversaionWithStickerCell *cell = (ConversaionWithStickerCell *)[tableView dequeueReusableCellWithIdentifier:@"WithSticker"];
        cell.delegate = self;
        cell.imgPlayContainer.image = nil;
        cell.imgPlayContainer.imageURL = nil;
        [cell clearsContextBeforeDrawing];
        
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        cell.imgPlayContainer.image = nil;
        cell.imgPlayContainer.imageURL = nil;
        cell.imgPlayContainer.hidden = YES;
        
        [cell setControlsInCellWithDictionary:dic withUserId:self.strLoggedInUserId isEdit:(self.btnEditDone.tag == 2)];


        cell.imgPlayContainer.hidden = NO;
        
        if (self.btnEditDone.tag == 1) {
            cell.imgSelected.hidden = YES;
        }
        else{
            cell.imgSelected.hidden = NO;
        }
        return cell;
        
    }
    else if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"2"]){
        //it is video
        //show thumb
        ConversationWithImgCell *cell = (ConversationWithImgCell *)[tableView dequeueReusableCellWithIdentifier:@"WithImg"];
        cell.delegate = self;
        cell.imgImage.image = nil;
        cell.imgImage.imageURL = nil;
        
        [cell clearsContextBeforeDrawing];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        [cell setControlsInCellWithDictionary:dic withUserId:self.strLoggedInUserId isEdit:(self.btnEditDone.tag == 2)];
        
        [cell.btnFullScreen removeTarget:self action:@selector(showImageFrom:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnFullScreen removeTarget:self action:@selector(showVideoFrom:) forControlEvents:UIControlEventTouchUpInside];
        NSString *strImgPath = [NSString stringWithFormat:@"%@",[dic valueForKey:ImagePath]];
        if ([DataValidation checkNullString:strImgPath].length > 0) {
            [cell.btnFullScreen addTarget:self action:@selector(showVideoFrom:) forControlEvents:UIControlEventTouchUpInside];
        }
        cell.btnFullScreen.tag = indexPath.row;
        
        if ([[dic valueForKey:IS_PRIVATE] boolValue]) {
            [cell.btnFullScreen setImage:nil forState:UIControlStateNormal];
        }
        else{
            [cell.btnFullScreen setImage:[UIImage imageNamed:@"btn_video_play.png"] forState:UIControlStateNormal];
        }
        [cell.btnForward removeTarget:self action:@selector(btnForwardClicked:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnForward addTarget:self action:@selector(btnForwardClicked:) forControlEvents:UIControlEventTouchUpInside];
        cell.btnForward.tag = indexPath.row;
        
        [cell.btnLike removeTarget:self action:@selector(btnFavoriteClicked:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnLike addTarget:self action:@selector(btnFavoriteClicked:) forControlEvents:UIControlEventTouchUpInside];
        cell.btnLike.tag = indexPath.row;
        
        [cell.btnReportAbuse removeTarget:self action:@selector(btnReportAbuseClicked:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnReportAbuse addTarget:self action:@selector(btnReportAbuseClicked:) forControlEvents:UIControlEventTouchUpInside];
        cell.btnReportAbuse.tag = indexPath.row;
        
        [cell.btnPlay removeTarget:self action:@selector(btnPlayFileClicked:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnPlay addTarget:self action:@selector(btnPlayFileClicked:) forControlEvents:UIControlEventTouchUpInside];
        cell.btnPlay.tag = indexPath.row;
        
        [cell.btnInstagramShare removeTarget:self action:@selector(btnInstaShareClicked:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnInstagramShare addTarget:self action:@selector(btnInstaShareClicked:) forControlEvents:UIControlEventTouchUpInside];
        cell.btnInstagramShare.tag = indexPath.row;
        
        
        if (self.isAdmin) {
            cell.viewButtonContainer.hidden = YES;
            cell.imgPlay.frame = CGRectMake(cell.viewButtonContainer.frame.origin.x, cell.viewButtonContainer.frame.origin.y, cell.imgPlay.frame.size.width, cell.imgPlay.frame.size.height);
            cell.btnPlay.frame = cell.imgPlay.frame;
            cell.imgPlayAnimation.frame = cell.imgPlay.frame;
        }
        
        if (self.selectedPlayID == [[NSString stringWithFormat:@"%@",[dic valueForKey:MESSAGE_CHAT_ID]] intValue] && self.isPlaying) {
            //          NSLog(@"show Animation for index = %d",(int)indexPath.row);
            cell.imgPlayAnimation.hidden = NO;
            [cell.contentView bringSubviewToFront:cell.imgPlayAnimation];
            [self setImageViewInview:cell.imgPlayAnimation];
        }
        else{
            cell.imgPlayAnimation.hidden = YES;
        }
        
        if (self.btnEditDone.tag == 1) {
            cell.imgSelected.hidden = YES;
        }
        else{
            cell.imgSelected.hidden = NO;
        }
        
//        [cell bringSubviewToFront:cell.imgImage];
        
        return cell;

    }
    else if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"3"] || [[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"4"] || [[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"5"]) {
        ConversationTextBlabCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TextBlab"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
        [cell setUI:dic withUserId:self.strLoggedInUserId isEdit:(self.btnEditDone.tag == 2)];
        
        [cell.btnReportAbuse removeTarget:self action:@selector(btnReportAbuseClicked:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnReportAbuse addTarget:self action:@selector(btnReportAbuseClicked:) forControlEvents:UIControlEventTouchUpInside];
        cell.btnReportAbuse.tag = indexPath.row;
        
        if (self.btnEditDone.tag == 1) {
            cell.imgSelected.hidden = YES;
        }
        else{
            cell.imgSelected.hidden = NO;
        }
        return cell;
    }
    else{
        if ([DataValidation checkNullString:[dic valueForKey:ImagePath]].length > 0) {
            //it is image
            //      NSLog(@"it is image");

            ConversationWithImgCell *cell = (ConversationWithImgCell *)[tableView dequeueReusableCellWithIdentifier:@"WithImg"];
            cell.delegate = self;
            cell.imgImage.image = nil;
            cell.imgImage.imageURL = nil;
            
            [cell clearsContextBeforeDrawing];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            [cell setControlsInCellWithDictionary:dic withUserId:self.strLoggedInUserId isEdit:(self.btnEditDone.tag == 2)];
            [cell.btnFullScreen setImage:nil forState:UIControlStateNormal];

            [cell.btnFullScreen removeTarget:self action:@selector(showImageFrom:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnFullScreen removeTarget:self action:@selector(showVideoFrom:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnFullScreen addTarget:self action:@selector(showImageFrom:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnFullScreen.tag = indexPath.row;
            
            [cell.btnForward removeTarget:self action:@selector(btnForwardClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnForward addTarget:self action:@selector(btnForwardClicked:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnForward.tag = indexPath.row;
            
            [cell.btnLike removeTarget:self action:@selector(btnFavoriteClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnLike addTarget:self action:@selector(btnFavoriteClicked:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnLike.tag = indexPath.row;
            
            [cell.btnReportAbuse removeTarget:self action:@selector(btnReportAbuseClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnReportAbuse addTarget:self action:@selector(btnReportAbuseClicked:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnReportAbuse.tag = indexPath.row;
            
            [cell.btnPlay removeTarget:self action:@selector(btnPlayFileClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnPlay addTarget:self action:@selector(btnPlayFileClicked:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnPlay.tag = indexPath.row;
            
            [cell.btnInstagramShare removeTarget:self action:@selector(btnInstaShareClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnInstagramShare addTarget:self action:@selector(btnInstaShareClicked:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnInstagramShare.tag = indexPath.row;
            
            if (self.isAdmin) {
                cell.viewButtonContainer.hidden = YES;
                cell.imgPlay.frame = CGRectMake(cell.viewButtonContainer.frame.origin.x, cell.viewButtonContainer.frame.origin.y, cell.imgPlay.frame.size.width, cell.imgPlay.frame.size.height);
                cell.btnPlay.frame = cell.imgPlay.frame;
                cell.imgPlayAnimation.frame = cell.imgPlay.frame;
            }
            
            if (self.selectedPlayID == [[NSString stringWithFormat:@"%@",[dic valueForKey:MESSAGE_CHAT_ID]] intValue] && self.isPlaying) {
                //          NSLog(@"show Animation for index = %d",(int)indexPath.row);
                cell.imgPlayAnimation.hidden = NO;
                [cell.contentView bringSubviewToFront:cell.imgPlayAnimation];
                [self setImageViewInview:cell.imgPlayAnimation];
            }
            else{
                cell.imgPlayAnimation.hidden = YES;
            }
            
            if (self.btnEditDone.tag == 1) {
                cell.imgSelected.hidden = YES;
            }
            else{
                cell.imgSelected.hidden = NO;
            }
            
//            [cell bringSubviewToFront:cell.imgImage];
            
            return cell;
        }
        else{
            //      NSLog(@"it is not an Image");
           
            ConversationWithoutImgCell *cell = (ConversationWithoutImgCell *)[tableView dequeueReusableCellWithIdentifier:@"WithoutImg"];
            cell.delegate = self;
            cell.imgPlayContainer.image = nil;
            cell.imgPlayContainer.imageURL = nil;
            
            cell.contentView.backgroundColor = [UIColor clearColor];
            [cell setControlsInCellWithDictionary:dic withUserId:self.strLoggedInUserId isEdit:(self.btnEditDone.tag == 2)];

            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            [cell.btnForward removeTarget:self action:@selector(btnForwardClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnForward addTarget:self action:@selector(btnForwardClicked:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnForward.tag = indexPath.row;
            
            [cell.btnLike removeTarget:self action:@selector(btnFavoriteClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnLike addTarget:self action:@selector(btnFavoriteClicked:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnLike.tag = indexPath.row;
            
            [cell.btnReportAbuse removeTarget:self action:@selector(btnReportAbuseClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnReportAbuse addTarget:self action:@selector(btnReportAbuseClicked:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnReportAbuse.tag = indexPath.row;
            
            [cell.btnPlayContainer removeTarget:self action:@selector(btnPlayFileClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnPlayContainer addTarget:self action:@selector(btnPlayFileClicked:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnPlayContainer.tag = indexPath.row;
            
            if (self.isAdmin) {
                cell.viewButtonContainer.hidden = YES;
                cell.imgPlay.frame = CGRectMake(cell.viewButtonContainer.frame.origin.x, cell.viewButtonContainer.frame.origin.y, cell.imgPlay.frame.size.width, cell.imgPlay.frame.size.height);
                cell.btnPlayContainer.frame = cell.imgPlay.frame;
                cell.imgPlayAnimation.frame = cell.imgPlay.frame;
            }
            
            if (self.selectedPlayID == [[NSString stringWithFormat:@"%@",[dic valueForKey:MESSAGE_CHAT_ID]] intValue] && self.isPlaying) {
                cell.imgPlayAnimation.hidden = NO;
                [cell.contentView bringSubviewToFront:cell.imgPlayAnimation];
                [self setImageViewInview:cell.imgPlayAnimation];
            }
            else{
                cell.imgPlayAnimation.hidden = YES;
            }
            
            if (self.btnEditDone.tag == 1) {
                cell.imgSelected.hidden = YES;
            }
            else{
                cell.imgSelected.hidden = NO;
            }
            return cell;
        }
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    [self StickerKeyboardHide];         //13MAR2015, 10:43AM
    [self btnKeyBoardCancel_Clicked:nil];

    if (self.btnEditDone.tag == 2) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indexPath.row]];
        if ([[dic valueForKey:IS_SELECTED] boolValue]) {
            
            [dic setValue:@"0" forKey:IS_SELECTED];
            
        }
        else{
            [dic setValue:@"1" forKey:IS_SELECTED];
        }
        [self.arrData replaceObjectAtIndex:indexPath.row withObject:dic];
        
        NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indexPath.row inSection:indexPath.section]];
        [self.tblData beginUpdates];
        [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
        [self.tblData endUpdates];
    }
}
- (CGRect)getHeight:(NSString *)strText{
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    //    CGSize size = CGSizeMake(self.lblTime.frame.size.width+50, self.lbl.frame.size.height);
    CGRect size =  [strText boundingRectWithSize:CGSizeMake(WIDTH_DESC, 20000)
                                         options:NSStringDrawingUsesLineFragmentOrigin
                                      attributes:@{NSFontAttributeName:[UIFont fontWithName:Font_Montserrat_Regular size:13],NSParagraphStyleAttributeName:paragraphStyle}
                                         context:nil];
    
    return size;
}
- (CGRect)getHeightTextBlab:(NSString *)strText{
    NSData *decodedData = [[NSData alloc] initWithBase64EncodedString:strText options:0];
    NSString *decodedString = [[NSString alloc] initWithData:decodedData encoding:NSUTF8StringEncoding];
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    //    CGSize size = CGSizeMake(self.lblTime.frame.size.width+50, self.lbl.frame.size.height);
    CGRect size =  [decodedString boundingRectWithSize:CGSizeMake(WIDTH_DESC_TEXTBLAB, 20000)
                                         options:NSStringDrawingUsesLineFragmentOrigin
                                      attributes:@{NSFontAttributeName:[UIFont fontWithName:Font_Montserrat_Regular size:15],NSParagraphStyleAttributeName:paragraphStyle}
                                         context:nil];
    
    
    return size;
}
- (CGRect)getHeightCaption:(NSString *)strText{
    
    
    //    CGSize size = CGSizeMake(self.lblTime.frame.size.width+50, self.lbl.frame.size.height);
    CGRect size =  [strText boundingRectWithSize:CGSizeMake(self.lblCaption.frame.size.width, 20000)
                                         options:NSStringDrawingUsesLineFragmentOrigin
                                      attributes:@{NSFontAttributeName:self.lblCaption.font}
                                         context:nil];
    
    return size;
}
-(void)hideLongPressEnabledBtns{
//    self.btnDelete.hidden = YES;
//    self.btnShare.hidden = YES;
    [self.arrData setValue:@"0" forKey:IS_SELECTED];
    [self.tblData reloadData];
}
-(IBAction)handleLongPress:(UILongPressGestureRecognizer *)gestureRecognizer{
    
    [self StickerKeyboardHide];         //13MAR2015, 10:43AM
    
    if (!self.isAdmin) {
        CGPoint p = [gestureRecognizer locationInView:self.tblData];
        
        NSIndexPath *indexPath = [self.tblData indexPathForRowAtPoint:p];
        if (indexPath == nil)
            NSLog(@"long press on table view but not on a row");
        else
        {
            //   NSLog(@"%ld",gestureRecognizer.state);
            if (gestureRecognizer.state == UIGestureRecognizerStateCancelled) {
                NSLog(@"UIGestureRecognizerStateCancelled");
                if ([self.btnShare isHidden]) {
//                    self.btnDelete.hidden = NO;
//                    self.btnShare.hidden = NO;
//                    
                    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indexPath.row]];
                    if ([[dic valueForKey:IS_SELECTED] boolValue]) {
                        
                        [dic setValue:@"0" forKey:IS_SELECTED];
                        
                    }
                    else{
                        [dic setValue:@"1" forKey:IS_SELECTED];
                    }
                    [self.arrData replaceObjectAtIndex:indexPath.row withObject:dic];
                    
                    NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indexPath.row inSection:indexPath.section]];
                    [self.tblData beginUpdates];
                    [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
                    [self.tblData endUpdates];
                    
                }
                else{
                    [self hideLongPressEnabledBtns];
/*                    self.btnDelete.hidden = YES;
                    self.btnShare.hidden = YES;
                    [self.arrData setValue:@"0" forKey:IS_SELECTED];
                    [self.tblData reloadData];
*/
                }
            }
            else if (gestureRecognizer.state == UIGestureRecognizerStateEnded) {
                NSLog(@"UIGestureRecognizerStateEnded");
                //Do Whatever You want on End of Gesture
                if ([self.btnShare isHidden]) {
//                    self.btnDelete.hidden = NO;
//                    self.btnShare.hidden = NO;
                    
                    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indexPath.row]];
                    if ([[dic valueForKey:IS_SELECTED] boolValue]) {
                        [dic setValue:@"0" forKey:IS_SELECTED];
                    }
                    else{
                        [dic setValue:@"1" forKey:IS_SELECTED];
                    }
                    [self.arrData replaceObjectAtIndex:indexPath.row withObject:dic];
                    
                    NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indexPath.row inSection:indexPath.section]];
                    [self.tblData beginUpdates];
                    [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
                    [self.tblData endUpdates];
                }
                else{
                    [self hideLongPressEnabledBtns];
/*
                    self.btnDelete.hidden = YES;
                    self.btnShare.hidden = YES;
                    [self.arrData setValue:@"0" forKey:IS_SELECTED];
                    [self.tblData reloadData];
*/
                }
            }
            else if (gestureRecognizer.state == UIGestureRecognizerStateBegan){
                
                NSLog(@"UIGestureRecognizerStateBegan.");
                NSLog(@"long press on table view at row %d",(int) indexPath.row);
                
                // Update ToDoStatus
                //Do Whatever You want on Began of Gesture
            }
        }
    }
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch{
    if ([touch.view isKindOfClass:[UIControl class]]) {
        return NO;
    }
    else{
        return YES;
    }
}
-(void)btnBlabCreatorName_Clicked:(NSDictionary *)dic{
    if (![[NSString stringWithFormat:@"%@",[dic valueForKey:@"SenderID"]] isEqualToString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]]]) {
        [self btnKeyBoardCancel_Clicked:nil];
        NSLog(@"dic %@",dic);
        if (self.objUserProfileVC == nil) {
            for (UIView *view in [self.view subviews]) {
                if ([view isKindOfClass:[UIButton class]]) {
                    UIButton *btn = (UIButton *)view;
                    btn.enabled = NO;
                }
                else if ([view isKindOfClass:[UITableView class]]){
                    UITableView *tbl = (UITableView *)view;
                    [tbl setUserInteractionEnabled:NO];
                }
            }
            self.objUserProfileVC = [self.storyboard instantiateViewControllerWithIdentifier:@"UserProfileVC"];
            self.objUserProfileVC.delegate = self;
            CGRect frame = self.view.frame;
            frame.origin.y = [UIScreen mainScreen].bounds.size.height;
            self.objUserProfileVC.view.frame = frame;
            self.objUserProfileVC.view.backgroundColor = [UIColor clearColor];
            [self.objUserProfileVC willMoveToParentViewController:self];
            [self.view addSubview:self.objUserProfileVC.view];
            [self addChildViewController:self.objUserProfileVC];
            [self.objUserProfileVC didMoveToParentViewController:self];
            self.objUserProfileVC.dicSelected = dic;
            self.objUserProfileVC.strUserID = [NSString stringWithFormat:@"%@",[dic valueForKey:@"SenderID"]];
            self.objUserProfileVC.selType = 2;  //  2 means display user data
            [self.objUserProfileVC updateUserInfo];
            [Validation animateYpoint:0 viewToAnimate:self.objUserProfileVC.view];
        }
    }
    
    
}
-(void)btnBlabCreatorImage_Clicked:(NSDictionary *)dic{
    if (![[NSString stringWithFormat:@"%@",[dic valueForKey:@"SenderID"]] isEqualToString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]]]) {
        [self btnKeyBoardCancel_Clicked:nil];
        NSLog(@"dic %@",dic);
        if (self.objUserProfileVC == nil) {
            for (UIView *view in [self.view subviews]) {
                if ([view isKindOfClass:[UIButton class]]) {
                    UIButton *btn = (UIButton *)view;
                    btn.enabled = NO;
                }
                else if ([view isKindOfClass:[UITableView class]]){
                    UITableView *tbl = (UITableView *)view;
                    [tbl setUserInteractionEnabled:NO];
                }
            }
            self.objUserProfileVC = [self.storyboard instantiateViewControllerWithIdentifier:@"UserProfileVC"];
            self.objUserProfileVC.delegate = self;
            CGRect frame = self.view.frame;
            frame.origin.y = [UIScreen mainScreen].bounds.size.height;
            self.objUserProfileVC.view.frame = frame;
            self.objUserProfileVC.view.backgroundColor = [UIColor clearColor];
            [self.objUserProfileVC willMoveToParentViewController:self];
            [self.view addSubview:self.objUserProfileVC.view];
            [self addChildViewController:self.objUserProfileVC];
            [self.objUserProfileVC didMoveToParentViewController:self];
            self.objUserProfileVC.dicSelected = dic;
            self.objUserProfileVC.strUserID = [NSString stringWithFormat:@"%@",[dic valueForKey:@"SenderID"]];
            self.objUserProfileVC.selType = 1;  //  1 means display user big image
            [self.objUserProfileVC updateUserInfo];
            [Validation animateYpoint:0 viewToAnimate:self.objUserProfileVC.view];
        }
    }
    
}
-(void)btnAboveText_Clicked:(NSDictionary *)dic{
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"4"]) {
        [self btnKeyBoardCancel_Clicked:nil];
        NSLog(@"dic %@",dic);
        if (self.objUserProfileVC == nil) {
            for (UIView *view in [self.view subviews]) {
                if ([view isKindOfClass:[UIButton class]]) {
                    UIButton *btn = (UIButton *)view;
                    btn.enabled = NO;
                }
                else if ([view isKindOfClass:[UITableView class]]){
                    UITableView *tbl = (UITableView *)view;
                    [tbl setUserInteractionEnabled:NO];
                }
            }
            self.objUserProfileVC = [self.storyboard instantiateViewControllerWithIdentifier:@"UserProfileVC"];
            self.objUserProfileVC.delegate = self;
            CGRect frame = self.view.frame;
            frame.origin.y = [UIScreen mainScreen].bounds.size.height;
            self.objUserProfileVC.view.frame = frame;
            self.objUserProfileVC.view.backgroundColor = [UIColor clearColor];
            [self.objUserProfileVC willMoveToParentViewController:self];
            [self.view addSubview:self.objUserProfileVC.view];
            [self addChildViewController:self.objUserProfileVC];
            [self.objUserProfileVC didMoveToParentViewController:self];
            self.objUserProfileVC.dicSelected = dic;
            self.objUserProfileVC.strUserID = [NSString stringWithFormat:@"%@",[dic valueForKey:@"message"]];
            self.objUserProfileVC.selType = 2;  //  2 means display user data
            [self.objUserProfileVC updateUserInfo];
            [Validation animateYpoint:0 viewToAnimate:self.objUserProfileVC.view];
        }
    }
    else if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"5"]) {
        appDelegate.dic_APNS = [NSMutableDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dic valueForKey:@"message"]],@"ConversationID", nil];
        
        if (appDelegate.arrAPNS == nil) {
            appDelegate.arrAPNS = [[NSMutableArray alloc] init];
        }
        
        NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
        [appDelegate.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
        
        [appDelegate.arrAPNS addObject:appDelegate.dic_APNS];
        
        appDelegate.validation.apnsPopUp.btnPlay.tag = (int)interval;
        [appDelegate showChannelDetail:nil];
    }
}
-(void)updateUserInfoFromPopup:(NSDictionary *)dic updatedInfo:(NSMutableDictionary *)updatedInfo{
/*    if ([self.arrData containsObject:dic]) {
        NSLog(@"having object %d",(int)[self.arrData indexOfObject:dic]);
        NSMutableDictionary *dicToChange = [NSMutableDictionary dictionaryWithDictionary:dic];
        [dicToChange setObject:[updatedInfo valueForKey:IS_USER_BLOCKED] forKey:IS_USER_BLOCKED];
        [dicToChange setObject:[updatedInfo valueForKey:IS_FRIEND] forKey:IS_FRIEND];
        [dicToChange setObject:[updatedInfo valueForKey:IS_FRND_REQ_SENT] forKey:IS_FRND_REQ_SENT];
        [dicToChange setObject:[updatedInfo valueForKey:IS_Follow] forKey:IS_Follow];
        [self.arrData replaceObjectAtIndex:[self.arrData indexOfObject:dic] withObject:dicToChange];
        
        [self.tblData beginUpdates];
        [self.tblData reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:[self.arrData indexOfObject:dic] inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
        [self.tblData endUpdates];
        //        NSMutableDictionary *dicUpdate = [NSMutableDictionary dictionaryWithDictionary:dic];
        //        [dicUpdate setValue:<#(id)#> forKey:<#(NSString *)#>]
    }
    else{
        NSLog(@"not having object");
    }
 */
}
-(void)btnAddFriendFromPopup_Clicked:(NSDictionary *)dicOld{
    if ([self.arrData containsObject:dicOld]) {
        NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:[self.arrData indexOfObject:dicOld]]];
        NSString *strRequestId = [NSString stringWithFormat:@"%@",[dicData valueForKey:USER_ID]];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
                             nil];
        
        RecrodingFriendRequestVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:@"RecrodingFriendRequestVC"];
        obj.delegateFriendReq = self;
        obj.indexSelected = (int)[self.arrData indexOfObject:dicOld];
        obj.dicToSendFriendRequest = dic;
        [self.navigationController pushViewController:obj animated:YES];
    }
}
-(void)updateUserData:(int)indSel{
    NSLog(@"indSel %d",indSel);
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indSel]];
    
    [dicData setValue:@"1" forKey:IS_FRND_REQ_SENT];
    [self.arrData replaceObjectAtIndex:indSel withObject:dicData];
    if (self.objUserProfileVC != nil) {
        [self.objUserProfileVC.dicUserDetail setObject:@"1" forKey:IS_FRND_REQ_SENT];
        [self.objUserProfileVC LoadViewSetting];
    }
//    
//    NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indSel inSection:0]];
//    [self.tblData beginUpdates];
//    [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
//    [self.tblData endUpdates];
}
-(void)hideUserProfileVC{
    for (UIView *view in [self.view subviews]) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *btn = (UIButton *)view;
            btn.enabled = YES;
        }
        else if ([view isKindOfClass:[UITableView class]]){
            UITableView *tbl = (UITableView *)view;
            [tbl setUserInteractionEnabled:YES];
        }
    }

    self.objUserProfileVC = nil;
}
#pragma mark
#pragma mark web service method

- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    self.lbl_NoDataAvailable.hidden = TRUE;
    
    if (self.activity != nil) {
        [self.activity stopAnimating];
        [self.activity removeFromSuperview];
        self.activity = nil;
    }
    
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            if (self.pageCounter==1) {
                                [self.arrData removeAllObjects];
                            }
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.isDataNull = NO;
                            NSLog(@"%d",(int)arr.count);
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            
                            for (int i=0; i<(int)arr.count; i++) {
                                NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arr objectAtIndex:i]];
                                [dic setValue:@"0" forKey:IS_SELECTED];
                                [arr replaceObjectAtIndex:i withObject:dic];
                            }
                            
                            if (self.arrData.count>0) {
                                [arr addObjectsFromArray:self.arrData];
                                [self.arrData removeAllObjects];
                            }
                            if (arr.count>0) {
                                [self.arrData addObjectsFromArray:arr];
                                [self.tblData setScrollEnabled:NO];
                                
                                [self.tblData reloadData];
                                
                                if (self.pageCounter > 1) {
                                    [self stayAtScrollPosition];
                                }
                            }
                            
                            arr = nil;
                        }
                        response = nil;
                        self.isCallInitiated = FALSE;
                    }
                    else if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]){
                        self.isDataNull = YES;
                        [self.tblData reloadData];
                        if (self.arrData.count == 0) {
                            self.lbl_NoDataAvailable.hidden = FALSE;
                            [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                        }
                    }
                }
                
                if (self.arrData.count == 0 && self.pageCounter == 1) {
                    self.lbl_NoDataAvailable.hidden = FALSE;
                    [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                }
                [HUD hide:YES];
                self.tblData.scrollEnabled = YES;
                if (self.pageCounter == 1) {
                    [self scrollToBottom];
                }
            }
            else if (tag == 2){
                //favorite response
                
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        [HUD hide:YES];
                    }
                }
            }
            else if (tag == 3){
                //not used by any service
            }
       /*     else if (tag == 4){
                //delete records
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        NSLog(@"%@",response);
                    }
                }
            }*/
            else if (tag == 5){
                //share records
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        NSLog(@"%@",response);
                        
                         [self shareWithShareURL:[NSDictionary dictionaryWithDictionary:(NSDictionary *)response]];
                    }
                }
            }
            else if (tag == 6){
                //keep request response
                NSLog(@"keep request response  --> dicResponse = %@",dicResponse);
            }
            else if (tag == 7){
                //private message deleted
                NSLog(@"private message deleted --> dicResponse = %@",dicResponse);
            }
            
            else if(tag==8){
//                NSLog(@"Sticker Get --> dicResponse = %@",dicResponse);
//                
//                
//                NSLog(@"Status:%ld",(long)[[dicResponse valueForKey:STATUS]integerValue]);
                
                
                //bhavik 24-Feb-2015
                 if ([[dicResponse valueForKey:STATUS] intValue] ==1)
                 {
                     _arrCategory = [dicResponse valueForKey:RESPONSE];
                     
                     _arrSubCategory = [[dicResponse valueForKey:RESPONSE]valueForKey:@"StickerDetail"];
                     
                     UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
                     UIScrollView *scrollview = (UIScrollView*)[stickiesView viewWithTag:ScrollViewTag];
                     
                     scrollview.contentSize = CGSizeMake((scrollview.frame.size.width*[_arrCategory count]), _subcatCollectionView.frame.size.height);
                     
                     [_catCollectionView reloadData];
                     [_catCollectionView performBatchUpdates:^{
                         [_catCollectionView reloadData];
                     } completion:^(BOOL finished) {
                         [MBProgressHUD hideHUDForView:stickiesView animated:YES];
                         [_subcatCollectionView reloadData];
                     }];
                     
//                     [self createCategory];
                 }
                self.tblData.userInteractionEnabled = YES;
            }
            else if (tag == 9){
                //send notification
                
                /*Printing description of dicResponse:
                 {
                 Response =     (
                 {
                 CreateDate = "2015-02-05T02:58:35.183";
                 ID = 181225;
                 ImagePath = "http://upload.wwhhaazzuupp.com//StickerImages/SHUAEGUHR2926674_1_1.png";
                 Name = "<null>";
                 ReceiverID = 20191;
                 SenderID = 20190;
                 message = 4;
                 }
                 );
                 Status = 1;
                 UserStatus =     {
                 IsActive = 1;
                 IsDelete = 0;
                 Msg = success;
                 status = 1;
                 };
                 }
                 */
                
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        NSLog(@"%@",[response class]);
                        NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData lastObject]];
                        [dic setValue:[NSString stringWithFormat:@"%@",[[arr lastObject] valueForKey:@"message"]] forKey:@"message"];
                        [dic setValue:[NSString stringWithFormat:@"%@",[[arr lastObject] valueForKey:MESSAGE_CHAT_ID]] forKey:MESSAGE_CHAT_ID];
                        [dic setValue:@"1s" forKey:@"strDate"];
                        
                        [self.arrData replaceObjectAtIndex:(self.arrData.count-1) withObject:dic];
                        
                        if (textView.text.length!=0) {
                            textView.text = @"";
                        }
                        dic = nil;
                        [self.tblData reloadData];
                    }
                    else{
                        if ([[dicResponse objectForKey:RESPONSE] isKindOfClass:[NSArray class]]) {
                            
                            //[Validation showToastMessage:[[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] displayDuration:ERROR_MSG_DURATION];
                            HUD.mode = MBProgressHUDModeText;
                            HUD.delegate = self;
                            HUD.detailsLabelFont = [UIFont boldSystemFontOfSize:16];
                            HUD.detailsLabelText = [[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] ;
//                                [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:4];
                        }
                        else{
                            [HUD hide:YES];
                            
                        }
                    }
                }
                [HUD hide:YES];
                NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
            }
            else if (tag == 10){
                NSLog(@"repsonse for loop count = %@",dicResponse);
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    if ([dicResponse valueForKey:STATUS] != 0) {
                        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.currentlyPlaingIndex]];
                        [dic setValue:[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:RESPONSE] valueForKey:@"BlabViewCount"]] forKey:@"BlabViewCount"];
                        [self.arrData replaceObjectAtIndex:self.currentlyPlaingIndex withObject:dic];
                        dic = nil;
                        
                        int section = 1;
                        
                        if (self.isDataNull) {
                            section = 0;
                        }
                        NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:self.currentlyPlaingIndex inSection:section]];
                        [self.tblData beginUpdates];
                        [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
                        [self.tblData endUpdates];
                        
                    }
                }
            }
            else if (tag == 11){
                NSLog(@"repsonse for loop count = %@",dicResponse);
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:[[[dicResponse objectForKey:RESPONSE] objectAtIndex:0] objectForKey:@"FilePath"],VideoPath, nil];
                        [self performSelectorInBackground:@selector(loadCameraRollAssetToInstagram:) withObject:dic];
                    }
                    else{
                        [HUD hide:YES];
                        [Validation showToastMessage:@"Can not share. Audio file must be longer than 3 seconds." displayDuration:INFO_MSG_DURATION];
                    }
                }
                else{
                    [HUD hide:YES];
                    [Validation showToastMessage:@"Can not share. Audio file must be longer than 3 seconds." displayDuration:INFO_MSG_DURATION];
                }
            }
            else if (tag == 12){
                NSLog(@"repsonse for loop count = %@",dicResponse);
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    if ([dicResponse objectForKey:RESPONSE] != nil) {
                        dicSelForSingleVideoImageShare = [NSDictionary dictionaryWithObjectsAndKeys:[[[dicResponse objectForKey:RESPONSE] objectAtIndex:0] objectForKey:@"FilePath"],VideoPath, nil];
                        [self performSelectorInBackground:@selector(shareVideoOrImageTOFB) withObject:nil];
                    }
                    else{
                        [HUD hide:YES];
                        [Validation showToastMessage:@"Can not share. Audio file must be longer than 3 seconds." displayDuration:INFO_MSG_DURATION];
                    }
                }
                else{
                    [HUD hide:YES];
                    [Validation showToastMessage:@"Can not share. Audio file must be longer than 3 seconds." displayDuration:INFO_MSG_DURATION];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
}


- (void)requestFinished:(ASIHTTPRequest *)request{
    NSError *error = nil;
    
    NSLog(@"notification Response");
    
    NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
                                                                 options:0
                                                                   error:&error];
    
    self.lbl_NoDataAvailable.hidden = TRUE;
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            
            if (request.tag == 4){
                //delete records
                /*                if ([dicResponse objectForKey:RESPONSE] != nil) {
                 
                 if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                 id response = [dicResponse objectForKey:RESPONSE];
                 NSLog(@"%@",response);
                 }
                 }
                 */
                
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        NSLog(@"%@",response);
                        [self performSelector:@selector(removeRowsFromArray) withObject:nil];
                    }
                }
                [HUD hide:YES];
            }
            else if (request.tag == 7){
                [self.tblData reloadData];
            }
        }
    }
    else{
        [HUD hide:YES];
    }
    
}

- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}

#pragma mark - Create Category

-(void)createCategory
{
    [self createStickerView];
}

#pragma mark - Create StickerView FirstTime

-(void)createStickerView
{
  UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
    
   if(stickiesView==nil)
   {
       
       isStickiesKeyboardOpen = YES;
       
       stickiesView = [[UIView alloc]initWithFrame:CGRectMake(0,[UIScreen mainScreen].bounds.size.height-KeyboardHeight-BottomViewHeight, [UIScreen mainScreen].bounds.size.width, KeyboardHeight)];
       stickiesView.hidden = YES;
       stickiesView.tag = StickerViewTag;
       stickiesView.backgroundColor = [UIColor clearColor];
       [self.view addSubview:stickiesView];
       
       selectedIndexPath = 0;
       
       
       UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc] init];
/*       CGRect frame = [self getStatusBarFrameViewRect:self.view];
       if (frame.size.height>20) {
           _catCollectionView=[[UICollectionView alloc] initWithFrame:CGRectMake(0,-20, stickiesView.frame.size.width, CategoryViewHeight) collectionViewLayout:layout];
       }
       else{
           _catCollectionView=[[UICollectionView alloc] initWithFrame:CGRectMake(0,0, stickiesView.frame.size.width, CategoryViewHeight) collectionViewLayout:layout];
       }
*/
       _catCollectionView=[[UICollectionView alloc] initWithFrame:CGRectMake(0,0, stickiesView.frame.size.width, CategoryViewHeight) collectionViewLayout:layout];
       [layout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
       [_catCollectionView setShowsVerticalScrollIndicator:NO];
       [_catCollectionView setShowsHorizontalScrollIndicator:NO];
       [_catCollectionView setDataSource:self];
       [_catCollectionView setDelegate:self];
       [_catCollectionView registerClass:[StickerCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
       [_catCollectionView setBackgroundColor:UIColorFromRGB(0Xfafafa)];
       [stickiesView addSubview:_catCollectionView];
       
       UILabel *lineView = [[UILabel alloc]initWithFrame:CGRectMake(0, _catCollectionView.frame.origin.y+_catCollectionView.frame.size.height, [UIScreen mainScreen].bounds.size.width, 1.0)];
       lineView.backgroundColor = UIColorFromRGB(0Xbebebe);
       [stickiesView addSubview:lineView];
       
       [_catCollectionView performBatchUpdates:^{
           [_catCollectionView reloadData];
       } completion:^(BOOL finished) {
           
      UICollectionViewFlowLayout *layout1=[[UICollectionViewFlowLayout alloc] init];
           
     //[layout1 setItemSize:CGSizeMake(300, 490)];

        UIScrollView *scrollview = [[UIScrollView alloc]initWithFrame:CGRectMake(0, lineView.frame.origin.y + lineView.frame.size.height, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-BottomViewHeight-(lineView.frame.origin.y + lineView.frame.size.height)-stickiesView.frame.origin.y)];
       scrollview.delegate = self;
       scrollview.tag = ScrollViewTag;
       scrollview.scrollEnabled = NO;
           
        scrollview.backgroundColor = [UIColor clearColor];
       
       [scrollview setShowsHorizontalScrollIndicator:NO];
       [scrollview setShowsVerticalScrollIndicator:NO];
           
           
           
           //  _subcatCollectionView=[[UICollectionView alloc] initWithFrame:CGRectMake(0,lineView.frame.origin.y + lineView.frame.size.height, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-50-(lineView.frame.origin.y + lineView.frame.size.height)) collectionViewLayout:layout1];
           
           _subcatCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, scrollview.frame.size.width, scrollview.frame.size.height) collectionViewLayout:layout1];
           
           [layout1 setMinimumInteritemSpacing:0.0f];
           [layout1 setMinimumLineSpacing:0.0f];
           
          // [layout1 setScrollDirection:UICollectionViewScrollDirectionHorizontal];
            //_subcatCollectionView.pagingEnabled = YES;
           
           [_subcatCollectionView setShowsVerticalScrollIndicator:NO];
           [_subcatCollectionView setShowsHorizontalScrollIndicator:NO];
           [_subcatCollectionView setDataSource:self];
           [_subcatCollectionView setDelegate:self];
           [_subcatCollectionView registerClass:[StickerCell class] forCellWithReuseIdentifier:@"cellIdentifier1"];
           [_subcatCollectionView setBackgroundColor:[UIColor clearColor]];
           
           [scrollview addSubview:_subcatCollectionView];
           [stickiesView addSubview:scrollview];
           
//          scrollview.contentSize = CGSizeMake((_subcatCollectionView.frame.size.width*[_arrCategory count]), _subcatCollectionView.frame.size.height);
           
           [MBProgressHUD showHUDAddedTo:stickiesView animated:YES];
       }];
   }
    
  //  self.tblData.backgroundColor = [UIColor greenColor];
    
//    [self.btnReply bringSubviewToFront:self.view];
//    [self.btnEmoji bringSubviewToFront:self.view];

    if(isStickiesKeyboardOpen)
    {
        /*To unhide*/
        UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
        [self.view sendSubviewToBack:stickiesView];
        stickiesView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height-50, [UIScreen mainScreen].bounds.size.width,0.0);
        isStickiesKeyboardOpen = NO;
        
        [UIView animateWithDuration:0.25 animations:^{
        stickiesView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height-KeyboardHeight-BottomViewHeight, [UIScreen mainScreen].bounds.size.width, KeyboardHeight);
//            stickiesView.frame = CGRectMake(0,, [UIScreen mainScreen].bounds.size.width, KeyboardHeight);
            stickiesView.hidden = NO;
            [self.tblData setFrame:CGRectMake(self.tblData.frame.origin.x,self.tblData.frame.origin.y, self.tblData.frame.size.width,stickiesView.frame.origin.y-self.tblData.frame.origin.y)];
            [self scrollToBottom];
        } completion:^(BOOL finished) {
        }];
    }
    else
    {
        /*To hide*/
        UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
        [UIView animateWithDuration:0.25 animations:^{
            stickiesView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, KeyboardHeight);
            isStickiesKeyboardOpen = YES;
            [self.tblData setFrame:CGRectMake(self.tblData.frame.origin.x,self.tblData.frame.origin.y, self.tblData.frame.size.width,[UIScreen mainScreen].bounds.size.height-self.tblData.frame.origin.y)];
        } completion:^(BOOL finished) {
        }];
    }
}

#pragma mark - CollectionView DataSource and Delegate Method

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if(collectionView == _catCollectionView)
    {
        return _arrCategory.count;
    }
    else
    {
      return [[_arrSubCategory objectAtIndex:selectedIndexPath]count];
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    StickerCell *cell;
    StickerCell *cell1;
    
    if(collectionView == _catCollectionView)
    {
        cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
        
        if(selectedIndexPath == indexPath.row)
        {
            
           cell.backgroundColor = UIColorFromRGB(0x00c2d9);
        }
        else
        {
            //bhavik 24-Feb-2015
            cell.backgroundColor = [UIColor clearColor];
        }
        
        cell.imgSticker.imageURL = nil;
        cell.imgSticker.image = nil;
        
       cell.imgSticker.frame = CGRectMake(cell.imgSticker.frame.origin.x, 7, 50, 30);
        cell.imgSticker.imageURL = [NSURL URLWithString:[[_arrCategory objectAtIndex:indexPath.row] valueForKey:@"LogoPath"]];
        
        return cell;
    }
    else
    {
        cell1 = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier1" forIndexPath:indexPath];
        
//      bhavik 10-Mar-2015 /*
        cell1.backgroundColor = [UIColor clearColor];
//      */
    
        cell1.imgSticker.imageURL = nil;
        cell1.imgSticker.image = nil;
        
//      bhavik 10-Mar-2015 /*
        cell1.imgSticker.frame = CGRectMake(cell1.imgSticker.frame.origin.x, cell1.imgSticker.frame.origin.y, 70, 64);
//      */
        
        NSString *strSubCategory = [[[_arrSubCategory objectAtIndex:selectedIndexPath]objectAtIndex:indexPath.row]valueForKey:@"StickerPath"];
        cell1.imgSticker.imageURL = [NSURL URLWithString:strSubCategory];
        
        return  cell1;
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
//    if (self.isGrid) {
//        int width = (self.view.frame.size.width/3)-1;
//        return CGSizeMake(width,width);
//    }
//    else{
//        float height =  self.view.frame.size.width;        //this is of image
//        height += 50;                                       // this is for user name
//        height += 40;                                      //this is for description
//        return CGSizeMake(self.view.frame.size.width, height);
//    }
    
    if(collectionView == _catCollectionView)
    {
        return CGSizeMake(50, 44);

    }
    else
    {
//      bhavik 10-Mar-2015 /*
//        return CGSizeMake(50, 44);
        return CGSizeMake(70,64);
//      */
    }
}


//- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
//{
//    if (collectionView == _subcatCollectionView) {
//        return 20;
//    }
//    else
//    {
//        return 0;
//    }
//}

//- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
//{
//    return 0;
//}
//
//- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
//{
//    return UIEdgeInsetsMake(0, 0, 0, 0);
//    
//}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if(collectionView == _catCollectionView)
    {
        if(selectedIndexPath !=indexPath.row)
        {
            selectedIndexPath = indexPath.row;
            
            UIView *stickiesView = [self.view viewWithTag:StickerViewTag];
            
            UIScrollView *scrollView = (UIScrollView*)[stickiesView viewWithTag:ScrollViewTag];
            
            [_subcatCollectionView setFrame:CGRectMake(scrollView.frame.size.width*selectedIndexPath, 0, _subcatCollectionView.frame.size.width, _subcatCollectionView.frame.size.height)];
            [scrollView setContentOffset:CGPointMake(scrollView.frame.size.width*selectedIndexPath, 0.0)];
            
            [_catCollectionView reloadData];
            
            [_catCollectionView performBatchUpdates:^{
                [_catCollectionView reloadData];
            } completion:^(BOOL finished) {
                [_subcatCollectionView reloadData];
            }];
        }
    }
    else
    {
        NSLog(@"Selected IndexdPath:%ld",(long)indexPath.row);
        [self sendSelectedStickerAtIndex:(int)indexPath.row];

        StickerCell *cell = (StickerCell*)[collectionView cellForItemAtIndexPath:indexPath];
        
        [UIView animateWithDuration:0.2 animations:^{
            cell.imgSticker.transform = CGAffineTransformMakeScale(1.5, 1.5);
        }
        completion:^(BOOL finished){
                             [UIView animateWithDuration:0.2 animations:^{
                                cell.imgSticker.transform = CGAffineTransformMakeScale(1, 1);
                             }];
            [self clickOnSticker:nil];
                         }];
    }
}



#pragma mark - Scrollview DidEnd

//- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
//{
//    NSLog(@"Scrolling End");
//    
//    if(scrollView.tag == ScrollViewTag)
//    {
//        NSInteger currentIndex = scrollView.contentOffset.x / scrollView.frame.size.width;
//        
//        if(selectedIndexPath !=currentIndex)
//        {
//            [_subcatCollectionView setFrame:CGRectMake(scrollView.frame.size.width*currentIndex, 0, _subcatCollectionView.frame.size.width, _subcatCollectionView.frame.size.height)];
//            [scrollView setContentOffset:CGPointMake(scrollView.frame.size.width*currentIndex, 0.0)];
//            
//            selectedIndexPath = currentIndex;
//            [_catCollectionView reloadData];
//            
//            [_catCollectionView performBatchUpdates:^{
//                [_catCollectionView reloadData];
//            } completion:^(BOOL finished) {
//                [_subcatCollectionView reloadData];
//            }];
//        }
//    }
//}



- (void)setReportAsPosted{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.selectedIndex]];
    [dic setValue:@"1" forKey:IS_REPORTED_FOR_ABUSE];
    [self.arrData replaceObjectAtIndex:self.selectedIndex withObject:dic];
    dic = nil;
    
    int section = 1;
    if (self.isDataNull) {
        section = 0;
    }
    
    NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:self.selectedIndex inSection:section]];
    [self.tblData beginUpdates];
    [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
    [self.tblData endUpdates];
    
}

-(void)scrollToBottom{
    
    [self.tblData scrollRectToVisible:CGRectMake(0, self.tblData.contentSize.height - self.tblData.bounds.size.height, self.tblData.bounds.size.width, self.tblData.bounds.size.height) animated:NO];
}

-(void)stayAtScrollPosition{

    int section = 1;
    if (self.isDataNull) {
        section = 0;
    }
   
    [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.arrData.count-(((self.pageCounter-1)*PageSize)) inSection:section] atScrollPosition:UITableViewScrollPositionTop animated:NO];
}

-(void)moveUpAtScrollPosition{
    int section = 1;
    if (self.isDataNull) {
        section = 0;
    }

    [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.arrData.count-(((self.pageCounter-1)*PageSize)-2) inSection:section] atScrollPosition:UITableViewScrollPositionBottom animated:NO];
}

#pragma mark    UIActionsheet Delegate

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"button index = %d",(int)buttonIndex);
    
    if (buttonIndex == actionSheet.cancelButtonIndex) {
        
    }
    else if (buttonIndex == 0){
        //only yap
        [self performSegueWithIdentifier:RECORD_OPTION_VC sender:nil];
    }
    else if (buttonIndex == 1){
        //yap with image
        [self performSegueWithIdentifier:CAPTURE_IMAGE_VC sender:nil];
    }
    else if (buttonIndex == 2){
        //yap with video
        if ([[NSFileManager defaultManager] fileExistsAtPath:VIDEO_RECORDING_FOLDER]) {
            //when folder exists
            NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
            if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
                [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
            }
        }
        [self performSegueWithIdentifier:SET_VIDEO_PRIVACY_VC sender:nil];
    }
}

#pragma mark    UIAlertView Delegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 1) {
        //delete selected blabs
        if (buttonIndex == alertView.cancelButtonIndex) {
            
        }
        else{
            
            NSLog(@"%@",[self.arrData valueForKey:IS_SELECTED]);
            
            
            [self callDeleteSelectedCellService];
        }
    }
    else if (alertView.tag == 2) {
        //share selected blabs
        if (buttonIndex == alertView.cancelButtonIndex) {
            
        }
        else{
            NSString *strIds = [self getSelectedIds:NO];
            NSArray *arr = [strIds componentsSeparatedByString:@"|"];
            NSArray *arrTemp;
            if (arr.count==1) {
                arrTemp =  [self filterArrayByADictionary:self.arrData andKey:[NSPredicate predicateWithFormat:@"(ID = %d)",[strIds intValue]]];
                if (arrTemp.count!=0) {
                    NSDictionary *dic = [arrTemp objectAtIndex:0];
                    
                    if (([DataValidation checkNullString:[dic valueForKey:VideoPath]].length!=0 || [DataValidation checkNullString:[dic valueForKey:ImagePath]].length!=0) && ![[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"1"]) {
                        //it it video
//                        self.strShareURL = [dic valueForKey:VideoPath];
                        dicSelForSingleVideoImageShare = dic;
//                        [self shareWithShareURL:[dic valueForKey:VideoPath]];
                        
                    }
/*                    else if([DataValidation checkNullString:[dic valueForKey:ImagePath]].length!=0){
                        //it is image
                        self.strShareURL = [dic valueForKey:ImagePath];
                        [self shareWithShareURL:[NSString stringWithFormat:@"%@",[dic valueForKey:ImagePath]]];
                    }
*/                    else{
                        dicSelForSingleVideoImageShare = nil;
    
                    }
                }
                else{
                    dicSelForSingleVideoImageShare = nil;
                }
            }
            else{
                dicSelForSingleVideoImageShare = nil;
            }
            [self callShareSelectedCellService];
        }
        
    }
    else if (alertView.tag == 3){
        
        if (buttonIndex == alertView.cancelButtonIndex) {
            //no, so delete that blab
//            [self deletePrivateMessage];
            if (self.isShouldCallIsRead) {
                [self setNotifAsRead];
            }
            else{
                [self deletePrivateMessage];
            }
            [self.arrData removeObjectAtIndex:self.currentlyPlaingIndex];
            if (self.arrPlaySelectedBlabs.count > 0 && self.currentlyPlaingIndex < self.arrPlaySelectedBlabs.count){
                [self.arrPlaySelectedBlabs removeObjectAtIndex:self.currentlyPlaingIndex];
            }
            self.countOfPlay --;
            self.currentlyPlaingIndex --;
            [self.tblData reloadData];
        }
        else{
            //send keep request
            [self sendKeppRequestForIndex];
        }
        self.isPlaying = NO;
        self.selectedPlayID = -1;
        if (self.isPlayAll) {
            [self startPlayLoop];
        }
    }
}


-(NSArray *)filterArrayByADictionary:(NSMutableArray *)aArray andKey:(NSPredicate *)aPredicte
{
    //    NSPredicate *filter = [NSPredicate predicateWithFormat:aPredicte];
    NSLog(@"%@ %@",self.arrData,aPredicte);
    return [aArray filteredArrayUsingPredicate:aPredicte];
}
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:RECORD_OPTION_VC] || [segue.identifier isEqualToString:CAPTURE_IMAGE_VC] || [segue.identifier isEqualToString:SET_VIDEO_PRIVACY_VC]) {
        
        if (appDelegate.dic_NotificationReleatedData != nil) {
            appDelegate.dic_NotificationReleatedData = nil;
        }
        
        //  NSDictionary dic = [NSDictionary dictionaryWithDictionary:(NSDictionary )[self.arrData lastObject]];
        
        NSString *strReceiverId = @"";
        BOOL isGroupMessage = FALSE;
        NSString *strGrpId = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:@"GroupID"]]];
        if (strGrpId.length >0 && ([strGrpId intValue]!=0)) {
            //it is group message
            strReceiverId = [NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:@"GroupID"]];
            isGroupMessage = TRUE;
        }
        else{
            strReceiverId = [NSString stringWithFormat:@"%@",[self.dicConversationDetail valueForKey:USER_CONVERSATION_USERID]];
        }
        
        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    [NSArray arrayWithObjects:strReceiverId, nil],SelectedIds,
                                                    [NSNumber numberWithBool:isGroupMessage],IS_GroupNotif,
                                                    [NSNumber numberWithBool:NO],IS_NotifSendToAll,
                                                    @"0",BlabType,
                                                    nil];
    }
    else if ([segue.identifier isEqualToString:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC]){
        
        if (appDelegate.isForwarded) {
            AddFriendFromExistingFriendListVC *obj = segue.destinationViewController;
            obj.dicSelectedNotifToForward = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.selectedIndex] ];
        }
    }
    else if ([segue.identifier isEqualToString:CONVERSATION_GRP_DETAIL_VC]){
        ConversationGrpDetailVC *obj = segue.destinationViewController;
        obj.dicGrpDetail = self.dicConversationDetail;
    }
    
    [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
    [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];

}

#pragma mark
-(void)shareWithFBClicked:(id)sender{
    [self RemoveSocialViewFromSuperView];
    
    if (dicSelForSingleVideoImageShare!=nil) {
        [HUD show:YES];
        
            [self performSelectorInBackground:@selector(shareVideoOrImageTOFB) withObject:nil];
        
    }
    else{
        if (!FBSession.activeSession.isOpen) {
            // if the session is closed, then we open it here, and establish a handler for state changes
            [FBSession openActiveSessionWithReadPermissions:@[@"public_profile", @"email", @"user_friends"]
                                               allowLoginUI:YES
                                          completionHandler:^(FBSession *session,
                                                              FBSessionState state,
                                                              NSError *error) {
                                              if (error) {
                                                  [HUD hide:YES];
                                                  UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                                                      message:@"Could not get your Facebook data.\nPlease check you internet connectivity or try later."
                                                                                                     delegate:nil
                                                                                            cancelButtonTitle:@"OK"
                                                                                            otherButtonTitles:nil];
                                                  [alertView show];
                                              } else if (session.isOpen) {
                                                  NSLog(@"facebook login");
                                                  [self PostOnFB:(int)((UIButton *)sender).tag];
                                              }
                                          }];
            return;
        }
        else if (FBSession.activeSession.isOpen) {
            NSLog(@"facebook activeSession.isOpen");
            [self PostOnFB:(int)((UIButton *)sender).tag];
        }
    }
}

-(void)PostOnFB:(int)Index{
    NSString *strURL = self.strShareURL;    //[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_AUDIO_PATH];
    
    FBLinkShareParams *params = [[FBLinkShareParams alloc] init];
    //    http://wwhhaazzuupp.com/content/content/6kkTrbUma2SIRbp8VY34cA==
   // NSLog(@"%@",[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_ID]]);
    
    /*
     Replace("_", "+"));
     Replace("-","/");
     */
    
//    NSString *strEncryptText = [Validation getEncryptedShareUrlId:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_ID]]];
    
    params.link = [NSURL URLWithString:self.strShareURL];
    params.name = @"Blabeey";
    params.picture =  [NSURL URLWithString:self.strShareImagePathURL];
  //  params.caption = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_Category]];
    
    // If the Facebook app is installed and we can present the share dialog
    if ([FBDialogs canPresentShareDialogWithParams:params]) {
        // Present the share dialog
         [FBDialogs presentShareDialogWithParams:params clientState:nil handler:^(FBAppCall *call, NSDictionary *results, NSError *error) {
                                          if(error) {
                                              // An error occurred, we need to handle the error
                                              // See: https://developers.facebook.com/docs/ios/errors
                                              NSLog(@"Error publishing story: %@", error.description);
                                          } else {
                                              // Success
                                              NSLog(@"result %@", results);
                                              if (![[results valueForKey:@"completionGesture"] isEqualToString:@"cancel"]) {
                                                  [Validation showToastMessage:@"Successfully posted" displayDuration:SUCCESS_MSG_DURATION];
                                              }
                                              
                                          }
                                      }];
    } else {
        // Present the feed dialog
        NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                       @"Blabeey", @"name",
//                                       [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_Category]], @"caption",
                                       //                                       @"Allow your users to share stories on Facebook from your app using the iOS SDK.", @"description",
                                       strURL, @"link",
                                       //                                       @"http://i.imgur.com/g3Qc1HN.png", @"picture",
                                       nil];
        
        // Show the feed dialog
        [FBWebDialogs presentFeedDialogModallyWithSession:nil
                                               parameters:params
                                                  handler:^(FBWebDialogResult result, NSURL *resultURL, NSError *error) {
                                                      if (error) {
                                                          // An error occurred, we need to handle the error
                                                          // See: https://developers.facebook.com/docs/ios/errors
                                                          NSLog(@"Error publishing story: %@", error.description);
                                                      } else {
                                                          if (result == FBWebDialogResultDialogNotCompleted) {
                                                              // User cancelled.
                                                              NSLog(@"User cancelled.");
                                                          } else {
                                                              // Handle the publish feed callback
                                                              NSDictionary *urlParams = [Validation parseURLParams:[resultURL query]];
                                                              
                                                              if (![urlParams valueForKey:@"post_id"]) {
                                                                  // User cancelled.
                                                                  NSLog(@"User cancelled.");
                                                                  
                                                              } else {
                                                                  // User clicked the Share button
                                                                  NSString *result = [NSString stringWithFormat: @"Posted story, id: %@", [urlParams valueForKey:@"post_id"]];
                                                                  NSLog(@"result %@", result);
                                                              }
                                                          }
                                                      }
                                                  }];
    }
    
}
-(void)shareVideoOrImageTOFB{
    /*
     __block ACAccount * facebookAccount;
     ACAccountStore* accountStore = [[ACAccountStore alloc] init];
     NSDictionary *options = @{
     ACFacebookAppIdKey: @"691572667578808",
     ACFacebookPermissionsKey: @[@"publish_actions",@"video_upload" ],
     @"ACFacebookAudienceKey": ACFacebookAudienceFriends
     };
     ACAccountType *facebookAccountType = [accountStore
     accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierFacebook];
     [accountStore requestAccessToAccountsWithType:facebookAccountType options:options completion:^(BOOL granted, NSError *error) {
     
     if (granted) {
     NSArray *accounts = [accountStore
     accountsWithAccountType:facebookAccountType];
     facebookAccount = [accounts lastObject];
     
     
     
     NSLog(@"access to facebook account ok %@", facebookAccount.username);
     
     NSURL *url = [NSURL URLWithString:@"https://graph.facebook.com/me/videos"];
     
     NSURL *videoPathURL = [NSURL URLWithString:str];
     NSData *videoData = [NSData dataWithContentsOfURL:videoPathURL];
     
     NSString *status = @"One step closer.";
     NSDictionary *params = @{@"title":status, @"description":status};
     
     SLRequest *request = [SLRequest requestForServiceType:SLServiceTypeFacebook
     requestMethod:SLRequestMethodPOST
     URL:url
     parameters:params];
     
     [request addMultipartData:videoData
     withName:@"source"
     type:@"video/mp4"
     filename:[videoPathURL absoluteString]];
     
     request.account = facebookAccount;
     [request performRequestWithHandler:^(NSData *data,NSHTTPURLResponse *response,NSError * error){
     NSLog(@"response = %@", response);
     NSLog(@"error = %@", [error localizedDescription]);
     
     }];
     
     
     } else {
     NSLog(@"access to facebook is not granted %@",[error description]);
     // extra handling here if necesary
     
     }
     
     }];
     */
    
    /*
     ACAccountStore *accountStore = [[ACAccountStore alloc] init];
     
     ACAccountType *facebookAccountType = [accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierFacebook];
     
     // Specify App ID and permissions
     NSDictionary *options = @{ACFacebookAppIdKey: @"691572667578808",
     ACFacebookPermissionsKey: @[@"publish_stream", @"video_upload"],
     ACFacebookAudienceKey: ACFacebookAudienceFriends}; // basic read permissions
     
     [accountStore requestAccessToAccountsWithType:facebookAccountType options:options completion:^(BOOL granted, NSError *e) {
     if (granted) {
     NSArray *accountsArray = [accountStore accountsWithAccountType:facebookAccountType];
     
     if ([accountsArray count] > 0) {
     ACAccount *facebookAccount = [accountsArray objectAtIndex:0];
     
     
     NSDictionary *parameters = @{@"description": @"JSR"};
     
     
     SLRequest *facebookRequest = [SLRequest requestForServiceType:SLServiceTypeFacebook
     requestMethod:SLRequestMethodPOST
     URL:[NSURL URLWithString:@"https://graph.facebook.com/me/videos"]
     parameters:parameters];
     
     NSURL *videoPathURL = [NSURL URLWithString:str];
     NSData *videoData = [NSData dataWithContentsOfURL:videoPathURL];
     [facebookRequest addMultipartData: videoData
     withName:@"source"
     type:@"video/mp4"
     filename:@"video.mov"];
     
     facebookRequest.account = facebookAccount;
     
     
     [facebookRequest performRequestWithHandler:^(NSData* responseData, NSHTTPURLResponse* urlResponse, NSError* error) {
     if (error == nil) {
     NSLog(@"responedata:%@", [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding]);
     }else{
     NSLog(@"%@",error.description);
     }
     }];
     }
     } else {
     NSLog(@"Access Denied");
     NSLog(@"[%@]",[e localizedDescription]);
     }
     }];
     */
    if ([DataValidation checkNullString:[dicSelForSingleVideoImageShare valueForKey:VideoPath]].length!=0) {
        NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[dicSelForSingleVideoImageShare valueForKey:VideoPath]]];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        
        if (![fm fileExistsAtPath:INSTAGRAMVIDEO_FOLDER]){
            
            [fm createDirectoryAtPath:INSTAGRAMVIDEO_FOLDER
          withIntermediateDirectories:YES
                           attributes:nil
                                error:NULL];
        }
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:INSTAGRAMVIDEO_FOLDER]) {
            NSString *tempPath = [INSTAGRAMVIDEO_FOLDER stringByAppendingFormat:@"/test.mp4"];
            if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
                [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
            }
        }
        
        NSString *tempPath1 = [INSTAGRAMVIDEO_FOLDER stringByAppendingFormat:@"/test.mp4"];
        
        BOOL success = [imageData writeToFile:tempPath1 atomically:NO];
        NSLog(@"success=%d",success);
        
        
        NSString *tempPath = [INSTAGRAMVIDEO_FOLDER stringByAppendingFormat:@"/test.mp4"];
        NSURL *movieURL = [NSURL fileURLWithPath:tempPath];
        
        ALAssetsLibrary* library = [[ALAssetsLibrary alloc] init];
        [library writeVideoAtPathToSavedPhotosAlbum:movieURL
                                    completionBlock:^(NSURL *assetURL, NSError *error){
                                        /*notify of completion*/
                                        NSLog(@"assetURL=======%@",assetURL);
                                        
                                        FBSDKShareDialog *shareDialog = [[FBSDKShareDialog alloc]init];
                                        // NSURL *videoURL=videoURL;
                                        FBSDKShareVideo *video = [[FBSDKShareVideo alloc] init];
                                        video.videoURL = assetURL;
                                        FBSDKShareVideoContent *content = [[FBSDKShareVideoContent alloc] init];
                                        content.video = video;
                                        shareDialog.shareContent = content;
                                        [shareDialog setDelegate:self];//=self;
                                        [shareDialog setFromViewController:self];
                                        [shareDialog show];
                                        
                                        [HUD hide:YES];
                                        
                                    }];
    }
    else{
/*
        UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[dicSelForSingleVideoImageShare valueForKey:ImagePath]]]];
        
        FBSDKSharePhoto *photo = [[FBSDKSharePhoto alloc] init];
        photo.image = image;
        photo.userGenerated = YES;
        FBSDKSharePhotoContent *content = [[FBSDKSharePhotoContent alloc] init];
        content.photos = @[photo];
        
        FBSDKShareDialog *shareDialog = [[FBSDKShareDialog alloc]init];
        // NSURL *videoURL=videoURL;
        
        shareDialog.shareContent = content;
        shareDialog.delegate=self;
        [shareDialog show];
*/
        [HUD show:YES];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dicSelForSingleVideoImageShare valueForKey:@"ID"]],KeyValue,@"MessageID",KeyName, nil],@"2",
                             [NSDictionary dictionaryWithObjectsAndKeys:[dicSelForSingleVideoImageShare valueForKey:@"SoundPath"],KeyValue,@"SoundPath",KeyName, nil],@"3",
                             [NSDictionary dictionaryWithObjectsAndKeys:[dicSelForSingleVideoImageShare valueForKey:ImagePath],KeyValue,@"ImagePath",KeyName, nil],@"4",
                             nil];
        
        NSString *strUrl = MERGE_AUDIO_IMAGE;
        AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
        obj.isLongTimeOut = YES;
        [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
        if (obj._currentRequest == nil) {
            [HUD hide:YES];
        }
        else{
            [obj setDelegate:self];
            [obj setTag:12];
        }
        //    [obj setDelegate:self];
        //    [obj setTag:5];
        strUrl = nil;
    }
}
- (void)sharer:(id<FBSDKSharing>)sharer didCompleteWithResults:(NSDictionary *)results{
    NSLog(@"---------->>>>>>> didCompleteWithResults %@",results);
    [HUD hide:YES];
}

- (void)sharer:(id<FBSDKSharing>)sharer didFailWithError:(NSError *)error{
    NSLog(@"---------->>>>>>> Error = %@",error.description);
    [HUD hide:YES];
}
- (void)sharerDidCancel:(id<FBSDKSharing>)sharer{
    NSLog(@"---------->>>>>>> %@",sharer);
    [HUD hide:YES];
}
-(void)shareWithGooglePlusClicked:(id)sender{
    [self RemoveSocialViewFromSuperView];
}

-(void)shareWithPinterestClicked:(id)sender{
    [self RemoveSocialViewFromSuperView];
}

-(void)shareWithTwitterClicked:(id)sender{
    [self RemoveSocialViewFromSuperView];
    [self PostOnTwitter:(int)((UIButton *)sender).tag];
}

-(void)PostOnTwitter:(int)Index{
    
    
    SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
    SLComposeViewControllerCompletionHandler myBlock = ^(SLComposeViewControllerResult result){
        if (result == SLComposeViewControllerResultCancelled) {
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Cancelled" message:@"You Cancelled posting the Tweet." delegate:nil cancelButtonTitle:OK_BUTTON_TITLE otherButtonTitles: nil] ;
            
            [alert show];
            //       [alert release];
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Success" message:@"The Tweet was posted successfully." delegate:nil cancelButtonTitle:OK_BUTTON_TITLE otherButtonTitles: nil] ;
            
            [alert show];
            //        [alert release];
        }
        
        [controller dismissViewControllerAnimated:YES completion:Nil];
    };
    
    controller.completionHandler =myBlock;
    
    //Adding the Text to the facebook post value from iOS
   // [controller setInitialText:[NSString stringWithFormat:@"Check this Blabeey!! - %@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_Category]]];
    
    [controller setInitialText:@"Check out this awesome content from Blabeey"];
    
    //Adding the URL to the facebook post value from iOS
//    NSString *strEncryptText = [Validation getEncryptedShareUrlId:self.strShareURL];
    
    
//    [controller addURL:[NSURL URLWithString:[Validation getEncryptedShareUrlId:self.strShareURL]]];
    [controller addURL:[NSURL URLWithString:self.strShareURL]];
    
    //Adding the Image to the facebook post value from iOS
    NSData *imageData=[NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Icon" ofType:@"png"]];
    
    UIImage *image = [UIImage imageWithData:imageData];
    if (image != nil) {
        [controller addImage:image];
    }
    
    [self presentViewController:controller animated:YES completion:Nil];
}

-(void)ShareThroughSMS:(id)sender{
	
	[self RemoveSocialViewFromSuperView];
	
  //  UIButton *btn = (UIButton *)sender;
    
	MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
	
	if([MFMessageComposeViewController canSendText])
	{
        [AlertHandler alertTitle:MESSAGE message:SMS_CHARGE_ALERT delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        
      //  NSString *strEncryptText = [Validation getEncryptedShareUrlId:self.strShareURL];
        
		NSString *strUrl = self.strShareURL;
        
        NSString *strTitle = [NSString stringWithFormat:@"%@ sent you Blab - ",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_NAME]];
        
        
		NSString *strShareText = [NSString stringWithFormat:@"%@ - %@",strTitle,strUrl];
		
		controller.body = strShareText;
        
		controller.messageComposeDelegate = self;
        [self presentViewController:controller animated:YES completion:nil];
	}
	
    //	[controller release];
}

-(void)ShareThroughMail:(id)sender{
	
	[self RemoveSocialViewFromSuperView];
//	UIButton *btn = (UIButton *)sender;
    
	MFMailComposeViewController *mailViewController = [[MFMailComposeViewController alloc] init];
	
	if (mailViewController != nil)
	{
		if ([MFMailComposeViewController canSendMail]) {
			
            //NSString *strEncryptText = [Validation getEncryptedShareUrlId:self.strShareURL];
            
            
			NSString *strUrl = self.strShareURL;      //[NSString stringWithFormat:@"%@%@",SHARE_URL,strEncryptText];
            
            NSString *strTitle = [NSString stringWithFormat:@"%@ sent you Blab -",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_NAME]];
            
			mailViewController.mailComposeDelegate = self;
			[mailViewController setSubject:@"Blabeey"];
			NSString *bodyText =@"<html>";
			bodyText = [bodyText stringByAppendingString:@"<head>"];
			bodyText = [bodyText stringByAppendingString:@"</head>"];
			bodyText = [bodyText stringByAppendingString:@"<body>"];
			bodyText = [bodyText stringByAppendingFormat:@"%@ <a href=\"%@\">%@",strTitle,strUrl,strUrl];
			bodyText = [bodyText stringByAppendingString:@"</a>"];
			
			[mailViewController setMessageBody:bodyText isHTML:YES];
            
            [self presentViewController:mailViewController animated:YES completion:nil];
		}
		else
		{
			[self launchMailAppOnDevice];
		}
	}
	else
	{
		[self launchMailAppOnDevice];
	}
    //	[mailViewController release];
}

- (void)removeSocialShareContainerFromParentVC{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
    self.objShareVC.view.alpha = 0;
    [UIView commitAnimations];
    
    [self performSelector:@selector(RemoveSocialViewFromSuperView) withObject:nil afterDelay:0.5];
}

-(void)RemoveSocialViewFromSuperView{
    [self.objShareVC.view removeFromSuperview];
    [self.objShareVC removeFromParentViewController];
    self.objShareVC = nil;
}

#pragma mark
#pragma MFMessageComposeViewController
#pragma mark

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [self dismissViewControllerAnimated:YES completion:nil];
	
	if (result == MessageComposeResultCancelled){
        [AlertHandler alertTitle:CANCELLED message:MESSAGE_CANCELLED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else if (result == MessageComposeResultSent){
        [AlertHandler alertTitle:SUCCESS message:MESSAGE_SENT delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else{
        [AlertHandler alertTitle:FAILURE message:MESSAGE_FAILED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
}

#pragma mark
#pragma MFMailComposeViewController
#pragma mark

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error{
	
    [self dismissViewControllerAnimated:YES completion:nil];
	
	if (result == MFMailComposeResultCancelled){
        [AlertHandler alertTitle:CANCELLED message:MAIL_SENDING_CANCELLED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else if (result == MFMailComposeResultSent){
        [AlertHandler alertTitle:SUCCESS message:MAIL_SEND delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else if (result == MFMailComposeResultFailed){
        [AlertHandler alertTitle:FAILURE message:MAIL_SENDING_FAILED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else if(result == MFMailComposeResultSaved){
        [AlertHandler alertTitle:SUCCESS message:MAIL_SAVED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
}

-(void)launchMailAppOnDevice
{
    //NSString *strEncryptText = [Validation getEncryptedShareUrlId:self.strShareURL];
    
    
	NSString *strUrl =  self.strShareURL; //[NSString stringWithFormat:@"%@%@",SHARE_URL,strEncryptText];
    
    NSString *strTitle = @"Blabeey!!";  //[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:NOTIF_Category]];
    
    NSString *strShareText = [NSString stringWithFormat:@"%@ - %@",strTitle,strUrl];
    
	NSString *bodyText =@"<html>";
	bodyText = [bodyText stringByAppendingString:@"<head>"];
	bodyText = [bodyText stringByAppendingString:@"</head>"];
	bodyText = [bodyText stringByAppendingString:@"<body>"];
	bodyText = [bodyText stringByAppendingFormat:@"<a href=\"%@\">%@",strUrl,strShareText];
	bodyText = [bodyText stringByAppendingString:@"</a>"];
	
	NSString *recipients = [NSString stringWithFormat:@"mailto:?cc=&subject=%@",@"Blabeey"];
	NSString *body = [NSString stringWithFormat:@"&body=%@",bodyText];
	
	NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
	email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}

@end
