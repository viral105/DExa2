//
//  ConversationWithoutImgCell.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 15/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ConversationWithoutImgCellDelegate <NSObject>

-(void)btnBlabCreatorName_Clicked:(NSDictionary *)dic;
-(void)btnBlabCreatorImage_Clicked:(NSDictionary *)dic;

@end

@interface ConversationWithoutImgCell : UITableViewCell

@property (nonatomic, retain) IBOutlet AsyncImageView      *imgPlayContainer;

@property (nonatomic, strong) IBOutlet UIButton         *btnPlayContainer;
@property (nonatomic, retain) IBOutlet UIImageView      *imgPlay;
@property (nonatomic, retain) IBOutlet UIImageView      *imgPlayAnimation;
@property (nonatomic, strong) IBOutlet UILabel          *lblCategoryName;
@property (nonatomic, strong) IBOutlet UILabel          *lblSubCategoryName;
@property (nonatomic, retain) IBOutlet UIImageView      *imgTimer;
@property (nonatomic, strong) IBOutlet UILabel          *lblDuration;

@property (nonatomic, strong) IBOutlet UIView           *viewButtonContainer;
@property (nonatomic, strong) IBOutlet UIButton         *btnLike;
@property (nonatomic, strong) IBOutlet UIButton         *btnReportAbuse;
@property (nonatomic, strong) IBOutlet UIButton         *btnForward;
@property (nonatomic, strong) IBOutlet UIImageView      *imgSelected;
@property (nonatomic, strong) IBOutlet UIImageView      *imgPrivate;
@property (nonatomic, strong) IBOutlet UILabel          *lblBlabCreatorName;
@property (nonatomic, strong) IBOutlet UIButton          *btnBlabCreatorName;
@property (nonatomic, strong) IBOutlet UIButton         *btnBlabCreatorImage;
@property (nonatomic, strong) IBOutlet UILabel          *lblBlabFullDesc;
@property (nonatomic, strong) IBOutlet UIView           *viewBlabFullDesc;


@property (nonatomic, strong) NSDictionary          *dicSelected;
@property (nonatomic, strong) id<ConversationWithoutImgCellDelegate> delegate;

@property (nonatomic, readwrite) CGSize                 categorySize;


-(void)setControlsInCellWithDictionary:(NSDictionary *)dic withUserId:(NSString *)strUserId isEdit:(BOOL)isEdit;
-(IBAction)btnBlabCreatorName_Clicked:(id)sender;
-(IBAction)btnBlabCreatorImage_Clicked:(id)sender;
@end
