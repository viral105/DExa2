//
//  ConversationWithoutImgCell.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 15/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "ConversationWithoutImgCell.h"
#define IS_SELECTED             @"is_selected"
#define WIDTH_DESC           250

@implementation ConversationWithoutImgCell

- (void)awakeFromNib
{
    // Initialization code
    self.categorySize = CGSizeMake(100, 15);

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setRightSideControls{
    float xStart = DEVICE_WIDTH-10;
    float yStart = 16;
    
    xStart -= 75;
    self.imgPlayContainer.frame = CGRectMake(xStart, yStart, 75, 75);
    
    xStart-= 10;            //distance
    yStart += (self.imgPlayContainer.frame.size.height-15);
    self.imgTimer.frame = CGRectMake(xStart-12, yStart, 12, 12);
    
    self.lblSubCategoryName.frame = CGRectMake(xStart-self.lblSubCategoryName.frame.size.width, yStart-15, self.lblSubCategoryName.frame.size.width, 15);
    if (self.lblSubCategoryName.text.length == 0) {
        self.lblCategoryName.frame = CGRectMake(xStart-self.lblCategoryName.frame.size.width, yStart-20, self.lblCategoryName.frame.size.width, 15);
        self.lblBlabCreatorName.frame = CGRectMake(xStart-self.lblBlabCreatorName.frame.size.width, yStart-40, self.lblBlabCreatorName.frame.size.width, 15);
    }
    else{
        self.lblCategoryName.frame = CGRectMake(xStart-self.lblCategoryName.frame.size.width, yStart-30, self.lblCategoryName.frame.size.width, 15);

        self.lblBlabCreatorName.frame = CGRectMake(xStart-self.lblBlabCreatorName.frame.size.width, yStart-50, self.lblBlabCreatorName.frame.size.width, 15);
    }
    
    xStart -= (15);
    xStart -= self.lblDuration.frame.size.width;

    self.lblDuration.frame = CGRectMake(xStart, yStart, self.lblDuration.frame.size.width, 12);
    if (![self.imgPrivate isHidden]) {
        xStart -= self.lblDuration.frame.size.width - 5 +10;
        self.imgPrivate.frame = CGRectMake(xStart, yStart, 10, 12);
    }
    
    yStart += (12+10);
    xStart = (DEVICE_WIDTH-(10+self.viewButtonContainer.frame.size.width));
    
    self.viewButtonContainer.frame = CGRectMake(xStart, yStart, self.viewButtonContainer.frame.size.width, self.viewButtonContainer.frame.size.height);
    xStart -= (50+10);
    self.imgPlay.frame = CGRectMake(xStart, self.viewButtonContainer.frame.origin.y-5, 50, 50);
    self.btnPlayContainer.frame = self.imgPlay.frame;
    self.imgPlayAnimation.frame = self.imgPlay.frame;
    
    self.lblDuration.textAlignment = NSTextAlignmentRight;
    self.imgSelected.frame = CGRectMake(10, self.imgPlay.frame.origin.y, 30, 30);

    self.lblBlabCreatorName.textAlignment = NSTextAlignmentRight;
    self.lblSubCategoryName.textAlignment = NSTextAlignmentRight;
    self.lblDuration.textAlignment = NSTextAlignmentRight;
    self.lblCategoryName.textAlignment = NSTextAlignmentCenter;
    
    
    if (self.viewBlabFullDesc.frame.size.width < WIDTH_DESC) {
        self.viewBlabFullDesc.frame = CGRectMake(DEVICE_WIDTH-self.viewBlabFullDesc.frame.size.width-10, self.viewButtonContainer.frame.origin.y+self.viewButtonContainer.frame.size.height+10, self.viewBlabFullDesc.frame.size.width, self.viewBlabFullDesc.frame.size.height);
        //  self.lblBlabFullDesc.frame = CGRectMake(5, 2, self.lblBlabFullDesc.frame.size.width, self.lblBlabFullDesc.frame.size.height);
    }
    else{
        self.viewBlabFullDesc.frame = CGRectMake(DEVICE_WIDTH-WIDTH_DESC-10, self.viewButtonContainer.frame.origin.y+self.viewButtonContainer.frame.size.height+10, WIDTH_DESC, self.viewBlabFullDesc.frame.size.height);
        //self.lblBlabFullDesc.frame = CGRectMake(DEVICE_WIDTH-WIDTH_DESC-10, self.viewButtonContainer.frame.origin.y+self.viewButtonContainer.frame.size.height+10, WIDTH_DESC, self.lblBlabFullDesc.frame.size.height);
    }
}

-(void)setLeftSideControls{
    
    float xStart = 10;
    float yStart = 16;
    
    self.imgPlayContainer.frame = CGRectMake(xStart, yStart, 75, 75);
   
    
    xStart += self.imgPlayContainer.frame.size.width+10;
    yStart += (self.imgPlayContainer.frame.size.height-15);
    
    self.imgTimer.frame = CGRectMake(xStart, yStart, 12, 12);
    
     self.lblSubCategoryName.frame = CGRectMake(xStart, yStart-15, self.lblSubCategoryName.frame.size.width, 15);
    if (self.lblSubCategoryName.text.length == 0) {
        self.lblBlabCreatorName.frame = CGRectMake(xStart, yStart-40, self.lblBlabCreatorName.frame.size.width, 15);
        self.lblCategoryName.frame = CGRectMake(xStart, yStart-20, self.lblCategoryName.frame.size.width, 15);
    }
    else{
        self.lblCategoryName.frame = CGRectMake(xStart, yStart-30, self.lblCategoryName.frame.size.width, 15);
        self.lblBlabCreatorName.frame = CGRectMake(xStart, yStart-50, self.lblBlabCreatorName.frame.size.width, 15);
    }
    
    xStart += 15;

    self.lblDuration.frame = CGRectMake(xStart, yStart, self.lblDuration.frame.size.width, 12);
    if (![self.imgPrivate isHidden]) {
        xStart += self.lblDuration.frame.size.width + 5;
        self.imgPrivate.frame = CGRectMake(xStart, yStart, 10, 12);
    }
    
    yStart += (12+10);
    xStart = self.imgPlayContainer.frame.origin.x;
    self.viewButtonContainer.frame = CGRectMake(xStart, yStart, self.viewButtonContainer.frame.size.width, self.viewButtonContainer.frame.size.height);
    
    xStart += (self.viewButtonContainer.frame.size.width+10);
    self.imgPlay.frame = CGRectMake(xStart, self.viewButtonContainer.frame.origin.y-5, 50, 50);
    self.btnPlayContainer.frame = self.imgPlay.frame;
    self.imgPlayAnimation.frame = self.imgPlay.frame;
    
    self.imgSelected.frame = CGRectMake(self.frame.size.width-40, self.imgPlayContainer.frame.origin.y, 30, 30);
    

    self.lblBlabCreatorName.textAlignment = NSTextAlignmentLeft;
    self.lblSubCategoryName.textAlignment = NSTextAlignmentLeft;
    self.lblDuration.textAlignment = NSTextAlignmentLeft;
    self.lblCategoryName.textAlignment = NSTextAlignmentCenter;
    
    if (self.viewBlabFullDesc.frame.size.width < WIDTH_DESC) {
        //        self.lblBlabFullDesc.frame = CGRectMake(10, self.viewButtonContainer.frame.origin.y+self.viewButtonContainer.frame.size.height+10, self.lblBlabFullDesc.frame.size.width, self.lblBlabFullDesc.frame.size.height);
        self.viewBlabFullDesc.frame = CGRectMake(10, self.viewButtonContainer.frame.origin.y+self.viewButtonContainer.frame.size.height+10, self.viewBlabFullDesc.frame.size.width, self.viewBlabFullDesc.frame.size.height);
    }
    else{
        //        self.lblBlabFullDesc.frame = CGRectMake(10, self.viewButtonContainer.frame.origin.y+self.viewButtonContainer.frame.size.height+10, WIDTH_DESC, self.lblBlabFullDesc.frame.size.height);
        self.viewBlabFullDesc.frame = CGRectMake(10, self.viewButtonContainer.frame.origin.y+self.viewButtonContainer.frame.size.height+10, WIDTH_DESC, self.viewBlabFullDesc.frame.size.height);
    }
    
}

-(void)setControlsInCellWithDictionary:(NSDictionary *)dic withUserId:(NSString *)strUserId isEdit:(BOOL)isEdit{
    
    self.dicSelected = dic;
    self.lblCategoryName.clipsToBounds = YES;
    self.lblSubCategoryName.text = @"";
    self.lblCategoryName.text = @"";
    
    self.lblDuration.font = [UIFont fontWithName:Font_OpneSans_SemiBol size:10];
    self.lblCategoryName.font = [UIFont fontWithName:Font_Montserrat_Regular size:9];
    self.lblSubCategoryName.font = [UIFont fontWithName:Font_Montserrat_Regular size:9];
    self.lblBlabCreatorName.font = [UIFont fontWithName:Font_Montserrat_Regular size:14];

    
    self.lblBlabFullDesc.textColor = UIColorFromRGB(0X656d78);
    
    
//    self.imgPlayContainer.backgroundColor = TWITTER_BLUE_COLOR;
//    self.imgPlayContainer.layer.cornerRadius = 10;
    
//    [self.contentView bringSubviewToFront:self.imgPlayContainer];
//    self.imgPlayContainer.imageURL = [NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]];
    if ([strUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
        self.imgPlayContainer.imageURL = [NSURL URLWithString:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]];
    }
    else{
        self.imgPlayContainer.imageURL = [NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]];
    }
    [Validation setCorners:self.imgPlayContainer];
    
    self.viewButtonContainer.layer.cornerRadius = 10;
    
    self.imgPlay.layer.cornerRadius = self.imgPlay.frame.size.height/2;
    self.imgPlayAnimation.layer.cornerRadius = self.imgPlay.frame.size.height/2;
    
    NSString *str = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_SENT_BEFORE]];
	self.lblDuration.text = str;
	CGSize size = CGSizeMake(40, self.lblDuration.frame.size.height);
	CGRect text = [str boundingRectWithSize:size
                                    options:NSStringDrawingUsesLineFragmentOrigin
                                 attributes:@{NSFontAttributeName:self.lblDuration.font}
                                    context:nil];
	float xStart = self.lblDuration.frame.origin.x;
	
	size = text.size;
	self.lblDuration.frame = CGRectMake(xStart, self.lblDuration.frame.origin.y, size.width, self.lblDuration.frame.size.height);

    //creator's name
    if ([strUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
//        str = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:USER_NAME]];
        str = [NSString stringWithFormat:@"Me"];
    }else{
        str = [NSString stringWithFormat:@"%@",[dic valueForKey:NAME]];
    }
    size = self.categorySize;
    NSMutableParagraphStyle *paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.lineBreakMode = NSLineBreakByTruncatingTail;
    
    text = [str boundingRectWithSize:size
                             options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                          attributes:@{NSFontAttributeName:self.lblBlabCreatorName.font, NSParagraphStyleAttributeName: paragraph}
                             context:nil];
	size = text.size;
    self.lblBlabCreatorName.frame = CGRectMake(self.lblBlabCreatorName.frame.origin.x, self.lblBlabCreatorName.frame.origin.y, (size.width>150)?(150):(size.width+4), self.lblBlabCreatorName.frame.size.height);
	self.lblBlabCreatorName.text = str;
	[self.lblBlabCreatorName setTextColor:(str.length >0)?[Validation getColorForAlphabet:self.lblBlabCreatorName.text]:[UIColor blackColor]];

    if ([[dic valueForKey:IsPrivate] boolValue]) {
        self.imgPrivate.hidden = NO;
    }
    else{
        self.imgPrivate.hidden = YES;
    }
    
    //------------------------category Name
    
    //category Name
    str = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_Category]];
    str = (([[DataValidation checkNullString:str] length] == 0)?@"Private":str);
    size = self.categorySize;
	text = [str boundingRectWithSize:size
                             options:NSStringDrawingUsesLineFragmentOrigin
                          attributes:@{NSFontAttributeName:self.lblCategoryName.font}
                             context:nil];
	
	size = text.size;
    self.lblCategoryName.frame = CGRectMake(self.lblCategoryName.frame.origin.x, self.lblCategoryName.frame.origin.y, (size.width>150)?(150):(size.width+4), self.lblCategoryName.frame.size.height);
	self.lblCategoryName.text = str;
    [self.lblCategoryName setTextColor:[UIColor whiteColor]];
	[self.lblCategoryName setBackgroundColor:[Validation getColorForAlphabet:self.lblCategoryName.text]];
    
    //------------------------sub category
    
    //sub category
    NSString *str1 = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_SUB_CATEGORY]];
    if ([DataValidation checkNullString:str1].length > 0) {
        size = self.categorySize;
        text = [str1 boundingRectWithSize:size
                                  options:NSStringDrawingUsesLineFragmentOrigin
                               attributes:@{NSFontAttributeName:self.lblSubCategoryName.font}
                                  context:nil];
        size = text.size;
        
        self.lblSubCategoryName.frame = CGRectMake(self.lblSubCategoryName.frame.origin.x, self.lblSubCategoryName.frame.origin.y, (size.width>150)?(150):(size.width+4), self.lblSubCategoryName.frame.size.height);
        self.lblSubCategoryName.text = str1;
        [self.lblSubCategoryName setTextColor:[Validation getColorForAlphabet:self.lblCategoryName.text]];
    }
    
    if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON] && [DataValidation checkNullString:[dic valueForKey:FULL_DESCRIPTION]].length != 0) {
        self.viewBlabFullDesc.layer.masksToBounds = YES;
        [self.viewBlabFullDesc.layer setCornerRadius:5.0];
        self.lblBlabFullDesc.text = [dic valueForKey:FULL_DESCRIPTION];
        self.lblBlabFullDesc.lineBreakMode= NSLineBreakByWordWrapping;
        CGRect lblBlabFullDescSize = [self getHeight:self.lblBlabFullDesc.text];
        self.lblBlabFullDesc.textAlignment = NSTextAlignmentLeft;
        self.viewBlabFullDesc.frame = CGRectMake(self.viewBlabFullDesc.frame.origin.x, self.viewBlabFullDesc.frame.origin.y, lblBlabFullDescSize.size.width+14, lblBlabFullDescSize.size.height+6);
        self.lblBlabFullDesc.frame = CGRectMake(5, 2, lblBlabFullDescSize.size.width, lblBlabFullDescSize.size.height);
//        self.lblBlabFullDesc.backgroundColor = [UIColor redColor];
//        CGRectIntegral( self.lblBlabFullDesc.frame);
    }
    else{
        self.viewBlabFullDesc.hidden = YES;
    }

    //--------
    
    if ([strUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
        //it is user, so show right side
        [self setRightSideControls];
    }
    else{
        [self setLeftSideControls];
    }
    
    NSString *strGroupId = [NSString stringWithFormat:@"%@",[dic valueForKey:@"GroupIDs"]];
    if ([DataValidation checkNullString:strGroupId].length >0 && ([strGroupId intValue]!=0)) {
        self.btnBlabCreatorName.hidden = NO;
        self.btnBlabCreatorImage.hidden = NO;
        self.btnBlabCreatorName.frame = self.lblBlabCreatorName.frame;
        self.btnBlabCreatorImage.frame = self.imgPlayContainer.frame;
        
    }
    else{
        self.btnBlabCreatorName.hidden = YES;
        self.btnBlabCreatorImage.hidden = YES;
    }
    
    NSLog(@"NSStringFromCGRect %@",NSStringFromCGRect(self.imgPlayContainer.frame));
    
    if ([[dic valueForKey:IS_SELECTED] boolValue]) {
        [self.imgSelected setHidden:NO];
        [self.imgSelected setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
    }
    else{
        if (isEdit) {
            [self.imgSelected setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication]];
        }
        else{
            [self.imgSelected setHidden:YES];
        }
    }

    if ([[dic valueForKey:IS_LIKE] boolValue]) {
        [self.btnLike setImage:[UIImage imageNamed:Btn_Like] forState:UIControlStateNormal];
    }
    else{
        [self.btnLike setImage:[UIImage imageNamed:Btn_UnLike] forState:UIControlStateNormal];
    }
    
}
-(IBAction)btnBlabCreatorName_Clicked:(id)sender{
    [self.delegate btnBlabCreatorName_Clicked:self.dicSelected];
}
-(IBAction)btnBlabCreatorImage_Clicked:(id)sender{
    [self.delegate btnBlabCreatorImage_Clicked:self.dicSelected];
}
- (CGRect)getHeight:(NSString *)strText{
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    //    CGSize size = CGSizeMake(self.lblTime.frame.size.width+50, self.lbl.frame.size.height);
    CGRect size =  [strText boundingRectWithSize:CGSizeMake(WIDTH_DESC-5, 20000)
                                         options:NSStringDrawingUsesLineFragmentOrigin
                                      attributes:@{NSFontAttributeName:self.lblBlabFullDesc.font,NSParagraphStyleAttributeName:paragraphStyle}
                                         context:nil];
    
    return size;
}
@end
