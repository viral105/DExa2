//
//  ConversaionWithStickerCell.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 05/02/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "ConversaionWithStickerCell.h"

#define IS_SELECTED             @"is_selected"


@implementation ConversaionWithStickerCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setRightSideControls{
    float xStart = DEVICE_WIDTH-10;
    float yStart = 16;
    
    xStart -= 75;
    self.imgPlayContainer.frame = CGRectMake(xStart, yStart, 75, 75);
    
    xStart-= 10;            //distance
    yStart += (self.imgPlayContainer.frame.size.height-15);
    self.imgTimer.frame = CGRectMake(xStart-12, yStart, 12, 12);
    
    
    self.imgUserThumb.frame  = CGRectMake(xStart-self.imgUserThumb.frame.size.width, yStart-55, self.imgUserThumb.frame.size.width, self.imgUserThumb.frame.size.width);       self.btnUserThumb.frame = self.imgUserThumb.frame;

    
    self.lblBlabCreatorName.frame = CGRectMake(xStart-self.lblBlabCreatorName.frame.size.width, yStart-18, self.lblBlabCreatorName.frame.size.width, 15);

    
    xStart -= (15);
    xStart -= self.lblDuration.frame.size.width;
    
    self.lblDuration.frame = CGRectMake(xStart, yStart, self.lblDuration.frame.size.width, 12);

    self.lblDuration.textAlignment = NSTextAlignmentRight;
    self.imgSelected.frame = CGRectMake(10, self.imgPlayContainer.frame.origin.y, 30, 30);
    
    self.lblBlabCreatorName.textAlignment = NSTextAlignmentRight;
    self.lblDuration.textAlignment = NSTextAlignmentRight;
}

-(void)setLeftSideControls{
    
    float xStart = 10;
    float yStart = 16;
    
    self.imgPlayContainer.frame = CGRectMake(xStart, yStart, 75, 75);
    
    
    xStart += self.imgPlayContainer.frame.size.width+10;
    yStart += (self.imgPlayContainer.frame.size.height-15);
    
    self.imgTimer.frame = CGRectMake(xStart, yStart, 12, 12);
    

    self.imgUserThumb.frame  = CGRectMake(xStart, yStart-55, self.imgUserThumb.frame.size.width, self.imgUserThumb.frame.size.width);       self.btnUserThumb.frame = self.imgUserThumb.frame;
    self.lblBlabCreatorName.frame = CGRectMake(xStart, yStart-18, self.lblBlabCreatorName.frame.size.width, 15);
    xStart += 15;
    
    self.lblDuration.frame = CGRectMake(xStart, yStart, self.lblDuration.frame.size.width, 12);
    xStart = self.imgPlayContainer.frame.origin.x;

    
//    self.btnPlayContainer.frame = self.imgPlay.frame;

    
    self.imgSelected.frame = CGRectMake(self.frame.size.width-40, self.imgPlayContainer.frame.origin.y, 30, 30);
    
    
    self.lblBlabCreatorName.textAlignment = NSTextAlignmentLeft;
    self.lblDuration.textAlignment = NSTextAlignmentLeft;

}

-(void)setControlsInCellWithDictionary:(NSDictionary *)dic withUserId:(NSString *)strUserId isEdit:(BOOL)isEdit{

    self.dicSelected = dic;
    self.imgPlayContainer.image = nil;
    self.imgPlayContainer.imageURL = nil;
    
    self.lblDuration.font = [UIFont fontWithName:Font_OpneSans_SemiBol size:10];
    self.lblBlabCreatorName.font = [UIFont fontWithName:Font_Montserrat_Regular size:14];

    [self.contentView bringSubviewToFront:self.imgPlayContainer];
    self.imgPlayContainer.imageURL = [NSURL URLWithString:[dic valueForKey:@"ImagePath"]];

    if ([strUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
        self.imgUserThumb.imageURL = [NSURL URLWithString:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]];
    }
    else{
        self.imgUserThumb.imageURL = [NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]];
    }
    
    [Validation setCorners:self.imgUserThumb];
    
    NSString *str = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_SENT_BEFORE]];
	self.lblDuration.text = str;
	CGSize size = CGSizeMake(100, self.lblDuration.frame.size.height);
	CGRect text = [str boundingRectWithSize:size
                                    options:NSStringDrawingUsesLineFragmentOrigin
                                 attributes:@{NSFontAttributeName:self.lblDuration.font}
                                    context:nil];
	float xStart = self.lblDuration.frame.origin.x;
	
	size = text.size;
	self.lblDuration.frame = CGRectMake(xStart, self.lblDuration.frame.origin.y, size.width, self.lblDuration.frame.size.height);
    
    //creator's name
    if ([strUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
        //        str = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:USER_NAME]];
        str = [NSString stringWithFormat:@"Me"];
    }else{
        str = [NSString stringWithFormat:@"%@",[dic valueForKey:NAME]];
    }
    size = self.categorySize;
    NSMutableParagraphStyle *paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.lineBreakMode = NSLineBreakByTruncatingTail;
    
    text = [str boundingRectWithSize:size
                             options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                          attributes:@{NSFontAttributeName:self.lblBlabCreatorName.font, NSParagraphStyleAttributeName: paragraph}
                             context:nil];
	size = text.size;
    self.lblBlabCreatorName.frame = CGRectMake(self.lblBlabCreatorName.frame.origin.x, self.lblBlabCreatorName.frame.origin.y, (size.width>150)?(150):(size.width+4), self.lblBlabCreatorName.frame.size.height);
	self.lblBlabCreatorName.text = str;
	[self.lblBlabCreatorName setTextColor:(str.length >0)?[Validation getColorForAlphabet:self.lblBlabCreatorName.text]:[UIColor blackColor]];
    
    
    
    if ([strUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
        //it is user, so show right side
        [self setRightSideControls];
    }
    else{
        [self setLeftSideControls];
    }
    NSString *strGroupId = [NSString stringWithFormat:@"%@",[dic valueForKey:@"GroupIDs"]];
    if ([DataValidation checkNullString:strGroupId].length >0 && ([strGroupId intValue]!=0)) {
        self.btnBlabCreatorName.hidden = NO;
        self.btnBlabCreatorImage.hidden = NO;
        self.btnBlabCreatorName.frame = self.lblBlabCreatorName.frame;
        self.btnBlabCreatorImage.frame = self.imgUserThumb.frame;
        
    }
    else{
        self.btnBlabCreatorName.hidden = YES;
        self.btnBlabCreatorImage.hidden = YES;
    }
    NSLog(@"NSStringFromCGRect %@",NSStringFromCGRect(self.imgPlayContainer.frame));
   
    if ([[dic valueForKey:IS_SELECTED] boolValue]) {
        [self.imgSelected setHidden:NO];
        [self.imgSelected setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
    }
    else{
        if (isEdit) {
            [self.imgSelected setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication]];
        }
        else{
            [self.imgSelected setHidden:YES];
        }
    }
}
-(IBAction)btnBlabCreatorName_Clicked:(id)sender{
    [self.delegate btnBlabCreatorName_Clicked:self.dicSelected];
}
-(IBAction)btnBlabCreatorImage_Clicked:(id)sender{
    [self.delegate btnBlabCreatorImage_Clicked:self.dicSelected];
}
@end
