//
//  ConversaionWithStickerCell.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 05/02/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ConversaionWithStickerCellDelegate <NSObject>

-(void)btnBlabCreatorName_Clicked:(NSDictionary *)dic;
-(void)btnBlabCreatorImage_Clicked:(NSDictionary *)dic;

@end

@interface ConversaionWithStickerCell : UITableViewCell

@property (nonatomic, retain) IBOutlet AsyncImageView      *imgPlayContainer;

@property (nonatomic, retain) IBOutlet UIImageView      *imgTimer;
@property (nonatomic, strong) IBOutlet UILabel          *lblDuration;

@property (nonatomic, strong) IBOutlet UIImageView      *imgSelected;
@property (nonatomic, strong) IBOutlet UILabel          *lblBlabCreatorName;
@property (nonatomic, strong) IBOutlet UIButton         *btnBlabCreatorName;
@property (nonatomic, strong) IBOutlet UIButton         *btnBlabCreatorImage;

@property (nonatomic, readwrite) CGSize                 categorySize;

@property (nonatomic, retain) IBOutlet AsyncImageView   *imgUserThumb;
@property (nonatomic, retain) IBOutlet UIButton         *btnUserThumb;

@property (nonatomic, strong) NSDictionary          *dicSelected;
@property (nonatomic, strong) id<ConversaionWithStickerCellDelegate> delegate;

-(void)setControlsInCellWithDictionary:(NSDictionary *)dic withUserId:(NSString *)strUserId isEdit:(BOOL)isEdit;
@end
