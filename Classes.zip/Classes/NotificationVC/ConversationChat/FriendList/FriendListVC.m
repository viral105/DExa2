//
//  FriendListVC.m
//  WWHHAAZZAAPP
//
//  Created by multicoreViral on 10/7/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "FriendListVC.h"
#import "UserCell.h"
#import "NotifOptionVC.h"
#import "CaptureImageVC.h"
#import "MBProgressHUD.h"
#import "CreateGrpWithSelected.h"
#import "ASIFormDataRequest.h"

#define IS_SELECTED			@"is_selected"
#define ScrollHeight		30
#define SelectedSection		@"selectedSection"
#define SelectedRow			@"selectedRow"

@interface FriendListVC ()<MBProgressHUDDelegate> {
    MBProgressHUD *HUD;
    NSMutableArray *arrTemp;
}
@property (nonatomic,strong) NSMutableArray *arrTemp;

@end

@implementation FriendListVC
@synthesize arrTemp;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self performSelector:@selector(LoadViewSetting)];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    self.progress = [[UIProgressView alloc] initWithFrame:CGRectZero];
    [self.progress setProgressViewStyle: UIProgressViewStyleBar];
    
    [self.progress setFrame:CGRectMake(([[UIScreen mainScreen]bounds].size.height-160)/2,181,160,10)];
    [self.view addSubview:self.progress];
    self.arrData = [[NSMutableArray alloc] init];
    self.sections = [[NSMutableDictionary alloc] init];
    self.arrTemp = [NSMutableArray new];
    
    self.isNotifSendToAll = NO;
    [self.tblData registerNib:[UINib nibWithNibName:@"UserCell" bundle:nil] forCellReuseIdentifier:@"cellIdentifier"];
    
    self.pageCounter = 1;
    
    self.isReloadData = YES;
    
    NSLog(@"self.dicSel--> %@",self.dicSel);
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    appDelegate.currentVc = self;
    
    [Validation removeAdviewFromSuperView];
    
    if (self.btnNext.hidden) {
        [self.view addSubview:[Validation sharedBannerView]];
        [Validation ResizeViewForAds];
    }
    if (self.isReloadData) {
        self.isReloadData = NO;
        [HUD show:YES];
        
        [self performSelectorInBackground:@selector(getMyFriendList) withObject:nil];
    }
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [Validation increaseTableSize];
    appDelegate.isShouldShowReplyPopUp = NO;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark

-(void)LoadViewSetting{
    
    self.view.backgroundColor = UIColorFromRGB(0Xefefef);
    [self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    
    [self.btnSelectAll setTitleColor:UIColorFromRGB(0X5d6970) forState:UIControlStateNormal];
    [self.btnSelectAll.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Bold size:16]];
    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
    [self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
 {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */
- (IBAction)btnBack_Clicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)getMyFriendList{
    
    if (self.request !=nil) {
        self.request = nil;
    }
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"100"],KeyValue,@"PageSize",KeyName, nil],@"3",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_MYFRIENDS_LIST withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }
    //    [self.request setDelegate:self];
    //    [self.request setTag:2];
    
    strUrl = nil;
}

-(void)SetSectionArrayToLoadData{
    
    BOOL  found = NO;
    
    for (NSDictionary *user in self.arrData)
    {
        NSString *strName = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[user objectForKey:NAME]]];
        
        if (strName.length == 0) {
            strName = [NSString stringWithFormat:@"%@",[user objectForKey:USER_NAME]];
        }
        strName = [strName lowercaseString];
        
        NSString *c = [strName substringToIndex:1];
        
        found = NO;
        
        for (NSString *str in [self.sections allKeys])
        {
            if ([str isEqualToString:c])
            {
                found = YES;
                [[self.sections objectForKey:[strName substringToIndex:1]] addObject:user];
            }
        }
        
        if (!found)
        {
            [self.sections setValue:[[NSMutableArray alloc] init] forKey:c];
            [[self.sections objectForKey:[strName substringToIndex:1]] addObject:user];
        }
    }
    
    for (NSString *key in [self.sections allKeys])
    {
        [[self.sections objectForKey:key] sortUsingDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:NAME ascending:YES]]];
    }
    
    [self.sections setValue:[[NSMutableArray alloc] init] forKey:@"zoo"];
    
    //NSLog(@"Sections = %@",self.sections);
    
    [self.tblData reloadData];
}

-(IBAction)btnSelectAll:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    [UIView beginAnimations:@"moveDown" context:nil];
    [UIView setAnimationDuration:0.5];
    self.tblData.frame = CGRectMake(0, 100, 320, DEVICE_HEIGHT-100);
    [UIView commitAnimations];
    
    [[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self.arrSelected removeAllObjects];
    [self showSelectedUsersOnTop];
    
    NSArray *arrKeyName = [NSArray arrayWithArray:(NSArray *)[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)]];
    NSLog(@"key name = %@",arrKeyName);
    
    NSMutableDictionary *sectionToMute = [NSMutableDictionary dictionaryWithDictionary:self.sections];
    if (!self.isNotifSendToAll) {
        
        [btn setImage:[UIImage imageNamed:Btn_selectedUserIndication] forState:UIControlStateNormal];
        self.viewSearch.hidden = YES;
        if (self.arrSelected==nil) {
            self.arrSelected = [[NSMutableArray alloc] init];
        }
        for (int i =0; i<arrKeyName.count; i++) {
            //section loop
            int count = 0;
            NSArray *arrRow = [sectionToMute valueForKey:[arrKeyName objectAtIndex:i]];
            for (int y = 0; y< arrRow.count; y++) {
                NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arrRow objectAtIndex:y]];
                
                if (![[NSString stringWithFormat:@"%@",[dic1 valueForKey:IS_USER_BLOCKED]] boolValue]) {
                    //                    if ([[dic1 valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
                    //                    }
                    //                    else{
                    [dic1 setValue:@"1" forKey:IS_SELECTED];
                    [[self.sections valueForKey:[arrKeyName objectAtIndex:i]] replaceObjectAtIndex:count withObject:dic1];
                    [dic1 setValue:[NSNumber numberWithInteger:i] forKey:SelectedSection];
                    [dic1 setValue:[NSNumber numberWithInteger:count] forKey:SelectedRow];
                    [self.arrSelected addObject:dic1];
                    //                    }
                }
                
                dic1 = nil;
                
                count ++;
            }
        }
        
        [self.tblData reloadData];
        //        self.tblData.alpha = 0.5;
        self.isNotifSendToAll = YES;
        self.btnNext.hidden= NO;
        [Validation removeAdviewFromSuperView];
        NSLog(@"count = %d",(int)[self.arrSelected count]);
    }
    else{
        
        [btn setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication] forState:UIControlStateNormal];
        self.viewSearch.hidden = NO;
        
        for (int i =0; i<arrKeyName.count; i++) {
            //section loop
            int count = 0;
            NSArray *arrRow = [self.sections valueForKey:[arrKeyName objectAtIndex:i]];
            for (int y = 0; y< arrRow.count; y++) {
                NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arrRow objectAtIndex:y]];
                if ([[dic1 valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
                    [dic1 setValue:@"0" forKey:IS_SELECTED];
                    [[self.sections valueForKey:[arrKeyName objectAtIndex:i]] replaceObjectAtIndex:count withObject:dic1];
                    [dic1 setValue:[NSNumber numberWithInteger:i] forKey:SelectedSection];
                    [dic1 setValue:[NSNumber numberWithInteger:count] forKey:SelectedRow];
                }
                else{
                    
                }
                dic1 = nil;
                count ++;
            }
        }
        [self.arrSelected removeAllObjects];
        [self.tblData reloadData];
        self.tblData.alpha = 1.0;
        self.isNotifSendToAll = NO;
        
        self.tblData.frame = CGRectMake(0, 100, 320, DEVICE_HEIGHT-100);
        self.btnNext.hidden = TRUE;
        [self.view addSubview:[Validation sharedBannerView]];
    }
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 1) {
        //unfrind user
        if (buttonIndex == alertView.cancelButtonIndex) {
            
        }
        else{
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:self.selectedUserIndexPath.section]] objectAtIndex:self.selectedUserIndexPath.row]];
            
            
            
            
            [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:self.selectedUserIndexPath.section]] removeObjectAtIndex:self.selectedUserIndexPath.row];
            
            if ([[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:self.selectedUserIndexPath.section]] count] == 0) {
                NSLog(@"count = %@",[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:self.selectedUserIndexPath.section]);
                [self.sections removeObjectForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:self.selectedUserIndexPath.section]];
                
            }
            
            
            int index = -1;
            if (self.arrSelected.count >0) {
                index = (int)[self.arrSelected indexOfObject:dic];
                NSLog(@"%d",index);
            }
            if (index > -1 && index < self.arrData.count) {
                [self.arrSelected removeObjectAtIndex:index];
            }
            
            [self.tblData reloadData];
            
            [[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
            
            [self showSelectedUsersOnTop];
            
            
            if (self.request !=nil) {
                self.request = nil;
            }
            NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                                  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                                  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dic valueForKey:USER_ID] ],KeyValue,@"FriendID",KeyName, nil],@"2",
                                  nil];
            
            NSString *strUrl = [WebServiceContainer getServiceURL:UNFRIEND_A_FRIEND withParameters:nil];
            self.request = [AFNetworkingDataTransaction sharedManager];
            [self.request SetCallForURL:strUrl WithDic:dic1 isAddHeader:TRUE];
            if (self.request._currentRequest == nil) {
                [HUD hide:YES];
            }
            else{
                [self.request setDelegate:self];
                [self.request setTag:5];
            }
            //            [self.request setDelegate:self];
            //            [self.request setTag:5];
            strUrl = nil;
            
            
        }
    }
}

-(void)btnUnfriendClicked:(id)sender{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tblData];
    NSIndexPath *indexPath = [self.tblData indexPathForRowAtPoint:buttonPosition];
    NSLog(@"indexpath = %@",indexPath);
    self.selectedUserIndexPath = indexPath;
    
    
    [AlertHandler alertTitle:CONFIRM message:@"Are you sure you want to unfriend selected friend?" delegate:self tag:1 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
    
}

-(IBAction)btnNextClicked:(id)sender{
    [Validation CancelOnGoingRequests:self.request];
    
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
    self.request = nil;
    
    NSLog(@"arrSelected => %@",self.arrSelected);
    if (self.arrSelected.count!=0) {
        [self callSendMsg];
    }
    else{
        [AlertHandler alertTitle:ALERT message:@"Please select any one friend." delegate:self tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
}

-(void)callSendMsg{
    BOOL isGroupMessage = FALSE;
    //    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData lastObject]];
    //    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:self.dicConversationDetail];
    NSString *strMsgType;
    NSString *strMsg;
    switch (self.index) {
        case 0:
            strMsgType = @"4";
            strMsg = [NSString stringWithFormat:@"Click here to check out @%@'s profile that %@ wants you to see",self.strShareName,[[NSUserDefaults standardUserDefaults] objectForKey:NAME]];
            break;
        case 1:
            strMsgType = @"5";
            strMsg = [NSString stringWithFormat:@"Click here to see the Channel #%@ that was shared with you by %@ ",self.strShareChannelName,self.strShareName];
            break;
        default:
            break;
    }
    NSData *plainData = [strMsg dataUsingEncoding:NSUTF8StringEncoding];
    NSString *base64String = [plainData base64EncodedStringWithOptions:0];
    NSLog(@"%@", base64String);
    
    UIImage *img = nil;
    //------
    
    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"1",
                          [NSDictionary dictionaryWithObjectsAndKeys:(isGroupMessage)?@"":[NSString stringWithFormat:@"%@",[[self.arrSelected valueForKey:USER_ID] componentsJoinedByString:@"|"]],KeyValue,@"ReceiverIDs",KeyName, nil],@"2",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"Ctype",KeyName, nil],@"3",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"GroupIDs",KeyName, nil],@"4",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SubCatID",KeyName, nil],@"5",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"6",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"AllFriend",KeyName, nil],@"7",
                          [NSDictionary dictionaryWithObjectsAndKeys:((img!= nil)?img:@""),KeyValue,@"ImgData",KeyName, nil],@"8",
                          [NSDictionary dictionaryWithObjectsAndKeys:base64String,KeyValue,@"Caption",KeyName, nil],@"9",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue, IsPublicImg,KeyName, nil],@"10",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"2",KeyValue, RequestedKeepStatus, KeyName, nil],@"11",
                          // [NSDictionary dictionaryWithObjectsAndKeys:@"1",KeyValue,@"TypeID",KeyName, nil],@"13",
                          [NSDictionary dictionaryWithObjectsAndKeys:strMsgType,KeyValue, BlabType, KeyName, nil],@"12",
                          [NSDictionary dictionaryWithObjectsAndKeys:self.strShareId,KeyValue, @"NewSoundID", KeyName, nil],@"13",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"14",
                          nil];
    
    
    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];
    
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic1 isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:4];
    }
    //    [obj setDelegate:self];
    //    [obj setTag:4];
    strUrl = nil;
    
    [HUD show:YES];
}

-(IBAction)btnGoToGroupClicked:(id)sender{
    //	[Validation CancelOnGoingRequests:self.request];
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
    self.request = nil;
    [self performSegueWithIdentifier:GROUP_LIST_VC sender:nil];
}

#pragma mark  UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [[self.sections allKeys] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 45;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    NSString *strChar = [[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section];
    UIView *view = [[UIView alloc] init];
    [view setBackgroundColor:[UIColor clearColor]];
    
    if (![strChar isEqualToString:@"zoo"]) {
        
        UILabel *lblTitle = [[UILabel alloc] init];
        [lblTitle setBackgroundColor:[Validation getColorForAlphabet:strChar]];
        lblTitle.frame = CGRectMake(tableView.frame.size.width-50, 5, 40, 40);
        [lblTitle setTextColor:[UIColor whiteColor]];
        lblTitle.textAlignment = NSTextAlignmentCenter;
        [lblTitle setText:[strChar uppercaseString]];
        [Validation setCorners:lblTitle];
        [view addSubview:lblTitle];
        lblTitle = nil;
    }
    return view;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 90;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section]] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    //NSLog(@"%@",[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row]);
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row]];
    
    UserCell *cell = (UserCell *)[tableView dequeueReusableCellWithIdentifier:@"cellIdentifier"];
    cell.isUserSelectionInView = YES;
    cell.ProfileImg.image = nil;
    cell.ProfileImg.imageURL = nil;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    [cell setBoxValuesWithData:dic];
    [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
    [cell.imgFriendshipStatus setHidden:TRUE];
    
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_USER_BLOCKED]] boolValue]) {
        [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_User_Blocked]];
        cell.imgFriendshipStatus.hidden = FALSE;
        cell.btnUserBlocked.hidden = YES;
    }
    else{
        if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
            [cell.imgFriendshipStatus setHidden:FALSE];
        }
        else{
            [cell.imgFriendshipStatus setHidden:TRUE];
        }
        
        if ([self.arrSelected count]==0) {
            [cell.imgFriendshipStatus setHidden:TRUE];
            [dic setValue:@"0" forKey:IS_SELECTED];
            [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
        }
        else{
            NSLog(@"arrselected cnt %d %d",(int)[self.arrSelected count],(int)indexPath.row);
            for (int i=0; i<[self.arrSelected count]; i++) {
                NSDictionary *selDic = [self.arrSelected objectAtIndex:i];
                if ([[dic valueForKey:@"ID"] intValue] == [[selDic valueForKey:@"ID"] intValue]) {
                    NSLog(@"seldic name %@",[selDic valueForKey:NAME]);
                    if ([[selDic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
                        NSLog(@"seldic name %@ flag 1",[selDic valueForKey:NAME]);
                        [cell.imgFriendshipStatus setHidden:FALSE];
                        [dic setValue:@"1" forKey:IS_SELECTED];
                        [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
                    }
                    else{
                        NSLog(@"seldic name %@ flag 0",[selDic valueForKey:NAME]);
                        [cell.imgFriendshipStatus setHidden:TRUE];
                        [dic setValue:@"0" forKey:IS_SELECTED];
                        [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
                    }
                    break;
                }
                else{
                    NSLog(@"seldic name %@ flag 0 id not found",[dic valueForKey:NAME]);
                    [cell.imgFriendshipStatus setHidden:TRUE];
                    [dic setValue:@"0" forKey:IS_SELECTED];
                    [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
                }
            }
        }
    }
    
    cell.btnUnfriend.hidden = NO;
    [cell.btnUnfriend addTarget:self action:@selector(btnUnfriendClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    
    cell.imgViewFriendType.hidden = NO;
    switch ([[dic valueForKey:@"FriendType"] intValue]) {
        case 0:
            cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_blabeey.png"];
            break;
        case 1:
            cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_fb.png"];
            break;
        case 2:
            cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_contacts.png"];
            break;
            
        default:
            break;
    }
    dic = nil;
    
    if (indexPath.section == self.sections.count) {
        if (indexPath.row == [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] count]) {
            self.pageCounter++;
            [HUD show:YES];
            [self performSelectorInBackground:@selector(getMyFriendList) withObject:nil];
        }
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //    if (!self.isNotifSendToAll) {
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row]];
    
    
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_USER_BLOCKED]] boolValue]) {
        [AlertHandler alertTitle:MESSAGE message:@"You have blocked this user." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    }
    else{
        UserCell *cell = (UserCell *)[tableView cellForRowAtIndexPath:indexPath];
        
        if (self.arrSelected==nil) {
            self.arrSelected = [[NSMutableArray alloc] init];
        }
        
        int index = -1;
        if (self.arrSelected.count >0) {
            index = (int)[self.arrSelected indexOfObject:dic];
            NSLog(@"%d",index);
        }
        
        
        if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
            //so deselect it
            [dic setValue:@"0" forKey:IS_SELECTED];
            [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
            cell.imgFriendshipStatus.hidden = TRUE;
            self.isNotifSendToAll = NO;
            self.viewSearch.hidden = NO;
            [self.btnSelectAll setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication] forState:UIControlStateNormal];
            if (index > -1 && index < self.arrData.count) {
                [self.arrSelected removeObjectAtIndex:index];
            }
            else{
                for (int i=0; i<self.arrSelected.count; i++) {
                    NSDictionary *selDic = [self.arrSelected objectAtIndex:i];
                    if ([[selDic valueForKey:@"ID"] intValue]==[[dic valueForKey:@"ID"] intValue]) {
                        [self.arrSelected removeObjectAtIndex:i];
                        break;
                    }
                }
            }
            [[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
            
        }
        else{
            [dic setValue:@"1" forKey:IS_SELECTED];
            [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
            cell.imgFriendshipStatus.hidden = FALSE;
            [dic setValue:[NSNumber numberWithInteger:indexPath.section] forKey:SelectedSection];
            [dic setValue:[NSNumber numberWithInteger:indexPath.row] forKey:SelectedRow];
            [self.arrSelected addObject:dic];
        }
        
        [self showSelectedUsersOnTop];
        NSLog(@"%@",self.sections);
        
    }
    
    //    }
    
}

-(void)showSelectedUsersOnTop{
    
    if (self.arrSelected.count>0) {
        
        [UIView beginAnimations:@"moveUp" context:nil];
        //[UIView setAnimationBeginsFromCurrentState:YES];
        [UIView setAnimationDuration:0.5];
        //		self.tblData.frame = CGRectMake(0, 68+ScrollHeight+5, 320, DEVICE_HEIGHT-(68+ScrollHeight+8));
        self.tblData.frame = CGRectMake(0, 100+ScrollHeight+5, 320, DEVICE_HEIGHT-(100+ScrollHeight+8));
        
        [UIView commitAnimations];
        
        if (self.scrollContainer == nil) {
            //			self.scrollContainer = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 68, 320, ScrollHeight)];
            self.scrollContainer = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 100, 320, ScrollHeight)];
            [self.view addSubview:self.scrollContainer];
            [self.scrollContainer setShowsHorizontalScrollIndicator:FALSE];
            [self.scrollContainer setShowsVerticalScrollIndicator:FALSE];
        }
        
        float xStart = 10;
        //      float scrollPosition = 10;
        for (int i=0; i<self.arrSelected.count; i++) {
            
            float X = 5;
            UIView *view = [[UIView alloc] init];
            UILabel *lblName = [[UILabel alloc] init];
            UIButton *btnRemove = [UIButton buttonWithType:UIButtonTypeCustom];
            
            lblName.font = [UIFont fontWithName:Font_Montserrat_Regular size:14];
            lblName.textColor = [UIColor whiteColor];
            
            NSDictionary *dic = [self.arrSelected objectAtIndex:i];
            NSString *strName = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:NAME]]];
            if (strName.length == 0) {
                strName = [NSString stringWithFormat:@"%@",[dic valueForKey:USER_NAME]];
            }
            
            CGSize size = CGSizeMake(1000, 46);
            CGRect text = [strName boundingRectWithSize:size
                                                options:NSStringDrawingUsesLineFragmentOrigin
                                             attributes:@{NSFontAttributeName:lblName.font}
                                                context:nil];
            
            size = text.size;
            view.frame = CGRectMake(xStart, 0, size.width+30, ScrollHeight);
            //			view.backgroundColor = [Validation getColorForAlphabet:[strName substringToIndex:1]];
            view.backgroundColor = [Validation getColorForAlphabet:strName];
            
            lblName.text = strName;
            lblName.frame = CGRectMake(X, 0, size.width+4, ScrollHeight);
            
            btnRemove.frame = CGRectMake(X, 0, view.frame.size.width-(X*2), ScrollHeight);
            [btnRemove setTitle:@"x" forState:UIControlStateNormal];
            [btnRemove setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
            btnRemove.tag = i;
            [btnRemove addTarget:self action:@selector(removeSelectedUserFromList:) forControlEvents:UIControlEventTouchUpInside];
            [view addSubview:lblName];
            [view addSubview:btnRemove];
            [self.scrollContainer addSubview:view];
            
            view.tag = i;
            lblName = nil;
            btnRemove = nil;
            
            //			if (i==self.arrSelected.count-1) {
            //
            //                scrollPosition = view.frame.size.width+5;
            //
            //			}
            //            else{
            //                self.scrollContainer.contentOffset = CGPointMake(xStart, self.scrollContainer.contentOffset.y);
            //            }
            xStart += (view.frame.size.width+5);
            
        }
        
        self.scrollContainer.contentSize = CGSizeMake(xStart, ScrollHeight);
        [UIView beginAnimations:@"ScrollToEnd" context:nil];
        //[UIView setAnimationBeginsFromCurrentState:YES];
        [UIView setAnimationDuration:0.5];
        self.scrollContainer.contentOffset = CGPointMake((xStart>320)?(xStart-320):0, self.scrollContainer.contentOffset.y);
        [UIView commitAnimations];
        
        
        
        self.btnNext.hidden = FALSE;
        
        [Validation removeAdviewFromSuperView];
        //		[Validation increaseTableSize];
        //		self.tblData.frame = CGRectMake(0, 68+ScrollHeight+5, 320, DEVICE_HEIGHT-(68+ScrollHeight+5));
        self.tblData.frame = CGRectMake(0, 100+ScrollHeight+5, 320, DEVICE_HEIGHT-(100+ScrollHeight+5));
    }
    else{
        [UIView beginAnimations:@"moveDown" context:nil];
        //[UIView setAnimationBeginsFromCurrentState:YES];
        [UIView setAnimationDuration:0.5];
        //		self.tblData.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-64);
        self.tblData.frame = CGRectMake(0, 100, 320, DEVICE_HEIGHT-100);
        self.btnNext.hidden = TRUE;
        [UIView commitAnimations];
        
        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        //[Validation ResizeViewForAds];
    }
}

-(void)removeSelectedUserFromList:(id)sender{
    
    NSLog(@"arrB4Delete = %@",self.arrSelected);
    NSMutableDictionary *dic = [self.arrSelected objectAtIndex:((UIButton *)sender).tag];
    //UserCell *cell = (UserCell *)[self.tblData cellForRowAtIndexPath:[NSIndexPath indexPathForRow:[[dic valueForKey:SelectedRow] intValue] inSection:[[dic valueForKey:SelectedSection] intValue]]];
    
    [dic setValue:@"0" forKey:IS_SELECTED];
    //	[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:[[dic valueForKey:SelectedSection] intValue]]] replaceObjectAtIndex:[[dic valueForKey:SelectedRow] intValue] withObject:dic];
    //	cell.imgFriendshipStatus.hidden = TRUE;
    
    [self.arrSelected removeObjectAtIndex:((UIButton *)sender).tag];
    [self.tblData reloadData];
    
    NSLog(@"arrB4Delete = %@",self.arrSelected);
    [[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self showSelectedUsersOnTop];
}


#pragma mark
#pragma mark web service method
/*
 - (void)requestFinished:(ASIHTTPRequest *)request{
 NSError *error = nil;
 
 //	NSLog(@"response =%@",[request responseString]);
 
 NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
 options:0
 error:&error];;
 */
- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
    
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    //NSLog(@"dictionary = %@",dicResponse);
    
    //	[HUD hide:YES];
    //    [HUD hide:YES];
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (tag == 3) {
                [HUD show:YES];
                [self performSelectorInBackground:@selector(getMyFriendList) withObject:nil];
            }
            else{
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        if (tag == 2) {
                            id response = [dicResponse objectForKey:RESPONSE];
                            if (response != nil) {
                                
                                NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                                if (arr.count>0) {
                                    for (int i=0; i<arr.count; i++) {
                                        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[arr objectAtIndex:i]];
                                        [dic setValue:@"0" forKey:IS_SELECTED];
                                        [arr replaceObjectAtIndex:i withObject:dic];
                                        dic = nil;
                                    }
                                }
                                
                                if (self.pageCounter == 1) {
                                    [self.arrData removeAllObjects];
                                    [self.arrTemp removeAllObjects];
                                }
                                [self.arrData addObjectsFromArray:arr];
                                [self.arrTemp addObjectsFromArray:arr];
                                if (arr.count>0) {
                                    [self SetSectionArrayToLoadData];
                                }
                                arr = nil;
                            }
                            self.request = nil;
                            [HUD hide:YES];
                        }
                        else if (tag == 4) {
                            id response = [dicResponse objectForKey:RESPONSE];
                            if (response != nil) {
                                
                                NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                                if (arr.count>0) {
                                    for (int i=0; i<arr.count; i++) {
                                        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[arr objectAtIndex:i]];
                                        [dic setValue:@"0" forKey:IS_SELECTED];
                                        [arr replaceObjectAtIndex:i withObject:dic];
                                        dic = nil;
                                    }
                                }
                                
                                if (self.pageCounter == 1) {
                                    [self.arrData removeAllObjects];
                                    [self.arrTemp removeAllObjects];
                                }
                                [self.arrData addObjectsFromArray:arr];
                                [self.arrTemp addObjectsFromArray:arr];
                                if (arr.count>0) {
                                    [self SetSectionArrayToLoadData];
                                }
                                arr = nil;
                                [self.navigationController popViewControllerAnimated:YES];
                            }
                            self.request = nil;
                            [HUD hide:YES];
                        }
                        else if (tag == 5){
                            id response = [dicResponse objectForKey:RESPONSE];
                            if (response != nil) {
                                [HUD hide:YES];
                                NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                                NSLog(@"arr send alarm req response %@",arr);
                                [self.navigationController popToRootViewControllerAnimated:YES];
                            }
                            else{
                                [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                                [HUD hide:YES];
                            }
                        }
                    }
                    else{
                        [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                        [HUD hide:YES];
                    }
                }
                else{
                    [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                    [HUD hide:YES];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
    dicResponse = nil;
}

- (void)requestFinished:(ASIHTTPRequest *)request{
    NSError *error = nil;
    
    NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
                                                                 options:0
                                                                   error:&error];;
    
    NSLog(@"dicResponse = %@",dicResponse);
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (request.tag == 1) {
                NSLog(@"upload Response");
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            /*
                             {
                             Response =     (
                             {
                             CreateBy = 20190;
                             CreateDate = "2014-10-07T06:04:30.92";
                             DeleteBy = "<null>";
                             DeleteDate = "<null>";
                             FilePath = "http://upload.wwhhaazzuupp.com/UserSound/0_0_EI8V92ME4730748_20190.mp3";
                             Gender = 0;
                             ID = 10257;
                             IsActive = 0;
                             IsDelete = 0;
                             IsPrivate = 1;
                             Name = "";
                             SoundMasterID = 0;
                             SoundSubMasterID = 0;
                             SubType = "<null>";
                             Type = "<null>";
                             UpdateBy = "<null>";
                             UpdateDate = "<null>";
                             UserID = "<null>";
                             }
                             );
                             Status = 1;
                             UserStatus =     {
                             IsActive = 1;
                             IsDelete = 0;
                             Msg = success;
                             status = 1;
                             };
                             }
                             */
                            
                            HUD.mode = MBProgressHUDModeIndeterminate;
                            NSString *strNotifId = [NSString stringWithFormat:@"%@",[response valueForKey:NEW_YAPEEY_ID]];
                            strNotifId = [strNotifId stringByTrimmingCharactersInSet: [[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
                            response = nil;
                        }
                        else{
                            response = nil;
                        }
                    }
                    else{
                        [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                        [HUD hide:YES];
                    }
                }
                else{
                    [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                    [HUD hide:YES];
                }
            }
            else if (request.tag == 2){
                //send notification
                
                NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
                __block UIImageView *imageView;
                UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                imageView = [[UIImageView alloc] initWithImage:image];
                
                HUD.customView = imageView;
                HUD.mode = MBProgressHUDModeText;
                HUD.labelText = @"Sent";
                imageView = nil;
                [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
            }
            else if (request.tag == 3){
                id response = [dicResponse objectForKey:RESPONSE];
                if (response != nil) {
                    [HUD hide:YES];
                    if ([NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]].length!=0 && [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]]]) {
                        [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@",[self.dicSel valueForKey:@"SoundPath"]] error:nil];
                    }
                    NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                    NSLog(@"arr send alarm req response %@",arr);
                    [self.navigationController popToRootViewControllerAnimated:YES];
                }
                else{
                    [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
                    [HUD hide:YES];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
    
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}
-(void)popToNotifListScreen{
    
    [Validation cleanNotifcationRelatedDicData];
    [HUD hide:YES];
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:RECORD_OPTION_VC] || [segue.identifier isEqualToString:CAPTURE_IMAGE_VC]) {
        if (appDelegate.dic_NotificationReleatedData != nil) {
            appDelegate.dic_NotificationReleatedData = nil;
        }
        
        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    [self.arrSelected valueForKey:USER_ID],SelectedIds,
                                                    [NSNumber numberWithBool:FALSE],IS_GroupNotif,
                                                    [NSNumber numberWithBool:self.isNotifSendToAll],IS_NotifSendToAll,
                                                    [NSDictionary dictionaryWithDictionary:self.dicSelectedNotifToForward],SelectedBlabDic,
                                                    
                                                    nil];
        
        
    }
    else if ([segue.identifier isEqualToString:GROUP_LIST_VC]){
        
        if (appDelegate.dic_NotificationReleatedData != nil) {
            appDelegate.dic_NotificationReleatedData = nil;
        }
        
        
        
        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    [NSNumber numberWithBool:TRUE],IS_GroupNotif,
                                                    [NSNumber numberWithBool:NO],IS_NotifSendToAll,
                                                    self.dicSelectedNotifToForward,SelectedBlabDic,
                                                    nil];
    }
    [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
    [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];
    
    NSLog(@"appDelegate.dic_NotificationReleatedData = %@",appDelegate.dic_NotificationReleatedData);
}


- (IBAction)btnCancel_Clicked:(id)sender {
    if (self.arrData.count!=0) {
        [self.arrData removeAllObjects];
    }
    [self.arrData addObjectsFromArray:self.arrTemp];
    [self.sections removeAllObjects];
    [self SetSectionArrayToLoadData];
    [self.tblData reloadData];
    /*    [[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
     if (self.arrSelected.count!=0) {
     [self.arrSelected removeAllObjects];
     }
     [self showSelectedUsersOnTop];
     */
    [self.tfSearch resignFirstResponder];
    self.tfSearch.text = @"";
    [self animate:285 viewToAnimate:self.viewSearch];
}

- (IBAction)btnSearch_Clicked:(id)sender {
    [self animate:4 viewToAnimate:self.viewSearch];
}
-(void)animate:(int)xPoint viewToAnimate:(UIView *)viewToAni{
    [UIView animateWithDuration:0.3 animations:^{
        
        CGRect frame;
        
        // move our subView to its new position
        frame=viewToAni.frame;
        frame.origin.x=xPoint;
        viewToAni.frame=frame;
        viewToAni.alpha=1.0;
        
    }];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (self.arrData.count!=0) {
        [self.arrData removeAllObjects];
    }
    [self.arrData addObjectsFromArray:self.arrTemp];
    
    [self.tfSearch resignFirstResponder];
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if ([string isEqualToString:@"\n"]) {
        return YES;
    }
    //   indexSelUser=-1;
    /*
     [[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
     if (self.arrSelected.count!=0) {
     [self.arrSelected removeAllObjects];
     }
     [self showSelectedUsersOnTop];
     */
    NSString *str = [NSString stringWithFormat:@"%@%@",self.tfSearch.text,string];
    if ([string isEqualToString:@""]) {
        NSLog(@"%@",[self.tfSearch.text substringToIndex:self.tfSearch.text.length-1]);
        NSArray *arr =  [self filterArrayByADictionary:self.arrTemp andKey:[NSString stringWithFormat:@"Name beginswith[c] '%@'",[self.tfSearch.text substringToIndex:self.tfSearch.text.length-1]]];
        
        [self.arrData removeAllObjects];
        [self.arrData addObjectsFromArray:arr];
        [self.sections removeAllObjects];
        if (arr.count>0) {
            [self SetSectionArrayToLoadData];
        }
        
        //      Deleting last char from textfield than display all the friens.
        if (arr.count==0 && [self.tfSearch.text substringToIndex:self.tfSearch.text.length-1].length<=0) {
            [self.arrData addObjectsFromArray:self.arrTemp];
            [self SetSectionArrayToLoadData];
            //            [self.tblData reloadData];
        }
        else{
            [self.tblData reloadData];
        }
        //        [self.tblData reloadData];
        arr = nil;
    }
    else{
        NSArray *arr =  [self filterArrayByADictionary:self.arrTemp andKey:[NSString stringWithFormat:@"Name beginswith[c] '%@'",str]];
        [self.arrData removeAllObjects];
        [self.arrData addObjectsFromArray:arr];
        [self.sections removeAllObjects];
        if (arr.count>0) {
            [self SetSectionArrayToLoadData];
        }
        else{
            [self.tblData reloadData];
        }
        
        
        arr = nil;
    }
    
    return YES;
}
-(NSArray *)filterArrayByADictionary:(NSMutableArray *)aArray andKey:(NSString *)aPredicte
{
    NSPredicate *filter = [NSPredicate predicateWithFormat:aPredicte];
    return [aArray filteredArrayUsingPredicate:filter];
}

@end
