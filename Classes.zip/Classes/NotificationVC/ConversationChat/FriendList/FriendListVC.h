//
//  FriendListVC.h
//  WWHHAAZZAAPP
//
//  Created by multicoreViral on 10/7/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIFormDataRequest.h"

@interface FriendListVC : UIViewController<UITableViewDataSource, UITableViewDelegate,UIActionSheetDelegate,UIAlertViewDelegate,AFNetworkingDataTransactionDelegate,UITextFieldDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, strong) NSMutableDictionary			*sections;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, strong) NSMutableArray				*arrSelected;
@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) AFNetworkingDataTransaction	*request;

@property (strong, nonatomic) IBOutlet UIView *viewSearch;
@property (strong, nonatomic) IBOutlet UITextField *tfSearch;
@property (nonatomic, strong) UIScrollView					*scrollContainer;

@property (nonatomic, strong) IBOutlet UIButton				*btnNext;
@property (nonatomic, strong) IBOutlet UIButton				*btnSelectAll;
@property (nonatomic, strong) IBOutlet UIButton				*btnMenuBack;

//@property (nonatomic, readwrite) int                        ForwardNotifId;
@property (nonatomic, strong) NSDictionary                  *dicSelectedNotifToForward;
@property (nonatomic, strong) NSString *strShareChannelName;
@property (nonatomic, strong) NSString *strShareName;
@property (nonatomic, assign) int index;
@property (nonatomic, strong) NSString *strShareId;
@property (nonatomic, readwrite) BOOL						isNotifSendToAll;
@property (nonatomic, readwrite) BOOL                       isReloadData;
@property (nonatomic, strong) NSIndexPath                   *selectedUserIndexPath;


@property (nonatomic, readwrite) BOOL                       isMultipleUsersSelected;
@property (nonatomic, strong) NSMutableDictionary           *dicSel;

@property (nonatomic, strong) NSTimer                       *timer;
@property (nonatomic, strong) UIProgressView                *progress;
- (IBAction)btnCancel_Clicked:(id)sender;
- (IBAction)btnSearch_Clicked:(id)sender;
@end
