//
//  StickerCell.m
//  WWHHAAZZAAPP
//
//  Created by Nivid Jain on 1/30/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "StickerCell.h"

@implementation StickerCell

@synthesize imgSticker;

- (id)initWithFrame:(CGRect)frame
{
    if ((self = [super initWithFrame:frame]))
    {
        self.imgSticker = [[AsyncImageView alloc]init];
        
      //  imgCategory.imageURL = [NSURL URLWithString:[[_arrCategory objectAtIndex:indexPath.row] valueForKey:@"LogoPath"]];
        self.imgSticker.contentMode = UIViewContentModeScaleAspectFit;
        self.imgSticker.clipsToBounds =  YES;
        self.imgSticker.frame = CGRectMake(0, 0, 50,44);
        [self.contentView addSubview: self.imgSticker];
    }
    return self;
}


@end
