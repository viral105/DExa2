//
//  StickerCell.h
//  WWHHAAZZAAPP
//
//  Created by Nivid Jain on 1/30/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StickerCell : UICollectionViewCell
{
    AsyncImageView *imgSticker;

}

@property (strong,nonatomic)AsyncImageView      *imgSticker;


@end
