//
//  TextBlabVC.m
//  WWHHAAZZAAPP
//
//  Created by multicoreViral on 8/18/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "TextBlabVC.h"

@interface TextBlabVC (){
    MBProgressHUD *HUD;
}

@end

@implementation TextBlabVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    
    [self.tvText becomeFirstResponder];
    
    
    NSArray *arrSelectedIds = [NSArray arrayWithArray:(NSArray *)[appDelegate.dic_NotificationReleatedData valueForKey:SelectedIds]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)btnBack_Clicked:(id)sender{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
-(void)popToNotifListScreen{
//    [Validation cleanNotifcationRelatedDicData];
//    
//    [self.request CancleOngoingRequest];
//    self.request = nil;
    
/*    [HUD hide:YES];
    NSArray *arr = [self.navigationController viewControllers];
    BOOL isGotPopViewController = FALSE;
    
    for (UIViewController *v in arr) {
        if ([v isKindOfClass:[UserConversationChatVC class]]) {
            isGotPopViewController = TRUE;
            [self.navigationController popToViewController:v animated:YES];
        }
    }
*/
    [HUD hide:YES];
    BOOL isGotPopViewController = FALSE;
    if (!isGotPopViewController) {
        
        [self removeViewControllersFromStack];
        
        if (appDelegate.selectedMenuIndex>0) {
            appDelegate.selectedMenuIndex = 0;
        }
        SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
        
        [UIView transitionWithView:self.navigationController.view
                          duration:0.5
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.navigationController pushViewController:ivc animated:NO];
                        }
                        completion:nil];
    }
}
-(void)removeViewControllersFromStack{
    //  NSArray *arrVC = self.navigationController.viewControllers;
    for (id vc in self.navigationController.viewControllers){
        if ([vc isKindOfClass:[FavoritesVC class]]) {
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[NotificationVC class]]) {
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[SearchFriendVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[OtherFriendNotifListVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[SettingsVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[NotifOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[CategoryListForUploadVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[GroupListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[UserListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[RecordingOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
    }
    
}
-(void)removeFromNavigationController:(UIViewController *)controller animated:(BOOL)animated {
    
    NSMutableArray *allViewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];;
    [allViewControllers removeObjectIdenticalTo:controller];
    self.navigationController.viewControllers = allViewControllers;
    
}
-(IBAction)btnSend_Clicked:(id)sender{
    
    NSString *str = [self.tvText.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (str.length>0) {
        //        self.viewContainerTextView.frame = CGRectMake(self.viewContainerTextView.frame.origin.x, DEVICE_HEIGHT-self.viewContainerTextView.frame.size.height, self.viewContainerTextView.frame.size.width, self.viewContainerTextView.frame.size.height);
        //        [self.tvTextBlab resignFirstResponder];
        //        self.viewContainerTextView.hidden = YES;
        //        self.tblData.frame = CGRectMake(self.tblData.frame.origin.x,self.tblData.frame.origin.y, self.tblData.frame.size.width,[UIScreen mainScreen].bounds.size.height-self.tblData.frame.origin.y);
        [self sendTextBlab:str];
    }
    else{
        [Validation showToastMessage:@"Please enter text." displayDuration:ERROR_MSG_DURATION];
    }
}
-(void)sendTextBlab:(NSString*)strText{
    
    NSData *plainData = [strText dataUsingEncoding:NSUTF8StringEncoding];
    NSString *base64String = [plainData base64EncodedStringWithOptions:0];
    NSLog(@"%@", base64String);
    
//    [self AddNewTextBlabInArr:strReceiverId isGroup:isGroupMessage strBase64:base64String];
    
    
    UIImage *img = nil;
    //------
    
    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"1",
                          [NSDictionary dictionaryWithObjectsAndKeys:(self.isGroupMessage)?@"":[NSString stringWithFormat:@"%@",self.strReceiverId],KeyValue,@"ReceiverIDs",KeyName, nil],@"2",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"Ctype",KeyName, nil],@"3",
                          [NSDictionary dictionaryWithObjectsAndKeys:(self.isGroupMessage)?[NSString stringWithFormat:@"%@",self.strReceiverId]:@"0",KeyValue,@"GroupIDs",KeyName, nil],@"4",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SubCatID",KeyName, nil],@"5",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"6",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"AllFriend",KeyName, nil],@"7",
                          [NSDictionary dictionaryWithObjectsAndKeys:((img!= nil)?img:@""),KeyValue,@"ImgData",KeyName, nil],@"8",
                          [NSDictionary dictionaryWithObjectsAndKeys:base64String,KeyValue,@"Caption",KeyName, nil],@"9",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue, IsPublicImg,KeyName, nil],@"10",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"2",KeyValue, RequestedKeepStatus, KeyName, nil],@"11",
                          // [NSDictionary dictionaryWithObjectsAndKeys:@"1",KeyValue,@"TypeID",KeyName, nil],@"13",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"3",KeyValue, BlabType, KeyName, nil],@"12",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"13",
                          nil];
    
    
    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];
    
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic1 isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:1];
    }
    //    [obj setDelegate:self];
    //    [obj setTag:9];
    strUrl = nil;
    
    [HUD show:YES];
    
}

- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
    
    NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    if (dicResponse != nil) {
        
        if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]) {
            
            if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                
                NSLog(@"dic = %@",dicResponse);
                [HUD hide:YES];
                [appDelegate callLogOutService];
            }
            else{
                if (tag == 1) {
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        if ([dicResponse objectForKey:RESPONSE] != nil) {
                            id response = [dicResponse objectForKey:RESPONSE];
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            
                            HUD.mode = MBProgressHUDModeText;
                            HUD.labelText = @"Sent";
                            [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
                            
                            arr = nil;
                            response = nil;
                        }
                        else{
                            [HUD hide:YES];
                        }
                    }
                    else{
                        [HUD hide:YES];
                    }
                }
            }
        }
        else{
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
    }
    else{
        [HUD hide:YES];
    }
    request = nil;
    
    
    //    [self performSelector:@selector(getTestNotif) withObject:nil afterDelay:10];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
