//
//  TextBlabVC.h
//  WWHHAAZZAAPP
//
//  Created by multicoreViral on 8/18/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextBlabVC : UIViewController<AFNetworkingDataTransactionDelegate>

@property (strong, nonatomic) IBOutlet UITextView *tvText;
//@property (strong, nonatomic) NSDictionary *dicConversationDetail;
@property (assign, nonatomic) BOOL isGroupMessage;
@property (strong, nonatomic) NSString *strReceiverId;
@end
