//
//  ConversationTextBlabCell.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 5/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "ConversationTextBlabCell.h"
#define WIDTH_DESC           170
#define WIDTH_LBLTEXT_MORE      15
#define HEIGHT_LBLTEXT_MORE      15
#define IS_SELECTED             @"is_selected"

@implementation ConversationTextBlabCell
/*
- (void)awakeFromNib {
    // Initialization code
}
-(void)setRightSideControls{
    float yPoint=10;
    float xPointViewLblContaner;
    
    self.imgSelected.frame = CGRectMake(10, yPoint, 30, 30);
    
    if (lblText.frame.size.height<19) {
        viewLblContaner.frame = CGRectMake(self.contentView.frame.size.width-lblText.frame.size.width-30, yPoint+15, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
        yPoint+=15;
    }
    else{
        viewLblContaner.frame = CGRectMake(self.contentView.frame.size.width-lblText.frame.size.width-30, yPoint, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
    }
    viewLblContaner.frame = CGRectMake(self.contentView.frame.size.width-lblText.frame.size.width-30, yPoint, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
    lblText.frame = CGRectMake(9, 5, lblText.frame.size.width, lblText.frame.size.height);
    imgViewTextTail.frame = CGRectMake(viewLblContaner.frame.size.width+viewLblContaner.frame.origin.x-7, viewLblContaner.frame.origin.y+viewLblContaner.frame.size.height-5, 14, 7);
    yPoint+=viewLblContaner.frame.size.height+10;
    
//    if (viewLblContaner.frame.size.width>viewButtonContainer.frame.size.width) {
        xPointViewLblContaner = viewLblContaner.frame.origin.x;
/*    }
    else{
        xPointViewLblContaner = self.contentView.frame.size.width-viewButtonContainer.frame.size.width;
    }
comment here
    lblBlabCreatorName.frame = CGRectMake(xPointViewLblContaner-lblBlabCreatorName.frame.size.width-10, viewLblContaner.frame.origin.y+viewLblContaner.frame.size.height-lblBlabCreatorName.frame.size.height, lblBlabCreatorName.frame.size.width, lblBlabCreatorName.frame.size.height);
    
    self.imgUserThumb.frame = CGRectMake(xPointViewLblContaner-self.imgUserThumb.frame.size.width-15, lblBlabCreatorName.frame.origin.y-self.imgUserThumb.frame.size.height-5, self.imgUserThumb.frame.size.width, self.imgUserThumb.frame.size.height);
    
    
    viewButtonContainer.frame = CGRectMake(self.contentView.frame.size.width-viewButtonContainer.frame.size.width-10, yPoint, viewButtonContainer.frame.size.width, viewButtonContainer.frame.size.height);
    
    imgTimer.frame = CGRectMake(viewButtonContainer.frame.origin.x-imgTimer.frame.size.width-10, viewButtonContainer.frame.origin.y+10, imgTimer.frame.size.width, imgTimer.frame.size.height);
    
    lblDuration.frame = CGRectMake(imgTimer.frame.origin.x-40-3, viewButtonContainer.frame.origin.y+10, 40, lblDuration.frame.size.height);
}
-(void)setLeftSideControls{
    float yPoint=10;
    float xPointViewLblContaner;
    
    self.imgSelected.frame = CGRectMake(self.contentView.frame.size.width-40, yPoint, 30, 30);
    if (lblText.frame.size.height<19) {
        viewLblContaner.frame = CGRectMake(17, yPoint+15, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
        yPoint+=15;
    }
    else{
        viewLblContaner.frame = CGRectMake(17, yPoint, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
    }
    
    lblText.frame = CGRectMake(9, 5, lblText.frame.size.width, lblText.frame.size.height);
    imgViewTextTail.frame = CGRectMake(viewLblContaner.frame.origin.x-7, viewLblContaner.frame.origin.y+viewLblContaner.frame.size.height-5, 14, 7);
    
    yPoint+=viewLblContaner.frame.size.height+10;
    
    
//    if (viewLblContaner.frame.size.width>viewButtonContainer.frame.size.width) {
        xPointViewLblContaner = viewLblContaner.frame.origin.x+viewLblContaner.frame.size.width+10;
/*    }
    else{
        xPointViewLblContaner = viewButtonContainer.frame.size.width+20;
    }
comment here
    NSLog(@"----====> %f %f %f",viewLblContaner.frame.size.width,viewButtonContainer.frame.size.width,xPointViewLblContaner);
    
    lblBlabCreatorName.frame = CGRectMake(xPointViewLblContaner, viewLblContaner.frame.origin.y+viewLblContaner.frame.size.height-lblBlabCreatorName.frame.size.height, lblBlabCreatorName.frame.size.width, lblBlabCreatorName.frame.size.height);
    self.imgUserThumb.frame = CGRectMake(xPointViewLblContaner-2, lblBlabCreatorName.frame.origin.y-self.imgUserThumb.frame.size.height, self.imgUserThumb.frame.size.width, self.imgUserThumb.frame.size.height);
    
    
    viewButtonContainer.frame = CGRectMake(10, yPoint, viewButtonContainer.frame.size.width, viewButtonContainer.frame.size.height);
    
    imgTimer.frame = CGRectMake(viewButtonContainer.frame.origin.x+viewButtonContainer.frame.size.width+10, viewButtonContainer.frame.origin.y+10, imgTimer.frame.size.width, imgTimer.frame.size.height);
    
    lblDuration.frame = CGRectMake(imgTimer.frame.origin.x+imgTimer.frame.size.width+3, viewButtonContainer.frame.origin.y+10, 40, lblDuration.frame.size.height);
}
-(void)setUI:(NSDictionary*)dic withUserId:(NSString *)strUserId isEdit:(BOOL)isEdit{
    self.dicSelected = dic;
    NSLog(@"cap** %@", [dic valueForKey:CaptionForImage]);
    NSData *decodedData = [[NSData alloc] initWithBase64EncodedString:[dic valueForKey:CaptionForImage] options:0];
    NSString *decodedString = [[NSString alloc] initWithData:decodedData encoding:NSUTF8StringEncoding];
    NSLog(@"%@", decodedString);
    lblText.text = decodedString;
    decodedData = nil;
    decodedString = nil;
    viewButtonContainer.layer.cornerRadius = 20;
    viewLblContaner.layer.cornerRadius = 10;
    viewLblContaner.backgroundColor = UIColorFromRGB(0X00c2d9);
//    viewLblContaner.backgroundColor = [UIColor whiteColor];
//    lblText.backgroundColor = [UIColor lightGrayColor];
//    self.contentView.backgroundColor = [UIColor whiteColor];
    [Validation setCorners:self.imgUserThumb];
//    [Validation setCorners:viewButtonContainer];
    
    
    CGRect size = [self getHeight:lblText.text];
    lblText.frame = CGRectMake(lblText.frame.origin.x, lblText.frame.origin.y, size.size.width, size.size.height);
/*
    NSArray *newString = [lblText.text componentsSeparatedByCharactersInSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
    NSArray *newString1 = [lblText.text componentsSeparatedByCharactersInSet:[NSCharacterSet decimalDigitCharacterSet]];
    NSLog(@"newString %@ %@",newString,newString1);
    
    lblText.userInteractionEnabled = YES;
    [lblText addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapOnLabel:)]];
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:@"123467890" attributes:nil];
    NSRange linkRange = NSMakeRange(0, 9); // for the word "link" in the string above
    
    NSDictionary *linkAttributes = @{ NSForegroundColorAttributeName : [UIColor whiteColor],
                                      NSUnderlineStyleAttributeName : @(NSUnderlineStyleSingle) };
    [attributedString setAttributes:linkAttributes range:linkRange];
    
    // Assign attributedText to UILabel
    lblText.attributedText = attributedString;

    self.layoutManager = [[NSLayoutManager alloc] init];
    self.textContainer = [[NSTextContainer alloc] initWithSize:CGSizeZero];
    self.textStorage = [[NSTextStorage alloc] initWithAttributedString:attributedString];
    
    // Configure layoutManager and textStorage
    [self.layoutManager addTextContainer:self.textContainer];
    [self.textStorage addLayoutManager:self.layoutManager];
    
    // Configure textContainer
    self.textContainer.lineFragmentPadding = 0.0;
    self.textContainer.lineBreakMode = lblText.lineBreakMode;
    self.textContainer.maximumNumberOfLines = lblText.numberOfLines;
    self.textContainer.size = lblText.bounds.size;
*/
/*    NSArray *arrTemp1 = [lblText.text componentsSeparatedByString:@" "];
    for (int i=0; i<arrTemp1.count; i++) {
        NSCharacterSet *numbersSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        if ([[arrTemp1 objectAtIndex:i] rangeOfCharacterFromSet:numbersSet].location == NSNotFound){
            
        }
        NSArray *newString = [[arrTemp1 objectAtIndex:i] componentsSeparatedByCharactersInSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
        NSArray *newString1 = [[arrTemp1 objectAtIndex:i] componentsSeparatedByCharactersInSet:[NSCharacterSet decimalDigitCharacterSet]];
        NSLog(@"newString %@ %@",newString,newString1);
    }
*/
/*
    UITapGestureRecognizer *tapGes =[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(textTapped:)];
    [tapGes setNumberOfTapsRequired:1];
    [lblText addGestureRecognizer:tapGes];
    
    NSMutableAttributedString * string = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"Welcome "]];
    NSAttributedString* attributedString = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"123"] attributes:@{@"tappable":@(YES),@"networkCallRequired": @(NO),@"loadCatPicture": @(NO)}];
    
    [string appendAttributedString:attributedString];
    [string addAttribute:NSFontAttributeName value:[UIFont boldSystemFontOfSize:13] range:NSMakeRange(0,7)];
    [string addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:NSMakeRange(8, 3)];
    [string addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInt:1] range:NSMakeRange(8, 3)];
    [string addAttribute:NSUnderlineColorAttributeName value:[UIColor whiteColor] range:NSMakeRange(8, 3)];
    [string addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:NSMakeRange(0, string.length)];
    
    NSMutableParagraphStyle *paragraph1 = [[NSMutableParagraphStyle alloc] init];
    paragraph1.maximumLineHeight = 12.0f;
    paragraph1.alignment = NSTextAlignmentRight;
    
    [string addAttribute:NSParagraphStyleAttributeName value:paragraph1 range:NSMakeRange(0, string.length)];
    
    [lblText setAttributedText:string];
    
    CGRect size = [self getHeight:lblText.text];
    lblText.frame = CGRectMake(lblText.frame.origin.x, lblText.frame.origin.y, size.size.width, size.size.height);
    
    NSString *str;
    if ([strUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
        str = @"Me";
        self.imgUserThumb.imageURL = [NSURL URLWithString:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]];
        imgViewTextTail.image = [UIImage imageNamed:@"chat_tail_2.png"];
        lblDuration.textAlignment = NSTextAlignmentRight;
    }
    else{
        str = [NSString stringWithFormat:@"%@",[dic valueForKey:NAME]];
        self.imgUserThumb.imageURL = [NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]];
        imgViewTextTail.image = [UIImage imageNamed:@"chat_tail.png"];
        lblDuration.textAlignment = NSTextAlignmentLeft;
    }
    
    NSMutableParagraphStyle *paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.lineBreakMode = NSLineBreakByTruncatingTail;
    
    size = [str boundingRectWithSize:CGSizeMake(150, MAXFLOAT)
                             options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                          attributes:@{NSFontAttributeName:lblBlabCreatorName.font, NSParagraphStyleAttributeName: paragraph}
                             context:nil];
//    size = text.size;
    lblBlabCreatorName.frame = CGRectMake(lblBlabCreatorName.frame.origin.x, lblBlabCreatorName.frame.origin.y, (size.size.width>150)?(150):(size.size.width+4), lblBlabCreatorName.frame.size.height);
    lblBlabCreatorName.text = str;
    [lblBlabCreatorName setTextColor:(str.length >0)?[Validation getColorForAlphabet:lblBlabCreatorName.text]:[UIColor blackColor]];
    

    //////////////////  Timer
    str = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_SENT_BEFORE]];
    lblDuration.text = str;
*/
/*    size = [str boundingRectWithSize:CGSizeMake(40, lblDuration.frame.size.height)
                                    options:NSStringDrawingUsesLineFragmentOrigin
                                 attributes:@{NSFontAttributeName:lblDuration.font}
                                    context:nil];
comment here
    
    if ([[dic valueForKey:IS_SELECTED] boolValue]) {
        [self.imgSelected setHidden:NO];
        [self.imgSelected setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
    }
    else{
        if (isEdit) {
            [self.imgSelected setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication]];
        }
        else{
            [self.imgSelected setHidden:YES];
        }
    }
    
    if ([strUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
        //it is user, so show right side
        [self setRightSideControls];
    }
    else{
        [self setLeftSideControls];
    }
    
    NSString *strGroupId = [NSString stringWithFormat:@"%@",[dic valueForKey:@"GroupIDs"]];
    if ([DataValidation checkNullString:strGroupId].length >0 && ([strGroupId intValue]!=0)) {
        btnBlabCreatorName.hidden = NO;
        btnBlabCreatorImage.hidden = NO;
        btnBlabCreatorName.frame = lblBlabCreatorName.frame;
        btnBlabCreatorImage.frame = self.imgUserThumb.frame;
        
    }
    else{
        btnBlabCreatorName.hidden = YES;
        btnBlabCreatorImage.hidden = YES;
    }
}
- (void)viewDidLayoutSubviews
{
//    [super viewDidLayoutSubviews];
    self.textContainer.size = lblText.bounds.size;
}
- (void)textTapped:(UITapGestureRecognizer *)recognizer
{
    UITextView *textView = (UITextView *)recognizer.view;
    // Location of the tap in text-container coordinates
    
    NSLayoutManager *layoutManager = textView.layoutManager;
    CGPoint location = [recognizer locationInView:textView];
    location.x -= textView.textContainerInset.left;
    location.y -= textView.textContainerInset.top;
    
    NSLog(@"location: %@", NSStringFromCGPoint(location));
    // Find the character that's been tapped on
    
    NSUInteger characterIndex;
    characterIndex = [layoutManager characterIndexForPoint:location inTextContainer:textView.textContainer fractionOfDistanceBetweenInsertionPoints:NULL];
    
    if (characterIndex < textView.textStorage.length) {
        NSRange range;
        NSDictionary *attributes = [textView.textStorage attributesAtIndex:characterIndex effectiveRange:&range];
        if (range.location==8) {
            //            [self btnViewContactInfo_Clicked];
        }
    }
}
- (CGRect)getHeight:(NSString *)strText{
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    //    CGSize size = CGSizeMake(self.lblTime.frame.size.width+50, self.lbl.frame.size.height);
    CGRect size =  [strText boundingRectWithSize:CGSizeMake(WIDTH_DESC-5, 20000)
                                         options:NSStringDrawingUsesLineFragmentOrigin
                                      attributes:@{NSFontAttributeName:lblText.font,NSParagraphStyleAttributeName:paragraphStyle}
                                         context:nil];
    
    return size;
}
-(IBAction)btnBlabCreatorName_Clicked:(id)sender{
    [self.delegate btnBlabCreatorName_Clicked:self.dicSelected];
}
-(IBAction)btnBlabCreatorImage_Clicked:(id)sender{
    [self.delegate btnBlabCreatorImage_Clicked:self.dicSelected];
}
- (void)boundingRectForCharacterRange:(NSRange)range
{
    
    if (self.layoutManager!=nil) {
        self.layoutManager = nil;
    }
    if (self.textStorage!=nil) {
        self.textStorage = nil;
    }
    if (self.textContainer!=nil) {
        self.textContainer = nil;
    }
    self.textStorage = [[NSTextStorage alloc] initWithAttributedString:lblText.attributedText];
    self.layoutManager = [[NSLayoutManager alloc] init];
    [self.textStorage addLayoutManager:self.layoutManager];
    self.textContainer = [[NSTextContainer alloc] initWithSize:[self bounds].size];
    self.textContainer.lineFragmentPadding = 0;
    [self.layoutManager addTextContainer:self.textContainer];
    
    NSRange glyphRange;
    
    // Convert the range for glyphs.
    [self.layoutManager characterRangeForGlyphRange:range actualGlyphRange:&glyphRange];
    
//    return [layoutManager boundingRectForGlyphRange:glyphRange inTextContainer:textContainer];
//    return layoutManager;
}
- (void)handleTapOnLabel:(UITapGestureRecognizer *)tapGesture
{
    [self boundingRectForCharacterRange:NSMakeRange(0, 9)];
    CGPoint locationOfTouchInLabel = [tapGesture locationInView:tapGesture.view];
    CGSize labelSize = tapGesture.view.bounds.size;
    CGRect textBoundingBox = [self.layoutManager usedRectForTextContainer:self.textContainer];
    CGPoint textContainerOffset = CGPointMake((labelSize.width - textBoundingBox.size.width) * 0.5 - textBoundingBox.origin.x,
                                              (labelSize.height - textBoundingBox.size.height) * 0.5 - textBoundingBox.origin.y);
    CGPoint locationOfTouchInTextContainer = CGPointMake(locationOfTouchInLabel.x - textContainerOffset.x,
                                                         locationOfTouchInLabel.y - textContainerOffset.y);
    NSInteger indexOfCharacter = [self.layoutManager characterIndexForPoint:locationOfTouchInTextContainer
                                                            inTextContainer:self.textContainer
                                   fractionOfDistanceBetweenInsertionPoints:nil];
    NSRange linkRange = NSMakeRange(0, 9); // it's better to save the range somewhere when it was originally used for marking link in attributed string
    if (NSLocationInRange(indexOfCharacter, linkRange)) {
        // Open an URL, or handle the tap on the link in any other way
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://stackoverflow.com/"]];
    }
}
*/
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
-(void)setRightSideControls{
    float yPoint=10;
    float xPointViewLblContaner;
    
    self.imgSelected.frame = CGRectMake(10, yPoint, 30, 30);
    
    if (lblText.frame.size.height<19) {
        viewLblContaner.frame = CGRectMake(self.contentView.frame.size.width-lblText.frame.size.width-30, yPoint+15, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
        yPoint+=15;
    }
    else{
        viewLblContaner.frame = CGRectMake(self.contentView.frame.size.width-lblText.frame.size.width-30, yPoint, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
    }
    viewLblContaner.frame = CGRectMake(self.contentView.frame.size.width-lblText.frame.size.width-30, yPoint, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
    lblText.frame = CGRectMake(9, 5, lblText.frame.size.width, lblText.frame.size.height);
    imgViewTextTail.frame = CGRectMake(viewLblContaner.frame.size.width+viewLblContaner.frame.origin.x-7, viewLblContaner.frame.origin.y+viewLblContaner.frame.size.height-5, 14, 7);
    yPoint+=viewLblContaner.frame.size.height+10;
    
    //    if (viewLblContaner.frame.size.width>viewButtonContainer.frame.size.width) {
    xPointViewLblContaner = viewLblContaner.frame.origin.x;
    /*    }
     else{
     xPointViewLblContaner = self.contentView.frame.size.width-viewButtonContainer.frame.size.width;
     }
     */
    lblBlabCreatorName.frame = CGRectMake(xPointViewLblContaner-lblBlabCreatorName.frame.size.width-10, viewLblContaner.frame.origin.y+viewLblContaner.frame.size.height-lblBlabCreatorName.frame.size.height, lblBlabCreatorName.frame.size.width, lblBlabCreatorName.frame.size.height);
    
    self.imgUserThumb.frame = CGRectMake(xPointViewLblContaner-self.imgUserThumb.frame.size.width-15, lblBlabCreatorName.frame.origin.y-self.imgUserThumb.frame.size.height-5, self.imgUserThumb.frame.size.width, self.imgUserThumb.frame.size.height);
    
    
    viewButtonContainer.frame = CGRectMake(self.contentView.frame.size.width-viewButtonContainer.frame.size.width-10, yPoint, viewButtonContainer.frame.size.width, viewButtonContainer.frame.size.height);
    
    imgTimer.frame = CGRectMake(viewButtonContainer.frame.origin.x-imgTimer.frame.size.width-10, viewButtonContainer.frame.origin.y+10, imgTimer.frame.size.width, imgTimer.frame.size.height);
    
    lblDuration.frame = CGRectMake(imgTimer.frame.origin.x-40-3, viewButtonContainer.frame.origin.y+10, 40, lblDuration.frame.size.height);
}
-(void)setLeftSideControls{
    float yPoint=10;
    float xPointViewLblContaner;
    
    self.imgSelected.frame = CGRectMake(self.contentView.frame.size.width-40, yPoint, 30, 30);
    if (lblText.frame.size.height<19) {
        viewLblContaner.frame = CGRectMake(17, yPoint+15, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
        yPoint+=15;
    }
    else{
        viewLblContaner.frame = CGRectMake(17, yPoint, lblText.frame.size.width+WIDTH_LBLTEXT_MORE, lblText.frame.size.height+HEIGHT_LBLTEXT_MORE);
    }
    
    lblText.frame = CGRectMake(9, 5, lblText.frame.size.width, lblText.frame.size.height);
    imgViewTextTail.frame = CGRectMake(viewLblContaner.frame.origin.x-7, viewLblContaner.frame.origin.y+viewLblContaner.frame.size.height-5, 14, 7);
    
    yPoint+=viewLblContaner.frame.size.height+10;
    
    
    //    if (viewLblContaner.frame.size.width>viewButtonContainer.frame.size.width) {
    xPointViewLblContaner = viewLblContaner.frame.origin.x+viewLblContaner.frame.size.width+10;
    /*    }
     else{
     xPointViewLblContaner = viewButtonContainer.frame.size.width+20;
     }
     */
    NSLog(@"----====> %f %f %f",viewLblContaner.frame.size.width,viewButtonContainer.frame.size.width,xPointViewLblContaner);
    
    lblBlabCreatorName.frame = CGRectMake(xPointViewLblContaner, viewLblContaner.frame.origin.y+viewLblContaner.frame.size.height-lblBlabCreatorName.frame.size.height, lblBlabCreatorName.frame.size.width, lblBlabCreatorName.frame.size.height);
    self.imgUserThumb.frame = CGRectMake(xPointViewLblContaner-2, lblBlabCreatorName.frame.origin.y-self.imgUserThumb.frame.size.height, self.imgUserThumb.frame.size.width, self.imgUserThumb.frame.size.height);
    
    
    viewButtonContainer.frame = CGRectMake(10, yPoint, viewButtonContainer.frame.size.width, viewButtonContainer.frame.size.height);
    
    imgTimer.frame = CGRectMake(viewButtonContainer.frame.origin.x+viewButtonContainer.frame.size.width+10, viewButtonContainer.frame.origin.y+10, imgTimer.frame.size.width, imgTimer.frame.size.height);
    
    lblDuration.frame = CGRectMake(imgTimer.frame.origin.x+imgTimer.frame.size.width+3, viewButtonContainer.frame.origin.y+10, 40, lblDuration.frame.size.height);
}
-(void)setUI:(NSDictionary*)dic withUserId:(NSString *)strUserId isEdit:(BOOL)isEdit{
    self.dicSelected = dic;
    NSLog(@"cap** %@", [dic valueForKey:CaptionForImage]);
    NSData *decodedData = [[NSData alloc] initWithBase64EncodedString:[dic valueForKey:CaptionForImage] options:0];
    NSString *decodedString = [[NSString alloc] initWithData:decodedData encoding:NSUTF8StringEncoding];
    NSLog(@"%@", decodedString);
    lblText.linkColor =  UIColorFromRGB(0X0076ff);
    lblText.delegate = self;
    lblText.userInteractionEnabled = YES;
    lblText.text = decodedString;
    decodedData = nil;
    decodedString = nil;
    viewButtonContainer.layer.cornerRadius = 20;
    viewLblContaner.layer.cornerRadius = 10;
    viewLblContaner.backgroundColor = UIColorFromRGB(0X00c2d9);
    //    viewLblContaner.backgroundColor = [UIColor whiteColor];
    //    lblText.backgroundColor = [UIColor lightGrayColor];
    //    self.contentView.backgroundColor = [UIColor whiteColor];
    [Validation setCorners:self.imgUserThumb];
    //    [Validation setCorners:viewButtonContainer];
    
    

    CGRect size = [self getHeight:lblText.text];
    lblText.frame = CGRectMake(lblText.frame.origin.x, lblText.frame.origin.y, ceilf(size.size.width), ceilf(size.size.height));
    
//    NSMutableAttributedString *atributedString = [[NSMutableAttributedString alloc] initWithString:@""];
    NSArray *arrTemp1 = [lblText.text componentsSeparatedByString:@" "];
/*    for (int i=0; i<arrTemp1.count; i++) {
        NSCharacterSet *numbersSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        if ([[arrTemp1 objectAtIndex:i] rangeOfCharacterFromSet:numbersSet].location == NSNotFound && [DataValidation checkNullString:[arrTemp1 objectAtIndex:i]].length>=6){
            
            NSMutableAttributedString *strAtemp = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"^^+^^%@",[arrTemp1 objectAtIndex:i]]];
            
            [strAtemp addAttribute:NSFontAttributeName value:lblText.font range:NSMakeRange(0, strAtemp.length)];
            [strAtemp addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:NSMakeRange(0, strAtemp.length)];//TextColor
            [strAtemp addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInt:1] range:NSMakeRange(0, strAtemp.length)];//Underline color
            [strAtemp addAttribute:NSUnderlineColorAttributeName value:[UIColor whiteColor] range:NSMakeRange(0, strAtemp.length)];

            [atributedString appendAttributedString:strAtemp];
        }
        else{
            NSMutableAttributedString *strAtemp;
            strAtemp = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@" %@ ",[arrTemp1 objectAtIndex:i]]];
            [atributedString appendAttributedString:strAtemp];
        }
//        NSArray *newString = [[arrTemp1 objectAtIndex:i] componentsSeparatedByCharactersInSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
//        NSArray *newString1 = [[arrTemp1 objectAtIndex:i] componentsSeparatedByCharactersInSet:[NSCharacterSet decimalDigitCharacterSet]];
//        NSLog(@"newString %@ %@",newString,newString1);
    }
*/
    NSCharacterSet *numbersSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    NSMutableString *strFinal = [[NSMutableString alloc] init];
    NSDataDetector* detector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingTypeLink error:nil];
    
    
    strFinal = (NSMutableString *)[strFinal stringByAppendingString:@""];
    for (int i=0; i<arrTemp1.count; i++) {
        NSArray* matches = [detector matchesInString:[arrTemp1 objectAtIndex:i] options:0 range:NSMakeRange(0, [[arrTemp1 objectAtIndex:i] length])];
        if ([[arrTemp1 objectAtIndex:i] rangeOfCharacterFromSet:numbersSet].location == NSNotFound && [DataValidation checkNullString:[arrTemp1 objectAtIndex:i]].length>=3){
            if (i==0) {
                strFinal = (NSMutableString *)[strFinal stringByAppendingString:[NSString stringWithFormat:@"^^+^^%@",[arrTemp1 objectAtIndex:i]]];
            }
            else{
                strFinal = (NSMutableString *)[strFinal stringByAppendingString:[NSString stringWithFormat:@" ^^+^^%@",[arrTemp1 objectAtIndex:i]]];
            }
//            NSMutableAttributedString *strAtemp = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"^^+^^%@",[arrTemp1 objectAtIndex:i]]];
        }
        else if (matches.count>0){
            NSLog(@"link detact %@",[arrTemp1 objectAtIndex:i]);
            if (i==0) {
                strFinal = (NSMutableString *)[strFinal stringByAppendingString:[NSString stringWithFormat:@"^^+^^%@",[arrTemp1 objectAtIndex:i]]];
            }
            else{
                strFinal = (NSMutableString *)[strFinal stringByAppendingString:[NSString stringWithFormat:@" ^^+^^%@",[arrTemp1 objectAtIndex:i]]];
            }
        }
        else{
            if (i==0) {
                strFinal = (NSMutableString *)[strFinal stringByAppendingString:[NSString stringWithFormat:@"%@",[arrTemp1 objectAtIndex:i]]];
            }
            else{
                strFinal = (NSMutableString *)[strFinal stringByAppendingString:[NSString stringWithFormat:@" %@",[arrTemp1 objectAtIndex:i]]];
            }
        }
        
    }
    if (arrTemp1.count==1 && [[arrTemp1 objectAtIndex:0] rangeOfCharacterFromSet:numbersSet].location == NSNotFound && [DataValidation checkNullString:[arrTemp1 objectAtIndex:0]].length>=3) {
    }
    lblText.text = strFinal;
    
    
    NSString *str;
    if ([strUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
        str = @"Me";
        self.imgUserThumb.imageURL = [NSURL URLWithString:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHOTOPATH]];
        imgViewTextTail.image = [UIImage imageNamed:@"chat_tail_2.png"];
        lblDuration.textAlignment = NSTextAlignmentRight;
    }
    else{
        str = [NSString stringWithFormat:@"%@",[dic valueForKey:NAME]];
        self.imgUserThumb.imageURL = [NSURL URLWithString:[dic valueForKey:USER_PHOTO_PATH]];
        imgViewTextTail.image = [UIImage imageNamed:@"chat_tail.png"];
        lblDuration.textAlignment = NSTextAlignmentLeft;
    }
    
    NSMutableParagraphStyle *paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.lineBreakMode = NSLineBreakByTruncatingTail;
    
    size = [str boundingRectWithSize:CGSizeMake(150, MAXFLOAT)
                             options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                          attributes:@{NSFontAttributeName:lblBlabCreatorName.font, NSParagraphStyleAttributeName: paragraph}
                             context:nil];
    //    size = text.size;
    lblBlabCreatorName.frame = CGRectMake(lblBlabCreatorName.frame.origin.x, lblBlabCreatorName.frame.origin.y, (size.size.width>150)?(150):(size.size.width+4), lblBlabCreatorName.frame.size.height);
    lblBlabCreatorName.text = str;
    [lblBlabCreatorName setTextColor:(str.length >0)?[Validation getColorForAlphabet:lblBlabCreatorName.text]:[UIColor blackColor]];
    
    
    //////////////////  Timer
    str = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_SENT_BEFORE]];
    lblDuration.text = str;
    
    /*    size = [str boundingRectWithSize:CGSizeMake(40, lblDuration.frame.size.height)
     options:NSStringDrawingUsesLineFragmentOrigin
     attributes:@{NSFontAttributeName:lblDuration.font}
     context:nil];
     */
    
    if ([[dic valueForKey:IS_SELECTED] boolValue]) {
        [self.imgSelected setHidden:NO];
        [self.imgSelected setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
    }
    else{
        if (isEdit) {
            [self.imgSelected setImage:[UIImage imageNamed:Btn_DeSelectedUserIndication]];
        }
        else{
            [self.imgSelected setHidden:YES];
        }
    }
    
    if ([strUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
        //it is user, so show right side
        [self setRightSideControls];
    }
    else{
        [self setLeftSideControls];
    }
    
    NSString *strGroupId = [NSString stringWithFormat:@"%@",[dic valueForKey:@"GroupIDs"]];
    if ([DataValidation checkNullString:strGroupId].length >0 && ([strGroupId intValue]!=0)) {
        btnBlabCreatorName.hidden = NO;
        btnBlabCreatorImage.hidden = NO;
        btnBlabCreatorName.frame = lblBlabCreatorName.frame;
        btnBlabCreatorImage.frame = self.imgUserThumb.frame;
        
    }
    else{
        btnBlabCreatorName.hidden = YES;
        btnBlabCreatorImage.hidden = YES;
    }
    
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"4"] || [[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"5"]){
        self.btnAboveText.hidden = NO;
        self.btnAboveText.frame = lblText.frame;
        [self.btnAboveText addTarget:self action:@selector(btnAboveText_Clicked) forControlEvents:UIControlEventTouchUpInside];
    }
}
-(void)label:(GLTapLabel *)label didSelectedHotWord:(NSString *)word atIndex:(int)index withArray:(NSArray *)arr{
    NSLog(@"Hot word tap %@ --%d --%@",word,index,arr);
    NSDataDetector* detector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingTypeLink error:nil];
    NSArray* matches = [detector matchesInString:word options:0 range:NSMakeRange(0, [word length])];
    if (matches.count>0) {
        NSString *strUrl;
        if ([word hasPrefix:@"http://"] || [word hasPrefix:@"https://"]) {
            strUrl = word;
        }
        else{
            strUrl = [NSString stringWithFormat:@"http://%@",word];
        }
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:strUrl]];
    }
    else{
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",word]]];
    }
}
-(void)label:(GLTapLabel *)label{
    NSLog(@"Hot word tap");
}
-(void)label:(GLTapLabel *)label didSelectedHotWord:(NSString *)w
{
//    word.text = w;
    NSLog(@"Hot word tap");
}
- (CGRect)getHeight:(NSString *)strText{
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    //    CGSize size = CGSizeMake(self.lblTime.frame.size.width+50, self.lbl.frame.size.height);
    CGRect size =  [strText boundingRectWithSize:CGSizeMake(WIDTH_DESC, 20000)
                                         options:NSStringDrawingUsesLineFragmentOrigin
                                      attributes:@{NSFontAttributeName:lblText.font,NSParagraphStyleAttributeName:paragraphStyle}
                                         context:nil];
    
    return size;
}
-(IBAction)btnBlabCreatorName_Clicked:(id)sender{
    [self.delegate btnBlabCreatorName_Clicked:self.dicSelected];
}
-(IBAction)btnBlabCreatorImage_Clicked:(id)sender{
    [self.delegate btnBlabCreatorImage_Clicked:self.dicSelected];
}
-(void)btnAboveText_Clicked{
    [self.delegate btnAboveText_Clicked:self.dicSelected];
}
@end
