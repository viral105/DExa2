//
//  ConversationTextBlabCell.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 5/28/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GLTapLabel.h"
#import "GLTapLabelDelegate.h"

@protocol ConversationTextBlabCellDelegate <NSObject>

-(void)btnBlabCreatorName_Clicked:(NSDictionary *)dic;
-(void)btnBlabCreatorImage_Clicked:(NSDictionary *)dic;
-(void)btnAboveText_Clicked:(NSDictionary *)dic;

@end
@interface ConversationTextBlabCell : UITableViewCell<UIGestureRecognizerDelegate,GLTapLabelDelegate>{
    IBOutlet GLTapLabel *lblText;
//    IBOutlet UITextView *tvText;
    IBOutlet UIView  *viewButtonContainer;
    IBOutlet UIView *viewLblContaner;
    IBOutlet UIImageView *imgViewTextTail;
//    IBOutlet AsyncImageView   *imgUserThumb;
    IBOutlet UIButton         *btnUserThumb;
    IBOutlet UIImageView      *imgTimer;
    IBOutlet UILabel          *lblDuration;
    IBOutlet UILabel          *lblBlabCreatorName;
    IBOutlet UIButton         *btnBlabCreatorName;
    IBOutlet UIButton         *btnBlabCreatorImage;
    
    
}
-(void)setUI:(NSDictionary*)dic withUserId:(NSString *)strUserId isEdit:(BOOL)isEdit;
@property (nonatomic, strong) IBOutlet UIButton         *btnReportAbuse;
@property (nonatomic, strong) IBOutlet UIButton         *btnAboveText;
@property (nonatomic, strong) IBOutlet UIImageView      *imgSelected;
@property (nonatomic, strong) IBOutlet AsyncImageView   *imgUserThumb;
@property (nonatomic, strong) id<ConversationTextBlabCellDelegate> delegate;
@property (nonatomic, strong) NSDictionary          *dicSelected;

@property (nonatomic, strong) NSLayoutManager *layoutManager;
@property (nonatomic, strong) NSTextContainer *textContainer;
@property (nonatomic, strong) NSTextStorage *textStorage;
@end
