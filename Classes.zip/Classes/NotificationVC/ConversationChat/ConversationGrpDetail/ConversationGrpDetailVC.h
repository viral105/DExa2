//
//  ConversationGrpDetailVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 10/12/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserCell.h"
#import "RecrodingFriendRequestVC.h"

@interface ConversationGrpDetailVC : UIViewController  <UITableViewDataSource, UITableViewDelegate,AFNetworkingDataTransactionDelegate,UIAlertViewDelegate,UserProfileVCDelegate,UserCellDelegate,RecrodingFriendRequestVCDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) IBOutlet AsyncImageView       *imgGrp;
@property (nonatomic, strong) IBOutlet UIButton             *btnExit;

@property (nonatomic, strong) NSDictionary                  *dicGrpDetail;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;
@property (nonatomic, strong) UIActivityIndicatorView		*activityLoading;

@property (nonatomic, readwrite) int                        selectedFriendIndex;

@property (nonatomic, strong) NSString                      *strLoggedInUserId;

@end
