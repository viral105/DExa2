//
//  ConversationGrpDetailVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 10/12/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "ConversationGrpDetailVC.h"
#import "UserCell.h"
#import "NotificationVC.h"

#define PageSize	15
#define CellHeight  90


@interface ConversationGrpDetailVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
    UserProfileVC *objUserProfileVC;
}
@property (nonatomic, strong)UserProfileVC *objUserProfileVC;
@end


@implementation ConversationGrpDetailVC
@synthesize objUserProfileVC;
-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	
    
	self.arrData = [[NSMutableArray alloc] init];
	appDelegate.currentVc = self;
	[self.tblData registerNib:[UINib nibWithNibName:@"UserCell" bundle:nil] forCellReuseIdentifier:@"cellIdentifier"];
	self.strLoggedInUserId = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]];
    
    
    NSLog(@"%@",self.dicGrpDetail);
    
	[self performSelector:@selector(LoadViewSetting)];
}

-(void)viewWillAppear:(BOOL)animated{
    
	[super viewWillAppear:animated];
	appDelegate.currentVc = self;

	self.pageCounter = 1;
	self.isDataNull = NO;
    
    [self GetGroupUsersByGrpId];
}

-(void)viewWillDisappear:(BOOL)animated{

	[super viewWillDisappear:animated];
    appDelegate.isShouldShowReplyPopUp = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark CUSTOM Methods

-(void)LoadViewSetting{
    NSLog(@"self.dicGrpDetail %@",self.dicGrpDetail);
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
	[self.btnExit setBackgroundImage:[UIImage imageNamed:BtnDeleteRed] forState:UIControlStateNormal];
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    [self.lblTitle setText:[NSString stringWithFormat:@"%@",[self.dicGrpDetail valueForKey:NAME]]];
    [self.imgGrp setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[self.dicGrpDetail valueForKey:Grp_PhotoPath]]]];
    [Validation setCorners:self.imgGrp];
}

-(IBAction)btnBackClicked:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnExitConversationClicked:(id)sender{
    if ([[NSString stringWithFormat:@"%@",[self.dicGrpDetail valueForKey:IS_GRP_ADMIN]] boolValue]) {
        //admin wants to delete group
        [AlertHandler alertTitle:CONFIRM message:@"Are you sure you want to delete and exit group?" delegate:self tag:2 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
    }
    else{
        //group member wants to exit group
        [AlertHandler alertTitle:CONFIRM message:@"Are you sure you want to exit group?" delegate:self tag:3 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
    }
}

-(void)GetGroupUsersByGrpId{
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[self.dicGrpDetail valueForKey:@"GroupID"],KeyValue,@"GroupID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"3",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"100"],KeyValue,@"PageSize",KeyName, nil],@"4",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_USER_IN_GRP withParameters:nil];
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:1];
    }
//    [obj setDelegate:self];
//    [obj setTag:1];
	strUrl = nil;
}

-(void)btnRemoveFriendFromGRPClicked:(id)sender{
    UIButton *btn = (UIButton *)sender;
    self.selectedFriendIndex = (int)btn.tag;
    
    [AlertHandler alertTitle:CONFIRM message:[NSString stringWithFormat:@"Are you sure you want to remove %@ from group?",[[self.arrData objectAtIndex:self.selectedFriendIndex] valueForKey:NAME]] delegate:self tag:1 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
    
}

-(void)CallRemoveFriendFromGroup:(BOOL)isByAdmin{

    [HUD show:YES];
	
	NSString *strIdsToRemove = [[self.arrData objectAtIndex:self.selectedFriendIndex] valueForKey:@"ID"];
	if (!isByAdmin) {
        strIdsToRemove = self.strLoggedInUserId;
    }
    
	NSLog(@"strIdsToRemove = %@",strIdsToRemove);
	
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicGrpDetail valueForKey:@"GroupID"]],KeyValue,@"GroupID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicGrpDetail valueForKey:NAME]],KeyValue,@"GroupName",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"AddUser",KeyName, nil],@"3",
						 
						 [NSDictionary dictionaryWithObjectsAndKeys:strIdsToRemove,KeyValue,@"RemoveUser",KeyName, nil],@"4",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:EDIT_GROUP_DETAIL withParameters:nil];
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        if (isByAdmin) {
            [obj setTag:2];
        }
        else{
            [obj setTag:4];
        }
    }
/*    [obj setDelegate:self];
    if (isByAdmin) {
        [obj setTag:2];
    }
    else{
        [obj setTag:4];
    }
*/	strUrl = nil;
    [self.arrData removeObjectAtIndex:self.selectedFriendIndex];
    [self.tblData reloadData];

}

-(void)callDeleteAndExitGroup{
	
    [HUD show:YES];
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dicGrpDetail valueForKey:@"GroupID"]],KeyValue,@"GroupID",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:DELETE_GRP withParameters:nil];
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:3];
    }
//    [obj setDelegate:self];
//    [obj setTag:3];

	strUrl = nil;
    
}
-(void)btnAddFriendClicked:(id)sender{
    self.view.userInteractionEnabled = NO;
    UIButton*btn = ((UIButton *)sender);
    
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    if ([[dicData valueForKey:IS_USER_BLOCKED] boolValue]) {
        [Validation showToastMessage:@"You cannot send friend request to a blocked user." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        if (![[NSString stringWithFormat:@"%@",[dicData valueForKey:IS_FRND_REQ_SENT]] boolValue]) {
/*            [dicData setValue:@"1" forKey:IS_FRND_REQ_SENT];
            [self.arrData replaceObjectAtIndex:btn.tag withObject:dicData];
            
            NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:btn.tag inSection:0]];
            [self.tblData beginUpdates];
            [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
            [self.tblData endUpdates];
*/
            NSString *strRequestId = [NSString stringWithFormat:@"%@",[dicData valueForKey:USER_ID]];
            
            NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                                 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                                 [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
                                 nil];
            
            RecrodingFriendRequestVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:@"RecrodingFriendRequestVC"];
            obj.delegateFriendReq = self;
            obj.indexSelected = (int)btn.tag;
            obj.dicToSendFriendRequest = dic;
            [self.navigationController pushViewController:obj animated:YES];
/*
        NSString *strUrl = [WebServiceContainer getServiceURL:ADD_FRIEND withParameters:nil];
        ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
        request.delegate = self;
        request.tag = 2;
        strUrl = nil;
*/
/*            NSString *strUrl = [WebServiceContainer getServiceURL:ADD_FRIEND withParameters:nil];
            AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
            [obj SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
            if (obj._currentRequest == nil) {
                [HUD hide:YES];
            }
            else{
                [obj setDelegate:self];
                [obj setTag:5];
            }
*/
        }
        else{
            [Validation showToastMessage:@"Friend request already sent." displayDuration:ERROR_MSG_DURATION];
        }
//        [obj setDelegate:self];
//        [obj setTag:5];
    }
    dicData = nil;

}
-(void)btnAddFriendFromPopup_Clicked:(NSDictionary *)dicOld{
    NSLog(@"arrData indexOfObject %d",(int)[self.arrData indexOfObject:dicOld]);
    if ([self.arrData containsObject:dicOld]) {
        NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:[self.arrData indexOfObject:dicOld]]];
        NSString *strRequestId = [NSString stringWithFormat:@"%@",[dicData valueForKey:USER_ID]];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"RequestID",KeyName, nil],@"2",
                             nil];
        
        RecrodingFriendRequestVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:@"RecrodingFriendRequestVC"];
        obj.delegateFriendReq = self;
        obj.indexSelected = (int)[self.arrData indexOfObject:dicOld];
        obj.dicToSendFriendRequest = dic;
        [self.navigationController pushViewController:obj animated:YES];
    }
    
}
-(void)updateUserData:(int)indSel{
    NSLog(@"indSel %d",indSel);
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:indSel]];
    
    [dicData setValue:@"1" forKey:IS_FRND_REQ_SENT];
    [self.arrData replaceObjectAtIndex:indSel withObject:dicData];
    if (self.objUserProfileVC != nil) {
        [self.objUserProfileVC.dicUserDetail setObject:@"1" forKey:IS_FRND_REQ_SENT];
        [self.objUserProfileVC LoadViewSetting];
    }
    
    NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indSel inSection:0]];
    [self.tblData beginUpdates];
    [self.tblData reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
    [self.tblData endUpdates];
}
#pragma mark
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 1) {
        //remove friend alert
        if (buttonIndex == alertView.cancelButtonIndex) {
            
        }
        else{
            [self CallRemoveFriendFromGroup:YES];
        }
    }else if (alertView.tag == 2) {
        //admin wants to delete and exit group
        if (buttonIndex == alertView.cancelButtonIndex) {
            
        }
        else{
            [self callDeleteAndExitGroup];
        }
    }
    else if (alertView.tag == 3){
        //group member wants to exit group
        if (buttonIndex == alertView.cancelButtonIndex) {
            
        }
        else{
            [self CallRemoveFriendFromGroup:NO];

        }
    }
}

#pragma mark
#pragma mark  UITableViewDelegate
#pragma mark

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *viewFooter = [[UIView alloc] init];
    viewFooter.backgroundColor = [UIColor clearColor];
    return viewFooter;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 56;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return CellHeight;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	//return self.arrData.count;

	return self.arrData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    NSDictionary *dic = [self.arrData objectAtIndex:indexPath.row];
	
	UserCell *cell = (UserCell *)[tableView dequeueReusableCellWithIdentifier:@"cellIdentifier"];
    cell.delegate = self;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
    [cell setBoxValuesWithData:dic];
    

    if ([[NSString stringWithFormat:@"%@",[self.dicGrpDetail valueForKey:IS_GRP_ADMIN]] boolValue]) {
        cell.imgFriendshipStatus.hidden = YES;
        cell.btnUnfriend.hidden = YES;
        
        cell.btnRemoveFromGRP.frame = cell.imgFriendshipStatus.frame;
        [cell.btnRemoveFromGRP removeTarget:self action:@selector(btnRemoveFriendFromGRPClicked:) forControlEvents:UIControlEventTouchUpInside];

        if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_GRP_ADMIN]] boolValue]) {
            cell.lblUserStatusInGrp.hidden = FALSE;
            [cell.lblUserStatusInGrp setText:@"Group Admin"];
        }
        else{
            [cell.btnRemoveFromGRP setBackgroundImage:[UIImage imageNamed:BtnUserRemove] forState:UIControlStateNormal];
            [cell.btnRemoveFromGRP setHidden:FALSE];
            cell.btnRemoveFromGRP.tag = indexPath.row;
            [cell.btnRemoveFromGRP addTarget:self action:@selector(btnRemoveFriendFromGRPClicked:) forControlEvents:UIControlEventTouchUpInside];
        }
    }
    else{
        NSString *isFriend = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IS_FRIEND]]];
        NSString *isFriendReqRec = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IS_FRND_REQ_REC]]];
        NSString *isFriendReqSent = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IS_FRND_REQ_SENT]]];
        if (isFriend.length>0 && [isFriend isEqualToString:@"1"]) {
            cell.imgFriendshipStatus.hidden = YES;
            cell.btnUnfriend.hidden = YES;
        }
        else{
            if (isFriendReqSent.length > 0 && [isFriendReqSent isEqualToString:@"1"]) {
                cell.imgFriendshipStatus.hidden = NO;
                [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_Waiting_For_Response]];
                cell.btnUnfriend.hidden = YES;
            }
            else if (isFriendReqRec.length > 0 && [isFriendReqRec isEqualToString:@"1"]){
                cell.imgFriendshipStatus.hidden = YES;
                cell.btnUnfriend.hidden = YES;
            }
            else{
                cell.imgFriendshipStatus.hidden = NO;
                cell.btnUnfriend.hidden = NO;
                cell.imgFriendshipStatus.frame = cell.btnRemoveFromGRP.frame;
                cell.btnUnfriend.frame = cell.btnRemoveFromGRP.frame;
                [cell.btnUnfriend setImage:[UIImage imageNamed:Btn_AddFriend] forState:UIControlStateNormal];
                [cell.btnUnfriend addTarget:self action:@selector(btnAddFriendClicked:) forControlEvents:UIControlEventTouchUpInside];
                cell.btnUnfriend.tag = (int)indexPath.row;
            }
        }
        
        if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_GRP_ADMIN]] boolValue]) {
            cell.lblUserStatusInGrp.hidden = FALSE;
            [cell.lblUserStatusInGrp setText:@"Group Admin"];
        }
        else if ([self.strLoggedInUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:USER_ID]]]) {
            cell.imgFriendshipStatus.hidden = YES;
            cell.btnUnfriend.hidden = YES;
            cell.lblUserStatusInGrp.hidden = FALSE;
            [cell.lblUserStatusInGrp setText:@"You"];
        }
    }
//    cell.imgFriendshipStatus.hidden = YES;
//	cell.btnUnfriend.hidden = YES;

    cell.imgViewFriendType.hidden = NO;
    switch ([[dic valueForKey:@"FriendType"] intValue]) {
        case 0:
            cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_blabeey.png"];
            break;
        case 1:
            cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_fb.png"];
            break;
        case 2:
            cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_contacts.png"];
            break;
            
        default:
            break;
    }
    
    dic = nil;
	
	if (indexPath.row == self.arrData.count) {
		if (indexPath.row == [[self.arrData objectAtIndex:indexPath.row] count]) {
			self.pageCounter++;
            [HUD show:YES];
			[self performSelectorInBackground:@selector(GetGroupUsersByGrpId) withObject:nil];
		}
	}
	return cell;
}
-(void)btnBlabCreatorName_Clicked:(NSDictionary *)dic{
    NSLog(@"dic %@",dic);
    if (self.objUserProfileVC == nil) {
        for (UIView *view in [self.view subviews]) {
            if ([view isKindOfClass:[UIButton class]]) {
                UIButton *btn = (UIButton *)view;
                btn.enabled = NO;
            }
            else if ([view isKindOfClass:[UITableView class]]){
                UITableView *tbl = (UITableView *)view;
                [tbl setUserInteractionEnabled:NO];
            }
        }
        self.objUserProfileVC = [self.storyboard instantiateViewControllerWithIdentifier:@"UserProfileVC"];
        self.objUserProfileVC.delegate = self;
        CGRect frame = self.view.frame;
        frame.origin.y = [UIScreen mainScreen].bounds.size.height;
        self.objUserProfileVC.view.frame = frame;
        self.objUserProfileVC.view.backgroundColor = [UIColor clearColor];
        [self.objUserProfileVC willMoveToParentViewController:self];
        [self.view addSubview:self.objUserProfileVC.view];
        [self addChildViewController:self.objUserProfileVC];
        [self.objUserProfileVC didMoveToParentViewController:self];
        self.objUserProfileVC.dicSelected = dic;
        self.objUserProfileVC.strUserID = [NSString stringWithFormat:@"%@",[dic valueForKey:@"ID"]];
        self.objUserProfileVC.selType = 2;  //  2 means display user data
        [self.objUserProfileVC updateUserInfo];
        [Validation animateYpoint:0 viewToAnimate:self.objUserProfileVC.view];
    }
}
-(void)btnBlabCreatorImage_Clicked:(NSDictionary *)dic{
    NSLog(@"dic %@",dic);
    if (self.objUserProfileVC == nil) {
        for (UIView *view in [self.view subviews]) {
            if ([view isKindOfClass:[UIButton class]]) {
                UIButton *btn = (UIButton *)view;
                btn.enabled = NO;
            }
            else if ([view isKindOfClass:[UITableView class]]){
                UITableView *tbl = (UITableView *)view;
                [tbl setUserInteractionEnabled:NO];
            }
        }
        self.objUserProfileVC = [self.storyboard instantiateViewControllerWithIdentifier:@"UserProfileVC"];
        self.objUserProfileVC.delegate = self;
        CGRect frame = self.view.frame;
        frame.origin.y = [UIScreen mainScreen].bounds.size.height;
        self.objUserProfileVC.view.frame = frame;
        self.objUserProfileVC.view.backgroundColor = [UIColor clearColor];
        [self.objUserProfileVC willMoveToParentViewController:self];
        [self.view addSubview:self.objUserProfileVC.view];
        [self addChildViewController:self.objUserProfileVC];
        [self.objUserProfileVC didMoveToParentViewController:self];
        self.objUserProfileVC.dicSelected = dic;
        self.objUserProfileVC.strUserID = [NSString stringWithFormat:@"%@",[dic valueForKey:@"ID"]];
        self.objUserProfileVC.selType = 1;  //  1 means display user big image
        [self.objUserProfileVC updateUserInfo];
        [Validation animateYpoint:0 viewToAnimate:self.objUserProfileVC.view];
    }
}
-(void)updateUserInfoFromPopup:(NSDictionary *)dic updatedInfo:(NSMutableDictionary *)updatedInfo{
    if ([self.arrData containsObject:dic]) {
        NSLog(@"having object %d",(int)[self.arrData indexOfObject:dic]);
        NSMutableDictionary *dicToChange = [NSMutableDictionary dictionaryWithDictionary:dic];
        [dicToChange setObject:[updatedInfo valueForKey:IS_USER_BLOCKED] forKey:IS_USER_BLOCKED];
        [dicToChange setObject:[updatedInfo valueForKey:IS_FRIEND] forKey:IS_FRIEND];
        [dicToChange setObject:[updatedInfo valueForKey:IS_FRND_REQ_SENT] forKey:IS_FRND_REQ_SENT];
        [dicToChange setObject:[updatedInfo valueForKey:IS_Follow] forKey:IS_Follow];
        [self.arrData replaceObjectAtIndex:[self.arrData indexOfObject:dic] withObject:dicToChange];
        
        [self.tblData beginUpdates];
        [self.tblData reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:[self.arrData indexOfObject:dic] inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
        [self.tblData endUpdates];
        //        NSMutableDictionary *dicUpdate = [NSMutableDictionary dictionaryWithDictionary:dic];
        //        [dicUpdate setValue:<#(id)#> forKey:<#(NSString *)#>]
    }
    else{
        NSLog(@"not having object");
    }
}

-(void)hideUserProfileVC{
    for (UIView *view in [self.view subviews]) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *btn = (UIButton *)view;
            btn.enabled = YES;
        }
        else if ([view isKindOfClass:[UITableView class]]){
            UITableView *tbl = (UITableView *)view;
            [tbl setUserInteractionEnabled:YES];
        }
    }
    self.objUserProfileVC = nil;
}

#pragma mark
#pragma mark web service method

- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];

    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            if (self.pageCounter==1) {
                                [self.arrData removeAllObjects];
                            }
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.isDataNull = NO;
                            NSLog(@"%d",(int)arr.count);
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            
                            
                            if (self.arrData.count>0) {
                                [arr addObjectsFromArray:self.arrData];
                                [self.arrData removeAllObjects];
                            }
                            if (arr.count>0) {
                                [self.arrData addObjectsFromArray:arr];
                              //  [self.tblData setScrollEnabled:NO];
                                
                                [self.tblData reloadData];
                            }
                            
                            arr = nil;
                        }
                        response = nil;
                    }
                    else if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]){
                        self.isDataNull = YES;
                        [self.tblData reloadData];
                        
                    }
                }
                
                [HUD hide:YES];
            }
            else if (tag == 2) {
                //admin deleted friend
                
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    NSLog(@"response  = %@",dicResponse);
                    
                    [HUD hide:YES];
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        //friend removed
                        
                        
//                        //received
//                        id response = [dicResponse objectForKey:RESPONSE];
//                        if (response != nil) {
//                        }
                    }
                }
            }
            else if (tag == 3){
                //admin deleted this group
                //so pop back to Feed view
                [HUD hide:YES];
                for (id v in self.navigationController.viewControllers) {
                    if ([v isKindOfClass:[NotificationVC class]]) {
                        [self.navigationController popToViewController:v animated:YES];
                        break;
                    }
                }
            }
            else if (tag == 4){
                //friend exit this group
                //so pop back to Feed view
                [HUD hide:YES];
                for (id v in self.navigationController.viewControllers) {
                    if ([v isKindOfClass:[NotificationVC class]]) {
                        [self.navigationController popToViewController:v animated:YES];
                        break;
                    }
                }
            }
            else if (tag == 5){
                [HUD hide:YES];
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    
                    [Validation showToastMessage:@"Request Sent" displayDuration:SUCCESS_MSG_DURATION];
                    [self.tblData reloadData];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
    self.view.userInteractionEnabled = YES;
}


- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}

@end
