//
//  NotificationCell.m
//  WWHHAAZZAAPP
//
//  Created by s on 8/6/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "NotificationCell.h"
#define CellHeight              115
#define BtnDeleteTitle			@" Delete"
#define CellBgHeight			82
#define CellBgWidth				313
#define ProfileImgWidth			66
#define ProfileImgHeight		66


@implementation NotificationCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
		self.backgroundColor = [UIColor clearColor];
		self.selectionStyle = UITableViewCellSelectionStyleNone;

    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setFramesForControllsInCell{
	
	self.backgroundColor = [UIColor clearColor];
	self.selectionStyle = UITableViewCellSelectionStyleBlue;
 	
	[self.lblUserName setBackgroundColor:[UIColor clearColor]];
    [self.lblCategory setBackgroundColor:[UIColor clearColor]];
	self.btnNotificationDetail.backgroundColor = [UIColor clearColor];
	self.btnNotificationForward.backgroundColor = [UIColor clearColor];
    self.btnNotificationConversation.backgroundColor = [UIColor clearColor];
	self.btnNotificationDelete.backgroundColor = [UIColor clearColor];
    self.btnNotificationShare.backgroundColor = [UIColor clearColor];
    self.btnNotificationWithImage.backgroundColor = [UIColor clearColor];
	self.img_user_unread_notif.backgroundColor = [UIColor clearColor];
	self.lblDuration.backgroundColor = [UIColor clearColor];
	
	[self.btnNotificationDetail setImage:[UIImage imageNamed:BtnNotifRead] forState:UIControlStateNormal];
	[self.btnNotificationForward setImage:[UIImage imageNamed:BtnNotifForward] forState:UIControlStateNormal];
	[self.btnNotificationDelete setImage:[UIImage imageNamed:BtnNotifDelete] forState:UIControlStateNormal];
//    [self.btnNotificationWithImage setImage:[UIImage imageNamed:Btn_Like] forState:UIControlStateNormal];
	
	self.lblUserName.font = [UIFont fontWithName:Font_OpneSans_SemiBol size:19];
	self.lblDuration.font = [UIFont fontWithName:Font_OpneSans_SemiBol size:10];
    self.lblCategory.font = [UIFont fontWithName:Font_Montserrat_Regular size:9];
    
    
	[self.btnNotificationForward.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Light size:11]];
    [self.btnNotificationShare.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Light size:11]];
	[self.btnNotificationDelete.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Light size:11]];

	self.cellBg.hidden = NO;
	self.btnNotificationDelete.hidden= NO;
	self.btnNotificationDetail.hidden = NO;
	self.btnNotificationForward.hidden = NO;
	self.btnNotificationProfile.hidden = NO;
    self.btnNotificationUserBlock.hidden = NO;
	self.lblUserName.hidden = NO;
	self.lblDuration.hidden = NO;
    self.lblCategory.hidden = NO;
	self.ProfileImg.hidden = NO;
	self.img_user_unread_notif.hidden = NO;
	self.imgNotifTime.hidden = NO;
    self.btnNotificationConversation.hidden = NO;
    self.btnNotificationShare.hidden = NO;
    self.btnNotificationFavorites.hidden = NO;
    self.btnNotificationWithImage.hidden = NO;
    self.imgNotifPictureBlab.hidden = NO;
    self.lblUnreadCount.hidden = YES;
    self.imgNotifPrivate.hidden = YES;
}

-(void)validateDisplayName:(NSDictionary *)dic{
	NSString *strDisplayName = [DataValidation checkNullString:[dic valueForKey:NAME]];
	if (strDisplayName.length==0) {
		strDisplayName = [NSString stringWithFormat:@"%@",[dic valueForKey:USER_NAME]];
	}
	self.lblUserName.text = strDisplayName;
}

-(void)setBoxValuesWithData:(NSDictionary *)dic{
	[self setFramesForControllsInCell];
	
    
	[self.ProfileImg setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:USER_PHOTO_PATH]]]];
	[Validation setCorners:self.ProfileImg];
	self.img_user_unread_notif.hidden = YES;
    
	if ([[dic valueForKey:IS_SENT_NOTIF_LIST] isEqualToString:@"1"]) {
		//sent
		[self.btnNotificationDetail setImage:[UIImage imageNamed:BtnNotifRead] forState:UIControlStateNormal];
        
        self.cellBg.image = [UIImage imageNamed:LilstBox_Bg_Notif];
		self.img_user_unread_notif.hidden = YES;
	}
	else{
		//rec
		if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IS_NOTIF_READ]]].length>0) {
			if ([[dic valueForKey:IS_NOTIF_READ] boolValue]) {
				[self.btnNotificationDetail setImage:[UIImage imageNamed:BtnNotifRead] forState:UIControlStateNormal];
                self.cellBg.image = [UIImage imageNamed:LilstBox_Bg_Notif];
			}
			else{
//				[self.btnNotificationDetail setImage:[UIImage imageNamed:BtnNotifUnRead] forState:UIControlStateNormal];
                [self.btnNotificationDetail setImage:[UIImage imageNamed:BtnNotifRead] forState:UIControlStateNormal];
				self.cellBg.image = [UIImage imageNamed:LilstBox_Bg_Notif];
//				self.img_user_unread_notif.hidden = NO;
			}
		}
		else{
		//	[self.btnNotificationDetail setImage:[UIImage imageNamed:BtnNotifUnRead] forState:UIControlStateNormal];
            [self.btnNotificationDetail setImage:[UIImage imageNamed:BtnNotifRead] forState:UIControlStateNormal];
			self.cellBg.image = [UIImage imageNamed:LilstBox_Bg_Notif];
//			self.img_user_unread_notif.hidden = NO;

		}
	}
	
	NSString *str = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_SENT_BEFORE]];
	self.lblDuration.text = str;
	CGSize size = CGSizeMake(40, self.lblDuration.frame.size.height);
	CGRect text = [str boundingRectWithSize:size
										options:NSStringDrawingUsesLineFragmentOrigin
									 attributes:@{NSFontAttributeName:self.lblDuration.font}
										context:nil];
	float xStart = self.lblDuration.frame.origin.x;
	
	size = text.size;
	self.lblDuration.frame = CGRectMake(xStart, self.lblDuration.frame.origin.y, size.width, self.lblDuration.frame.size.height);
	
	xStart += size.width+6;
    
    self.btnNotificationWithImage.hidden = YES;
    
    if ([DataValidation checkNullString:[dic valueForKey:ImagePath]].length > 0) {
        self.btnNotificationWithImage.frame  = CGRectMake(xStart, self.btnNotificationWithImage.frame.origin.y, self.btnNotificationWithImage.frame.size.width, self.btnNotificationWithImage.frame.size.height);
        
        xStart += self.btnNotificationWithImage.frame.size.width+6;
        
        self.btnNotificationWithImage.hidden = NO;
        
    }
   
    //category Name
    str = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_Category]];
    str = (([[DataValidation checkNullString:str] length] == 0)?@"Private":str);
	size = CGSizeMake(self.frame.size.width-(self.frame.size.width-self.btnNotificationDetail.frame.origin.x)-xStart, self.lblCategory.frame.size.height);
	text = [str boundingRectWithSize:size
                             options:NSStringDrawingUsesLineFragmentOrigin
                          attributes:@{NSFontAttributeName:self.lblCategory.font}
                             context:nil];
	
	size = text.size;
//	self.lblCategory.frame = CGRectMake(xStart, self.lblCategory.frame.origin.y, ((xStart+size.width+4)>312)?(312-xStart):(size.width+4), self.lblCategory.frame.size.height);
    self.lblCategory.frame = CGRectMake(xStart, self.lblCategory.frame.origin.y, (size.width>150)?(150):(size.width+4), self.lblCategory.frame.size.height);
	self.lblCategory.text = str;
	[self.lblCategory setBackgroundColor:[Validation getColorForAlphabet:self.lblCategory.text]];
    
    if ([DataValidation checkNullString:[dic valueForKey:@"ImagePath"]].length==0) {
        self.imgNotifPictureBlab.hidden = YES;
        CGRect frame = self.lblCategory.frame;
        frame.origin.x = 135;
        self.lblCategory.frame = frame;
    }
    else{
        self.imgNotifPictureBlab.hidden = NO;
        CGRect frame = self.lblCategory.frame;
        frame.origin.x = 160;
        self.lblCategory.frame = frame;
        if ([DataValidation checkNullString:[dic valueForKey:VideoPath]].length==0) {
            [self.imgNotifPictureBlab setImage:[UIImage imageNamed:@"icn_gallery.png"]];
        }
        else{
            [self.imgNotifPictureBlab setImage:[UIImage imageNamed:@"icn_vidi_blab.png"]];
        }
    }
    
    //private blab check
/*
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_PRIVATE]] boolValue]) {
        self.imgNotifPrivate.hidden = NO;
        //show private lock but check if pic img is hidden or not
        CGRect frame = self.lblCategory.frame;
        if ([self.imgNotifPictureBlab isHidden]) {
            //pic img is hidden, but lock img is visible
            self.imgNotifPrivate.frame = self.imgNotifPictureBlab.frame;
            frame.origin.x = 160;
        }
        else{
            //pic img is not hidden so picImg+lock img
            frame.origin.x = 180;
        }
        
        self.lblCategory.frame = frame;
//        self.imgNotifPrivate.frame = CGRectMake(xStart, self.imgNotifPrivate.frame.origin.y, 13, 15);
//        xStart += (self.imgNotifPrivate.frame.size.width+10);
    }
    else{
        self.imgNotifPrivate.hidden = YES;  //hide lock img
        
//        CGRect frame = self.lblCategory.frame;
//        if ([self.imgNotifPictureBlab isHidden]) {
//            frame.origin.x = 135;
//        }
//        else{
//            frame.origin.x = 160;
//        }
//        self.lblCategory.frame = frame;
    }
*/
    
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_PRIVATE]] boolValue]) {
        self.imgNotifPrivate.hidden = NO;
        //show private lock but check if pic img is hidden or not
        CGRect frame = self.lblCategory.frame;
        if ([self.imgNotifPictureBlab isHidden]) {
            //pic img is hidden, but lock img is visible
            self.imgNotifPrivate.frame = self.imgNotifPictureBlab.frame;
            frame.origin.x = 160;
        }
        else{
            //pic img is not hidden so picImg+lock img
            xStart = (self.imgNotifPictureBlab.frame.origin.x + self.imgNotifPictureBlab.frame.size.width+7);
            self.imgNotifPrivate.frame = CGRectMake(xStart, self.imgNotifPrivate.frame.origin.y, self.imgNotifPrivate.frame.size.width, self.imgNotifPrivate.frame.size.height);
            frame.origin.x = 180;
        }
        
        self.lblCategory.frame = frame;
    }
    else{
        self.imgNotifPrivate.hidden = YES;  //hide lock img
    }
    
    //-------
    
	[self validateDisplayName:dic];
	if ([DataValidation checkNullString:self.lblUserName.text].length > 0) {
		[self.lblUserName setTextColor:[Validation getColorForAlphabet:self.lblUserName.text]];
	}
    [self.btnNotificationFavorites setImage:[UIImage imageNamed:Btn_UnLike] forState:UIControlStateNormal];
    if ([[dic valueForKey:IS_LIKE] boolValue]) {
        [self.btnNotificationFavorites setImage:[UIImage imageNamed:Btn_Like] forState:UIControlStateNormal];
    }
    
    
    self.btnNotificationConversation.frame = self.lblUserName.frame;
    self.lblUserName.text = [@"@" stringByAppendingFormat:@"%@",self.lblUserName.text];
    
}

-(void)setFramesForConversationControlInCell{
    
    [self.cellBg setImage:[UIImage imageNamed:ListBox_User_Bg_Conversation]];
    
    
    [self.lblUserName setBackgroundColor:[UIColor clearColor]];

	self.btnNotificationDetail.backgroundColor = [UIColor clearColor];
    self.btnNotificationConversation.backgroundColor = [UIColor clearColor];
	self.btnNotificationDelete.backgroundColor = [UIColor clearColor];
    self.btnNotificationUserBlock.backgroundColor = [UIColor clearColor];
    
    self.lblCategory.hidden = YES;
    self.lblDuration.hidden = YES;
    self.imgNotifTime.hidden = YES;
    self.btnNotificationShare.hidden = YES;
    self.btnNotificationForward.hidden = YES;
    self.btnNotificationFavorites.hidden = YES;
    self.btnNotificationWithImage.hidden = YES;
    self.viewUnreadCount.hidden = YES;
    self.lblUnreadCount.hidden = YES;
    
    [self.btnNotificationDetail setImage:[UIImage imageNamed:BtnNotifRead] forState:UIControlStateNormal];
	[self.btnNotificationDelete setImage:[UIImage imageNamed:BtnNotifDelete] forState:UIControlStateNormal];

    self.lblUserName.font = [UIFont fontWithName:Font_OpneSans_SemiBol size:19];
    
	[self.btnNotificationDelete.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Light size:11]];
    
}

-(void)setBoxValuesForConversationUserListingWithData:(NSDictionary *)dic{
//    self.backgroundColor = [UIColor redColor];
    
	[self setFramesForConversationControlInCell];
    self.ProfileImg.image = nil;
    self.ProfileImg.imageURL = nil;
    
    self.cellBg.hidden = NO;
	self.btnNotificationDelete.hidden= NO;
	self.btnNotificationProfile.hidden = NO;
    self.btnNotificationUserBlock.hidden = NO;
	self.lblUserName.hidden = NO;
	self.ProfileImg.hidden = NO;
    self.btnNotificationConversation.hidden = NO;

    NSString *strGrpId = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:@"GroupID"]]];
    if (strGrpId.length > 0 && ![strGrpId isEqualToString:@"0"]) {
        //it is grp, so hide block button
        self.btnNotificationUserBlock.hidden = YES;
    }
    
	[self.ProfileImg setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:USER_PHOTO_PATH]]]];
	[Validation setCorners:self.ProfileImg];
	self.img_user_unread_notif.hidden = YES;
    self.viewUnreadCount.hidden = YES;
    self.viewUnreadCount.hidden = YES;
    self.lblUnreadCount.hidden = YES;
    
    [self.btnNotificationDetail setImage:[UIImage imageNamed:BtnNotifRead] forState:UIControlStateNormal];
    
    NSString *strUnreadCount = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:UNREAD_MESSAGE_COUNT]]];
    if ([strUnreadCount intValue] > 0) {

        self.viewUnreadCount.hidden = NO;
        self.lblUnreadCount.hidden = NO;
        self.lblUnreadCount.text = [NSString stringWithFormat:@"%@",strUnreadCount];
        self.lblUnreadCount.font = [UIFont fontWithName:Font_Montserrat_Regular size:15];
        self.lblUnreadCount.textColor = [UIColor whiteColor];
        self.lblUnreadCount.backgroundColor = UIColorFromRGB(0X00c2d9);
        
        self.viewUnreadCount.layer.borderColor = [UIColor whiteColor].CGColor;
        
        
        CGSize size = CGSizeMake(150, self.lblUnreadCount.frame.size.height);
        CGRect text = [self.lblUnreadCount.text boundingRectWithSize:size
                                 options:NSStringDrawingUsesLineFragmentOrigin
                              attributes:@{NSFontAttributeName:self.lblUnreadCount.font}
                                 context:nil];
        size = text.size;
        self.lblUnreadCount.frame = CGRectMake(self.lblUnreadCount.frame.origin.x, self.lblUnreadCount.frame.origin.y, size.width+11, self.lblUnreadCount.frame.size.height);
        self.viewUnreadCount.frame = CGRectMake(self.viewUnreadCount.frame.origin.x, self.viewUnreadCount.frame.origin.y, size.width+12, self.viewUnreadCount.frame.size.height);
        self.viewUnreadCount.layer.borderWidth = 2.0;
        self.viewUnreadCount.layer.cornerRadius = 5.0;
        self.lblUnreadCount.layer.cornerRadius = 4.0;
        self.lblUnreadCount.layer.masksToBounds = YES;

    }

    //-------
    
	[self validateDisplayName:dic];
	if ([DataValidation checkNullString:self.lblUserName.text].length > 0) {
		[self.lblUserName setTextColor:[Validation getColorForAlphabet:self.lblUserName.text]];
	}

    self.lblUserName.text = [@"@" stringByAppendingFormat:@"%@",self.lblUserName.text];
    
}
@end
