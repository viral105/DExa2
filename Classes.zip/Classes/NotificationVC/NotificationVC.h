//
//  NotificationVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/6/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "MenuOptionView.h"
#import <AVFoundation/AVFoundation.h>
#import "AFNetworkingDataTransaction.h"

@interface NotificationVC : UIViewController <UITableViewDataSource, UITableViewDelegate,UIActionSheetDelegate,UIAlertViewDelegate,AFNetworkingDataTransactionDelegate>
//menu
@property (nonatomic, strong) IBOutlet UIView               *viewNotificationMenuContainer;
//@property (nonatomic, strong) MenuOptionView                *MenuOption;
@property (nonatomic, strong) IBOutlet UILabel              *lblChangeNotifMode;
@property (nonatomic, strong) IBOutlet UIButton             *btnChangeNotifMode;
@property (nonatomic, strong) IBOutlet UIButton             *btnDelete;
@property (nonatomic, strong) IBOutlet UIButton             *btnMenu;
@property (nonatomic, strong) IBOutlet UIButton             *btnQuietMode;

//table
@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, strong) NSMutableSet					*selectedRows;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;

@property (nonatomic, readwrite) BOOL						isSentNotifList;
@property (nonatomic, readwrite) BOOL						isViewDidLoadCalled;

//@property (nonatomic, strong) ASIHTTPRequest				*request;
@property (nonatomic, strong) AFNetworkingDataTransaction   *request;
@property (nonatomic, strong) UIActivityIndicatorView		*activityLoading;
@property (nonatomic, readwrite) int						selectedIndex;

@property (nonatomic, retain) IBOutlet UILabel				*lbl_NoDataAvailable;

@property (nonatomic, strong) UIRefreshControl				*refresh;
@property (nonatomic, readwrite) BOOL						isServiceWaitingForResponse;

//@property (nonatomic, strong) SocialShareVC                 *objShareVC;
//@property (nonatomic, strong) MenuVC                        *objMenuVC;
@property (nonatomic, strong) IBOutlet  UILabel             *lblTotalNotifCount;

@property (nonatomic, readwrite) BOOL                       isAnimationStarted;
@property (nonatomic, readwrite) BOOL                       isEditing;

@property (nonatomic, strong) IBOutlet UITextField			*tfSearch;
@property (nonatomic, strong) IBOutlet UITextField          *tfSearchAtText;

-(void)get_ConversationListWithUsers;
//-(void)get_RecSent_NotifList;
-(void)setCountLabel;
-(void)loadConversationFromNotif;
@end
