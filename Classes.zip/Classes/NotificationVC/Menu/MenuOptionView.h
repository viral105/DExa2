//
//  MenuOptionView.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/6/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuOptionView : UIView

@property (nonatomic, strong) UILabel		*lblMenuTitle;

@property (nonatomic, strong) UIButton		*btnMenu;
@property (nonatomic, retain) UIImageView	*imgSeparator;

-(void)setViewItemsTitle:(NSString *)str_Title1;
@end
