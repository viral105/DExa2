//
//  MenuOptionView.m
//  WWHHAAZZAAPP
//
//  Created by s on 8/6/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "MenuOptionView.h"

@implementation MenuOptionView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
		
        self.backgroundColor = [UIColor clearColor];
        
		self.lblMenuTitle = [[UILabel alloc] init] ;
		self.imgSeparator = [[UIImageView alloc] init] ;
		self.btnMenu = [UIButton buttonWithType:UIButtonTypeCustom];
		
		float xStart = 5;
		//float yStart = (self.frame.size.height-14)/2;
		//xStart += 35;
		
		self.lblMenuTitle.frame = CGRectMake(xStart, (self.frame.size.height-14)/2, self.frame.size.width-xStart-10, 14);
	//	yStart += 20;
		
		self.imgSeparator.frame = CGRectMake(5, self.frame.size.height-1, self.frame.size.width-10, 1);
		self.imgSeparator.backgroundColor = [UIColor lightGrayColor];
		
		self.btnMenu.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
		
		self.lblMenuTitle.textAlignment = NSTextAlignmentCenter;
		
		self.lblMenuTitle.textColor = UIColorFromRGB(0X00c2d9);
		self.lblMenuTitle.font = [UIFont fontWithName:Font_Montserrat_Bold size:18];
		
		[self addSubview:self.lblMenuTitle];
		[self addSubview:self.imgSeparator];
		[self addSubview:self.btnMenu];
		
    }
    return self;
}

-(void)setViewItemsTitle:(NSString *)str_Title1 {
	
	[self.lblMenuTitle setText:str_Title1];
	
	
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
