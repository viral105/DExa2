//
//  ReportAbuseVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 19/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "ReportAbuseVC.h"
#import "MBProgressHUD.h"
#define IS_SELECTED             @"is_selected"


@interface ReportAbuseVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}
@end

@implementation ReportAbuseVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:[[UIApplication sharedApplication] keyWindow]];
	[[[UIApplication sharedApplication] keyWindow] addSubview:HUD];
    
    self.selectedSection = -1;
    [self LoadViewSetting];
    [self performSelectorInBackground:@selector(getAllReportAbuseOptions) withObject:nil];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSLog(@"%@",self.dic);
    appDelegate.currentVc = self;
    [ [NSNotificationCenter defaultCenter] addObserver: self selector: @selector(keyboardWillShow:)
                                                  name: UIKeyboardWillShowNotification object: nil];
    [ [NSNotificationCenter defaultCenter] addObserver: self selector: @selector(keyboardWillHide:)
                                                  name: UIKeyboardWillHideNotification object: nil];
    self.isKeyBoardHide = YES;
}

- (void) viewWillDisappear: (BOOL) animated {
    [super viewWillDisappear: animated];
    
    [ [NSNotificationCenter defaultCenter] removeObserver: self name: UIKeyboardDidShowNotification object: nil];
    [ [NSNotificationCenter defaultCenter] removeObserver: self name: UIKeyboardWillHideNotification object: nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark       Custom Methods

-(void)LoadViewSetting{
    
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    self.tblRect = self.tblData.frame;
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    self.FontList = [UIFont fontWithName:Font_Montserrat_Regular size:18];
    
    
    self.tvOther = [[UITextView alloc] initWithFrame:CGRectMake(10, 10, 300, 80)];
    self.tvOther.delegate = self;
    self.tvOther.backgroundColor = [UIColor clearColor];
    [self.tvOther setTextColor:UIColorFromRGB(0X00c2d9)];
    [self.tvOther setFont:self.FontList];
    
    self.imgSelected = [[UIImageView alloc] init];
    [self.imgSelected setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
    self.imgSelected.contentMode = UIViewContentModeRight;
    
    self.arrData = [[NSMutableArray alloc] init];
}

-(IBAction)btnBackClicked:(id)sender{
    [self dismissViewControllerAnimated:YES completion:NULL];
}

-(void)getAllReportAbuseOptions{
   	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_ALL_REPORT_ABUSE_OPTION withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:nil forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:1];
    }
//	request.delegate = self;
//	request.tag = 1;
	strUrl = nil;
}

-(IBAction)btnReportAbuse:(id)sender{
    NSString *str = [self.tvOther.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
//    if (self.isOtherSelected && str.length==0) { // This condition changed by viral as flag is getting changed in viewForHeaderInSection
    if ([[[self.arrData objectAtIndex:self.selectedSection] valueForKey:NAME] caseInsensitiveCompare:@"other"]==NSOrderedSame && self.selectedSection==self.arrData.count-1 && str.length == 0) {
        [AlertHandler alertTitle:MESSAGE message:@"Please enter text for other" delegate:self tag:3 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        return;
    }
    // Added by viral for sending text with service if other selected
    if ([[[self.arrData objectAtIndex:self.selectedSection] valueForKey:NAME] caseInsensitiveCompare:@"other"]==NSOrderedSame && self.selectedSection==self.arrData.count-1) {
        self.isOtherSelected = YES;
    }
    else{
        self.isOtherSelected = NO;
    }
    [self addReportAbuseWithOther:self.isOtherSelected];
}
-(void)addReportAbuseWithOther:(BOOL)isOther{
    
    NSString *strOtherText = @"";
    if (isOther) {
        strOtherText = [DataValidation checkNullString:self.tvOther.text];
    }
    [self.view setUserInteractionEnabled:NO];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[self.dic valueForKey:@"message"],KeyValue,@"SoundID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"ID"],KeyValue,@"AbuseReportMasterID",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[self.dic valueForKey:MESSAGE_CHAT_ID],KeyValue,@"MsgID",KeyName, nil],@"3",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:strOtherText,KeyValue,@"Detail",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.reportAbuseFrom],KeyValue,@"Type",KeyName, nil],@"6",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:ADD_REPORT_ABUSE withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [self.view setUserInteractionEnabled:YES];
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:2];
    }
//	request.delegate = self;
//	request.tag = 2;
	strUrl = nil;
}
-(void)btnSelectAbuseClicked:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    if (btn.tag!=self.selectedSection) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
        [dic setValue:@"1" forKey:IS_SELECTED];
        [self.arrData replaceObjectAtIndex:btn.tag withObject:dic];
        dic = nil;
        
        NSMutableIndexSet *mutableIndexSet = [[NSMutableIndexSet alloc] init];
        [mutableIndexSet addIndex:btn.tag];
        
        if (self.selectedSection != -1 && self.selectedSection!=btn.tag) {
            NSMutableDictionary *dicPrev = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.selectedSection]];
            [dicPrev setValue:@"0" forKey:IS_SELECTED];
            [self.arrData replaceObjectAtIndex:self.selectedSection withObject:dicPrev];
            dicPrev = nil;
            
            [mutableIndexSet addIndex:self.selectedSection];
        }
        
        [self.tblData beginUpdates];
        [self.tblData reloadSections:mutableIndexSet withRowAnimation:UITableViewRowAnimationNone];
        [self.tblData endUpdates];
        if ([[[self.arrData objectAtIndex:btn.tag] valueForKey:NAME] caseInsensitiveCompare:@"other"]==NSOrderedSame && btn.tag==self.arrData.count-1) {
            [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForItem:0 inSection:self.arrData.count-1] atScrollPosition:UITableViewScrollPositionBottom animated:NO];
            if(self.tvOther.text.length!=0){
                self.tvOther.text = @"";
            }
            self.isOtherSelected = YES;
            [self.tvOther becomeFirstResponder];
        }
        else{
            self.isOtherSelected = NO;
        }
        self.selectedSection = (int)btn.tag;
        mutableIndexSet = nil;
        
    }
    
}

#pragma mark  UITableViewDelegate

-(CGSize)getHeightForSection:(int)section{
    NSString *strText = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:NAME]];
    
    CGRect text = [strText boundingRectWithSize:CGSizeMake(320, 1000)
                                        options:NSStringDrawingUsesLineFragmentOrigin
                                     attributes:@{NSFontAttributeName:self.FontList}
                                        context:nil];
    strText = nil;
    return text.size;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 110;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    int height = ([self getHeightForSection:(int)section].height+10);
    
    if (height < 75) {
        height = 75;
    }
    
    return height;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    CGSize size = [self getHeightForSection:(int)section];
    
    int height = (size.height+10);
    
    if (height < 75) {
        height = 75;
    }

    
    UIView *viewLoadMore = [[UIView alloc] initWithFrame:CGRectMake(0, 0, DEVICE_WIDTH, height)];
    viewLoadMore.backgroundColor = [UIColor clearColor];
    UIButton *btnSelectAbuse = [UIButton buttonWithType:UIButtonTypeCustom];
    btnSelectAbuse.frame = CGRectMake(5, 5, 280, height);
    btnSelectAbuse.titleLabel.numberOfLines = 0;
    [btnSelectAbuse setTitle:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:NAME]] forState:UIControlStateNormal] ;
    [btnSelectAbuse addTarget:self action:@selector(btnSelectAbuseClicked:) forControlEvents:UIControlEventTouchUpInside];
    btnSelectAbuse.tag = section;
    btnSelectAbuse.backgroundColor = [UIColor clearColor];
    [btnSelectAbuse.titleLabel setFont:self.FontList];
    btnSelectAbuse.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [btnSelectAbuse setTitleColor:UIColorFromRGB(0X616161) forState:UIControlStateNormal];
    [viewLoadMore addSubview:btnSelectAbuse];
    
    
    self.isOtherSelected = NO;
    if ([[[self.arrData objectAtIndex:section] valueForKey:IS_SELECTED] boolValue]) {
        [self.imgSelected removeFromSuperview];
        self.imgSelected.frame = CGRectMake(DEVICE_WIDTH-45, (height-35)/2, 35, 35);
        self.isOtherSelected = YES;
        [viewLoadMore addSubview:self.imgSelected];
    }
    
    return viewLoadMore;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.arrData.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == self.arrData.count-1 && [[[self.arrData objectAtIndex:section] valueForKey:NAME] caseInsensitiveCompare:@"other"]==NSOrderedSame) {
        if ([[[self.arrData objectAtIndex:section] valueForKey:IS_SELECTED] boolValue]) {
         return 1;
        }
        return 0;
    }
    else return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    [cell clearsContextBeforeDrawing];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
        UIImageView *imgBg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:LilstBox_Bg]];
        imgBg.frame = CGRectMake(5, 5, 310, 100);
        [cell.contentView addSubview:imgBg];
        [self.tvOther removeFromSuperview];
        [cell.contentView addSubview:self.tvOther];
    }
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}

- (void) keyboardWillShow: (NSNotification *) notification {
    
    if (self.isKeyBoardHide) {
        CGRect keyboardFrame = [ [ [notification userInfo] objectForKey: UIKeyboardFrameBeginUserInfoKey] CGRectValue];
        
       // self.tblData.contentOffset = CGPointMake(self.tblData.contentOffset.x, self.tblData.contentOffset.y+20);
        self.tblData.frame = CGRectMake(self.tblData.frame.origin.x, self.tblData.frame.origin.y, self.tblData.frame.size.width,
                                        self.view.frame.size.height - self.tblData.frame.origin.y - keyboardFrame.size.height-50);
        
        [self scrollToBottom];

        UIView *viewToolBar = [[UIView alloc] initWithFrame:CGRectMake(0, DEVICE_HEIGHT-keyboardFrame.size.height-50, DEVICE_WIDTH, 50)];
        viewToolBar.backgroundColor = [UIColor grayColor];
        viewToolBar.alpha = 0.5;
        viewToolBar.tag = 1112;
        [self.view addSubview:viewToolBar];
        
        UIButton *btnDoneWithKeyboard = [UIButton buttonWithType:UIButtonTypeCustom];
        btnDoneWithKeyboard.frame = CGRectMake(5,0 ,100, 50);
        btnDoneWithKeyboard.tag = 1113;
        [btnDoneWithKeyboard setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [btnDoneWithKeyboard addTarget:self action:@selector(geoLocationDoneBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [btnDoneWithKeyboard setTitle:@"Done" forState:UIControlStateNormal];
        [viewToolBar addSubview:btnDoneWithKeyboard];
        self.isKeyBoardHide = NO;
    }
}
-(void)scrollToBottom{
    
    CGRect rect = [self.tblData rectForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:self.arrData.count-1]];
    [self.tblData scrollRectToVisible:rect animated:YES];
    //[self.tblData scrollRectToVisible:CGRectMake(0, self.tblData.contentSize.height - self.tblData.bounds.size.height, self.tblData.bounds.size.width, self.tblData.bounds.size.height) animated:NO];
    
}

- (void) keyboardWillHide: (NSNotification *) notification {
    self.tblData.frame = self.tblRect;
    UIView *viewToolBr = (UIView *)[self.view viewWithTag:1112];
    UIButton *btnDoneWithKeyboard = (UIButton *)[viewToolBr viewWithTag:1113];
    [btnDoneWithKeyboard removeFromSuperview];
    btnDoneWithKeyboard = nil;
    
    [viewToolBr removeFromSuperview];
    viewToolBr = nil;
    
    self.isKeyBoardHide = YES;
}

-(void)geoLocationDoneBtnClicked:(id)sender{
    [self.tvOther resignFirstResponder];
}

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;

    NSLog(@"notification Response");
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];
	
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (request.tag == 1) {
                if (self.arrData == nil) {
                    self.arrData = [[NSMutableArray alloc] init];
                }
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            
                            for (int i= 0; i<arr.count; i++) {
                                NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[arr objectAtIndex:i]];
                                if (i == 0) {
                                    [dic setValue:@"1" forKey:IS_SELECTED];
                                    self.selectedSection = 0;
                                }
                                else{
                                    [dic setValue:@"0" forKey:IS_SELECTED];
                                }
                                [arr replaceObjectAtIndex:i withObject:dic];
                                dic = nil;
                            }
                            
                            if (arr.count>0) {
                                [self.arrData addObjectsFromArray:arr];
                                
                            }
                            arr = nil;
                        }
                        response = nil;
                        
                        [HUD hide:YES];
                    }
                    [self.tblData reloadData];
                }

            }
            else if (request.tag == 2){
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        [self.delegate setReportAsPosted];
                        [Validation showToastMessage:@"Report Sent." displayDuration:SUCCESS_MSG_DURATION];
                        [self performSelector:@selector(dismissView) withObject:nil afterDelay:SUCCESS_MSG_DURATION];
                        
//                        id response = [dicResponse objectForKey:RESPONSE];
//                        if (response != nil) {
                        
//                        }
                    }
                }
            }
            
        }
    }
    else{
        [HUD hide:YES];
    }
	
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

-(void)dismissView{
    [self.view setUserInteractionEnabled:YES];
    [self dismissViewControllerAnimated:YES completion:NULL];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
