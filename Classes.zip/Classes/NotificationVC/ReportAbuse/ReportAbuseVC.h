//
//  ReportAbuseVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 19/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ReportAbuseVCDelegate;

@protocol ReportAbuseVCDelegate <NSObject>
- (void)setReportAsPosted;

@end


@interface ReportAbuseVC : UIViewController <UITableViewDataSource, UITableViewDelegate,UITextViewDelegate>

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;
@property (nonatomic, strong) NSDictionary                  *dic;
@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, strong) NSMutableDictionary           *DicReportAbuseSectionHeight;
@property (nonatomic, retain) UIFont                        *FontList;

@property (nonatomic, strong) UIImageView                   *imgSelected;
@property (nonatomic, strong) UITextView                    *tvOther;

@property (nonatomic, readwrite)CGRect                      tblRect;
@property (nonatomic, readwrite) BOOL                       isKeyBoardHide;
@property (nonatomic, readwrite) int                        selectedSection;
@property (nonatomic, readwrite) BOOL                       isOtherSelected;
@property (nonatomic ,assign) id <ReportAbuseVCDelegate>       delegate;
@property (nonatomic, readwrite) int                       reportAbuseFrom; // 0 user conversation      1 Hash conversation

@end
