//
//  NotificationCell.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/6/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"
@interface NotificationCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UIImageView		*cellBg;
@property (nonatomic, strong) IBOutlet UIImageView		*img_user_unread_notif;
@property (nonatomic, strong) IBOutlet AsyncImageView	*ProfileImg;
@property (nonatomic, strong) IBOutlet UIButton			*btnNotificationProfile;
@property (nonatomic, strong) IBOutlet UILabel			*lblUserName;
//@property (nonatomic, strong) IBOutlet UIView			*viewVerticalSaperator;
//@property (nonatomic, strong) IBOutlet UIView			*viewHorizontalSaperator;
@property (nonatomic, strong) IBOutlet UIButton			*btnNotificationDetail;
@property (nonatomic, strong) IBOutlet UIButton			*btnNotificationForward;
@property (nonatomic, strong) IBOutlet UIButton			*btnNotificationShare;
@property (nonatomic, strong) IBOutlet UIButton			*btnNotificationConversation;
@property (nonatomic, strong) IBOutlet UIButton			*btnNotificationDelete;
@property (nonatomic, strong) IBOutlet UIButton			*btnNotificationFavorites;
@property (nonatomic, strong) IBOutlet UIButton			*btnNotificationUserBlock;

@property (nonatomic, strong) IBOutlet UILabel			*lblDuration;
@property (nonatomic, strong) IBOutlet UILabel			*lblCategory;
@property (nonatomic, strong) IBOutlet UIImageView		*imgNotifTime;
@property (nonatomic, strong) IBOutlet UIImageView		*imgNotifPictureBlab;
@property (nonatomic, strong) IBOutlet UIImageView		*imgNotifPrivate;
@property (nonatomic, strong) IBOutlet UIButton			*btnDelete;
@property (nonatomic, strong) IBOutlet UIButton         *btnNotificationWithImage;
@property (nonatomic, strong) IBOutlet UILabel          *lblUnreadCount;
@property (nonatomic, strong) IBOutlet UIView           *viewUnreadCount;

-(void)setBoxValuesWithData:(NSDictionary *)dic;
-(void)setBoxValuesForConversationUserListingWithData:(NSDictionary *)dic;

@end
