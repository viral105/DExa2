//
//  AddFriendsVC.h
//  WWHHAAZZAAPP
//
//  Created by multicoreViral on 7/8/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddFriendsVC : UIViewController<MFMessageComposeViewControllerDelegate>{
    
}

@property (nonatomic, strong) IBOutlet UILabel             *lblTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblContactTitle;
@property (strong, nonatomic) IBOutlet UITextField *tfContact;
@property (strong, nonatomic) IBOutlet UIButton *btnSync;
@property (strong, nonatomic) IBOutlet UIButton *btnBackOrMenu;
@property (strong, nonatomic) IBOutlet UIButton *btnMore;
@property (strong, nonatomic) IBOutlet UIView *viewInsindScrlView;
@property (strong, nonatomic) IBOutlet UIScrollView *scrlView;

@property (nonatomic,strong) IBOutlet UIButton *btnFacebook;
@property (nonatomic,strong) IBOutlet UIButton *btnFriendReq;
@property (nonatomic,strong) IBOutlet UIButton *btnMessages;

@property (nonatomic,strong) IBOutlet UILabel *lblFacebook;
@property (nonatomic,strong) IBOutlet UILabel *lblFriendReq;
@property (nonatomic,strong) IBOutlet UILabel *lblMessages;

@property (assign, nonatomic) int index;// 0 show menu 1 show back
@property (assign, nonatomic) int indexShowFriendReq;// 0 Friend Request screen 1 Show current screen
@property (nonatomic, strong) ASIHTTPRequest			*request;
- (IBAction)btnSync_Clicked:(id)sender;
- (IBAction)btnFacebook_Clicked:(id)sender;
@property (assign,nonatomic) BOOL isFromContact;
@property (strong,nonatomic) NSMutableArray *arrUserList;

@end
