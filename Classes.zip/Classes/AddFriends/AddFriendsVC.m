//
//  AddFriendsVC.m
//  WWHHAAZZAAPP
//
//  Created by multicoreViral on 7/8/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "AddFriendsVC.h"
#import "FbOrContactUserListVC.h"

@interface AddFriendsVC ()<MBProgressHUDDelegate> {
    MBProgressHUD *HUD;
    NSArray *arrSettingText;
    NSString *strFBID;
}
@property (nonatomic,strong)NSString *strFBID;
@end

@implementation AddFriendsVC
@synthesize strFBID;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    
    if (self.indexShowFriendReq==0) {
        [self performSegueWithIdentifier:OTHER_FRNDREQ_NOTIF_LIST_VC sender:self];
    }
    
    self.scrlView.contentSize = CGSizeMake(self.viewInsindScrlView.frame.size.width, self.viewInsindScrlView.frame.size.height);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewWillAppear:(BOOL)animated{
    
    appDelegate.currentVc = self;
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
    
    NSString *strMobileNo = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHONE]];
    if (strMobileNo.length!=0) {
        self.btnSync.frame = CGRectMake(self.btnSync.frame.origin.x, self.tfContact.frame.origin.y, self.btnSync.frame.size.width, self.btnSync.frame.size.height);
        self.tfContact.hidden = YES;
        self.lblContactTitle.text = @"Sync contacts from Contact Book to blab with you.";
        
        [self setUpView];
    }
    if (self.index==0) {
        [self.btnBackOrMenu setImage:[UIImage imageNamed:@"btn_menu.png"] forState:UIControlStateNormal];
        [self.btnBackOrMenu removeTarget:self action:@selector(btnBack_Clicked:) forControlEvents:UIControlEventTouchUpInside];
        [self.btnBackOrMenu removeTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
        [self.btnBackOrMenu addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    }
    else{
        [self.btnBackOrMenu setImage:[UIImage imageNamed:@"icon_topbar_transparent.png"] forState:UIControlStateNormal];
        self.btnMore.hidden = YES;
    }
    
}

-(void)setUpView
{
    int ypos = self.btnSync.frame.origin.y + self.btnSync.frame.size.height+3;
    
    self.lblFacebook.frame = CGRectMake(self.lblFacebook.frame.origin.x, ypos, self.lblFacebook.frame.size.width, self.lblFacebook.frame.size.height);
    
    ypos = self.lblFacebook.frame.origin.y + self.lblFacebook.frame.size.height+3;
    
    self.btnFacebook.frame = CGRectMake(self.btnFacebook.frame.origin.x, ypos, self.btnFacebook.frame.size.width, self.btnFacebook.frame.size.height);
    
    ypos = self.btnFacebook.frame.origin.y + self.btnFacebook.frame.size.height+3;
    
    self.lblFriendReq.frame = CGRectMake(self.lblFriendReq.frame.origin.x, ypos, self.lblFriendReq.frame.size.width, self.lblFriendReq.frame.size.height);
    
    ypos = self.lblFriendReq.frame.origin.y + self.lblFriendReq.frame.size.height+3;
    
    self.btnFriendReq.frame = CGRectMake(self.btnFriendReq.frame.origin.x, ypos, self.btnFriendReq.frame.size.width, self.btnFriendReq.frame.size.height);
    
    ypos = self.btnFriendReq.frame.origin.y + self.btnFriendReq.frame.size.height+3;
    
    self.lblMessages.frame = CGRectMake(self.lblMessages.frame.origin.x, ypos, self.lblMessages.frame.size.width, self.lblMessages.frame.size.height);
    
    ypos = self.lblMessages.frame.origin.y + self.lblMessages.frame.size.height+3;
    
    self.btnMessages.frame = CGRectMake(self.btnMessages.frame.origin.x, ypos, self.btnMessages.frame.size.width, self.btnMessages.frame.size.height);
    
    ypos = self.btnMessages.frame.origin.y + self.btnMessages.frame.size.height;
    
    // self.scrlView.contentSize = CGSizeMake(self.viewInsindScrlView.frame.size.width, ypos);
    
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    NSLog(@"segue.identifier %@",segue.identifier);
    if ([segue.identifier isEqualToString:@"FbOrContactUserListVC"]) {
        FbOrContactUserListVC *obj = [segue destinationViewController];
        obj.arrUsers = self.arrUserList;
        obj.isFromContact = self.isFromContact;
    }
}


- (IBAction)btnSync_Clicked:(id)sender {
    [self performSelector:@selector(SendUserContactListToServer) withObject:nil];
}

- (IBAction)btnFacebook_Clicked:(id)sender {
    [self performSelector:@selector(fetchFriendListFromFB) withObject:nil];
}
-(IBAction)btnBack_Clicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnSearch_Clicked:(id)sender{
    appDelegate.selectedMenuIndex = 5;

    SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];

    [UIView transitionWithView:self.navigationController.view
                  duration:0.5
                   options:UIViewAnimationOptionTransitionCrossDissolve
                animations:^{
                    [self.navigationController pushViewController:ivc animated:NO];
                }
                completion:nil];
}
#pragma mark - Open Message

-(IBAction) openMessageView
{
    //set message text
    NSString * message = @"Come message me on Blabeey :\n\niPhone - https://itunes.apple.com/us/app/blabeey/id966451741?mt=8\n\nAndroid - https://play.google.com/store/apps/details?id=com.blab.blabeey";
    
    MFMessageComposeViewController *messageController = [[MFMessageComposeViewController alloc] init];
    messageController.messageComposeDelegate = self;
    [messageController setBody:message];
    
    [self presentViewController:messageController animated:YES completion:nil];
}

#pragma mark - MFMailComposeViewControllerDelegate methods

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult) result
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark UITextfieldDelegate

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (range.location==1 && ![string isEqualToString:@""]) {
        NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"1234567890"];
        s = [s invertedSet];
        NSRange r = [string rangeOfCharacterFromSet:s];
        if (r.location != NSNotFound) {
            return FALSE;
        }
    }
    return TRUE;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return TRUE;
}

-(void)SendUserContactListToServer{
    
    __block NSArray *arr = nil;
    arr = [DataValidation getAllContacts];
    
    if (arr!=nil) {
        if (arr.count>0) {
            if (self.request !=nil) {
                self.request = nil;
            }
            
            [self performSelector:@selector(sendContactToServer:) withObject:arr];
        }
    }
}

-(void)sendContactToServer:(NSArray *)arr{
    //[Validation showLoadingIndicator];
    [HUD show:YES];
    NSString *strContactNum;
    NSDictionary *dic1;
    if ([DataValidation checkNullString:self.tfContact.text].length==0) {
        strContactNum = @"";
        dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                              [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                              [NSDictionary dictionaryWithObjectsAndKeys:[arr componentsJoinedByString:@"|"],KeyValue,@"PhoneList",KeyName, nil],@"2",
                              nil];
    }
    else{
        strContactNum = self.tfContact.text;
        dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                              [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                              [NSDictionary dictionaryWithObjectsAndKeys:strContactNum,KeyValue,@"MyPhone",KeyName, nil],@"2",
                              [NSDictionary dictionaryWithObjectsAndKeys:[arr componentsJoinedByString:@"|"],KeyValue,@"PhoneList",KeyName, nil],@"3",
                              nil];
    }
    
//    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_USER_CONTACT_LIST withParameters:nil];
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_FB_OR_CONTACT_USER withParameters:nil];
    ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:1];
    }
    //	request.delegate = self;
    //	request.tag = 3;
    strUrl = nil;
}
#pragma mark Facebook Friend

-(void)fetchFriendListFromFB{
    //[self performSelector:@selector(addFaceBookFriends) withObject:nil];
    [self performSelector:@selector(addFaceBookFriends) withObject:nil afterDelay:0.5];
}
-(void)addFaceBookFriends{
    NSLog(@"fb btn pressed");
    //	[Validation showLoadingIndicator];
    
    [HUD show:YES];
    
    if (!FBSession.activeSession.isOpen) {
        // if the session is closed, then we open it here, and establish a handler for state changes
        [FBSession openActiveSessionWithReadPermissions:@[@"public_profile", @"email", @"user_friends"]
                                           allowLoginUI:YES
                                      completionHandler:^(FBSession *session,
                                                          FBSessionState state,
                                                          NSError *error) {
                                          if (error) {
                                              [HUD hide:YES];
                                              UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                                                  message:@"Could not get your Facebook data.\nPlease check you internet connectivity or try later."
                                                                                                 delegate:nil
                                                                                        cancelButtonTitle:@"OK"
                                                                                        otherButtonTitles:nil];											  [alertView show];
                                          } else if (session.isOpen) {
                                              NSLog(@"facebook login");
                                              [self getUserInfo];
                                          }
                                      }];
        return;
    }
    else if (FBSession.activeSession.isOpen) {
        NSLog(@"facebook login");
        [self getUserInfo];
    }
}

- (void)GetUserFriendList {
    
    [FBRequestConnection startWithGraphPath:@"/me/friends"
                                 parameters:nil
                                 HTTPMethod:@"GET"
                          completionHandler:^(
                                              FBRequestConnection *connection,
                                              id result,
                                              NSError *error
                                              ) {
                              /* handle the result */
                              NSLog(@"%@",result);
                              NSArray *arr = [((NSArray *)[result valueForKey:@"data"]) valueForKey:@"id"];
                              [self addFacebookFreinds:arr];
                          }
     ];
}

-(void)getUserInfo{
    //[Validation showLoadingIndicator];
    
    [HUD show:YES];
    
    [[FBRequest requestForMe] startWithCompletionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
        //result contains a dictionary of your user, including Facebook ID.
        NSLog(@"result=  %@",result);
        self.strFBID = [result valueForKey:@"id"];
        NSLog(@"self.strFBID %@",self.strFBID);
        [self GetUserFriendList];
    }];
}

-(void)addFacebookFreinds:(NSArray *)arrFbId{
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[arrFbId componentsJoinedByString:@"|"]],KeyValue,@"FacebookIDs",KeyName, nil],@"2",
                         nil];
    
//    NSString *strUrl = [WebServiceContainer getServiceURL:ADD_FB_FRIENDS withParameters:nil];
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_FB_OR_CONTACT_USER withParameters:nil];
    ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:2];
    }
    //	request.delegate = self;
    //	request.tag = 4;
    strUrl = nil;
}
-(void)checkFBID_Exist{
    NSLog(@"%@",[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]);
    if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]].length == 0) {
        //	[Validation showLoadingIndicator];
        
        [HUD show:YES];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"emailID",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"userName",KeyName, nil],@"2",
                             [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:self.strFBID isGeneral:YES],KeyValue,@"facebookID",KeyName, nil],@"3",
                             [NSDictionary dictionaryWithObjectsAndKeys:@"-1",KeyValue,@"IsActive",KeyName, nil],@"4",
                             nil];
        
        if (self.request != nil) {
            self.request = nil;
        }
        NSString *strUrl = [WebServiceContainer getServiceURL:CHECK_USER_EXIST withParameters:nil];
        self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
        if (self.request == nil) {
            [HUD hide:YES];
        }
        else{
            [self.request setDelegate:self];
            [self.request setTag:3];
        }
        //		self.request.delegate = self;
        //		self.request.tag = 5;
        strUrl = nil;
    }
    else{
        [HUD hide:YES];
        [Validation showToastMessage:@"Friends added successfully.\nPlease check your friend list." displayDuration:SUCCESS_MSG_DURATION];
    }
}
-(void)updateUserFBId{
    //[Validation showLoadingIndicator];
    
    [HUD show:YES];
    
    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Name",KeyName, nil],@"1",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Phone",KeyName, nil],@"2",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Email",KeyName, nil],@"3",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"UserName",KeyName, nil],@"4",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Pwd",KeyName, nil],@"5",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"DateOfBirth",KeyName, nil],@"6",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"Gender",KeyName, nil],@"7",
                          [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"ID",KeyName, nil],@"8",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"ImgData",KeyName, nil],@"9",
                          [NSDictionary dictionaryWithObjectsAndKeys:self.strFBID,KeyValue,@"FacebookID",KeyName, nil],@"10",
                          nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:EDIT_USER_PROFILE withParameters:nil];
    ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:4];
    }
    //	request.delegate = self;
    //	request.tag = 6;
    strUrl = nil;
    
}
#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
    NSError *error = nil;
    
    [HUD hide:YES];
    
    NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
                                                                 options:0
                                                                   error:&error];
    NSLog(@"response =%@",dicResponse);
    if (dicResponse != nil) {
        
        if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]) {
            
            if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                
                NSLog(@"dic = %@",dicResponse);
                [HUD hide:YES];
                [appDelegate callLogOutService];
            }
            else{
                if (request.tag == 1) {
                    //contact list
                    NSArray *arResponse = [dicResponse objectForKey:RESPONSE];
                    if (arResponse.count!=0) {
                        if ([DataValidation checkNullString:self.tfContact.text].length!=0) {
                            [[NSUserDefaults standardUserDefaults] setObject:self.tfContact.text forKey:LOGIN_USER_PHONE];
                            [[NSUserDefaults standardUserDefaults] synchronize];
                            //                            [Validation showToastMessage:@"Contacts added successfully.\nPlease check your friend list." displayDuration:ERROR_MSG_DURATION];
//                            [AlertHandler alertTitle:MESSAGE message:@"We have found a few of your friends in Blabeey.  Check your friend list and start a fun Blabeey conversation" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                            self.tfContact.text = @"";
                            [self.tfContact resignFirstResponder];
                            self.btnSync.frame = CGRectMake(self.btnSync.frame.origin.x, self.tfContact.frame.origin.y, self.btnSync.frame.size.width, self.btnSync.frame.size.height);
                            self.tfContact.hidden = YES;
                            self.lblContactTitle.text = @"Sync contacts from Contact Book to blab with you.";
                            [self setUpView];

                        }
                        else{
//                            [AlertHandler alertTitle:MESSAGE message:@"We have found a few of your friends in Blabeey.  Check your friend list and start a fun Blabeey conversation" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                            //                                [Validation showToastMessage:@"Contacts added successfully.\nPlease check your friend list." displayDuration:ERROR_MSG_DURATION];
                        }
                        self.isFromContact = YES;
                        self.arrUserList = [NSMutableArray new];
                        [self.arrUserList addObjectsFromArray:arResponse];
                        [self performSegueWithIdentifier:@"FbOrContactUserListVC" sender:self];
                    }
                    else{
                        [AlertHandler alertTitle:MESSAGE message:@"No friends found from your contacts" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                    }
                    self.request = nil;
                }
                else if (request.tag == 2){
                    //add fb friends
                    NSArray *arResponse = [dicResponse objectForKey:RESPONSE];
                    self.arrUserList = [NSMutableArray new];
                    [self.arrUserList addObjectsFromArray:arResponse];
                    
                    if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]].length > 0) {
//                        [Validation showToastMessage:@"Friends added successfully.\nPlease check your friend list." displayDuration:SUCCESS_MSG_DURATION];
                        
                        
                        if (arResponse.count!=0) {
                            
                            [self performSegueWithIdentifier:@"FbOrContactUserListVC" sender:self];
                            self.isFromContact = NO;
                        }
                        else{
                            [AlertHandler alertTitle:MESSAGE message:@"No friends found from your facebook" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                        }
                    }
                    else{
                        [self checkFBID_Exist];
                    }
                }
                else if (request.tag == 4){
                    //edit profile for fbid
                    id response = [dicResponse objectForKey:RESPONSE];
                    if (response != nil) {
                        NSMutableDictionary *dic = nil;
                        if ([[response valueForKey:RESPONSE] isKindOfClass:[NSDictionary class]]) {
                            dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)response];
                        }
                        else if ([[response valueForKey:RESPONSE] isKindOfClass:[NSArray class]]){
                            dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[response objectAtIndex:0]];
                        }
                        NSLog(@"di  -%@",dic);
                        
                        [Validation setAllKeyValueFromData:dic];
                        [HUD hide:YES];
                        
                        dic = nil;
//                        [Validation showToastMessage:@"Friends added successfully.\nPlease check your friend list." displayDuration:SUCCESS_MSG_DURATION];
                        if ([self.arrUserList count]!=0){
                            [self performSegueWithIdentifier:@"FbOrContactUserListVC" sender:self];
                            self.isFromContact = NO;
                        }
                        else{
                            [AlertHandler alertTitle:MESSAGE message:@"No friends found from your facebook" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                        }
                    }
                    
                }
            }
        }
        
        if (request.tag == 3){
            //check fbid exists
            
            id response = [dicResponse objectForKey:RESPONSE];
            if ([response isKindOfClass:[NSArray class]]) {
                if (((NSDictionary *)response).count>0) {
                    //so call login service
                    if ([response isKindOfClass:[NSArray class]]) {
                        int breakReason = -1;
                        NSArray *arr = [NSArray arrayWithArray:(NSArray *)response];
                        for (int i = 0; i<arr.count; i++) {
                            for (int y = 0; y<3; y++) {
                                switch (y) {
                                    case 0:{
                                        //check for username
                                        
                                    }
                                        break;
                                    case 1:{
                                        //check for email
                                        
                                    }
                                        break;
                                    case 2:{
                                        //check for fb ID
                                        if ([[self.strFBID lowercaseString] isEqualToString:[[[arr objectAtIndex:i] valueForKey:FB_ID] lowercaseString]]) {
                                            breakReason = 3;
                                            break;
                                        }
                                    }
                                        break;
                                    default:
                                        break;
                                }
                                if (breakReason != -1) {
                                    break;
                                }
                            }
                            if (breakReason != -1) {
                                break;
                            }
                        }
                        
                        if (breakReason == 3) {
                            //fb id exists
                            if ([self.arrUserList count]!=0){
                                [self performSegueWithIdentifier:@"FbOrContactUserListVC" sender:self];
                                self.isFromContact = NO;
                            }
                            else{
                                [AlertHandler alertTitle:MESSAGE message:@"No friends found from your facebook" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                            }
//                            [Validation showToastMessage:@"Friends added successfully.\nPlease check your friend list." displayDuration:SUCCESS_MSG_DURATION];
                        }
                        else if (breakReason == -1){
                            //fb id does not exists
                            [self updateUserFBId];
                        }
                    }
                }
                else {
                    [self updateUserFBId];
                }
            }
            else if (response==nil){
                [self updateUserFBId];
            }
        }
    }
    
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
@end
