//
//  ContactList.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/7/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ContactList : NSObject


@property (nonatomic, retain) NSString *strFirstName;
@property (nonatomic, retain) NSString *strLastName;
@property (nonatomic, retain) NSString *strContactNo;
@end
