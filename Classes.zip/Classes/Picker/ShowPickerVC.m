//
//  ShowPickerVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 02/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "ShowPickerVC.h"

@interface ShowPickerVC ()

@end

@implementation ShowPickerVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)setPickerView:(int)type{
    self.selectedPickerType = type;
    self.lblTitle.numberOfLines = 0;
    
    if (self.selectedPickerType == 0 || self.selectedPickerType == 3) {
        //pickerView   0 = gender , 3 = profile
        UIPickerView *pkr = [[UIPickerView alloc] initWithFrame:CGRectMake(0, DEVICE_HEIGHT-217, 320, 217)];
        pkr.backgroundColor = [UIColor whiteColor];
        pkr.delegate = self;
        pkr.dataSource = self;
        self.pkr = pkr;
        self.lblTitle.frame = CGRectMake(60, 119, 200, 96);
        if (self.selectedPickerType==0) {
            self.lblTitle.text = @"Select Gender";
        }
        else if (self.selectedPickerType==3) {
            self.lblTitle.text = @"Select\nProfile Status";
        }
        
    }
    else {
        //dtp
        UIDatePicker *dtp = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, DEVICE_HEIGHT-217, 320, 217)];
        [dtp setDatePickerMode:UIDatePickerModeDate];
         dtp.backgroundColor = [UIColor whiteColor];
        
        NSDate *today = [[NSDate alloc] init];
        NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
        
        if (self.selectedPickerType == 1){
            //dob
            
            self.lblTitle.frame = CGRectMake(10, self.lblTitle.frame.origin.y, 300, self.lblTitle.frame.size.height);
            self.lblTitle.text = @"Please Adjust Birth Year prior\nto setting Month and Date\n\n Min Age: 13";
            
            [offsetComponents setYear:-13]; // note that I'm setting it to -8
            
            NSDate *minimumDate = [gregorian dateByAddingComponents:offsetComponents toDate:today options:0];
            
            [offsetComponents setYear:-100]; // note that I'm setting it to -100
            NSDate *maximumDate = [gregorian dateByAddingComponents:offsetComponents toDate:today options:0];

            dtp.minimumDate = maximumDate;
            dtp.maximumDate = minimumDate;
            dtp.date = minimumDate;
        }
        else{
            //anniversary
            self.lblTitle.frame = CGRectMake(60, 119, 200, 96);
            self.lblTitle.text = @"Select\nDate of Anniversary";
            
            [offsetComponents setDay:-1]; // note that I'm setting it to -1
            
            NSDate *minimumDate = [gregorian dateByAddingComponents:offsetComponents toDate:today options:0];
            
            [offsetComponents setYear:-100]; // note that I'm setting it to -100
            NSDate *maximumDate = [gregorian dateByAddingComponents:offsetComponents toDate:today options:0];
            
            dtp.minimumDate = maximumDate;
            dtp.maximumDate = minimumDate;
            dtp.date = minimumDate;
        }
        
        self.pkr = dtp;
    }
    [self.view addSubview:self.pkr];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)btnDoneClicked:(id)sender{
    if (self.selectedPickerType == 0) {
        //gender
        [self.delegate doneButton:[NSNumber numberWithInt:self.selectedPickerType]];
    }
    else if (self.selectedPickerType >= 1 && self.selectedPickerType<3){
        [self.delegate doneDTPButton];
    }
    else if (self.selectedPickerType == 3){
        //profile
        [self.delegate doneButton:[NSNumber numberWithInt:self.selectedPickerType]];
    }
}

-(IBAction)btnCancelClicked:(id)sender{
    [self.delegate CancelButton];
}

#pragma mark UIPickerView Delegate and DataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if (self.arrData == nil) {
        return 0;
    }
    return self.arrData.count;
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return [self.arrData objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{

}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
