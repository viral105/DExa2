//
//  ShowPickerVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 02/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ShowPickerVCDelegate;

@protocol ShowPickerVCDelegate <NSObject>
- (void)doneButton:(id)callerId;
- (void)doneDTPButton;
- (void)CancelButton;

@end


@interface ShowPickerVC : UIViewController <UIPickerViewDataSource,UIPickerViewDelegate>


@property (nonatomic, readwrite) int                    selectedGender;
@property (nonatomic, retain) IBOutlet  UIImageView     *imgBg;
@property (nonatomic ,assign) id <ShowPickerVCDelegate>       delegate;
@property (nonatomic, strong) id                        pkr;
@property (nonatomic, strong) NSArray                   *arrData;
@property (nonatomic, readwrite) int                    selectedPickerType;
@property (nonatomic, retain) IBOutlet UILabel          *lblTitle;

-(void)setPickerView:(int)type;
@end
