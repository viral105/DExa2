//
//  BlockUnBlockVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 9/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "BlockUnBlockVC.h"
#import "MBProgressHUD.h"
@interface BlockUnBlockVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}


@end

@implementation BlockUnBlockVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	[self loadUserListingVC];
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    appDelegate.currentVc = self;
    [Validation removeAdviewFromSuperView];
	[self.view addSubview:[Validation sharedBannerView]];
	[Validation ResizeViewForAds];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark	custom methods

-(void)loadUserListingVC{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
	
	[self setBtnImg];
	[self showAllUserListForIndexList:2];
}

-(IBAction)btnBackClicked:(id)sender{
	[self dismissViewControllerAnimated:YES completion:nil];
}

-(void)showAllUserListForIndexList:(int)listForIndex{
	if (self.objUserListVC == nil) {
	//	UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
		self.objUserListVC = [MainStoryboard instantiateViewControllerWithIdentifier:USER_LIST_VC];
		self.objUserListVC.delegate = self;
		self.objUserListVC.selectedParentView_Index = listForIndex;
		self.objUserListVC.view.frame = CGRectMake(0, 68+self.btnAll.frame.size.height+20, 320, DEVICE_HEIGHT-(68+self.btnAll.frame.size.height+30));
		[self.view addSubview:self.objUserListVC.view];
		[self.objUserListVC didMoveToParentViewController:self];
		[self addChildViewController:self.objUserListVC];
        [self performSelector:@selector(loadDataInChildView:) withObject:[NSNumber numberWithInt:listForIndex] afterDelay:0.1];
	}
	else{
        [self loadDataInChildView:[NSNumber numberWithInt:listForIndex]];
	}
}

-(void)loadDataInChildView:(NSNumber *)listForIndex{
    
    self.objUserListVC.selectedParentView_Index = [listForIndex intValue];
    [self.objUserListVC loadUserListingView];

}

-(void)setBtnImg{
	
	[self.btnAll setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[self.btnBlocked setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
	
	[self.btnAll.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:17]];
	[self.btnBlocked.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:17]];
	
	
	[self.btnAll setBackgroundImage:[UIImage imageNamed:btn_Blue_Selected] forState:UIControlStateNormal];
	[self.btnBlocked setBackgroundImage:[UIImage imageNamed:btn_White_DeSelected] forState:UIControlStateNormal];
}

-(IBAction)btnAllClicked:(id)sender{
	
	[self.btnAll setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[self.btnAll setBackgroundImage:[UIImage imageNamed:btn_Blue_Selected] forState:UIControlStateNormal];
	
	[self.btnBlocked setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
	[self.btnBlocked setBackgroundImage:[UIImage imageNamed:btn_White_DeSelected] forState:UIControlStateNormal];
	
	[self showAllUserListForIndexList:2];
}

-(IBAction)btnBlockedClicked:(id)sender{
//	[self.objUserListVC.view removeFromSuperview];
//	[self.objUserListVC removeFromParentViewController];
//	self.objUserListVC.delegate = nil;
//	self.objUserListVC = nil;
	
	[self.btnBlocked setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[self.btnBlocked setBackgroundImage:[UIImage imageNamed:btn_Blue_Selected] forState:UIControlStateNormal];
	
	[self.btnAll setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
	[self.btnAll setBackgroundImage:[UIImage imageNamed:btn_White_DeSelected] forState:UIControlStateNormal];
	
	[self showAllUserListForIndexList:3];
}

- (void)showButton{
	self.btnAll.enabled = YES;
	self.btnBlocked.enabled = YES;
}

- (void)hideButton{
	self.btnAll.enabled = NO;
	self.btnBlocked.enabled = NO;
}

/*
-(void)getBlockedFriendList{
	
	if (self.request !=nil) {
		self.request = nil;
	}
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"100"],KeyValue,@"PageSize",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_BLOCKED_USER_LIST withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
	self.request.delegate = self;
	self.request.tag = 1;
	strUrl = nil;
}
*/
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
