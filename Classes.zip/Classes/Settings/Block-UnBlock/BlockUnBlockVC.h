//
//  BlockUnBlockVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 9/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserListVC.h"


@interface BlockUnBlockVC : UIViewController <UserListVCDelegate>

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;
@property (nonatomic, strong) UserListVC					*objUserListVC;
@property (nonatomic, strong) UserListVC					*objUserListVCForBlockedList;

@property (nonatomic, retain) IBOutlet UIButton				*btnAll;
@property (nonatomic, retain) IBOutlet UIButton				*btnBlocked;

@property (nonatomic, strong) ASIFormDataRequest			*request;

@end
