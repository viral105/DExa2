//
//  AboutVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 9/15/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "AboutVC.h"

@interface AboutVC ()

@end

@implementation AboutVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	[self LoadViewSettings];
/*    NSString *htmlFile = [[NSBundle mainBundle] pathForResource:@"about_blabeey" ofType:@"html"];
    
    NSString* htmlString = [NSString stringWithContentsOfFile:htmlFile encoding:NSUTF8StringEncoding error:nil];
    [self.webView loadHTMLString:htmlString baseURL:nil];
*/
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"about_blabeey" withExtension:@"html"];
    [self.webView loadRequest:[NSURLRequest requestWithURL:url]];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    appDelegate.currentVc = self;
    
    self.webView.scrollView.showsHorizontalScrollIndicator = FALSE;
    self.webView.scrollView.showsVerticalScrollIndicator = FALSE;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark	Methods

-(void)LoadViewSettings{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
//	self.scrollContainer.backgroundColor = UIColorFromRGB(0Xefefef);

	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:27];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
/*
	self.lblDescription.text = @"Blabeey is a zero character communication tool that allows users to send brief, randomized, pre-recorded and custom-recorded audible phrases selected by category/theme to other users. Blabeey puts popular words and phrases at your fingertips and gives users an entertaining and simple way to communicate. Blabs range from silly and fun to sincere and thoughtful. The user is engaged in a personalized mobile messaging experience that is simple, non-intrusive, and exciting. Users select a recipient from the in-app contact list and customize the message by selecting from a range of categories. After the category is selected the Blab’s content is pulled at random from the application’s database of thousands of pre-recorded audio files. This makes the message unique and engaging for the user by adding the element of surprise.";
	
	self.lblDescription.font = [UIFont fontWithName:Font_Montserrat_Bold size:18];
	self.lblDescription.numberOfLines = 0;
	CGSize size = CGSizeMake(self.scrollContainer.frame.size.width, 2000);
	
	CGRect textRectDate = [self.lblDescription.text boundingRectWithSize:size
											options:NSStringDrawingUsesLineFragmentOrigin
										 attributes:@{NSFontAttributeName:self.lblDescription.font}
											context:nil];
	
	size = textRectDate.size;
	self.scrollContainer.contentSize = CGSizeMake(self.scrollContainer.contentSize.width, textRectDate.size.height+20);
	self.lblDescription.frame = CGRectMake(0, 0, self.lblDescription.frame.size.width, size.height);
	self.lblDescription.textAlignment = NSTextAlignmentJustified;
*/
}

-(IBAction)btnBackClicked:(id)sender{
	[self dismissViewControllerAnimated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
