//
//  SettingsCell.h
//  WWHHAAZZAAPP
//
//  Created by s on 9/11/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsCell : UITableViewCell

@property (nonatomic, retain) IBOutlet	UILabel	*lblCellTitle;
@property (nonatomic,retain)  IBOutlet  UIImageView *imgArrowIndicator;
@property (nonatomic,retain)  IBOutlet  UISwitch *notiSwitch;

@end
