//
//  SettingsVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/8/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>

@interface SettingsVC : UIViewController <UIAlertViewDelegate,UINavigationControllerDelegate, UIActionSheetDelegate, UITableViewDataSource, UITableViewDelegate,UIDocumentInteractionControllerDelegate,MFMessageComposeViewControllerDelegate>

@property (nonatomic, strong) IBOutlet UIButton			*btnBack;
@property (nonatomic, strong) IBOutlet UITableView		*tblData;
@property (nonatomic, strong) IBOutlet UIButton			*btnEditProfile;
@property (nonatomic, strong) IBOutlet UIButton			*btnInviteFB_Friends;
@property (nonatomic, strong) IBOutlet UIButton			*btnLogout;
@property (nonatomic, strong) IBOutlet UIButton			*btnDeActivate;
@property (nonatomic, strong) IBOutlet UIButton			*btnAddFbContactFriends;
@property (nonatomic, strong) IBOutlet UILabel			*lblTitle;
@property (nonatomic, strong) IBOutlet UITextField      *tfPhoneNumber;
@property (nonatomic, strong) IBOutlet UILabel			*lblTitleContactNumber;
@property (nonatomic, strong) IBOutlet UIView           *viewContactNumber;

@property (nonatomic, readwrite) BOOL					isNotifOff;

@property (nonatomic, strong) ASIHTTPRequest			*request;
@property (nonatomic, strong) NSString					*strFBID;
@property (retain, nonatomic) UIDocumentInteractionController *dic;

@end
