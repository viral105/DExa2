//
//  AboutVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 9/15/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutVC : UIViewController

@property (nonatomic, strong) IBOutlet UIWebView        *webView;
@property (nonatomic, strong) IBOutlet UIScrollView		*scrollContainer;
@property (nonatomic, retain) IBOutlet UILabel			*lblDescription;
@property (nonatomic, strong) IBOutlet UILabel			*lblTitle;
@end
