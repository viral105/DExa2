//
//  SettingsVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 8/8/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "SettingsVC.h"
#import "SettingsCell.h"
#import "BlockUnBlockVC.h"
#import "AboutVC.h"
#import "ActivityViewCustomActivity.h"
#import "UserInterestList.h"
#import "ViewController.h"
#import "MBProgressHUD.h"
#import "ProfileDescriptionVC.h"
#import "HelpVideoListVC.h"

#define NumberOfSections		13
#define InviteActionSheetTag    145897


@interface SettingsVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
    NSArray *arrSettingText;
}

@end

@implementation SettingsVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	//self.canDisplayBannerAds = YES;
    
//   Bhavik 11-Mar-2015 /*
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(AppForeGround:) name:UIApplicationWillEnterForegroundNotification object:nil];
//   */
    [self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    
    arrSettingText = [NSLocalizedString(@"strSettingText", nil) componentsSeparatedByString:@","];
	
    self.viewContactNumber.hidden = YES;
    
	[self LoadViewSettings];
    
    if ([Validation setOverlayFlags:4]) {
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
        [imgView setImage:[UIImage imageNamed:@"settings@2x.png"]];
        [imgView setUserInteractionEnabled:YES];
        
        UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(overlayImageTaped:)];
        [tapGes setNumberOfTapsRequired:1];
        [imgView addGestureRecognizer:tapGes];
        tapGes = nil;
        
        [[[UIApplication sharedApplication] keyWindow] addSubview:imgView];
    }
}

-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	
	appDelegate.currentVc = self;
    
    //set menu image
    [self.btnBack removeTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
	[self.btnBack addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];

    
	self.isNotifOff = [[NSUserDefaults standardUserDefaults] boolForKey:IS_APNS_OFF];
	[Validation removeAdviewFromSuperView];
	[self.view addSubview:[Validation sharedBannerView]];
	[Validation ResizeViewForAds];
}
//  Bhavik 11-Mar-2015 /*
- (void)AppForeGround:(NSNotification *)notification {
    NSLog(@"did become active notification");
    self.view.userInteractionEnabled = YES;
}
//  */
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma  mark	UITableView delegate & dataSource

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	return NumberOfSections;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	static NSString *cellIdentifier = @"CellIdentifier";
//    
//    UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
//    
//    UIImageView *accessoryView;
//
//    if(cell == nil)
//    {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
//
//        accessoryView = [[UIImageView alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-20, 19, 8, 12)];
//        [accessoryView setImage:[UIImage imageNamed:@"icon_settings_right_arrow.png"]];
//        [cell.contentView addSubview:accessoryView];
//        
//        cell.textLabel.backgroundColor = [UIColor clearColor];
//        cell.textLabel.font = [UIFont fontWithName:@"Montserrat-Regular" size:15.0];
//        
//        cell.selectionStyle = UITableViewCellSelectionStyleNone;
//    }
    
   // cell.textLabel.text = [arrSettingText objectAtIndex:indexPath.row];
    
  
	SettingsCell *cell = (SettingsCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    cell.backgroundColor = [UIColor whiteColor];
	//[cell.lblCellTitle setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:btn_With_WhiteBg]]];
	
    cell.lblCellTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:15.0];
    cell.lblCellTitle.backgroundColor = [UIColor clearColor];
    cell.lblCellTitle.text = [arrSettingText objectAtIndex:indexPath.row];
    
   // NSLog(@"%@",NSStringFromCGRect(cell.imgArrowIndicator.frame));


	switch (indexPath.row) {
		case 0:{ //blabby
			cell.lblCellTitle.textColor = UIColorFromRGB(0X00c2d9);
            cell.notiSwitch.hidden = YES;
		}
			break;
        case 1:{ //Help
            cell.lblCellTitle.textColor = UIColorFromRGB(0X689f38);
            cell.imgArrowIndicator.hidden = YES;
            cell.notiSwitch.hidden = YES;
        }
            break;
		case 2:{ //Edit Profile
			cell.lblCellTitle.textColor = UIColorFromRGB(0Xff5252);
            cell.notiSwitch.hidden = YES;
        }
			break;
        case 3:{ //Edit Interest
			cell.lblCellTitle.textColor = UIColorFromRGB(0X43a047);
            cell.notiSwitch.hidden = YES;
		}
			break;
        case 4:{ //Profile Desc
			cell.lblCellTitle.textColor = UIColorFromRGB(0Xfcb732);
            cell.notiSwitch.hidden = YES;
		}
			break;
		case 5:{ //Block
            cell.lblCellTitle.textColor = UIColorFromRGB(0Xfd6631);
            cell.notiSwitch.hidden = YES;
		}
			break;
		case 6:{ //Notification
			cell.lblCellTitle.textColor = UIColorFromRGB(0X008984);
            cell.notiSwitch.hidden = NO;
            cell.imgArrowIndicator.hidden = YES;

            [cell.notiSwitch addTarget:self action:@selector(SetUserGlobalSettings) forControlEvents:UIControlEventValueChanged];
            if(self.isNotifOff)
            {
                [cell.notiSwitch  setOn:NO animated:NO];
            }
            else
            {
                [cell.notiSwitch  setOn:YES animated:NO];
            }
            if([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON]){
                cell.notiSwitch.enabled = NO;
            }
            else{
                cell.notiSwitch.enabled = YES;
            }
		}
			break;
        case 7:{ //Quiet Mode
            cell.lblCellTitle.textColor = UIColorFromRGB(0Xff5722);
            cell.notiSwitch.hidden = NO;
            cell.imgArrowIndicator.hidden = YES;
            
            [cell.notiSwitch addTarget:self action:@selector(SetUserQuietModeSettings) forControlEvents:UIControlEventValueChanged];
            if([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON])
            {
                [cell.notiSwitch  setOn:YES animated:NO];
            }
            else
            {
                [cell.notiSwitch  setOn:NO animated:NO];
            }
        }
            break;
        case 8:{ //Is SAVE TO GALLARY
            cell.lblCellTitle.textColor = UIColorFromRGB(0Xfbc02d);
            cell.notiSwitch.hidden = NO;
            cell.imgArrowIndicator.hidden = YES;
            
            [cell.notiSwitch addTarget:self action:@selector(SetSwitchSaveToGallary) forControlEvents:UIControlEventValueChanged];
            if([[NSUserDefaults standardUserDefaults] boolForKey:IS_SAVE_TO_GALLERY])
            {
                [cell.notiSwitch  setOn:YES animated:NO];
            }
            else
            {
                [cell.notiSwitch  setOn:NO animated:NO];
            }
        }
            break;
		case 9:{ //Invite
			cell.lblCellTitle.textColor = UIColorFromRGB(0X5064aa);
            cell.imgArrowIndicator.hidden = YES;
            cell.notiSwitch.hidden = YES;
		}
			break;
		case 10:{ //Add Friends
			cell.lblCellTitle.textColor = UIColorFromRGB(0Xad4ee3);
            cell.imgArrowIndicator.hidden = YES;
            cell.notiSwitch.hidden = YES;
		}
			break;
        
		case 11:{ //Logout
			cell.lblCellTitle.textColor = UIColorFromRGB(0Xe53935);
            cell.imgArrowIndicator.hidden = YES;
            cell.notiSwitch.hidden = YES;
		}
			break;
		case 12:{ //Deactive
			cell.lblCellTitle.textColor = UIColorFromRGB(0X2e2e2f);
            cell.imgArrowIndicator.hidden = YES;
            cell.notiSwitch.hidden = YES;
		}
			break;
		default:
			break;
	}
	
	return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
	
	switch (indexPath.row) {
		case 0:{ //What is Blabby?
			AboutVC *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:ABOUT_APP_VC];
			[self presentViewController:ivc animated:YES completion:nil];
		}
			break;
        case 1://Help
            [self performSegueWithIdentifier:@"HelpVideoListVC" sender:self];
            //            [self btnLogOutClicked:nil];
            break;
		case 2:{ //Edit Profile
			[self btnEditProfileClicked:nil];
		}
			break;
        case 3: //Edit Interest
			[self btnInterestClicked:nil];
			break;
        case 4: //ProfileDesc
			[self btnProfileDescClicked:nil];
			break;
		case 5: //BlockUnBlock
        {
            BlockUnBlockVC *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:BLOCK_UNBLOCK_VC];
            [self presentViewController:ivc animated:YES completion:nil];
        }
            break;
		case 9://Invite
//  Bhavik 11-Mar-2015  /*
        {
            NSLog(@"Called Once");
            self.view.userInteractionEnabled = NO;
            [self btnInviteFBFriendsClicked:nil];
        }
//  */
			break;
		case 10://Add Friend
			[self btnAddFriendClicked:nil];
			break;
        
		case 11://LogOut
             [self btnLogOutClicked:nil];
			break;
		case 12: //DeActivate
			[self btnDeActivateClicked:nil];
			break;
        default:
			break;
	}
}

#pragma mark  send invite to social media apps

-(UIDocumentInteractionController *)setUpControllerWithURL :(NSURL *)filuURL usingDelegate:(id <UIDocumentInteractionControllerDelegate>)interactionDelegate{
    UIDocumentInteractionController *interactionController = [UIDocumentInteractionController interactionControllerWithURL:filuURL];
    interactionController.delegate = interactionDelegate;
    return interactionController;
}

-(void)OpenSocialOptions{
    NSString *savePath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/InviteForApp.png"];  //.ig for instagram
    UIImage *imgInvite = [UIImage imageNamed:@"Icon144x144.png"];
    NSData *data = UIImagePNGRepresentation(imgInvite);
    [data writeToFile:savePath atomically:YES];
    CGRect rect = CGRectMake(0, 0, 0, 0);
    
    NSString *jpgPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/InviteForApp.png"];   //.ig for instagram
    NSURL *igImageHookFile = [NSURL URLWithString:[NSString stringWithFormat:@"file://%@",jpgPath]];
   
    self.dic = [self setUpControllerWithURL:igImageHookFile usingDelegate:self];
    self.dic = [UIDocumentInteractionController interactionControllerWithURL:igImageHookFile];
    [self.dic presentOptionsMenuFromRect:rect inView:self.view animated:YES];

    /*
    NSString *string = @"Come and join Yapeey! with me";
    NSURL *URL = [NSURL URLWithString:@"http://wwhhaazzuupp.com/"];
    
    ActivityViewCustomActivity *insta = [[ActivityViewCustomActivity alloc]initWithActivityWithId:0];
    ActivityViewCustomActivity *flickr = [[ActivityViewCustomActivity alloc]initWithActivityWithId:1];
    
    
    
    UIActivityViewController *activityViewController =
    [[UIActivityViewController alloc] initWithActivityItems:@[string, URL]
                                      applicationActivities:[NSArray arrayWithObjects:insta,flickr,nil]];
    [self.navigationController presentViewController:activityViewController
                                       animated:YES
                                     completion:^{
                                         // ...
                                     }];
     */
}

/*
- (id)activityViewController:(UIActivityViewController *)activityViewController
         itemForActivityType:(NSString *)activityType
{
    if ([activityType isEqualToString:UIActivityTypePostToFacebook]) {
        return NSLocalizedString(@"Like this!");
    } else if ([activityType isEqualToString:UIActivityTypePostToTwitter]) {
        return NSLocalizedString(@"Retweet this!");
    } else {
        return nil;
    }
}
*/

#pragma mark	Methods

-(void)LoadViewSettings{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
//	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:30];
//	[self.lblTitle setTextColor:UIColorFromRGB(0Xccf5ff)];
	
    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
    [self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
	[self.btnDeActivate.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnEditProfile.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnInviteFB_Friends.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnLogout.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnAddFbContactFriends.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	
	[self.btnLogout setTitleColor:UIColorFromRGB(0Xfb8c00) forState:UIControlStateNormal];
	[self.btnDeActivate setTitleColor:UIColorFromRGB(0Xff5252) forState:UIControlStateNormal];
	[self.btnEditProfile setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
	[self.btnAddFbContactFriends setTitleColor:UIColorFromRGB(0Xa5de37) forState:UIControlStateNormal];
    
    
    self.lblTitleContactNumber.font = [UIFont fontWithName:Font_Montserrat_Regular size:30];
    [self.lblTitleContactNumber setTextColor:UIColorFromRGB(0Xffffff)];
    
    [self.tfPhoneNumber setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [self.tfPhoneNumber setTextColor:UIColorFromRGB(0X585f66)];
    [self.tfPhoneNumber setValue:UIColorFromRGB(0X585f66)	forKeyPath:@"_placeholderLabel.textColor"];
    
    UIButton *btnNext = (UIButton *)[self.view viewWithTag:110];
    [btnNext.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [btnNext setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
    
    UIButton *btnSkip = (UIButton *)[self.view viewWithTag:111];
    [btnSkip.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [btnSkip setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
}

-(void)overlayImageTaped:(UIGestureRecognizer *)gesRecognizer{
    [gesRecognizer.view removeFromSuperview];
}

-(IBAction)btnBackClicked:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnLogOutClicked:(id)sender{
//    [AlertHandler alertTitle:CONFIRM message:@"Your scheduled reminder will be deleted.\nAre you sure to logout ?" delegate:self tag:1 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
	[self callLogOutService];
}

-(IBAction)btnDeActivateClicked:(id)sender{
	[self callDeactivateService];
}

-(IBAction)btnInviteClicked:(id)sender{
    
}
-(IBAction)btnInviteFBFriendsClicked:(id)sender{
    UIActionSheet *actionSheetInviteFB = [[UIActionSheet alloc] initWithTitle:@"Select" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:@"Facebook",@"Messages", nil];
    actionSheetInviteFB.tag = InviteActionSheetTag;
    [actionSheetInviteFB showInView:self.view];
//    actionSheetInviteFB = nil;
    
//    UIActionSheet *actionCameraOption = [[UIActionSheet alloc] initWithTitle:@"Add Friends" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:@"From Facebook",@"From Contacts", nil];
//    
//    [actionCameraOption showInView:self.view];
//    actionCameraOption = nil;
}

-(IBAction)btnEditProfileClicked:(id)sender{
	[Validation CancelOnGoingRequests:self.request];
	[self performSegueWithIdentifier:EDIT_PROFILE_VC sender:nil];
}

-(IBAction)btnInterestClicked:(id)sender{
 //   UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UserInterestList *obj = [MainStoryboard instantiateViewControllerWithIdentifier:USER_INTEREST_VC];
    obj.isFromRegister = NO;
    obj.strShowSkip = @"0";
    [self.navigationController pushViewController:obj animated:NO];
}
-(IBAction)btnProfileDescClicked:(id)sender{
    //   UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ProfileDescriptionVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:PROFILE_DESCRIPTION_VC];
    [self.navigationController pushViewController:obj animated:NO];
}
-(IBAction)btnDoneContactNumber:(id)sender{
    NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"1234567890"];
    s = [s invertedSet];
    NSRange r = [self.tfPhoneNumber.text rangeOfCharacterFromSet:s];
    if ([DataValidation checkNullString:self.tfPhoneNumber.text].length==0) {
        [Validation showToastMessage:@"Please enter valid\ncontact number." displayDuration:ERROR_MSG_DURATION];
        return;
    }
    else if ([DataValidation checkNullString:self.tfPhoneNumber.text].length > 0 && !([self.tfPhoneNumber.text length] >= 10 && self.tfPhoneNumber.text.length <= 15)){
        [Validation showToastMessage:@"Contact number must be of 10-15 digit." displayDuration:ERROR_MSG_DURATION];
        return;
    }
    else if (r.location != NSNotFound) {
        //  HAVE TO CHECK FOR NUMBERS ONLY HERE ALSO. BECAUSE IT IS POSSIBLE USER CAN COPY PASTE TEXT IN TEXT FIELD.
        [Validation showToastMessage:@"Please enter only numbers." displayDuration:ERROR_MSG_DURATION];
        return;
    }
    else{
        [self performSelector:@selector(SendUserContactListToServer) withObject:nil];
    }
}
-(IBAction)btnCancelContactNumber:(id)sender{
    self.tfPhoneNumber.text = @"";
    self.viewContactNumber.hidden = YES;
    [self.tfPhoneNumber resignFirstResponder];
}
-(void)callLogOutService{
    
    
    //[self.navigationController popToRootViewControllerAnimated:YES];
    
	if (self.request !=nil) {
		self.request = nil;
	}
	//[Validation showLoadingIndicator];
    
    [HUD show:YES];
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]],KeyValue,@"RegID",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:LOG_OUT withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//	self.request.delegate = self;
//	self.request.tag = 1;
	strUrl = nil;

}

-(void)callDeactivateService{
	[AlertHandler alertTitle:CONFIRM message:DEACTIVATE_CONFIRM_MSG delegate:self tag:0 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
}

-(IBAction)btnAddFriendClicked:(id)sender{
	UIActionSheet *actionCameraOption = [[UIActionSheet alloc] initWithTitle:@"Add Friends" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:@"From Facebook",@"From Contacts", nil];
	
	[actionCameraOption showInView:self.view];
	actionCameraOption = nil;
}

-(void)SendUserContactListToServer{
	
	__block NSArray *arr = nil;
	arr = [DataValidation getAllContacts];
	
	if (arr!=nil) {
		if (arr.count>0) {
			if (self.request !=nil) {
				self.request = nil;
			}
			
			[self performSelector:@selector(sendContactToServer:) withObject:arr];
		}
	}
}

-(void)sendContactToServer:(NSArray *)arr{
	//[Validation showLoadingIndicator];
    [HUD show:YES];
    NSString *strContactNum;
    if ([DataValidation checkNullString:self.tfPhoneNumber.text].length==0) {
        strContactNum = @"";
    }
    else{
        strContactNum = self.tfPhoneNumber.text;
    }
	NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
						  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						  [NSDictionary dictionaryWithObjectsAndKeys:strContactNum,KeyValue,@"PhoneNo",KeyName, nil],@"2",
						  [NSDictionary dictionaryWithObjectsAndKeys:[arr componentsJoinedByString:@"|"],KeyValue,@"ContactList",KeyName, nil],@"3",
						  nil];
	NSString *strUrl = [WebServiceContainer getServiceURL:SEND_USER_CONTACT_LIST withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:3];
    }
//	request.delegate = self;
//	request.tag = 3;
	strUrl = nil;
}

-(void)SetUserGlobalSettings{
	/*
	 OffNotification = true , if user wants to off the notif
	 OffNotification = false, if user wants to turn on the notif
	 */
	
	//[Validation showLoadingIndicator];
    [HUD show:YES];
    
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:(self.isNotifOff)?@"false":@"true",KeyValue,@"OffNotification",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:UPDATE_USER_SETTING withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:7];
    }
//	request.delegate = self;
//	request.tag = 7;
	strUrl = nil;

	if (self.isNotifOff) {
		self.isNotifOff = FALSE;
	}
	else{
		self.isNotifOff = TRUE;
	}
	[self.tblData reloadData];
}
-(void)SetUserQuietModeSettings{
    /*
     OffNotification = true , if user wants to off the notif
     OffNotification = false, if user wants to turn on the notif
     */
    
    //[Validation showLoadingIndicator];
    [HUD show:YES];
    
/*
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON])?@"false":@"true",KeyValue,@"QuietMode",KeyName, nil],@"2",
                         nil];
 */
    NSDictionary *dic;
    if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON]) {
        
        dic = [NSDictionary dictionaryWithObjectsAndKeys:
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
               [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"QuietMode",KeyName, nil],@"2",
               [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"OffNotification",KeyName, nil],@"3",
               nil];
        
    }
    else{
        
        dic = [NSDictionary dictionaryWithObjectsAndKeys:
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
               [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"QuietMode",KeyName, nil],@"2",
               [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"OffNotification",KeyName, nil],@"3",
               nil];
    }
    
    NSString *strUrl = [WebServiceContainer getServiceURL:UPDATE_USER_SETTING withParameters:nil];
    ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:8];
    }
    strUrl = nil;
    
/*  This setting is done in web service response so don't it here
 
    if (self.isNotifOff) {
        self.isNotifOff = FALSE;
    }
    else{
        self.isNotifOff = TRUE;
    }

    [self.tblData reloadData];
*/
}
-(void)SetSwitchSaveToGallary{
    /*
     OffNotification = true , if user wants to off the notif
     OffNotification = false, if user wants to turn on the notif
     */
    
    //[Validation showLoadingIndicator];
    
    if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_SAVE_TO_GALLERY]) {
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:IS_SAVE_TO_GALLERY];
    }
    else{
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:IS_SAVE_TO_GALLERY];
    }
    [self.tblData beginUpdates];
    [self.tblData reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:7 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
    [self.tblData endUpdates];
/*
    NSDictionary *dic;
    if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_QUIETMODE_ON]) {
        
        dic = [NSDictionary dictionaryWithObjectsAndKeys:
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
               [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"QuietMode",KeyName, nil],@"2",
               [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"OffNotification",KeyName, nil],@"3",
               nil];
        
    }
    else{
        
        dic = [NSDictionary dictionaryWithObjectsAndKeys:
               [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
               [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"QuietMode",KeyName, nil],@"2",
               [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"OffNotification",KeyName, nil],@"3",
               nil];
    }
    
    NSString *strUrl = [WebServiceContainer getServiceURL:UPDATE_USER_SETTING withParameters:nil];
    ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:8];
    }
    strUrl = nil;
*/
    
    
    /*    if (self.isNotifOff) {
     self.isNotifOff = FALSE;
     }
     else{
     self.isNotifOff = TRUE;
     }
     
     [self.tblData reloadData];
     */
}
#pragma mark UITextfieldDelegate

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (range.location==1 && ![string isEqualToString:@""]) {
        NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"1234567890"];
        s = [s invertedSet];
        NSRange r = [string rangeOfCharacterFromSet:s];
        if (r.location != NSNotFound) {
            return FALSE;
        }
    }
    return TRUE;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return TRUE;
}

#pragma mark	UIAlertView Delegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag==0) {
        if (buttonIndex == alertView.cancelButtonIndex) {
            
        }
        else{
            if (self.request !=nil) {
                self.request = nil;
            }
            //[Validation showLoadingIndicator];
            
            [HUD show:YES];
            
            NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                                 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                                 nil];
            
            NSString *strUrl = [WebServiceContainer getServiceURL:DEACTIVATE_USER withParameters:nil];
            self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
            if (self.request == nil) {
                [HUD hide:YES];
            }
            else{
                [self.request setDelegate:self];
                [self.request setTag:2];
            }
//            self.request.delegate = self;
//            self.request.tag = 2;
            strUrl = nil;
        }
    }
    else if (alertView.tag == 1){
        if (buttonIndex == alertView.cancelButtonIndex) {
            
        }
        else{
            [self callLogOutService];
        }
    }
    else if (alertView.tag == 2){
        if (buttonIndex == alertView.cancelButtonIndex) {
            [self.view bringSubviewToFront:self.viewContactNumber];
            self.viewContactNumber.hidden = NO;
            
            [self.tfPhoneNumber becomeFirstResponder];
            
        }
        else{
            [self performSelector:@selector(SendUserContactListToServer) withObject:nil];
        }
    }
}

- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
	
	if(actionSheet.tag == InviteActionSheetTag)
    {
        if (buttonIndex == actionSheet.cancelButtonIndex) {
        }
        else{
            if (buttonIndex == 0) {
                //facebook
               // [self signUpSignInWithFB];
                [self performSelector:@selector(signUpSignInWithFB) withObject:nil];

            }
            else if (buttonIndex == 1){
                //Messages
               // [self openMessageView];
                [self performSelector:@selector(openMessageView) withObject:nil];
                self.view.userInteractionEnabled = YES;
            }
        }
        
    }
    else
    {
        if (buttonIndex == actionSheet.cancelButtonIndex) {
        }
        else{
            if (buttonIndex == 0) {
                //facebook
                [self performSelector:@selector(fetchFriendListFromFB) withObject:nil];
            }
            else if (buttonIndex == 1){
                //contact list
                NSLog(@"contact num from setting %@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHONE]);
                if ([DataValidation checkNullString:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_PHONE]].length==0) {
                    [AlertHandler alertTitle:ALERT message:@"You have not entered your contact number yet. Do you want to add it now?" delegate:self tag:2 cancelButtonTitle:@"Add Now" OKButtonTitle:@"Not Now" otherButtonTitle:nil];
                }
                else{
                    
                    [self performSelector:@selector(SendUserContactListToServer) withObject:nil];
                }
            }
        }
    }
//    [actionSheet dismissWithClickedButtonIndex:buttonIndex animated:YES];
}

#pragma mark - Open Message

-(void) openMessageView
{
    //set message text
    NSString * message = @"Come message me on Blabeey :\n\niPhone - https://itunes.apple.com/us/app/blabeey/id966451741?mt=8\n\nAndroid - https://play.google.com/store/apps/details?id=com.blab.blabeey";
    
    MFMessageComposeViewController *messageController = [[MFMessageComposeViewController alloc] init];
    messageController.messageComposeDelegate = self;
    [messageController setBody:message];

    [self presentViewController:messageController animated:YES completion:nil];
}

#pragma mark - MFMailComposeViewControllerDelegate methods

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult) result
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark		FACEBOOK INVITE

-(void)signUpSignInWithFB{
	if (!FBSession.activeSession.isOpen) {
        // if the session is closed, then we open it here, and establish a handler for state changes
        [FBSession openActiveSessionWithReadPermissions:@[@"public_profile", @"email", @"user_friends"]
                                           allowLoginUI:YES
                                      completionHandler:^(FBSession *session,
														  FBSessionState state,
														  NSError *error) {
										  if (error) {
//                                              Bhavik  11-Mar-2015     /*
                                              self.view.userInteractionEnabled = YES;
//                                              */
											  [HUD hide:YES];
											  UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
																								  message:@"Could not get your Facebook data.\nPlease check you internet connectivity or try later."
																								 delegate:nil
																						cancelButtonTitle:@"OK"
																						otherButtonTitles:nil];											  [alertView show];
										  } else if (session.isOpen) {
											  NSLog(@"facebook login");
											  [self GetUserData];
										  }
									  }];
        return;
    }
	else if (FBSession.activeSession.isOpen) {
		NSLog(@"facebook login");
		[self GetUserData];
	}
}

-(void)GetUserData{
	[[FBRequest requestForMe] startWithCompletionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
		//result contains a dictionary of your user, including Facebook ID.
//      Bhavik  11-Mar-2015     /*
        self.view.userInteractionEnabled = YES;
//      */
        
		NSLog(@"result=  %@",result);
		
		[self postOnFacebook];
	}];
}

-(void)postOnFacebook{
	
	NSString *strLINK = [NSString stringWithFormat:FACEBOOK_INVITE_URL];
	NSMutableDictionary *parmaDic = [NSMutableDictionary dictionaryWithCapacity:7];
//	[parmaDic setObject:INVITE_TEXT forKey:@"message"]; // if you want send message
	[parmaDic setObject:@"Blabeey" forKey:@"name"];         // if you want send name
	[parmaDic setObject:strLINK forKey:@"link"];
//	[parmaDic setObject:INVITE_TEXT forKey:@"description"];
	
	[FBWebDialogs presentDialogModallyWithSession:nil dialog:@"feed" parameters:parmaDic handler:^(FBWebDialogResult result, NSURL *resultURL, NSError *error){
		if (result == FBWebDialogResultDialogNotCompleted) {
			// User canceled.
			NSLog(@"User cancelled.");
			
		} else {
			// Handle the publish feed callback
			NSDictionary *urlParams = [Validation parseURLParams:[resultURL query]];
			
			if (![urlParams valueForKey:@"post_id"]) {
				// User canceled.
				HIDE_LOADER;
				NSLog(@"User cancelled.");
				
			} else {
				// User clicked the Share button
				NSString *result = [NSString stringWithFormat: @"Posted story, id: %@", [urlParams valueForKey:@"post_id"]];
				NSLog(@"result %@", result);
				HIDE_LOADER;
//				[CustomAlert HeaderTitle:SUCCESS message:@"Invitation sent successfully." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK otherButtonTitle:nil];
				[Validation showToastMessage:@"Invitation sent successfully." displayDuration:SUCCESS_MSG_DURATION];
			}
		}
	}];
}

-(void)fetchFriendListFromFB{
	//[self performSelector:@selector(addFaceBookFriends) withObject:nil];
	[self performSelector:@selector(addFaceBookFriends) withObject:nil afterDelay:0.5];
}
-(void)addFaceBookFriends{
	NSLog(@"fb btn pressed");
//	[Validation showLoadingIndicator];
    
	[HUD show:YES];
	
	if (!FBSession.activeSession.isOpen) {
        // if the session is closed, then we open it here, and establish a handler for state changes
        [FBSession openActiveSessionWithReadPermissions:@[@"public_profile", @"email", @"user_friends"]
                                           allowLoginUI:YES
                                      completionHandler:^(FBSession *session,
														  FBSessionState state,
														  NSError *error) {
										  if (error) {
											  [HUD hide:YES];
											  UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
																								  message:@"Could not get your Facebook data.\nPlease check you internet connectivity or try later."
																								 delegate:nil
																						cancelButtonTitle:@"OK"
																						otherButtonTitles:nil];											  [alertView show];
										  } else if (session.isOpen) {
											  NSLog(@"facebook login");
											  [self getUserInfo];
										  }
									  }];
        return;
    }
	else if (FBSession.activeSession.isOpen) {
		NSLog(@"facebook login");
		[self getUserInfo];
	}
}

- (void)GetUserFriendList {
	
	[FBRequestConnection startWithGraphPath:@"/me/friends"
								 parameters:nil
								 HTTPMethod:@"GET"
						  completionHandler:^(
											  FBRequestConnection *connection,
											  id result,
											  NSError *error
											  ) {
							  /* handle the result */
							  NSLog(@"%@",result);
							  NSArray *arr = [((NSArray *)[result valueForKey:@"data"]) valueForKey:@"id"];
							  [self addFacebookFreinds:arr];
						 }
	 ];
}

-(void)getUserInfo{
	//[Validation showLoadingIndicator];
    
    [HUD show:YES];
    
	[[FBRequest requestForMe] startWithCompletionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
		//result contains a dictionary of your user, including Facebook ID.
		NSLog(@"result=  %@",result);
		self.strFBID = [result valueForKey:@"id"];
		[self GetUserFriendList];
	}];
}

-(void)addFacebookFreinds:(NSArray *)arrFbId{
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[arrFbId componentsJoinedByString:@"|"]],KeyValue,@"FacebookIDs",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:ADD_FB_FRIENDS withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:4];
    }
//	request.delegate = self;
//	request.tag = 4;
	strUrl = nil;
}

-(void)checkFBID_Exist{
	NSLog(@"%@",[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]);
	if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]].length == 0) {
	//	[Validation showLoadingIndicator];
        
        [HUD show:YES];
        
		NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
							 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"emailID",KeyName, nil],@"1",
							 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"userName",KeyName, nil],@"2",
							 [NSDictionary dictionaryWithObjectsAndKeys:[Validation getEncryptedTextForString:self.strFBID isGeneral:YES],KeyValue,@"facebookID",KeyName, nil],@"3",
							 [NSDictionary dictionaryWithObjectsAndKeys:@"-1",KeyValue,@"IsActive",KeyName, nil],@"4",
							 nil];
		
		if (self.request != nil) {
			self.request = nil;
		}
		NSString *strUrl = [WebServiceContainer getServiceURL:CHECK_USER_EXIST withParameters:nil];
		self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
        if (self.request == nil) {
            [HUD hide:YES];
        }
        else{
            [self.request setDelegate:self];
            [self.request setTag:5];
        }
//		self.request.delegate = self;
//		self.request.tag = 5;
		strUrl = nil;
	}
	else{
		[HUD hide:YES];
		[Validation showToastMessage:@"Friends added successfully.\nPlease check your friend list." displayDuration:SUCCESS_MSG_DURATION];
	}
}
-(void)updateUserFBId{
	//[Validation showLoadingIndicator];
    
    [HUD show:YES];
    
	NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
						  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Name",KeyName, nil],@"1",
						  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Phone",KeyName, nil],@"2",
						  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Email",KeyName, nil],@"3",
						  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"UserName",KeyName, nil],@"4",
						  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Pwd",KeyName, nil],@"5",
						  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"DateOfBirth",KeyName, nil],@"6",
						  [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"Gender",KeyName, nil],@"7",
						  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"ID",KeyName, nil],@"8",
						  [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"ImgData",KeyName, nil],@"9",
						  [NSDictionary dictionaryWithObjectsAndKeys:self.strFBID,KeyValue,@"FacebookID",KeyName, nil],@"10",
						  nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:EDIT_USER_PROFILE withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:6];
    }
//	request.delegate = self;
//	request.tag = 6;
	strUrl = nil;

}

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	
	[HUD hide:YES];
    
    NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
                                                                 options:0
                                                                   error:&error];;
	NSLog(@"response =%@",dicResponse);
    
	if (request.tag<3) {
		if (request.tag == 1) {
			//logout
            NSLog(@"status-------> %d",[[NSString stringWithFormat:@"%@",[dicResponse valueForKey:STATUS]] intValue]);
//            if ([[NSString stringWithFormat:@"%@",[dicResponse valueForKey:STATUS]] intValue]!=0) {
                [Validation removeAllKeyValue];
                [appDelegate InfoDeleteAllAlarm];
                [[UIApplication sharedApplication] cancelAllLocalNotifications];
                appDelegate.is_Login = NO;
                //            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                ViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"ViewController"];
                
                NSMutableArray *arr = [[NSMutableArray alloc] init];
                [arr addObject:ivc];
                [arr addObject:[self.navigationController.viewControllers objectAtIndex:0]];
                
                [self.navigationController setViewControllers:arr];
                [self.navigationController popViewControllerAnimated:NO];
                self.request = nil;

/*           }
            else{
                [HUD hide:YES];
                [Validation showToastMessage:MESSAGE_SOMETHING_WRONG displayDuration:INFO_MSG_DURATION];
            }
*/
		}
		else if (request.tag == 2){
			//deactivate
			[Validation removeAllKeyValue];
//			appDelegate.is_Login = NO;
//			self.request = nil;
			[Validation showToastMessage:@"Account deactivated successfully." displayDuration:ERROR_MSG_DURATION];
//			[self.navigationController popToRootViewControllerAnimated:YES];

            [appDelegate InfoDeleteAllAlarm];
            [[UIApplication sharedApplication] cancelAllLocalNotifications];
            appDelegate.is_Login = NO;
            //            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            ViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"ViewController"];
            
            NSMutableArray *arr = [[NSMutableArray alloc] init];
            [arr addObject:ivc];
            [arr addObject:[self.navigationController.viewControllers objectAtIndex:0]];
            
            [self.navigationController setViewControllers:arr];
            [self.navigationController popViewControllerAnimated:NO];
            self.request = nil;

		}
	}
	else{
		NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData] options:0 error:&error];
        if (dicResponse != nil) {
            if (request.tag == 5){
                //check fbid exists
                
                id response = [dicResponse objectForKey:RESPONSE];
                if ([response isKindOfClass:[NSArray class]]) {
                    if (((NSDictionary *)response).count>0) {
                        //so call login service
                        if ([response isKindOfClass:[NSArray class]]) {
                            int breakReason = -1;
                            NSArray *arr = [NSArray arrayWithArray:(NSArray *)response];
                            for (int i = 0; i<arr.count; i++) {
                                for (int y = 0; y<3; y++) {
                                    switch (y) {
                                        case 0:{
                                            //check for username
                                            
                                        }
                                            break;
                                        case 1:{
                                            //check for email
                                            
                                        }
                                            break;
                                        case 2:{
                                            //check for fb ID
                                            if ([[self.strFBID lowercaseString] isEqualToString:[[[arr objectAtIndex:i] valueForKey:FB_ID] lowercaseString]]) {
                                                breakReason = 3;
                                                break;
                                            }
                                        }
                                            break;
                                        default:
                                            break;
                                    }
                                    if (breakReason != -1) {
                                        break;
                                    }
                                }
                                if (breakReason != -1) {
                                    break;
                                }
                            }
                            
                            if (breakReason == 3) {
                                //fb id exists
                                [Validation showToastMessage:@"Friends added successfully.\nPlease check your friend list." displayDuration:SUCCESS_MSG_DURATION];
                            }
                            else if (breakReason == -1){
                                //fb id does not exists
                                [self updateUserFBId];
                            }
                        }
                    }
                    else {
                        [self updateUserFBId];
                    }
                }
                else if (response==nil){
                    [self updateUserFBId];
                }
            }
            else{
                if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                    NSLog(@"dic = %@",dicResponse);
                    [appDelegate callLogOutService];
                }
                else{
                    if (request.tag == 3){
                        //contact list
                        NSArray *arResponse = [dicResponse objectForKey:RESPONSE];
                        if (arResponse.count!=0) {
                            if ([DataValidation checkNullString:self.tfPhoneNumber.text].length!=0) {
                                [[NSUserDefaults standardUserDefaults] setObject:self.tfPhoneNumber.text forKey:LOGIN_USER_PHONE];
                                [[NSUserDefaults standardUserDefaults] synchronize];
                                //                            [Validation showToastMessage:@"Contacts added successfully.\nPlease check your friend list." displayDuration:ERROR_MSG_DURATION];
                                [AlertHandler alertTitle:MESSAGE message:@"We have found a few of your friends in Blabeey.  Check your friend list and start a fun Blabeey conversation" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                                self.tfPhoneNumber.text = @"";
                                [self.tfPhoneNumber resignFirstResponder];
                                self.viewContactNumber.hidden = YES;
                            }
                            else{
                                [AlertHandler alertTitle:MESSAGE message:@"We have found a few of your friends in Blabeey.  Check your friend list and start a fun Blabeey conversation" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
//                                [Validation showToastMessage:@"Contacts added successfully.\nPlease check your friend list." displayDuration:ERROR_MSG_DURATION];
                            }
                        }
                        else{
                            [AlertHandler alertTitle:MESSAGE message:@"No friends found from your contacts" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                        }
                        self.request = nil;
                    }
                    else if (request.tag == 4){
                        //add fb friends
                        if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]].length > 0) {
                            [Validation showToastMessage:@"Friends added successfully.\nPlease check your friend list." displayDuration:SUCCESS_MSG_DURATION];
                        }
                        else{
                            [self checkFBID_Exist];
                        }
                    }
                    else if (request.tag == 6){
                        //edit profile for fbid
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            NSMutableDictionary *dic = nil;
                            if ([[response valueForKey:RESPONSE] isKindOfClass:[NSDictionary class]]) {
                                dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)response];
                            }
                            else if ([[response valueForKey:RESPONSE] isKindOfClass:[NSArray class]]){
                                dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[response objectAtIndex:0]];
                            }
                            NSLog(@"di  -%@",dic);
                            
                            [Validation setAllKeyValueFromData:dic];
                            [HUD hide:YES];
                            
                            dic = nil;
                            [Validation showToastMessage:@"Friends added successfully.\nPlease check your friend list." displayDuration:SUCCESS_MSG_DURATION];
                        }
                        
                    }
                    else if (request.tag == 7){
                        [HUD hide:YES];
                        
                        if ([[dicResponse valueForKey:STATUS] boolValue]) {
                            if (self.isNotifOff) {
                                [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:IS_APNS_OFF];
                                [Validation showToastMessage:@"Notification - OFF" displayDuration:ERROR_MSG_DURATION];
                            }
                            else{
                                [[NSUserDefaults standardUserDefaults] setBool:FALSE forKey:IS_APNS_OFF];
                                [Validation showToastMessage:@"Notification - ON" displayDuration:ERROR_MSG_DURATION];
                            }
                            
                            [[NSUserDefaults standardUserDefaults] synchronize];
                        }
                    }
                    else if (request.tag == 8){
                        [HUD hide:YES];
                        if ([[dicResponse valueForKey:STATUS] boolValue]) {
                            if ([[[[dicResponse valueForKey:RESPONSE] objectAtIndex:0] valueForKey:@"QuietMode"] intValue]==0) {

                                [[NSUserDefaults standardUserDefaults] setBool:FALSE forKey:IS_QUIETMODE_ON];
                                [[NSUserDefaults standardUserDefaults] setBool:FALSE forKey:IS_APNS_OFF];
                                self.isNotifOff = FALSE;
                                [[NSUserDefaults standardUserDefaults] synchronize];
                                [Validation showToastMessage:@"Quiet Mode - OFF" displayDuration:ERROR_MSG_DURATION];
                            }
                            else{
                                [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:IS_QUIETMODE_ON];
                                [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:IS_APNS_OFF];
                                self.isNotifOff = TRUE;
                                [[NSUserDefaults standardUserDefaults] synchronize];
                                [Validation showToastMessage:@"Quiet Mode - ON" displayDuration:ERROR_MSG_DURATION];
                            }
                        }
                        [self.tblData reloadData];
                    }
                }
            }
        }
        else{
            [HUD hide:YES];
        }
        
        dicResponse = nil;
	}
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:HELP_VIDEO_LIST_VC]) {
        HelpVideoListVC *obj = [segue destinationViewController];
        obj.indexViewCalledFrom = 1;
    }
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}


@end
