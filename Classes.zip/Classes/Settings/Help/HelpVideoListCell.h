//
//  HelpVideoListCell.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/2/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"
@interface HelpVideoListCell : UITableViewCell{
    IBOutlet UILabel *lblTitle;
    IBOutlet UIView *viewSeperate;
}
@property (nonatomic,strong) IBOutlet AsyncImageView *imgView;
-(void)setUI:(NSDictionary*)selDic;
@end
