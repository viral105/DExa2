//
//  HelpVideoListVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/2/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "HelpVideoListVC.h"
#import "HelpVideoListCell.h"
#import "Constant.h"

@interface HelpVideoListVC ()<MBProgressHUDDelegate>{
    MBProgressHUD *HUD;
    NSMutableArray *arrVideoList;
}
@property (nonatomic,strong)NSMutableArray *arrVideoList;
@end

@implementation HelpVideoListVC
@synthesize arrVideoList;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    
    [tblView setBackgroundColor:UIColorFromRGB(0Xefefef)];
    [self.view setBackgroundColor:UIColorFromRGB(0Xefefef)];
    tblView.frame = CGRectMake(tblView.frame.origin.x, tblView.frame.origin.y, tblView.frame.size.width, tblView.frame.size.height-50);
    
//    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"New to blabeey?",@"title",@"",@"image", nil];
//    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:@"Blbeey 101. Share Blbaeey Conversation",@"title",@"",@"image", nil];
//    NSDictionary *dic2 = [NSDictionary dictionaryWithObjectsAndKeys:@"The large number of recording audio filled categories",@"title",@"",@"image", nil];
    
    self.arrVideoList = [NSMutableArray new];
//    [self.arrVideoList addObject:dic];
//    [self.arrVideoList addObject:dic1];
//    [self.arrVideoList addObject:dic2];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self callGetVideoList];
}
-(void)viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)btnBack_Clicked:(id)sender{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)callGetVideoList{
    [HUD show:YES];
    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSDictionary dictionaryWithObjectsAndKeys:@"1",KeyValue,@"PageNo",KeyName, nil],@"1",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"PageSize",KeyName, nil],@"1",
                          nil];
    
    
    NSString *strUrl = [WebServiceContainer getServiceURL:GET_ALL_HELP_VIDEO withParameters:nil];
    
    AFNetworkingDataTransaction *obj = [AFNetworkingDataTransaction sharedManager];
    [obj SetCallForURL:strUrl WithDic:dic1 isAddHeader:TRUE];
    if (obj._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [obj setDelegate:self];
        [obj setTag:1];
    }
    strUrl = nil;
    
    
}
- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            [self.arrVideoList addObjectsFromArray:arr];
                            [tblView reloadData];
                        }
                    }
                }
                [HUD hide:YES];
            }
        }
    }
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrVideoList.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    HelpVideoListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HelpVideoList"];
    cell.imgView.image = nil;
    cell.imgView.imageURL = nil;
    
    NSDictionary *dic = [self.arrVideoList objectAtIndex:indexPath.row];
    [cell setUI:dic];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dic = [self.arrVideoList objectAtIndex:indexPath.row];
    viewVideoContainer.hidden = NO;
    self.moviePlayer = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:[dic valueForKey:@"VideoPath"]]];
/*
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:MPMoviePlayerDidExitFullscreenNotification
                                               object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(MPMovieDurationAvailable:)
                                                 name:MPMovieDurationAvailableNotification
                                               object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(MPMoviePlayerPlaybackStateDidChange:)
                                                 name:MPMoviePlayerPlaybackStateDidChangeNotification
                                               object:self.moviePlayer.moviePlayer];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(MPMoviewPlayerLoadStateDidChange:)
                                                 name:MPMoviePlayerLoadStateDidChangeNotification
                                               object:self.moviePlayer.moviePlayer];
    
*/
    self.moviePlayer.moviePlayer.shouldAutoplay = YES;
    
    [self.moviePlayer.moviePlayer prepareToPlay];

    self.moviePlayer.view.frame = CGRectMake(0, 0, DEVICE_WIDTH, DEVICE_HEIGHT);
    self.moviePlayer.moviePlayer.controlStyle = MPMovieControlStyleNone;
    
    [self.moviePlayer.moviePlayer play];
    self.moviePlayer.moviePlayer.scalingMode = MPMovieScalingModeAspectFit;
    [viewVideoContainer addSubview:self.moviePlayer.view];
    [viewVideoContainer bringSubviewToFront:btnClose];
}
-(IBAction)btnCloseVideo_Clicked:(id)sender{
    if (self.moviePlayer) {
        [self.moviePlayer.moviePlayer stop];
        [self.moviePlayer.view removeFromSuperview];
        self.moviePlayer = nil;
    }
    viewVideoContainer.hidden = YES;
}
@end
