//
//  HelpVideoListCell.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/2/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "HelpVideoListCell.h"

@implementation HelpVideoListCell

- (void)awakeFromNib {
    // Initialization code
    lblTitle.textColor = UIColorFromRGB(0X00c2d9);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setUI:(NSDictionary*)selDic{
    NSLog(@"seldic thumbpath %@",[selDic valueForKey:@"ThumbPath"]);
    lblTitle.text = [selDic valueForKey:@"Name"];
    self.imgView.imageURL = [NSURL URLWithString:[selDic valueForKey:@"ThumbPath"]];
    CGRect size = [self getHeightTextBlab:lblTitle.text];
    lblTitle.frame = CGRectMake(lblTitle.frame.origin.x, lblTitle.frame.origin.y, size.size.width, size.size.height);
}
- (CGRect)getHeightTextBlab:(NSString *)strText{
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    //    CGSize size = CGSizeMake(self.lblTime.frame.size.width+50, self.lbl.frame.size.height);
    CGRect size =  [strText boundingRectWithSize:CGSizeMake(lblTitle.frame.size.width, 20000)
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                            attributes:@{NSFontAttributeName:lblTitle.font,NSParagraphStyleAttributeName:paragraphStyle}
                                               context:nil];
    
    
    return size;
}
@end
