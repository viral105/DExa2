//
//  HelpVideoListVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/2/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelpVideoListVC : UIViewController<UITableViewDataSource,UITableViewDelegate,AFNetworkingDataTransactionDelegate>
{
    IBOutlet UITableView *tblView;
    IBOutlet UIView *viewVideoContainer;
    IBOutlet UIButton *btnClose;
    IBOutlet UIButton *btnBackOrMenu;
}
@property (nonatomic,strong)MPMoviePlayerViewController *moviePlayer;
@property (nonatomic,assign)int indexViewCalledFrom;// 0 means called from setting.
@end
