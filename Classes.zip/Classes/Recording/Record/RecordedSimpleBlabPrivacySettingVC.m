//
//  RecordedSimpleBlabPrivacySettingVCViewController.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 3/4/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "RecordedSimpleBlabPrivacySettingVC.h"

@interface RecordedSimpleBlabPrivacySettingVC ()

@end

@implementation RecordedSimpleBlabPrivacySettingVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self LoadViewSetting];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)LoadViewSetting{
    
    self.view.backgroundColor = UIColorFromRGB(0Xefefef);
    [self.btnPublic setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    [self.btnPrivate setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
//    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
//    [self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    
    
}
-(IBAction)btnPrivate_Clicked:(id)sender{
    [self.btnPrivate setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    [self.btnPublic setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
//    self.selectedPrivacy  = 1;
    self.ViewSetTimePeriod.hidden = NO;
    [self showTimePeriodView];
}
-(IBAction)btnPublic_Clicked:(id)sender{
    [self.btnPublic setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    [self.btnPrivate setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
//    self.selectedPrivacy  = 2;
    self.ViewSetTimePeriod.hidden = YES;
}
-(void)showTimePeriodView{
    
    float yStart = self.viewPrivacyContianer.frame.origin.y;
    yStart += self.viewPrivacyContianer.frame.size.height+20;
    
    
    self.ViewSetTimePeriod.hidden = FALSE;
    [self.btnNever setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    [self.btnOnce setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    
    yStart += self.ViewSetTimePeriod.frame.size.height+20;
    
//    self.ViewDescriptionContainer.frame = CGRectMake(0, yStart, 320, self.ViewDescriptionContainer.frame.size.height);
//    self.scrollContainer.contentSize  = CGSizeMake(self.scrollContainer.contentSize.width, yStart+self.ViewDescriptionContainer.frame.size.height+10);
}
-(IBAction)btnBack_Clicked{
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
