//
//  RecordedSimpleBlabPrivacySettingVCViewController.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 3/4/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecordedSimpleBlabPrivacySettingVC : UIViewController

//Privacy
@property (nonatomic, strong) IBOutlet UIView           *viewPrivacyContianer;
@property (nonatomic, retain) IBOutlet UILabel          *lblPrivacy;
@property (nonatomic, strong) IBOutlet UIButton         *btnPrivate;
@property (nonatomic, strong) IBOutlet UIButton         *btnPublic;

//Set Time Period
@property (nonatomic, retain) IBOutlet UIView           *ViewSetTimePeriod;
@property (nonatomic, retain) IBOutlet UILabel          *lblSetTimePeriod;
@property (nonatomic, retain) IBOutlet UILabel          *lblRecipientCanOnly;
@property (nonatomic, strong) IBOutlet UIButton         *btnOnce;
@property (nonatomic, strong) IBOutlet UIButton         *btnNever;
@end
