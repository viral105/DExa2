//
//  RecrodingVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 06/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "RecrodingVC.h"
#import "NotificationVC.h"
#import "UploadFormVC.h"
#import "MBProgressHUD.h"
#import "ASIFormDataRequest.h"
#import "UserConversationChatVC.h"
#import "IQAudioRecorderController.h"

//#define kAudioFilePath @"Test.m4a"
//void audioRouteChangeListenerCallback (void *inUserData, AudioSessionPropertyID inPropertyID,
//									   UInt32 inPropertyValueSize, const void *inPropertyValue);


@interface RecrodingVC () <MBProgressHUDDelegate,IQAudioRecorderControllerDelegate> {
	MBProgressHUD *HUD;
    IQAudioRecorderController *objIQRecorder;
}
@property (nonatomic, strong)IQAudioRecorderController *objIQRecorder;
@end

@implementation RecrodingVC
@synthesize objIQRecorder;
//id  refToSelf;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

#pragma mark - Initialization
-(id)init {
    self = [super init];
    if(self){
        [self initializeViewController];
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if(self){
        [self initializeViewController];
    }
    return self;
}

#pragma mark - Initialize View Controller Here
-(void)initializeViewController {
    // Create an instance of the microphone and tell it to use this view controller instance as the delegate
//    self.microphone = [EZMicrophone microphoneWithDelegate:self];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    NSArray *array = [self.navigationController viewControllers];
    for (int i=0;i<array.count;i++) {
        if ([[array objectAtIndex:i] isKindOfClass:[CreateHBlabVC class]]) {
            NSLog(@"going in loop");
            self.childController = [array objectAtIndex:i];
            self.delegate = self.childController;
        }
        
    }
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	
	// Set determinate mode
	HUD.mode = MBProgressHUDModeDeterminate;
	HUD.delegate = self;
	HUD.labelText = @"Uploading";
    self.progress = [[UIProgressView alloc] initWithFrame:CGRectZero] ;
	[self.progress setProgressViewStyle: UIProgressViewStyleBar];
	
	[self.progress setFrame:CGRectMake(([[UIScreen mainScreen]bounds].size.height-160)/2,181,160,10)];
	[self.view addSubview:self.progress];
    
    self.arrSelectedIds = [NSArray arrayWithArray:(NSArray *)[appDelegate.dic_NotificationReleatedData valueForKey:SelectedIds]];
    self.isGroupNotif = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue];
    self.isNotifSendToAll = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_NotifSendToAll] boolValue];
    
    [self LoadViewSetting];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appplicationIsActive)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];
    if (![[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_MESSAGE_SHOW_FOR_AUDIO_SCREEN]] boolValue]) {
        [Validation showToastMessageBigText:@"Press and Hold button to begin recording and release when you want to stop." displayDuration:INFO_MSG_DURATION];
        [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_MESSAGE_SHOW_FOR_AUDIO_SCREEN];
    }
    
}
-(void)appplicationIsActive{

    self.strFilePath = @"";
    self.lblTime.text = @"15";

}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    NSLog(@"viewWillDisappear");
    appDelegate.isShouldShowReplyPopUp = NO;
//    self.microphone.microphoneDelegate = nil;
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    
    if (Validation.adView.isFullScreenAd) {
        NSLog(@"isfullscreenad");
        Validation.adView.isFullScreenAd = FALSE;
    }
    else{
        NSLog(@"not isfullscreenad");
    }
    if (self.objIQRecorder) {
        NSLog(@"objIQRecorder");
    }
    else{
        NSLog(@"not objIQRecorder");
    }
    appDelegate.currentVc = self;
    self.lblTime.text = @"15";

    [self.scrlView setScrollEnabled:YES];
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
}

-(void)getMicePermission{

	NSError *error;
	[[AVAudioSession sharedInstance] setCategory:
	 AVAudioSessionCategoryPlayAndRecord error:&error];
	[[AVAudioSession sharedInstance] requestRecordPermission:^(BOOL response){
		if (!response) {
			//	NSLog(@"Microphone mute");
		}
	}];
}

- (BOOL)isHeadsetPluggedIn {
    AVAudioSessionRouteDescription* route = [[AVAudioSession sharedInstance] currentRoute];
    for (AVAudioSessionPortDescription* desc in [route outputs]) {
        if ([[desc portType] isEqualToString:AVAudioSessionPortHeadphones])
            return YES;
    }
    [Validation setAudioPropertyForRecording];
    return NO;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark CUSTOM METHODs

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    if (DEVICE_HEIGHT == 480) {
        self.lblTime.font = [UIFont fontWithName:Font_Montserrat_Regular size:72];
        self.lblSec.font = [UIFont fontWithName:Font_Montserrat_Regular size:20];
    }
    else{
        self.lblTime.font = [UIFont fontWithName:Font_Montserrat_Regular size:90];
        self.lblSec.font = [UIFont fontWithName:Font_Montserrat_Regular size:35];
    }
    
    [self.btnRecord setTitleColor:UIColorFromRGB(0Xff3b30) forState:UIControlStateNormal];
    [self.btnNext setTitleColor:UIColorFromRGB(0Xff3b30) forState:UIControlStateNormal];
    
    [self.btnPreview.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:17]];
    [self.btnNext.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:17]];
    
    
        
    //------------------------------------------------------------------------------
    
    /*
     Customizing the audio plot's look
     */
    [self createAudioPlot];
    
    UIImage *img = [appDelegate.dic_NotificationReleatedData valueForKey:CapturedImage];
    BOOL isGroupBlab = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue];
    if (img==nil) {
        if (isGroupBlab) {
            [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
            [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];
            self.ViewSetTimePeriod.hidden = YES;
            self.viewPrivacyContianer.hidden = YES;
            CGRect frame = self.btnPreview.frame;
            frame.origin.y = 380;
            self.btnPreview.frame = frame;
            
            frame = self.btnNext.frame;
            frame.origin.y = self.btnPreview.frame.origin.y+self.btnPreview.frame.size.height+10;
            self.btnNext.frame = frame;
            
            float height = (self.btnNext.frame.origin.y+self.btnNext.frame.size.height+50);
            self.viewMain.frame = CGRectMake(0, 0, self.viewMain.frame.size.width, height);

            //bhavik 12-Oct-2015
            
            // self.scrlView.contentSize = CGSizeMake(self.scrlView.contentSize.width, self.viewMain.frame.size.height);
            
            int yPoint = self.btnRecord.frame.origin.y+self.btnRecord.frame.size.height+10;
            
            self.btnPreview.frame = CGRectMake(self.btnPreview.frame.origin.x, yPoint, self.btnPreview.frame.size.width, self.btnPreview.frame.size.height);
            
            yPoint+= self.btnPreview.frame.size.height +10;
            
            self.btnNext.frame = CGRectMake(self.btnNext.frame.origin.x, yPoint, self.btnNext.frame.size.width, self.btnNext.frame.size.height);
            
            yPoint+= self.btnNext.frame.size.height +10;
        }
        else{
            [self.btnPublic setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
            [self.btnPrivate setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
            [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
            [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];
            [self setFramesOfView:NO];
        }
    }
    else{
        self.ViewSetTimePeriod.hidden = YES;
        self.viewPrivacyContianer.hidden = YES;
    
        float height = (self.btnNext.frame.origin.y+self.btnNext.frame.size.height+50);
        
        self.viewMain.frame = CGRectMake(0, 0, self.viewMain.frame.size.width, height);

        //bhavik 12-Oct-2015
        
        // self.scrlView.contentSize = CGSizeMake(self.scrlView.contentSize.width, self.viewMain.frame.size.height);
        
        int yPoint = self.btnRecord.frame.origin.y+self.btnRecord.frame.size.height+10;
        
        self.btnPreview.frame = CGRectMake(self.btnPreview.frame.origin.x, yPoint, self.btnPreview.frame.size.width, self.btnPreview.frame.size.height);
        
        yPoint+= self.btnPreview.frame.size.height +10;
        
        self.btnNext.frame = CGRectMake(self.btnNext.frame.origin.x, yPoint, self.btnNext.frame.size.width, self.btnNext.frame.size.height);
        
        yPoint+= self.btnNext.frame.size.height +10;
    }
    
    
    
    
    // Starts fetching audio from the default device microphone and sends data to EZMicrophoneDelegate
    
//    NSURL *url = [self testFilePathURL];
//    NSFileManager *fm = [NSFileManager defaultManager];
//    if ([fm fileExistsAtPath:self.strFilePath]) {
//        [fm removeItemAtPath:self.strFilePath error:nil];
//    }
    
    
}
-(void)setFramesOfView:(BOOL)isPrivate{// "isPrivate" Means have to show set time period view or not
    

    int yPoint;
    self.viewPrivacyContianer.hidden = NO;
    
    if (isPrivate) {
        self.ViewSetTimePeriod.hidden = NO;
        [self.btnNever setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        [self.btnOnce setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
        
//        yPoint = self.audioPlot.frame.origin.y + self.audioPlot.frame.size.height +10;
        
        yPoint = self.objIQRecorder.view.frame.origin.y + self.objIQRecorder.view.frame.size.height +10;
        
        self.viewPrivacyContianer.frame = CGRectMake(self.viewPrivacyContianer.frame.origin.x, yPoint, self.viewPrivacyContianer.frame.size.width, self.viewPrivacyContianer.frame.size.height);
        
        yPoint+= self.viewPrivacyContianer.frame.size.height +10;
        
        self.ViewSetTimePeriod.frame = CGRectMake(self.ViewSetTimePeriod.frame.origin.x, yPoint, self.ViewSetTimePeriod.frame.size.width, self.ViewSetTimePeriod.frame.size.height);
        
        yPoint+= self.ViewSetTimePeriod.frame.size.height +10;
        
        self.btnPreview.frame = CGRectMake(self.btnPreview.frame.origin.x, yPoint, self.btnPreview.frame.size.width, self.btnPreview.frame.size.height);
        
        yPoint+= self.btnPreview.frame.size.height +10;
        
        self.btnNext.frame = CGRectMake(self.btnNext.frame.origin.x, yPoint, self.btnNext.frame.size.width, self.btnNext.frame.size.height);
        
        yPoint+= self.btnNext.frame.size.height +10;
        
    }
    else{
        self.ViewSetTimePeriod.hidden = YES;
        
//        yPoint = self.audioPlot.frame.origin.y + self.audioPlot.frame.size.height +10;
        
        yPoint = self.objIQRecorder.view.frame.origin.y + self.objIQRecorder.view.frame.size.height +10;

        self.viewPrivacyContianer.frame = CGRectMake(self.viewPrivacyContianer.frame.origin.x, yPoint, self.viewPrivacyContianer.frame.size.width, self.viewPrivacyContianer.frame.size.height);
        
        yPoint+= self.viewPrivacyContianer.frame.size.height +10;
        
        self.btnPreview.frame = CGRectMake(self.btnPreview.frame.origin.x, yPoint, self.btnPreview.frame.size.width, self.btnPreview.frame.size.height);
        
        yPoint+= self.btnPreview.frame.size.height +10;
        
        self.btnNext.frame = CGRectMake(self.btnNext.frame.origin.x, yPoint, self.btnNext.frame.size.width, self.btnNext.frame.size.height);
        
        yPoint+= self.btnNext.frame.size.height +10;
    }
    NSLog(@"objIQRecorder.view.frame %@",NSStringFromCGRect(self.objIQRecorder.view.frame));
    self.viewMain.frame = CGRectMake(0, 0, self.viewMain.frame.size.width, yPoint);
    self.objIQRecorder.view.frame = CGRectMake(self.objIQRecorder.view.frame.origin.x, self.objIQRecorder.view.frame.origin.y, self.objIQRecorder.view.frame.size.width, 200);
    self.scrlView.contentSize = CGSizeMake(self.viewMain.frame.size.width, self.viewMain.frame.size.height);
    
}
-(IBAction)btnPrivate_Clicked:(id)sender{
    [self.btnPrivate setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    [self.btnPublic setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    
    [appDelegate.dic_NotificationReleatedData setValue:@"false" forKeyPath:IsPublicImg];
    
//    self.selectedPrivacy  = 1;

    [self setFramesOfView:YES];
}
-(IBAction)btnPublic_Clicked:(id)sender{
    [self.btnPublic setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    [self.btnPrivate setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
    [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];
    //    self.selectedPrivacy  = 2;

    [self setFramesOfView:NO];
}
-(IBAction)btnViewOnce_Clicked:(id)sender{
    [self.btnOnce setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    [self.btnNever setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [appDelegate.dic_NotificationReleatedData setValue:@"1" forKeyPath:RequestedKeepStatus];
}
-(IBAction)btnKeepBUtNotShare_Clicked:(id)sender{
    [self.btnNever setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    [self.btnOnce setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];
}
-(NSURL*)testFilePathURL {
    
    //    NSURL *url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@",
    //                                         [self applicationDocumentsDirectory],
    //                                         kAudioFilePath]];
    
    self.strFilePath = [NSString stringWithFormat:@"%@",[Validation applicationDocumentsDirectory]];
    
    NSURL *url = [NSURL fileURLWithPath:self.strFilePath];
    
    
    NSLog(@"%@",[url absoluteString]);
    
    return url;
}

-(void)createAudioPlot{
/*
    if (self.audioPlot) {
        [self.audioPlot removeFromSuperview];
    //    [self.audioPlot release];
        self.audioPlot = nil;
    }
    
    self.audioPlot = [[EZAudioPlotGL alloc]  initWithFrame:CGRectMake(10, 68, 300, 400)];
//    [self.audioPlot setAutoresizingMask:UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleTopMargin];
    self.audioPlot.contentMode = UIViewContentModeScaleAspectFill;
    self.audioPlot.center = self.btnRecord.center;
    [self.viewMain addSubview:self.audioPlot];
    
    // Background color
    //    self.audioPlot.backgroundColor = [UIColor colorWithRed: 0.984 green: 0.71 blue: 0.365 alpha: 1];
//    self.audioPlot.backgroundColor = UIColorFromRGB(0Xefefef);
    
    self.audioPlot.backgroundColor = UIColorFromRGB(0Xefefef);
//    self.audioPlot.backgroundColor = UIColorFromRGB(0X00efef);

    
    // Waveform color
    //    self.audioPlot.color           = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:1.0];
    self.audioPlot.color           = [UIColor redColor];
    // Plot type
    self.audioPlot.plotType        = EZPlotTypeRolling;
    // Fill
    self.audioPlot.shouldFill      = YES;
    // Mirror
    self.audioPlot.shouldMirror    = YES;
    
    self.audioPlot.gain = 3;
    
    [self.viewMain sendSubviewToBack:self.audioPlot];
*/
    self.objIQRecorder = [[IQAudioRecorderController alloc]  init];
    self.objIQRecorder.delegate = self;
    CGRect frame = CGRectMake(10, 68, 300, 200);
    self.objIQRecorder.view.frame = frame;
    [self.objIQRecorder willMoveToParentViewController:self];
    [self.viewMain addSubview:self.objIQRecorder.view];
    [self.viewMain sendSubviewToBack:self.objIQRecorder.view];
    [self addChildViewController:self.objIQRecorder];
    [self.objIQRecorder didMoveToParentViewController:self];

}
-(void)audioRecorderController:(IQAudioRecorderController *)controller didFinishWithAudioAtPath:(NSString *)filePath
{
    self.strFilePath = filePath;
//    buttonPlayAudio.enabled = YES;
}

-(void)audioRecorderControllerDidCancel:(IQAudioRecorderController *)controller
{
//    buttonPlayAudio.enabled = NO;
}
#pragma mark timer methods

-(void)startTimer:(NSTimer *)time{
    self.timeRemaining -= 1;
    
    self.lblTime.text = [NSString stringWithFormat:@"%d",self.timeRemaining];
    
    if (self.timeRemaining <= 0) {
        self.isShouldStop = YES;
    }
    
    if (self.isShouldStop) {
        [self.timerRecord invalidate];
        self.timerRecord = nil;
        
        NSFileManager *fm = [NSFileManager defaultManager];
        if ([fm fileExistsAtPath:self.strFilePath]) {
            NSLog(@"file exist");
        }
        
        
        self.isRecording = NO;
        
        if ([fm fileExistsAtPath:self.strFilePath]) {
            NSLog(@"file exist");
        }
        
        
        //
//        
//        self.audioPlot.plotType        = EZPlotTypeRolling;
//        // Fill
//        self.audioPlot.shouldFill      = YES;
//        // Mirror
//        self.audioPlot.shouldMirror    = YES;
//        
//        self.audioPlot.gain = 3;
        
  //      [self.recorder release];

    }
}
-(void)updateRemainingTimeLabel:(NSString*)str{
    
    self.lblTime.text = [NSString stringWithFormat:@"%d",15-[str intValue]];
}
-(void)checkForIsAudioPlaying{
    if( self.audioPlayer )
    {
        if( self.audioPlayer.playing)
        {
            [self.audioPlayer stop];
        }
        self.audioPlayer.delegate = nil;
        self.audioPlayer = nil;
        [self.btnPreview setTitle:@"Preview" forState:UIControlStateNormal];
    }
}

#pragma mark - Utility

-(NSArray*)applicationDocuments {
    return NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
}

-(NSString*)applicationDocumentsDirectory
{
        NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:RECORDING_FOLDER])
	{
		[fm createDirectoryAtPath:RECORDING_FOLDER
								  withIntermediateDirectories:YES
												   attributes:nil
														error:NULL];
	}
    
    
    NSString *basePath = [RECORDING_FOLDER stringByAppendingPathComponent:@"MySound.m4a"];
    

    if ([fm fileExistsAtPath:basePath]) {
        [fm removeItemAtPath:basePath error:nil];
    }
    return basePath;
}
/*
-(IBAction)btnStartStopRecording:(id)sender{

    if ([self.audioPlayer isPlaying]) {
        [self.audioPlayer stop];
    }
    
    if (![self.timerRecord isValid]) {
        if(((UIButton *)sender).tag == 10)
        {
            [self createAudioPlot];
            self.timeRemaining = 10;
            self.lblTime.text = [NSString stringWithFormat:@"%d",self.timeRemaining];
            
//             Create the recorder
             
           
            NSURL *url = [self testFilePathURL];
            self.recorder = [EZRecorder recorderWithDestinationURL:url
                                                      sourceFormat:self.microphone.audioStreamBasicDescription
                                               destinationFileType:EZRecorderFileTypeM4A];
            
          
            
            
            self.timerRecord = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(startTimer:) userInfo:nil repeats:YES];
            
            self.btnRecord.tag = 11;
            self.isShouldStop = NO;
            [self.microphone startFetchingAudio];
            self.isRecording = YES;
            [self.btnPreview setEnabled:NO];
            [self.btnRecord setImage:[UIImage imageNamed:btnRecordStop] forState:UIControlStateNormal];
        }
    }
}
*/
-(IBAction)btnStartStopRecording:(id)sender{
    
    if ([self.audioPlayer isPlaying]) {
        [self.audioPlayer stop];
        
        self.isRecording = NO;
    }
    
    if (![self.timerRecord isValid]) {
        if(((UIButton *)sender).tag == 10)
        {
            [self createAudioPlot];
            self.timeRemaining = 15;
            self.lblTime.text = [NSString stringWithFormat:@"%d",self.timeRemaining];
            /*
             Create the recorder
             */
            
            
            self.timerRecord = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(startTimer:) userInfo:nil repeats:YES];
            
            self.btnRecord.tag = 11;
            self.isShouldStop = NO;
            self.isRecording = YES;
            [self.btnPreview setEnabled:NO];
            [self.btnRecord setImage:[UIImage imageNamed:btnRecordStop] forState:UIControlStateNormal];
        }
    }
}
-(IBAction)btnStopRecordingClicked:(id)sender{
    self.btnRecord.tag = 10;
    
    self.isShouldStop = YES;
//    self.isRecording = NO;
    [self.btnPreview setEnabled:YES];
    [self.btnRecord setImage:[UIImage imageNamed:btnRecordStart] forState:UIControlStateNormal];
    
}


-(IBAction)btnPreviewRecroding:(id)sender{
    // Create Audio Player
    [self isHeadsetPluggedIn];
    if( self.audioPlayer )
    {
        if( self.audioPlayer.playing)
        {
            [self.audioPlayer stop];
        }
        self.audioPlayer.delegate = nil;
        self.audioPlayer = nil;
        [self.btnRecord setEnabled:YES];
        [self.btnPreview setTitle:@"Preview" forState:UIControlStateNormal];
    }
    else{
        
       // [Validation setAudioPropertyForRecording];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        if ([fm fileExistsAtPath:self.strFilePath]) {
            NSLog(@"file exist");
            
            //        if( self.recorder )
            //        {
            //            [self.recorder closeAudioFile];
            //        }
            [self.btnPreview setTitle:@"Stop" forState:UIControlStateNormal];
            NSError *err;
            self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL URLWithString:self.strFilePath]
                                                                      error:&err];
            [self.audioPlayer prepareToPlay];
            
            self.audioPlayer.delegate = self;
            self.isRecording = NO;
            [self.btnRecord setEnabled:NO];
            [self.audioPlayer play];

        }
        else{
            [Validation showToastMessage:@"Please record a Blab." displayDuration:ERROR_MSG_DURATION];
        }
    }
   
    // Close the audio file
}

-(IBAction)btnNextUploadClicked:(id)sender{
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:self.strFilePath]) {
        NSLog(@"file exist");
        
        //now check if it is Private image blab
        // if image+ private then set this Recorded file to private
/*        
 // Commented by viral 03-05-2015
        BOOL isPublic = [[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:IsPublicImg]] boolValue];
        if (!isPublic) {
            //image is set to private
            self.isPrivate = TRUE;
            [self StartUploadingAudioFile];
        }
        else{
            //ask user again for keeping this blab as private
//            self.isPrivate = YES;
            [self performSegueWithIdentifier:@"RecordedSimpleBlabPrivacySettingVC" sender:self];
//            [AlertHandler alertTitle:@"Set Time Period" message:@"Recipient Can" delegate:self tag:2 cancelButtonTitle:CANCLE_BUTTON_TITLE OKButtonTitle:@"Keep but not Share" otherButtonTitle:@"View Once"];
//            [AlertHandler alertTitle:CONFIRM message:@"Would you like to add this recording to a Blabeey categroy?" delegate:self tag:1 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
        }
*/
        [self StartUploadingAudioFile];
    }
    else{
        [Validation showToastMessage:@"Please record a Blab." displayDuration:ERROR_MSG_DURATION];
    }
    
}

-(IBAction)btnCancel:(id)sender{
    if (!self.isRecording) {
        if ([self.audioPlayer isPlaying]) {
            [self.audioPlayer stop];
            
        }
        [self.timerRecord invalidate];
        [self.navigationController popViewControllerAnimated:YES];
    }

    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:self.strFilePath]) {
        [fm removeItemAtPath:self.strFilePath error:nil];
    }
    
}

-(void)uploadFile{

       NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:self.strFilePath]) {
        NSLog(@"file exists");
    }
    

	NSString *strUrl = [NSString stringWithFormat:@"%@",UPLOAD_AUDIO_FILE];
    NSString *strPath = [NSString stringWithFormat:@"%@",self.strFilePath];
    
    if ([fm fileExistsAtPath:strPath]) {
        NSLog(@"file exist");
    }

    NSMutableData *data = [NSMutableData dataWithContentsOfFile:strPath];

    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Name",KeyName,nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SoundMasterID",KeyName,nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SoundSubMasterID",KeyName,nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"UserID",KeyName,nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"Gender",KeyName,nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"IsPrivate",KeyName,nil],@"6",
                         [NSDictionary dictionaryWithObjectsAndKeys:(data.length>0)?data:@"",KeyValue,@"SoundData",KeyName, nil],@"7",
                         
                         nil];
    
    AFNetworkingDataTransaction *requestUpload = [AFNetworkingDataTransaction sharedManager];
    //[request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    [requestUpload SetCallForURLWithImg:strUrl WithDic:dic isAddHeader:TRUE forLoader:HUD];
    
    if (requestUpload._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [requestUpload setDelegate:self];
        [requestUpload setTag:1];
        HUD.mode = MBProgressHUDModeDeterminate;
        HUD.delegate = self;
        HUD.labelText = @"Uploading";
        
        [requestUpload._currentRequest setUploadProgressBlock:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) {
            double percentDone = (double)totalBytesWritten / (double)totalBytesExpectedToWrite;
            //Upload Progress bar here
            NSLog(@"progress updated(percentDone) : %f", percentDone);
            [HUD setProgress:percentDone];
            if (percentDone == 1.0) {
                [self.timer invalidate];
                HUD.mode = MBProgressHUDModeIndeterminate;
                HUD.labelText = @"";
            }
        }];
    }
    /*
    self.request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:strUrl]];
    
    [self.request setDelegate:self];
    
    [self.request addRequestHeader:@"userid" value:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]];
    NSString *strT1 = [Validation GetUTCDate];
    [self.request addRequestHeader:@"T1" value:strT1];
    [self.request addRequestHeader:@"T2" value:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE]];
    
    [self.request setPostValue:@"" forKey:@"Name"];
    [self.request setPostValue:@"0" forKey:@"SoundMasterID"];
    [self.request setPostValue:@"0" forKey:@"SoundSubMasterID"];
    [self.request setPostValue:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]] forKey:@"UserID"];
    [self.request setPostValue:@"0" forKey:@"Gender"];
    [self.request setPostValue:@"true" forKey:@"IsPrivate"];
    
    
    self.progress.progress = 0.0;
    self.progress.hidden = YES;
    [self.request setUploadProgressDelegate:self.progress];
    [self.request setShouldContinueWhenAppEntersBackground:YES];
  
    NSString *strPath = [NSString stringWithFormat:@"%@",self.strFilePath];
    
    if ([fm fileExistsAtPath:strPath]) {
        NSLog(@"file exist");
    }
    NSMutableData *data = [NSMutableData dataWithContentsOfFile:strPath];
    [self.request addData:data withFileName:@"userSound.m4a" andContentType:@"multipart/form-data" forKey:@"SoundData"];

    self.request.tag = 1;
    [self.request startAsynchronous];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(setProgressFORHUD:) userInfo:nil repeats:YES];
*/
}

- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
    
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    
    if (dicResponse != nil) {
        
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.2];
            Validation.viewPullToRefresh.alpha = 0;
            [UIView commitAnimations];
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            /*
                             {
                             Response =     (
                             {
                             CreateBy = 20190;
                             CreateDate = "2014-10-07T06:04:30.92";
                             DeleteBy = "<null>";
                             DeleteDate = "<null>";
                             FilePath = "http://upload.wwhhaazzuupp.com/UserSound/0_0_EI8V92ME4730748_20190.mp3";
                             Gender = 0;
                             ID = 10257;
                             IsActive = 0;
                             IsDelete = 0;
                             IsPrivate = 1;
                             Name = "";
                             SoundMasterID = 0;
                             SoundSubMasterID = 0;
                             SubType = "<null>";
                             Type = "<null>";
                             UpdateBy = "<null>";
                             UpdateDate = "<null>";
                             UserID = "<null>";
                             }
                             );
                             Status = 1;
                             UserStatus =     {
                             IsActive = 1;
                             IsDelete = 0;
                             Msg = success;
                             status = 1;
                             };
                             }
                             */
                            
                            HUD.mode = MBProgressHUDModeIndeterminate;
                            NSString *strNotifId = [NSString stringWithFormat:@"%@",[response valueForKey:NEW_YAPEEY_ID]];
                            strNotifId = [strNotifId stringByTrimmingCharactersInSet: [[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
                            response = nil;
                            [self sendNotifMsg:strNotifId];
                        }
                        else{
                            response = nil;
                        }
                    }
                }
            }
            else if (tag == 2){
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
                        __block UIImageView *imageView;
                        UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                        imageView = [[UIImageView alloc] initWithImage:image];
                        
                        HUD.customView = imageView;
                        HUD.mode = MBProgressHUDModeText;
                        HUD.labelText = @"Sent";
                        imageView = nil;
                        [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
                    }
                    else{
                        if ([[dicResponse objectForKey:RESPONSE] isKindOfClass:[NSArray class]]) {
                            
                            //[Validation showToastMessage:[[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] displayDuration:ERROR_MSG_DURATION];
                            HUD.mode = MBProgressHUDModeText;
                            HUD.delegate = self;
                            HUD.detailsLabelFont = [UIFont boldSystemFontOfSize:16];
                            HUD.detailsLabelText = [[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] ;
                            [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:4];
                        }
                        else{
                            [HUD hide:YES];
                            
                        }
                    }
                }

            }
        }
    }
}

- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}

- (void)setProgressFORHUD:(float)progress {
    NSLog(@"actual progress = %f",self.progress.progress);
   // int prog = (round(self.progress.progress*100));
    [HUD setProgress:self.progress.progress];
    if (self.progress.progress == 1.0) {
        [self.timer invalidate];
        HUD.mode = MBProgressHUDModeIndeterminate;
        HUD.labelText = @"";
    }
}
-(void)sendNotifMsg:(NSString *)strNewYapeeyId{
	
    UIImage *img = [appDelegate.dic_NotificationReleatedData valueForKey:CapturedImage];
    NSString *strCaption = [NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:ImageCaption]];
    
    self.arrSelectedIds = [NSArray arrayWithArray:(NSArray *)[appDelegate.dic_NotificationReleatedData valueForKey:SelectedIds]];
    self.isGroupNotif = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue];
    self.isNotifSendToAll = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_NotifSendToAll] boolValue];


	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:(self.isGroupNotif)?@"":[NSString stringWithFormat:@"%@",[self.arrSelectedIds componentsJoinedByString:@"|"]],KeyValue,@"ReceiverIDs",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"Ctype",KeyName, nil],@"3",
						 [NSDictionary dictionaryWithObjectsAndKeys:(self.isGroupNotif)?[NSString stringWithFormat:@"%@",[self.arrSelectedIds componentsJoinedByString:@"|"]]:@"0",KeyValue,@"GroupIDs",KeyName, nil],@"4",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SubCatID",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"6",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",(self.isNotifSendToAll)?@"true":@"false"],KeyValue,@"AllFriend",KeyName, nil],@"7",
                         [NSDictionary dictionaryWithObjectsAndKeys:strNewYapeeyId,KeyValue,@"NewSoundID",KeyName, nil],@"8",
                         [NSDictionary dictionaryWithObjectsAndKeys:((img!= nil)?img:@""),KeyValue,@"ImgData",KeyName, nil],@"9",
                         [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:strCaption].length > 0)?strCaption:@"",KeyValue,@"Caption",KeyName, nil],@"10",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:IsPublicImg]],KeyValue, IsPublicImg,KeyName, nil],@"11",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:RequestedKeepStatus]],KeyValue, RequestedKeepStatus, KeyName, nil],@"12",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:BlabType]],KeyValue, BlabType, KeyName, nil],@"13",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"14",

						 nil];
	
    if([self.delegate respondsToSelector:@selector(passBlabDataForHBlab:)]) {
        [self.delegate passBlabDataForHBlab:dic];
        [HUD hide:YES];
        [self popToCreateHBlab];
        return;
    }
    //only @"ID" represents notif If that we want to forward, in this screen it will be 0 as we arent forwarding any notif
    NSLog(@"recording send notif dic %@",dic);
	NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];       //SEND_TEST_MSG     //SEND_NOTIF_MSG
	
    //self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];

    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURLWithImg:strUrl WithDic:dic isAddHeader:TRUE forLoader:HUD];
    
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }
//	self.request.delegate = self;
//	self.request.tag = 2;
	strUrl = nil;
}

-(void)ShowUploadForm{
    
}

#pragma mark    UIAlertViewDelegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 1) {
        if (buttonIndex == alertView.cancelButtonIndex) {
            self.isPrivate = YES;
            //if ([appDelegate.dic_NotificationReleatedData valueForKey:CapturedImage] == nil) {
                [AlertHandler alertTitle:@"Set Time Period" message:@"Recipient Can" delegate:self tag:2 cancelButtonTitle:CANCLE_BUTTON_TITLE OKButtonTitle:@"Keep but not Share" otherButtonTitle:@"View Once"];
//            }
//            else{
//                [self StartUploadingAudioFile];
//            }
        }
        else{
            self.isPrivate = NO;
            [self performSegueWithIdentifier:UPLOAD_FORM_VC sender:nil];
        }
    }
    else if (alertView.tag == 2) {
        if (buttonIndex == alertView.cancelButtonIndex) {

        }
        else if (buttonIndex == 1){
            //Keep but not share
            [appDelegate.dic_NotificationReleatedData setObject:@"false" forKey:IsPublicImg];
            [appDelegate.dic_NotificationReleatedData setObject:@"2" forKey:RequestedKeepStatus];
            [self StartUploadingAudioFile];
            
        }
        else if (buttonIndex == 2){
            //view Once
            [appDelegate.dic_NotificationReleatedData setObject:@"false" forKey:IsPublicImg];
            [appDelegate.dic_NotificationReleatedData setObject:@"1" forKey:RequestedKeepStatus];
            [self StartUploadingAudioFile];
        }
    }
}

-(void)StartUploadingAudioFile{
 //   [Validation showLoadingIndicatorInView:self.view];
    [HUD show:YES];

    [self uploadFile];

}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:UPLOAD_FORM_VC]) {
        UploadFormVC *objUpload = segue.destinationViewController;
        objUpload.strFilePath = self.strFilePath;
    }
}

#pragma mark - EZMicrophoneDelegate
//#warning Thread Safety
// Note that any callback that provides streamed audio data (like streaming microphone input) happens on a separate audio thread that should not be blocked. When we feed audio data into any of the UI components we need to explicity create a GCD block on the main thread to properly get the UI to work.
/*
-(void)microphone:(EZMicrophone *)microphone
 hasAudioReceived:(float **)buffer
   withBufferSize:(UInt32)bufferSize
withNumberOfChannels:(UInt32)numberOfChannels {
    // Getting audio data as an array of float buffer arrays. What does that mean? Because the audio is coming in as a stereo signal the data is split into a left and right channel. So buffer[0] corresponds to the float* data for the left channel while buffer[1] corresponds to the float* data for the right channel.
    
    // See the Thread Safety warning above, but in a nutshell these callbacks happen on a separate audio thread. We wrap any UI updating in a GCD block on the main thread to avoid blocking that audio flow.
    dispatch_async(dispatch_get_main_queue(),^{
        // All the audio plot needs is the buffer data (float*) and the size. Internally the audio plot will handle all the drawing related code, history management, and freeing its own resources. Hence, one badass line of code gets you a pretty plot :)
        [self.audioPlot updateBuffer:buffer[0] withBufferSize:bufferSize];
    });
}

-(void)microphone:(EZMicrophone *)microphone
    hasBufferList:(AudioBufferList *)bufferList
   withBufferSize:(UInt32)bufferSize
withNumberOfChannels:(UInt32)numberOfChannels {
    
    // Getting audio data as a buffer list that can be directly fed into the EZRecorder. This is happening on the audio thread - any UI updating needs a GCD main queue block. This will keep appending data to the tail of the audio file.
    if( self.isRecording ){
        [self.recorder appendDataFromBufferList:bufferList
                                 withBufferSize:bufferSize];
    }
    
}
*/

#pragma mark - AVAudioPlayerDelegate
/*
 Occurs when the audio player instance completes playback
 */
-(void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag {
 
    self.audioPlayer.delegate = nil;
    self.audioPlayer = nil;
    [self.btnRecord setEnabled:YES];
    [self.btnPreview setTitle:@"Preview" forState:UIControlStateNormal];

}

#pragma mark    WEBSERVICE RESPONSE
- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];;
	
    NSLog(@"dicResponse = %@",dicResponse);
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if ([dicResponse objectForKey:RESPONSE] != nil) {
                
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    if (request.tag == 1) {
                        NSLog(@"upload Response");
                        if ([dicResponse objectForKey:RESPONSE] != nil) {
                            
                            if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                                
                                //received
                                id response = [dicResponse objectForKey:RESPONSE];
                                if (response != nil) {
                                    
                                    /*
                                     {
                                     Response =     (
                                     {
                                     CreateBy = 20190;
                                     CreateDate = "2014-10-07T06:04:30.92";
                                     DeleteBy = "<null>";
                                     DeleteDate = "<null>";
                                     FilePath = "http://upload.wwhhaazzuupp.com/UserSound/0_0_EI8V92ME4730748_20190.mp3";
                                     Gender = 0;
                                     ID = 10257;
                                     IsActive = 0;
                                     IsDelete = 0;
                                     IsPrivate = 1;
                                     Name = "";
                                     SoundMasterID = 0;
                                     SoundSubMasterID = 0;
                                     SubType = "<null>";
                                     Type = "<null>";
                                     UpdateBy = "<null>";
                                     UpdateDate = "<null>";
                                     UserID = "<null>";
                                     }
                                     );
                                     Status = 1;
                                     UserStatus =     {
                                     IsActive = 1;
                                     IsDelete = 0;
                                     Msg = success;
                                     status = 1;
                                     };
                                     }
                                     */
                                    
                                    HUD.mode = MBProgressHUDModeIndeterminate;
                                    NSString *strNotifId = [NSString stringWithFormat:@"%@",[response valueForKey:NEW_YAPEEY_ID]];
                                    strNotifId = [strNotifId stringByTrimmingCharactersInSet: [[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
                                     response = nil;
                                    [self sendNotifMsg:strNotifId];
                                }
                                else{
                                     response = nil;
                                }
                            }
                        }
                    }
            else if (request.tag == 2){
                //send notification
                
                NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
                __block UIImageView *imageView;
                UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                imageView = [[UIImageView alloc] initWithImage:image];
                
                HUD.customView = imageView;
                HUD.mode = MBProgressHUDModeText;
                HUD.labelText = @"Sent";
                imageView = nil;
                [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
            }
                }
                else{
                    [HUD hide:YES];
                }
            }
            else{
                [HUD hide:YES];
            }
        }
    }
    else{
        [HUD hide:YES];
    }
	
}

- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}
-(void)popToCreateHBlab{
    
    //    [Validation cleanNotifcationRelatedDicData];
    
    [HUD hide:YES];
    
    //    self.isNotifSentMsgVisible = NO;
    //    [self.request CancleOngoingRequest];
    //    self.request = nil;
    
    NSArray *arr = [self.navigationController viewControllers];
    //    BOOL isGotPopViewController = FALSE;
    
    
    //    [self removeFilesFromDir];
    
    for (UIViewController *v in arr) {
        
        if ([v isKindOfClass:[CreateHBlabVC class]]) {
            [self.navigationController popToViewController:v animated:YES];
            break;
        }
    }
    
}
-(void)popToNotifListScreen{
    [Validation cleanNotifcationRelatedDicData];
    
    [self.request CancleOngoingRequest];
    self.request = nil;
    
	[HUD hide:YES];
    NSArray *arr = [self.navigationController viewControllers];
    BOOL isGotPopViewController = FALSE;
    
    for (UIViewController *v in arr) {
        if ([v isKindOfClass:[UserConversationChatVC class]]) {
            isGotPopViewController = TRUE;
            [self.navigationController popToViewController:v animated:YES];
        }
    }
    
    if (!isGotPopViewController) {
        
        [self removeViewControllersFromStack];
        
        if (appDelegate.selectedMenuIndex>0) {
            appDelegate.selectedMenuIndex = 0;
        }
        SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
        
        [UIView transitionWithView:self.navigationController.view
                          duration:0.5
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.navigationController pushViewController:ivc animated:NO];
                        }
                        completion:nil];
    }
    

//    if (!isGotPopViewController) {
//        
//        [self removeViewControllersFromStack];
//        
//        if (appDelegate.selectedMenuIndex>0) {
//            appDelegate.selectedMenuIndex = 0;
//  //          UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//            SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
//            
//            [UIView transitionWithView:self.navigationController.view
//                              duration:0.5
//                               options:UIViewAnimationOptionTransitionCrossDissolve
//                            animations:^{
//                                [self.navigationController pushViewController:ivc animated:NO];
//                            }
//                            completion:nil];
//            
//        }
//        else{
//            
// //           UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
////            NotificationVC *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:NOTIFICATION_VC];
////            [self.navigationController pushViewController:ivc animated:YES];
//        }
//    }
}

-(void)removeViewControllersFromStack{
  //  NSArray *arrVC = self.navigationController.viewControllers;
    for (id vc in self.navigationController.viewControllers){
		if ([vc isKindOfClass:[FavoritesVC class]]) {
			[self removeFromNavigationController:vc animated:NO];
		}
        else if ([vc isKindOfClass:[NotificationVC class]]) {
			[self removeFromNavigationController:vc animated:NO];
		}
        else if ([vc isKindOfClass:[SearchFriendVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[OtherFriendNotifListVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[SettingsVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[NotifOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[CategoryListForUploadVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[GroupListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[UserListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[RecordingOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
	}
    
}

-(void)removeFromNavigationController:(UIViewController *)controller animated:(BOOL)animated {
    
    NSMutableArray *allViewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];;
    [allViewControllers removeObjectIdenticalTo:controller];
    self.navigationController.viewControllers = allViewControllers;
	
}


/*
void audioRouteChangeListenerCallback (void *inUserData, AudioSessionPropertyID inPropertyID,
                                       UInt32 inPropertyValueSize, const void *inPropertyValue) {
	
	CFDictionaryRef routeChangeDictionary = inPropertyValue;
	CFNumberRef routeChangeReasonRef = CFDictionaryGetValue (routeChangeDictionary, CFSTR(kAudioSession_AudioRouteChangeKey_Reason));
	SInt32 routeChangeReason;
	CFNumberGetValue(routeChangeReasonRef, kCFNumberSInt32Type, &routeChangeReason);
	
	if (routeChangeReason == kAudioSessionRouteChangeReason_OldDeviceUnavailable ||
		routeChangeReason == kAudioSessionRouteChangeReason_NewDeviceAvailable) {
		CFStringRef route;
		UInt32 propertySize = sizeof(CFStringRef);
		if (AudioSessionGetProperty(kAudioSessionProperty_AudioRoute, &propertySize, &route) == 0)	{
			NSString *routeString = (NSString *) route;
            if (refToSelf != nil) {
				if ([routeString isEqualToString: @"Headphone"] == YES) {
					
				}
				else if ([routeString isEqualToString:@"HeadsetInOut"] == YES){
					
					
				}
				else if ([routeString isEqualToString:@"SpeakerAndMicrophone"] == YES){
					
                }
				else if ([routeString isEqualToString:@"ReceiverAndMicrophone"] == YES){
					
				}
				else if ([routeString isEqualToString:@"HeadphonesAndMicrophone"] == YES){
									}
                
			}
		}
	}
}

*/
@end
