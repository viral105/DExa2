//
//  RecrodingVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 06/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
// Import EZAudio header
#import "ASIFormDataRequest.h"
#import "CreateHBlabVC.h"
#import "GeneralDelegate.h"

@interface RecrodingVC : UIViewController <AVAudioRecorderDelegate,AVAudioPlayerDelegate,UIAlertViewDelegate,AFNetworkingDataTransactionDelegate>

@property (nonatomic, assign) BOOL isRecording;
@property (nonatomic, strong) IBOutlet UIScrollView *scrlView;
@property (nonatomic, strong) IBOutlet UIView *viewMain;
@property (nonatomic, retain) IBOutlet UIButton     *btnRecord;
@property (nonatomic, retain) IBOutlet UIButton     *btnPreview;
@property (nonatomic, retain) IBOutlet UIButton     *btnNext;

@property (nonatomic, strong) AVAudioPlayer *audioPlayer;

@property (nonatomic, retain) IBOutlet UILabel      *lblTime;
@property (nonatomic, retain) IBOutlet UILabel      *lblSec;
@property (nonatomic, strong) NSTimer               *timerRecord;
@property (nonatomic, strong) IBOutlet UILabel		*lblTitle;
@property (nonatomic, readwrite) int				timeRemaining;
@property (nonatomic, readwrite) BOOL               isShouldStop;
@property (nonatomic, readwrite) BOOL               isPrivate;
@property (nonatomic, strong) NSString              *strFilePath;
@property (nonatomic, strong) NSArray				*arrSelectedIds;
@property (nonatomic, strong) AFNetworkingDataTransaction		*request;
@property (nonatomic, readwrite) BOOL				isGroupNotif;
@property (nonatomic, readwrite) BOOL				isNotifSendToAll;
@property (nonatomic, strong) CreateHBlabVC *childController;
@property (nonatomic, strong) id<GeneralDelegate> delegate;

@property (nonatomic, strong) NSTimer               *timer;
@property (nonatomic, strong) UIProgressView			*progress;

//Privacy
@property (nonatomic, strong) IBOutlet UIView           *viewPrivacyContianer;
@property (nonatomic, retain) IBOutlet UILabel          *lblPrivacy;
@property (nonatomic, strong) IBOutlet UIButton         *btnPrivate;
@property (nonatomic, strong) IBOutlet UIButton         *btnPublic;

//Set Time Period
@property (nonatomic, retain) IBOutlet UIView           *ViewSetTimePeriod;
@property (nonatomic, retain) IBOutlet UILabel          *lblSetTimePeriod;
@property (nonatomic, retain) IBOutlet UILabel          *lblRecipientCanOnly;
@property (nonatomic, strong) IBOutlet UIButton         *btnOnce;
@property (nonatomic, strong) IBOutlet UIButton         *btnNever;

@end
