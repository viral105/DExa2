//
//  RecordingOptionVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 06/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworkingDataTransaction.h"
#import "RecordOptionBannerCell.h"
#import "ASIFormDataRequest.h"
#import "CreateHBlabVC.h"
#import "GeneralDelegate.h"

@interface RecordingOptionVC : UIViewController <UITableViewDelegate, UITableViewDataSource,AFNetworkingDataTransactionDelegate>

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;
@property (nonatomic, strong) IBOutlet UITableView          *tblData;
@property (nonatomic, strong) NSArray                       *arrData;

@property (nonatomic, strong) AFNetworkingDataTransaction   *requestAFNetworking;
@property (nonatomic, strong) NSTimer                       *timer;

@property (nonatomic, strong) IBOutlet UIButton             *btnRecord;
@property (nonatomic, strong) IBOutlet UIButton             *btnPreRecordedCategory;
@property (nonatomic, strong) IBOutlet UIButton             *btnVidiBlaboverAudio;
@property (nonatomic, strong) IBOutlet UIButton             *btnHelpVideo;
//@property (nonatomic, strong) ASIFormDataRequest            *requestData;

@property (nonatomic, strong) NSTimer               *timer1;
@property (nonatomic, strong) UIProgressView			*progress;
@property (nonatomic, strong) CreateHBlabVC *childController;
@property (nonatomic, strong) id<GeneralDelegate> delegate;

@property (nonatomic, strong) IBOutlet UIView *viewVideoContainer;
@property (nonatomic, strong) IBOutlet UIButton *btnClose;
@property (nonatomic,strong)MPMoviePlayerViewController *moviePlayer;

@end
