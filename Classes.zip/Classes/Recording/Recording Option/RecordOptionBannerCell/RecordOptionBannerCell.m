//
//  RecordOptionBannerCell.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 18/12/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "RecordOptionBannerCell.h"

@implementation RecordOptionBannerCell


-(void)setBannerControlls:(NSDictionary *)dic{
    CGAffineTransform transform =   CGAffineTransformMakeRotation(1.5707963);          //CGAffineTransformMakeRotation(1.5707963);
    self.transform = transform;
    [self.imgBanner setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:@"ImagePath"]]]];
}

@end
