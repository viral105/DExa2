//
//  RecordOptionBannerCell.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 18/12/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecordOptionBannerCell : UITableViewCell

@property (nonatomic, strong) IBOutlet AsyncImageView    *imgBanner;
//@property (nonatomic, strong) IBOutlet UIButton          *btnbanner;

-(void)setBannerControlls:(NSDictionary *)dic;

@end
