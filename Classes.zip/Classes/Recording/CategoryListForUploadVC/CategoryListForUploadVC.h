//
//  CategoryListForUploadVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 08/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CategoryListForUploadVCDelegate;

@protocol CategoryListForUploadVCDelegate <NSObject>
- (void)setCategoryDetail:(NSDictionary *)dic WithRowIndex:(NSString *)strIndex;

@end

@interface CategoryListForUploadVC : UIViewController <UITableViewDataSource, UITableViewDelegate,UICollectionViewDataSource, UICollectionViewDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, strong) NSMutableArray				*arrSubCat;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) ASIHTTPRequest				*request;
@property (nonatomic, readwrite) BOOL						isShowSubCategories;
@property (nonatomic, readwrite) BOOL						isShowFooter;
@property (nonatomic, readwrite) int						selectedSection;
@property (nonatomic, readwrite) int						selectedRow;
@property (nonatomic, strong) IBOutlet UIButton             *btnNext;
@property (nonatomic, retain) UIImageView                   *imgSelection;

@property (nonatomic ,assign) id <CategoryListForUploadVCDelegate>       delegate;

@property (nonatomic, strong) NSMutableDictionary *contentOffsetDictionary;


@end
