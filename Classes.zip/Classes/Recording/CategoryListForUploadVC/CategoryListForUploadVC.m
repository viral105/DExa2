//
//  CategoryListForUploadVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 08/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "CategoryListForUploadVC.h"
#import "NotifFileOptionCell.h"
#import "AFTableViewCell.h"
#import "SubCat_CollectionCell.h"
#import "MBProgressHUD.h"

#define PageSize			20


@interface CategoryListForUploadVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation CategoryListForUploadVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.arrData = [[NSMutableArray alloc] init];
    self.imgSelection = [[UIImageView alloc] initWithImage:[UIImage imageNamed:Btn_selectedUserIndication]];
    self.imgSelection.frame  = CGRectMake(5, 5, 29, 30);
    
    self.selectedSection = -1;
    self.selectedRow = -1;
    
    HUD = [[MBProgressHUD alloc] initWithView:[[UIApplication sharedApplication] keyWindow]];
	[[[UIApplication sharedApplication] keyWindow] addSubview:HUD];

    
	[self performSelector:@selector(LoadViewSetting)];
    
}
-(void)viewWillAppear:(BOOL)animated{
	self.pageCounter = 1;
    appDelegate.currentVc = self;
    [Validation removeAdviewFromSuperView];
    
    if (self.btnNext.hidden) {
		[self.view addSubview:[Validation sharedBannerView]];
		[Validation ResizeViewForAds];
	}
    
	//[Validation showLoadingIndicator];
    [HUD show:YES];
    [self getNotifOptionList];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [HUD hide:YES];
    
    appDelegate.isShouldShowReplyPopUp = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
	self.tblData.frame = CGRectMake(self.tblData.frame.origin.x, self.tblData.frame.origin.y, 320, DEVICE_HEIGHT-(self.btnNext.frame.size.height));
    
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
}

-(IBAction)btnBackClicked:(id)sender{
	//[self.navigationController popViewControllerAnimated:NO];
//    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(IBAction)btnDoneClicked:(id)sender{
//    [self.delegate setSection:[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"ID"] forRow:[[self.arrSubCat objectAtIndex:self.selectedRow] valueForKey:@"ID"]];
    [self.delegate setCategoryDetail:(NSDictionary *)[self.arrData objectAtIndex:self.selectedSection] WithRowIndex:[NSString stringWithFormat:@"%d",self.selectedRow]];
}

-(void)getNotifOptionList{
	if (self.request !=nil) {
		self.request = nil;
	}
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Name",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Descript",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue, @"PageSize",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"6",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_CAT_SUBCAT_LIST withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//	self.request.delegate = self;
//	self.request.tag = 1;
	strUrl = nil;
	
}

-(void)getSubCatList{
    
    if (self.arrSubCat== nil) {
        self.arrSubCat = [[NSMutableArray alloc] init];
    }
    
    [self.arrSubCat addObjectsFromArray:[NSArray arrayWithArray:[[self.arrData objectAtIndex:self.selectedSection] valueForKey:@"SoundSubMaster"]]];
    
    [self.tblData reloadData];
    
    if (self.arrSubCat.count > 0) {
        [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:self.selectedSection] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
}

-(NSArray*) indexPathsForSection:(int)section withNumberOfRows:(int)numberOfRows {
    NSMutableArray* indexPaths = [NSMutableArray new];
    for (int i = 0; i < numberOfRows; i++) {
        NSIndexPath* indexPath = [NSIndexPath indexPathForRow:i inSection:section];
        [indexPaths addObject:indexPath];
    }
    return indexPaths;
}

-(IBAction)btnShowSubCategoriesClicked:(id)sender{
	
	UIButton *btn = ((UIButton *)sender);
	
    
	if (self.isShowSubCategories) {
        
		self.isShowFooter = NO;
		self.isShowSubCategories = NO;
        self.btnNext.hidden = YES;
		int numOfRows = (int)[self.tblData numberOfRowsInSection:self.selectedSection];
		NSArray* indexPaths = [self indexPathsForSection:self.selectedSection withNumberOfRows:numOfRows];
		[self.tblData deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationFade];
		
        CGRect rect = [self.tblData rectForSection:(int)btn.tag];
        
        [self.tblData scrollRectToVisible:rect animated:NO];
        
        if (self.selectedSection != btn.tag) {
            [self btnShowSubCategoriesClicked:sender];
        }
        else{
            [UIView setAnimationsEnabled:NO];
            [self.tblData reloadSections:[NSIndexSet indexSetWithIndex:self.selectedSection] withRowAnimation:UITableViewRowAnimationFade];
            [UIView setAnimationsEnabled:YES];
        }
        
    //    self.selectedSection = (int)btn.tag;
        [self.view addSubview:[Validation sharedBannerView]];
        [Validation ResizeViewForAds];

	}
	else{

		self.btnNext.hidden = YES;
		self.isShowSubCategories = YES;
		self.selectedSection = (int)btn.tag;

		if (self.selectedSection == self.arrData.count-1) {
			self.isShowFooter = YES;
		}
		else{
			self.isShowFooter = NO;
		}
		if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedSection] valueForKey:IS_CAT_HAS_SUBCATS]]].length > 0) {
			if ([[[self.arrData objectAtIndex:self.selectedSection] valueForKey:IS_CAT_HAS_SUBCATS] boolValue]) {
				//call web service
				if (self.arrSubCat != nil) {
					if (self.arrSubCat.count > 0) {
						[self.arrSubCat removeAllObjects];
					}
				}
                [self.view addSubview:[Validation sharedBannerView]];
                [Validation ResizeViewForAds];
				[self getSubCatList];
			}
			else{
				//initiate notif
				self.isShowSubCategories = NO;
                self.btnNext.hidden = NO;
                [Validation removeAdviewFromSuperView];
                [self.tblData reloadData];
			}
		}
		else{
			//initiate notif
			self.isShowSubCategories = NO;
            self.btnNext.hidden = NO;
            [Validation removeAdviewFromSuperView];
            [self.tblData reloadData];
		}
	}
}
#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	
//	[HUD hide:YES];
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];;
	NSLog(@"response =%@",dicResponse);
    
    if (dicResponse != nil){
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if (request.tag == 1) {
                        //get cat list
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            [self.arrData addObjectsFromArray:arr];
                            
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            arr = nil;
                        }
                        [self.tblData reloadData];
                        response = nil;
                        [HUD hide:YES];
                    }
                    else if (request.tag == 2){
                        //send notification
                        
                       // [HUD hide:YES];
//                        NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
//                        [Validation showToastMessage:@"Sent" displayDuration:3];
                        
                        __block UIImageView *imageView;
                        UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                        imageView = [[UIImageView alloc] initWithImage:image];
                        
                        HUD.customView = imageView;
                        HUD.mode = MBProgressHUDModeText;
                        HUD.labelText = @"Sent";
                        imageView = nil;

                        [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
                    }
                    if (request.tag == 3) {
                        //get sub-cat list
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            if (arr.count >0) {
                                if (self.arrSubCat== nil) {
                                    self.arrSubCat = [[NSMutableArray alloc] init] ;
                                }
                                [self.arrSubCat addObjectsFromArray:arr];
                                
                                [self.tblData reloadData];
                                
                            }
                            
                            [self.tblData scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:self.selectedSection] atScrollPosition:UITableViewScrollPositionTop animated:YES];
                            
                            arr = nil;
                        }
                        //[self.tblData reloadData];
                        response = nil;
                        [HUD hide:YES];
                    }
                }
            }
            else{
                if (self.arrData.count == 0) {
                    [AlertHandler alertTitle:MESSAGE message:@"No Blabeey found under this category.\nPlease try another category." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
                }
            }
        }
    }
    else{
        [HUD hide:YES];
    }
	
	self.request = nil;
	dicResponse = nil;
	
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

-(void)popToNotifListScreen{
    [Validation cleanNotifcationRelatedDicData];
	[HUD hide:YES];
	[self.navigationController popViewControllerAnimated:YES];
}

#pragma mark  UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return self.arrData.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	return 130;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
	if (self.isShowFooter) {
		if (section == self.arrData.count-1) {
			return 40;
		}
	}
	return 0;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
	UIView *viewFooterContainer = [[UIView alloc] init] ;
	viewFooterContainer.backgroundColor = [UIColor clearColor];
	return viewFooterContainer;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
	UIView *viewHeaderContainer = [[UIView alloc] init];
	
	AsyncImageView *catImg = [[AsyncImageView alloc] init];
	UILabel *lblTitle = [[UILabel alloc] init];
	UILabel *lblDesc = [[UILabel alloc] init];
	UIButton *btnCategories = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImageView     *imgSubCategory = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icn_circle_plus.png"]];

	btnCategories.backgroundColor = [UIColor clearColor];
	
	lblTitle.numberOfLines = 0;
	lblDesc.numberOfLines = 0;
	lblDesc.lineBreakMode = NSLineBreakByWordWrapping;
	lblTitle.lineBreakMode = NSLineBreakByWordWrapping;
	
	catImg.layer.borderColor = [UIColor whiteColor].CGColor;
	catImg.layer.borderWidth = 2;
	
	if (section % 2==0) {
		lblDesc.textAlignment = NSTextAlignmentLeft;
		lblTitle.textAlignment = NSTextAlignmentLeft;
		
		catImg.frame = CGRectMake(5, 15, 100, 100);
		
		lblTitle.frame = CGRectMake(110, 8, tableView.frame.size.width-120, 35);
		lblDesc.frame = CGRectMake(110, 40, tableView.frame.size.width-120, 80);
        imgSubCategory.frame = CGRectMake(5, 105, 20, 20);
    }
	else{
		lblDesc.textAlignment = NSTextAlignmentRight;
		lblTitle.textAlignment = NSTextAlignmentRight;
		
		catImg.frame = CGRectMake(tableView.frame.size.width-100-5, 15, 100, 100);
		
		lblTitle.frame = CGRectMake(5, 8, tableView.frame.size.width-120, 35);
		lblDesc.frame = CGRectMake(5, 40, tableView.frame.size.width-120, 80);
        
        imgSubCategory.frame = CGRectMake(tableView.frame.size.width-25, 105, 20, 20);

	}
    
    imgSubCategory.hidden = YES;
    if ([[[self.arrData objectAtIndex:section] objectForKey:@"SoundSubMaster"] count]>0) {
        imgSubCategory.hidden = NO;
        if (self.isShowSubCategories && (self.selectedSection == section)) {
            [imgSubCategory setImage:[UIImage imageNamed:@"icn_circle_minus.png"]];
        }
        else{
            [imgSubCategory setImage:[UIImage imageNamed:@"icn_circle_plus.png"]];
        }
    }
    
	lblTitle.font = [UIFont fontWithName:Font_Montserrat_Bold size:20];
	lblDesc.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
	
	lblDesc.adjustsFontSizeToFitWidth = YES;
	lblTitle.adjustsFontSizeToFitWidth = YES;
	
	[catImg setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:CATEGORY_PHOTO_PATH]]]];
	[Validation setCorners:catImg];
	
	lblTitle.textColor = [UIColor whiteColor];
	[lblTitle setText:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:NAME]]];
	
	lblDesc.textColor = [UIColor colorWithRed:0.2 green:0.2 blue:0.2 alpha:0.8];
	lblDesc.text = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:section] valueForKey:DESCRIPTION]];
	NSString *strChar = [[[self.arrData objectAtIndex:section] valueForKey:NAME] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	viewHeaderContainer.backgroundColor = [Validation getColorForAlphabet:[NSString stringWithFormat:@"%@",strChar]];
	viewHeaderContainer.frame = CGRectMake(0, 0, tableView.frame.size.width, 130);
	
	btnCategories.frame = viewHeaderContainer.frame;
	[btnCategories addTarget:self action:@selector(btnShowSubCategoriesClicked:) forControlEvents:UIControlEventTouchUpInside];
	btnCategories.tag = section;
	
	[viewHeaderContainer addSubview:catImg];
	[viewHeaderContainer addSubview:lblTitle];
	[viewHeaderContainer addSubview:lblDesc];
	[viewHeaderContainer addSubview:btnCategories];
	[viewHeaderContainer addSubview:imgSubCategory];

    
    if (self.selectedSection == section) {
        [self.imgSelection removeFromSuperview];
        [viewHeaderContainer addSubview:self.imgSelection];
        
        if (section % 2==0) {
            [self.imgSelection setFrame:CGRectMake(tableView.frame.size.width-40, 5, 29, 30)];
        }
        else{
            [self.imgSelection setFrame:CGRectMake(5, 5, 29, 30)];
        }
    }

	lblTitle = nil;
	
	lblDesc = nil;
	
	catImg = nil;
    
    imgSubCategory = nil;

    if (section == self.arrData.count-1) {
        if (!self.isDataNull) {
            [HUD show:YES];
            self.pageCounter ++;
            [self performSelectorInBackground:@selector(getNotifOptionList) withObject:nil];
        }
    }
    
	return viewHeaderContainer;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 120;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	//return self.arrData.count;
//	if (section == self.selectedSection) {
//		if (self.isShowSubCategories) {
//			return  [self.arrSubCat count];
//		}
//	}
//	return 0;
    
    if (section == self.selectedSection) {
		if (self.isShowSubCategories) {
            NSLog(@"%f",ceil([self.arrSubCat count]/2.0));
            int rows = (int)(ceil([self.arrSubCat count]/2.0));
			return rows;
		}
	}
	return 0;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

	static NSString *CellIdentifier = @"CellIdentifier";
    
    AFTableViewCell *cell = (AFTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!cell)
    {
        cell = [[AFTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    [cell.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:CollectionViewCellIdentifier];
    
    NSString *strChar = [[[self.arrData objectAtIndex:self.selectedSection] valueForKey:NAME] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	cell.collectionView.backgroundColor = [Validation getColorForAlphabet:[NSString stringWithFormat:@"%@",strChar]];
    
    cell.collectionView.dataSource = self;
    cell.collectionView.delegate = self;
    
    return cell;

    
//	NSString *cellIdentifier = @"CellIdentifier";
    
//	NotifFileOptionCell *cell = (NotifFileOptionCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
//	
//	cell.lblSubCatTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:20];
//	[cell.lblSubCatTitle setText:[NSString stringWithFormat:@"%@",[[self.arrSubCat objectAtIndex:indexPath.row] valueForKey:NAME]]];
//	
//    cell.lblSubCatTitle.textColor = [Validation getColorForAlphabet:cell.lblSubCatTitle.text];
//	[cell.imgProfile setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[self.arrSubCat objectAtIndex:indexPath.row] valueForKey:SUBCATEGORY_LOGO_PATH]]]];
//    cell.imgProfile.layer.borderColor = [UIColor whiteColor].CGColor;
//    cell.imgProfile.layer.borderWidth = 2;
//    [Validation setCorners:cell.imgProfile];
    
    
	return cell;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(AFTableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setCollectionViewDataSourceDelegate:self index:indexPath.row forDictionary:[self.arrSubCat objectAtIndex:indexPath.row]];
    
    NSInteger index = cell.collectionView.tag;
    
    CGFloat horizontalOffset = [self.contentOffsetDictionary[[@(index) stringValue]] floatValue];
    [cell.collectionView setContentOffset:CGPointMake(horizontalOffset, 0)];
}

#pragma mark - UICollectionViewDataSource Methods

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    
    int rowIndex = (int)collectionView.tag+1;
    if (self.isShowSubCategories) {
        if ((rowIndex*2) > self.arrSubCat.count) {
            return 1;
        }
        return  2;
    }
    return 0;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"Cell";
    
    SubCat_CollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    [cell clearsContextBeforeDrawing];
    
    cell.imgProfile.image = nil;
    cell.imgProfile.imageURL = nil;

    int count = ((int)collectionView.tag+1)*2;         //by multiples of 2
    int index = 0;
    
    if (indexPath.row == 0) {
        index = count - 2;
    }
    else{
        index = count - 1;
    }
    NSLog(@"index = %d",index);
    cell.layer.borderColor = [UIColor whiteColor].CGColor;
    cell.layer.borderWidth = 0.5;

    if (index < (int)self.arrSubCat.count) {
        cell.backgroundColor = [Validation getColorForAlphabet:[[self.arrSubCat objectAtIndex:index] valueForKey:NAME]];
        cell.layer.borderColor = [UIColor whiteColor].CGColor;
        cell.layer.borderWidth = 0.5;

        [cell setCollectionViewForindex:indexPath.row forDictionary:[self.arrSubCat objectAtIndex:index]];
    }
    else{
        cell.imgProfile.hidden = YES;
        [cell.imgProfile setImage:nil];
        cell.imgFriendshipStatus.hidden = YES;
        cell.lblSubCatTitle.textColor = [UIColor whiteColor];
        [cell.lblSubCatTitle setText:@""];
        cell.lblSubCatTitle.hidden = YES;
        NSString *strChar = [[[self.arrData objectAtIndex:self.selectedSection] valueForKey:NAME] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        cell.backgroundColor = [Validation getColorForAlphabet:[NSString stringWithFormat:@"%@",strChar]];
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    int count = ((int)collectionView.tag+1)*2;         //by multiples of 2
    int index = 0;
    
    if (indexPath.row == 0) {
        index = count - 2;
    }
    else{
        index = count - 1;
    }
    NSLog(@"index = %d",index);
    
    if (index < self.arrSubCat.count) {
        self.selectedRow = (int)collectionView.tag;
        
        NSLog(@"index = %d",self.selectedRow);
        
        [self.imgSelection removeFromSuperview];
        SubCat_CollectionCell *cell = (SubCat_CollectionCell *)[collectionView cellForItemAtIndexPath:indexPath];
        [cell.contentView addSubview:self.imgSelection];
        [self.imgSelection setFrame:CGRectMake(cell.frame.size.width-40, 5, 29, 30)];
        
        [Validation removeAdviewFromSuperView];
        self.btnNext.hidden = NO;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
    self.selectedRow = (int)indexPath.row;
    
    [self.imgSelection removeFromSuperview];
    AFTableViewCell *cell = (AFTableViewCell *)[tableView cellForRowAtIndexPath:indexPath];
    [cell.contentView addSubview:self.imgSelection];
    [self.imgSelection setFrame:CGRectMake(tableView.frame.size.width-40, 5, 29, 30)];
    
    [Validation removeAdviewFromSuperView];
    self.btnNext.hidden = NO;
}

-(void)btnNotifSelected:(id)sender{
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
