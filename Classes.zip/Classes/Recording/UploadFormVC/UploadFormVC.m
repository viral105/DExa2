//
//  UploadFormVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 08/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "UploadFormVC.h"
#import "NotificationVC.h"
#import "MBProgressHUD.h"
#import "UserConversationChatVC.h"

@interface UploadFormVC () <MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation UploadFormVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	HUD.mode = MBProgressHUDModeDeterminate;
	HUD.delegate = self;
	HUD.labelText = @"Uploading";
    self.progress = [[UIProgressView alloc] initWithFrame:CGRectZero] ;
	[self.progress setProgressViewStyle: UIProgressViewStyleBar];
	
	[self.progress setFrame:CGRectMake(([[UIScreen mainScreen]bounds].size.height-160)/2,181,160,10)];
	[self.view addSubview:self.progress];

    
    [self LoadViewSetting];
    
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    appDelegate.currentVc = self;
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    appDelegate.isShouldShowReplyPopUp = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark  UIButton Delegate

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    self.scrollContainer.backgroundColor = [UIColor clearColor];
    
    [self.btnCategory.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnCategory setTitleColor:UIColorFromRGB(0X757575) forState:UIControlStateNormal];
    
    [self.btnGender.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnGender setTitleColor:UIColorFromRGB(0X757575) forState:UIControlStateNormal];

    [self.btnUploadAndSave.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.btnUploadAndSave setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];

    [self.tfName setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
	[self.tfName setTextColor:UIColorFromRGB(0X00c2d9)];
    [self.tfName setValue:UIColorFromRGB(0X757575)		forKeyPath:@"_placeholderLabel.textColor"];
    
    self.selectedGender = -1;
    self.strSelectedSectionID = nil;
    self.strSelectedRowID = nil;
    
    
    self.arrSelectedIds = [NSArray arrayWithArray:(NSArray *)[appDelegate.dic_NotificationReleatedData valueForKey:SelectedIds]];
    self.isGroupNotif = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue];
    self.isNotifSendToAll = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_NotifSendToAll] boolValue];
}

-(IBAction)btnBackClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnCategoryClicked:(id)sender{
    if (self.objCatList != nil) {
		[self.objCatList.view removeFromSuperview];
        [self.objCatList removeFromParentViewController];
        self.objCatList = nil;
	}
	
//	UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
	self.objCatList = [MainStoryboard instantiateViewControllerWithIdentifier:CATEGORY_LIST_FOR_UPLOAD_VC];
    self.objCatList.delegate  = self;
	[self.navigationController presentViewController:self.objCatList animated:YES completion:nil];
}

-(IBAction)btnGenderClicked:(id)sender{
    if (self.objPkrView != nil) {
		[self.objPkrView.view removeFromSuperview];
        [self.objPkrView removeFromParentViewController];
        self.objPkrView.delegate = nil;
        self.objPkrView = nil;
	}
	
//	UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
	self.objPkrView = [MainStoryboard instantiateViewControllerWithIdentifier:SHOW_PKR_VC];
	self.objPkrView.delegate = self;
    self.objPkrView.view.frame = self.view.frame;
    [self.objPkrView setPickerView:0];
    [self.view addSubview:self.objPkrView.view];
    [self.objPkrView didMoveToParentViewController:self];
    [self addChildViewController:self.objPkrView];
    self.objPkrView.view.alpha = 0.0f;
    
    self.objPkrView.arrData = [NSArray arrayWithObjects:GenderDoNotDisclose,GenderMale,GenderFemale, nil];
    [self.objPkrView.pkr reloadAllComponents];
    [self.objPkrView.pkr selectRow:self.selectedGender inComponent:0 animated:NO];
    
    [UIView beginAnimations:nil context:NULL];
    //[UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.5];
    self.objPkrView.view.alpha = 1.0f;
    [UIView commitAnimations];

}

-(IBAction)btnUploadAndSaveClicked:(id)sender{
    if ([self validateUploadForm]) {
         [HUD show:YES];
        [self uploadFile];
    }
}
/*
-(void)uploadFile{
//     [Validation showLoadingIndicator];
    [HUD show:YES];
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:self.strFilePath]) {
        NSLog(@"file exists");
    }
    
    NSString *strName = [DataValidation checkNullString:self.tfName.text];
    
	NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
						  [NSDictionary dictionaryWithObjectsAndKeys:self.strFilePath,KeyValue,@"SoundData",KeyName, nil],@"1",
						  [NSDictionary dictionaryWithObjectsAndKeys:strName,KeyValue,@"Name",KeyName, nil],@"2",
						  [NSDictionary dictionaryWithObjectsAndKeys:self.strSelectedSectionID,KeyValue,@"SoundMasterID",KeyName, nil],@"3",
						  [NSDictionary dictionaryWithObjectsAndKeys:(self.strSelectedRowID==nil)?@"0":self.strSelectedRowID,KeyValue,@"SoundSubMasterID",KeyName, nil],@"4",
						  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"5",
						  [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.selectedGender],KeyValue,@"Gender",KeyName, nil],@"6",
						  [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"IsPrivate",KeyName, nil],@"7",
						  nil];
	NSString *strUrl = [NSString stringWithFormat:@"%@",UPLOAD_AUDIO_FILE];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
	request.delegate = self;
	request.tag = 1;
	strUrl = nil;
}
*/
-(void)uploadFile{
    
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:self.strFilePath]) {
        NSLog(@"file exists");
    }
    
	NSString *strUrl = [NSString stringWithFormat:@"%@",UPLOAD_AUDIO_FILE];

    self.request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:strUrl]];
    
    [self.request setDelegate:self];
    
    [self.request addRequestHeader:@"userid" value:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]];
    NSString *strT1 = [Validation GetUTCDate];
    [self.request addRequestHeader:@"T1" value:strT1];
    [self.request addRequestHeader:@"T2" value:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE]];

    NSString *strName = [DataValidation checkNullString:self.tfName.text];
    [self.request setPostValue:strName forKey:@"Name"];
    
    [self.request setPostValue:self.strSelectedSectionID forKey:@"SoundMasterID"];
    [self.request setPostValue:(self.strSelectedRowID==nil)?@"0":self.strSelectedRowID forKey:@"SoundSubMasterID"];
    [self.request setPostValue:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]] forKey:@"UserID"];
    [self.request setPostValue:[NSString stringWithFormat:@"%d",self.selectedGender] forKey:@"Gender"];
    [self.request setPostValue:@"false" forKey:@"IsPrivate"];
    
    
    self.progress.progress = 0.0;
    self.progress.hidden = YES;
    [self.request setUploadProgressDelegate:self.progress];
    [self.request setShouldContinueWhenAppEntersBackground:YES];
    
    NSString *strPath = [NSString stringWithFormat:@"%@",self.strFilePath];
    
    if ([fm fileExistsAtPath:strPath]) {
        NSLog(@"file exist");
    }
    NSMutableData *data = [NSMutableData dataWithContentsOfFile:strPath];
    [self.request addData:data withFileName:@"userSound.m4a" andContentType:@"multipart/form-data" forKey:@"SoundData"];

    self.request.tag = 1;
    [self.request startAsynchronous];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(setProgressFORHUD:) userInfo:nil repeats:YES];
    
}

- (void)setProgressFORHUD:(float)progress {
    NSLog(@"actual progress = %f",self.progress.progress);
    // int prog = (round(self.progress.progress*100));
    [HUD setProgress:self.progress.progress];
    if (self.progress.progress == 1.0) {
        [self.timer invalidate];
        HUD.mode = MBProgressHUDModeIndeterminate;
        HUD.labelText = @"";
    }
}

-(void)sendNotifMsg:(NSString *)strNewYapeeyId{
	
	//[Validation showLoadingIndicator];
    [HUD show:YES];
    
    UIImage *img = [appDelegate.dic_NotificationReleatedData valueForKey:CapturedImage];
    NSString *strCaption = [NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:ImageCaption]];
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:(self.isGroupNotif)?@"":[NSString stringWithFormat:@"%@",[self.arrSelectedIds componentsJoinedByString:@"|"]],KeyValue,@"ReceiverIDs",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:self.strSelectedSectionID,KeyValue,@"Ctype",KeyName, nil],@"3",
						 [NSDictionary dictionaryWithObjectsAndKeys:(self.isGroupNotif)?[NSString stringWithFormat:@"%@",[self.arrSelectedIds componentsJoinedByString:@"|"]]:@"0",KeyValue,@"GroupIDs",KeyName, nil],@"4",
						 [NSDictionary dictionaryWithObjectsAndKeys:(self.strSelectedRowID == nil)?@"0":self.strSelectedRowID,KeyValue,@"SubCatID",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"6",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",(self.isNotifSendToAll)?@"true":@"false"],KeyValue,@"AllFriend",KeyName, nil],@"7",
                         [NSDictionary dictionaryWithObjectsAndKeys:strNewYapeeyId,KeyValue,@"NewSoundID",KeyName, nil],@"8",
                         [NSDictionary dictionaryWithObjectsAndKeys:((img!= nil)?img:@""),KeyValue,@"ImgData",KeyName, nil],@"9",
                         [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:strCaption].length > 0)?strCaption:@"",KeyValue,@"Caption",KeyName, nil],@"10",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:IsPublicImg]],KeyValue, IsPublicImg,KeyName, nil],@"11",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:RequestedKeepStatus]],KeyValue, RequestedKeepStatus, KeyName, nil],@"12",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"13",
						 nil];
	
    //only @"ID" represents notif If that we want to forward, in this screen it will be 0 as we arent forwarding any notif
    
	NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];       //SEND_TEST_MSG
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }
//	self.request.delegate = self;
//	self.request.tag = 2;
	strUrl = nil;
}


-(BOOL)validateUploadForm{
    
    if ([DataValidation checkNullString:self.tfName.text].length == 0) {
        [Validation highLightTextField:self.tfName inView:self.scrollContainer];
        [Validation showToastMessage:@"Please enter valid name." displayDuration:ERROR_MSG_DURATION];
        return FALSE;
    }
    else if (self.strSelectedSectionID == nil){
        [Validation highLightTextField:self.btnCategory inView:self.scrollContainer];
        [Validation showToastMessage:@"Please select category" displayDuration:ERROR_MSG_DURATION];
        return FALSE;
    }
    else if (self.selectedGender == -1){
        [Validation highLightTextField:self.btnGender inView:self.scrollContainer];
        [Validation showToastMessage:@"Please select gender." displayDuration:ERROR_MSG_DURATION];
        return FALSE;
    }
    return TRUE;
}
#pragma mark  ShowPickerVCDelegate

- (void)doneDTPButton{
}

- (void)doneButton:(id)callerId{
    
    self.selectedGender = (int)[self.objPkrView.pkr selectedRowInComponent:0];
    NSString *strGender = @"";
    switch (self.selectedGender) {
        case 0:
            strGender = GenderDoNotDisclose;
            break;
        case 1:
            strGender = GenderMale;
            break;
        case 2:
            strGender = GenderFemale;
            break;
        default:
            break;
    }
    [self.btnGender setTitle:strGender forState:UIControlStateNormal];
    [self.btnGender setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];
    strGender = nil;
    
    [self hidePicker];
}

-(void)CancelButton{
    [self hidePicker];
}

-(void)hidePicker{
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    self.objPkrView.view.alpha = 0.0f;
    [UIView commitAnimations];
    
    [self performSelector:@selector(removePickerAfterAnimation) withObject:nil afterDelay:0.8];
}

-(void)removePickerAfterAnimation{
    self.objPkrView.delegate = nil;
    [self.objPkrView.view removeFromSuperview];
    [self.objPkrView removeFromParentViewController];
    self.objPkrView = nil;
    
}
#pragma mark CategoryListForUploadVC Delegate

- (void)setCategoryDetail:(NSDictionary *)dic WithRowIndex:(NSString *)strIndex{

    self.dicSelectedCategory = [NSDictionary dictionaryWithDictionary:dic];
    [self.objCatList dismissViewControllerAnimated:YES completion:nil];
    
    self.strSelectedSectionID = [NSString stringWithFormat:@"%@",[dic valueForKey:@"ID"]];
    if ([[dic valueForKey:IS_CAT_HAS_SUBCATS] boolValue]) {
            self.strSelectedRowID = [[[dic valueForKey:@"SoundSubMaster"] objectAtIndex:[strIndex integerValue]] valueForKey:@"ID"];
    }
    
    [self.btnCategory setTitle:[self.dicSelectedCategory valueForKey:NAME] forState:UIControlStateNormal];
    [self.btnCategory setTitleColor:UIColorFromRGB(0X00c2d9) forState:UIControlStateNormal];

}


#pragma mark  UITextfield Delegate

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return TRUE;
}

#pragma mark    WEBSERVICE RESPONSE

- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	
    
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];;
	
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (request.tag == 1) {
                NSLog(@"upload Response");
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            /*
                             {
                             Response =     (
                             {
                             CreateBy = 20190;
                             CreateDate = "2014-10-07T06:04:30.92";
                             DeleteBy = "<null>";
                             DeleteDate = "<null>";
                             FilePath = "http://upload.wwhhaazzuupp.com/UserSound/0_0_EI8V92ME4730748_20190.mp3";
                             Gender = 0;
                             ID = 10257;
                             IsActive = 0;
                             IsDelete = 0;
                             IsPrivate = 1;
                             Name = "";
                             SoundMasterID = 0;
                             SoundSubMasterID = 0;
                             SubType = "<null>";
                             Type = "<null>";
                             UpdateBy = "<null>";
                             UpdateDate = "<null>";
                             UserID = "<null>";
                             }
                             );
                             Status = 1;
                             UserStatus =     {
                             IsActive = 1;
                             IsDelete = 0;
                             Msg = success;
                             status = 1;
                             };
                             }
                             
                             */
                            
                            NSString *strNotifId = [NSString stringWithFormat:@"%@",[response valueForKey:NEW_YAPEEY_ID]];
                            strNotifId = [strNotifId stringByTrimmingCharactersInSet: [[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
                            
                            [self sendNotifMsg:strNotifId];
                        }
                        response = nil;
                    }
                }
            }
            else if (request.tag == 2){
                //send notification
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        NSFileManager *fm = [NSFileManager defaultManager];
                        if ([fm fileExistsAtPath:self.strFilePath]) {
                            [fm removeItemAtPath:self.strFilePath error:nil];
                        }
                        NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
                        __block UIImageView *imageView;
                        UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                        imageView = [[UIImageView alloc] initWithImage:image];
                        
                        HUD.customView = imageView;
                        HUD.mode = MBProgressHUDModeText;
                        HUD.labelText = @"Sent";
                        imageView = nil;
                        [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
                    }
                    else{

                        if ([[dicResponse objectForKey:RESPONSE] isKindOfClass:[NSArray class]]) {
                            
                            //[Validation showToastMessage:[[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] displayDuration:ERROR_MSG_DURATION];
                            HUD.mode = MBProgressHUDModeText;
                            HUD.delegate = self;
                            HUD.detailsLabelFont = [UIFont boldSystemFontOfSize:16];
                            HUD.detailsLabelText = [[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] ;
                            [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:4];
                        }
                        else{
                            [HUD hide:YES];
                            
                        }
                        
                    }
                }

//                [HUD hide:YES];
//                NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);
//                [Validation showToastMessage:@"Sent" displayDuration:3];
//                [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
            }
        }
    }
    else{
        [HUD hide:YES];
    }
	
}

- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

-(void)popToNotifListScreen{
    
	[HUD hide:YES];
    [Validation cleanNotifcationRelatedDicData];
    
    NSArray *arr = [self.navigationController viewControllers];
    BOOL isGotPopViewController = FALSE;
    
    for (UIViewController *v in arr) {
        if ([v isKindOfClass:[UserConversationChatVC class]]) {
            isGotPopViewController = TRUE;
            [self.navigationController popToViewController:v animated:YES];
        }
    }

    
    if (!isGotPopViewController) {

        [self removeViewControllersFromStack];
        
        if (appDelegate.selectedMenuIndex>0) {
            appDelegate.selectedMenuIndex = 0;
  //          UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
            
            [UIView transitionWithView:self.navigationController.view
                              duration:0.5
                               options:UIViewAnimationOptionTransitionCrossDissolve
                            animations:^{
                                [self.navigationController pushViewController:ivc animated:NO];
                            }
                            completion:nil];
            
        }
        else{
 //           UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            NotificationVC *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:NOTIFICATION_VC];
            [self.navigationController pushViewController:ivc animated:YES];
        }
    }
}

-(void)removeViewControllersFromStack{
   // NSArray *arrVC = self.navigationController.viewControllers;
    for (id vc in self.navigationController.viewControllers){
		if ([vc isKindOfClass:[FavoritesVC class]]) {
			[self removeFromNavigationController:vc animated:NO];
		}
        else if ([vc isKindOfClass:[SearchFriendVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[OtherFriendNotifListVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[SettingsVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[NotifOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[CategoryListForUploadVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[GroupListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[UserListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[RecordingOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
	}
    
}

-(void)removeFromNavigationController:(UIViewController *)controller animated:(BOOL)animated {
    
    NSMutableArray *allViewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];;
    [allViewControllers removeObjectIdenticalTo:controller];
    self.navigationController.viewControllers = allViewControllers;
	
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
