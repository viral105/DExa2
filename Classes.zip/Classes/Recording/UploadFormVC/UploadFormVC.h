//
//  UploadFormVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 08/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShowPickerVC.h"
#import "CategoryListForUploadVC.h"
#import "ASIFormDataRequest.h"
#import "SWRevealViewController.h"
@interface UploadFormVC : UIViewController <UITextFieldDelegate,ShowPickerVCDelegate,CategoryListForUploadVCDelegate>

@property (nonatomic, strong) IBOutlet UIScrollView     *scrollContainer;
@property (nonatomic, strong) IBOutlet UITextField      *tfName;
@property (nonatomic, strong) IBOutlet UIButton         *btnCategory;
@property (nonatomic, strong) IBOutlet UIButton         *btnGender;
@property (nonatomic, strong) IBOutlet UIButton         *btnUploadAndSave;
@property (nonatomic, retain) IBOutlet UILabel          *lblTitle;

@property (nonatomic, strong) ASIFormDataRequest		*request;

@property (nonatomic, readwrite) int                    selectedGender;
@property (nonatomic, strong) NSString                  *strSelectedSectionID;
@property (nonatomic, strong) NSString                  *strSelectedRowID;
@property (nonatomic, strong) ShowPickerVC              *objPkrView;
@property (nonatomic, strong) CategoryListForUploadVC   *objCatList;
@property (nonatomic, strong) NSDictionary              *dicSelectedCategory;
@property (nonatomic, strong) NSString                  *strFilePath;


@property (nonatomic, strong) NSArray				*arrSelectedIds;
@property (nonatomic, readwrite) BOOL				isGroupNotif;
@property (nonatomic, readwrite) BOOL				isNotifSendToAll;

@property (nonatomic, strong) NSTimer               *timer;
@property (nonatomic, strong) UIProgressView			*progress;

@end
