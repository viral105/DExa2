//
//  ProfileDescriptionVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 1/15/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileDescriptionVC : UIViewController<UITableViewDataSource,UITableViewDelegate,UICollectionViewDataSource,UICollectionViewDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, strong) NSMutableArray				*arrSubCat;

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) ASIFormDataRequest			*request;
@property (nonatomic, strong) IBOutlet  UIButton            *btnSave;
@property (nonatomic, strong) IBOutlet  UIButton            *btnSkip;
//@property (nonatomic, strong) UIActivityIndicatorView		*activityLoading;

@property (nonatomic, strong) NSString                      *strShowSkip;

@property (nonatomic, readwrite) BOOL						isShowSubCategories;
@property (nonatomic, readwrite) BOOL						isShowFooter;
@property (nonatomic, readwrite) int						selectedSection;
@property (nonatomic, readwrite) int						selectedRow;
@property (nonatomic, readwrite) int                        pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;

@property (nonatomic, strong) NSMutableDictionary           *contentOffsetDictionary;
@end
