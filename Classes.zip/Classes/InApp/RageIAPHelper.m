//
//  RageIAPHelper.m
//  In App Rage
//
//  Created by Ray Wenderlich on 9/5/12.
//  Copyright (c) 2012 Razeware LLC. All rights reserved.
//

#import "RageIAPHelper.h"

@implementation RageIAPHelper

+ (RageIAPHelper *)sharedInstance {
    static dispatch_once_t once;
    static RageIAPHelper * sharedInstance;
    dispatch_once(&once, ^{
//        NSSet * productIdentifiers = [NSSet setWithObject: @"product1nonconsumable"];
		
		NSSet * productIdentifiers = [NSSet setWithObjects:
									  Product_0_99,
									  Product_1_99,
									  Product_2_99,
									  Product_3_99,
									  Product_4_99,
									  nil];
		
		/*
		 NSSet * productIdentifiers = [NSSet setWithObjects:
		 @"soundtrackProduct1",@"com.songs.product1",@"com.PaidSongs.Product2",
		 nil];

		 
		 */
        sharedInstance = [[self alloc] initWithProductIdentifiers:productIdentifiers];
    });
    return sharedInstance;
}

@end
