//
//  GetGenderBDatePrivacyVC.h
//  WWHHAAZZAAPP
//
//  Created by Nivid on 18/03/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GetGenderBDatePrivacyVC : UIViewController <ShowPickerVCDelegate>


@property (nonatomic, strong) IBOutlet UIButton			*btnDOB;
@property (nonatomic, strong) IBOutlet UIButton			*btnGender;
@property (nonatomic, strong) IBOutlet UIButton			*btnProfilePrivacy;
@property (nonatomic, strong) IBOutlet UIButton			*btnNextSignUp;
@property (nonatomic, strong) IBOutlet UILabel			*lblTitle;
@property (nonatomic, strong) ASIHTTPRequest			*request;
@property (nonatomic, readwrite) int                    selectedGender;
@property (nonatomic, readwrite) int                    selectedBtnForDate;
@property (nonatomic, readwrite) int                    selectedProfile;        //0=public, 1= private
@property (nonatomic, strong) NSString                  *strDOB;
@property (nonatomic, strong) ShowPickerVC              *objPkrView;

@end
