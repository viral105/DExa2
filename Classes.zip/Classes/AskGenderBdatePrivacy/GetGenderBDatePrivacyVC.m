//
//  GetGenderBDatePrivacyVC.m
//  WWHHAAZZAAPP
//
//  Created by Nivid on 18/03/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "GetGenderBDatePrivacyVC.h"
#import "IntroductionVC.h"
#import "MBProgressHUD.h"
#import "UserInterestList.h"
#import "SinUpGetUserContactNumberVC.h"

@interface GetGenderBDatePrivacyVC () <MBProgressHUDDelegate> {
    MBProgressHUD *HUD;
}

@end

@implementation GetGenderBDatePrivacyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
    [super viewWillAppear:animated];
    [self performSelector:@selector(LoadViewSettings)];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}

-(void)LoadViewSettings{
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:Blue_BG]];
    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:30];
    [self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    [self.btnNextSignUp.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [self.btnNextSignUp setTitleColor:UIColorFromRGB(0X04c6fb) forState:UIControlStateNormal];
    
    
    [self.btnDOB.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [self.btnDOB setTitleColor:UIColorFromRGB(0X585f66) forState:UIControlStateNormal];
    
    [self.btnGender.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [self.btnGender setTitleColor:UIColorFromRGB(0X585f66) forState:UIControlStateNormal];
    
    [self.btnProfilePrivacy.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:22]];
    [self.btnProfilePrivacy setTitleColor:UIColorFromRGB(0X585f66) forState:UIControlStateNormal];
    
    self.selectedGender = -1;
    self.selectedProfile = 0;
    [self.btnDOB setTitle:Select_DOB forState:UIControlStateNormal];
    [self.btnGender setTitle:@"Gender" forState:UIControlStateNormal];
    [self.btnProfilePrivacy setTitle:Profile_Public forState:UIControlStateNormal];
    
//    self.btnNextSignUp.alpha = 0;
//    self.btnNextSignUp.frame = CGRectMake(self.btnNextSignUp.frame.origin.x, DEVICE_HEIGHT+self.btnNextSignUp.frame.size.height, self.btnNextSignUp.frame.size.width, self.btnNextSignUp.frame.size.height);
}

-(IBAction)btnDOBClicked:(id)sender{
    
    if (self.objPkrView != nil) {
        [self.objPkrView.view removeFromSuperview];
        [self.objPkrView removeFromParentViewController];
        self.objPkrView.delegate = nil;
        self.objPkrView = nil;
    }
    
    self.objPkrView = [MainStoryboard instantiateViewControllerWithIdentifier:SHOW_PKR_VC];
    self.objPkrView.delegate = self;
    self.objPkrView.view.frame = self.view.frame;
    [self.objPkrView setPickerView:1];
    [self.view addSubview:self.objPkrView.view];
    [self.objPkrView didMoveToParentViewController:self];
    [self addChildViewController:self.objPkrView];
    self.objPkrView.view.alpha = 0.0f;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    self.objPkrView.view.alpha = 1.0f;
    [UIView commitAnimations];
}

-(IBAction)btnGenderClicked:(id)sender{
    
    if (self.objPkrView != nil) {
        [self.objPkrView.view removeFromSuperview];
        [self.objPkrView removeFromParentViewController];
        self.objPkrView.delegate = nil;
        self.objPkrView = nil;
    }
    
    self.objPkrView = [MainStoryboard instantiateViewControllerWithIdentifier:SHOW_PKR_VC];
    self.objPkrView.delegate = self;
    self.objPkrView.view.frame = self.view.frame;
    [self.objPkrView setPickerView:0];
    [self.view addSubview:self.objPkrView.view];
    [self.objPkrView didMoveToParentViewController:self];
    [self addChildViewController:self.objPkrView];
    self.objPkrView.view.alpha = 0.0f;
    
    self.objPkrView.arrData = [NSArray arrayWithObjects:GenderDoNotDisclose,GenderMale,GenderFemale, nil];
    [self.objPkrView.pkr reloadAllComponents];
    [self.objPkrView.pkr selectRow:0 inComponent:0 animated:NO];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    self.objPkrView.view.alpha = 1.0f;
    [UIView commitAnimations];
}

-(IBAction)btnPrivacyClicked:(id)sender{
    
    if (self.objPkrView != nil) {
        [self.objPkrView.view removeFromSuperview];
        [self.objPkrView removeFromParentViewController];
        self.objPkrView.delegate = nil;
        self.objPkrView = nil;
    }
    
    self.objPkrView = [MainStoryboard instantiateViewControllerWithIdentifier:SHOW_PKR_VC];
    self.objPkrView.delegate = self;
    self.objPkrView.view.frame = self.view.frame;
    [self.objPkrView setPickerView:3];
    [self.view addSubview:self.objPkrView.view];
    [self.objPkrView didMoveToParentViewController:self];
    [self addChildViewController:self.objPkrView];
    self.objPkrView.view.alpha = 0.0f;
    
    self.objPkrView.arrData = [NSArray arrayWithObjects:Profile_Public,Profile_Private, nil];
    [self.objPkrView.pkr reloadAllComponents];
    [self.objPkrView.pkr selectRow:self.selectedProfile inComponent:0 animated:NO];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    self.objPkrView.view.alpha = 1.0f;
    [UIView commitAnimations];
}

- (void)doneButton:(id)callerId{
    
    if ([callerId intValue] == 0) {
        self.selectedGender = (int)[self.objPkrView.pkr selectedRowInComponent:0];
        NSString *strGender = @"";
        switch (self.selectedGender) {
            case 0:
                strGender = GenderDoNotDisclose;
                break;
            case 1:
                strGender = GenderMale;
                break;
            case 2:
                strGender = GenderFemale;
                break;
            default:
                break;
        }
        [self.btnGender setTitle:strGender forState:UIControlStateNormal];
        
        strGender = nil;
    }
    else if ([callerId intValue] == 3){
        //profile privacy
        self.selectedProfile = (int)[self.objPkrView.pkr selectedRowInComponent:0];
        
        NSString *strProfile = @"";
        switch (self.selectedProfile) {
            case 0:
                strProfile = Profile_Public;
                break;
            case 1:
                strProfile = Profile_Private;
                break;
                
            default:
                break;
        }
        [self.btnProfilePrivacy setTitle:strProfile forState:UIControlStateNormal];
        
        strProfile = nil;
        
    }
    
    [self hidePicker];
}


-(void)CancelButton{
    [self hidePicker];
}

- (void)doneDTPButton{
    NSDate *dt = [self.objPkrView.pkr date];
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init] ;
    [df setDateFormat:@"MM/dd/yyyy"];
    NSString *strDate = [df stringFromDate:dt];
    
    NSDateFormatter *df1 = [[NSDateFormatter alloc] init] ;
    [df1 setDateFormat:@"MMM dd, yyyy"];
    
    //birthdate
    [self.btnDOB setTitle:[df1 stringFromDate:dt] forState:UIControlStateNormal];
    self.strDOB = strDate;
    //----------------
    int ageDiff = [self getYearDifference];
    if (ageDiff<=18) {
        self.selectedProfile = 1;
        [self.btnProfilePrivacy setTitle:Profile_Private forState:UIControlStateNormal];
    }
    else{
        [self.btnProfilePrivacy setTitle:Profile_Public forState:UIControlStateNormal];
    }
    
    [self hidePicker];
    NSLog(@"DOB ====>> %@",self.strDOB);
}

-(int)getYearDifference{
    NSDateFormatter *df2 = [[NSDateFormatter alloc] init];
    [df2 setDateFormat:@"YYYY"];
    NSDate *today = [[NSDate alloc] init];
    
    NSDateFormatter *f = [[NSDateFormatter alloc] init];
    [f setDateFormat:@"MM/dd/yyyy"];
    NSDate *selectedDT = [NSDate date];
    selectedDT = [f dateFromString:self.strDOB];
    
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [calendar components:NSYearCalendarUnit|NSMonthCalendarUnit|NSDayCalendarUnit
                                               fromDate:selectedDT
                                                 toDate:today
                                                options:0];
    
    NSLog(@"Difference in date components: %li/%li/%li", (long)components.day, (long)components.month, (long)components.year);
    
    return (int)components.year;
}
-(void)hidePicker{
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    self.objPkrView.view.alpha = 0.0f;
    [UIView commitAnimations];
    
    [self performSelector:@selector(removePickerViewFromParentView) withObject:nil afterDelay:0.8];
}

-(void)removePickerViewFromParentView{
    self.objPkrView.delegate = nil;
    [self.objPkrView.view removeFromSuperview];
    [self.objPkrView removeFromParentViewController];
    self.objPkrView = nil;
    
}

-(BOOL)checkForValidation{
/*    if (self.strDOB == nil || self.strDOB.length == 0) {
        [HUD hide:YES];
        [Validation showToastMessage:@"Please select valid Birthday." displayDuration:ERROR_MSG_DURATION];
        [Validation highLightTextField:self.btnDOB inView:self.view];
        return FALSE;
    }
    else if (self.selectedGender == -1){
        [HUD hide:YES];
        [Validation showToastMessage:@"Please select valid Gender." displayDuration:ERROR_MSG_DURATION];
        [Validation highLightTextField:self.btnGender inView:self.view];
        return FALSE;
    }
    else{
        return TRUE;
    }
*/    return TRUE;
}

-(IBAction)btnNextClicked:(id)sender{
    
   
    if (self.request !=nil) {
        self.request = nil;
    }
    if ([self checkForValidation]) {
        NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[[NSUserDefaults standardUserDefaults]valueForKey:DIC_SIGNUP]];
        
        [HUD show:YES];
        //with FB
/*
        NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_DISPLAYNAME]],KeyValue,@"Name",KeyName, nil],@"1",
                             [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Phone",KeyName, nil],@"2",
                             [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_EMAIL]],KeyValue,@"Email",KeyName, nil],@"3",
                             [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_USERNAME]],KeyValue,@"UserName",KeyName, nil],@"4",
                             [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_PASSWORD]],KeyValue, @"Pwd",KeyName, nil],@"5",
                             [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]],KeyValue,@"FacebookID",KeyName, nil],@"6",
                             [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"PhotoPath",KeyName, nil],@"7",
                             [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:self.strDOB].length>0)?self.strDOB:@"",KeyValue,@"DateOfBirth",KeyName, nil],@"8",
                             [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]],KeyValue,@"RegID",KeyName, nil],@"9",
                             [NSDictionary dictionaryWithObjectsAndKeys:APPLICATION_OS,KeyValue,@"OS",KeyName, nil],@"10",
                             [NSDictionary dictionaryWithObjectsAndKeys:(self.selectedGender == -1)?@"0":[NSString stringWithFormat:@"%d",self.selectedGender],KeyValue,@"Gender",KeyName, nil],@"11",
                             [NSDictionary dictionaryWithObjectsAndKeys:(self.selectedProfile==0)?@"false":@"true",KeyValue,@"IsPrivate",KeyName, nil],@"12",
                              [NSDictionary dictionaryWithObjectsAndKeys:[dic valueForKey:SIGNUP_USER_PHOTO],KeyValue,@"ImgData",KeyName, nil],@"13",
                             nil];
 */
        NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                     [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_DISPLAYNAME]],KeyValue,@"Name",KeyName, nil],@"1",
                                     [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Phone",KeyName, nil],@"2",
                                     [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_EMAIL]],KeyValue,@"Email",KeyName, nil],@"3",
                                     [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_USERNAME]],KeyValue,@"UserName",KeyName, nil],@"4",
                                     [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_PASSWORD]],KeyValue, @"Pwd",KeyName, nil],@"5",
                                     [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:FB_ID]]],KeyValue,@"FacebookID",KeyName, nil],@"6",
                                     [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"PhotoPath",KeyName, nil],@"7",
                                     [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]],KeyValue,@"RegID",KeyName, nil],@"8",
                                     [NSDictionary dictionaryWithObjectsAndKeys:APPLICATION_OS,KeyValue,@"OS",KeyName, nil],@"9",
                                     [NSDictionary dictionaryWithObjectsAndKeys:(self.selectedProfile==0)?@"false":@"true",KeyValue,@"IsPrivate",KeyName, nil],@"10",
                                     [NSDictionary dictionaryWithObjectsAndKeys:[dic valueForKey:SIGNUP_USER_PHOTO],KeyValue,@"ImgData",KeyName, nil],@"11",
                                     [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_MAIDENNAME]],KeyValue,@"MaidenName",KeyName, nil],@"12",
                                     nil];
        
        if (self.selectedGender == -1) {
            //gender not set, so dont pass
            if ([DataValidation checkNullString:self.strDOB].length==0) {
                //date not set so dont pass
            }
            else{
                //date set so pass
                [dic1 setObject:[NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:self.strDOB].length>0)?self.strDOB:@"",KeyValue,@"DateOfBirth",KeyName, nil] forKey:@"12"];
            }
        }
        else{
            //gender set so pass it
            [dic1 setObject:[NSDictionary dictionaryWithObjectsAndKeys:(self.selectedGender == -1)?@"0":[NSString stringWithFormat:@"%d",self.selectedGender],KeyValue,@"Gender",KeyName, nil] forKey:@"12"];
            if ([DataValidation checkNullString:self.strDOB].length==0) {
                //date not set so dont pass
            }
            else{
                //date set so pass
                [dic1 setObject:[NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:self.strDOB].length>0)?self.strDOB:@"",KeyValue,@"DateOfBirth",KeyName, nil] forKey:@"13"];
            }
        }
        
      /*
       //without FBID
       
        NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                              [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_DISPLAYNAME]],KeyValue,@"Name",KeyName, nil],@"1",
                              [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"Phone",KeyName, nil],@"2",
                              [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_EMAIL]],KeyValue,@"Email",KeyName, nil],@"3",
                              [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_USERNAME]],KeyValue,@"UserName",KeyName, nil],@"4",
                              [NSDictionary dictionaryWithObjectsAndKeys:[DataValidation checkNullString:[dic valueForKey:SIGNUP_PASSWORD]],KeyValue, @"Pwd",KeyName, nil],@"5",
                              [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"PhotoPath",KeyName, nil],@"6",
                              [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:self.strDOB].length>0)?self.strDOB:@"",KeyValue,@"DateOfBirth",KeyName, nil],@"7",
                              [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]],KeyValue,@"RegID",KeyName, nil],@"8",
                              [NSDictionary dictionaryWithObjectsAndKeys:APPLICATION_OS,KeyValue,@"OS",KeyName, nil],@"9",
                              [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.selectedGender],KeyValue,@"Gender",KeyName, nil],@"10",
                              [NSDictionary dictionaryWithObjectsAndKeys:(self.selectedProfile==0)?@"false":@"true",KeyValue,@"IsPrivate",KeyName, nil],@"11",
                              [NSDictionary dictionaryWithObjectsAndKeys:[dic valueForKey:SIGNUP_USER_PHOTO],KeyValue,@"ImgData",KeyName, nil],@"12",
                              nil];
*/
        NSLog(@"REGISTRATION for user dic %@",dic1);
        
        NSString *strUrl = [WebServiceContainer getServiceURL:REGISTRATION withParameters:nil];
        self.request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:FALSE];
        if (self.request == nil) {
            [HUD hide:YES];
        }
        else{
            [self.request setDelegate:self];
            [self.request setTag:4];
        }
//        self.request.delegate = self;
//        self.request.tag = 4;
        strUrl = nil;
        dic = nil;

    }
 //   [AlertHandler alertTitle:SUCCESS message:@"Sign up done" delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
//    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[[NSUserDefaults standardUserDefaults] valueForKey:DIC_SIGNUP]];
//    [dic setValue:self.tfDisplyName.text forKey:SIGNUP_DISPLAYNAME];
//    [dic setValue:self.img_UserProfileImg.image forKey:SIGNUP_USER_PHOTO];
//    [[NSUserDefaults standardUserDefaults] setValue:dic forKey:DIC_SIGNUP];
//    [[NSUserDefaults standardUserDefaults] synchronize];
//    
}

- (void)requestFinished:(ASIHTTPRequest *)request{
    NSError *error = nil;
    
    [HUD hide:YES];
    NSLog(@"response =%@",[request responseString]);
    NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[self.request responseData]
                                                                 options:0
                                                                   error:&error];;
    
    
    NSLog(@"dictionary = %@",dicResponse);
    
    [Validation resetTextFieldBorderColor];
    
    if ([dicResponse objectForKey:RESPONSE] != nil) {
        if ([[dicResponse valueForKey:STATUS] intValue] == 1){
            if (request.tag == 4){
                
                [HUD hide:YES];
//                [Validation showToastMessage:[NSString stringWithFormat:@"Welcome\n%@",[DataValidation checkNullString:self.tfUserName.text]] displayDuration:SUCCESS_MSG_DURATION];
            //    [Validation showToastMessage:@"Welcome" displayDuration:SUCCESS_MSG_DURATION];

                id response = [dicResponse objectForKey:RESPONSE];
                NSMutableDictionary *dic = nil;
                
                if ([response isKindOfClass:[NSDictionary class]]) {
                    if (((NSDictionary *)response).count>0) {
                        //[Validation setAllKeyValueFromData:response];
                        dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)response];
                    }
                }
                else if ([response isKindOfClass:[NSArray class]]){
                    if (((NSArray *)response).count > 0) {
                        //[Validation setAllKeyValueFromData:[response objectAtIndex:0]];
                        dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[response objectAtIndex:0]];
                    }
                }
                NSLog(@"dic after sign up user %@",dic);
                [dic setValue:[[[NSUserDefaults standardUserDefaults]valueForKey:DIC_SIGNUP] valueForKey:SIGNUP_PASSWORD] forKey:LOGIN_USER_KEY];
                [Validation setAllKeyValueFromData:dic];
                [Validation setMatTrackingForRegisterAndLogin:dic index:0];
                [Validation CancelOnGoingRequests:self.request];
                [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:IS_FROM_SIGN_UP];
                [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:IS_OVERLAY_VIEWED_CONVOS];
                [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:IS_OVERLAY_VIEWED_FRIENDLIST];
                [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:IS_OVERLAY_VIEWED_REMINDER];
                [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:IS_OVERLAY_VIEWED_SENDBLAB];
                [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:IS_OVERLAY_VIEWED_SETTING];
                [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:IS_OVERLAY_VIEWED_FRIEND_REMINDER];
                [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:IS_MESSAGE_SHOW_FOR_AUDIO_SCREEN];
                [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:IS_MESSAGE_SHOW_FOR_VIDEO_SCREEN];
                [[NSUserDefaults standardUserDefaults] setValue:nil forKey:DIC_SIGNUP];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
               // [self performSegueWithIdentifier:INTRODUCTION_VC sender:nil];
                UserInterestList *obj = [MainStoryboard instantiateViewControllerWithIdentifier:USER_INTEREST_VC];
                obj.isFromRegister = YES;
                obj.strShowSkip = @"1";
                [self.navigationController pushViewController:obj animated:YES];
/*
                SinUpGetUserContactNumberVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:SIGNUP_GET_CONTACTNUMBER_VC];
                [self.navigationController pushViewController:obj animated:NO];
*/
                self.request = nil;
                response = nil;
                dic = nil;
            }
        }
        else{
            [HUD hide:YES];
            [Validation showToastMessage:@"Request failure.\nPlease try again saving." displayDuration:ERROR_MSG_DURATION];
        }
    }
    else{
        [HUD hide:YES];
        [Validation showToastMessage:@"Request failure.\nPlease try again saving." displayDuration:ERROR_MSG_DURATION];
    }
    dicResponse = nil;
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
