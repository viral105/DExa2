//
//  KeepRequestListCell.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 10/12/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeepRequestListCell : UITableViewCell

@property (nonatomic, strong) IBOutlet AsyncImageView       *imgUser;
@property (nonatomic, strong) IBOutlet AsyncImageView       *imgBlabPicture;
@property (nonatomic, strong) IBOutlet UILabel              *lblText;
@property (nonatomic, strong) IBOutlet UIButton             *btnAccept;
@property (nonatomic, strong) IBOutlet UIButton             *btnReject;
@property (nonatomic, readwrite) NSRange                    range;


-(void)setControlValuesInCellWithData:(NSDictionary *)dic;
@end
