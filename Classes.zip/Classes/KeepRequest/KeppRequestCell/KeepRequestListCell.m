//
//  KeepRequestListCell.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 10/12/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "KeepRequestListCell.h"

@implementation KeepRequestListCell

-(void)setControlValuesInCellWithData:(NSDictionary *)dic{
    [self.imgUser setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:USER_PHOTO_PATH]]]];
    if ([DataValidation checkNullString:[dic valueForKey:ImagePath]].length==0) {
        self.imgBlabPicture.hidden = YES;
    }
    else{
        self.imgBlabPicture.hidden = NO;
        [self.imgBlabPicture setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[dic valueForKey:ImagePath]]]];
    }
    

    [Validation setCorners:self.imgUser.image];
    
    self.lblText.textColor = UIColorFromRGB(0X757575);
    self.lblText.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    
    
    NSString *text = [NSString stringWithFormat:@"%@ wants to keep your Blab!!",[dic valueForKey:NAME]];
    
    NSMutableAttributedString *hogan = [[NSMutableAttributedString alloc] initWithString:text];
    NSString *strName = [NSString stringWithFormat:@"%@",[dic valueForKey:NAME]];
    self.range = [text rangeOfString:strName];
    
    
    [hogan addAttribute:NSForegroundColorAttributeName
                  value:TWITTER_BLUE_COLOR
                  range:self.range];
    [hogan addAttribute:NSFontAttributeName
                  value:[UIFont boldSystemFontOfSize:20]
                  range:self.range];
    self.lblText.attributedText = hogan;
    self.lblText.numberOfLines = 0;
    
    [self.btnAccept setTitleColor:UIColorFromRGB(0X424242) forState:UIControlStateNormal];
    [self.btnReject setTitleColor:UIColorFromRGB(0X424242) forState:UIControlStateNormal];
    
    [self.btnAccept.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:10]];
    [self.btnReject.titleLabel setFont:[UIFont fontWithName:Font_Montserrat_Regular size:10]];

    
}
@end
