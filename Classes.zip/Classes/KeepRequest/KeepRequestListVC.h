//
//  KeepRequestListVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 10/12/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeepRequestListVC : UIViewController <UITableViewDataSource, UITableViewDelegate,AFNetworkingDataTransactionDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) IBOutlet  UIButton            *btnMenu;

@property (nonatomic, retain) IBOutlet UILabel				*lbl_NoDataAvailable;
@property (nonatomic, readwrite) int						selectedIndex;

@property (nonatomic, strong) UIRefreshControl				*refresh;

@property (nonatomic, strong) AFNetworkingDataTransaction	*request;
@end
