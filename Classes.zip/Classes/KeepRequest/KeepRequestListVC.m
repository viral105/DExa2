//
//  KeepRequestListVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 10/12/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "KeepRequestListVC.h"
#import "KeepRequestListCell.h"
#import "MBProgressHUD.h"

#define PageSize			10


@interface KeepRequestListVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation KeepRequestListVC

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	
    
	self.arrData = [[NSMutableArray alloc] init];
	appDelegate.currentVc = self;
	[self performSelector:@selector(LoadViewSetting)];
	self.pageCounter = 1;
	
	//[self.tblData registerNib:[UINib nibWithNibName:@"UserCell" bundle:nil] forCellReuseIdentifier:@"CellKeep"];
    
	
	//pull to refresh
	self.refresh = [[UIRefreshControl alloc] init];
	
	self.refresh.attributedTitle = [[NSAttributedString alloc] initWithString:@""];
	self.refresh.tintColor = TWITTER_BLUE_COLOR;
	[self.refresh setAutoresizingMask:(UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleLeftMargin)];
	
	[[self.refresh.subviews objectAtIndex:0] setFrame:CGRectMake(-5, 10, 20, 30)];
	[self.refresh addTarget:self action:@selector(loadNewData) forControlEvents:UIControlEventValueChanged];
	[self.tblData addSubview:self.refresh];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
	
}

-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
    
    NSLog(@"ViewControllers = %@",self.navigationController.viewControllers);
    
	[self.lbl_NoDataAvailable setHidden:YES];
	self.pageCounter = 1;
	self.isDataNull = NO;
	appDelegate.currentVc = self;
    
    //set menu image
    [self.btnMenu removeTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
	[self.btnMenu addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
	
	[Validation removeAdviewFromSuperView];
	[self.view addSubview:[Validation sharedBannerView]];
	[Validation ResizeViewForAds];
	[self.arrData removeAllObjects];
	[self performSelectorInBackground:@selector(getRequestList) withObject:nil];
    
    // [appDelegate checkForNotification];
}
-(void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
	[Validation increaseTableSize];
    appDelegate.isShouldShowReplyPopUp = NO;
}

#pragma mark

-(void)getRequestList{
    
	if (self.request !=nil) {
		self.request = nil;
	}
	//[Validation showLoadingIndicator];
    [HUD show:YES];
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_KEEP_REQUEST_LIST withParameters:nil];
	
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:1];
    strUrl = nil;
}

-(void)loadNewData{
	self.pageCounter = 1;
	self.isDataNull = NO;
	[self.arrData removeAllObjects];
	[self getRequestList];
}

-(void)LoadViewSetting{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xccf5ff)];
    
    [self.lbl_NoDataAvailable setTextColor:TWITTER_BLUE_COLOR];
    [self.lbl_NoDataAvailable setShadowColor:[UIColor clearColor]];
}

-(IBAction)btnBackClicked:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}

-(void)btnAcceptFriendRequest:(id)sender{
    
    [HUD show:YES];
    
	if (self.request !=nil) {
		self.request = nil;
	}
	self.selectedIndex = (int)((UIButton *)sender).tag;
    
    
    
    NSString *strRequestId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:@"MsgID"]];
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"MsgID",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"IsAccept",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:ACCEPT_DENY_KEEP_MESSAGE withParameters:nil];
	//self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }

//	self.request.delegate = self;
//	self.request.tag = 2;
	strUrl = nil;
	
    //--
    
    [self.arrData removeObjectAtIndex:self.selectedIndex];
    [self.tblData reloadData];
	
    //--
}

-(void)btnRejectFriendRequest:(id)sender{
    
    [HUD show:YES];
    
	if (self.request !=nil) {
		self.request = nil;
	}
	self.selectedIndex = (int)((UIButton *)sender).tag;
    
        NSString *strRequestId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:@"MsgID"]];
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:strRequestId,KeyValue,@"MsgID",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"IsAccept",KeyName, nil],@"3",
						 nil];
    
	NSString *strUrl = [WebServiceContainer getServiceURL:ACCEPT_DENY_KEEP_MESSAGE withParameters:nil];
	//self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:3];
    }

//	self.request.delegate = self;
//	self.request.tag = 3;
	strUrl = nil;
    
    //--
    
    [self.arrData removeObjectAtIndex:self.selectedIndex];
    [self.tblData reloadData];
    
    //--
}

#pragma mark  UITableViewDelegate

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 100;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	//return self.arrData.count;
	return self.arrData.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
		
	KeepRequestListCell *cell = (KeepRequestListCell *)[tableView dequeueReusableCellWithIdentifier:@"CellKeep"];
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;

    [cell setControlValuesInCellWithData:[self.arrData objectAtIndex:indexPath.row]];

    [cell.btnAccept removeTarget:self action:@selector(btnAcceptFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnReject removeTarget:self action:@selector(btnRejectFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
    
    [cell.btnAccept addTarget:self action:@selector(btnAcceptFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnReject addTarget:self action:@selector(btnRejectFriendRequest:) forControlEvents:UIControlEventTouchUpInside];
	
	return cell;
}

#pragma mark
#pragma mark web service method

- (void)successResponseWithData:(id)request withTag:(int)tag{
    
    NSLog(@"tag = %d",tag);
   
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    self.lbl_NoDataAvailable.hidden = TRUE;
    
    if (dicResponse != nil) {
        
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.2];
            Validation.viewPullToRefresh.alpha = 0;
            [UIView commitAnimations];
            [self.refresh endRefreshing];
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            
                            [self.arrData addObjectsFromArray:arr];
                            arr = nil;
                            [self.lbl_NoDataAvailable setHidden:YES];
                            [self.tblData reloadData];
                            
                            if (self.arrData.count == 0 && self.pageCounter==1) {
                                [self.lbl_NoDataAvailable setHidden:NO];
                                [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                            }
                        }
                    }
                    else if (self.arrData.count == 0 && self.pageCounter==1) {
                        [self.lbl_NoDataAvailable setHidden:NO];
                        [self.view bringSubviewToFront:self.lbl_NoDataAvailable];
                    }
                }
                [self.refresh endRefreshing];
                [HUD hide:YES];
            }
            else if (tag == 2) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    ///accept response
                    
         /*           if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            NSLog(@"rezponse = %@",[response objectAtIndex:0]);
                            NSString *strFR = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_FRIENDS_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strNotif = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_UNREAD_NOTIF]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            
                            
                            Validation.dicNotifCount = [NSDictionary
                                                        dictionaryWithObjectsAndKeys:
                                                        strFR,TOTAL_FRIENDS_REQUEST,
                                                        strNotif,TOTAL_UNREAD_NOTIF,
                                                        nil];
                            
                            strFR = nil;
                            strNotif = nil;
                        }
                        
                    }
                    else{
                        Validation.dicNotifCount = [NSDictionary
                                                    dictionaryWithObjectsAndKeys:
                                                    @"",TOTAL_FRIENDS_REQUEST,
                                                    @"",TOTAL_UNREAD_NOTIF,
                                                    nil];
                    }
           */     }
                [self.refresh endRefreshing];
                [HUD hide:YES];
            }
            else if (tag == 3){
               //reject response
                [self.refresh endRefreshing];
                [HUD hide:YES];
            }
        }
    }
    else{
        [HUD hide:YES];
    }
	
	
	self.request = nil;
}


- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
 {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
