//
//  PBJViewController.m
//  Vision
//
//  Created by Patrick Piemonte on 7/23/13.
//  Copyright (c) 2013-present, Patrick Piemonte, http://patrickpiemonte.com
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy of
//  this software and associated documentation files (the "Software"), to deal in
//  the Software without restriction, including without limitation the rights to
//  use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
//  the Software, and to permit persons to whom the Software is furnished to do so,
//  subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
//  FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
//  COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
//  IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
//  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

#import "PBJViewController.h"
#import "PBJStrobeView.h"
#import "PBJFocusView.h"

#import "PBJVision.h"
#import "PBJVisionUtilities.h"

#import <AssetsLibrary/AssetsLibrary.h>
#import <GLKit/GLKit.h>

#import "VideoListVC.h"

#define MAX_RECORDING_SECONDS   15
#define MIN_RECORDING_SECONDS   3

@interface ExtendedHitButton : UIButton

+ (instancetype)extendedHitButton;

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event;

@end

@implementation ExtendedHitButton

+ (instancetype)extendedHitButton
{
    return (ExtendedHitButton *)[ExtendedHitButton buttonWithType:UIButtonTypeCustom];
}

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    CGRect relativeFrame = self.bounds;
    UIEdgeInsets hitTestEdgeInsets = UIEdgeInsetsMake(-35, -35, -35, -35);
    CGRect hitFrame = UIEdgeInsetsInsetRect(relativeFrame, hitTestEdgeInsets);
    return CGRectContainsPoint(hitFrame, point);
}
@end

@interface PBJViewController () <
    UIGestureRecognizerDelegate,
    PBJVisionDelegate,
    UIAlertViewDelegate>
{
    PBJStrobeView *_strobeView;
    UIButton *_doneButton;
    
    UIButton *_flipButton;
    UIButton *_focusButton;
    UIButton *_frameRateButton;
    UIButton *_onionButton;
    UIView *_captureDock;

    UIView *_previewView;
    AVCaptureVideoPreviewLayer *_previewLayer;
    PBJFocusView *_focusView;
    GLKViewController *_effectsViewController;
    
    UILabel *_instructionLabel;
    UIView *_gestureView;
    UILongPressGestureRecognizer *_longPressGestureRecognizer;
    UITapGestureRecognizer *_focusTapGestureRecognizer;
    UITapGestureRecognizer *_photoTapGestureRecognizer;
    
    BOOL _recording;

    ALAssetsLibrary *_assetLibrary;
    __block NSDictionary *_currentVideo;
    __block NSDictionary *_currentPhoto;
    
    NSTimer *timer;
    UILabel *lblTimer;
    NSInteger count;
//    NSInteger seconds;
    
    UIButton *butFlash;
    
    UIButton *butGallery;
    
    UIButton *butCancel;
    UIButton *butDone;
    
    UIImageView *ImageviewVideo;
}
@property (nonatomic, readwrite) int seconds;

@end

@implementation PBJViewController


#pragma mark - UIViewController

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

#pragma mark - init

- (void)dealloc
{
//    [UIApplication sharedApplication].idleTimerDisabled = NO;
//    _longPressGestureRecognizer.delegate = nil;
//    _focusTapGestureRecognizer.delegate = nil;
//    _photoTapGestureRecognizer.delegate = nil;
}

#pragma mark - view lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

    [PBJVision resetSharedInstance];
    self.view.backgroundColor = [UIColor blackColor];
    self.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    self.seconds = MAX_RECORDING_SECONDS;
    
    _assetLibrary = [[ALAssetsLibrary alloc] init];
    
    appDelegate.CamreBack = 1;
    
    // preview and AV layer
    _previewView = [[UIView alloc] initWithFrame:CGRectZero];
    _previewView.backgroundColor = [UIColor blackColor];
    //  CGRect previewFrame = CGRectMake(0, 60.0f, CGRectGetWidth(self.view.frame), CGRectGetWidth(self.view.frame));
    
    CGRect previewFrame = CGRectMake(0, 0.0f, CGRectGetWidth(self.view.frame), self.view.frame.size.height);
    
    NSLog(@"previewFrame %@",NSStringFromCGRect(previewFrame));
    
    _previewView.frame = previewFrame;
    _previewLayer = [[PBJVision sharedInstance] previewLayer];
    _previewLayer.frame = _previewView.bounds;
    _previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    [_previewView.layer addSublayer:_previewLayer];
    
    // onion skin
    _effectsViewController = [[GLKViewController alloc] init];
    _effectsViewController.preferredFramesPerSecond = 30;
    
    GLKView *view = (GLKView *)_effectsViewController.view;
    CGRect viewFrame = _previewView.bounds;
    view.frame = viewFrame;
    view.context = [[PBJVision sharedInstance] context];
    view.contentScaleFactor = [[UIScreen mainScreen] scale];
    view.alpha = 0.5f;
    view.hidden = YES;
    [[PBJVision sharedInstance] setPresentationFrame:_previewView.frame];
    [_previewView addSubview:_effectsViewController.view];
    
    // focus view
    _focusView = [[PBJFocusView alloc] initWithFrame:CGRectZero];
    
    
    // touch to record
    _longPressGestureRecognizer = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(_handleLongPressGestureRecognizer:)];
    _longPressGestureRecognizer.delegate = self;
    _longPressGestureRecognizer.minimumPressDuration = 0.05f;
    _longPressGestureRecognizer.allowableMovement = 10.0f;
    
    // tap to focus
    _focusTapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(_handleFocusTapGesterRecognizer:)];
    _focusTapGestureRecognizer.delegate = self;
    _focusTapGestureRecognizer.numberOfTapsRequired = 1;
    _focusTapGestureRecognizer.enabled = NO;
    [_previewView addGestureRecognizer:_focusTapGestureRecognizer];
    
    
    // gesture view to record
    _gestureView = [[UIView alloc] initWithFrame:CGRectMake(120, 460, 82, 82)];
    _gestureView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_gestureView];
    [self.view bringSubviewToFront:_gestureView];
    
    [_gestureView addGestureRecognizer:_longPressGestureRecognizer];
    
    // bottom dock
    _captureDock = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(self.view.bounds) - 60.0f, CGRectGetWidth(self.view.bounds), 60.0f)];
    _captureDock.backgroundColor = [UIColor clearColor];
    _captureDock.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    [self.view addSubview:_captureDock];
    
    
    _flipButton= [UIButton buttonWithType:UIButtonTypeCustom];
    [_flipButton setFrame:CGRectMake(20, 480, 50, 50)];
    [_flipButton addTarget:self action:@selector(_handleFlipButton:) forControlEvents:UIControlEventTouchUpInside];
    
    // flip button
    //     _flipButton = [ExtendedHitButton extendedHitButton];
    //    UIImage *flipImage = [UIImage imageNamed:@"btn_camera_front_default.png"];
    
    [_flipButton setImage:[UIImage imageNamed:@"btn_camera_front_default.png"] forState:UIControlStateNormal];
    [_flipButton setImage:[UIImage imageNamed:@"btn_camera_front_highlighted.png"] forState:UIControlStateSelected];
    //    [_flipButton setExclusiveTouch:YES];
    
    [self.view addSubview:_flipButton];
    [self.view bringSubviewToFront:_flipButton];
    
    
    butFlash= [UIButton buttonWithType:UIButtonTypeCustom];
    [butFlash setFrame:CGRectMake(250, 480, 50, 50)];
    [butFlash addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    //  btn_camera_flash_default
    [butFlash setImage:[UIImage imageNamed:@"btn_camera_flash_default.png"] forState:UIControlStateNormal];
    
    [butFlash setImage:[UIImage imageNamed:@"btn_camera_flash_highlighted.png"] forState:UIControlStateSelected];
    [butFlash setExclusiveTouch:YES];
    
    [self.view addSubview:butFlash];
    [self.view bringSubviewToFront:butFlash];
    
    ImageviewVideo = [[UIImageView alloc]initWithFrame:CGRectMake(120, 460, 82, 82)];
    //    [ImageviewVideo setFrame:CGRectMake(130, 480, 82, 82)];
    UIImage *imagevideo = [UIImage imageNamed:@"btn_video_capture.png"];
    ImageviewVideo.image = imagevideo;
    [self.view addSubview:ImageviewVideo];
    [self.view bringSubviewToFront:ImageviewVideo];
    
    
    [_previewView addSubview:ImageviewVideo];
    [_previewView bringSubviewToFront:ImageviewVideo];
    
    
    butCancel= [UIButton buttonWithType:UIButtonTypeCustom];
    [butCancel setFrame:CGRectMake(20, 30, 34, 34)];
    [butCancel addTarget:self action:@selector(buttonClickedCancel) forControlEvents:UIControlEventTouchUpInside];
    
    //  btn_camera_flash_default
    [butCancel setImage:[UIImage imageNamed:@"btn_close_2.png"] forState:UIControlStateNormal];
    [butCancel setExclusiveTouch:YES];
    
    [self.view addSubview:butCancel];
    [self.view bringSubviewToFront:butCancel];
    
    
    //Done button
    
    butDone= [UIButton buttonWithType:UIButtonTypeCustom];
    [butDone setFrame:CGRectMake(self.view.frame.size.width-50, 30, 34, 34)];
    [butDone addTarget:self action:@selector(buttonDoneClicked) forControlEvents:UIControlEventTouchUpInside];
    
    //  btn_camera_flash_default
    [butDone setImage:[UIImage imageNamed:@"btn_vidiblab_done.png"] forState:UIControlStateNormal];
    [butDone setExclusiveTouch:YES];
    butDone.hidden = YES;
    [self.view addSubview:butDone];
    [self.view bringSubviewToFront:butDone];
    
    self.lblProgressBar = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0, 20)];
    self.lblProgressBar.backgroundColor = TWITTER_BLUE_COLOR;
    self.lblProgressBar.alpha = 0.8;
    [self.view addSubview:self.lblProgressBar];
    
    
    self.isDoneClicked = FALSE;
    
    NSFileManager *fm = [NSFileManager defaultManager];
    
    if (![fm fileExistsAtPath:VIDEO_RECORDING_FOLDER]){
        
        [fm createDirectoryAtPath:VIDEO_RECORDING_FOLDER
      withIntermediateDirectories:YES
                       attributes:nil
                            error:NULL];
    }

    /*
     // focus mode button
     _focusButton = [ExtendedHitButton extendedHitButton];
     UIImage *focusImage = [UIImage imageNamed:@"capture_focus_button"];
     [_focusButton setImage:focusImage forState:UIControlStateNormal];
     [_focusButton setImage:[UIImage imageNamed:@"capture_focus_button_active"] forState:UIControlStateSelected];
     CGRect focusFrame = _focusButton.frame;
     focusFrame.origin = CGPointMake((CGRectGetWidth(self.view.bounds) * 0.5f) - (focusImage.size.width * 0.5f), 16.0f);
     focusFrame.size = focusImage.size;
     _focusButton.frame = focusFrame;
     [_focusButton addTarget:self action:@selector(_handleFocusButton:) forControlEvents:UIControlEventTouchUpInside];
     [self.view addSubview:_focusButton];
     
     // butGallery
     
     
     butGallery= [UIButton buttonWithType:UIButtonTypeCustom];
     [butGallery setFrame:CGRectMake(120, 520, 70, 35)];
     [butGallery addTarget:self action:@selector(buttonClickedGallery) forControlEvents:UIControlEventTouchUpInside];
     
     [butGallery setTitle:@"Gallery" forState:UIControlStateNormal];
     
     [butGallery setExclusiveTouch:YES];
     
     [self.view addSubview:butGallery];
     [self.view bringSubviewToFront:butGallery];
     */
    
    self.isRecordingStarted = NO;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkOrientation) name:UIDeviceOrientationDidChangeNotification object:nil];
    
    if ([[PBJVision sharedInstance] supportsVideoFrameRate:120]) {
        // set faster frame rate
    }
    
    lblTimer.text = [NSString stringWithFormat:@"00:15"];
    
    
    // iOS 6 support
    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];
    
    
    [self _resetCapture];
    [[PBJVision sharedInstance] startPreview];
    
    if (![[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:IS_MESSAGE_SHOW_FOR_VIDEO_SCREEN]] boolValue]) {
        [self performSelector:@selector(displayToast) withObject:nil afterDelay:0.1f];
        [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:IS_MESSAGE_SHOW_FOR_VIDEO_SCREEN];
    }
    
}
-(void)displayToast{
    [Validation showToastMessageBigText:@"Press and Hold button to begin recording and release when you want to stop." displayDuration:INFO_MSG_DURATION];
}

- (void)viewWillAppear:(BOOL)animated
{
    appDelegate.currentVc = self;
    [super viewWillAppear:animated];
    [[PBJVision sharedInstance] StartCapturingTemp];
 
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [session setActive:NO error:nil];
    BOOL success = [session setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionMixWithOthers|AVAudioSessionCategoryOptionDefaultToSpeaker error:nil];
    if (!success) {
        NSLog(@"setCategoryError");
    }
}

-(void)HideOrientationView{
//    [UIView beginAnimations:@"showOrientationMSG" context:nil];
//    [UIView setAnimationDuration:1.0];
//    self.lblForOrientation.alpha = 0.0;
//    [UIView commitAnimations];
}

-(void)buttonDoneClicked{

//    BOOL isMoveToTrimVC = FALSE;
    
//    if(self.seconds == 0 || self.pauseTimeinterval >=3.0){
//        isMoveToTrimVC = TRUE;
//    }
    
    [timer invalidate];
    
    
    
    self.isDoneClicked = YES;
    
    _gestureView.hidden = YES;
    
    
    //-----------------
    appDelegate.CamreBack = 1;
    
    if(self.seconds == 0 ){
        //[self _handleDoneButton:nil];
        if (self.isDoneClicked) {
            [self MoveToTrimVC];
        }
    }
    else if (self.pauseTimeinterval >3){
        self.isShouldMerge = TRUE;
        [self _handleDoneButton:nil];
    }
    else{
        _gestureView.hidden = FALSE;
        _longPressGestureRecognizer.enabled = YES;
        [Validation showToastMessage:@"Your video should be atleast of 3seconds." displayDuration:ERROR_MSG_DURATION];
    }
}

-(UIImage *)generateThumbImage : (NSURL *)url
{
    AVAsset *asset = [AVAsset assetWithURL:url];
    AVAssetImageGenerator *imageGenerator = [[AVAssetImageGenerator alloc]initWithAsset:asset];
    CMTime time = CMTimeMakeWithSeconds(0,1);
    CGImageRef imageRef = [imageGenerator copyCGImageAtTime:time actualTime:NULL error:NULL];
    UIImage *thumbnail = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);  // CGImageRef won't be released by ARC
    return thumbnail;
}

-(void)MoveToTrimVC{
    
    NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
    
    NSURL *videoFileUrl1 = [NSURL fileURLWithPath:tempPath];
    
    AVURLAsset *movieAsset=[AVURLAsset URLAssetWithURL:videoFileUrl1 options:nil];
    CMTime duration = movieAsset.duration;
    
    NSLog(@"%f",CMTimeGetSeconds(duration));
    
    if (CMTimeGetSeconds(duration) <3.0) {
        _gestureView.hidden = FALSE;
        self.isPaused = FALSE;
        _longPressGestureRecognizer.enabled = YES;
        butDone.hidden = TRUE;
        self.lblProgressBar.frame = CGRectMake(0, 0, 0, 20);
        
        self.seconds = 15.0;
        self.pauseTimeinterval = 0.0f;
        lblTimer.text = [NSString stringWithFormat:@"00:%li",(long)self.seconds];

        [Validation showToastMessage:@"Your video should be atleast of 3seconds." displayDuration:ERROR_MSG_DURATION];
        
    }
    else{
        
//        AVAssetTrack *VideoTrack = [[movieAsset tracksWithMediaType:AVMediaTypeVideo] lastObject];
//        CGAffineTransform txf = [VideoTrack preferredTransform];
     //   appDelegate.videoPrefferedTransform = txf;
        
        UIImage *img = [self generateThumbImage:[NSURL fileURLWithPath:tempPath]];
        
        
        UIImageOrientation oldOrientation = img.imageOrientation;
        switch (oldOrientation) {
            case UIImageOrientationUp:{
                NSLog(@"UIImageOrientationUp"); //-1
                //newOrientation = UIImageOrientationRight;
            }
                break;
            case UIImageOrientationLeft:{
                NSLog(@"UIImageOrientationLeft");
                //newOrientation = UIImageOrientationDown;
            }
                break;
            case UIImageOrientationDown:{
                NSLog(@"UIImageOrientationDown");
                //            newOrientation = UIImageOrientationLandscapeRight;
            }
                break;
            case UIImageOrientationRight:{
                NSLog(@"UIImageOrientationRight");
                //          newOrientation = UIImageOrientationUp;
            }
                break;
            case  UIImageOrientationUpMirrored:{
                NSLog(@"UIImageOrientationUpMirrored");
            }
                break;
            case UIImageOrientationDownMirrored:{
                NSLog(@"UIImageOrientationDownMirrored");
            }
                break;
            case UIImageOrientationLeftMirrored:{
                NSLog(@"UIImageOrientationLeftMirrored");
            }
                break;
            case UIImageOrientationRightMirrored:{
                NSLog(@"UIImageOrientationRightMirrored:");
            }
                break;
                // you can also handle mirrored orientations similarly ...
        }
   //     NSLog(@"%f",txf.a);
    //    appDelegate.videoPrefferedTransform = txf;

        
        appDelegate.isRecordingFromCamera = YES;
        VideoListVC *obj = [[VideoListVC alloc]initWithNibName:@"VideoListVC" bundle:nil];
        [self.navigationController pushViewController:obj animated:YES];
    }
    
    
//    appDelegate.isRecordingFromCamera = YES;
//    VideoListVC *obj = [[VideoListVC alloc]initWithNibName:@"VideoListVC" bundle:nil];
//    [self.navigationController pushViewController:obj animated:YES];
}

-(void)buttonClickedCancel{
//    [self _handleFlipButton:_flipButton];
    [self handleFlipButtonCancelBtn];
    
//    [self handleFlipButton];
//    
//    [_flipButton setSelected:FALSE];
    
    self.isPaused = FALSE;
    if ([[NSFileManager defaultManager] fileExistsAtPath:VIDEO_RECORDING_FOLDER]) {
        //when folder exists
        NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
        if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
            [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
        }
    }
    appDelegate.FlagVideo = 0;
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)buttonClickedGallery{
    
    NSLog(@"call");
    
    UIImagePickerController *imagePicker =[[UIImagePickerController alloc] init];
    
    imagePicker.delegate = self;
    imagePicker.sourceType =UIImagePickerControllerSourceTypePhotoLibrary;
    
    imagePicker.mediaTypes =@[(NSString *) kUTTypeImage,
      (NSString *) kUTTypeMovie];
    
    imagePicker.allowsEditing = YES;
    [self presentViewController:imagePicker animated:YES completion:nil];
    
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    NSString *mediaType = [info objectForKey:UIImagePickerControllerMediaType];
    
     if ([mediaType isEqualToString:@"public.movie"]){
        
        NSURL *videoURL = [info objectForKey:UIImagePickerControllerMediaURL];
    // Code here to work with media
         
//         NSURL *url = [NSURL fileURLWithPath:path];
         
         ALAssetsLibrary *library = [[ALAssetsLibrary alloc]init];
         
//         appDelegat.vedioURL = videoURL;
         
         [library writeVideoAtPathToSavedPhotosAlbum:videoURL completionBlock:^(NSURL *assetURL, NSError *error) {
             NSLog(@"true");
         }];
         
     }
   [self dismissViewControllerAnimated:YES completion:nil];
    
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)navigationController:(UINavigationController *)nc
       didShowViewController:(UIViewController *)vc
                    animated:(BOOL)animated {
    
}

-(void)doCancel{
    
}

-(void)buttonClicked:(UIButton*)sender
{
//    NSLog(@"you clicked on button %ld", (long)sender.tag);
    
    UIButton *btn=(UIButton*)sender;
    btn.selected=!btn.selected;
    
    NSInteger tag = [btn tag];
    NSLog(@"Tag = %ld",(long)tag);
    
    if (btn.selected) {

        // check if flashlight available
        Class captureDeviceClass = NSClassFromString(@"AVCaptureDevice");
        if (captureDeviceClass != nil) {
            AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
            if ([device hasTorch] && [device hasFlash]){
                
                [device lockForConfiguration:nil];
                    [device setTorchMode:AVCaptureTorchModeOn];
                    [device setFlashMode:AVCaptureFlashModeOn];
                    //torchIsOn = YES; //define as a variable/property if you need to know status
                [device unlockForConfiguration];
            }
        }
    }
    else{
        // check if flashlight available
        Class captureDeviceClass = NSClassFromString(@"AVCaptureDevice");
        if (captureDeviceClass != nil) {
            AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
            if ([device hasTorch] && [device hasFlash]){
                
                [device lockForConfiguration:nil];
                [device setTorchMode:AVCaptureTorchModeOff];
                [device setFlashMode:AVCaptureFlashModeOff];
                //torchIsOn = YES; //define as a variable/property if you need to know status
                [device unlockForConfiguration];
            }
        }
    }
}

- (void) turnTorchOn: (bool) on {
    
    // check if flashlight available
    Class captureDeviceClass = NSClassFromString(@"AVCaptureDevice");
    if (captureDeviceClass != nil) {
        AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        if ([device hasTorch] && [device hasFlash]){
            
            [device lockForConfiguration:nil];
            if (on) {
                [device setTorchMode:AVCaptureTorchModeOn];
                [device setFlashMode:AVCaptureFlashModeOn];
                //torchIsOn = YES; //define as a variable/property if you need to know status
            } else {
                [device setTorchMode:AVCaptureTorchModeOff];
                [device setFlashMode:AVCaptureFlashModeOff];
                //torchIsOn = NO;
            }
            [device unlockForConfiguration];
        }
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[PBJVision sharedInstance] stopPreview];
    
    // iOS 6 support
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationSlide];
}

- (void)subtractTime{
    
    NSDate *currentDate = [NSDate date];
    NSTimeInterval timeInterval = [currentDate timeIntervalSinceDate:self.startDate];
    self.pauseTimeinterval = timeInterval;
    
    //15 seconds count down
    NSTimeInterval timeIntervalCountDown = 16.0 - timeInterval;
    
    float widthOfLbl = (320.0*self.pauseTimeinterval)/15;
    self.lblProgressBar.frame = CGRectMake(0, 0, widthOfLbl, 20);
    
 //   NSLog(@"time elapsed = %f",timeInterval);
    NSDate *timerDate = [NSDate
                         dateWithTimeIntervalSince1970:timeIntervalCountDown];
    
    // Create a date formatter
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"mm:ss"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0.0]];
    
    // Format the elapsed time and set it to the label
    NSString *timeString = [dateFormatter stringFromDate:timerDate];

    butDone.hidden = FALSE;
    lblTimer.text = timeString;
    
    if(self.pauseTimeinterval > totalRecordingDuration){
        
        [timer invalidate];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:UIDeviceOrientationDidChangeNotification object:nil];
        
        self.seconds = 0;
        lblTimer.text = [NSString stringWithFormat:@"00:00"];
        //_gestureView.hidden = YES;
        
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:INFO message:[NSString stringWithFormat:@"Recording Completed Successfully"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert setTag:0];
        [alert show];
        self.isRecordingStarted = NO;
        
        [self _handleDoneButton:nil];
    }
}

-(void)checkOrientation{
    
    if (self.isRecordingStarted || self.isDoneClicked) {
        [[NSNotificationCenter defaultCenter] removeObserver:self name:UIDeviceOrientationDidChangeNotification object:nil];
    }
    else{
        UIDevice *currentDevice = [UIDevice currentDevice];
        appDelegate.CameraOrientationForVideo = 4;
        
        switch (currentDevice.orientation) {
            case PBJCameraOrientationPortraitUpsideDown:
                NSLog(@"PBJCameraOrientationPortraitUpsideDown");
                appDelegate.CameraOrientationForVideo = 1;
               
                break;
            case PBJCameraOrientationLandscapeRight:
                NSLog(@"PBJCameraOrientationLandscapeRight");
                appDelegate.CameraOrientationForVideo = 2;
               
                break;
            case PBJCameraOrientationLandscapeLeft:
                NSLog(@"PBJCameraOrientationLandscapeLeft");
                appDelegate.CameraOrientationForVideo = 3;
                
                break;
            case PBJCameraOrientationPortrait:
                NSLog(@"PBJCameraOrientationPortrait");
                appDelegate.CameraOrientationForVideo = 4;
                
                break;
            default:
                break;
        }
    }
}
#pragma mark - private start/stop helper methods

- (void)_startCapture
{
    [self checkOrientation];
    self.isRecordingStarted = YES;
    _flipButton.enabled = false;
   // self.lblForOrientation.hidden = YES;
    BOOL isFileExists = FALSE;
    self.isShouldMerge = FALSE;
    
    NSFileManager *fm = [NSFileManager defaultManager];
    self.isDoneClicked = FALSE;
    if (![fm fileExistsAtPath:VIDEO_RECORDING_FOLDER]){
        //folder does not exists
         //it mens file does not exists
    }
    else{
        //folder exists
        //now check for file
        NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
        if ([fm fileExistsAtPath:tempPath]) {
            //file exists , so ask for delete
            [AlertHandler alertTitle:CONFIRM message:@"New Recording will remove previouse recording." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
            isFileExists = TRUE;
            [fm removeItemAtPath:tempPath error:NULL];
        }

        butDone.hidden = TRUE;
        self.lblProgressBar.frame = CGRectMake(0, 0, 0, 20);

        self.seconds = 15.0;
        self.pauseTimeinterval = 0.0f;
         lblTimer.text = [NSString stringWithFormat:@"00:%li",(long)self.seconds];
        
    }
    
    if (!isFileExists) {
        self.seconds = MAX_RECORDING_SECONDS;
        minute = 0;
        
        if ([_previewView viewWithTag:222] != nil) {
            UIView *v = (UIView *)[_previewView viewWithTag:222];
            [v removeFromSuperview];
            v = nil;
        }
        
        UIView *viewLbl = [[UIView alloc]initWithFrame:CGRectMake(120, 400, 70, 40)];
        [viewLbl setAlpha:0.7];
        viewLbl.backgroundColor = UIColorFromRGB(0X00c2d9);
        viewLbl.layer.cornerRadius = 5;
        viewLbl.layer.masksToBounds = YES;
        viewLbl.tag = 222;
        
        if (lblTimer == nil) {
            lblTimer = [[UILabel alloc]initWithFrame:CGRectMake(120, 400, 70, 40)];
        }
        
        
        lblTimer.font = [UIFont fontWithName:Font_Montserrat_Regular size:16.0f];
        lblTimer.textColor = [UIColor whiteColor];
        //    lblTimer.backgroundColor = UIColorFromRGB(0X00c2d9);
        lblTimer.backgroundColor = [UIColor clearColor];
        if (self.seconds<=9) {
            lblTimer.text = [NSString stringWithFormat:@"00:0%li",(long)self.seconds];
        }
        else{
            lblTimer.text = [NSString stringWithFormat:@"00:%li",(long)self.seconds];
        }
        lblTimer.textAlignment = NSTextAlignmentCenter;
        
        [_previewView addSubview:viewLbl];
        [_previewView addSubview:lblTimer];
        
        [UIApplication sharedApplication].idleTimerDisabled = YES;
        
//        [UIView animateWithDuration:0.02f delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
//            _instructionLabel.backgroundColor = [UIColor redColor];
//
//            _instructionLabel.alpha = 0;
//            _instructionLabel.transform = CGAffineTransformMakeTranslation(0, 10.0f);
//        } completion:^(BOOL finished) {
//        }];
        self.isPaused = FALSE;
        [[PBJVision sharedInstance] startVideoCapture];
    }
}

-(void)startTimer{
    self.startDate = [NSDate date] ;
    self.startDate = [self.startDate dateByAddingTimeInterval:((-1)*(self.pauseTimeinterval))] ;
    timer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(subtractTime) userInfo:nil repeats:YES];

}

- (void)_pauseCapture
{
    self.isPaused = TRUE;
    _flipButton.enabled = TRUE;
    
//    [UIView animateWithDuration:0.02f delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
//        _instructionLabel.alpha = 1;
//        _instructionLabel.backgroundColor = [UIColor redColor];
//
//        _instructionLabel.transform = CGAffineTransformIdentity;
//    } completion:^(BOOL finished) {
//    }];

    [[PBJVision sharedInstance] pauseVideoCapture];
    [timer invalidate];
    _effectsViewController.view.hidden = !_onionButton.selected;
    secondAtPause = self.seconds;
    minuteAtPause = minute;
}

- (void)_resumeCapture
{
    _flipButton.enabled = FALSE;
    if (self.seconds==0) {
        [timer invalidate];
        return;
    }
    else{
       // timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(subtractTime) userInfo:nil repeats:YES];
   //     self.lblForOrientation.hidden = YES;
        
        secondAtPause = second;
        minuteAtPause = minute;
        
        [[PBJVision sharedInstance] resumeVideoCapture];
        _effectsViewController.view.hidden = YES;
        [self startTimer];

//        [UIView animateWithDuration:0.02f delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
//            _instructionLabel.alpha = 10;
//            _instructionLabel.backgroundColor = [UIColor redColor];
//            _instructionLabel.transform = CGAffineTransformMakeTranslation(0, 10.0f);
//        } completion:^(BOOL finished) {
//        }];
        
    }
    
    NSLog(@"second=%ld",(long)self.seconds);
}

- (void)_endCapture
{
    [UIApplication sharedApplication].idleTimerDisabled = NO;
    [[PBJVision sharedInstance] endVideoCapture];
    _effectsViewController.view.hidden = YES;
}

- (void)_resetCapture
{
    _flipButton.enabled = TRUE;
    [_strobeView stop];
    _longPressGestureRecognizer.enabled = YES;
    ImageviewVideo.alpha = 1.0;
    
    PBJVision *vision = [PBJVision sharedInstance];
    vision.delegate = self;

    if ([vision isCameraDeviceAvailable:PBJCameraDeviceBack]) {
        vision.cameraDevice = PBJCameraDeviceBack;
        _flipButton.hidden = NO;
        [_flipButton setSelected:FALSE];
    } else {
        vision.cameraDevice = PBJCameraDeviceFront;
        _flipButton.hidden = YES;
    }
    
    vision.cameraMode = PBJCameraModeVideo;
    //vision.cameraMode = PBJCameraModePhoto; // PHOTO: uncomment to test photo capture
    vision.cameraOrientation = PBJCameraOrientationPortrait;
    vision.focusMode = PBJFocusModeContinuousAutoFocus;
    vision.outputFormat = PBJOutputFormatSquare;
    vision.videoRenderingEnabled = YES;
    vision.additionalCompressionProperties = @{AVVideoProfileLevelKey : AVVideoProfileLevelH264Baseline30}; // AVVideoProfileLevelKey requires specific captureSessionPreset
    
    // specify a maximum duration with the following property
    // vision.maximumCaptureDuration = CMTimeMakeWithSeconds(5, 600); // ~ 5 seconds
}

#pragma mark - UIButton

- (void)handleFlipButtonCancelBtn{
    PBJVision *vision = [PBJVision sharedInstance];
    vision.cameraDevice = PBJCameraDeviceBack;
}

- (void)handleFlipButton
{
    PBJVision *vision = [PBJVision sharedInstance];
    
    if (appDelegate.CamreBack == 1) {
        if (vision.cameraDevice== PBJCameraDeviceBack) {
            vision.cameraDevice= PBJCameraDeviceFront;
        }
        else{
            vision.cameraDevice= PBJCameraDeviceBack;
        }
    }
    else{
        if (vision.cameraDevice== PBJCameraDeviceBack) {
            vision.cameraDevice= PBJCameraDeviceBack;
        }
        else{
            vision.cameraDevice= PBJCameraDeviceFront;
        }
    }
}

/*
- (void)_handleFlipButton:(UIButton *)button
{
    UIButton *btn=(UIButton*)button;
    btn.selected=!btn.selected;
    
    PBJVision *vision = [PBJVision sharedInstance];
    vision.cameraDevice = vision.cameraDevice == PBJCameraDeviceBack ? PBJCameraDeviceFront : PBJCameraDeviceBack;
    
    if (vision.cameraDevice== PBJCameraDeviceBack) {
        appDelegate.CamreBack = 1;
    }
    else{
        appDelegate.CamreBack = 0;
    }
}
*/

- (void)_handleFlipButton:(UIButton *)button
{
    UIButton *btn=(UIButton*)button;
    btn.selected=!btn.selected;
    
    _longPressGestureRecognizer.enabled = FALSE;
    ImageviewVideo.alpha = 0.4;
    
    if (btn.selected) {
        NSLog(@"Selected");
        butFlash.selected = FALSE;
        butFlash.enabled = FALSE;
    }
    else{
        NSLog(@"Not Selected");
        butFlash.enabled = TRUE;
    }
    
    PBJVision *vision = [PBJVision sharedInstance];
    vision.cameraDevice = vision.cameraDevice == PBJCameraDeviceBack ? PBJCameraDeviceFront : PBJCameraDeviceBack;
    
    if (vision.cameraDevice== PBJCameraDeviceBack) {
        appDelegate.CamreBack = 1;
    }
    else{
        appDelegate.CamreBack = 0;
    }
}

- (void)_handleFocusButton:(UIButton *)button
{
    _focusButton.selected = !_focusButton.selected;
    
    if (_focusButton.selected) {
        _focusTapGestureRecognizer.enabled = YES;
        _gestureView.hidden = YES;

    } else {
        if (_focusView && [_focusView superview]) {
            [_focusView stopAnimation];
        }
        _focusTapGestureRecognizer.enabled = NO;
        _gestureView.hidden = NO;
    }
    
//    [UIView animateWithDuration:0.8f delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
//        _instructionLabel.backgroundColor = [UIColor redColor];
//
//        _instructionLabel.alpha = 0;
//    } completion:^(BOOL finished) {
//        _instructionLabel.text = _focusButton.selected ? NSLocalizedString(@"Touch to focus", @"Touch to focus") :
//                                                         NSLocalizedString(@"Touch and hold to record", @"Touch and hold to record");
//        [UIView animateWithDuration:0.8f delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
//            _instructionLabel.backgroundColor = [UIColor redColor];
//
//            _instructionLabel.alpha = 1;
//        } completion:^(BOOL finished1) {
//        }];
//    }];
}

- (void)_handleFrameRateChangeButton:(UIButton *)button
{
}

- (void)_handleOnionSkinningButton:(UIButton *)button
{
    _onionButton.selected = !_onionButton.selected;
    
    if (_recording) {
        _effectsViewController.view.hidden = !_onionButton.selected;
    }
}

- (void)_handleDoneButton:(UIButton *)button
{
    // resets long press
    _longPressGestureRecognizer.enabled = NO;
    _longPressGestureRecognizer.enabled = YES;
    ImageviewVideo.alpha = 1;
    
    [self _endCapture];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
//    [self _resetCapture];
    
    if (alertView.tag==10) {
        
        self.seconds = 0;
        [timer invalidate];
        lblTimer.text = [NSString stringWithFormat:@"00:00"];
//        lblTimer.text =@"";
        _gestureView.hidden = YES;
        [self _handleDoneButton:nil];
    }
    else{
        _gestureView.hidden = NO;
        self.seconds = MAX_RECORDING_SECONDS;
        NSLog(@"label-%@",lblTimer.text);
//        lblTimer.text = @"";
        [self _resetCapture];
        
      //  [[PBJVision sharedInstance] _destroyCamera];
        VideoListVC *obj = [[VideoListVC alloc]initWithNibName:@"VideoListVC" bundle:nil];
        [self.navigationController pushViewController:obj animated:YES];

    }

}

#pragma mark - UIGestureRecognizer

- (void)_handleLongPressGestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
{
    // PHOTO: uncomment to test photo capture
//    if (gestureRecognizer.state == UIGestureRecognizerStateBegan) {
//        [[PBJVision sharedInstance] capturePhoto];
//        return;
//    }

    switch (gestureRecognizer.state) {
      case UIGestureRecognizerStateBegan:
        {
            if (!_recording){
                self.isRecordingStarted = NO;
                [[NSNotificationCenter defaultCenter] removeObserver:self name:UIDeviceOrientationDidChangeNotification object:nil];
                [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkOrientation) name:UIDeviceOrientationDidChangeNotification object:nil];
                [self _startCapture];
            }
            else
                [self _resumeCapture];
            break;
        }
      case UIGestureRecognizerStateEnded:
      case UIGestureRecognizerStateCancelled:
      case UIGestureRecognizerStateFailed:
        {
            [self _pauseCapture];
            break;
        }
      default:
        break;
    }
}

- (void)_handleFocusTapGesterRecognizer:(UIGestureRecognizer *)gestureRecognizer
{
    CGPoint tapPoint = [gestureRecognizer locationInView:_previewView];

    // auto focus is occuring, display focus view
    CGPoint point = tapPoint;
    
    CGRect focusFrame = _focusView.frame;
#if defined(__LP64__) && __LP64__
    focusFrame.origin.x = rint(point.x - (focusFrame.size.width * 0.5));
    focusFrame.origin.y = rint(point.y - (focusFrame.size.height * 0.5));
#else
    focusFrame.origin.x = rintf(point.x - (focusFrame.size.width * 0.5f));
    focusFrame.origin.y = rintf(point.y - (focusFrame.size.height * 0.5f));
#endif
    [_focusView setFrame:focusFrame];
    
    [_previewView addSubview:_focusView];
    [_focusView startAnimation];

    CGPoint adjustPoint = [PBJVisionUtilities convertToPointOfInterestFromViewCoordinates:tapPoint inFrame:_previewView.frame];
    [[PBJVision sharedInstance] focusExposeAndAdjustWhiteBalanceAtAdjustedPoint:adjustPoint];
}

#pragma mark - PBJVisionDelegate

// session

- (void)visionSessionWillStart:(PBJVision *)vision
{
}

- (void)visionSessionDidStart:(PBJVision *)vision
{
    if (![_previewView superview]) {
        [self.view addSubview:_previewView];
        [self.view sendSubviewToBack:_previewView];
        
        [self.view bringSubviewToFront:_gestureView];
    }
}

- (void)visionSessionDidStop:(PBJVision *)vision
{
    NSLog(@"visionSessionDidStop");
    [_previewView removeFromSuperview];
    [UIApplication sharedApplication].idleTimerDisabled = NO;
    _longPressGestureRecognizer.delegate = nil;
    _focusTapGestureRecognizer.delegate = nil;
    _photoTapGestureRecognizer.delegate = nil;
    [[PBJVision sharedInstance] _destroyCamera];
}

// preview

- (void)visionSessionDidStartPreview:(PBJVision *)vision
{
    NSLog(@"Camera preview did start");
}

- (void)visionSessionDidStopPreview:(PBJVision *)vision
{
    NSLog(@"Camera preview did stop");
}

// device

- (void)visionCameraDeviceWillChange:(PBJVision *)vision
{
    NSLog(@"Camera device will change");
}

- (void)visionCameraDeviceDidChange:(PBJVision *)vision
{
    NSLog(@"Camera device did change");
    _longPressGestureRecognizer.enabled = TRUE;
    ImageviewVideo.alpha = 1.0;
}

// mode

- (void)visionCameraModeWillChange:(PBJVision *)vision
{
    NSLog(@"Camera mode will change");
}

- (void)visionCameraModeDidChange:(PBJVision *)vision
{
    NSLog(@"Camera mode did change");
}

// format

- (void)visionOutputFormatWillChange:(PBJVision *)vision
{
    NSLog(@"Output format will change");
}

- (void)visionOutputFormatDidChange:(PBJVision *)vision
{
    NSLog(@"Output format did change");
}

- (void)vision:(PBJVision *)vision didChangeCleanAperture:(CGRect)cleanAperture
{
}

// focus / exposure

- (void)visionWillStartFocus:(PBJVision *)vision
{
}

- (void)visionDidStopFocus:(PBJVision *)vision
{
    if (_focusView && [_focusView superview]) {
        [_focusView stopAnimation];
    }
}

- (void)visionWillChangeExposure:(PBJVision *)vision
{
}

- (void)visionDidChangeExposure:(PBJVision *)vision
{
    if (_focusView && [_focusView superview]) {
        [_focusView stopAnimation];
    }
}

// flash

- (void)visionDidChangeFlashMode:(PBJVision *)vision
{
    NSLog(@"Flash mode did change");
}

// photo

- (void)visionWillCapturePhoto:(PBJVision *)vision
{
}

- (void)visionDidCapturePhoto:(PBJVision *)vision
{
}

- (void)vision:(PBJVision *)vision capturedPhoto:(NSDictionary *)photoDict error:(NSError *)error
{
    if (error) {
        // handle error properly
        return;
    }
    _currentPhoto = photoDict;
    
    // save to library
    NSData *photoData = _currentPhoto[PBJVisionPhotoJPEGKey];
    NSDictionary *metadata = _currentPhoto[PBJVisionPhotoMetadataKey];
   [_assetLibrary writeImageDataToSavedPhotosAlbum:photoData metadata:metadata completionBlock:^(NSURL *assetURL, NSError *error1) {
        if (error1 || !assetURL) {
            // handle error properly
            return;
        }
       
        NSString *albumName = @"PBJVision";
        __block BOOL albumFound = NO;
        [_assetLibrary enumerateGroupsWithTypes:ALAssetsGroupAlbum usingBlock:^(ALAssetsGroup *group, BOOL *stop) {
            if ([albumName compare:[group valueForProperty:ALAssetsGroupPropertyName]] == NSOrderedSame) {
                albumFound = YES;
                [_assetLibrary assetForURL:assetURL resultBlock:^(ALAsset *asset) {
                    [group addAsset:asset];
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Photo Saved!" message: @"Saved to the camera roll."
                                                       delegate:nil
                                              cancelButtonTitle:nil
                                              otherButtonTitles:@"OK", nil];
                    [alert show];
                } failureBlock:nil];
            }
            if (!group && !albumFound) {
                __weak ALAssetsLibrary *blockSafeLibrary = _assetLibrary;
                [_assetLibrary addAssetsGroupAlbumWithName:albumName resultBlock:^(ALAssetsGroup *group1) {
                    [blockSafeLibrary assetForURL:assetURL resultBlock:^(ALAsset *asset) {
                        [group1 addAsset:asset];
                        UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Photo Saved!" message: @"Saved to the camera roll."
                                                       delegate:nil
                                              cancelButtonTitle:nil
                                              otherButtonTitles:@"OK", nil];
                        [alert show];
                    } failureBlock:nil];
                } failureBlock:nil];
            }
        } failureBlock:nil];
    }];
    
    _currentPhoto = nil;
}

// video capture

- (void)visionDidStartVideoCapture:(PBJVision *)vision
{
    [_strobeView start];
    _recording = YES;
    NSLog(@"visionDidStartVideoCapture ============> ");
    NSString *outputFile = [NSString stringWithFormat:@"videoRecording.mp4"];
    NSString *outputPath = [VIDEO_RECORDING_FOLDER stringByAppendingPathComponent:outputFile];
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:outputPath]){
       // [self stopRecording];
         NSLog(@"File does not Exist");
        return;
    }
    else{
        NSLog(@"File Exists");
        
      //  [self startTimer];
    }

}

- (void)visionDidPauseVideoCapture:(PBJVision *)vision
{
    [_strobeView stop];
}

- (void)visionDidResumeVideoCapture:(PBJVision *)vision
{
    [_strobeView start];
}

- (void)vision:(PBJVision *)vision capturedVideo:(NSDictionary *)videoDict error:(NSError *)error
{
    _recording = NO;

    if (error && [error.domain isEqual:PBJVisionErrorDomain] && error.code == PBJVisionErrorCancelled) {
        NSLog(@"recording session cancelled");
        [self stopRecording];
        return;
    } else if (error) {
        NSLog(@"encounted an error in video capture (%@)", error);
        [self stopRecording];
        return;
    }

    _currentVideo = videoDict;
    
    NSString *videoPath = [_currentVideo  objectForKey:PBJVisionVideoPathKey];

    NSLog(@"videoPath= %@",videoPath);
    
    NSURL *videoURL =  [NSURL fileURLWithPath:videoPath];
    
    NSData *videoData = [NSData dataWithContentsOfURL:videoURL];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    
    if (![fm fileExistsAtPath:VIDEO_RECORDING_FOLDER]){
        
        [fm createDirectoryAtPath:VIDEO_RECORDING_FOLDER
      withIntermediateDirectories:YES
                       attributes:nil
                            error:NULL];
    }

    
    NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
    if ([fm fileExistsAtPath:tempPath]) {
        [fm removeItemAtPath:tempPath error:nil];
    }
    
    _flipButton.enabled = TRUE;
    
    BOOL success = [videoData writeToFile:tempPath atomically:NO];
    
    AVAsset *myAsset = [[AVURLAsset alloc] initWithURL:[NSURL fileURLWithPath:videoPath] options:nil];
    AVAssetTrack *VideoTrack = [[myAsset tracksWithMediaType:AVMediaTypeVideo] lastObject];
    CGAffineTransform txf = [VideoTrack preferredTransform];
    appDelegate.videoPrefferedTransform = txf;

    NSLog(@"success=%d, %f",success,CMTimeGetSeconds(myAsset.duration));

    _gestureView.hidden = NO;
 //   seconds = 8;
    NSLog(@"label-%@",lblTimer.text);
    //        lblTimer.text = @"";
    [self _resetCapture];
    
    
    NSLog(@"%@",self.isShouldMerge?@"true":@"false");
    if (self.isShouldMerge) {
        [self MoveToTrimVC];
    }
}

-(void)stopRecording{
    
    [AlertHandler alertTitle:INFO message:@"Sorry, recording did not initiate. Please try again." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    [timer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIDeviceOrientationDidChangeNotification object:nil];
    
    self.seconds = 15.0;
    butDone.hidden = YES;
    _flipButton.enabled = YES;
    _gestureView.hidden = NO;
    _longPressGestureRecognizer.enabled = YES;
    lblTimer.text = [NSString stringWithFormat:@"00:15"];
    self.isRecordingStarted = NO;
    
    [self _handleDoneButton:nil];
}

// progress

- (void)vision:(PBJVision *)vision didCaptureVideoSampleBuffer:(CMSampleBufferRef)sampleBuffer
{
    NSLog(@"captured audio (%f) seconds", vision.capturedAudioSeconds);
    if (![timer isValid]) {
        if (!self.isPaused) {
            [self startTimer];
        }
    }
}

- (void)vision:(PBJVision *)vision didCaptureAudioSample:(CMSampleBufferRef)sampleBuffer
{
//    NSLog(@"captured video (%f) seconds", vision.capturedVideoSeconds);
}

@end
