//
//  VideoListVCHBlab.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/15/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "VideoListVCHBlab.h"
#import "CaptureImageVC.h"
#import "PBJViewControllerHBlab.h"

#import "PBJStrobeView.h"
#import "PBJFocusView.h"

#import "PBJVision.h"
#import "PBJVisionUtilities.h"

#import <AssetsLibrary/AssetsLibrary.h>
#import <GLKit/GLKit.h>

#import "VideoListVC.h"

#import "SetVideoAndPrivacyHBlabVC.h"
#import "MBProgressHUD.h"

#define degreesToRadians(x) (M_PI * x / 180.0)
#define radiansToDegrees(x) (180.0 * x / M_PI)

#define DATE_COMPONENTS (NSYearCalendarUnit| NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit | NSWeekdayCalendarUnit |NSWeekdayOrdinalCalendarUnit)
#define CURRENT_CALENDAR [NSCalendar currentCalendar]


#define VIDEO_EXTENSION			@"mp4"
#define filterFilePath          @"newvdo.mp4"

@interface VideoListVCHBlab ()<MBProgressHUDDelegate> {
    MBProgressHUD *HUD;
}

@property (strong, nonatomic) SAVideoRangeSlider *mySAVideoRangeSlider;
@property (strong, nonatomic) IBOutlet UILabel *timeLabel;
@property (strong, nonatomic) AVAssetExportSession *exportSession;
@property (strong, nonatomic) NSString *originalVideoPath;
@property (strong, nonatomic) NSString *tmpVideoPath;
@property (nonatomic,assign) CGFloat startTime;
@property (nonatomic,assign) CGFloat stopTime;
//@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *myActivityIndicator;
@property (strong, nonatomic) IBOutlet UIButton *trimBtn;
@end

@implementation VideoListVCHBlab
@synthesize mySAVideoRangeSlider;
@synthesize timeLabel;
@synthesize exportSession;
@synthesize originalVideoPath;
//@synthesize myActivityIndicator;
@synthesize trimBtn;
@synthesize tmpVideoPath;
@synthesize startTime;
@synthesize stopTime;
@synthesize imageVideoThumb;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    appDelegat = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    
    if ([self respondsToSelector:@selector(setNeedsStatusBarAppearanceUpdate)]) {
        // iOS 7
        [self performSelector:@selector(setNeedsStatusBarAppearanceUpdate)];
    } else {
        // iOS 6
        [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];
    }
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    
    if (![fm fileExistsAtPath:VIDEO_RECORDING_FOLDER]){
        
        [fm createDirectoryAtPath:VIDEO_RECORDING_FOLDER
      withIntermediateDirectories:YES
                       attributes:nil
                            error:NULL];
    }
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    
    self.originalVideoPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
    vedioURL =[NSURL fileURLWithPath:self.originalVideoPath];
    
    NSLog(@"vurl %@",vedioURL);
    
    HUD.mode = MBProgressHUDModeText;
    HUD.detailsLabelText = @"Please wait\nGenerating Preview..";
    
    
    [HUD show:YES];
    [self SetVideoOrientationForSelection];
    
    viewlbl.hidden = YES;
    self.mySAVideoRangeSlider.hidden = YES;
    
    appDelegate.currentVc = self;
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
    
    
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}


-(void)viewWillAppear:(BOOL)animated{
    
    appDelegate.currentVc = self;
    
    [viewlbl setAlpha:0.7];
    viewlbl.backgroundColor = UIColorFromRGB(0X00c2d9);
    viewlbl.layer.cornerRadius = 5;
    viewlbl.layer.masksToBounds = YES;
    
    lblTime.font = [UIFont fontWithName:Font_Montserrat_Regular size:16.0f];
    lblTime.textColor = [UIColor whiteColor];
    lblTime.backgroundColor = [UIColor clearColor];
    lblTime.textAlignment = NSTextAlignmentCenter;
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self MoviePlayerRemoveObserver];
    [self.moviePlayer.view removeFromSuperview];
    self.moviePlayer = nil;
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
}


-(void)CallMethod{
    
    // self.myActivityIndicator.hidden = YES;
    [HUD hide:YES];
    
    NSURL *videoFileUrl = [NSURL fileURLWithPath:self.originalVideoPath];
    
    AVURLAsset *movieAsset=[AVURLAsset URLAssetWithURL:videoFileUrl options:nil];
    CMTime duration = movieAsset.duration;
    
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        
        self.mySAVideoRangeSlider = [[SAVideoRangeSlider alloc] initWithFrame:CGRectMake(10, 200, self.view.frame.size.width, 70) videoUrl:videoFileUrl ];
        [self.mySAVideoRangeSlider setPopoverBubbleSize:200 height:100];
        
    } else {
        
        self.mySAVideoRangeSlider = [[SAVideoRangeSlider alloc] initWithFrame:CGRectMake(0, 400, self.view.frame.size.width, 80) videoUrl:videoFileUrl];
        self.mySAVideoRangeSlider.bubleText.font = [UIFont systemFontOfSize:12];
        [self.mySAVideoRangeSlider setPopoverBubbleSize:120 height:60];
    }
    float timeDuration,roundUptime,totalrecduration;
    if (appDelegate.is90SecondsVideoRec) {
        [self.mySAVideoRangeSlider setMinGap:10];
        timeDuration = 90.5;
        roundUptime = 89.3;
        totalrecduration = totalRecordingDuration_Hblab;
    }
    else{
        [self.mySAVideoRangeSlider setMinGap:3];
        timeDuration = 15.5;
        roundUptime = 9.3;
        totalrecduration = totalRecordingDuration;
    }
    
    
    if (CMTimeGetSeconds(duration) > timeDuration) {
        [self.mySAVideoRangeSlider setMaxGap:timeDuration];
    }
    else{
        [self.mySAVideoRangeSlider setMaxGap:CMTimeGetSeconds(duration)];
    }
    self.mySAVideoRangeSlider.delegate = self;
    
    self.mySAVideoRangeSlider.topBorder.backgroundColor =  UIColorFromRGB(0X00c2d9);
    self.mySAVideoRangeSlider.bottomBorder.backgroundColor = UIColorFromRGB(0X00c2d9);
    
    NSLog(@"%f",CMTimeGetSeconds(duration));
    
    float totalSeconds = CMTimeGetSeconds(duration);
    
    int min = (int)totalSeconds/60;
    int sec = (int)totalSeconds % 60;
    if (min<10) {
        lblTime.text = [NSString stringWithFormat:@"0%d:",min];
    }
    else{
        lblTime.text = [NSString stringWithFormat:@"%d:",min];
    }
    if (totalSeconds<9.5 || sec<10) {
        lblTime.text = [lblTime.text stringByAppendingFormat:@"0%d",sec];
    }
    else if (totalSeconds>roundUptime && totalSeconds<totalrecduration){
        if (appDelegate.is90SecondsVideoRec) {
            lblTime.text = [lblTime.text stringByAppendingString:@"30"];
        }
        else{
            lblTime.text = [lblTime.text stringByAppendingString:@"15"];
        }
    }
    else{
        lblTime.text = [lblTime.text stringByAppendingFormat:@"%d",sec];
    }
    
    //  [self.mySAVideoRangeSlider setMaxGap:8];
    //    self.mySAVideoRangeSlider.rightPosition = 5.0;
    
    [self.view addSubview:self.mySAVideoRangeSlider];
    
    self.mySAVideoRangeSlider.hidden = FALSE;
    viewlbl.hidden = FALSE;
    
    self.startTime = 0.0;
    self.stopTime = self.mySAVideoRangeSlider.rightPosition;
    [self btnPlayClicked];
}

#pragma mark - IBAction

-(void)btnPlayClicked{
    
    [self MoviePlayerRemoveObserver];
    
    self.moviePlayer = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL fileURLWithPath:self.originalVideoPath]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:MPMoviePlayerDidExitFullscreenNotification
                                               object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(MPMovieDurationAvailable:)
                                                 name:MPMovieDurationAvailableNotification
                                               object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(MPMoviePlayerPlaybackStateDidChange:)
                                                 name:MPMoviePlayerPlaybackStateDidChangeNotification
                                               object:self.moviePlayer.moviePlayer];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(MPMoviewPlayerLoadStateDidChange:)
                                                 name:MPMoviePlayerLoadStateDidChangeNotification
                                               object:self.moviePlayer.moviePlayer];
    
    
    self.moviePlayer.moviePlayer.shouldAutoplay = YES;
    
    [self.view addSubview:self.moviePlayer.view];
    [self.view sendSubviewToBack:self.moviePlayer.view];
    
    self.imageVideoThumb.hidden = YES;
    [self.moviePlayer.moviePlayer prepareToPlay];
    
    self.moviePlayer.view.frame = CGRectMake(0, 63, 320, 320);
    self.moviePlayer.moviePlayer.controlStyle = MPMovieControlStyleNone;
    
    [self.moviePlayer.moviePlayer play];
    //    self.moviePlayer.moviePlayer.scalingMode = MPMovieScalingModeAspectFit;
    
    self.moviePlayer.moviePlayer.initialPlaybackTime = (float)self.startTime;
    if ([self.playTimer isValid]) {
        [self.playTimer invalidate];
    }
    self.playTimer = [NSTimer scheduledTimerWithTimeInterval:self.stopTime-self.startTime target:self selector:@selector(stopSliderVideoPlay) userInfo:nil repeats:NO];
    
    
}

- (IBAction)showOriginalVideo:(id)sender {
    
    [self playMovie:self.originalVideoPath];
    
}

-(IBAction)btnGoNext2:(id)sender{
    
    UISaveVideoAtPathToSavedPhotosAlbum( self.originalVideoPath, nil, nil, nil);
    
    
    AVURLAsset *videoasset = [[AVURLAsset alloc]initWithURL:[NSURL fileURLWithPath:self.originalVideoPath] options:nil];
    
    //ONLY IF WE ADDED TEXT
    
    //    CGSize videoSize = CGSizeMake(460, 310);
    //
    //    AVMutableVideoComposition* videoComp = [AVMutableVideoComposition videoComposition];
    //    videoComp.renderSize = videoSize;
    //    videoComp.frameDuration = CMTimeMake(1, 30);
    
    AVMutableComposition *mixComposition = [AVMutableComposition composition];
    
    //Recorded  video
    AVMutableCompositionTrack *compositionVideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo preferredTrackID:kCMPersistentTrackID_Invalid];
    
    AVAssetTrack *VideoTrack = [[videoasset tracksWithMediaType:AVMediaTypeVideo] lastObject];
    
    //  CGSize videoSize = CGSizeMake(460, 310);
    
    AVMutableVideoComposition* videoComp = [AVMutableVideoComposition videoComposition];
    videoComp.renderSize = [VideoTrack naturalSize];
    videoComp.frameDuration = CMTimeMake(1, 30);
    
    NSLog(@"vieoSize = %@",NSStringFromCGSize([VideoTrack naturalSize]));
    
    [compositionVideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration)  ofTrack:VideoTrack atTime:kCMTimeZero error:nil];
    
    // Audio of Video
    AVMutableCompositionTrack *compositionVideoAudio = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
    
    AVAssetTrack *VideoAudioTrack = [[videoasset tracksWithMediaType:AVMediaTypeAudio] lastObject];
    [compositionVideoAudio insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration)  ofTrack:VideoAudioTrack atTime:kCMTimeZero error:nil];
    
    self.tmpVideoPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov11.mp4"];
    
    [self deleteTmpFile];
    
    NSURL *videoFileUrl = [NSURL fileURLWithPath:self.originalVideoPath];
    
    AVMutableVideoCompositionInstruction *instruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
    instruction.timeRange = CMTimeRangeMake(kCMTimeZero, [mixComposition duration]);
    AVAssetTrack *videoTrack = [[mixComposition tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
    AVMutableVideoCompositionLayerInstruction* layerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoTrack];
    
    
    CGAffineTransform t1;
    CGAffineTransform t2;
    CGAffineTransform txf = [videoTrack preferredTransform];
    
    /*
     
     if (txf.a == -1) {	//landscape left
     orientaion = UIImageOrientationUp;
     }
     else if (txf.a == 1){	//landscape right
     orientaion = UIImageOrientationDown;
     }
     else if (txf.c == 1){	//portrait button up
     orientaion = UIImageOrientationLeft;
     }
     else if (txf.c == -1){		//portrait button down
     orientaion = UIImageOrientationRight;
     }
     
     */
    
    
    if (txf.a == -1) {	//landscape left
        //        t1 = CGAffineTransformMakeTranslation(DEVICE_HEIGHT, DEVICE_WIDTH);
        t2 = CGAffineTransformRotate(t1, degreesToRadians(-90.0));
        t2 = CGAffineTransformRotate(t2, degreesToRadians(-90.0));
        
        if (self.orientation == 1) {
            //            t2 = CGAffineTransformRotate(t1, degreesToRadians(-90.0));
            //            t2 = CGAffineTransformRotate(t2, degreesToRadians(-90.0));
            //t2 = CGAffineTransformScale(t2, 1.3, 1);
        }
        else if (self.orientation == 2){
            //          t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
        }
    }
    else if (txf.a == 1){	//landscape right
        NSLog(@"Landscape right");
        
        //        t1 = CGAffineTransformMakeRotation(degreesToRadians(90.0));
        //        t2 = CGAffineTransformTranslate(t1, 2*DEVICE_HEIGHT, 0);
        
        //        t1 = CGAffineTransformMakeTranslation([VideoTrack naturalSize].height,0);
        //        t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
        //        t2 = CGAffineTransformScale(t2, 1.3, 1);
    }
    else if (txf.c == 1){	//portrait button up
        NSLog(@"Portrait up");
        
    }
    else if (txf.c == -1){		//portrait button down
        NSLog(@"portrait button down");
    }
    //   [layerInstruction setTransform:t2 atTime:kCMTimeZero];
    
    instruction.layerInstructions = [NSArray arrayWithObject:layerInstruction];
    videoComp.instructions = [NSArray arrayWithObject: instruction];
    
    
    AVAsset *anAsset = [[AVURLAsset alloc] initWithURL:videoFileUrl options:nil];
    NSArray *compatiblePresets = [AVAssetExportSession exportPresetsCompatibleWithAsset:anAsset];
    if ([compatiblePresets containsObject:AVAssetExportPresetMediumQuality]) {
        
        //self.exportSession = [[AVAssetExportSession alloc]
        //                    initWithAsset:anAsset presetName:AVAssetExportPresetHighestQuality];
        self.exportSession =[[AVAssetExportSession alloc] initWithAsset:mixComposition presetName:AVAssetExportPresetHighestQuality] ;//
        self.exportSession.videoComposition = videoComp;
        
        // Implementation continues.
        
        NSURL *furl = [NSURL fileURLWithPath:self.tmpVideoPath];
        self.exportSession.outputURL = furl;
        self.exportSession.outputFileType = AVFileTypeQuickTimeMovie;
        self.trimBtn.hidden = YES;
        [HUD show:YES];
        //        self.myActivityIndicator.hidden = NO;
        //        [self.myActivityIndicator startAnimating];
        [self.exportSession exportAsynchronouslyWithCompletionHandler:^{
            
            switch ([self.exportSession status]) {
                case AVAssetExportSessionStatusFailed:
                    NSLog(@"Export failed: %@", [[self.exportSession error] localizedDescription]);
                    break;
                case AVAssetExportSessionStatusCancelled:
                    NSLog(@"Export canceled");
                    break;
                default:{
                    NSLog(@"NONE");
                    NSFileManager *fm = [NSFileManager defaultManager];
                    
                    if ([fm fileExistsAtPath:self.tmpVideoPath]){
                        
                        NSLog(@"fileexis");
                        UISaveVideoAtPathToSavedPhotosAlbum(self.tmpVideoPath, nil, nil, nil);
                    }
                    
                    ////////////            Done by kunal for new video recording hang after uploding and blab send 15-04-2015
                    appDelegate.FlagVideo = 0;
                    
                    for (UIViewController *obj in [self.navigationController viewControllers]) {
                        
                        if ([obj isKindOfClass:[PBJViewControllerHBlab class]]) {
                            PBJViewControllerHBlab *obj12 = (PBJViewControllerHBlab *)obj;
                            [obj12 handleFlipButtonCancelBtn];
                            //                                [self.navigationController popToViewController:obj animated:YES];
                        }
                    }
                    /////////////
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [HUD hide:YES];
                        //                        [self.myActivityIndicator stopAnimating];
                        //                        self.myActivityIndicator.hidden = YES;
                        self.trimBtn.hidden = NO;
                        [self playMovie:self.tmpVideoPath];
                    });
                }
                    break;
            }
        }];
    }
}

-(void)SetVideoOrientationForSelection{
    
    NSString *str = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov11.mp4"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:str]) {
        [[NSFileManager defaultManager] removeItemAtPath:str error:nil];
    }
    
    if (appDelegate.isRecordingFromCamera) {
        
        AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
        NSDictionary *options = @{AVURLAssetPreferPreciseDurationAndTimingKey:@YES};
        
        AVURLAsset *videoasset = [[AVURLAsset alloc]initWithURL:[NSURL fileURLWithPath:self.originalVideoPath] options:options];
        
        //Recorded  video
        AVMutableCompositionTrack *compositionVideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo
                                                                                       preferredTrackID:kCMPersistentTrackID_Invalid];
        
        // Audio of Video
        AVMutableCompositionTrack *compositionAudioTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio
                                                                                       preferredTrackID:kCMPersistentTrackID_Invalid];
        
        
        
        [compositionVideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration)
                                       ofTrack:[[videoasset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]
                                        atTime:kCMTimeZero error:nil];
        
        //-----
        [compositionAudioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration)
                                       ofTrack:[[videoasset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]
                                        atTime:kCMTimeZero error:nil];
        
        
        AVAssetTrack *videoTrack = [[mixComposition tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
        
        //        UIImage *myImage = [UIImage imageNamed:@"app_logo.png"];
        //        CALayer *aLayer = [CALayer layer];
        //        aLayer.contents = (id)myImage.CGImage;
        //        aLayer.frame = CGRectMake(175,25,117,52); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
        //        aLayer.opacity = 1;
        NSLog(@"natural - %@",NSStringFromCGSize([videoTrack naturalSize]));
        
        CGSize videoSize;
//        if (appDelegat.CameraOrientationForVideo==4) {    // open this comment if need to change video orientation forcefully to portrait
            videoSize = CGSizeMake([videoTrack naturalSize].width, [videoTrack naturalSize].height);
            
/* // open this comment if need to change video orientation forcefully to portrait       }
        else{
            videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_WIDTH);
        }
*/
        //        CALayer *parentLayer = [CALayer layer];
        //        CALayer *videoLayer = [CALayer layer];
        
        AVMutableVideoCompositionLayerInstruction* layerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoTrack];
        
        AVMutableVideoCompositionInstruction *instruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
        instruction.timeRange = CMTimeRangeMake(kCMTimeZero, [mixComposition duration]);
        
        AVMutableVideoComposition* videoComp = [AVMutableVideoComposition videoComposition];
        
/*
 // open this comment if need to change video orientation forcefully to portrait
        CGAffineTransform t1;
        CGAffineTransform t2;
        
        t1 = CGAffineTransformIdentity;
        
        if (appDelegate.CameraOrientationForVideo == 4) {
            //dont rotate
            //PBJCameraOrientationPortrait
            NSLog(@"PBJCameraOrientationPortrait");
            t2 = CGAffineTransformScale(t1, 1, 1);
        }
        else if (appDelegate.CameraOrientationForVideo == 1){
            //                PBJCameraOrientationPortraitUpsideDown
            NSLog(@"PBJCameraOrientationPortraitUpsideDown");
            //videoSize = CGSizeMake(DEVICE_HEIGHT, DEVICE_HEIGHT);
            t1 = CGAffineTransformTranslate(t1,videoSize.height, 0);
            t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
            t2 = CGAffineTransformTranslate(t2, videoSize.height, 0);
            t2 = CGAffineTransformRotate(t2, degreesToRadians(90.0));
        }
        else if (appDelegate.CameraOrientationForVideo == 2){
            //                PBJCameraOrientationLandscapeRight
            videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_WIDTH);
            NSLog(@"PBJCameraOrientationLandscapeRight");
            t1 = CGAffineTransformTranslate(t1,0, videoSize.width);
            t2 = CGAffineTransformRotate(t1, degreesToRadians(-90.0));
            t2 = CGAffineTransformScale(t2, 1.0, 1.0);
        }
        else if (appDelegate.CameraOrientationForVideo == 3){
            //                PBJCameraOrientationLandscapeLeft
            NSLog(@"PBJCameraOrientationLandscapeLeft");
            
            videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_WIDTH);
            
            t1 = CGAffineTransformTranslate(t1,videoSize.width, 0);
            t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
            t2 = CGAffineTransformScale(t2, 1, 1);
        }
*/
        
        //        parentLayer.frame = CGRectMake(0, 0, videoSize.width, videoSize.height);
        //        videoLayer.frame = CGRectMake(0, 0, videoSize.width, videoSize.height);
        videoComp.renderSize = videoSize;   //CGSizeMake(DEVICE_WIDTH, DEVICE_HEIGHT);
        
        
        //        [parentLayer addSublayer:videoLayer];
        //        [parentLayer addSublayer:aLayer];
        
        videoComp.frameDuration = CMTimeMake(1, 30);
        //   videoComp.animationTool = [AVVideoCompositionCoreAnimationTool videoCompositionCoreAnimationToolWithPostProcessingAsVideoLayer:videoLayer inLayer:parentLayer];
/* 
 // open this comment if need to change video orientation forcefully to portrait
        if (appDelegat.CameraOrientationForVideo != 4) {
            [layerInstruction setTransform:t2 atTime:kCMTimeZero];
        }
*/
        
        instruction.layerInstructions = [NSArray arrayWithObject:layerInstruction];
        videoComp.instructions = [NSArray arrayWithObject: instruction];
        
        self.exportSession = [[AVAssetExportSession alloc]
                              initWithAsset:mixComposition presetName:AVAssetExportPresetHighestQuality];
        // Implementation continues.
        
        NSString *strNewPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov2.mp4"];
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:strNewPath]) {
            [[NSFileManager defaultManager] removeItemAtPath:strNewPath error:nil];
        }
        
        
        NSURL *furl = [NSURL fileURLWithPath:strNewPath];
/*
        CMTime start = kCMTimeZero;  //CMTimeMakeWithSeconds(0, mixComposition.duration.timescale);
        CMTime duration = mixComposition.duration;
        float maxDuration = CMTimeGetSeconds(duration);
        if (appDelegat.is90SecondsVideoRec) {
            maxDuration = (maxDuration>totalRecordingDuration_Hblab)?totalRecordingDuration_Hblab:maxDuration;
        }
        else{
            maxDuration = (maxDuration>totalRecordingDuration)?totalRecordingDuration:maxDuration;
        }
        CMTime duration1 = CMTimeMakeWithSeconds(maxDuration, mixComposition.duration.timescale);
        CMTimeRange range = CMTimeRangeMake(start, duration1);
        self.exportSession.timeRange = range;
*/
        self.exportSession.outputURL = furl;
        self.originalVideoPath = strNewPath;
        self.exportSession.outputFileType = AVFileTypeMPEG4;
        
        self.exportSession.videoComposition = videoComp;
        self.exportSession.shouldOptimizeForNetworkUse = YES;
        self.trimBtn.hidden = YES;
        [self.exportSession exportAsynchronouslyWithCompletionHandler:^{
            
            switch ([self.exportSession status]) {
                case AVAssetExportSessionStatusFailed:
                    [HUD hide:YES];
                    NSLog(@"Export failed: %@", [[self.exportSession error] localizedDescription]);
                    break;
                case AVAssetExportSessionStatusCancelled:
                    [HUD hide:YES];
                    NSLog(@"Export canceled");
                    break;
                default:{
                    NSLog(@"NONE");
                    NSFileManager *fm = [NSFileManager defaultManager];
                    
                    if ([fm fileExistsAtPath:self.tmpVideoPath]){
                        NSLog(@"fileexis");
                    }
                    ////////////            Done by kunal for new video recording hang after uploding and blab send 15-04-2015
                    appDelegate.FlagVideo = 0;
                    
                    for (UIViewController *obj in [self.navigationController viewControllers]) {
                        
                        if ([obj isKindOfClass:[PBJViewControllerHBlab class]]) {
                            PBJViewControllerHBlab *obj12 = (PBJViewControllerHBlab *)obj;
                            [obj12 handleFlipButtonCancelBtn];
                        }
                    }
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        //                        AVURLAsset *asset = [[AVURLAsset alloc] initWithURL:furl options:nil];
                        //                        AVAssetImageGenerator *generate = [[AVAssetImageGenerator alloc] initWithAsset:asset];
                        //                        generate.appliesPreferredTrackTransform = YES;
                        //                        NSError *err = NULL;
                        //                        CMTime time = CMTimeMake(1, 30);
                        //                        CGImageRef imgRef = [generate copyCGImageAtTime:time actualTime:NULL error:&err];
                        //
                        //                        UIImage *img = [[UIImage alloc] initWithCGImage:imgRef];
                        //
                        //                        img = [self fixrotation:img];
                        //                        NSLog(@"image size = %f",img.size.width);
                        //                        NSLog(@"image size = %f",img.size.height);
                        //                        imageVideoThumb.image = img;
                        
                        [self CallMethod];
                    });
                }
                    break;
            }
        }];
        
    }
    else{
        
        //        [self mergeST_and_Song];
        //        return;
        
        
        AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
        
        //        NSURL* sourceMovieURL = [NSURL fileURLWithPath:self.originalVideoPath];
        //------ create Audio and Video Assets
        NSDictionary *options = @{AVURLAssetPreferPreciseDurationAndTimingKey:@YES};
        
        AVURLAsset *videoasset = [[AVURLAsset alloc]initWithURL:[NSURL fileURLWithPath:self.originalVideoPath] options:options];
        AVAssetTrack *assetTrack = [[videoasset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
        CMTime duration = assetTrack.timeRange.duration;
        
        NSError *error = nil;
        
        // Audio of Video
        AVMutableCompositionTrack *compositionAudioTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio
                                                                                       preferredTrackID:kCMPersistentTrackID_Invalid];
        
        
        //Recorded  video
        AVMutableCompositionTrack *compositionVideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo
                                                                                       preferredTrackID:kCMPersistentTrackID_Invalid];
        
        
        
        //-----
        [compositionAudioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, duration)
                                       ofTrack:[[videoasset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]
                                        atTime:kCMTimeZero error:nil];
        
        
        [compositionVideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, duration)
                                       ofTrack:[[videoasset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]
                                        atTime:kCMTimeZero error:nil];
        
        if (error) {
            NSLog(@"%@",error.description);
        }
        
        NSMutableArray *audioMixParams = [[NSMutableArray alloc] init];
        // Add Audio of video
        CMTime startTime1 = CMTimeMakeWithSeconds(0, 1);
        AVMutableAudioMixInputParameters *trackMix1 = [AVMutableAudioMixInputParameters audioMixInputParametersWithTrack:compositionAudioTrack];
        [trackMix1 setVolume:1 atTime:startTime1];
        [audioMixParams addObject:trackMix1];
        AVMutableAudioMix *audioMix = [AVMutableAudioMix audioMix];
        audioMix.inputParameters = [NSArray arrayWithArray:audioMixParams];
        
        //-------------
        
        
        AVAssetTrack *videoTrack = [[mixComposition tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
        
        //        UIImage *myImage = [UIImage imageNamed:@"app_logo.png"];
        //        CALayer *aLayer = [CALayer layer];
        //        aLayer.contents = (id)myImage.CGImage;
        //        //aLayer.opacity = 0.65; //Feel free to alter the alpha here'
        //        aLayer.opacity = 1;
        //        NSLog(@"%@",NSStringFromCGSize([videoTrack naturalSize]));
        CGSize videoSize = CGSizeMake([videoTrack naturalSize].width, [videoTrack naturalSize].height);
        float videoWidth = videoSize.width;
        
        //        CALayer *parentLayer = [CALayer layer];
        //        CALayer *videoLayer = [CALayer layer];
        
        
        
        AVMutableVideoCompositionInstruction *instruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
        instruction.timeRange = CMTimeRangeMake(kCMTimeZero,  duration);
        
        AVMutableVideoCompositionLayerInstruction* layerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoTrack];
        
        AVMutableVideoComposition* videoComp = [AVMutableVideoComposition videoComposition];
        videoComp.frameDuration = CMTimeMake(1, 30);
        
        
        //        AVMutableVideoCompositionLayerInstruction* layerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoTrack];
        //
        //        AVMutableVideoCompositionInstruction *instruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
        //        instruction.timeRange = CMTimeRangeMake(kCMTimeZero, [mixComposition duration]);
        //
        //        AVMutableVideoComposition* videoComp = [AVMutableVideoComposition videoComposition];
/*
 // open this comment if need to change video orientation forcefully to portrait
        CGAffineTransform t1;
        CGAffineTransform t2;
        CGAffineTransform txf = appDelegate.videoPrefferedTransform;
        
        if (txf.a == -1) {	//landscape left        - DONE
            if (videoWidth == 320 || videoWidth == 360 || videoWidth <= DEVICE_WIDTH || videoWidth <= DEVICE_HEIGHT) {
                //     aLayer.frame = CGRectMake(175,25,117,52); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_WIDTH);
                
                t1 = CGAffineTransformMakeTranslation(DEVICE_WIDTH, 0);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                t2 = CGAffineTransformTranslate(t2, DEVICE_WIDTH, 0);
                t2 = CGAffineTransformRotate(t2, degreesToRadians(90.0));
                t2 = CGAffineTransformScale(t2, 1, 1);
            }
            else{
                if (videoWidth==720) {
                    //720
                    //            aLayer.frame = CGRectMake(175*3,25*2,117*2,52*2); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                    
                    videoSize = CGSizeMake(720, 720);
                    t1 = CGAffineTransformMakeTranslation(720, 100);
                    t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                    t2 = CGAffineTransformTranslate(t2, 568+(DEVICE_WIDTH/2), 0);
                    t2 = CGAffineTransformRotate(t2, degreesToRadians(90.0));
                    t2 = CGAffineTransformScale(t2, 1, 1);
                }
                else{
                    //1280
                    //        aLayer.frame = CGRectMake(175*4,25*3,117*3,52*3); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                    
                    videoSize = CGSizeMake(1280, 1280);
                    t1 = CGAffineTransformMakeTranslation(1280, 100);
                    t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                    t2 = CGAffineTransformTranslate(t2, 720+(DEVICE_WIDTH/2), 0);
                    t2 = CGAffineTransformRotate(t2, degreesToRadians(90.0));
                    t2 = CGAffineTransformScale(t2, 1, 1);
                }
            }
        }
        else if (txf.a == 1){	//landscape right       - DONE
            if (videoWidth == 320 || videoWidth == 360  || videoWidth <= DEVICE_WIDTH || videoWidth <= DEVICE_HEIGHT) {
                //        aLayer.frame = CGRectMake(175,25,117,52); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_WIDTH);
                t2 = CGAffineTransformMakeTranslation(0, 0);
                t2 = CGAffineTransformScale(t2, 1.0, 1.0);
            }
            else{
                if (videoWidth == 720) {
                    //           aLayer.frame = CGRectMake(175*3,25*2,117*2,52*2); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                    videoSize = CGSizeMake(720, 720);
                    t2 = CGAffineTransformMakeTranslation(0, 0);
                    t2 = CGAffineTransformScale(t2, 1.0, 1.0);
                }
                else{
                    //1280
                    //        aLayer.frame = CGRectMake(175*4,25*3,117*3,52*3); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                    videoSize = CGSizeMake(1280, 1280);
                    t2 = CGAffineTransformMakeTranslation(0, 300);
                    t2 = CGAffineTransformScale(t2, 1.0, 1.0);
                }
            }
        }
        else if (txf.c == 1){	//portrait button up
            if (videoWidth == 320 || videoWidth == 360 || videoWidth <= DEVICE_WIDTH || videoWidth <= DEVICE_HEIGHT) {
                //     aLayer.frame = CGRectMake(175,25,117,52); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_WIDTH);
                t1 = CGAffineTransformMakeTranslation(0, videoSize.width);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(-90.0));
                t2 = CGAffineTransformScale(t2, 1, 1);
            }
            else{
                if (videoWidth == 720) {
                    //         aLayer.frame = CGRectMake(175*2,25*2,117*2,52*2); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                    videoSize = CGSizeMake(720, 1280);
                    
                    t1 = CGAffineTransformMakeTranslation(0, videoSize.width);
                    t2 = CGAffineTransformRotate(t1, degreesToRadians(-90.0));
                    t2 = CGAffineTransformScale(t2, 1, 1);
                }
                else{
                    //          aLayer.frame = CGRectMake(175*2,25*2,117*2,52*2); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                    videoSize = CGSizeMake(1280, 720);
                    
                    t1 = CGAffineTransformMakeTranslation(0, videoSize.width);
                    t2 = CGAffineTransformRotate(t1, degreesToRadians(-90.0));
                    t2 = CGAffineTransformScale(t2, 1, 1);
                }
            }
        }
        else if (txf.c == -1){		//portrait button down      - DONE
            if (videoWidth == 320 || videoWidth == 360 || videoWidth <= DEVICE_WIDTH || videoWidth <= DEVICE_HEIGHT) {
                //       aLayer.frame = CGRectMake(175,25,117,52); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_WIDTH);
                
                t1 = CGAffineTransformMakeTranslation(videoSize.height, 0);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                t2 = CGAffineTransformScale(t2, 1, 1);
            }
            else{
                if (videoWidth == 720) {
                    //720
                    //           aLayer.frame = CGRectMake(175*2,25*2,117*2,52*2);
                    
                    t1 = CGAffineTransformMakeTranslation(videoSize.height, 0);
                    t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                    t2 = CGAffineTransformScale(t2, 1, 1);
                }
                else{
                    //1280
                    //          aLayer.frame = CGRectMake(175*2,25*2,117*2,52*2);
                    
                    t1 = CGAffineTransformMakeTranslation(videoSize.height, 0);
                    t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                    t2 = CGAffineTransformScale(t2, 1, 1);
                }
            }
        }
        else{
            //all 0
            t2 = CGAffineTransformMakeTranslation(0, 100);
        }
        
        
        if (videoWidth==320 || videoWidth == 360  || videoWidth <= DEVICE_WIDTH || videoWidth <= DEVICE_HEIGHT) {
            //            parentLayer.frame = CGRectMake(0, 0, videoSize.width, videoSize.height);
            //            videoLayer.frame = CGRectMake(0, 0, videoSize.width, videoSize.height);
            videoComp.renderSize = videoSize;
        }
        else{
            if (videoWidth == 720) {
                //                parentLayer.frame = CGRectMake(0, 0, videoSize.height, 1280);
                //                videoLayer.frame = CGRectMake(0, 0, videoSize.height, 1280);
                videoComp.renderSize = CGSizeMake(videoSize.height, 1280);
            }else{
                //                parentLayer.frame = CGRectMake(0, 0, videoSize.height, 1280);
                //                videoLayer.frame = CGRectMake(0, 0, videoSize.height, 1280);
                videoComp.renderSize = CGSizeMake(videoSize.height, 1280);
            }
        }
        
        //        [parentLayer addSublayer:videoLayer];
        //        [parentLayer addSublayer:aLayer];
        //
        //        videoComp.animationTool = [AVVideoCompositionCoreAnimationTool videoCompositionCoreAnimationToolWithPostProcessingAsVideoLayer:videoLayer inLayer:parentLayer];
        
        
        [layerInstruction setTransform:t2 atTime:kCMTimeZero];
*/
        videoComp.renderSize = videoSize; // comment this if need to change video orientation forcefully to portrait
        
        videoComp.frameDuration = CMTimeMake(1, 30); // comment this if need to change video orientation forcefully to portrait
        
        instruction.layerInstructions = [NSArray arrayWithObject:layerInstruction];
        videoComp.instructions = [NSArray arrayWithObject: instruction];
        
        self.exportSession = [[AVAssetExportSession alloc]
                              initWithAsset:mixComposition presetName:AVAssetExportPresetHighestQuality];
        // Implementation continues.
        
        NSString *strNewPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov2.mp4"];
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:strNewPath]) {
            [[NSFileManager defaultManager] removeItemAtPath:strNewPath error:nil];
        }
        
        //-----
        NSURL *furl = [NSURL fileURLWithPath:strNewPath];
        
        /*
         CMTime start = kCMTimeZero;  //CMTimeMakeWithSeconds(0, mixComposition.duration.timescale);
         CMTime duration = mixComposition.duration;
         float maxDuration = CMTimeGetSeconds(duration);
         //        maxDuration = (maxDuration>totalRecordingDuration)?totalRecordingDuration:maxDuration;
         CMTime duration1 = CMTimeMakeWithSeconds(maxDuration, mixComposition.duration.timescale);
         CMTimeRange range = CMTimeRangeMake(start, duration1);
         self.exportSession.timeRange = range;
         */
        
        self.exportSession.outputURL = furl;
        self.originalVideoPath = strNewPath;
        self.exportSession.outputFileType = AVFileTypeMPEG4;
        
        self.exportSession.videoComposition = videoComp;
        self.exportSession.shouldOptimizeForNetworkUse = YES;
        self.trimBtn.hidden = YES;
        
        [self.exportSession exportAsynchronouslyWithCompletionHandler:^{
            
            switch ([self.exportSession status]) {
                case AVAssetExportSessionStatusFailed:
                    [HUD hide:YES];
                    NSLog(@"Export failed: %@, %@ %@", [[self.exportSession error] localizedDescription], [self.exportSession.error description],[self.exportSession.error userInfo]);
                    break;
                case AVAssetExportSessionStatusCancelled:
                    [HUD hide:YES];
                    NSLog(@"Export canceled");
                    break;
                default:{
                    NSLog(@"NONE");
                    NSFileManager *fm = [NSFileManager defaultManager];
                    
                    if ([fm fileExistsAtPath:self.tmpVideoPath]){
                        NSLog(@"fileexis");
                    }
                    
                    ////////////            Done by kunal for new video recording hang after uploding and blab send 15-04-2015
                    appDelegate.FlagVideo = 0;
                    
                    for (UIViewController *obj in [self.navigationController viewControllers]) {
                        
                        if ([obj isKindOfClass:[PBJViewControllerHBlab class]]) {
                            PBJViewControllerHBlab *obj12 = (PBJViewControllerHBlab *)obj;
                            [obj12 handleFlipButtonCancelBtn];
                        }
                    }
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        [self CallMethod];
                    });
                }
                    break;
            }
        }];
    }
}


-(void)mergeST_and_Song{
    
    AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
    // 2 - Video track
    
    //    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    //    NSString *SongPath = [appDelegate.captureMovieURL absoluteString];
    NSURL* sourceMovieURL = [NSURL fileURLWithPath:self.originalVideoPath];
    NSError *error = nil;
    //------ create Audio and Video Assets
    
    AVURLAsset *VideoAsset = [[AVURLAsset alloc]initWithURL:sourceMovieURL options:nil] ;
    //    AVURLAsset* audioAsset = [[AVURLAsset alloc]initWithURL:[NSURL fileURLWithPath:appDelegate.strSoundTrackPath] options:nil];
    
    //    CMTime duration = VideoAsset.duration;
    //    float duration1 = [[NSString stringWithFormat:@"%.2f",CMTimeGetSeconds(duration)] floatValue];
    
    //------
    
    //1 ---- add external audio - Soundtrack
    
    //    AVMutableCompositionTrack *AudioOfSoundTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
    //
    //    [AudioOfSoundTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, VideoAsset.duration) ofTrack:([audioAsset tracksWithMediaType:AVMediaTypeAudio].count > 0)?[[audioAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
    //------
    
    //2 ---- video
    
    AVMutableCompositionTrack *VideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo preferredTrackID:kCMPersistentTrackID_Invalid];
    
    [VideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, VideoAsset.duration)
                        ofTrack:([VideoAsset tracksWithMediaType:AVMediaTypeVideo].count >0)?[[VideoAsset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
    //------
    
    //3	----- url of first path - audio of video
    AVMutableCompositionTrack *VideoAudioTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
    
    [VideoAudioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, VideoAsset.duration) ofTrack:([VideoAsset tracksWithMediaType:AVMediaTypeAudio].count > 0)?[[VideoAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
    //-------
    
    
    //---- ------- ------- ------- ------
    
    AVAssetTrack *videoTrack = [[mixComposition tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
    
    AVMutableVideoComposition* videoComp = [AVMutableVideoComposition videoComposition];
    
    
    UIImage *myImage = [UIImage imageNamed:@"app_logo.png"];
    CALayer *aLayer = [CALayer layer];
    aLayer.contents = (id)myImage.CGImage;
    //aLayer.opacity = 0.65; //Feel free to alter the alpha here'
    aLayer.opacity = 1;
    NSLog(@"%@",NSStringFromCGSize([videoTrack naturalSize]));
    CGSize videoSize = CGSizeMake([videoTrack naturalSize].width, [videoTrack naturalSize].height);
    float videoWidth = videoSize.width;
    
    CALayer *parentLayer = [CALayer layer];
    CALayer *videoLayer = [CALayer layer];
    
    AVMutableVideoCompositionInstruction *instruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
    instruction.timeRange = CMTimeRangeMake(kCMTimeZero, [mixComposition duration]);
    //  AVAssetTrack *videoTrack = [[mixComposition tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
    AVMutableVideoCompositionLayerInstruction* layerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoTrack];
    
    
    CGAffineTransform t1;
    CGAffineTransform t2;
    CGAffineTransform txf = appDelegate.videoPrefferedTransform;
    
    if (txf.a == -1) {	//landscape left        - DONE
        if (videoWidth == 320 || videoWidth == 360 || videoWidth <= DEVICE_WIDTH || videoWidth <= DEVICE_HEIGHT) {
            aLayer.frame = CGRectMake(175,25,117,52); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
            videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_WIDTH);
            
            t1 = CGAffineTransformMakeTranslation(DEVICE_WIDTH, 0);
            t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
            t2 = CGAffineTransformTranslate(t2, DEVICE_WIDTH, 0);
            t2 = CGAffineTransformRotate(t2, degreesToRadians(90.0));
            t2 = CGAffineTransformScale(t2, 1, 1);
        }
        else{
            if (videoWidth==720) {
                //720
                aLayer.frame = CGRectMake(175*3,25*2,117*2,52*2); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                
                videoSize = CGSizeMake(720, 720);
                t1 = CGAffineTransformMakeTranslation(720, 100);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                t2 = CGAffineTransformTranslate(t2, 568+(DEVICE_WIDTH/2), 0);
                t2 = CGAffineTransformRotate(t2, degreesToRadians(90.0));
                t2 = CGAffineTransformScale(t2, 1, 1);
            }
            else{
                //1280
                aLayer.frame = CGRectMake(175*4,25*3,117*3,52*3); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                
                videoSize = CGSizeMake(1280, 1280);
                t1 = CGAffineTransformMakeTranslation(1280, 100);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                t2 = CGAffineTransformTranslate(t2, 720+(DEVICE_WIDTH/2), 0);
                t2 = CGAffineTransformRotate(t2, degreesToRadians(90.0));
                t2 = CGAffineTransformScale(t2, 1, 1);
            }
        }
    }
    else if (txf.a == 1){	//landscape right       - DONE
        if (videoWidth == 320 || videoWidth == 360  || videoWidth <= DEVICE_WIDTH || videoWidth <= DEVICE_HEIGHT) {
            aLayer.frame = CGRectMake(175,25,117,52); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
            videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_WIDTH);
            t2 = CGAffineTransformMakeTranslation(0, 0);
            t2 = CGAffineTransformScale(t2, 1.0, 1.0);
        }
        else{
            if (videoWidth == 720) {
                aLayer.frame = CGRectMake(175*3,25*2,117*2,52*2); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                videoSize = CGSizeMake(720, 720);
                t2 = CGAffineTransformMakeTranslation(0, 0);
                t2 = CGAffineTransformScale(t2, 1.0, 1.0);
            }
            else{
                //1280
                aLayer.frame = CGRectMake(175*4,25*3,117*3,52*3); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                videoSize = CGSizeMake(1280, 1280);
                t2 = CGAffineTransformMakeTranslation(0, 300);
                t2 = CGAffineTransformScale(t2, 1.0, 1.0);
            }
        }
    }
    else if (txf.c == 1){	//portrait button up
        if (videoWidth == 320 || videoWidth == 360 || videoWidth <= DEVICE_WIDTH || videoWidth <= DEVICE_HEIGHT) {
            aLayer.frame = CGRectMake(175,25,117,52); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
            videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_WIDTH);
            t1 = CGAffineTransformMakeTranslation(0, videoSize.width);
            t2 = CGAffineTransformRotate(t1, degreesToRadians(-90.0));
            t2 = CGAffineTransformScale(t2, 1, 1);
        }
        else{
            if (videoWidth == 720) {
                aLayer.frame = CGRectMake(175*2,25*2,117*2,52*2); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                videoSize = CGSizeMake(720, 1280);
                
                t1 = CGAffineTransformMakeTranslation(0, videoSize.width);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(-90.0));
                t2 = CGAffineTransformScale(t2, 1, 1);
            }
            else{
                aLayer.frame = CGRectMake(175*2,25*2,117*2,52*2); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
                videoSize = CGSizeMake(1280, 720);
                
                t1 = CGAffineTransformMakeTranslation(0, videoSize.width);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(-90.0));
                t2 = CGAffineTransformScale(t2, 1, 1);
            }
        }
    }
    else if (txf.c == -1){		//portrait button down      - DONE
        if (videoWidth == 320 || videoWidth == 360 || videoWidth <= DEVICE_WIDTH || videoWidth <= DEVICE_HEIGHT) {
            aLayer.frame = CGRectMake(175,25,117,52); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
            videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_WIDTH);
            
            t1 = CGAffineTransformMakeTranslation(videoSize.height, 0);
            t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
            t2 = CGAffineTransformScale(t2, 1, 1);
        }
        else{
            if (videoWidth == 720) {
                //720
                aLayer.frame = CGRectMake(175*2,25*2,117*2,52*2);
                
                t1 = CGAffineTransformMakeTranslation(videoSize.height, 0);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                t2 = CGAffineTransformScale(t2, 1, 1);
            }
            else{
                //1280
                aLayer.frame = CGRectMake(175*2,25*2,117*2,52*2);
                
                t1 = CGAffineTransformMakeTranslation(videoSize.height, 0);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                t2 = CGAffineTransformScale(t2, 1, 1);
            }
        }
    }
    else{
        //all 0
        t2 = CGAffineTransformMakeTranslation(0, 100);
    }
    
    
    if (videoWidth==320 || videoWidth == 360  || videoWidth <= DEVICE_WIDTH || videoWidth <= DEVICE_HEIGHT) {
        parentLayer.frame = CGRectMake(0, 0, videoSize.width, videoSize.height);
        videoLayer.frame = CGRectMake(0, 0, videoSize.width, videoSize.height);
        [parentLayer addSublayer:videoLayer];
        [parentLayer addSublayer:aLayer];
        
        videoComp.renderSize = videoSize;
    }
    else{
        if (videoWidth == 720) {
            parentLayer.frame = CGRectMake(0, 0, videoSize.height, 1280);
            videoLayer.frame = CGRectMake(0, 0, videoSize.height, 1280);
            [parentLayer addSublayer:videoLayer];
            [parentLayer addSublayer:aLayer];
            
            videoComp.renderSize = CGSizeMake(videoSize.height, 1280);
        }else{
            parentLayer.frame = CGRectMake(0, 0, videoSize.height, 1280);
            videoLayer.frame = CGRectMake(0, 0, videoSize.height, 1280);
            [parentLayer addSublayer:videoLayer];
            [parentLayer addSublayer:aLayer];
            
            videoComp.renderSize = CGSizeMake(videoSize.height, 1280);
        }
    }
    
    
    
    //----
    //    AVMutableVideoCompositionInstruction *instruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
    //    instruction.timeRange = CMTimeRangeMake(kCMTimeZero, [mixComposition duration]);
    //  //  AVAssetTrack *videoTrack = [[mixComposition tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
    //    AVMutableVideoCompositionLayerInstruction* layerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoTrack];
    
    videoComp.frameDuration = CMTimeMake(1, 30);
    videoComp.animationTool = [AVVideoCompositionCoreAnimationTool videoCompositionCoreAnimationToolWithPostProcessingAsVideoLayer:videoLayer inLayer:parentLayer];
    
    
    [layerInstruction setTransform:t2 atTime:kCMTimeZero];
    
    //    videoComp.instructions = [NSArray arrayWithObject: instruction];
    
    
    
    instruction.layerInstructions = [NSArray arrayWithObject:layerInstruction];
    videoComp.instructions = [NSArray arrayWithObject:instruction];
    //----
    //---- ------- ------- ------- ------
    
    //    AVAssetExportSession* _assetExport = [[AVAssetExportSession alloc] initWithAsset:mixComposition presetName:AVAssetExportPresetHighestQuality];
    
    //	NSString *strPath = [NSString stringWithFormat:@"%@newMergedMovie111.mp4", NSTemporaryDirectory()];
    NSString *strNewPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov2.mp4"];
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:strNewPath]) {
        [[NSFileManager defaultManager] removeItemAtPath:strNewPath error:nil];
    }
    
    NSURL *exportURL = [NSURL fileURLWithPath:strNewPath];
    //    _assetExport.outputURL = exportURL;
    //    _assetExport.shouldOptimizeForNetworkUse = YES;
    //    _assetExport.outputFileType = AVFileTypeMPEG4;
    //    _assetExport.videoComposition = videoComp;
    AVAssetExportSession* _assetExport = [[AVAssetExportSession alloc]
                                          initWithAsset:mixComposition presetName:AVAssetExportPresetHighestQuality];
    _assetExport.outputURL = exportURL;
    self.originalVideoPath = strNewPath;
    _assetExport.outputFileType = AVFileTypeMPEG4;
    
    //    _assetExport.videoComposition = videoComp;
    _assetExport.shouldOptimizeForNetworkUse = YES;
    self.trimBtn.hidden = YES;
    
    
    [_assetExport exportAsynchronouslyWithCompletionHandler:^{
        switch ([_assetExport status]) {
            case AVAssetExportSessionStatusFailed:
                [HUD hide:YES];
                NSLog(@"Export failed: %@, %@ %@", [[_assetExport error] localizedDescription], [_assetExport.error description],[_assetExport.error userInfo]);
                break;
            case AVAssetExportSessionStatusCancelled:
                [HUD hide:YES];
                NSLog(@"Export canceled");
                break;
            default:{
                NSLog(@"NONE");
                NSFileManager *fm = [NSFileManager defaultManager];
                
                if ([fm fileExistsAtPath:self.tmpVideoPath]){
                    NSLog(@"fileexis");
                }
                
                ////////////            Done by kunal for new video recording hang after uploding and blab send 15-04-2015
                appDelegate.FlagVideo = 0;
                
                for (UIViewController *obj in [self.navigationController viewControllers]) {
                    
                    if ([obj isKindOfClass:[PBJViewControllerHBlab class]]) {
                        PBJViewControllerHBlab *obj12 = (PBJViewControllerHBlab *)obj;
                        [obj12 handleFlipButtonCancelBtn];
                    }
                }
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [self CallMethod];
                });
            }
                break;
        }
    }];
    
}

-(IBAction)btnGoNext:(id)sender{
    
    //    NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
    
    NSURL *videoFileUrl1 = [NSURL fileURLWithPath:self.originalVideoPath];
    
    AVURLAsset *movieAsset=[AVURLAsset URLAssetWithURL:videoFileUrl1 options:nil];
    CMTime duration = movieAsset.duration;
    
    NSLog(@"%f",CMTimeGetSeconds(duration));
    
    HUD.mode = MBProgressHUDModeIndeterminate;
    HUD.detailsLabelText = @"";
    
    
    float RecordDuration = CMTimeGetSeconds(duration);
    
    if (RecordDuration > 90.5) {
        [Validation showToastMessage:@"Your video cannot exceed more then 90seconds." displayDuration:ERROR_MSG_DURATION];
    }
    else if (RecordDuration<3.0){
        [Validation showToastMessage:@"Your video should be atleast of 3seconds." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        [HUD show:YES];
        
        if (appDelegate.isRecordingFromCamera) {
            
            AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
            
            AVURLAsset *videoasset = [[AVURLAsset alloc]initWithURL:[NSURL fileURLWithPath:self.originalVideoPath] options:nil];
            
            //Recorded  video
            AVMutableCompositionTrack *compositionVideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo
                                                                                           preferredTrackID:kCMPersistentTrackID_Invalid];
            [compositionVideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration)
                                           ofTrack:[[videoasset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]
                                            atTime:kCMTimeZero error:nil];
            
            //-----
            // Audio of Video
            AVMutableCompositionTrack *compositionAudioTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio
                                                                                           preferredTrackID:kCMPersistentTrackID_Invalid];
            [compositionAudioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration)
                                           ofTrack:[[videoasset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]
                                            atTime:kCMTimeZero error:nil];
            
            
            self.tmpVideoPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov11.mp4"];
            
            [self deleteTmpFile];
            
            self.exportSession = [[AVAssetExportSession alloc]
                                  initWithAsset:mixComposition presetName:AVAssetExportPresetHighestQuality];
            // Implementation continues.
            
            NSURL *furl = [NSURL fileURLWithPath:self.tmpVideoPath];
            
            self.exportSession.outputURL = furl;
            self.exportSession.outputFileType = AVFileTypeQuickTimeMovie;
            
            self.exportSession.shouldOptimizeForNetworkUse = YES;
            self.trimBtn.hidden = YES;
            [self.exportSession exportAsynchronouslyWithCompletionHandler:^{
                
                switch ([self.exportSession status]) {
                    case AVAssetExportSessionStatusFailed:
                        [HUD hide:YES];
                        NSLog(@"Export failed: %@", [[self.exportSession error] localizedDescription]);
                        break;
                    case AVAssetExportSessionStatusCancelled:
                        [HUD hide:YES];
                        NSLog(@"Export canceled");
                        break;
                    default:{
                        NSLog(@"NONE");
                        NSFileManager *fm = [NSFileManager defaultManager];
                        
                        if ([fm fileExistsAtPath:self.tmpVideoPath]){
                            NSLog(@"fileexis");
                        }
                        ////////////            Done by kunal for new video recording hang after uploding and blab send 15-04-2015
                        appDelegate.FlagVideo = 0;
                        
                        for (UIViewController *obj in [self.navigationController viewControllers]) {
                            
                            if ([obj isKindOfClass:[PBJViewControllerHBlab class]]) {
                                PBJViewControllerHBlab *obj12 = (PBJViewControllerHBlab *)obj;
                                [obj12 handleFlipButtonCancelBtn];
                            }
                        }
                        dispatch_async(dispatch_get_main_queue(), ^{
                            self.trimBtn.hidden = NO;
                            [self playMovie:self.tmpVideoPath];
                        });
                    }
                        break;
                }
            }];
            
        }
        else{
            
            NSURL* sourceMovieURL = [NSURL fileURLWithPath:self.originalVideoPath];
            //------ create Audio and Video Assets
            
            AVURLAsset *videoasset = [[AVURLAsset alloc] initWithURL:sourceMovieURL options:nil];
            
            AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
            
            NSError *error = nil;
            
            // Audio of Video
            
            AVMutableCompositionTrack *compositionVideoAudio = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
            [compositionVideoAudio insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration) ofTrack:([videoasset tracksWithMediaType:AVMediaTypeAudio].count > 0)?[[videoasset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
            
            
            //Recorded  video
            AVMutableCompositionTrack *compositionVideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo preferredTrackID:kCMPersistentTrackID_Invalid];
            [compositionVideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration) ofTrack:([videoasset tracksWithMediaType:AVMediaTypeVideo].count > 0)?[[videoasset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
            
            self.tmpVideoPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov11.mp4"];
            [self deleteTmpFile];
            
            
            NSString *outFilePath = self.tmpVideoPath;
            NSURL    *savetUrl = [NSURL fileURLWithPath:outFilePath];
            
            if ([[NSFileManager defaultManager] fileExistsAtPath:outFilePath])
            {
                [[NSFileManager defaultManager] removeItemAtPath:outFilePath error:nil];
            }
            
            self.exportSession = [[AVAssetExportSession alloc] initWithAsset:mixComposition
                                                                  presetName:AVAssetExportPresetHighestQuality];
            
            self.exportSession.outputFileType = @"com.apple.quicktime-movie";
            
            self.exportSession.outputURL = savetUrl;
            self.exportSession.shouldOptimizeForNetworkUse = YES;
            
            self.trimBtn.hidden = YES;
            [self.exportSession exportAsynchronouslyWithCompletionHandler:^{
                
                switch ([self.exportSession status]) {
                    case AVAssetExportSessionStatusFailed:
                        [HUD hide:YES];
                        NSLog(@"Export failed: %@", [[self.exportSession error] localizedDescription]);
                        break;
                    case AVAssetExportSessionStatusCancelled:
                        [HUD hide:YES];
                        NSLog(@"Export canceled");
                        break;
                    default:{
                        NSLog(@"NONE");
                        NSFileManager *fm = [NSFileManager defaultManager];
                        
                        if ([fm fileExistsAtPath:self.tmpVideoPath]){
                            NSLog(@"fileexis");
                        }
                        
                        ////////////            Done by kunal for new video recording hang after uploding and blab send 15-04-2015
                        appDelegate.FlagVideo = 0;
                        
                        for (UIViewController *obj in [self.navigationController viewControllers]) {
                            
                            if ([obj isKindOfClass:[PBJViewControllerHBlab class]]) {
                                PBJViewControllerHBlab *obj12 = (PBJViewControllerHBlab *)obj;
                                [obj12 handleFlipButtonCancelBtn];
                            }
                        }
                        
                        dispatch_async(dispatch_get_main_queue(), ^{
                            self.trimBtn.hidden = NO;
                            [self playMovie:self.tmpVideoPath];
                        });
                    }
                        break;
                }
            }];
        }
    }
}


- (IBAction)showTrimmedVideo:(UIButton *)sender {
    
    float duration = self.stopTime - self.startTime;
    HUD.mode = MBProgressHUDModeIndeterminate;
    HUD.detailsLabelText = @"";
    
    if (duration > 90.5) {
        [Validation showToastMessage:@"Your video cannot exceed more then 90seconds." displayDuration:ERROR_MSG_DURATION];
    }
    else if (duration<3.0){
        [Validation showToastMessage:@"Your video should be atleast of 3seconds." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        [HUD show:YES];
        
        if (appDelegate.isRecordingFromCamera) {
            
            AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
            
            AVURLAsset *videoasset = [[AVURLAsset alloc]initWithURL:[NSURL fileURLWithPath:self.originalVideoPath] options:nil];
            
            //Recorded  video
            AVMutableCompositionTrack *compositionVideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo
                                                                                           preferredTrackID:kCMPersistentTrackID_Invalid];
            [compositionVideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration)
                                           ofTrack:[[videoasset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]
                                            atTime:kCMTimeZero error:nil];
            
            //-----
            // Audio of Video
            AVMutableCompositionTrack *compositionAudioTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio
                                                                                           preferredTrackID:kCMPersistentTrackID_Invalid];
            [compositionAudioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration)
                                           ofTrack:[[videoasset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]
                                            atTime:kCMTimeZero error:nil];
            
            
            self.tmpVideoPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov11.mp4"];
            
            [self deleteTmpFile];
            
            self.exportSession = [[AVAssetExportSession alloc]
                                  initWithAsset:mixComposition presetName:AVAssetExportPresetHighestQuality];
            // Implementation continues.
            
            NSURL *furl = [NSURL fileURLWithPath:self.tmpVideoPath];
            
            self.exportSession.outputURL = furl;
            self.exportSession.outputFileType = AVFileTypeQuickTimeMovie;
            
            CMTime start = CMTimeMakeWithSeconds(self.startTime, mixComposition.duration.timescale);
            CMTime duration = CMTimeMakeWithSeconds(self.stopTime-self.startTime, mixComposition.duration.timescale);
            CMTimeRange range = CMTimeRangeMake(start, duration);
            self.exportSession.timeRange = range;
            //     self.exportSession.videoComposition = videoComp;
            self.exportSession.shouldOptimizeForNetworkUse = YES;
            self.trimBtn.hidden = YES;
            [self.exportSession exportAsynchronouslyWithCompletionHandler:^{
                
                switch ([self.exportSession status]) {
                    case AVAssetExportSessionStatusFailed:
                        [HUD hide:YES];
                        NSLog(@"Export failed: %@", [[self.exportSession error] localizedDescription]);
                        break;
                    case AVAssetExportSessionStatusCancelled:
                        NSLog(@"Export canceled");[HUD hide:YES];
                        break;
                    default:{
                        NSLog(@"NONE");
                        NSFileManager *fm = [NSFileManager defaultManager];
                        
                        if ([fm fileExistsAtPath:self.tmpVideoPath]){
                            NSLog(@"fileexis");
                        }
                        ////////////            Done by kunal for new video recording hang after uploding and blab send 15-04-2015
                        appDelegate.FlagVideo = 0;
                        
                        for (UIViewController *obj in [self.navigationController viewControllers]) {
                            
                            if ([obj isKindOfClass:[PBJViewControllerHBlab class]]) {
                                PBJViewControllerHBlab *obj12 = (PBJViewControllerHBlab *)obj;
                                [obj12 handleFlipButtonCancelBtn];
                            }
                        }
                        ////////////
                        
                        dispatch_async(dispatch_get_main_queue(), ^{
                            self.trimBtn.hidden = NO;
                            [self playMovie:self.tmpVideoPath];
                        });
                    }
                        break;
                }
            }];
            
            //            }
            
        }
        else{
            //library
            NSURL* sourceMovieURL = [NSURL fileURLWithPath:self.originalVideoPath];
            //------ create Audio and Video Assets
            
            AVURLAsset *videoasset = [[AVURLAsset alloc] initWithURL:sourceMovieURL options:nil];
            
            AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
            
            NSError *error = nil;
            
            // Audio of Video
            
            AVMutableCompositionTrack *compositionVideoAudio = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
            [compositionVideoAudio insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration) ofTrack:([videoasset tracksWithMediaType:AVMediaTypeAudio].count > 0)?[[videoasset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
            
            
            //Recorded  video
            AVMutableCompositionTrack *compositionVideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo preferredTrackID:kCMPersistentTrackID_Invalid];
            [compositionVideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration) ofTrack:([videoasset tracksWithMediaType:AVMediaTypeVideo].count > 0)?[[videoasset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
            
            
            self.tmpVideoPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov11.mp4"];
            [self deleteTmpFile];
            
            
            NSString *outFilePath = self.tmpVideoPath;
            NSURL    *savetUrl = [NSURL fileURLWithPath:outFilePath];
            
            if ([[NSFileManager defaultManager] fileExistsAtPath:outFilePath])
            {
                [[NSFileManager defaultManager] removeItemAtPath:outFilePath error:nil];
            }
            
            self.exportSession = [[AVAssetExportSession alloc] initWithAsset:mixComposition
                                                                  presetName:AVAssetExportPresetHighestQuality];
            
            self.exportSession.outputFileType = @"com.apple.quicktime-movie";
            
            //       self.exportSession.videoComposition = videoComp;
            
            self.exportSession.outputURL = savetUrl;
            self.exportSession.shouldOptimizeForNetworkUse = YES;
            
            CMTime start = CMTimeMakeWithSeconds(self.startTime, mixComposition.duration.timescale);
            CMTime duration = CMTimeMakeWithSeconds(self.stopTime-self.startTime, mixComposition.duration.timescale);
            CMTimeRange range = CMTimeRangeMake(start, duration);
            self.exportSession.timeRange = range;
            
            self.trimBtn.hidden = YES;
            
            [self.exportSession exportAsynchronouslyWithCompletionHandler:^{
                
                switch ([self.exportSession status]) {
                    case AVAssetExportSessionStatusFailed:
                        NSLog(@"Export failed: %@", [[self.exportSession error] localizedDescription]);
                        break;
                    case AVAssetExportSessionStatusCancelled:
                        NSLog(@"Export canceled");
                        break;
                    default:{
                        NSLog(@"NONE");
                        NSFileManager *fm = [NSFileManager defaultManager];
                        
                        if ([fm fileExistsAtPath:self.tmpVideoPath]){
                            NSLog(@"fileexis");
                        }
                        
                        ////////////            Done by kunal for new video recording hang after uploding and blab send 15-04-2015
                        appDelegate.FlagVideo = 0;
                        
                        for (UIViewController *obj in [self.navigationController viewControllers]) {
                            
                            if ([obj isKindOfClass:[PBJViewControllerHBlab class]]) {
                                PBJViewControllerHBlab *obj12 = (PBJViewControllerHBlab *)obj;
                                [obj12 handleFlipButtonCancelBtn];
                            }
                        }
                        [HUD hide:YES];
                        
                        dispatch_async(dispatch_get_main_queue(), ^{
                            
                            self.trimBtn.hidden = NO;
                            [self playMovie:self.tmpVideoPath];
                        });
                    }
                        break;
                }
            }];
        }
    }
}

- (IBAction)showTrimmedVideoWithoutInitialSetup:(UIButton *)sender {
    
    float duration = self.stopTime - self.startTime;
    
    if (duration > 90.5) {
        [Validation showToastMessage:@"Your video cannot exceed more then 90seconds." displayDuration:ERROR_MSG_DURATION];
    }
    else if (duration<3.0){
        [Validation showToastMessage:@"Your video should be atleast of 3seconds." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        [HUD show:YES];
        if (appDelegate.isRecordingFromCamera) {
            
            AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
            
            AVURLAsset *videoasset = [[AVURLAsset alloc]initWithURL:[NSURL fileURLWithPath:self.originalVideoPath] options:nil];
            
            //Recorded  video
            AVMutableCompositionTrack *compositionVideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo
                                                                                           preferredTrackID:kCMPersistentTrackID_Invalid];
            [compositionVideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration)
                                           ofTrack:[[videoasset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]
                                            atTime:kCMTimeZero error:nil];
            
            //-----
            // Audio of Video
            AVMutableCompositionTrack *compositionAudioTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio
                                                                                           preferredTrackID:kCMPersistentTrackID_Invalid];
            [compositionAudioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration)
                                           ofTrack:[[videoasset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]
                                            atTime:kCMTimeZero error:nil];
            
            
            self.tmpVideoPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov11.mp4"];
            
            [self deleteTmpFile];
            
            AVAssetTrack *videoTrack = [[mixComposition tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
            
            UIImage *myImage = [UIImage imageNamed:@"app_logo.png"];
            CALayer *aLayer = [CALayer layer];
            aLayer.contents = (id)myImage.CGImage;
            aLayer.frame = CGRectMake(175,25,117,52); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
            //aLayer.opacity = 0.65; //Feel free to alter the alpha here'
            aLayer.opacity = 1;
            CGSize videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_HEIGHT);
            CALayer *parentLayer = [CALayer layer];
            CALayer *videoLayer = [CALayer layer];
            parentLayer.frame = CGRectMake(0, 0, videoSize.width, videoSize.height);
            videoLayer.frame = CGRectMake(0, 0, videoSize.width, videoSize.height);
            [parentLayer addSublayer:videoLayer];
            [parentLayer addSublayer:aLayer];
            
            AVMutableVideoComposition* videoComp = [AVMutableVideoComposition videoComposition];
            videoComp.renderSize = CGSizeMake(DEVICE_WIDTH, DEVICE_HEIGHT);
            videoComp.frameDuration = CMTimeMake(1, 30);
            
            videoComp.animationTool = [AVVideoCompositionCoreAnimationTool videoCompositionCoreAnimationToolWithPostProcessingAsVideoLayer:videoLayer inLayer:parentLayer];
            
            AVMutableVideoCompositionInstruction *instruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
            instruction.timeRange = CMTimeRangeMake(kCMTimeZero, [mixComposition duration]);
            AVMutableVideoCompositionLayerInstruction* layerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoTrack];
            
            
            CGAffineTransform t1;
            CGAffineTransform t2;
            
            
            if (appDelegate.CameraOrientationForVideo == 4) {
                //dont rotate
                //PBJCameraOrientationPortrait
                NSLog(@"PBJCameraOrientationPortrait");
                t1 = CGAffineTransformIdentity;
                t2 = CGAffineTransformTranslate(t1, 0, 100);
                //  t2 = CGAffineTransformScale(t1, 1, 1);
                [layerInstruction setTransform:t2 atTime:kCMTimeZero];
                
            }
            else if (appDelegate.CameraOrientationForVideo == 1){
                //                PBJCameraOrientationPortraitUpsideDown
                NSLog(@"PBJCameraOrientationPortraitUpsideDown");
                t1 = CGAffineTransformMakeTranslation(DEVICE_WIDTH, 0);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                t2 = CGAffineTransformTranslate(t2, 450, 0);
                t2 = CGAffineTransformRotate(t2, degreesToRadians(90.0));
                [layerInstruction setTransform:t2 atTime:kCMTimeZero];
            }
            else if (appDelegate.CameraOrientationForVideo == 2){
                //                PBJCameraOrientationLandscapeRight
                NSLog(@"PBJCameraOrientationLandscapeRight");
                t1 = CGAffineTransformMakeTranslation(0, 450);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(-90.0));
                [layerInstruction setTransform:t2 atTime:kCMTimeZero];
            }
            else if (appDelegate.CameraOrientationForVideo == 3){
                //                PBJCameraOrientationLandscapeLeft
                NSLog(@"PBJCameraOrientationLandscapeLeft");
                
                t1 = CGAffineTransformMakeTranslation(DEVICE_WIDTH, 100);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                t2 = CGAffineTransformScale(t2, 1, 1);
                [layerInstruction setTransform:t2 atTime:kCMTimeZero];
                
            }
            
            instruction.layerInstructions = [NSArray arrayWithObject:layerInstruction];
            videoComp.instructions = [NSArray arrayWithObject: instruction];
            self.exportSession = [[AVAssetExportSession alloc]
                                  initWithAsset:mixComposition presetName:AVAssetExportPresetHighestQuality];
            // Implementation continues.
            
            NSURL *furl = [NSURL fileURLWithPath:self.tmpVideoPath];
            
            self.exportSession.outputURL = furl;
            self.exportSession.outputFileType = AVFileTypeQuickTimeMovie;
            
            CMTime start = CMTimeMakeWithSeconds(self.startTime, mixComposition.duration.timescale);
            CMTime duration = CMTimeMakeWithSeconds(self.stopTime-self.startTime, mixComposition.duration.timescale);
            CMTimeRange range = CMTimeRangeMake(start, duration);
            self.exportSession.timeRange = range;
            self.exportSession.videoComposition = videoComp;
            self.exportSession.shouldOptimizeForNetworkUse = YES;
            self.trimBtn.hidden = YES;
            [self.exportSession exportAsynchronouslyWithCompletionHandler:^{
                
                switch ([self.exportSession status]) {
                    case AVAssetExportSessionStatusFailed:
                        [HUD hide:YES];
                        NSLog(@"Export failed: %@", [[self.exportSession error] localizedDescription]);
                        break;
                    case AVAssetExportSessionStatusCancelled:
                        NSLog(@"Export canceled");[HUD hide:YES];
                        break;
                    default:{
                        NSLog(@"NONE");
                        NSFileManager *fm = [NSFileManager defaultManager];
                        
                        if ([fm fileExistsAtPath:self.tmpVideoPath]){
                            NSLog(@"fileexis");
                        }
                        ////////////            Done by kunal for new video recording hang after uploding and blab send 15-04-2015
                        appDelegate.FlagVideo = 0;
                        
                        for (UIViewController *obj in [self.navigationController viewControllers]) {
                            
                            if ([obj isKindOfClass:[PBJViewControllerHBlab class]]) {
                                PBJViewControllerHBlab *obj12 = (PBJViewControllerHBlab *)obj;
                                [obj12 handleFlipButtonCancelBtn];
                            }
                        }
                        ////////////
                        
                        dispatch_async(dispatch_get_main_queue(), ^{
                            self.trimBtn.hidden = NO;
                            [self playMovie:self.tmpVideoPath];
                        });
                    }
                        break;
                }
            }];
            
            //            }
            
        }
        else{
            //library
            NSURL* sourceMovieURL = [NSURL fileURLWithPath:self.originalVideoPath];
            //------ create Audio and Video Assets
            
            AVURLAsset *videoasset = [[AVURLAsset alloc] initWithURL:sourceMovieURL options:nil];
            
            AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
            
            NSError *error = nil;
            
            NSMutableArray *audioMixParams = [[NSMutableArray alloc] initWithObjects:nil] ;
            
            // Audio of Video
            
            AVMutableCompositionTrack *compositionVideoAudio = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
            [compositionVideoAudio insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration) ofTrack:([videoasset tracksWithMediaType:AVMediaTypeAudio].count > 0)?[[videoasset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
            
            
            //Recorded  video
            AVMutableCompositionTrack *compositionVideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo preferredTrackID:kCMPersistentTrackID_Invalid];
            [compositionVideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoasset.duration) ofTrack:([videoasset tracksWithMediaType:AVMediaTypeVideo].count > 0)?[[videoasset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
            
            
            // Add Audio of video
            CMTime startTime1 = CMTimeMakeWithSeconds(0, 1);
            AVMutableAudioMixInputParameters *trackMix1 = [AVMutableAudioMixInputParameters audioMixInputParametersWithTrack:compositionVideoAudio];
            [trackMix1 setVolume:1 atTime:startTime1];
            [audioMixParams addObject:trackMix1];
            AVMutableAudioMix *audioMix = [AVMutableAudioMix audioMix];
            audioMix.inputParameters = [NSArray arrayWithArray:audioMixParams];
            
            //-------------
            
            UIImage *myImage = [UIImage imageNamed:@"app_logo.png"];
            CALayer *aLayer = [CALayer layer];
            aLayer.contents = (id)myImage.CGImage;
            aLayer.frame = CGRectMake(175,25,117,52); //Needed for proper display. We are using the app icon (57x57). If you use 0,0 you will not see it
            //aLayer.opacity = 0.65; //Feel free to alter the alpha here'
            aLayer.opacity = 1;
            CGSize videoSize = CGSizeMake(DEVICE_WIDTH, DEVICE_HEIGHT);
            CALayer *parentLayer = [CALayer layer];
            CALayer *videoLayer = [CALayer layer];
            parentLayer.frame = CGRectMake(0, 0, videoSize.width, videoSize.height);
            videoLayer.frame = CGRectMake(0, 0, videoSize.width, videoSize.height);
            [parentLayer addSublayer:videoLayer];
            [parentLayer addSublayer:aLayer];
            
            AVMutableVideoComposition* videoComp = [AVMutableVideoComposition videoComposition];
            videoComp.renderSize =  CGSizeMake(DEVICE_WIDTH, DEVICE_HEIGHT);
            videoComp.frameDuration = CMTimeMake(1, 30);
            
            videoComp.animationTool = [AVVideoCompositionCoreAnimationTool videoCompositionCoreAnimationToolWithPostProcessingAsVideoLayer:videoLayer inLayer:parentLayer];
            AVMutableVideoCompositionInstruction *instruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
            instruction.timeRange = CMTimeRangeMake(kCMTimeZero, [mixComposition duration]);
            
            AVAssetTrack *videoTrack = [[mixComposition tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
            AVMutableVideoCompositionLayerInstruction* layerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoTrack];
            
            CGAffineTransform t1;
            CGAffineTransform t2;
            CGAffineTransform txf = appDelegate.videoPrefferedTransform;
            
            if (txf.a == -1) {	//landscape left
                t1 = CGAffineTransformMakeTranslation(DEVICE_WIDTH, 0);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                t2 = CGAffineTransformTranslate(t2, 400, 0);
                t2 = CGAffineTransformRotate(t2, degreesToRadians(90.0));
                t2 = CGAffineTransformScale(t2, 0.3, 0.3);
                [layerInstruction setTransform:t2 atTime:kCMTimeZero];
            }
            else if (txf.a == 1){	//landscape right
                //                t2 = CGAffineTransformMakeScale(0.5, 0.5);
                t2 = CGAffineTransformMakeScale(0.3, 0.4);
                //                t2 = CGAffineTransformTranslate(t2, 0, 300);
                t2 = CGAffineTransformTranslate(t2, 0, 270);
                [layerInstruction setTransform:t2 atTime:kCMTimeZero];
            }
            else if (txf.c == 1){	//portrait button up
                t1 = CGAffineTransformMakeTranslation(0, DEVICE_HEIGHT);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(-90.0));
                t2 = CGAffineTransformScale(t2, 0.5, 0.5);
                [layerInstruction setTransform:t2 atTime:kCMTimeZero];
            }
            else if (txf.c == -1){		//portrait button down
                t1 = CGAffineTransformMakeTranslation(DEVICE_WIDTH, 0);
                t2 = CGAffineTransformRotate(t1, degreesToRadians(90.0));
                t2 = CGAffineTransformScale(t2, 0.5, 0.5);
                [layerInstruction setTransform:t2 atTime:kCMTimeZero];
            }
            else{
                //all 0
                t2 = CGAffineTransformMakeTranslation(0, 100);
                t2 = CGAffineTransformMakeScale(1, 1);
                [layerInstruction setTransform:t2 atTime:kCMTimeZero];
            }
            
            instruction.layerInstructions = [NSArray arrayWithObject:layerInstruction];
            videoComp.instructions = [NSArray arrayWithObject: instruction];
            
            
            self.tmpVideoPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov11.mp4"];
            [self deleteTmpFile];
            
            
            NSString *outFilePath = self.tmpVideoPath;
            NSURL    *savetUrl = [NSURL fileURLWithPath:outFilePath];
            
            if ([[NSFileManager defaultManager] fileExistsAtPath:outFilePath])
            {
                [[NSFileManager defaultManager] removeItemAtPath:outFilePath error:nil];
            }
            
            self.exportSession = [[AVAssetExportSession alloc] initWithAsset:mixComposition
                                                                  presetName:AVAssetExportPresetHighestQuality];
            
            self.exportSession.outputFileType = @"com.apple.quicktime-movie";
            
            self.exportSession.videoComposition = videoComp;
            
            self.exportSession.outputURL = savetUrl;
            self.exportSession.shouldOptimizeForNetworkUse = YES;
            
            CMTime start = CMTimeMakeWithSeconds(self.startTime, mixComposition.duration.timescale);
            CMTime duration = CMTimeMakeWithSeconds(self.stopTime-self.startTime, mixComposition.duration.timescale);
            CMTimeRange range = CMTimeRangeMake(start, duration);
            self.exportSession.timeRange = range;
            
            self.trimBtn.hidden = YES;
            
            [self.exportSession exportAsynchronouslyWithCompletionHandler:^{
                
                switch ([self.exportSession status]) {
                    case AVAssetExportSessionStatusFailed:
                        NSLog(@"Export failed: %@", [[self.exportSession error] localizedDescription]);
                        break;
                    case AVAssetExportSessionStatusCancelled:
                        NSLog(@"Export canceled");
                        break;
                    default:{
                        NSLog(@"NONE");
                        NSFileManager *fm = [NSFileManager defaultManager];
                        
                        if ([fm fileExistsAtPath:self.tmpVideoPath]){
                            NSLog(@"fileexis");
                        }
                        
                        ////////////            Done by kunal for new video recording hang after uploding and blab send 15-04-2015
                        appDelegate.FlagVideo = 0;
                        
                        for (UIViewController *obj in [self.navigationController viewControllers]) {
                            
                            if ([obj isKindOfClass:[PBJViewControllerHBlab class]]) {
                                PBJViewControllerHBlab *obj12 = (PBJViewControllerHBlab *)obj;
                                [obj12 handleFlipButtonCancelBtn];
                            }
                        }
                        [HUD hide:YES];
                        
                        dispatch_async(dispatch_get_main_queue(), ^{
                            
                            self.trimBtn.hidden = NO;
                            [self playMovie:self.tmpVideoPath];
                        });
                    }
                        break;
                }
            }];
        }
    }
}

-(void)MPMovieDurationAvailable:(NSNotification *)notification{
    
    //    if (self.moviePlayer !=nil) {
    //        if (![self.moviePlayer.view isHidden]) {
    //            if (self.moviePlayer.moviePlayer.duration > 0.00000) {
    //
    //                if (!self.moviePlayer) {
    //                    [self.moviePlayer.moviePlayer stop];
    //                }
    //            }
    //        }
    //        else{
    //            [self.moviePlayer.moviePlayer stop];
    //            [self.moviePlayer.view removeFromSuperview];
    //            self.moviePlayer = nil;
    //        }
    //    }
}

-(void)MPMoviewPlayerLoadStateDidChange:(NSNotification *)notification{
    
    //    if (self.moviePlayer != nil) {
    //        if (self.moviePlayer.moviePlayer.loadState == MPMovieLoadStatePlaythroughOK) {
    //            [self.activity stopAnimating];
    //        }
    //        else if (self.moviePlayer.moviePlayer.loadState == MPMovieLoadStateStalled){
    //            [self.activity startAnimating];
    //        }
    //    }
}
- (void)MPMoviePlayerPlaybackStateDidChange:(NSNotification *)notification{
    
    //    if (self.moviePlayer != nil) {
    //        if (self.moviePlayer.moviePlayer.playbackState == MPMoviePlaybackStatePlaying) {
    //
    //            [self.activity stopAnimating];
    //
    //            [self.moviePlayer.moviePlayer play];
    //        }
    //        else if (self.moviePlayer.moviePlayer.playbackState == MPMoviePlaybackStatePaused){     //|| self.moviePlayer.moviePlayer.playbackState == MPMoviePlaybackStateInterrupted){
    //            //[self.activity startAnimating];
    //        }
    //    }
}
- (void)moviePlayBackDidFinish:(NSNotification *)notification {
    
    //    if (!self.isPlayAll) {
    //        if (self.isStoppedForceFully) {
    //            [self.activity removeFromSuperview];
    //            self.activity = nil;
    //
    //        }else{
    //            [self.activity stopAnimating];
    //            [self.moviePlayer.moviePlayer play];
    //        }
    //
    //
    //        //        if (notification.object == self.moviePlayer) {
    //        //            NSInteger reason = [[notification.userInfo objectForKey:MPMoviePlayerPlaybackDidFinishReasonUserInfoKey] integerValue];
    //        //            if (reason == MPMovieFinishReasonPlaybackEnded)
    //        //            {
    //        //                [self.moviePlayer.moviePlayer play];
    //        //            }
    //        //        }
    //    }
    //    else{
    //        [self MoviePlayerRemoveObserver];
    //        [self.activity removeFromSuperview];
    //        self.activity = nil;
    //        self.viewFullImageContainer.hidden = YES;
    //        self.isFullScreenClicked = NO;
    //        //        self.isStoppedForceFully = YES;
    //        self.moviePlayer.moviePlayer.shouldAutoplay = NO;
    //        [self.moviePlayer.view removeFromSuperview];
    //        self.moviePlayer = nil;
    //        [self removeAnimationFromSuperView];
    //    }
    
}


-(void)MoviePlayerRemoveObserver{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerDidExitFullscreenNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerDidEnterFullscreenNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackStateDidChangeNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerLoadStateDidChangeNotification object:self.moviePlayer.moviePlayer];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMovieDurationAvailableNotification object:self.moviePlayer.moviePlayer];
    
    
}


#pragma mark - Other
-(void)deleteTmpFile{
    
    NSLog(@"self.tmpVideoPath=%@",self.tmpVideoPath);
    NSURL *url = [NSURL fileURLWithPath:self.tmpVideoPath];
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL exist = [fm fileExistsAtPath:url.path];
    NSError *err;
    if (exist) {
        [fm removeItemAtURL:url error:&err];
        NSLog(@"file deleted");
        if (err) {
            NSLog(@"file remove error, %@", err.localizedDescription);
        }
    } else {
        NSLog(@"no file by that name");
    }
}


-(void)playMovie: (NSString *) path{
    
    NSURL *videoURL = [NSURL fileURLWithPath:path];
    
    appDelegat.vedioURL = videoURL;
    
    NSData *videoData = [NSData dataWithContentsOfURL:videoURL];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    
    if (![fm fileExistsAtPath:VIDEO_RECORDING_FOLDER]){
        
        [fm createDirectoryAtPath:VIDEO_RECORDING_FOLDER
      withIntermediateDirectories:YES
                       attributes:nil
                            error:NULL];
    }
    
    
    NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov11.mp4"];
    BOOL success = [videoData writeToFile:tempPath atomically:YES];
    NSLog(@"success=%d",success);
    
    appDelegate.vedioURL = [NSURL URLWithString:tempPath];
    
    [HUD hide:YES];
    
    for (UIViewController *obj in [self.navigationController viewControllers]) {
        if ([obj isKindOfClass:[SetVideoAndPrivacyHBlabVC class]]) {
            
            ((SetVideoAndPrivacyHBlabVC *)obj).pickedImg.image = [self generateThumbImage:[NSURL fileURLWithPath:tempPath]];
            
            [self.navigationController popToViewController:obj animated:YES];
            break;
        }
    }
}

-(UIImage *)generateThumbImage : (NSURL *)url
{
    AVAsset *asset = [AVAsset assetWithURL:url];
    AVAssetImageGenerator *imageGenerator = [[AVAssetImageGenerator alloc]initWithAsset:asset];
    CMTime time = CMTimeMakeWithSeconds(0,1);
    CGImageRef imageRef = [imageGenerator copyCGImageAtTime:time actualTime:NULL error:NULL];
    UIImage *thumbnail = [UIImage imageWithCGImage:imageRef];
    
    //    thumbnail = [self fixrotation:thumbnail];
    //    UIImageOrientation oldOrientation = thumbnail.imageOrientation;
    //    UIImageOrientation newOrientation = oldOrientation;
    //    switch (oldOrientation) {
    //        case UIImageOrientationUp:
    //            newOrientation = UIImageOrientationRight;
    //            break;
    ////        case UIImageOrientationLandscapeLeft:
    ////            newOrientation = UIImageOrientationDown;
    ////            break;
    ////        case UIImageOrientationDown:
    ////            newOrientation = UIImageOrientationLandscapeRight;
    ////            break;
    ////        case UIImageOrientationLandscapeRight:
    ////            newOrientation = UIImageOrientationUp;
    ////            break;
    //            // you can also handle mirrored orientations similarly ...
    //    }
    //    UIImage *rotatedImage = [UIImage imageWithCGImage:thumbnail.CGImage scale:1.0f orientation:newOrientation];
    UIImageWriteToSavedPhotosAlbum(thumbnail, NULL, NULL, NULL);
    CGImageRelease(imageRef);  // CGImageRef won't be released by ARC
    return thumbnail;
}

- (UIImage *)fixrotation:(UIImage *)image{
    //    if (image.imageOrientation == UIImageOrientationUp) return image;
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    if (appDelegate.isRecordingFromCamera) {
        if (appDelegate.CameraOrientationForVideo == 4) {
            //dont rotate
            //PBJCameraOrientationPortrait
            NSLog(@"PBJCameraOrientationPortrait");
            
            transform = CGAffineTransformIdentity;
            // transform = CGAffineTransformTranslate(transform, 0, DEVICE_HEIGHT);
            //  t2 = CGAffineTransformScale(t1, 1, 1);
            
        }
        else if (appDelegate.CameraOrientationForVideo == 1){
            //                PBJCameraOrientationPortraitUpsideDown
            NSLog(@"PBJCameraOrientationPortraitUpsideDown");
            
            //transform = CGAffineTransformMakeTranslation(DEVICE_HEIGHT, 0);
            transform = CGAffineTransformTranslate(transform, DEVICE_HEIGHT, 0);
            
            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
            transform = CGAffineTransformTranslate(transform, 300, 210);
            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
        }
        else if (appDelegate.CameraOrientationForVideo == 3){
            //                PBJCameraOrientationLandscapeLeft
            NSLog(@"PBJCameraOrientationLandscapeLeft");
            
            //transform = CGAffineTransformMakeTranslation(0, 450);
            transform = CGAffineTransformTranslate(transform, 0, 300);
            transform = CGAffineTransformRotate(transform, degreesToRadians(-90.0));
            
        }
        else if (appDelegate.CameraOrientationForVideo == 2){
            //                PBJCameraOrientationLandscapeRight
            NSLog(@"PBJCameraOrientationLandscapeRight");
            //            transform = CGAffineTransformMakeTranslation(360, 100);
            //transform = CGAffineTransformMakeTranslation(360, 0);
            transform = CGAffineTransformTranslate(transform, 360, 0);
            
            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
            transform = CGAffineTransformScale(transform, 1, 1);
        }
    }
    else{
        //       CGAffineTransform txf = appDelegate.videoPrefferedTransform;
        
        //        if (txf.a == -1) {	//landscape left
        //            transform = CGAffineTransformMakeTranslation(DEVICE_WIDTH, 0);
        //            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
        //            transform = CGAffineTransformTranslate(transform, 400, 0);
        //            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
        //            transform = CGAffineTransformScale(transform, 0.3, 0.3);
        //        }
        //        else if (txf.a == 1){	//landscape right
        ////            transform = CGAffineTransformMakeScale(0.5, 0.5);
        ////            transform = CGAffineTransformTranslate(transform, 0, 300);
        //        }
        //        else if (txf.c == 1){	//portrait button up
        //            transform = CGAffineTransformMakeTranslation(0, DEVICE_HEIGHT);
        //            transform = CGAffineTransformRotate(transform, degreesToRadians(-90.0));
        //            transform = CGAffineTransformScale(transform, 0.5, 0.5);
        //        }
        //        else if (txf.c == -1){		//portrait button down
        ////            transform = CGAffineTransformMakeTranslation(DEVICE_WIDTH, 0);
        ////            transform = CGAffineTransformRotate(transform, degreesToRadians(90.0));
        ////            transform = CGAffineTransformScale(transform, 0.5, 0.5);
        //        }
        //        else{
        //            //all 0
        //            transform = CGAffineTransformMakeTranslation(0, 100);
        //        }
        
    }
    
    /*
     switch (image.imageOrientation) {
     case UIImageOrientationDown:
     case UIImageOrientationDownMirrored:
     transform = CGAffineTransformTranslate(transform, image.size.width, image.size.height);
     transform = CGAffineTransformRotate(transform, M_PI);
     break;
     
     case UIImageOrientationLeft:
     case UIImageOrientationLeftMirrored:
     transform = CGAffineTransformTranslate(transform, image.size.width, 0);
     transform = CGAffineTransformRotate(transform, M_PI_2);
     break;
     
     case UIImageOrientationRight:
     case UIImageOrientationRightMirrored:
     transform = CGAffineTransformTranslate(transform, 0, image.size.height);
     transform = CGAffineTransformRotate(transform, -M_PI_2);
     break;
     case UIImageOrientationUp:
     case UIImageOrientationUpMirrored:
     transform = CGAffineTransformTranslate(transform, 0, image.size.height);
     transform = CGAffineTransformRotate(transform, -M_PI_2);
     
     break;
     }
     
     switch (image.imageOrientation) {
     case UIImageOrientationUpMirrored:
     case UIImageOrientationDownMirrored:
     transform = CGAffineTransformTranslate(transform, image.size.width, 0);
     transform = CGAffineTransformScale(transform, -1, 1);
     break;
     
     case UIImageOrientationLeftMirrored:
     case UIImageOrientationRightMirrored:
     transform = CGAffineTransformTranslate(transform, image.size.height, 0);
     transform = CGAffineTransformScale(transform, -1, 1);
     break;
     case UIImageOrientationUp:
     case UIImageOrientationDown:
     case UIImageOrientationLeft:
     case UIImageOrientationRight:
     break;
     }
     */
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, image.size.width, image.size.height,
                                             CGImageGetBitsPerComponent(image.CGImage), 0,
                                             CGImageGetColorSpace(image.CGImage),
                                             CGImageGetBitmapInfo(image.CGImage));
    CGContextConcatCTM(ctx, transform);
    //    switch (image.imageOrientation) {
    //        case UIImageOrientationLeft:
    //        case UIImageOrientationLeftMirrored:
    //        case UIImageOrientationRight:
    //        case UIImageOrientationRightMirrored:
    //            // Grr...
    //            CGContextDrawImage(ctx, CGRectMake(0,0,image.size.height,image.size.width), image.CGImage);
    //            break;
    //
    //        default:
    //            CGContextDrawImage(ctx, CGRectMake(0,0,image.size.width,image.size.height), image.CGImage);
    //            break;
    //    }
    CGContextDrawImage(ctx, CGRectMake(0,0,image.size.width,image.size.height), image.CGImage);
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    UIImageWriteToSavedPhotosAlbum(img, nil, nil, nil);
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
}

- (UIImage *)fixrotation1:(UIImage *)image{
    if (image.imageOrientation == UIImageOrientationUp) return image;
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    switch (image.imageOrientation) {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.width, image.size.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.width, 0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, image.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationUpMirrored:
            transform = CGAffineTransformTranslate(transform, 0, image.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            
            break;
    }
    
    switch (image.imageOrientation) {
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.width, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
            
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.height, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationDown:
        case UIImageOrientationLeft:
        case UIImageOrientationRight:
            break;
    }
    
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, image.size.width, image.size.height,
                                             CGImageGetBitsPerComponent(image.CGImage), 0,
                                             CGImageGetColorSpace(image.CGImage),
                                             CGImageGetBitmapInfo(image.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (image.imageOrientation) {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,image.size.height,image.size.width), image.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,image.size.width,image.size.height), image.CGImage);
            break;
    }
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
}

#pragma mark - SAVideoRangeSliderDelegate

- (void)videoRange:(SAVideoRangeSlider *)videoRange didChangeLeftPosition:(CGFloat)leftPosition rightPosition:(CGFloat)rightPosition
{
    self.startTime = leftPosition;
    self.stopTime = rightPosition;
    self.timeLabel.text = [NSString stringWithFormat:@"%f - %f", leftPosition, rightPosition];
    self.timeLabel.textColor = [UIColor whiteColor];
    
    [self.moviePlayer.moviePlayer pause];
}

- (void)videoRange:(SAVideoRangeSlider *)videoRange didGestureStateEndedLeftPosition:(CGFloat)leftPosition rightPosition:(CGFloat)rightPosition
{
    
    self.moviePlayer.moviePlayer.currentPlaybackTime = (float)leftPosition;
    [self.moviePlayer.moviePlayer play];
    
    if ([self.playTimer isValid]) {
        [self.playTimer invalidate];
    }
    
    self.playTimer = [NSTimer scheduledTimerWithTimeInterval:rightPosition-leftPosition target:self selector:@selector(stopSliderVideoPlay) userInfo:nil repeats:NO];
}

-(void)stopSliderVideoPlay{
    [self.playTimer invalidate];
    [self.moviePlayer.moviePlayer pause];
}

-(IBAction)cancelClicked:(id)sender{
    
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:VIDEO_RECORDING_FOLDER]){
        NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
        if ([fm fileExistsAtPath:tempPath]) {
            //file exists
            [fm removeItemAtPath:tempPath error:NULL];
        }
    }
    
    appDelegate.FlagVideo = 1;
    
    for (UIViewController *obj in [self.navigationController viewControllers]) {
        
        if ([obj isKindOfClass:[PBJViewControllerHBlab class]]) {
            PBJViewControllerHBlab *obj12 = (PBJViewControllerHBlab *)obj;
            [obj12 handleFlipButtonCancelBtn];
            [self.navigationController popToViewController:obj animated:YES];
            break;
        }
        else if ([obj isKindOfClass:[SetVideoAndPrivacyHBlabVC class]]){
            [self.navigationController popToViewController:obj animated:YES];
            break;
        }
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
