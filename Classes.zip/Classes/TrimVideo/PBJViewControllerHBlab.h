//
//  PBJViewControllerHBlab.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 6/15/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PBJViewControllerHBlab : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>{
    int second;
    int minute;
    
    int secondAtPause;
    int minuteAtPause;
    
}

- (void)handleFlipButton;
@property (nonatomic, readwrite) BOOL           isDoneClicked;
@property (nonatomic, readwrite) BOOL           isShouldMerge;
@property (nonatomic, strong) NSDate					*startDate;
@property (nonatomic, readwrite) NSTimeInterval			pauseTimeinterval;
@property (nonatomic, strong) UILabel           *lblProgressBar;
//@property (nonatomic, strong) UILabel           *lblForOrientation;
@property (nonatomic, readwrite) BOOL           isRecordingStarted;

@property (nonatomic, readwrite) BOOL           isPaused;

- (void)handleFlipButtonCancelBtn;

@end
