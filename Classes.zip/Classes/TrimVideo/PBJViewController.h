//
//  PBJViewController.h
//  Vision
//
//  Created by Patrick Piemonte on 7/23/13.
//  Copyright (c) 2013-present, Patrick Piemonte, http://patrickpiemonte.com
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy of
//  this software and associated documentation files (the "Software"), to deal in
//  the Software without restriction, including without limitation the rights to
//  use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
//  the Software, and to permit persons to whom the Software is furnished to do so,
//  subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
//  FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
//  COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
//  IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
//  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

#import <UIKit/UIKit.h>

@interface PBJViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>{
    int second;
    int minute;
    
    int secondAtPause;
    int minuteAtPause;

}

- (void)handleFlipButton;
@property (nonatomic, readwrite) BOOL           isDoneClicked;
@property (nonatomic, readwrite) BOOL           isShouldMerge;
@property (nonatomic, strong) NSDate					*startDate;
@property (nonatomic, readwrite) NSTimeInterval			pauseTimeinterval;
@property (nonatomic, strong) UILabel           *lblProgressBar;
//@property (nonatomic, strong) UILabel           *lblForOrientation;
@property (nonatomic, readwrite) BOOL           isRecordingStarted;

@property (nonatomic, readwrite) BOOL           isPaused;

- (void)handleFlipButtonCancelBtn;
@end
