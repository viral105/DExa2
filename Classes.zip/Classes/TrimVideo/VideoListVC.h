//
//  VideoListVC.h
//  Vision
//
//  Created by Multicore on 02/04/15.
//  Copyright (c) 2015 Patrick Piemonte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>
#import <MobileCoreServices/UTCoreTypes.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <MediaPlayer/MediaPlayer.h>

#import "SAVideoRangeSlider.h"

@interface VideoListVC : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,MPMediaPickerControllerDelegate,SAVideoRangeSliderDelegate>{
    
    AppDelegate *appDelegat;
    
    NSURL *vedioURL;
    
    IBOutlet UIImageView *imageVideoThumb;
    
    IBOutlet UIView *viewlbl;
    
    IBOutlet UILabel *lblTime;

    
}
@property (nonatomic,strong) IBOutlet UIImageView *imageVideoThumb;
@property (nonatomic, readwrite) int                orientation;

@property (nonatomic, strong) MPMoviePlayerViewController   *moviePlayer;
@property (nonatomic, strong) NSTimer               *playTimer;

-(IBAction)cancelClicked:(id)sender;



@end
