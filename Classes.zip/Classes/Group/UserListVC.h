//
//  UserListVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 9/3/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol UserListVCDelegate;

@protocol UserListVCDelegate <NSObject>
- (void)showButton;
- (void)hideButton;

@end


@interface UserListVC : UIViewController <UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate,UIAlertViewDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrDataAll;
@property (nonatomic, strong) NSMutableArray				*arrDataBlocked;
@property (nonatomic, strong) NSMutableDictionary			*sections;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, strong) NSMutableArray				*arrSelected;
@property (nonatomic, retain) IBOutlet UILabel				*lblInfo;

@property (nonatomic, strong) ASIHTTPRequest				*request;

@property (nonatomic, strong) UIScrollView					*scrollContainer;

@property (nonatomic, readwrite) int						selectedParentView_Index;

@property (nonatomic ,assign) id <UserListVCDelegate>       delegate;

@property (nonatomic, retain) IBOutlet UILabel              *lblNoUserFound;

-(void)loadUserListingView;
@end
