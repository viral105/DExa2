//
//  GroupListCell.m
//  WWHHAAZZAAPP
//
//  Created by s on 9/4/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "GroupListCell.h"
#define CellHeight			56
#define BtnDeleteTitle			@" Delete"
#define BtnEditTitle			@" Edit"


@implementation GroupListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
		self.backgroundColor = [UIColor clearColor];
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		
		float xStart = 5;
		//float yStart = 5;
		
		self.cellBg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:LilstBox_Bg]] ;
		self.lblGroupName = [[UILabel alloc] init] ;
		self.btnGroupEdit = [UIButton buttonWithType:UIButtonTypeCustom];
		self.btnGroupDelete = [UIButton buttonWithType:UIButtonTypeCustom];
		
		
		
		self.cellBg.frame = CGRectMake(3.5, 4, 313, CellHeight);
		
		xStart = 10;
	//	yStart = 3;
		
				
		self.lblGroupName.frame = CGRectMake(xStart, 3, self.cellBg.frame.size.width-xStart-45, (self.cellBg.frame.size.height*2)/3);
		//yStart +=(self.lblGroupName.frame.size.height);
		
		xStart = DEVICE_WIDTH-(70*2);
		
		self.btnGroupEdit.frame = CGRectMake(xStart, (self.cellBg.frame.size.height-28), 60, 30);
		
		xStart = self.frame.size.width-70;
		self.btnGroupDelete.frame = CGRectMake(xStart, (self.cellBg.frame.size.height-28), 60, 30);
		
		
		[self.lblGroupName setBackgroundColor:[UIColor clearColor]];
		self.btnGroupDelete.backgroundColor = [UIColor clearColor];
		self.btnGroupEdit.backgroundColor = [UIColor clearColor];
		
		self.btnGroupDelete.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
		self.btnGroupEdit.contentVerticalAlignment = UIControlContentHorizontalAlignmentCenter;
		
		self.btnGroupDelete.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
		self.btnGroupEdit.contentVerticalAlignment = UIControlContentHorizontalAlignmentCenter;
		
		[self.btnGroupDelete setTitle:BtnDeleteTitle forState:UIControlStateNormal];
		[self.btnGroupEdit setTitle:BtnEditTitle forState:UIControlStateNormal];
		
		[self.btnGroupEdit setImage:[UIImage imageNamed:Btn_Group_Edit] forState:UIControlStateNormal];
		[self.btnGroupDelete setImage:[UIImage imageNamed:BtnNotifDelete] forState:UIControlStateNormal];
		
		[self.btnGroupDelete setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
		[self.btnGroupEdit setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
		
//		self.lblGroupName.font = [UIFont fontWithName:Font_OpneSans_Light size:19];
		self.lblGroupName.font = [UIFont fontWithName:Font_OpneSans_SemiBol size:19];
		
		[self.btnGroupDelete.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Light size:11]];
		[self.btnGroupDelete  setTitleColor:UIColorFromRGB(0X3f454c) forState:UIControlStateNormal];
		
		[self.btnGroupEdit.titleLabel setFont:[UIFont fontWithName:Font_OpneSans_Light size:11]];
		[self.btnGroupEdit  setTitleColor:UIColorFromRGB(0X3f454c) forState:UIControlStateNormal];
		
		
		[self.contentView addSubview:self.cellBg];
		[self.contentView addSubview:self.lblGroupName];
		[self.contentView addSubview:self.btnGroupEdit];
		[self.contentView addSubview:self.btnGroupDelete];
		
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
	
    // Configure the view for the selected state
}

-(void)validateDisplayName:(NSDictionary *)dic{
	NSString *strDisplayName = [DataValidation checkNullString:[dic valueForKey:GRP_NAME]];
	if (strDisplayName.length==0) {
		strDisplayName = [NSString stringWithFormat:@"%@",[dic valueForKey:GRP_NAME]];
	}
	
	self.lblGroupName.text = strDisplayName;
	
}

-(void)setBoxValuesWithData:(NSDictionary *)dic{
	[self validateDisplayName:dic];
	if ([DataValidation checkNullString:self.lblGroupName.text].length > 0) {
//		[self.lblGroupName setTextColor:[Validation getColorForAlphabet:[self.lblGroupName.text substringToIndex:1]]];
		[self.lblGroupName setTextColor:[Validation getColorForAlphabet:self.lblGroupName.text]];		
	}
	
}

@end
