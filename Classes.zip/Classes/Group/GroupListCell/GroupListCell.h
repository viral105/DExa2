//
//  GroupListCell.h
//  WWHHAAZZAAPP
//
//  Created by s on 9/4/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GroupListCell : UITableViewCell
@property (nonatomic, strong) UIImageView		*cellBg;
@property (nonatomic, strong) UILabel			*lblGroupName;
@property (nonatomic, strong) UIButton			*btnGroupEdit;
@property (nonatomic, strong) UIButton			*btnGroupDelete;


-(void)setBoxValuesWithData:(NSDictionary *)dic;

@end
