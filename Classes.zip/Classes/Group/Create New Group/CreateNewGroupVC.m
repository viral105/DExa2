//
//  CreateNewGroupVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 9/3/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "CreateNewGroupVC.h"
#import "UserCell.h"
#import "MBProgressHUD.h"

#define IS_SELECTED			@"is_selected"
#define TextFieldHeight		45
#define SelectedSection		@"selectedSection"
#define SelectedRow			@"selectedRow"


@interface CreateNewGroupVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation CreateNewGroupVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];

	[self loadUserListingVC];
}

-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
    appDelegate.currentVc = self;
}

-(void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
	[self.tfGrpName resignFirstResponder];
    appDelegate.isShouldShowReplyPopUp = NO;
}

-(void)loadUserListingVC{
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
	
	if (self.objUserListVC != nil) {
		self.objUserListVC.delegate = nil;
		self.objUserListVC = nil;
	}
	
//	UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
	self.objUserListVC = [MainStoryboard instantiateViewControllerWithIdentifier:USER_LIST_VC];
	self.objUserListVC.delegate = self;
	self.objUserListVC.selectedParentView_Index = 1;
    self.objUserListVC.view.frame = CGRectMake(0, 68+TextFieldHeight, 320, DEVICE_HEIGHT-(68+TextFieldHeight));
    [self.view addSubview:self.objUserListVC.view];
    [self.objUserListVC didMoveToParentViewController:self];
    [self addChildViewController:self.objUserListVC];
	[self.view bringSubviewToFront:self.btnSave];
    
    self.objUserListVC.view.backgroundColor = [UIColor redColor];
    
    [self performSelector:@selector(loadDataInChildView:) withObject:[NSNumber numberWithInt:1] afterDelay:0.1];
}

-(void)loadDataInChildView:(NSNumber *)listForIndex{
    
    self.objUserListVC.selectedParentView_Index = [listForIndex intValue];
    [self.objUserListVC loadUserListingView];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    [self.view endEditing:YES];
    
    //    UITableView *tblRegister = (UITableView*) [self.view viewWithTag:kSignUpTableViewTag];
    //    [tblRegister setContentOffset:CGPointMake(0, 0) animated:YES];
}
- (void)showButton{
	self.btnSave.hidden = FALSE;
}

- (void)hideButton{
	self.btnSave.hidden = TRUE;
}

#pragma mark	UIButton Action

-(IBAction)btnBackClicked:(id)sender{
	
	[self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnSaveClicked:(id)sender{
	
	if ([DataValidation checkNullString:self.tfGrpName.text].length > 0) {
		
		[HUD show:YES];
		
		NSLog(@"%@",self.objUserListVC.arrSelected);
		
		NSArray *arrSelectedUsers = [NSArray arrayWithArray:[self.objUserListVC.arrSelected valueForKey:USER_ID]];
		NSLog(@"selected Users = %@",arrSelectedUsers);
		self.objUserListVC.delegate = nil;
		self.objUserListVC = nil;
		[self createGroup:arrSelectedUsers];
	}
	else{
		[Validation highLightTextField:self.tfGrpName inView:self.view];
		[Validation showToastMessage:@"Enter valid group name." displayDuration:ERROR_MSG_DURATION];
	}
}

#pragma mark	UITextField Action

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
	[textField resignFirstResponder];
	return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (textField.text.length >= 20) {
        [Validation showToastMessage:@"Maximum 20 characters are allowed" displayDuration:3];
        return FALSE;
    }
    return TRUE;
}
-(void)createGroup:(NSArray *)arrSelectedUserId{
	NSLog(@"createGroup:arrSelectedUserId = %@",arrSelectedUserId);
	
	if (self.request !=nil) {
		self.request = nil;
	}
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[DataValidation checkNullString:self.tfGrpName.text]],KeyValue,@"GroupName",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"2",
						 
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[arrSelectedUserId componentsJoinedByString:@"|"]],KeyValue,@"GroupUserIDs",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"true", KeyValue, @"IsPublic",KeyName,nil],@"4",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:CREAT_NEW_GROUP withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//	self.request.delegate = self;
//	self.request.tag = 1;
	strUrl = nil;
}

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData] options:0 error:&error];;
	
	//NSLog(@"dictionary = %@",dicResponse);
	
	[HUD hide:YES];
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [appDelegate callLogOutService];
        }
        else{
            if (request.tag == 1) {
                [Validation showToastMessage:@"Group created" displayDuration:ERROR_MSG_DURATION];
                [appDelegate.dic_NotificationReleatedData setValue:[NSNumber numberWithBool:NO] forKeyPath:Is_Create_Direct_Group];
                [appDelegate.dic_NotificationReleatedData setValue:nil forKeyPath:Selected_Friends_For_Creating_Group];
                [self.navigationController popViewControllerAnimated:NO];
            }
        }
    }
    else{
        [HUD hide:YES];
    }
    dicResponse =nil;
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
