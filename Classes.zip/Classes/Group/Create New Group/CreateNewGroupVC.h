//
//  CreateNewGroupVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 9/3/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UserListVC.h"

@interface CreateNewGroupVC : UIViewController <UITextFieldDelegate,UserListVCDelegate>

@property (nonatomic, strong) IBOutlet	UITextField			*tfGrpName;

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) IBOutlet UIButton				*btnSave;

@property (nonatomic, strong) UserListVC					*objUserListVC;

@property (nonatomic, strong) ASIFormDataRequest			*request;
//@property (nonatomic, retain) NSArray						*arrSelectedUsers;
@end
