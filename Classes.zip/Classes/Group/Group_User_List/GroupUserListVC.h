//
//  GroupUserListVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 9/3/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserListVC.h"

@interface GroupUserListVC : UIViewController <UITextFieldDelegate,UserListVCDelegate,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@property (nonatomic, strong) IBOutlet	UITextField			*tfGrpName;

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) IBOutlet UIButton				*btnSave;

@property (nonatomic, strong) IBOutlet UIButton				*btnBack;

@property (nonatomic, strong) IBOutlet UIButton				*btnShowUserListToAdd;

@property (nonatomic, strong) UserListVC					*objUserListVC;

@property (nonatomic, strong) ASIFormDataRequest			*request;

@property (nonatomic, strong) NSDictionary					*DicGrpDetail;

@property (nonatomic, strong) NSMutableArray				*arrData;

@property (nonatomic, strong) NSMutableArray				*arrDeletedData;

@property (nonatomic, strong) NSMutableArray				*arrAddedData;

@property (nonatomic, readwrite) int						pageCounter;

@property (nonatomic, readwrite) BOOL						isDataNull;

@property (nonatomic, strong) IBOutlet UITableView			*tblData;

@property (nonatomic, strong) IBOutlet UILabel				*lblNoUserInGrpFound;

@property (nonatomic, strong) IBOutlet AsyncImageView       *imgGroup;

@property (nonatomic, strong) IBOutlet UIButton             *btnEditGroupPic;

@end
