//
//  GroupListVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 9/3/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GroupListVC : UIViewController <UITableViewDataSource, UITableViewDelegate,UIAlertViewDelegate,UIActionSheetDelegate,AFNetworkingDataTransactionDelegate>

@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, strong) IBOutlet UILabel				*lblNoGrpFound;
@property (nonatomic, readwrite) int						selectedIndex;
@property (nonatomic, strong) AFNetworkingDataTransaction	*request;
@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) UIActivityIndicatorView		*activityLoading;

@end
