//
//  GroupListVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 9/3/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "GroupListVC.h"
#import "GroupUserListVC.h"
#import "GroupListCell.h"
#import "NotifOptionVC.h"
#import "MBProgressHUD.h"
#import "UserConversationChatVC.h"
#import "TextBlabVC.h"

#define CellHeight			63
#define PageSize			8


@interface GroupListVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}

@end

@implementation GroupListVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	self.arrData = [[NSMutableArray alloc] init] ;
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
    [self.lblNoGrpFound setTextColor:TWITTER_BLUE_COLOR];
    [self.lblNoGrpFound setShadowColor:[UIColor clearColor]];

    NSLog(@"dic = %@",appDelegate.dic_NotificationReleatedData);
	self.pageCounter= 1;
	self.lblNoGrpFound.hidden = YES;
	//[Validation showLoadingIndicator];
   
	[self loadUserListingVC];
}

-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
	appDelegate.currentVc = self;
	//self.lblNoGrpFound.hidden = FALSE;
    [self performSelectorInBackground:@selector(GetGroupList) withObject:nil];
    
    [Validation removeAdviewFromSuperView];
	[self.view addSubview:[Validation sharedBannerView]];
	[Validation ResizeViewForAds];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark	UIButton Action

-(void)loadUserListingVC{
	
	//show user listing here only
	// and when user clickes on add user to group then go to this
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
	
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
	
	
	self.pageCounter = 1;
	self.lblNoGrpFound.hidden = YES;
}

-(IBAction)btnBackClicked:(id)sender{
    
    NSArray *arr = [self.navigationController viewControllers];
    for (UIViewController *v in arr) {
        if ([v isKindOfClass:[AddFriendFromExistingFriendListVC class]]) {
            [self.navigationController popToViewController:v animated:YES];
            break;
        }
    }
	
   // [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnAddGroupClicked:(id)sender{
    NSLog(@"%@ %@",[appDelegate.dic_NotificationReleatedData valueForKey:TOTAL_FRIENDS],appDelegate.dic_NotificationReleatedData);
    if ([DataValidation checkNullString:[appDelegate.dic_NotificationReleatedData valueForKey:TOTAL_FRIENDS]].length>0 && [[appDelegate.dic_NotificationReleatedData valueForKey:TOTAL_FRIENDS] intValue]>0) {
        [Validation CancelOnGoingRequests:self.request];
        [self.request CancleOngoingRequest];
        [self.request setDelegate:nil];
        self.request = nil;
        [self performSegueWithIdentifier:CREATE_NEW_GRP_VC sender:nil];
    }
    else{
        [Validation showToastMessage:@"You don't have any friends in your friend list.\nPlease go to search and add some friend in your friend list." displayDuration:INFO_MSG_DURATION];
    }
}

-(void)showYapOptions{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Select" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:Only_Yap,Yap_With_Image,Yap_With_Video,Text_Blab, nil];
    [action showInView:self.view];
    action.delegate = self;
}

-(void)GetGroupList{
	if (self.request !=nil) {
		self.request = nil;
	}
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_GRP_LIST withParameters:nil];
//	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
//	self.request.delegate = self;
//	self.request.tag = 1;
    
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:1];
	strUrl = nil;
}

-(void)deleteGroupFromlist{
	if (self.request !=nil) {
		self.request = nil;
	}
	//[Validation showLoadingIndicator];
    [HUD show:YES];
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:GRP_ID]],KeyValue,@"GroupID",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:DELETE_GRP withParameters:nil];
    self.request = [AFNetworkingDataTransaction sharedManager];
    [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:2];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:2];
    
    
//	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
//	self.request.delegate = self;
//	self.request.tag = 2;
	strUrl = nil;

}

#pragma mark
#pragma mark		UITableView DataSource Methos
#pragma mark

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//	if (!self.isDataNull) {
//		if (self.arrData.count>PageSize-1) {
//			return self.arrData.count+1;
//		}
//		return self.arrData.count;
//	}
	return self.arrData.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return CellHeight;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
		
	NSString *cellId = [NSString stringWithFormat:@"%d",(int)indexPath.row];
	
	if (indexPath.row < self.arrData.count) {
		cellId = [cellId stringByAppendingFormat:@"%@%@",[[self.arrData objectAtIndex:indexPath.row] valueForKey:GRP_ID],[[self.arrData objectAtIndex:indexPath.row] valueForKey:GRP_NAME]];
	}
	
	GroupListCell *cell = (GroupListCell *)[tableView dequeueReusableCellWithIdentifier:cellId];
	[cell clearsContextBeforeDrawing];

    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary*)[self.arrData objectAtIndex:indexPath.row]];
    if (cell == nil) {
        cell = [[GroupListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        [cell setBoxValuesWithData:dic];
        [cell.btnGroupEdit addTarget:self action:@selector(btnEditClicked:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnGroupDelete addTarget:self action:@selector(btnDeleteClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    cell.btnGroupEdit.tag = indexPath.row;
    cell.btnGroupDelete.tag = indexPath.row;
    
    dic = nil;

    if (indexPath.row == self.arrData.count-1) {
		if (self.isDataNull == NO) {
//			cell = [[GroupListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
//			cell.cellBg.hidden = YES;
//			cell.lblGroupName.hidden= YES;
//			cell.btnGroupDelete.hidden = YES;
//			cell.btnGroupEdit.hidden = YES;
//			
//			if (self.activityLoading != nil) {
//				[self.activityLoading removeFromSuperview];
//				self.activityLoading = nil;
//			}
//			self.activityLoading = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
//			self.activityLoading.center = cell.contentView.center;
//			self.activityLoading.frame = cell.contentView.frame;
//			self.activityLoading.hidesWhenStopped = TRUE;
//			[self.activityLoading startAnimating];
//			[cell.contentView addSubview:self.activityLoading];
			[HUD show:YES];
            
			self.pageCounter++;
			[self performSelectorInBackground:@selector(GetGroupList) withObject:nil];
		}
	}
	
	return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	
    self.selectedIndex = (int)indexPath.row;
    
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
	[Validation CancelOnGoingRequests:self.request];
    
    if (appDelegate.isForwarded) {
        [self callForwardNotifToSelectedGrouAtIndex:(int)indexPath.row];
    }
    else{
/*        if ([[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:@"IsAllBlock"]] boolValue]) {
            [Validation showToastMessage:@"You have blocked all users in this group." displayDuration:ERROR_MSG_DURATION];
        }
        else if ([DataValidation checkNullString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:@"GroupUserIDs"]]].length > 0) {
            [self showYapOptions];
        }
        else{
            [Validation showToastMessage:@"No friend found in this group." displayDuration:ERROR_MSG_DURATION];
        }
*/
        [self showYapOptions];
    }
}

-(void)callForwardNotifToSelectedGrouAtIndex:(int)index{
    if (self.request !=nil) {
        self.request = nil;
    }
    
    [HUD show:YES];
    
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ReceiverIDs",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[appDelegate.dic_NotificationReleatedData valueForKey:SelectedBlabDic] valueForKey:@"Ctype"]],KeyValue,@"Ctype",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:[[self.arrData objectAtIndex:index] valueForKey:GRP_ID],KeyValue,@"GroupIDs",KeyName, nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[appDelegate.dic_NotificationReleatedData valueForKey:SelectedBlabDic] valueForKey:@"SubCatID"]],KeyValue,@"SubCatID",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[appDelegate.dic_NotificationReleatedData valueForKey:SelectedBlabDic]valueForKey:@"ID"]],KeyValue,@"ID",KeyName, nil],@"6",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"false",KeyValue,@"AllFriend",KeyName, nil],@"7",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:@"TypeID"]],KeyValue,BlabType,KeyName, nil],@"8",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"9",
                         nil];
    
    NSLog(@"sendMessage => dic => %@",dic);
    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];
    //    self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    //    self.request.delegate = self;
    //    self.request.tag = 4;
    self.request = [AFNetworkingDataTransaction sharedManager];
  //  [self.request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    [self.request SetCallForURLWithImg:strUrl WithDic:dic isAddHeader:TRUE forLoader:HUD];
    if (self.request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:4];
    }
//    [self.request setDelegate:self];
//    [self.request setTag:4];
    strUrl = nil;
}

-(void)btnEditClicked:(id)sender{
	self.selectedIndex = (int)((UIButton *)sender).tag;
	[Validation CancelOnGoingRequests:self.request];
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
	self.request = nil;
    [self performSegueWithIdentifier:EDIT_GRP_LIST_VC sender:nil];
	
}

-(void)btnDeleteClicked:(id)sender{
	self.selectedIndex = (int)((UIButton *)sender).tag;
	[AlertHandler alertTitle:CONFIRM message:CONFIRM_GRP_DELETE delegate:self tag:0 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
	if (buttonIndex == alertView.cancelButtonIndex) {
		
	}
	else{
		[self deleteGroupFromlist];
	}
}
#pragma mark	UITextField Action
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (textField.text.length >= 20) {
        [Validation showToastMessage:@"Maximum 20 characters are allowed" displayDuration:3];
        return FALSE;
    }
    return TRUE;
}
#pragma mark
#pragma mark web service method

#pragma mark
#pragma mark web service method


- (void)successResponseWithData:(id)request withTag:(int)tag{
//	NSError *error = nil;
	if (self.activityLoading != nil) {
		[self.activityLoading removeFromSuperview];
		self.activityLoading = nil;
	}

   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
	
	//NSLog(@"dictionary = %@",dicResponse);
	
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if ([dicResponse objectForKey:RESPONSE] != nil) {
                
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    
                    if (tag == 1){
                        //get grp list
                        //received
                        
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            if (self.pageCounter==1) {
                                [self.arrData removeAllObjects];
                            }
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.isDataNull = NO;
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            
                            if (arr.count>0) {
                                [self.arrData addObjectsFromArray:arr];
                                
                                [self.tblData reloadData];
                            }
                            if (self.arrData.count>0) {
                                self.lblNoGrpFound.hidden = YES;
                            }
                            arr = nil;
                        }
                        response = nil;
                        [HUD hide:YES];
                    }
                    else if (tag == 2){
                        //delete group
                        [HUD hide:YES];
                        [Validation showToastMessage:@"Group deleted successfully." displayDuration:SUCCESS_MSG_DURATION];
                        [self.arrData removeObjectAtIndex:self.selectedIndex];
                        
                        if (self.arrData.count == 0) {
                            self.lblNoGrpFound.hidden = FALSE;
                        }
                        
                        [self.tblData reloadData];
                    }
                    else if (tag == 4){
                        //notofication response
                        NSLog(@"%@",dicResponse);
                        __block UIImageView *imageView;
                        UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                        imageView = [[UIImageView alloc] initWithImage:image];
                        HUD.customView = imageView;
                        HUD.mode = MBProgressHUDModeText;
                        HUD.labelText = @"Sent";
                        imageView = nil;
                        
                        [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:3];
                    }
                }
                else{
                    if (tag==4) {
                        if ([[dicResponse objectForKey:RESPONSE] isKindOfClass:[NSArray class]]) {
                            
                            //[Validation showToastMessage:[[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] displayDuration:ERROR_MSG_DURATION];
                            HUD.mode = MBProgressHUDModeText;
                            HUD.delegate = self;
                            HUD.detailsLabelFont = [UIFont boldSystemFontOfSize:16];
                            HUD.detailsLabelText = [[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] ;
                            [self performSelector:@selector(popToNotifListScreen) withObject:nil afterDelay:4];
                        }
                        else{
                            [HUD hide:YES];
                            
                        }
                    }
                    else{
                        [HUD hide:YES];
                        self.isDataNull = YES;
                        if (self.arrData.count ==0) {
                            self.lblNoGrpFound.hidden = FALSE;
                        }
                    }
                    

                }
                self.request = nil;
            }
            else{
                [HUD hide:YES];
                if (self.arrData.count ==0) {
                    self.lblNoGrpFound.hidden = FALSE;
                }
            }
            
            dicResponse = nil;
        }

    }
    else{
        [HUD hide:YES];
    }
    dicResponse = nil;
}


- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}
-(void)popToNotifListScreen{
    
    [self.request CancleOngoingRequest];
    [self.request setDelegate:nil];
	self.request = nil;
    
    [Validation cleanNotifcationRelatedDicData];
    
	[HUD hide:YES];
    
  
    NSArray *arr = [self.navigationController viewControllers];
    BOOL isGotPopViewController = FALSE;
    
    for (UIViewController *v in arr) {
        if ([v isKindOfClass:[UserConversationChatVC class]]) {
            isGotPopViewController = TRUE;
            [self.navigationController popToViewController:v animated:YES];
            break;
        }
        if ([v isKindOfClass:[FavoritesVC class]]) {
            isGotPopViewController = TRUE;
            [self.navigationController popToViewController:v animated:YES];
            break;
        }
    }
    
    
    if (!isGotPopViewController) {
        
        [self removeViewControllersFromStack];
        
        if (appDelegate.selectedMenuIndex>0) {
            appDelegate.selectedMenuIndex = 0;
 //           UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
            
            [UIView transitionWithView:self.navigationController.view
                              duration:0.5
                               options:UIViewAnimationOptionTransitionCrossDissolve
                            animations:^{
                                [self.navigationController pushViewController:ivc animated:NO];
                            }
                            completion:nil];
            
        }
        else{
   //         UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            NotificationVC *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:NOTIFICATION_VC];
            [self.navigationController pushViewController:ivc animated:YES];
        }
    }
}

-(void)removeViewControllersFromStack{
    //   NSArray *arrVC = self.navigationController.viewControllers;
    for (id vc in self.navigationController.viewControllers){
		if ([vc isKindOfClass:[FavoritesVC class]]) {
			[self removeFromNavigationController:vc animated:NO];
		}
        else if ([vc isKindOfClass:[SearchFriendVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[OtherFriendNotifListVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[SettingsVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[CategoryListForUploadVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[GroupListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[UserListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[RecordingOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
	}
    
}

-(void)removeFromNavigationController:(UIViewController *)controller animated:(BOOL)animated {
    
    NSMutableArray *allViewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];;
    [allViewControllers removeObjectIdenticalTo:controller];
    self.navigationController.viewControllers = allViewControllers;
	
}


#pragma mark    UIActionsheet Delegate

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"button index = %d",(int)buttonIndex);
    
    if (buttonIndex == actionSheet.cancelButtonIndex) {
        
    }
    else if (buttonIndex == 0){
        //only yap
        [self.request CancleOngoingRequest];
        [self.request setDelegate:nil];
        self.request = nil;
        [self performSegueWithIdentifier:RECORD_OPTION_VC sender:nil];
    }
    else if (buttonIndex == 1){
        //yap with image
        [self.request CancleOngoingRequest];
        [self.request setDelegate:nil];
        self.request = nil;
        [self performSegueWithIdentifier:CAPTURE_IMAGE_VC sender:nil];
    }
    else if (buttonIndex == 2){
        //yap with video
        [self.request CancleOngoingRequest];
        [self.request setDelegate:nil];
        self.request = nil;
        if ([[NSFileManager defaultManager] fileExistsAtPath:VIDEO_RECORDING_FOLDER]) {
            //when folder exists
            NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
            if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
                [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
            }
        }
        [self performSegueWithIdentifier:SET_VIDEO_PRIVACY_VC sender:nil];
    }
    else if (buttonIndex == 3) {
        TextBlabVC *objVc = [self.storyboard instantiateViewControllerWithIdentifier:@"TextBlabVC"];
        objVc.isGroupMessage = TRUE;
        NSLog(@"%@",[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:GRP_ID]]);
        objVc.strReceiverId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:GRP_ID]];
        [self.navigationController pushViewController:objVc animated:YES];
    }
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:EDIT_GRP_LIST_VC]  ) {
		GroupUserListVC *obj = segue.destinationViewController;
		obj.DicGrpDetail = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.selectedIndex]];
	}
    else if ([segue.identifier isEqualToString:RECORD_OPTION_VC] || [segue.identifier isEqualToString:CAPTURE_IMAGE_VC] || [segue.identifier isEqualToString:SET_VIDEO_PRIVACY_VC]) {
        if (appDelegate.dic_NotificationReleatedData != nil) {
            appDelegate.dic_NotificationReleatedData = nil;
        }
        
        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    [NSArray arrayWithObjects:[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:GRP_ID], nil],SelectedIds,
                                                    [NSNumber numberWithBool:YES],IS_GroupNotif,
                                                    [NSNumber numberWithBool:NO],IS_NotifSendToAll,
                                                    @"0",BlabType,
                                                    nil];
    }
    [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
    [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];

}


@end
