//
//  UserListVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 9/3/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "UserListVC.h"
#import "UserCell.h"
#import "MBProgressHUD.h"

#define IS_SELECTED			@"is_selected"
#define ScrollHeight		30
#define SelectedSection		@"selectedSection"
#define SelectedRow			@"selectedRow"
#define LabelHeight			18
#define CellIdentifier		@"cellIdentifier"


@interface UserListVC () <MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
    NSIndexPath *indPathSel;
}

@end

@implementation UserListVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    HUD = [[MBProgressHUD alloc] initWithView:[[UIApplication sharedApplication] keyWindow]];
	[[[UIApplication sharedApplication] keyWindow] addSubview:HUD];

    [self.lblNoUserFound setTextColor:TWITTER_BLUE_COLOR];
    [self.lblNoUserFound setShadowColor:[UIColor clearColor]];
    self.lblInfo.hidden = YES;
	self.arrDataAll = [[NSMutableArray alloc] init] ;
	self.arrDataBlocked = [[NSMutableArray alloc] init] ;
	self.sections = [[NSMutableDictionary alloc] init] ;
	[self.tblData registerNib:[UINib nibWithNibName:@"UserCell" bundle:nil] forCellReuseIdentifier:@"cellIdentifier"];
	//[self loadUserListingView];
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated{
    appDelegate.currentVc = self;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark	UIButton Action

-(void)loadUserListingView{
	NSLog(@"%@",[NSNumber numberWithBool:self.lblInfo.hidden]);
	
	self.view.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
    self.lblNoUserFound.backgroundColor = UIColorFromRGB(0Xefefef);
	[self.lblNoUserFound setHidden:YES];
//	[self.arrDataAll removeAllObjects];
//	[self.arrDataBlocked removeAllObjects];
	
	self.pageCounter = 1;

    [HUD show:YES];
    
	switch (self.selectedParentView_Index) {
		case 1:{
			//create group
//			self.b.tag = 0;
            self.lblInfo.hidden = NO;
			if (self.arrDataAll.count > 0) {
				[self reloadTableBeforeReposneIsReceived];
			}
			[self performSelector:@selector(getMyFriendList) withObject:nil afterDelay:0.2];
		}
			break;
		case 2:{
			//block unblock- all
			//			self.b.tag = 0;
			self.lblInfo.hidden = YES;
			if (self.arrDataAll.count > 0) {
				[self reloadTableBeforeReposneIsReceived];
			}
			[self performSelector:@selector(getMyFriendList) withObject:nil afterDelay:0.2];
		}
			break;
		case 3:{
			//blocked users only
			self.lblInfo.hidden = YES;
			if (self.arrDataBlocked.count > 0) {
				[self reloadTableBeforeReposneIsReceived];
			}
			[self performSelector:@selector(getBlockedFriendList) withObject:nil afterDelay:0.2];
		}
		default:
			break;
	}
	
	self.tblData.frame = CGRectMake(0, ([self.lblInfo isHidden])?0:LabelHeight, 320, self.view.frame.size.height-LabelHeight);
    self.lblNoUserFound.frame = self.tblData.frame;
}

-(IBAction)btnSaveAndAddGroupClicked:(id)sender{
	if (((UIButton *)sender).tag == 0) {
		//create group
		[self.navigationController popViewControllerAnimated:YES];
	}
}
-(void)reloadTableBeforeReposneIsReceived{
	[self.tblData reloadData];
}
-(void)getMyFriendList{
	
	//[HUD hide:YES];
	if (self.arrDataAll.count==0) {
    //    [HUD show:YES];
    }


	if (self.request !=nil) {
		self.request = nil;
	}
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"100"],KeyValue,@"PageSize",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_MYFRIENDS_LIST withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//	self.request.delegate = self;
//	self.request.tag = 1;
	strUrl = nil;
}

-(void)getBlockedFriendList{
	
//	[HUD hide:YES];
	if (self.arrDataBlocked.count==0) {
   //     [HUD show:YES];
	}
	

	if (self.request !=nil) {
		self.request = nil;
	}
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"100"],KeyValue,@"PageSize",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_BLOCKED_USER_LIST withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:4];
    }
//	self.request.delegate = self;
//	self.request.tag = 4;
	strUrl = nil;
}

-(void)SetSectionArrayToLoadDataForArr:(NSMutableArray *)arr{
	BOOL  found = NO;
	for (NSDictionary *user in arr)
    {
		NSString *strName = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[user objectForKey:NAME]]];
		
		if (strName.length == 0) {
			strName = [NSString stringWithFormat:@"%@",[user objectForKey:USER_NAME]];
		}
		strName = [strName lowercaseString];
		
        NSString *c = [strName substringToIndex:1];
		
        found = NO;
		
        for (NSString *str in [self.sections allKeys])
        {
            if ([str isEqualToString:c])
            {
                found = YES;
				[[self.sections objectForKey:[strName substringToIndex:1]] addObject:user];
            }
        }
		
        if (!found)
        {
            [self.sections setValue:[[NSMutableArray alloc] init] forKey:c];
			[[self.sections objectForKey:[strName substringToIndex:1]] addObject:user];
        }
    }
	
	for (NSString *key in [self.sections allKeys])
    {
        [[self.sections objectForKey:key] sortUsingDescriptors:[NSArray arrayWithObject:[NSSortDescriptor sortDescriptorWithKey:NAME ascending:YES]]];
    }
	
	[self.sections setValue:[[NSMutableArray alloc] init] forKey:@"zoo"];
	
	NSLog(@"Sections = %@",[self.sections allKeys]);
	
	[self.tblData reloadData];
}

-(void)BlockSelectedUser:(NSDictionary *)dicForSelectedUser{
	if (self.request !=nil) {
		self.request = nil;
	}
	
	BOOL isBlocked = [[NSString stringWithFormat:@"%@",[dicForSelectedUser valueForKey:IS_USER_BLOCKED]]  boolValue];
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dicForSelectedUser valueForKey:USER_ID]],KeyValue,@"BlockUserID",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:(!isBlocked)?@"false":@"true",KeyValue,@"IsBlock",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:BLOCK_UNBLOCK_USER withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
//        [self.request setTag:2];
        self.request.tag = (!isBlocked)?2:3;
    }
//	self.request.delegate = self;
//	self.request.tag = (!isBlocked)?2:3;		//unblock - 2, block = 3
	strUrl = nil;
}


#pragma mark
#pragma mark		UITableView DataSource Methos
#pragma mark

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [[self.sections allKeys] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	return 45;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
	NSString *strChar = [[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section];
	UIView *view = [[UIView alloc] init] ;
	[view setBackgroundColor:[UIColor clearColor]];
	
	if (![strChar isEqualToString:@"zoo"]) {
		
		UILabel *lblTitle = [[UILabel alloc] init];
		[lblTitle setBackgroundColor:[Validation getColorForAlphabet:strChar]];
		lblTitle.frame = CGRectMake(tableView.frame.size.width-50, 5, 40, 40);
		[lblTitle setTextColor:[UIColor whiteColor]];
		lblTitle.textAlignment = NSTextAlignmentCenter;
		[lblTitle setText:[strChar uppercaseString]];
		[Validation setCorners:lblTitle];
		[view addSubview:lblTitle];
		lblTitle = nil;
	}
	return view;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 90;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section]] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	//NSLog(@"%@",[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row]);
	
	NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row]];
	
	UserCell *cell = (UserCell *)[tableView dequeueReusableCellWithIdentifier:@"cellIdentifier"];
    cell.ProfileImg.image = nil;
    cell.ProfileImg.imageURL = nil;
	cell.isUserSelectionInView = YES;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;

	
	[cell setBoxValuesWithData:dic];
	
	if (self.selectedParentView_Index == 1) {
		//user selection
				
        if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_USER_BLOCKED]] boolValue]) {
            [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_User_Blocked]];
            cell.imgFriendshipStatus.hidden = FALSE;
            cell.btnUserBlocked.hidden = YES;
        }
        else{
            [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_selectedUserIndication]];
            [cell.imgFriendshipStatus setHidden:TRUE];

            if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
                [cell.imgFriendshipStatus setHidden:FALSE];
                cell.btnUserBlocked.hidden = YES;
            }
            else{
                [cell.imgFriendshipStatus setHidden:TRUE];
            }
        }
	}
	else if (self.selectedParentView_Index == 2 || self.selectedParentView_Index == 3){
        NSString *str = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IS_USER_BLOCKED]]];
        if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_USER_BLOCKED]] boolValue]) {
            [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_User_Blocked]];
            cell.imgFriendshipStatus.hidden = FALSE;
            cell.btnUserBlocked.hidden = YES;
        }
        else{
		
            if (str.length>0) {
                if ([str boolValue]) {
                    [cell.imgFriendshipStatus setImage:[UIImage imageNamed:Btn_User_Blocked]];
                    [cell.imgFriendshipStatus setHidden:NO];
                    cell.btnUserBlocked.hidden = YES;
                }
            }
        }
	}
	
		cell.btnUnfriend.hidden = YES;
    
    NSString *strFTypeTemp = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:@"FriendType"]]];
    if (strFTypeTemp.length==0) {
        cell.imgViewFriendType.hidden = YES;
    }
    else{
        cell.imgViewFriendType.hidden = NO;
        switch ([[dic valueForKey:@"FriendType"] intValue]) {
            case 0:
                cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_blabeey.png"];
                break;
            case 1:
                cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_fb.png"];
                break;
            case 2:
                cell.imgViewFriendType.image = [UIImage imageNamed:@"icn_friends_contacts.png"];
                break;
                
            default:
                break;
        }
    }
    
    
	dic = nil;
	
	if (indexPath.section == self.sections.count) {
		if (indexPath.row == [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] count]) {
			self.pageCounter++;
        //    [HUD show:YES];
			[self performSelectorInBackground:@selector(getMyFriendList) withObject:nil];
		}
	}
	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	UserCell *cell = (UserCell *)[tableView cellForRowAtIndexPath:indexPath];
	
	NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row]];

    
	if (self.selectedParentView_Index == 1) {
        if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_USER_BLOCKED]] boolValue]) {
            [AlertHandler alertTitle:MESSAGE message:@"You have blocked this user." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        }
        else{
            if (self.arrSelected==nil) {
                self.arrSelected = [[NSMutableArray alloc] init] ;
            }
            
            int index = -1;
            if (self.arrSelected.count >0) {
                index = (int)[self.arrSelected indexOfObject:dic];
                NSLog(@"%d",index);
            }
            
            if ([[dic valueForKey:IS_SELECTED] isEqualToString:@"1"]) {
                //so deselect it
                [dic setValue:@"0" forKey:IS_SELECTED];
                [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
                cell.imgFriendshipStatus.hidden = TRUE;
                if (index > -1 && index < self.arrDataAll.count) {
                    [self.arrSelected removeObjectAtIndex:index];
                }
                [[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                
            }
            else{
                [dic setValue:@"1" forKey:IS_SELECTED];
                [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
                cell.imgFriendshipStatus.hidden = FALSE;
                [dic setValue:[NSNumber numberWithInteger:indexPath.section] forKey:SelectedSection];
                [dic setValue:[NSNumber numberWithInteger:indexPath.row] forKey:SelectedRow];
                [self.arrSelected addObject:dic];
            }
            
            [self showSelectedUsersOnTop];
        }
    }
	else if (self.selectedParentView_Index == 2){
        if ([[dic valueForKey:IS_USER_BLOCKED] boolValue]) {
            [dic setValue:@"0" forKey:IS_USER_BLOCKED];
            
            [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
            
            [self performSelectorInBackground:@selector(BlockSelectedUser:) withObject:dic];
            
            [self.tblData reloadData];
        }
        else{
            indPathSel = indexPath;
            [AlertHandler alertTitle:MESSAGE message:[NSString stringWithFormat:@"Are you sure you want to block %@?",[dic valueForKey:NAME]] delegate:self tag:101 cancelButtonTitle:NO_BUTTON_TITLE OKButtonTitle:YES_BUTTON_TITLE otherButtonTitle:nil];
        }
	}
	else if (self.selectedParentView_Index == 3){
        [dic setValue:@"0" forKey:IS_USER_BLOCKED];
        
        [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indexPath.section]] replaceObjectAtIndex:indexPath.row withObject:dic];
        
        [self performSelectorInBackground:@selector(BlockSelectedUser:) withObject:dic];
        
        [self.tblData reloadData];
		
	}

//	NSLog(@"%@",self.sections);
}
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if (alertView.tag==101) {
        if (buttonIndex != alertView.cancelButtonIndex) {
            NSLog(@"user block");

            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indPathSel.section]] objectAtIndex:indPathSel.row]];
            
            if ([[dic valueForKey:IS_USER_BLOCKED] boolValue]) {
                [dic setValue:@"0" forKey:IS_USER_BLOCKED];
            }
            else{
                [dic setValue:@"1" forKey:IS_USER_BLOCKED];
            }
            [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indPathSel.section]] replaceObjectAtIndex:indPathSel.row withObject:dic];
            
            [self performSelectorInBackground:@selector(BlockSelectedUser:) withObject:dic];
            
            [self.tblData reloadData];
 
        }
        
    }
    else if (alertView.tag==102) {
        if (buttonIndex != alertView.cancelButtonIndex) {
            NSLog(@"all user block");
/*
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indPathSel.section]] objectAtIndex:indPathSel.row]];
            
            [dic setValue:@"0" forKey:IS_USER_BLOCKED];
            
            [[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:indPathSel.section]] replaceObjectAtIndex:indPathSel.row withObject:dic];
            
            [self performSelectorInBackground:@selector(BlockSelectedUser:) withObject:dic];
            
            [self.tblData reloadData];
*/
        }
    }
}
/*
-(void)showSelectedUsersOnTop{
	
	if (self.selectedParentView_Index == 1) {
		if (self.arrSelected.count>0) {
			
			
			if (self.scrollContainer == nil) {
				self.scrollContainer = [[UIScrollView alloc] initWithFrame:CGRectMake(0, LabelHeight, 320, ScrollHeight)];
				[self.view addSubview:self.scrollContainer];
				[self.scrollContainer setShowsHorizontalScrollIndicator:FALSE];
				[self.scrollContainer setShowsVerticalScrollIndicator:FALSE];
			}
			
			float xStart = 10;
			
			for (int i=0; i<self.arrSelected.count; i++) {
				
				float X = 5;
				UIView *view = [[UIView alloc] init] ;
				UILabel *lblName = [[UILabel alloc] init];
				UIButton *btnRemove = [UIButton buttonWithType:UIButtonTypeCustom];
				
				lblName.font = [UIFont fontWithName:Font_Montserrat_Regular size:14];
				lblName.textColor = [UIColor whiteColor];
				
				NSDictionary *dic = [self.arrSelected objectAtIndex:i];
				NSString *strName = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:NAME]]];
				if (strName.length == 0) {
					strName = [NSString stringWithFormat:@"%@",[dic valueForKey:USER_NAME]];
				}
				
				CGSize size = CGSizeMake(1000, 46);
				CGRect text = [strName boundingRectWithSize:size
													options:NSStringDrawingUsesLineFragmentOrigin
												 attributes:@{NSFontAttributeName:lblName.font}
													context:nil];
				
				size = text.size;
				view.frame = CGRectMake(xStart, 0, size.width+30, ScrollHeight);
				view.backgroundColor = [Validation getColorForAlphabet:strName];
				
				lblName.text = strName;
				lblName.frame = CGRectMake(X, 0, size.width+4, ScrollHeight);
				
				btnRemove.frame = CGRectMake(X, 0, view.frame.size.width-(X*2), ScrollHeight);
				[btnRemove setTitle:@"x" forState:UIControlStateNormal];
				[btnRemove setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
				btnRemove.tag = i;
				[btnRemove addTarget:self action:@selector(removeSelectedUserFromList:) forControlEvents:UIControlEventTouchUpInside];
				[view addSubview:lblName];
				[view addSubview:btnRemove];
				[self.scrollContainer addSubview:view];
				
				view.tag = i;
				lblName = nil;
				btnRemove = nil;
				
				if (i==self.arrSelected.count-1) {
					
					[UIView beginAnimations:@"ScrollToEnd" context:nil];
                    //[UIView setAnimationBeginsFromCurrentState:YES];
					[UIView setAnimationDuration:0.5];
					self.scrollContainer.contentOffset = CGPointMake(xStart, self.scrollContainer.contentOffset.y);
					[UIView commitAnimations];
				}
				
				xStart += (view.frame.size.width+5);
			}
			
			self.scrollContainer.contentSize = CGSizeMake(xStart, ScrollHeight);
			//self.btnSave.hidden = FALSE;
			[self.delegate showButton];
			
			[Validation removeAdviewFromSuperView];
			//self.tblData.frame = CGRectMake(0, LabelHeight+ScrollHeight+5, 320, self.view.frame.size.height-(64+ScrollHeight+LabelHeight));
            self.tblData.frame = CGRectMake(0, LabelHeight+ScrollHeight+5, 320, self.view.frame.size.height-(64));
		}
		else{
			[UIView beginAnimations:@"moveDown" context:nil];
            //[UIView setAnimationBeginsFromCurrentState:YES];
			[UIView setAnimationDuration:0.5];
			self.tblData.frame = CGRectMake(0, LabelHeight, 320, self.view.frame.size.height-LabelHeight);
			[self.delegate hideButton];
			[UIView commitAnimations];
			
			[Validation removeAdviewFromSuperView];
			[self.view addSubview:[Validation sharedBannerView]];
		}

	}
	else if (self.selectedParentView_Index == 2){
		
	}
}
*/
-(void)showSelectedUsersOnTop{
    
    if (self.selectedParentView_Index == 1) {
        if (self.arrSelected.count>0) {
            
            if (self.scrollContainer == nil) {
                self.scrollContainer = [[UIScrollView alloc] initWithFrame:CGRectMake(0, LabelHeight, 320, ScrollHeight)];
                [self.view addSubview:self.scrollContainer];
                [self.scrollContainer setShowsHorizontalScrollIndicator:FALSE];
                [self.scrollContainer setShowsVerticalScrollIndicator:FALSE];
            }
            
            float xStart = 10;
            
            for (int i=0; i<self.arrSelected.count; i++) {
                
                float X = 5;
                UIView *view = [[UIView alloc] init] ;
                UILabel *lblName = [[UILabel alloc] init];
                UIButton *btnRemove = [UIButton buttonWithType:UIButtonTypeCustom];
                
                lblName.font = [UIFont fontWithName:Font_Montserrat_Regular size:14];
                lblName.textColor = [UIColor whiteColor];
                
                NSDictionary *dic = [self.arrSelected objectAtIndex:i];
                NSString *strName = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:NAME]]];
                if (strName.length == 0) {
                    strName = [NSString stringWithFormat:@"%@",[dic valueForKey:USER_NAME]];
                }
                
                CGSize size = CGSizeMake(1000, 46);
                CGRect text = [strName boundingRectWithSize:size
                                                    options:NSStringDrawingUsesLineFragmentOrigin
                                                 attributes:@{NSFontAttributeName:lblName.font}
                                                    context:nil];
                
                size = text.size;
                view.frame = CGRectMake(xStart, 0, size.width+30, ScrollHeight);
                view.backgroundColor = [Validation getColorForAlphabet:strName];
                
                lblName.text = strName;
                lblName.frame = CGRectMake(X, 0, size.width+4, ScrollHeight);
                
                btnRemove.frame = CGRectMake(X, 0, view.frame.size.width-(X*2), ScrollHeight);
                [btnRemove setTitle:@"x" forState:UIControlStateNormal];
                [btnRemove setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
                btnRemove.tag = i;
                [btnRemove addTarget:self action:@selector(removeSelectedUserFromList:) forControlEvents:UIControlEventTouchUpInside];
                [view addSubview:lblName];
                [view addSubview:btnRemove];
                [self.scrollContainer addSubview:view];
                
                view.tag = i;
                lblName = nil;
                btnRemove = nil;
                
                xStart += (view.frame.size.width+5);
            }
            
            self.scrollContainer.contentSize = CGSizeMake(xStart, ScrollHeight);
            [UIView beginAnimations:@"ScrollToEnd" context:nil];
            [UIView setAnimationDuration:0.5];
            self.scrollContainer.contentOffset = CGPointMake((xStart>320)?(xStart-320):0, self.scrollContainer.contentOffset.y);
            [UIView commitAnimations];
            
            
            self.scrollContainer.contentSize = CGSizeMake(xStart, ScrollHeight);
            [self.delegate showButton];
            
            [Validation removeAdviewFromSuperView];
            self.tblData.frame = CGRectMake(0, LabelHeight+ScrollHeight+5, 320, self.view.frame.size.height-(64));
        }
        else{
            [UIView beginAnimations:@"moveDown" context:nil];
            [UIView setAnimationDuration:0.5];
            self.tblData.frame = CGRectMake(0, LabelHeight, 320, self.view.frame.size.height-LabelHeight);
            [self.delegate hideButton];
            [UIView commitAnimations];
            
            [Validation removeAdviewFromSuperView];
            [self.view addSubview:[Validation sharedBannerView]];
        }
        
    }
    else if (self.selectedParentView_Index == 2){
        
    }
}
-(void)removeSelectedUserFromList:(id)sender{
	
	NSLog(@"arrB4Delete = %@",self.arrSelected);
	NSMutableDictionary *dic = [self.arrSelected objectAtIndex:((UIButton *)sender).tag];
	
	[dic setValue:@"0" forKey:IS_SELECTED];
	[[self.sections valueForKey:[[[self.sections allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:[[dic valueForKey:SelectedSection] intValue]]] replaceObjectAtIndex:[[dic valueForKey:SelectedRow] intValue] withObject:dic];
	
	[self.arrSelected removeObjectAtIndex:((UIButton *)sender).tag];
	[self.tblData reloadData];
	
	NSLog(@"arrB4Delete = %@",self.arrSelected);
	[[self.scrollContainer subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
	[self showSelectedUsersOnTop];
}

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];;
	
	//NSLog(@"dictionary = %@",dicResponse);
    [self.lblNoUserFound setHidden:YES];
	[HUD hide:YES];
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
            [appDelegate callLogOutService];
        }
        else{
            
            if ([dicResponse objectForKey:RESPONSE] != nil) {
                
                if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                    
                    if (request.tag == 1) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSArray *arrAlreadySelectedFriends = nil;
                            if ([[appDelegate.dic_NotificationReleatedData valueForKey:Is_Create_Direct_Group] boolValue]) {

                                arrAlreadySelectedFriends = [NSArray arrayWithArray:(NSArray *)[appDelegate.dic_NotificationReleatedData valueForKey:Selected_Friends_For_Creating_Group]];
                              //  [self.delegate showButton];
                            }
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            if (self.arrSelected == nil) {
                                self.arrSelected = [[NSMutableArray alloc] init];
                            }
                            if (arr.count>0) {
                                for (int i=0; i<arr.count; i++) {
                                    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[arr objectAtIndex:i]];
                                   
                                    if (arrAlreadySelectedFriends != nil) {
                                        int userId = [[NSString stringWithFormat:@"%@",[dic valueForKey:USER_ID]] intValue];
                                        NSLog(@"id = %d,%lu,%d",userId,(unsigned long)[arrAlreadySelectedFriends indexOfObject:[NSNumber numberWithInt:userId]],(int)arr.count+(int)self.arrDataAll.count);
                                        int indexFriend = (int)[arrAlreadySelectedFriends indexOfObject:[NSNumber numberWithInt:userId]];
                                        if (indexFriend>-1 && indexFriend<(arr.count+self.arrDataAll.count)) {
                                            [dic setValue:@"1" forKey:IS_SELECTED];
                                            [self.arrSelected addObject:dic];
                                        }
                                        else{
                                            [dic setValue:@"0" forKey:IS_SELECTED];
                                        }

                                    }
                                    else{
                                        [dic setValue:@"0" forKey:IS_SELECTED];
                                    }
                                    [arr replaceObjectAtIndex:i withObject:dic];
                                    dic = nil;
                                }
                            }
                            if (arr.count > 0) {
                                [self.sections removeAllObjects];
                                if (self.arrDataAll.count>0) {
                                    
                                    [self.arrDataAll removeAllObjects];
                                }
                            }
                            
                            [self.arrDataAll addObjectsFromArray:arr];
                            
                            if (arr.count>0) {
                                [self SetSectionArrayToLoadDataForArr:self.arrDataAll];
                            }
                            arr = nil;
                        }
                        [HUD hide:YES];
                    }
                    else if (request.tag == 2){
                        //Unblocked
                        /*
                         {
                         Response =     (
                         {
                         BlockUserID = 32;
                         IsBlock = "<null>";
                         UserID = 63;
                         }
                         );
                         Status = 1;
                         UserStatus =     {
                         IsActive = 1;
                         IsDelete = 0;
                         Msg = success;
                         status = 1;
                         };
                         }
                         */
                        
                    }
                    else if (request.tag == 3){
                        //blocked
                        /*
                         {
                         Response =     (
                         {
                         BlockUserID = 32;
                         IsBlock = "<null>";
                         UserID = 63;
                         }
                         );
                         Status = 1;
                         UserStatus =     {
                         IsActive = 1;
                         IsDelete = 0;
                         Msg = success;
                         status = 1;
                         };
                         }
                         */
                    }
                    else if (request.tag == 4){
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            if (arr.count>0) {
                                [self.sections removeAllObjects];
                                if (self.arrDataBlocked.count>0) {
                                    [self.arrDataBlocked removeAllObjects];
                                }
                            }
                            
                            [self.arrDataBlocked addObjectsFromArray:arr];
                            
                            if (arr.count>0) {
                                [self SetSectionArrayToLoadDataForArr:self.arrDataBlocked];
                            }
                            else{
                                [self.lblNoUserFound setHidden:NO];
                                [self.tblData reloadData];
                            }
                            arr = nil;
                        }
                    }
                }
                else{
                    
                    [self.lblNoUserFound setHidden:NO];
                    [self.tblData reloadData];
                }
            }
            else{
                [self.lblNoUserFound setHidden:NO];
                [self.tblData reloadData];
            }
            self.request = nil;
            [HUD hide:YES];
        }
    }
    else{
        [HUD hide:YES];
    }
	
	dicResponse = nil;
}

- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
