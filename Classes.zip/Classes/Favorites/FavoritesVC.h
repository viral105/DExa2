//
//  FavoritesVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 30/09/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SocialShareVC.h"
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>
#import <MessageUI/MFMessageComposeViewController.h>
#import <FBSDKShareKit/FBSDKShareKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>

@interface FavoritesVC : UIViewController <UITableViewDataSource, UITableViewDelegate,SocialShareVCDelegate,MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate,UIActionSheetDelegate,FBSDKSharingDelegate>

//table
@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, strong) NSMutableSet					*selectedRows;
@property (nonatomic, readwrite) int						pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, strong) ASIHTTPRequest				*request;
@property (nonatomic, readwrite) int						selectedIndex;

@property (nonatomic, strong) UIActivityIndicatorView		*activityLoading;

@property (nonatomic, retain) IBOutlet UILabel				*lbl_NoDataAvailable;

@property (nonatomic, strong) UIRefreshControl				*refresh;
@property (nonatomic, readwrite) BOOL						isServiceWaitingForResponse;

@property (nonatomic, strong) IBOutlet UIButton             *btnDelete;
@property (nonatomic, strong) IBOutlet UIButton             *btnMenu;
@property (nonatomic, readwrite) BOOL						isViewDidLoadCalled;

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;


@property (nonatomic, strong) NSString                      *strLoggedInUserId;
@property (nonatomic, strong) NSString                      *strShareURL;
@property (nonatomic, strong) NSString                      *strShareImagePathURL;

@property (nonatomic, strong) SocialShareVC                 *objShareVC;
@property (nonatomic, readwrite) BOOL                       isShouldShowImage;
@end
