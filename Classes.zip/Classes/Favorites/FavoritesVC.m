//
//  FavoritesVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 30/09/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "FavoritesVC.h"
#import "NotificationCell.h"
#import "NotifOptionVC.h"
#import "AddFriendFromExistingFriendListVC.h"
#import "MBProgressHUD.h"

#define NO_RECEIVED_NOTIF	@"No notifications in the list"
#define NO_SENT_NOTIF		@"No notifications in the list"

#define PageSize			10
#define CellHeight          115

@interface FavoritesVC ()<MBProgressHUDDelegate> {
	MBProgressHUD *HUD;
}


@end

@implementation FavoritesVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	//[self setNeedsStatusBarAppearanceUpdate];
    // Do any additional setup after loading the view.
	self.arrData = [[NSMutableArray alloc] init] ;
	self.selectedRows = [[NSMutableSet alloc] init] ;
	
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];

    
	appDelegate.currentVc = self;
	//[self LoadViewSetting];
	self.pageCounter = 1;
	self.lbl_NoDataAvailable.hidden = TRUE;
	self.isDataNull = NO;
	[self LoadViewSetting];
	
	//pull to refresh
	self.refresh = [[UIRefreshControl alloc] init] ;
	
	self.refresh.attributedTitle = [[NSAttributedString alloc] initWithString:@""];
	self.refresh.tintColor = TWITTER_BLUE_COLOR;
	[self.refresh setAutoresizingMask:(UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleLeftMargin)];
	
	[[self.refresh.subviews objectAtIndex:0] setFrame:CGRectMake(-5, 10, 20, 30)];
	[self.refresh addTarget:self action:@selector(loadNewData) forControlEvents:UIControlEventValueChanged];
	[self.tblData addSubview:self.refresh];
    [self.tblData setEditing:NO];
    if (!self.isServiceWaitingForResponse) {
        //[Validation showLoadingIndicatorInView:self.tblData];
        [HUD show:YES];
        [self performSelector:@selector(get_FavoritesList) ];
    }
}

-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
	[Validation DisableScreenLockWhilePlaying:YES];
    appDelegate.currentVc = self;
    appDelegate.isForwarded = NO;
    self.isShouldShowImage = TRUE;
    
	[Validation removeAdviewFromSuperView];
	[self.view addSubview:[Validation sharedBannerView]];
	[Validation ResizeViewForAds];
	
    [self.btnMenu removeTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
	[self.btnMenu addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
    [Validation.apnsReplyPopUp.btnPlay removeTarget:self action:@selector(apnsReplyToUser:) forControlEvents:UIControlEventTouchUpInside];
    [Validation.apnsReplyPopUp.btnClose removeTarget:self action:@selector(closeReplyPopup:) forControlEvents:UIControlEventTouchUpInside];
    [Validation.apnsReplyPopUp.btnPlayPause removeTarget:self action:@selector(PlaySoundAtIndex:) forControlEvents:UIControlEventTouchUpInside];
    
	
}

-(void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
	[Validation DisableScreenLockWhilePlaying:NO];
//	if ([self.tblData isEditing]) {
//		[self.tblData setEditing:NO animated:YES];
//		[self hideDeleteBtn];
//	}
    
    [Validation.apnsReplyPopUp.btnPlay removeTarget:self action:@selector(apnsReplyToUser:) forControlEvents:UIControlEventTouchUpInside];
    [Validation.apnsReplyPopUp.btnClose removeTarget:self action:@selector(closeReplyPopup:) forControlEvents:UIControlEventTouchUpInside];
    [Validation.apnsReplyPopUp.btnPlayPause removeTarget:self action:@selector(PlaySoundAtIndex:) forControlEvents:UIControlEventTouchUpInside];
    
    
	if (appDelegate.player !=nil) {
		[appDelegate.player pause];
	}
		
	if (self.request!= nil) {
		[self.request clearDelegatesAndCancel];
	}
    [self removeAndReleaseSocialView];
    
	[HUD hide:YES];
	self.isServiceWaitingForResponse = NO;
    
    appDelegate.isShouldShowReplyPopUp = NO;
//    self.strLoggedInUserId = nil;
}

-(void)removeAndReleaseSocialView{
    [self RemoveSocialViewFromSuperView];
//    [self.socialShareView release];
//    self.socialShareView = nil;
}

-(void)REmoveShareViewAfterAnimationFinishes{
    [self.objShareVC.view removeFromSuperview];
    [self.objShareVC removeFromParentViewController];
    self.objShareVC = nil;
}
- (void)removeSocialShareContainerFromParentVC{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
    self.objShareVC.view.alpha = 0;
    [UIView commitAnimations];
    [self performSelector:@selector(REmoveShareViewAfterAnimationFinishes) withObject:nil afterDelay:0.5];
}

-(void)RemoveSocialViewFromSuperView{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
    self.objShareVC.view.alpha = 0;
    [UIView commitAnimations];
    [self performSelector:@selector(REmoveShareViewAfterAnimationFinishes) withObject:nil afterDelay:0.5];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark	Methods

-(void)LoadViewSetting{
	
	[self.tblData setBackgroundColor:UIColorFromRGB(0Xefefef)];
   // [self.btnDelete setBackgroundColor:UIColorFromRGB(0Xff5252)];
    
	//-----
	self.tblData.allowsMultipleSelectionDuringEditing = YES;
	[self.tblData setValue:[UIColor grayColor] forKeyPath:@"multiselectCheckmarkColor"];
	//-----
    
	self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
	[self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    [self.lbl_NoDataAvailable setTextColor:TWITTER_BLUE_COLOR];
    [self.lbl_NoDataAvailable setShadowColor:[UIColor clearColor]];
    
    self.strLoggedInUserId = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]];
}

-(IBAction)btnBackClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)loadNewData{
	if ([self.refresh isRefreshing] && self.arrData.count!=0) {
		self.pageCounter = 1;
		self.isDataNull = NO;
	//	[self.arrData removeAllObjects];
        
       // [Validation showLoadingIndicatorInView:self.view];
        [HUD show:YES];
        [self performSelector:@selector(get_FavoritesList)];
	}
    else{
        self.lbl_NoDataAvailable.hidden = NO;
        [self.refresh endRefreshing];
    }
}
-(void)get_FavoritesList{
    NSLog(@"get_FavoritesList getting call");
	if (self.isViewDidLoadCalled) {
		//[Validation showLoadingIndicator];
        [HUD show:YES];
		self.isViewDidLoadCalled = FALSE;
	}
	if (self.request !=nil) {
		self.request = nil;
	}
	self.lbl_NoDataAvailable.hidden = YES;
	
	self.isServiceWaitingForResponse = YES;
	
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",self.pageCounter],KeyValue,@"PageNo",KeyName, nil],@"2",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",PageSize],KeyValue,@"PageSize",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_LIKE_LIST withParameters:nil];
	
	
	
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:1];
    }
//	self.request.delegate = self;
//	self.request.tag = 1;
	strUrl = nil;
}
-(void)playSoundForURL:(id)sender{
    
    UIButton *btn = ((UIButton *)sender);
    
    dispatch_async(dispatch_get_main_queue(),^{
        
//        [self updateTableViewAtIndex:sender];
        [self play:(int)btn.tag];
    });
}

-(void)updateTableViewAtIndex:(id)sender {
    
    UIButton *btn = ((UIButton *)sender);
    int index = (int)btn.tag;
	[btn setImage:[UIImage imageNamed:BtnNotifRead] forState:UIControlStateNormal];
	NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    NotificationCell *cell = (NotificationCell *)[self.tblData cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
    cell.cellBg.image = [UIImage imageNamed:LilstBox_Bg_Notif];
    cell.img_user_unread_notif.hidden = YES;
    
    if (![[NSString stringWithFormat:@"%@",[dic valueForKey:IS_NOTIF_READ]] boolValue]) {
        [self performSelectorInBackground:@selector(setNotifAsReadForNotifId:) withObject:[[self.arrData objectAtIndex:index] valueForKey:NOTIF_ID]];
    }
    
    [dic setValue:@"1" forKey:IS_NOTIF_READ];
    [self.arrData replaceObjectAtIndex:index withObject:dic];
    
    dic = nil;

}
-(void)play:(int)index{
    
	self.selectedIndex = index;
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:index]];
    
    self.isShouldShowImage = TRUE;
    
    if ([[dic valueForKey:IsPrivate] boolValue]) {
        if (![[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]] isEqualToString:self.strLoggedInUserId]) {
            if ([[NSString stringWithFormat:@"%@",[dic valueForKey:RequestedKeepStatus]] intValue] == 1) {
                
                NSString *strRequestSendStatus = [DataValidation checkNullString:[NSString stringWithFormat:@"%@",[dic valueForKey:IsRequestSent]]];
                strRequestSendStatus = (strRequestSendStatus.length >0)?strRequestSendStatus:@"false";
                if ([strRequestSendStatus boolValue]) {
                    self.isShouldShowImage = FALSE;
                }
            }
        }
    }
    if (self.isShouldShowImage) {
        
        [Validation showAPNS_ReplyPopUp:dic forId:1];
        
        [Validation.apnsReplyPopUp.btnPlay removeTarget:self action:@selector(apnsReplyToUser:) forControlEvents:UIControlEventTouchUpInside];
        [Validation.apnsReplyPopUp.btnClose removeTarget:self action:@selector(closeReplyPopup:) forControlEvents:UIControlEventTouchUpInside];
        [Validation.apnsReplyPopUp.btnPlayPause removeTarget:self action:@selector(PlaySoundAtIndex:) forControlEvents:UIControlEventTouchUpInside];
        
        
        [Validation.apnsReplyPopUp.btnPlay setTitle:@"Reply" forState:UIControlStateNormal];
        [Validation.apnsReplyPopUp.btnClose addTarget:self action:@selector(closeReplyPopup:) forControlEvents:UIControlEventTouchUpInside];
        [Validation.apnsReplyPopUp.btnPlay addTarget:self action:@selector(apnsReplyToUser:) forControlEvents:UIControlEventTouchUpInside];
        [Validation.apnsReplyPopUp.btnPlayPause addTarget:self action:@selector(PlaySoundAtIndex:) forControlEvents:UIControlEventTouchUpInside];
        
        Validation.apnsReplyPopUp.btnClose.tag = index;
        Validation.apnsReplyPopUp.btnPlay.tag = index;
        Validation.apnsReplyPopUp.btnPlayPause.tag = index;
        NSString *strURL = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_AUDIO_PATH]];
        //NSError *error = nil;
        appDelegate.dic_SelectedAPNSToPlay = dic;
        if ([DataValidation checkNullString:[dic valueForKey:VideoPath]].length==0) {
            appDelegate.isPlayingFromPopUp = YES;
            [appDelegate playSoundForURL:[NSURL URLWithString:strURL]];
        }
        
    }
    else{
        //keep request already sent, so couldnot show this blab till opponent user responds to request
        [Validation showToastMessage:@"Please wait till user responds to your keep request" displayDuration:ERROR_MSG_DURATION];
    }
/*
    [Validation showAPNS_ReplyPopUp:dic forId:1];
    
    [Validation.apnsReplyPopUp.btnPlay removeTarget:self action:@selector(apnsReplyToUser:) forControlEvents:UIControlEventTouchUpInside];
    [Validation.apnsReplyPopUp.btnClose removeTarget:self action:@selector(closeReplyPopup:) forControlEvents:UIControlEventTouchUpInside];
    [Validation.apnsReplyPopUp.btnPlayPause removeTarget:self action:@selector(PlaySoundAtIndex:) forControlEvents:UIControlEventTouchUpInside];
    
    
    [Validation.apnsReplyPopUp.btnPlay setTitle:@"Reply" forState:UIControlStateNormal];
    [Validation.apnsReplyPopUp.btnClose addTarget:self action:@selector(closeReplyPopup:) forControlEvents:UIControlEventTouchUpInside];
    [Validation.apnsReplyPopUp.btnPlay addTarget:self action:@selector(apnsReplyToUser:) forControlEvents:UIControlEventTouchUpInside];
    [Validation.apnsReplyPopUp.btnPlayPause addTarget:self action:@selector(PlaySoundAtIndex:) forControlEvents:UIControlEventTouchUpInside];
    
    Validation.apnsReplyPopUp.btnClose.tag = index;
    Validation.apnsReplyPopUp.btnPlay.tag = index;
    Validation.apnsReplyPopUp.btnPlayPause.tag = index;
    NSString *strURL = [NSString stringWithFormat:@"%@",[dic valueForKey:NOTIF_AUDIO_PATH]];
    //NSError *error = nil;
    
    appDelegate.isPlayingFromPopUp = YES;
    [appDelegate playSoundForURL:[NSURL URLWithString:strURL]];
*/
}
-(void)closeReplyPopup:(id)sender{
    [appDelegate closeReplyPopup];
    [Validation hideAPNS_ReplyPopup];
}

-(void)apnsReplyToUser:(id)sender{
    //	self.selectedIndex = (int)((UIButton *)sender).tag;
    //	[Validation CancelOnGoingRequests:self.request];
    
    [appDelegate closeReplyPopup];
    [self btnReplyClicked:sender];
}

-(void)setNotifAsReadForNotifId:(NSString *)notifId{
	if (self.request !=nil) {
		self.request = nil;
	}
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",notifId],KeyValue,@"MsgIDs",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:NOTIF_READ withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:3];
    }
//	self.request.delegate = self;
//	self.request.tag = 3;
	strUrl = nil;
    
}

/*
-(void)btnDeleteClicked:(id)sender{
   	
	if (self.selectedRows.count>0) {
		[self showDeleteBtn];
	}
	else{
		[self hideDeleteBtn];
	}
	
//	if ([self.tblData isEditing]) {
//		[self.selectedRows removeAllObjects];
//		[self.tblData setEditing:NO animated:YES];
//		[self hideDeleteBtn];
//	}
//	else{
//		
//		[self.tblData setEditing:YES animated:YES];
//	}
}
*/

/*
-(void)btnForwardClicked:(id)sender{
    UIButton *btn = (UIButton *)sender;
    
    if (![[[self.arrData objectAtIndex:btn.tag] valueForKey:IS_PRIVATE] boolValue]) {
        self.selectedIndex = (int)btn.tag;
        [Validation CancelOnGoingRequests:self.request];
        appDelegate.isForwarded = YES;
        [self performSegueWithIdentifier:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC sender:nil];
    }
    else{
        [Validation showToastMessage:@"You cannot forward a private Blabeey!!" displayDuration:ERROR_MSG_DURATION];
    }
}
*/
-(void)btnForwardClicked:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    BOOL CanForward = TRUE;
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_PAID]] boolValue]) {
        //it is paid audio category
        if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_PURCHASED]] boolValue]) {
            //logged in user has purchased it so he can forward it
        }
        else{
            //logged in user has not purchased this paid audio category.. so he can not forward it
            CanForward = FALSE;
        }
    }
    else{
        //this audio file is free, so logged in user can forward it
    }
    
    if (CanForward) {
        
        //now check if this blab is private or not
        
        if (![[dic valueForKey:IS_PRIVATE] boolValue]) {
            //it is public blab
            self.selectedIndex = (int)btn.tag;
            appDelegate.isForwarded = YES;
            [self performSegueWithIdentifier:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC sender:nil];
        }
        else{
            //it is private blab, now check if it is loggen-in user's blab or other user's blab
            if ([self.strLoggedInUserId isEqualToString:[NSString stringWithFormat:@"%@",[dic valueForKey:SENDER_ID]]]) {
                //it is private but it is my own blab so can forward it
                self.selectedIndex = (int)btn.tag;
                appDelegate.isForwarded = YES;
                [self performSegueWithIdentifier:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC sender:nil];
            }
            else{
                //i cannot share other user's private blab
                [Validation showToastMessage:@"You cannot forward a private Blab!!" displayDuration:ERROR_MSG_DURATION];
            }
        }
    }
    else{
        [Validation showToastMessage:@"To forward this blab you will have to buy this Audio category." displayDuration:ERROR_MSG_DURATION];
    }
    
}
-(void)callShareSelectedCellServiceAtIndex:(NSDictionary *)dic{
    //TypeID = 0 for blab, 1 for hashBlab    
    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dic valueForKey:USER_CONVERSATION_ID]],KeyValue,USER_CONVERSATION_ID,KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dic valueForKey:MESSAGE_CHAT_ID]],KeyValue,@"MsgIDs",KeyName, nil],@"3",
                          [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"TypeID",KeyName, nil],@"4",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:SHARE_SELECTED_CHAT withParameters:nil];
	ASIFormDataRequest *request = [WebServiceContainer CallWebserviceWithPost:dic1 forURL:strUrl isAddHeader:TRUE];
    if (request == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:5];
    }
//	request.delegate = self;
//	request.tag = 5;
	strUrl = nil;
}
/*
- (void)btnShareClicked:(id)sender {
    UIButton *btn = ((UIButton *)sender);
    
    NSLog(@"%d",(int)btn.tag);

    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    if (![[dic valueForKey:IS_PRIVATE] boolValue]) {
        
        [self callShareSelectedCellServiceAtIndex:dic];
        
        self.selectedIndex = (int)btn.tag;
    }
    else{
        [Validation showToastMessage:@"You cannot share a private Blabeey!!" displayDuration:ERROR_MSG_DURATION];
    }
}
*/
- (void)btnShareClicked:(id)sender {
    UIButton *btn = ((UIButton *)sender);
    
    NSLog(@"%d",(int)btn.tag);
    
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:btn.tag]];
    
    BOOL CanForward = TRUE;
    if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_PAID]] boolValue]) {
        //it is paid audio category
        if ([[NSString stringWithFormat:@"%@",[dic valueForKey:IS_PURCHASED]] boolValue]) {
            //logged in user has purchased it so he can forward it
        }
        else{
            //logged in user has not purchased this paid audio category.. so he can not forward it
            CanForward = FALSE;
        }
    }
    else{
        //this audio file is free, so logged in user can forward it
    }
    
    if (CanForward) {
        
        //now check if this blab is private or not
        
        if (![[dic valueForKey:IS_PRIVATE] boolValue]) {
            
            [self callShareSelectedCellServiceAtIndex:dic];
            
            self.selectedIndex = (int)btn.tag;
        }
        else{
            [Validation showToastMessage:CANNOT_SHARE_PRIVATE_BLAB displayDuration:ERROR_MSG_DURATION];
        }
    }
    else{
        [Validation showToastMessage:@"To share this blab you will have to buy this Audio category." displayDuration:ERROR_MSG_DURATION];
        
    }
    
}
-(void)shareWithShareURL:(NSDictionary *)shareURL{
    self.strShareURL = [shareURL valueForKey:@"Url"];
    self.strShareImagePathURL = [shareURL valueForKey:@"ImagePath"];
    
    if (self.objShareVC == nil) {
 //       UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        self.objShareVC = [MainStoryboard instantiateViewControllerWithIdentifier:SOCIAL_SHARE_VC];
//        self.objShareVC.viewContainer.tag = btn.tag;
        self.objShareVC.delegate = self;
        self.objShareVC.view.frame = self.view.frame;
        [self.view addSubview:self.objShareVC.view];
        [self.objShareVC didMoveToParentViewController:self];
        [self addChildViewController:self.objShareVC];
    }
    
    //fb
    UIButton *btnFb = (UIButton *)[self.objShareVC.viewContainer viewWithTag:1];      //fb
    [btnFb removeTarget:self action:@selector(shareWithFBClicked:) forControlEvents:UIControlEventTouchUpInside];
    [btnFb addTarget:self action:@selector(shareWithFBClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    //twitter
    UIButton *btnTwitter = (UIButton *)[self.objShareVC.viewContainer viewWithTag:2];      //twitter
    [btnTwitter removeTarget:self action:@selector(shareWithTwitterClicked:) forControlEvents:UIControlEventTouchUpInside];
    [btnTwitter addTarget:self action:@selector(shareWithTwitterClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    //mail
    UIButton *btnMail = (UIButton *)[self.objShareVC.viewContainer viewWithTag:3];      //twitter
    [btnMail removeTarget:self action:@selector(ShareThroughMail:) forControlEvents:UIControlEventTouchUpInside];
    [btnMail addTarget:self action:@selector(ShareThroughMail:) forControlEvents:UIControlEventTouchUpInside];
    
    
    //sms
    UIButton *btnMessage = (UIButton *)[self.objShareVC.viewContainer viewWithTag:4];      //twitter
    [btnMessage removeTarget:self action:@selector(ShareThroughSMS:) forControlEvents:UIControlEventTouchUpInside];
    [btnMessage addTarget:self action:@selector(ShareThroughSMS:) forControlEvents:UIControlEventTouchUpInside];
    
//    btnFb.tag = btn.tag;
//    btnTwitter.tag = btn.tag;
//    btnMail.tag = btn.tag;
//    btnMessage.tag = btn.tag;

}

-(void)shareWithFBClicked:(id)sender{
    [self RemoveSocialViewFromSuperView];
    NSDictionary *dic =[self.arrData objectAtIndex:self.selectedIndex];
    if (([DataValidation checkNullString:[dic valueForKey:VideoPath]].length!=0 || [DataValidation checkNullString:[dic valueForKey:ImagePath]].length!=0) && ![[NSString stringWithFormat:@"%@",[dic valueForKey:@"TypeID"]] isEqualToString:@"1"]) {
        [HUD show:YES];
        [self performSelectorInBackground:@selector(shareVideoOrImageTOFB) withObject:nil];
    }
    else{
        if (!FBSession.activeSession.isOpen) {
            // if the session is closed, then we open it here, and establish a handler for state changes
            [FBSession openActiveSessionWithReadPermissions:@[@"public_profile", @"email", @"user_friends"]
                                               allowLoginUI:YES
                                          completionHandler:^(FBSession *session,
                                                              FBSessionState state,
                                                              NSError *error) {
                                              if (error) {
                                                  [HUD hide:YES];
                                                  UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                                                      message:@"Could not get your Facebook data.\nPlease check you internet connectivity or try later."
                                                                                                     delegate:nil
                                                                                            cancelButtonTitle:@"OK"
                                                                                            otherButtonTitles:nil];                                              [alertView show];
                                              } else if (session.isOpen) {
                                                  // [self pickFriendsButtonClick:sender];
                                                  NSLog(@"facebook login");
                                                  [self PostOnFB:self.selectedIndex];
                                              }
                                          }];
            return;
        }
        else if (FBSession.activeSession.isOpen) {
            // [self pickFriendsButtonClick:sender];
            NSLog(@"facebook activeSession.isOpen");
            [self PostOnFB:self.selectedIndex];
        }
    }
}

-(void)PostOnFB:(int)Index{
    //NSString *strURL = [[self.arrData objectAtIndex:Index] valueForKey:NOTIF_AUDIO_PATH];
    NSString *strURL = self.strShareURL;
    
    FBLinkShareParams *params = [[FBLinkShareParams alloc] init] ;
    //    http://wwhhaazzuupp.com/content/content/6kkTrbUma2SIRbp8VY34cA==
    NSLog(@"-->*() %d",Index);
    NSLog(@"%@",[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_ID]]);
    
    /*
     Replace("_", "+"));
     Replace("-","/");
     */
    
    //    NSString *strEncryptText = [[Validation getEncryptedTextForString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_ID]] isGeneral:YES] stringByReplacingOccurrencesOfString:@"+" withString:@"_"];
    //    strEncryptText = [strEncryptText stringByReplacingOccurrencesOfString:@"/" withString:@"-"];
 //  NSString *strEncryptText = [Validation getEncryptedShareUrlId:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_ID]]];
    
    params.link = [NSURL URLWithString:self.strShareURL];;  //[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SHARE_URL,strEncryptText]];
    params.name = @"Blabeey";
    params.caption = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_Category]];
    params.picture =  [NSURL URLWithString:self.strShareImagePathURL];
    
    // If the Facebook app is installed and we can present the share dialog
    if ([FBDialogs canPresentShareDialogWithParams:params]) {
        // Present the share dialog
        [FBDialogs presentShareDialogWithParams:params clientState:nil handler:^(FBAppCall *call, NSDictionary *results, NSError *error) {
                                          if(error) {
                                              // An error occurred, we need to handle the error
                                              // See: https://developers.facebook.com/docs/ios/errors
                                              NSLog(@"Error publishing story: %@", error.description);
                                          } else {
                                              // Success
                                              NSLog(@"result %@", results);
                                              if (![[results valueForKey:@"completionGesture"] isEqualToString:@"cancel"]) {
                                                  [Validation showToastMessage:@"Successfully posted" displayDuration:SUCCESS_MSG_DURATION];
                                              }
                                              
                                          }
                                      }];
    } else {
        // Present the feed dialog
        NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                       @"Blabeey", @"name",
                                       [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_Category]], @"caption",
                                       //                                       @"Allow your users to share stories on Facebook from your app using the iOS SDK.", @"description",
                                       strURL, @"link",
                                       //                                       @"http://i.imgur.com/g3Qc1HN.png", @"picture",
                                       nil];
        
        // Show the feed dialog
        [FBWebDialogs presentFeedDialogModallyWithSession:nil
                                               parameters:params
                                                  handler:^(FBWebDialogResult result, NSURL *resultURL, NSError *error) {
                                                      if (error) {
                                                          // An error occurred, we need to handle the error
                                                          // See: https://developers.facebook.com/docs/ios/errors
                                                          NSLog(@"Error publishing story: %@", error.description);
                                                      } else {
                                                          if (result == FBWebDialogResultDialogNotCompleted) {
                                                              // User cancelled.
                                                              NSLog(@"User cancelled.");
                                                          } else {
                                                              // Handle the publish feed callback
                                                              NSDictionary *urlParams = [Validation parseURLParams:[resultURL query]];
                                                              
                                                              if (![urlParams valueForKey:@"post_id"]) {
                                                                  // User cancelled.
                                                                  NSLog(@"User cancelled.");
                                                                  
                                                              } else {
                                                                  // User clicked the Share button
                                                                  NSString *result = [NSString stringWithFormat: @"Posted story, id: %@", [urlParams valueForKey:@"post_id"]];
                                                                  NSLog(@"result %@", result);
                                                              }
                                                          }
                                                      }
                                                  }];
    }
    
}
-(void)shareVideoOrImageTOFB{
    /*
     __block ACAccount * facebookAccount;
     ACAccountStore* accountStore = [[ACAccountStore alloc] init];
     NSDictionary *options = @{
     ACFacebookAppIdKey: @"691572667578808",
     ACFacebookPermissionsKey: @[@"publish_actions",@"video_upload" ],
     @"ACFacebookAudienceKey": ACFacebookAudienceFriends
     };
     ACAccountType *facebookAccountType = [accountStore
     accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierFacebook];
     [accountStore requestAccessToAccountsWithType:facebookAccountType options:options completion:^(BOOL granted, NSError *error) {
     
     if (granted) {
     NSArray *accounts = [accountStore
     accountsWithAccountType:facebookAccountType];
     facebookAccount = [accounts lastObject];
     
     
     
     NSLog(@"access to facebook account ok %@", facebookAccount.username);
     
     NSURL *url = [NSURL URLWithString:@"https://graph.facebook.com/me/videos"];
     
     NSURL *videoPathURL = [NSURL URLWithString:str];
     NSData *videoData = [NSData dataWithContentsOfURL:videoPathURL];
     
     NSString *status = @"One step closer.";
     NSDictionary *params = @{@"title":status, @"description":status};
     
     SLRequest *request = [SLRequest requestForServiceType:SLServiceTypeFacebook
     requestMethod:SLRequestMethodPOST
     URL:url
     parameters:params];
     
     [request addMultipartData:videoData
     withName:@"source"
     type:@"video/mp4"
     filename:[videoPathURL absoluteString]];
     
     request.account = facebookAccount;
     [request performRequestWithHandler:^(NSData *data,NSHTTPURLResponse *response,NSError * error){
     NSLog(@"response = %@", response);
     NSLog(@"error = %@", [error localizedDescription]);
     
     }];
     
     
     } else {
     NSLog(@"access to facebook is not granted %@",[error description]);
     // extra handling here if necesary
     
     }
     
     }];
     */
    
    /*
     ACAccountStore *accountStore = [[ACAccountStore alloc] init];
     
     ACAccountType *facebookAccountType = [accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierFacebook];
     
     // Specify App ID and permissions
     NSDictionary *options = @{ACFacebookAppIdKey: @"691572667578808",
     ACFacebookPermissionsKey: @[@"publish_stream", @"video_upload"],
     ACFacebookAudienceKey: ACFacebookAudienceFriends}; // basic read permissions
     
     [accountStore requestAccessToAccountsWithType:facebookAccountType options:options completion:^(BOOL granted, NSError *e) {
     if (granted) {
     NSArray *accountsArray = [accountStore accountsWithAccountType:facebookAccountType];
     
     if ([accountsArray count] > 0) {
     ACAccount *facebookAccount = [accountsArray objectAtIndex:0];
     
     
     NSDictionary *parameters = @{@"description": @"JSR"};
     
     
     SLRequest *facebookRequest = [SLRequest requestForServiceType:SLServiceTypeFacebook
     requestMethod:SLRequestMethodPOST
     URL:[NSURL URLWithString:@"https://graph.facebook.com/me/videos"]
     parameters:parameters];
     
     NSURL *videoPathURL = [NSURL URLWithString:str];
     NSData *videoData = [NSData dataWithContentsOfURL:videoPathURL];
     [facebookRequest addMultipartData: videoData
     withName:@"source"
     type:@"video/mp4"
     filename:@"video.mov"];
     
     facebookRequest.account = facebookAccount;
     
     
     [facebookRequest performRequestWithHandler:^(NSData* responseData, NSHTTPURLResponse* urlResponse, NSError* error) {
     if (error == nil) {
     NSLog(@"responedata:%@", [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding]);
     }else{
     NSLog(@"%@",error.description);
     }
     }];
     }
     } else {
     NSLog(@"Access Denied");
     NSLog(@"[%@]",[e localizedDescription]);
     }
     }];
     */
    NSDictionary *dicSelForSingleVideoImageShare = [self.arrData objectAtIndex:self.selectedIndex];
    if ([DataValidation checkNullString:[dicSelForSingleVideoImageShare valueForKey:VideoPath]].length!=0) {
        NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[dicSelForSingleVideoImageShare valueForKey:VideoPath]]];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        
        if (![fm fileExistsAtPath:INSTAGRAMVIDEO_FOLDER]){
            
            [fm createDirectoryAtPath:INSTAGRAMVIDEO_FOLDER
          withIntermediateDirectories:YES
                           attributes:nil
                                error:NULL];
        }
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:INSTAGRAMVIDEO_FOLDER]) {
            NSString *tempPath = [INSTAGRAMVIDEO_FOLDER stringByAppendingFormat:@"/test.mp4"];
            if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
                [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
            }
        }
        
        NSString *tempPath1 = [INSTAGRAMVIDEO_FOLDER stringByAppendingFormat:@"/test.mp4"];
        
        BOOL success = [imageData writeToFile:tempPath1 atomically:NO];
        NSLog(@"success=%d",success);
        
        
        NSString *tempPath = [INSTAGRAMVIDEO_FOLDER stringByAppendingFormat:@"/test.mp4"];
        NSURL *movieURL = [NSURL fileURLWithPath:tempPath];
        
        ALAssetsLibrary* library = [[ALAssetsLibrary alloc] init];
        [library writeVideoAtPathToSavedPhotosAlbum:movieURL
                                    completionBlock:^(NSURL *assetURL, NSError *error){
                                        /*notify of completion*/
                                        NSLog(@"assetURL=======%@",assetURL);
                                        
                                        FBSDKShareDialog *shareDialog = [[FBSDKShareDialog alloc]init];
                                        // NSURL *videoURL=videoURL;
                                        FBSDKShareVideo *video = [[FBSDKShareVideo alloc] init];
                                        video.videoURL = assetURL;
                                        FBSDKShareVideoContent *content = [[FBSDKShareVideoContent alloc] init];
                                        content.video = video;
                                        shareDialog.shareContent = content;
                                        [shareDialog setDelegate:self];//=self;
                                        [shareDialog setFromViewController:self];
                                        [shareDialog show];
                                        
                                        [HUD hide:YES];
                                        
                                    }];
    }
    else{
        UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[dicSelForSingleVideoImageShare valueForKey:ImagePath]]]];
        
        FBSDKSharePhoto *photo = [[FBSDKSharePhoto alloc] init];
        photo.image = image;
        photo.userGenerated = YES;
        FBSDKSharePhotoContent *content = [[FBSDKSharePhotoContent alloc] init];
        content.photos = @[photo];
        
        FBSDKShareDialog *shareDialog = [[FBSDKShareDialog alloc]init];
        // NSURL *videoURL=videoURL;
        
        shareDialog.shareContent = content;
        shareDialog.delegate=self;
        [shareDialog show];
    }
}
- (void)sharer:(id<FBSDKSharing>)sharer didCompleteWithResults:(NSDictionary *)results{
    NSLog(@"---------->>>>>>> didCompleteWithResults %@",results);
    [HUD hide:YES];
}

- (void)sharer:(id<FBSDKSharing>)sharer didFailWithError:(NSError *)error{
    NSLog(@"---------->>>>>>> Error = %@",error.description);
    [HUD hide:YES];
}
- (void)sharerDidCancel:(id<FBSDKSharing>)sharer{
    NSLog(@"---------->>>>>>> %@",sharer);
    [HUD hide:YES];
}
-(void)shareWithGooglePlusClicked:(id)sender{
    [self RemoveSocialViewFromSuperView];
}

-(void)shareWithPinterestClicked:(id)sender{
    [self RemoveSocialViewFromSuperView];
}

-(void)shareWithTwitterClicked:(id)sender{
    [self RemoveSocialViewFromSuperView];
    [self PostOnTwitter:self.selectedIndex];
}

-(void)PostOnTwitter:(int)Index{
    
    
    SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
    SLComposeViewControllerCompletionHandler myBlock = ^(SLComposeViewControllerResult result){
        if (result == SLComposeViewControllerResultCancelled) {
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Cancelled" message:@"You Cancelled posting the Tweet." delegate:nil cancelButtonTitle:OK_BUTTON_TITLE otherButtonTitles: nil] ;
            
            [alert show];
         //   [alert release];
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Success" message:@"The Tweet was posted successfully." delegate:nil cancelButtonTitle:OK_BUTTON_TITLE otherButtonTitles: nil] ;
            
            [alert show];
         //   [alert release];
        }
        
        [controller dismissViewControllerAnimated:YES completion:Nil];
    };
    
    controller.completionHandler =myBlock;
    
    //Adding the Text to the facebook post value from iOS
    //[controller setInitialText:[NSString stringWithFormat:@"My latest %@ : %@",MERGED_SONG_TEXT,clipTitle]];
    NSLog(@"NSString------> %@ \n %@",[NSString stringWithFormat:@"Check this Blabeey!! - %@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_Category]],[self.arrData objectAtIndex:Index]);
    [controller setInitialText:[NSString stringWithFormat:@"Check this Blabeey!! - %@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_Category]]];
    
    //Adding the URL to the facebook post value from iOS
    //    NSString *strEncryptText = [[Validation getEncryptedTextForString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_ID]] isGeneral:YES] stringByReplacingOccurrencesOfString:@"+" withString:@"_"] ;
    //    strEncryptText = [strEncryptText stringByReplacingOccurrencesOfString:@"/" withString:@"-"];
    
//    NSString *strEncryptText = self.strShareURL;    //[Validation getEncryptedShareUrlId:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_ID]]];
    
    
    [controller addURL:[NSURL URLWithString:self.strShareURL]];
    
    //Adding the Image to the facebook post value from iOS
    NSData *imageData=[NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Icon114x114" ofType:@"png"]];
    
    UIImage *image = [UIImage imageWithData:imageData];
    if (image != nil) {
        [controller addImage:image];
    }
    
    [self presentViewController:controller animated:YES completion:Nil];
}

-(void)ShareThroughSMS:(id)sender{
	
	[self RemoveSocialViewFromSuperView];
	
//    UIButton *btn = (UIButton *)sender;
    
	MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
	
	if([MFMessageComposeViewController canSendText])
	{
        [AlertHandler alertTitle:MESSAGE message:SMS_CHARGE_ALERT delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        
        //        NSString *strEncryptText = [[Validation getEncryptedTextForString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:btn.tag] valueForKey:NOTIF_ID]] isGeneral:YES] stringByReplacingOccurrencesOfString:@"+" withString:@"_"];
        //        strEncryptText = [strEncryptText stringByReplacingOccurrencesOfString:@"/" withString:@"-"];
//        NSString *strEncryptText = self.strShareURL;        //[Validation getEncryptedShareUrlId:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:btn.tag] valueForKey:NOTIF_ID]]];
//        
//		NSString *strUrl = [NSString stringWithFormat:@"%@%@",SHARE_URL,strEncryptText];
        
        NSString *strTitle = [NSString stringWithFormat:@"%@ send you %@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_NAME],[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:NOTIF_Category]];
        
        
		NSString *strShareText = [NSString stringWithFormat:@"%@ - %@",strTitle,self.strShareURL];
		
		controller.body = strShareText;
        
		controller.messageComposeDelegate = self;
        [self presentViewController:controller animated:YES completion:nil];
	}
	
//	[controller release];
}

-(void)ShareThroughMail:(id)sender{
	
	[self RemoveSocialViewFromSuperView];
//	UIButton *btn = (UIButton *)sender;
    
	MFMailComposeViewController *mailViewController = [[MFMailComposeViewController alloc] init] ;
	
	if (mailViewController != nil)
	{
		if ([MFMailComposeViewController canSendMail]) {
			
            //            NSString *strEncryptText = [[Validation getEncryptedTextForString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:btn.tag] valueForKey:NOTIF_ID]] isGeneral:YES] stringByReplacingOccurrencesOfString:@"+" withString:@"_"];
            //            strEncryptText = [strEncryptText stringByReplacingOccurrencesOfString:@"/" withString:@"-"];
   //         NSString *strEncryptText = self.strShareURL;    //[Validation getEncryptedShareUrlId:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:btn.tag] valueForKey:NOTIF_ID]]];
            
            
			NSString *strUrl = self.strShareURL;        //[NSString stringWithFormat:@"%@%@",SHARE_URL,strEncryptText];
            
            NSString *strTitle = [NSString stringWithFormat:@"%@ send you %@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_NAME],[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:NOTIF_Category]];
            
            
            //    NSString *strShareText = [NSString stringWithFormat:@"%@",strUrl];
            
			mailViewController.mailComposeDelegate = self;
			[mailViewController setSubject:@"Blabeey"];
			NSString *bodyText =@"<html>";
			bodyText = [bodyText stringByAppendingString:@"<head>"];
			bodyText = [bodyText stringByAppendingString:@"</head>"];
			bodyText = [bodyText stringByAppendingString:@"<body>"];
			bodyText = [bodyText stringByAppendingFormat:@"%@ <a href=\"%@\">%@",strTitle,strUrl,strUrl];
			bodyText = [bodyText stringByAppendingString:@"</a>"];
			
			[mailViewController setMessageBody:bodyText isHTML:YES];
            
            [self presentViewController:mailViewController animated:YES completion:nil];
		}
		else
		{
			[self launchMailAppOnDevice];
		}
	}
	else
	{
		[self launchMailAppOnDevice];
	}
    //	[mailViewController release];
}

#pragma mark
#pragma MFMessageComposeViewController
#pragma mark

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [self dismissViewControllerAnimated:YES completion:nil];
	
	if (result == MessageComposeResultCancelled){
		//[CustomAlert HeaderTitle:CANCELLED message:MESSAGE_CANCELLED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK otherButtonTitle:nil];
        [AlertHandler alertTitle:CANCELLED message:MESSAGE_CANCELLED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else if (result == MessageComposeResultSent){
		//[CustomAlert HeaderTitle:SUCCESS message:MESSAGE_SENT delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK otherButtonTitle:nil];
        [AlertHandler alertTitle:SUCCESS message:MESSAGE_SENT delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else{
        //		[CustomAlert HeaderTitle:FAILED message:MESSAGE_FAILED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK otherButtonTitle:nil];
        [AlertHandler alertTitle:FAILURE message:MESSAGE_FAILED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
}

#pragma mark
#pragma MFMailComposeViewController
#pragma mark

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error{
	
    [self dismissViewControllerAnimated:YES completion:nil];
	
	if (result == MFMailComposeResultCancelled){
		//[CustomAlert HeaderTitle:CANCELLED message:MAIL_SENDING_CANCELLED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK otherButtonTitle:nil];
        [AlertHandler alertTitle:CANCELLED message:MAIL_SENDING_CANCELLED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else if (result == MFMailComposeResultSent){
		//[CustomAlert HeaderTitle:SUCCESS message:MAIL_SEND delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK otherButtonTitle:nil];
        [AlertHandler alertTitle:SUCCESS message:MAIL_SEND delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else if (result == MFMailComposeResultFailed){
		//[CustomAlert HeaderTitle:FAILED message:MAIL_SENDING_FAILED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK otherButtonTitle:nil];
        [AlertHandler alertTitle:FAILURE message:MAIL_SENDING_FAILED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else if(result == MFMailComposeResultSaved){
		//[CustomAlert HeaderTitle:SUCCESS message:MAIL_SAVED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK otherButtonTitle:nil];
        [AlertHandler alertTitle:SUCCESS message:MAIL_SAVED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
}

-(void)launchMailAppOnDevice
{
    //    NSString *strEncryptText = [Validation getEncryptedTextForString:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:NOTIF_ID]] isGeneral:YES];
    //    strEncryptText = [strEncryptText stringByReplacingOccurrencesOfString:@"/" withString:@"-"];
 //   NSString *strEncryptText = self.strShareURL;    //[Validation getEncryptedShareUrlId:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:NOTIF_ID]]];
    
    
	NSString *strUrl = self.strShareURL;    //[NSString stringWithFormat:@"%@%@",SHARE_URL,strEncryptText];
    
    NSString *strTitle = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:NOTIF_Category]];
    
    
    NSString *strShareText = [NSString stringWithFormat:@"%@ - %@",strTitle,strUrl];
    
	NSString *bodyText =@"<html>";
	bodyText = [bodyText stringByAppendingString:@"<head>"];
	bodyText = [bodyText stringByAppendingString:@"</head>"];
	bodyText = [bodyText stringByAppendingString:@"<body>"];
	bodyText = [bodyText stringByAppendingFormat:@"<a href=\"%@\">%@",strUrl,strShareText];
	bodyText = [bodyText stringByAppendingString:@"</a>"];
	
	NSString *recipients = [NSString stringWithFormat:@"mailto:?cc=&subject=%@",@"Blabeey"];
	//	NSString *body = [NSString stringWithFormat:@"&body=%@\n%@",strTitle,clipURL];
	NSString *body = [NSString stringWithFormat:@"&body=%@",bodyText];
	
	NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
	email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}

-(void)btnResentClicked:(id)sender{
	self.selectedIndex = (int)((UIButton *)sender).tag;
	[Validation CancelOnGoingRequests:self.request];
    appDelegate.isForwarded = NO;
	//[self performSegueWithIdentifier:RECORD_OPTION_VC sender:nil];
    [self showYapOptions];
}

-(void)btnReplyClicked:(id)sender{
	self.selectedIndex = (int)((UIButton *)sender).tag;
	[Validation CancelOnGoingRequests:self.request];
    appDelegate.isForwarded = NO;
    
    NSString *strRecId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:SENDER_ID]];
    if ([strRecId isEqualToString:self.strLoggedInUserId]) {
        [Validation showToastMessage:@"You can not reply to yourself." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        [self showYapOptions];
    }
}

-(void)btnFavoriteClicked:(id)sender{
    [HUD show:YES];
    self.selectedIndex = (int)((UIButton *)sender).tag;
    [Validation CancelOnGoingRequests:self.request];
    appDelegate.isForwarded = NO;
    [self SetSelectedNotifToFavorites];
}

-(void)showYapOptions{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Select" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:Only_Yap,Yap_With_Image,Yap_With_Video, nil];
    [action showInView:self.view];
    action.delegate = self;
}

-(void)SetSelectedNotifToFavorites{
    if (self.request !=nil) {
		self.request = nil;
	}
    NSLog(@"unfav doing");
    NSMutableDictionary *dic1 = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.selectedIndex] ];
    BOOL isLike = [[NSString stringWithFormat:@"%@",[dic1 valueForKey:IS_LIKE]] boolValue];
    
    if (isLike) {
        NSLog(@"fav name--> dislikd %@",[dic1 valueForKey:@"Name"]);
        isLike = FALSE;
    }
    else{
        NSLog(@"fav name--> like %@",[dic1 valueForKey:@"Name"]);
        isLike = TRUE;
    }
/*
    dispatch_async(dispatch_get_main_queue(),^{
        
        [self changeLikeButtonImageInListForDic:dic1];
    });
*/
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:self.strLoggedInUserId,KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[dic1 valueForKey:NOTIF_ID]],KeyValue,@"MsgID",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:(isLike)?@"true":@"false",KeyValue,@"IsLike",KeyName, nil],@"3",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:SET_NOTIF_LIKE_UNLIKE withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
    if (self.request == nil) {
        [HUD hide:YES];
    }
    else{
        [self.request setDelegate:self];
        [self.request setTag:4];
    }
//	self.request.delegate = self;
//	self.request.tag = 4;
	strUrl = nil;
}

-(void)changeLikeButtonImageInListForDic:(NSMutableDictionary *)dic{
    [self.arrData removeObjectAtIndex:self.selectedIndex];
    [self.tblData reloadData];
    if (self.arrData.count == 0) {
        self.lbl_NoDataAvailable.hidden = NO;
    }
}


-(void)PlaySoundAtIndex:(id)sender{
    NSString *strURL = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:((UIButton *)sender).tag] valueForKey:NOTIF_AUDIO_PATH]];
    //NSError *error = nil;
    
    [appDelegate playSoundForURL:[NSURL URLWithString:strURL]];
}

#pragma mark  UITableViewDelegate

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self RemoveSocialViewFromSuperView];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return CellHeight;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	//return self.arrData.count;
	if (!self.isDataNull) {
		if (self.arrData.count>PageSize-1) {
			return self.arrData.count+1;
		}
		return self.arrData.count;
	}
	return self.arrData.count;
	
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
//	NSString *cellId = [NSString stringWithFormat:@"%d",(int)indexPath.row];
	
//	if (indexPath.row < self.arrData.count) {
//		cellId = [cellId stringByAppendingFormat:@"%@",[[self.arrData objectAtIndex:indexPath.row] valueForKey:@"ID"]];
//	}
	
	NotificationCell *cell = (NotificationCell *)[tableView dequeueReusableCellWithIdentifier:@"cellIdentifier"];
    
	[cell clearsContextBeforeDrawing];
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    NSLog(@"arr modulo %d",(int)self.arrData.count%PageSize);
    
	if (!self.isDataNull && (indexPath.row == (self.arrData.count+1) || indexPath.row == self.arrData.count) && ((int)(self.arrData.count%PageSize) == 0)){
        NSLog(@"service call from cell for row %d",self.pageCounter);
		if (!self.isDataNull) {
			cell.cellBg.hidden = YES;
			cell.btnNotificationDelete.hidden= YES;
			cell.btnNotificationDetail.hidden = YES;
			cell.btnNotificationForward.hidden = YES;
			cell.btnNotificationProfile.hidden = YES;
			cell.lblUserName.hidden = YES;
            cell.lblCategory.hidden = YES;
			cell.lblDuration.hidden = YES;
			cell.ProfileImg.hidden = YES;
			cell.img_user_unread_notif.hidden = YES;
			cell.imgNotifTime.hidden = YES;
            cell.btnNotificationShare.hidden = YES;
            cell.btnNotificationShare.hidden = YES;
            cell.btnNotificationFavorites.hidden = YES;
            cell.imgNotifPrivate.hidden = YES;
            cell.imgNotifPictureBlab.hidden = YES;
			
			if (self.activityLoading != nil) {
				[self.activityLoading removeFromSuperview];
				self.activityLoading = nil;
			}
			self.activityLoading = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
			self.activityLoading.center = cell.contentView.center;
			self.activityLoading.frame = cell.contentView.frame;
			self.activityLoading.hidesWhenStopped = TRUE;
			[self.activityLoading startAnimating];
			[cell.contentView addSubview:self.activityLoading];
			
			self.pageCounter ++;
			[self performSelectorInBackground:@selector(get_FavoritesList) withObject:nil];
		}
	}
    else{
        
        [cell.btnNotificationForward removeTarget:self action:@selector(btnForwardClicked:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnNotificationForward addTarget:self action:@selector(btnForwardClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        
//        [cell.btnNotificationConversation removeTarget:self action:@selector(btnReplyClicked:) forControlEvents:UIControlEventTouchUpInside];
//        [cell.btnNotificationConversation addTarget:self action:@selector(btnReplyClicked:) forControlEvents:UIControlEventTouchUpInside];

        [cell.btnNotificationConversation removeTarget:self action:@selector(playSoundForURL:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnNotificationConversation addTarget:self action:@selector(playSoundForURL:) forControlEvents:UIControlEventTouchUpInside];

        
        [cell.btnNotificationDetail removeTarget:self action:@selector(playSoundForURL:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnNotificationDetail addTarget:self action:@selector(playSoundForURL:) forControlEvents:UIControlEventTouchUpInside];
        
        [cell.btnNotificationShare removeTarget:self action:@selector(btnShareClicked:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnNotificationShare addTarget:self action:@selector(btnShareClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        
        [cell.btnNotificationFavorites removeTarget:self action:@selector(btnFavoriteClicked:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnNotificationFavorites addTarget:self action:@selector(btnFavoriteClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        
        if (self.arrData.count >0) {
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self.arrData objectAtIndex:indexPath.row]];
            [cell setBoxValuesWithData:dic];
            dic = nil;
        }
        
        UIView *bgColorView = [[UIView alloc] init];
        bgColorView.backgroundColor = [UIColor clearColor];
        [cell setSelectedBackgroundView:bgColorView];
        cell.multipleSelectionBackgroundView = bgColorView;
        
        cell.btnNotificationDelete.tag = indexPath.row;
        cell.btnNotificationForward.tag = indexPath.row;
        cell.btnNotificationDetail.tag = indexPath.row;
        cell.btnNotificationProfile.tag = indexPath.row;
        cell.btnNotificationConversation.tag = indexPath.row;
        cell.btnNotificationShare.tag = indexPath.row;
        cell.btnNotificationFavorites.tag = indexPath.row;
        
        if ([self.tblData isEditing]) {
            if ([self.selectedRows count]>0) {
                NSNumber *rowNsNum = [NSNumber numberWithUnsignedInt:(int)indexPath.row];
                if ( [self.selectedRows containsObject:rowNsNum] ){
                    cell.selected = YES;
                }
                else{
                    cell.selected = NO;
                }
            }
            else{
                cell.selected = NO;
            }
        }
    }
	return cell;
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath{
    
//    NotificationCell *cell = (NotificationCell *)[tableView cellForRowAtIndexPath:indexPath];
//    if (tableView.isEditing) {
//        cell.lblCategory.textColor = [UIColor whiteColor];
//    }
//    
//    // Update the delete button's title based on how many items are selected.
//	NSNumber *rowNsNum = [NSNumber numberWithUnsignedInt:(int)indexPath.row];
//	if ( [self.selectedRows containsObject:rowNsNum] )
//		[self.selectedRows removeObject:rowNsNum];
//    
//	if (self.selectedRows.count>0) {
//		[self showDeleteBtn];
//	}
//	else{
//		[self hideDeleteBtn];
//		[self.tblData setEditing:NO animated:YES];
//	}
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
//    NotificationCell *cell = (NotificationCell *)[tableView cellForRowAtIndexPath:indexPath];
//    if (!tableView.isEditing) {
//        [tableView deselectRowAtIndexPath:indexPath animated:NO];
//        cell.lblCategory.textColor = [UIColor whiteColor];
//    }
//    else{
//        
//        cell.lblCategory.textColor = [UIColor blackColor];
//    }
//    
//    // Update the delete button's title based on how many items are selected.
//	NSNumber *rowNsNum = [NSNumber numberWithUnsignedInt:(int)indexPath.row];
//	if ( [self.selectedRows containsObject:rowNsNum] )
//		[self.selectedRows removeObject:rowNsNum];
//	else
//		[self.selectedRows addObject:rowNsNum];
//    
//	if (self.selectedRows.count>0) {
//		[self showDeleteBtn];
//	}
//	else{
//		[self hideDeleteBtn];
//		[self.tblData setEditing:NO animated:YES];
//	}
}
/*
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!tableView.isEditing) {
        [tableView deselectRowAtIndexPath:indexPath animated:NO];
    }

    // Update the delete button's title based on how many items are selected.
	NSNumber *rowNsNum = [NSNumber numberWithUnsignedInt:(int)indexPath.row];
	if ( [self.selectedRows containsObject:rowNsNum] )
		[self.selectedRows removeObject:rowNsNum];
	else
		[self.selectedRows addObject:rowNsNum];
    
	if (self.selectedRows.count>0) {
		[self showDeleteBtn];
	}
	else{
		[self hideDeleteBtn];
		[self.tblData setEditing:NO animated:YES];
	}
}
*/

/*
-(IBAction)btnDeleteSelected:(id)sender{
	
	//[Validation showLoadingIndicator];
    [HUD show:YES];
    
	if (self.request !=nil) {
		self.request = nil;
	}
	
	NSString *strIds = @"";
	for (NSNumber *num in self.selectedRows) {
		NSLog(@"%@",num);
		if (strIds.length == 0) {
			strIds = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:[num intValue]] valueForKey:NOTIF_ID]];
		}
		else{
			strIds = [strIds stringByAppendingFormat:@"|%@",[[self.arrData objectAtIndex:[num intValue]] valueForKey:NOTIF_ID]];
		}
	}
	
	self.selectedIndex = (int)((UIButton *)sender).tag;
    
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:strIds,KeyValue,@"MsgIDs",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:DELETE_NOTIFICATION_FRM_LIST withParameters:nil];
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
	self.request.delegate = self;
	self.request.tag = 2;
	strUrl = nil;
}
*/

/*
-(void)showDeleteBtn{
    
	self.btnDelete.hidden = FALSE;
	[Validation removeAdviewFromSuperView];
	self.tblData.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-(64)-(64));
}

-(void)hideDeleteBtn{
    
	[UIView beginAnimations:@"moveDown" context:nil];
    //[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.5];
	self.tblData.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-64);
	self.btnDelete.hidden = TRUE;
	[UIView commitAnimations];
	
	[Validation removeAdviewFromSuperView];
	[self.view addSubview:[Validation sharedBannerView]];
}
*/
#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	
	if (self.activityLoading != nil) {
		[self.activityLoading removeFromSuperview];
//		[self.activityLoading release];
		self.activityLoading = nil;
	}
	
    
    NSLog(@"notification Response req tag %d",(int)request.tag);
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];;
	
	self.lbl_NoDataAvailable.hidden = TRUE;
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            [self.refresh endRefreshing];
            NSLog(@"dic = %@",dicResponse);
            [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (request.tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            
                            if (self.pageCounter==1) {
                                [self.arrData removeAllObjects];
                            }
                            
                            NSMutableArray *arr = [NSMutableArray arrayWithArray:(NSArray *)response];
                            self.isDataNull = NO;
                            if (arr.count < PageSize) {
                                self.isDataNull = YES;
                            }
                            
                            if (arr.count>0) {
                                [self.arrData addObjectsFromArray:arr];
                                
                                [self.tblData reloadData];
                                
                                for (NSNumber *num in self.selectedRows) {
                                    [self.tblData selectRowAtIndexPath:[NSIndexPath indexPathForRow:[num intValue] inSection:0] animated:NO scrollPosition:UITableViewScrollPositionNone];
                                }
                            }
                            
                            arr = nil;
                        }
                        response = nil;
                    }
                    else if ([[NSString stringWithFormat:@"%@",[[dicResponse objectForKey:USER_STATUS] valueForKey:USER_STATUS_STATUS]] boolValue]){
                        self.isDataNull = YES;
                        if (self.pageCounter==1) {
                            [self.arrData removeAllObjects];
                        }
                        [self.tblData reloadData];
                        //					[self.arrData removeAllObjects];
                        //					[self.selectedRows removeAllObjects];
                        
                    }
                }
                if (self.arrData.count == 0 && self.pageCounter == 1) {
                    //self.lbl_NoDataAvailable.text = (self.isSentNotifList)?NO_SENT_NOTIF:NO_RECEIVED_NOTIF;
                    self.lbl_NoDataAvailable.hidden = FALSE;
                }
                [self.refresh endRefreshing];
                [HUD hide:YES];
            }
            else if (request.tag == 2){
                //delte notif
                BOOL is_NewServiceCall = FALSE;
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        [self.selectedRows removeAllObjects];
                        self.pageCounter = 1;
                        self.isDataNull = NO;
                        [self.arrData removeAllObjects];
                       // [self.tblData setEditing:NO];
                    //    [self.btnDelete setHidden:YES];
                       // [Validation showLoadingIndicator];
                        [HUD show:YES];
                        [self performSelectorInBackground:@selector(get_FavoritesList) withObject:nil];
                        is_NewServiceCall = YES;
                        
                    }
                }
                if (self.arrData.count == 0 && is_NewServiceCall == FALSE) {
                    self.lbl_NoDataAvailable.hidden = FALSE;
                }
                [HUD hide:YES];
            }
            else if (request.tag == 3){
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        NSLog(@"%@",dicResponse);
                    }
                }
                [HUD hide:YES];
            }
            else if (request.tag == 4){
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        if (self.arrData.count == 0) {
                            self.lbl_NoDataAvailable.hidden = NO;
                        }
                        else{
                            self.pageCounter = 1;
                            self.isDataNull = NO;
                            [self performSelector:@selector(get_FavoritesList)];
                        }
                    }
                }
                
                request = nil;
//                [HUD hide:YES];
            }
            else if (request.tag == 5){
                //share records
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        id response = [dicResponse objectForKey:RESPONSE];
                        NSLog(@"%@",response);
                        
                        [self shareWithShareURL:[NSDictionary dictionaryWithDictionary:(NSDictionary *)response]];
                        
                    }
                }
                [HUD hide:YES];
            }
        }
    }
    else{
        [HUD hide:YES];
    }
    self.request = nil;
	dicResponse = nil;
	self.isServiceWaitingForResponse = NO;
}

- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
    [HUD hide:YES];
}

#pragma mark    UIActionsheet Delegate

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"button index = %d",(int)buttonIndex);
    
    if (buttonIndex == actionSheet.cancelButtonIndex) {
        
    }
    else if (buttonIndex == 0){
        //only yap
        [self performSegueWithIdentifier:RECORD_OPTION_VC sender:nil];
    }
    else if (buttonIndex == 1){
        //yap with image
        [self performSegueWithIdentifier:CAPTURE_IMAGE_VC sender:nil];
    }
    else if (buttonIndex == 2){
        //yap with video
        if ([[NSFileManager defaultManager] fileExistsAtPath:VIDEO_RECORDING_FOLDER]) {
            //when folder exists
            NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
            if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
                [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
            }
        }
        [self performSegueWithIdentifier:SET_VIDEO_PRIVACY_VC sender:nil];
    }
}



#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:RECORD_OPTION_VC] || [segue.identifier isEqualToString:CAPTURE_IMAGE_VC] || [segue.identifier isEqualToString:SET_VIDEO_PRIVACY_VC]) {
        if (appDelegate.dic_NotificationReleatedData != nil) {
            appDelegate.dic_NotificationReleatedData = nil;
        }
        
        NSString *strRecId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:SENDER_ID]];
        if ([strRecId isEqualToString:self.strLoggedInUserId]) {
            strRecId = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:RECEIVER_ID]];
        }
        
        appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                    [NSArray arrayWithObjects:strRecId, nil],SelectedIds,
                                                    [NSNumber numberWithBool:FALSE],IS_GroupNotif,
                                                    [NSNumber numberWithBool:NO],IS_NotifSendToAll,
                                                    @"0",BlabType,
                                                    nil];
    }

    else if ([segue.identifier isEqualToString:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC]){
        
        if (appDelegate.isForwarded) {
            AddFriendFromExistingFriendListVC *obj = segue.destinationViewController;
            obj.dicSelectedNotifToForward = [NSDictionary dictionaryWithDictionary:(NSDictionary *)[self.arrData objectAtIndex:self.selectedIndex] ];
        }
    }
    
    [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
    [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
