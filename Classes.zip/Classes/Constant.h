//
//  Constant.h
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#ifndef WWHHAAZZAAPP_Constant_h
#define WWHHAAZZAAPP_Constant_h

//#pragma mark NSLOG
#define NSLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__)

#define SUCCESS_MSG_DURATION		2
#define ERROR_MSG_DURATION			3
#define INFO_MSG_DURATION           4
#define totalRecordingDuration      15.3f
#define totalRecordingDuration_Hblab      90.3f

#define RECORDING_FOLDER				[NSTemporaryDirectory() stringByAppendingPathComponent:@"Recording"]
#define VIDEO_RECORDING_FOLDER          [NSTemporaryDirectory() stringByAppendingPathComponent:@"VidiRecording"]
//#define ALARM_RECORDINGS_FOLDER         [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)objectAtIndex:0]stringByAppendingPathComponent:@"AlarmRecordings"]
#define ALARM_RECORDINGS_FOLDER         NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)

#define INSTAGRAMIMAGE_FOLDER                [NSTemporaryDirectory() stringByAppendingPathComponent:@"InstagramImageData"]
#define INSTAGRAMVIDEO_FOLDER                [NSTemporaryDirectory() stringByAppendingPathComponent:@"InstagramVideoData"]


enum typeRecurringReminder
{
    kDaily=1,
    kWeekly=2,
    kMonthly=3,
    kYearly=4,
};
#pragma mark		ViewController Name

#define FORMAT_DATE                 @"MM-dd-yyyy"
#define FORMAT_TIME                 @"hh:mm a"
#define FORMAT_DATE_TIME            @"MM-dd-yyyy hh:mm a"

#define STORYBOARD					@"Main"
#define VIEW_CONTRLLER				@"ViewController"
#define LOGIN_VC					@"LoginVC"
#define SIGNUP_VC					@"SignUpVC"
#define PROFILE_VC					@"ProfileVC"
#define EDIT_PROFILE_VC				@"EditProfileVC"
#define NOTIFICATION_VC				@"NotificationVC"
#define NOTIFICATION_CELL_VC		@"NotificationCell"
#define ALARM_MAIN_VC               @"AlarmMainVC"
#define SETTINGS_VC					@"SettingsVC"
#define HASH_BLAB_VC                @"HashBlabHomeVC"
#define HELP_VIDEO_LIST_VC          @"HelpVideoListVC"
#define ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC @"AddFriendFromExistingFriendListVC"
#define ADD_FRIENDS_VC              @"AddFriendsVC"
#define OTHER_FRNDREQ_NOTIF_LIST_VC		@"OtherFriendNotifListVC"
#define SEARCH_NEW_FRIEND_FROM_WHAZUP_VC	@"SearchFriendVC"
#define NOTIF_OPTION_VC				@"NotifOptionVC"
#define LISTALL_MY_CAT_SUBCAT_VC    @"ListAllMyCatSubcatVC"
#define GROUP_LIST_VC				@"GroupListVC"
#define CREATE_NEW_GRP_VC			@"CreateNewGroupVC"
#define USER_LIST_VC				@"UserListVC"
#define EDIT_GRP_LIST_VC			@"GroupUserListVC"
#define GROUP_LIST_CELL				@"GroupListCell"
#define BLOCK_UNBLOCK_VC			@"BlockUnBlockVC"
#define ABOUT_APP_VC				@"AboutVC"
#define SOCIAL_SHARE_VIEW           @"SocialShareView"
#define SOCIAL_SHARE_VC             @"SocialShareVC"
#define MENU_SLIDER_CLASS           @"SWRevealViewController"
#define MENU_VC                     @"MenuVC"
#define FAVORITES_LIST_VC           @"FavoritesVC"
#define MENU_CELL                   @"MenuCell"
#define SHOW_PKR_VC                 @"ShowPickerVC"
#define RECORD_VC                   @"RecrodingVC"
#define RECORD_OPTION_VC            @"RecordingOptionVC"
#define UPLOAD_FORM_VC              @"UploadFormVC"
#define CATEGORY_LIST_FOR_UPLOAD_VC @"CategoryListForUploadVC"
#define CAPTURE_IMAGE_VC            @"CaptureImageVC"
#define SET_VIDEO_PRIVACY_VC        @"SetVideoAndPrivacyVC"
#define COLLECTIONCELL_IN_TABLEVIEWCELL     @"AFTableViewCell"
#define SUBCATE_COLLECTION_CELL     @"SubCat_CollectionCell"
#define USER_LOCATION_VC            @"LocationVC"
#define USER_INTEREST_VC            @"UserInterestList"
#define INTRODUCTION_VC             @"IntroductionVC"
#define PROFILE_DESCRIPTION_VC      @"ProfileDescriptionVC"
#define SEARCH_CONTAINER_VC         @"SearchContainerVC"
#define INTRESTLIST_FOR_SEARCH_VC   @"InterestListForSearchVC"
#define PROFILE_DESCFOR_SEARCHVC    @"ProfileDescForSearchVC"
#define USER_LIST_BY_INTEREST       @"UserListingByInterestVC"
#define SEARCH_FILTER_SELECTION_VC  @"SearchFilterSelectionVC"
#define FILTER_CELL                 @"FilterCell"
#define USER_CONVERSATION_CHAT_VC   @"UserConversationChatVC"
#define REPORT_ABUSE_VC             @"ReportAbuseVC"
#define CONVERSATION_WITH_IMG_CELL  @"ConversationWithImgCell"
#define CONVERSATION_WO_IMG_CELL    @"ConversationWithoutImgCell"
#define KEEP_REQUEST_LIST_VC        @"KeepRequestListVC"
#define KEEP_REQUEST_LIST_CELL      @"KeepRequestListCell"
#define CONVERSATION_GRP_DETAIL_VC  @"ConversationGrpDetailVC"
#define CUSTOM_CAMERA_VC            @"CustomCameraVC"
#define CREATE_GRP_WITH_SELECTED    @"CreateGrpWithSelected"
#define ALARM_FRIEND_LIST_VC        @"AlarmFriendListVC"
#define GET_ALLMYSTICKER            @"Sticker/GetAllMySticker"
#define SELECT_STORE_VC             @"SelectStoreVC"
#define SHOW_ITEMLIST_FOR_SELECTED_STORE_VC @"ShowItemListForSelectedStoreVC"
#define STORE_ITEM_COLLECTIONVIEW_CELL      @"StoreItemCollectionViewCell"
#define STORE_ITEM_COLLECTION_FLOWLAYOUT    @"StoreItemCollectionFlowLayout"
#define SELECTED_STORE_SELECTED_ITEM_DETAIL_VC @"SelectedStore_SelectedItem_DetailVC"
#define CONVERSATION_WITH_STICKER_CELL      @"ConversaionWithStickerCell"
#define GET_GENDER_BDATE_ORIVACY_VC @"GetGenderBDatePrivacyVC"
#define SIGNUP_GET_CONTACTNUMBER_VC @"SinUpGetUserContactNumberVC"
#define FIND_FRIENDS_ON_FB_VC       @"FindFriendsOnFB_VC"
#define ALARM_GRP_LIST_VC           @"AlarmGrpListVC"

#define RECORD_OPTION_HBlab_VC            @"RecordingOptionHBlabVC"
#define NOTIF_OPTION_HBLAB_VC				@"NotifOptionHBlabVC"
#define RECORD_HBLAB_VC                   @"RecrodingHBlabVC"
#define CAPTURE_IMAGE_HBLAB_VC            @"CaptureImageHBlabVC"
#define SET_VIDEO_PRIVACY_HBLAB_VC        @"SetVideoAndPrivacyHBlabVC"

#define localize(key, default) NSLocalizedStringWithDefaultValue(key, nil, [NSBundle mainBundle], default, nil)

#pragma mark - Message Bars

#define kStringMessageBarErrorTitle localize(@"message.bar.error.title", @"Error")
#define kStringMessageBarInfoTitle localize(@"message.bar.info.title", @"Information")
#define kStringMessageBarSuccessTitle localize(@"message.bar.success.title", @"Success")



#define kStringMessageBarErrorMessage localize(@"message.bar.error.message", @"This is an error message!")
#define kStringMessageBarSuccessMessage localize(@"message.bar.success.message", @"This is a success message!")
#define kStringMessageBarInfoMessage localize(@"message.bar.info.message", @"This is an info message!")

#define kStringMessageBarNetworkAvailabilityMessage localize(@"message.bar.network.message", @"Please check your internet connection.!")

#pragma mark - UIAlert Message

#define ALERT				@"Alert"
#define MESSAGE				@"Message"
#define WARNING				@"Warning"
#define INFO				@"Information"
#define ERROR				@"Error"
#define FAILURE				@"Failure"
#define SUCCESS				@"Success"
#define CONFIRM				@"Confirmation"
#define CANCELLED           @"Cancelled"

#define ALREADY_EXISTS		@"%@ already exists."
#define INVITE_TEXT			@"You have been invited to an amazing app called Blabeey. Please come check it out, you won’t be disappointed."
#define ALERT_FOR_PHOTO_LIBRARY_ACCESS		@"You have not authorised Blabeey to access your photo library. Please go to Settings -> Privacy -> Photos and enable Blabeey to access your photos."
#define DEACTIVATE_CONFIRM_MSG	@"Are you sure you want to deactivate this account?"
#define ACCOUNT_DEACTIVATED		@"This account has been deactivated."
#define CONFIRM_GRP_DELETE		@"Are you sure, you want to delete this group?"
#define SMS_CHARGE_ALERT                @"Standard text messaging and data rates apply."
#define KEEP_REQUEST_MESSAGE    @"Would you like to send keep request for this Blab?"
#define CANNOT_FAVORITE_PRIVATE_BLAB    @"You cannot favourite private blab."
#define MESSAGE_SOMETHING_WRONG    @"Something went wrong. Please try again later."
#define CANNOT_SHARE_PRIVATE_BLAB    @"Blabs marked as Private cannot be shared."

#define MESSAGE_CANCELLED				@"Message Cancelled"
#define MESSAGE_SENT					@"Message Sent"
#define MESSAGE_FAILED					@"Message Failed"

#define MAIL_SENDING_CANCELLED			@"Sending cancelled"
#define MAIL_SEND						@"Mail sent"
#define MAIL_SENDING_FAILED				@"Sending failed"
#define MAIL_SAVED						@"Mail saved"
#define TXT_ALARM                       @"Alarm"

#pragma mark Button Title

#define OK_BUTTON_TITLE				@"Ok"
#define CANCLE_BUTTON_TITLE			@"Cancel"
#define YES_BUTTON_TITLE			@"Yes"
#define NO_BUTTON_TITLE				@"No"
#define SHOW_BUTTON_TITLE			@"Show"
#define HIDE_BUUTON_TITLE			@"Hide"
#define PLAY_BUTTON_TITLE			@"Play Now"
#define SHOW_BUTTON_TITLE			@"Show"
#define LATER_BUTTON_TITLE			@"Later"
#define SHARE_TEXT                  @"Blabeey!!!"
#define HASHTAG_CHARACTER           @"@"
#define HASHBLAB_CHARACTER          @"#"

#pragma mark - Buttons

//#define kStringButtonLabelSuccessMessage localize(@"button.label.success.message", @"Success Message")
//#define kStringButtonLabelErrorMessage localize(@"button.label.error.message", @"Error Message")
//#define kStringButtonLabelInfoMessage localize(@"button.label.info.message", @"Information Message")
//#define kStringButtonLabelHideAll localize(@"button.label.hide.all", @"Hide All")


#pragma mark - Fonts

#define Font_Montserrat_Bold		@"Montserrat-Bold"
#define Font_Montserrat_Regular		@"Montserrat-Regular"

#define Font_OpneSans_ExtraBold     @"OpenSans-Extrabold"	//@"OpenSans-Bold"
#define Font_OpneSans_Bold			@"OpenSans-Bold"
#define	Font_OpneSans_Regular		@"OpenSans"
#define	Font_OpneSans_Light			@"OpenSans-Light"
#define	Font_OpneSans_SemiBol		@"OpenSans-Semibold"
//OpenSans-Regular.ttf
#pragma mark - Color

#define UIColorFromRGB(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define TWITTER_BLUE_COLOR			UIColorFromRGB(0X04c6fb)

#define NUMBER_OF_MENU_OPTION	2
#define MENU_BTN_HEIGHT			50

#pragma mark ImageName

#define Blue_BG						@"app_bg.png"
#define BlueTopBar					@"bg_topbar.png"

#define BTN_MENU_IMG                @"btn_menu.png"
#define BTN_BACK_IMG                @"icon_topbar_transparent.png"

#define LilstBox_Bg_Notif           @"bg_listview_home_screen_New.png"
#define ListBox_User_Bg_Conversation   @"bg_Conversation_UserList.png"
#define LilstBox_Bg                 @"bg_listview_home_screen.png"
#define BtnNotifDelete				@"icn_homescreen_delete.png"
#define BtnNotifRead				@"icn_homescreen_play_default.png"
#define BtnNotifUnRead				@"icn_homescreen_play_highlighted.png"
#define BtnNotifReplayResend		@"icn_homescreen_reply.png"
#define BtnNotifForward             @"icn_HomeView_forward.png"
#define BtnUserRemove               @"btn_user_remove.png"
#define BtnDeleteRed                @"btn_UserList_delete.png"
#define BtnNotifAddFrnd				@"icn_topbar_add_new.png"
#define BtnNotifHideMenu			@"icn_topbar_dropdown.png"
#define BtnNotifShowMenu			@"icn_topbar_dropdown_down.png"
#define BtnNotifFriendsRead			@"icn_topbar_friendsRequest_default.png"
#define BtnNotifFriendsUnRead		@"icn_topbar_friendsRequest_highlighted.png"
#define BtnNotifSearch				@"icn_topbar_search.png"
#define BtnNotifSettings			@"icn_topbar_settings.png"
#define Btn_selectedUserIndication	@"btn_search_selected_user.png"
#define Btn_DeSelectedUserIndication	@"btn_search_deselected_user.png"
#define Btn_AddFriend				@"btn_search_addfriend.png"
#define Btn_Waiting_For_Response	@"btn_search_waiting_response.png"
#define Btn_Reject_Request			@"btn_search_reject_request.png"
#define Btn_Accept_Request			@"btn_search_accepted_request.png"
#define ListBox_Group_Bg			@"bg_listview_GroupList.png"
#define Btn_Group					@"btn_groups.png"
#define Btn_Group_Edit				@"icon_Edit.png"
#define ListBox_Unread_Bg			@"bg_listview_home_screen_blue_border.png"
#define Highlight_User_Unread_Notif	@"icn_home_unread.png"
#define Btn_Pause                   @"btn_pause.png"

#define btn_With_WhiteBg			@"btn_signin.png"
#define btn_Invite_FB				@"btn_settings_invite.png"

#define btn_Blue_Selected			@"btn_SelectedOption.png"
#define btn_White_DeSelected		@"btn_DeselectedOption.png"
#define Btn_User_Blocked			@"btn_block_user.png"

#define Btn_Apns_Close              @"btn_APNS_close.png"
#define Btn_Apns_Play               @"btn_APNS_play.png"

#define Btn_Share                   @"icn_home_share.png"

#define BTN_FB_SHARE                @"icn_share_fb.png"
#define BTN_TWITTER_SHARE           @"icn_share_twitter.png"

#define Btn_Like                    @"icn_HomeView_like.png"
#define Btn_UnLike                  @"icn_HomeView_unlike.png"

#define btn_Checkbox_Deselected     @"btn_checkbox_deselected.png"
#define btn_Checkbox_Selected       @"btn_checkbox_selected.png"

#define BTN_CAMERA_FRONT_SELECTED   @"btn_camera_front_highlighted.png"
#define BTN_CAMERA_FRONT_DESELECTED @"btn_camera_front_default.png"

#define BTN_CAMERA_FLASH_SELECTED   @"btn_camera_flash_highlighted.png"
#define BTN_CAMERA_FLASH_DESELECTED @"btn_camera_flash_default.png"



//MENU
#define btnMenu_FriendList          @"icn_menu_create_default.png"
#define btnMenu_FriendList_Selected @"icn_menu_create_highlighted.png"
#define btnMenu_Add_Friend          @"icn_menu_add_friends_default.png"
#define btnMenu_Add_Friend_Selected @"icn_menu_add_friends_highlighted.png"
#define btnMenu_Alarm               @"icn_menu_alarm_default.png"
#define btnMenu_Alarm_Selected      @"icn_menu_alarm_highlighted.png"
#define btnMenu_Favorite            @"icn_menu_favorite_default.png"
#define btnMenu_Favorite_Selected   @"icn_menu_favorite_highlighted.png"
#define btnMenu_Home                @"icn_menu_home_default.png"
#define btnMenu_Home_Selected       @"icn_menu_home_highlighted.png"
#define btnMenu_Frnd_Request        @"icn_menu_notification_default.png"
#define btnMenu_Frnd_Request_selected   @"icn_menu_notification_highlighted.png"
#define btnMenu_Search              @"icn_menu_search_default.png"
#define btnMenu_Search_Selected     @"icn_menu_search_highlighted.png"
#define btnMenu_Settings            @"icn_menu_settings_default.png"
#define btnMenu_Settings_Selected   @"icn_menu_settings_highlighted.png"
#define btnMenu_NearbyUser          @"icn_menu_nearby_default.png"
#define btnMenu_NearbyUser_Selected @"icn_menu_nearby_highlighted.png"
#define btnMenu_KeepNotif           @"icn_menu_keepReq_default.png"
#define btnMenu_KeepNotif_Selected  @"icn_menu_keepReq_highlighted.png"
#define btnMenu_Store               @"icn_menu_store_default.png"
#define btnMenu_Store_Selected      @"icn_menu_store_highlighted@2x.png"
#define btnMenu_HBLAB               @"icn_menu_#blab_default@2x.png"
#define btnMenu_HBLAB_Selected      @"icn_menu_#blab_highlighted@2x.png"
#define btnMenu_Help                @"icn_menu_help_default.png"
#define btnMenu_Help_Selected       @"icn_menu_help_highlighted.png"


#define btnRecordStart              @"icon_record_green.png"
#define btnRecordStop               @"icon_record.png"

#define Btn_Search_Indicator        @"search_tab_indicator.png"

#define Btn_Block_Black             @"btn_block.png"
#define Btn_Report_Abuse            @"icn_report_abuse.png"

#pragma mark -	SERVICE-URL

#define App_Environment				1

#if App_Environment == 1            

//production
/*
 http://www.blabeey.com/
 http://upload.blabeey.com/
 */

#define UPLOAD_AUDIO_FILE           @"http://upload.blabeey.com/api/Upload/Sound"
#define BASE_URL                    @"http://www.blabeey.com/api/"
#define MERGE_AUDIO_IMAGE           @"http://upload.blabeey.com/api/Upload/MergeAudioImage"
#define SHARE_URL                   @"http://www.blabeey.com/content/newcontent/"
#define TERMS_AND_CONDITION         @"http://blabeey.com/termsandconditions.html"
#define PRIVACY_POLICY              @"http://blabeey.com/privacy.html"
#define FACEBOOK_INVITE_URL         @"http://www.blabeey.com"

#else

#define BASE_URL                    @"http://wwhhaazzuupp.com/api/"
#define UPLOAD_AUDIO_FILE           @"http://upload.wwhhaazzuupp.com/api/Upload/Sound"
#define MERGE_AUDIO_IMAGE           @"http://upload.wwhhaazzuupp.com/api/Upload/MergeAudioImage"
#define SHARE_URL                   @"http://wwhhaazzuupp.com/content/content/"
#define TERMS_AND_CONDITION         @"http://blabeey.com/termsandconditions.html"
#define PRIVACY_POLICY              @"http://blabeey.com/privacy.html"
#define FACEBOOK_INVITE_URL         @"http://wwhhaazzuupp.com"

#endif


#define REMOVE_DEVICETOKEN          @"User/UpdateDeviceToken"
#define GET_ALL_USERS				@"getallusers"
#define LOGIN						@"Login/Login?"
#define FORGOT_PWD					@"User/ForgotPass"
#define CHECK_USER_EXIST			@"CheckUserExist/CheckUserExist"		//api/CheckUserExis/tCheckUserExist
#define REGISTRATION				@"Login/Registration"
#define LOGIN_WITH_FB				@"LoginWithFB/LoginWithFB"
#define EDIT_USER_PROFILE			@"User/EditProfile"
#define SEND_USER_CONTACT_LIST		@"friend/GetFriendListByContactNo"
#define SEND_FRIEND_REQUEST			@"Friend/SendFriendRequest"
#define GET_MYFRIENDS_LIST			@"Friend/GetUserFriendList"
#define GET_FB_OR_CONTACT_USER      @"Friend/GetFacebookOrPhoneUsers"
#define ADD_FRIEND_BY_USERID        @"Friend/AddFriendByUserID"
#define SEARCH_USER					@"User/SearchUser"
//#define GET_NOTIF_OPTION			@"Messaging/GetAllCategory"
#define GET_CAT_SUBCAT_LIST         @"Messaging/GetAllCategorySubCategory"
#define GET_ALLMY_CAT_SUBCAT        @"Messaging/GetAllMyCategorySubCategory"
#define SEND_NOTIF_MSG				@"Messaging/SendMessage"
#define SEND_TEST_MSG               @"Messaging/SendTestMessage"
#define GET_RECEIVED_NOTIF_LIST		@"Messaging/GetReceivedMessage"
#define GET_SENT_NOTIF_LIST			@"Messaging/GetSentMessage"
#define LOG_OUT						@"User/Logout"
#define GET_ALL_HELP_VIDEO          @"Help/GetAllHelpVideo"
#define SEARCH_USER					@"User/SearchUser"
#define RECOMMENDED_USER			@"User/GetRecommendedUsers"
#define ADD_FRIEND					@"Friend/SendFriendRequest"
#define ACCEPT_REJECT_FRND_REQ		@"Friend/AcceptDenyFriendRequest"
#define GET_REQUEST_LIST			@"Friend/GetAllFriendRequest"
#define GET_SENT_REQUEST_LIST       @"Friend/GetAllSentFriendRequest"
#define DELETE_NOTIFICATION_FRM_LIST @"Messaging/DeleteMessage"
#define DEACTIVATE_USER				@"User/DeactivateUser"
#define ADD_FB_FRIENDS				@"Friend/GetFriendListByFacebookID"
#define NOTIF_READ					@"Messaging/ReadMessage"
#define GET_GRP_LIST				@"UserGroup/GetGroupList"
#define CREAT_NEW_GROUP				@"UserGroup/CreateNewGroup"
#define EDIT_GROUP_DETAIL			@"UserGroup/EditGroup"
#define GET_USER_IN_GRP				@"UserGroup/GetGroupUserList"
#define	DELETE_GRP					@"UserGroup/DeleteGroup"
#define	UPDATE_USER_SETTING			@"User/UpdateUserSetting"
#define BLOCK_UNBLOCK_USER			@"User/BlockUnblockUser"
#define GET_BLOCKED_USER_LIST		@"User/GetBlockUserList"
#define GET_SUB_CAT_BY_CAT_ID		@"Messaging/GetAllSubCategory"
#define SET_NOTIF_LIKE_UNLIKE       @"Messaging/LikeUnlikeMessage"
#define GET_LIKE_LIST               @"Messaging/GetLikeList"
//#define UPLOAD_AUDIO_FILE           @"http://upload.wwhhaazzuupp.com/api/Upload/Sound"
#define GET_REQUEST_COUNT           @"Messaging/GetTotalCount"
#define SEARCH_MSG_CONVERSATION     @"Messaging/SearchMsgConversation"
#define GET_INTEREST_LIST           @"User/GetAllInterestList"
#define SET_INTEREST                @"User/AddEditUserInterest"
#define SET_PROFIL_DESCRIPTION      @"User/AddEditUserDesc"
#define GET_USER_INTEREST           @"User/GetInterestList"
#define GET_USER_INTEREST_SUB_INTERESTLIST  @"User/GetAllInterestSubInterest"
#define GET_ALL_DESC_SUBDESC        @"User/GetAllDescSubDesc"
#define SET_USER_LAT_LONG           @"Friend/SetUserLatLong"
#define SEARCH_USER_BY_INTEREST     @"User/SearchUserByInterest"
#define UNFRIEND_A_FRIEND           @"Friend/UnFriend"
#define SEARCH_BY_FILTER            @"User/SearchUserDetail"
#define GET_CONVERSATIONLIST_WITH_USERS  @"Messaging/GetAllMsgConversation"
#define GET_CONVERSATION_WITH_SELECTED_USER     @"Messaging/GetMsgConversationByID"
#define GET_ALL_REPORT_ABUSE_OPTION @"AbuseReport/GetAllAbuseReportList"
#define DELETE_SELECTED_CHAT_FROM_CONVERSATION  @"Messaging/DeleteMessageConversation"
#define DELETE_WHOLE_CONVERSATION_WITH_USERS    @"Messaging/DeleteConversation"
#define SHARE_SELECTED_CHAT         @"Content/GetContentShareLink"
#define ADD_REPORT_ABUSE            @"AbuseReport/AddAbuseReport"
#define SEND_KEEP_REQUEST           @"Messaging/SetRequestSent"
#define DELETE_CHAT_PRIVATE_MESSAGE @"Messaging/DeletePrivateOnceMessages"
#define ACCEPT_DENY_KEEP_MESSAGE    @"Messaging/AcceptDeniedKeepRequest"
#define GET_KEEP_REQUEST_LIST       @"Messaging/GetKeepRequestListByUserID"
#define FEATURED_BANNER_LIST        @"FeaturedBanner/GetAllFeaturedBanner"
#define GET_USER_ALL_DETAIL         @"User/GetUserAllDetail"
#define SEND_ALARM_REQUEST          @"Alarm/SendAlarmRequest"
#define GET_ALL_ALARM_REQUEST       @"Alarm/GetAllAlarmRequest"
#define ACCEPTDENY_ALARM_REQUEST    @"Alarm/AcceptDenyAlarmRequest"
#define GET_ALLMYSTICKER            @"Sticker/GetAllMySticker"
#define GET_ALL_PAID_STICKERS       @"Store/GetAllPaidStickers"
//#define GET_ALL_PAID_CATEGORY       @"Store/GetAllPaidCategorySubCategory"
#define GET_STICKERLIST_BY_STICKER_ID   @"Sticker/GetStickerDetailByID"
#define SEND_STICKER_PAYMENT_RESPONSE_VALUES    @"Purchase/ProcessPaymentSticker"
#define GET_ALL_PAID_CATEGORY        @"Store/GetAllPaidCategory"
#define GET_ALL_PAID_SUBCATEGORYBYID @"Store/GetAllPaidSubCategoryByID"

#define SEND_STICKER_PAYMENT_RESPONSE_VALUES    @"Purchase/ProcessPaymentSticker"
#define SEND_CATEGORY_PAYMENT_RESPONSE_VALUES    @"Purchase/ProcessPayment"


#define GET_ALL_FEATURED_HASHBLAB       @"HashBlab/GetAllFeaturedHashBlab"
#define GET_ALL_RECOMMENDED_HASHBLAB    @"HashBlab/GetRecommendedHashBlab"
#define GET_ALL_HASHCONVOS              @"HashBlab/GetAllHashConversation"
#define GET_MY_HASH_CONTOS              @"HashBlab/GetMyHashConversation"
#define GET_ALL_HASHBLAB_CAT_SUBCAT     @"HashBlab/GetAllHashCategorySubCategory"
#define SEND_HASH_MESSAGE               @"HashBlab/SendHashMessage"
#define GET_HASH_CONVERSATION_DETAIL_BYID    @"HashBlab/GetHashConversationDetailByID"
#define FOLLOW_UNFOLLOW                 @"Follower/FollowUnfollow"
#define SET_VIDEO_VIEW_COUNT            @"HashBlab/SetBlabViewCount"
#define HASH_BLAB_SEARCH                @"HashBlab/SearchHashConversation"
#define HASH_BLAB_DELETE                @"HashBlab/DeleteHashBlab"
#define GET_SHORTDETAIL_HASHCONV_BYID   @"HashBlab/GetShortDetailHashConvByID"
#define LIKE_UNLIKE_HASH_CONVERSATION   @"HashBlab/LikeUnlikeHashConversation"
#define DELETE_HASH_CONVERSATION_BY_ID  @"HashBlab/DeleteHashConversationByID"
#define EDIT_HASH_CONVERSATION          @"HashBlab/EditHashConvesation"


/*
 ConvCreateDate in GetAllMsgConversation
 &
 strDate in GetMsgConversationByID
 
 */
#pragma mark	FACEBOOK


#pragma mark Response key

#define apnsTag				 @"apnsTag"

#define RESPONSE					@"Response"
#define STATUS						@"Status"
#define USER_STATUS					@"UserStatus"
#define IS_ACTIVE					@"IsActive"
#define IS_DELETE					@"IsDelete"
#define USER_STATUS_STATUS			@"status"


#define IS_SENT_NOTIF_LIST			@"isSentNotifList"

#pragma mark	User Default Key name

#define DEVICE_TOKEN			@"DeviceToken"
#define IS_LOGIN                @"is_Login"

#define LOGIN_USER_DISPLAY_NAME	@"Name"						//display name		- not unique
#define LOGIN_USER_MAIDEN_NAME	@"MaidenName"
#define LOGIN_USER_NAME			@"UserName"					//user name			- unique (check user exists)
#define W_ID					@"userID"
#define LOGIN_USER_EMAIL		@"userEmail"
#define LOGIN_USER_KEY			@"keyPWD"
#define LOGIN_USER_PHONE		@"Phone"
#define LOGIN_USER_PHOTOPATH	@"PhotoPath"
#define GENERAL_KEY				@"GeneralKey"
#define APP_PLIST_NAME			@"WWHHAAZZAAPP-Info"
#define APPLICATION_OS			@"IOS"
#define IS_APNS_OFF				@"OffPushNotif"
#define IS_QUIETMODE_ON         @"QuietMode"
#define IS_SAVE_TO_GALLERY      @"IsSaveToGallery"
#define LOGIN_USER_DOB          @"DOB"
#define LOGIN_USER_DateOfBirth  @"DateOfBirth"
#define LOGIN_USER_ANNIVERSARY  @"AnniversaryDate"
#define LOGIN_USER_GENDER       @"Gender"
#define IS_FROM_SIGN_UP         @"isFromSignUp"
#define IS_OVERLAY_VIEWED_CONVOS                @"isOverlayViewedConvos"
#define IS_OVERLAY_VIEWED_FRIENDLIST            @"isOverlayViewedFriendList"
#define IS_OVERLAY_VIEWED_REMINDER              @"isOverlayViewedReminder"
#define IS_OVERLAY_VIEWED_SETTING               @"isOverlayViewedSetting"
#define IS_OVERLAY_VIEWED_SENDBLAB              @"isOverlayViewedSendBlab"
#define IS_OVERLAY_VIEWED_FRIEND_REMINDER       @"isOverlayViewedFriendReminder"
#define IS_MESSAGE_SHOW_FOR_VIDEO_SCREEN       @"isMessageShowForVideoScreen"
#define IS_MESSAGE_SHOW_FOR_AUDIO_SCREEN       @"isMessageShowForAudioScreen"
#define DIC_SIGNUP              @"dic_SignUp"
#define SIGNUP_USERNAME         @"UserName"
#define SIGNUP_EMAIL            @"Email"
#define SIGNUP_PASSWORD         @"Password"
#define SIGNUP_DISPLAYNAME      @"DisplayName"
#define SIGNUP_MAIDENNAME       @"MaidenName"
#define SIGNUP_USER_PHOTO       @"UserProfilePic"
#define SIGNUP_DOB              @"DOB"
#define SIGNUP_GENDER           @"Gender"
#define SIGNUP_PRIVACY          @"Privacy"


#define GenderMale              @"Male"
#define GenderFemale            @"Female"
#define GenderDoNotDisclose     @"Do not disclose"
#define GenderDoesNotMatter     @"Doesn't matter"
#define Profile_Public          @"Public"
#define Profile_Private         @"Private"
#define Select_DOB              @"Birthday"


#define SelectedIds             @"arrSelectedIds"
#define IS_GroupNotif           @"isGroupNotif"
#define IS_NotifSendToAll       @"isNotifSendToAll"
#define IsPrivate               @"IsPrivate"
#define Only_Yap                @"Simple Blab"
#define Yap_With_Image          @"Blab with Picture"
#define Yap_With_Video          @"Vidi Blab"
#define Text_Blab               @"Text Blab"
#define CapturedImage           @"CapturedImage"
#define CapturedVideo           @"CapturedVideo"
#define BlabType                @"MsgType"
#define ImageCaption            @"imageCaption"
#define SelectedBlabDic         @"selectedBlabDic"
#define IsPublicImg             @"IsPublicImg"
#define RequestedKeepStatus     @"KeepStatus"
#define Is_Create_Direct_Group  @"isCreateDirectGroupFromAddFriendVC"
#define Selected_Friends_For_Creating_Group @"Friends_selected_From_AddFriendVC"
#define TOTAL_FRIENDS           @"totalfriends"
#define REPLY_TO_ONE_BLAB_ID           @"replayToOneBlabID"

/*
public enum MessageKeepStatus
{
    Once = 1,
    NeverGo = 2
}
*/

//------------------------------------


#pragma mark PRODUCT IDs

/*
// Non Consumable
#define Soundtrack_0_99							@"Item_0_99"				//appId = 879462266
#define Soundtrack_1_99							@"Item_1_99"				//appId = 879462279
#define Soundtrack_2_99							@"Item_2_99"				//appId	= 879462536
//Non-Renewing Subscription
#define Subscription_3_99						@"Item_3_99"			//appId = 879829410
#define Subscription_4_99						@"Item_4_99"				//appId	= 879751716
*/

// Consumable
#define Product_0_99							@"product_0_99"				//appId = 987925751
#define Product_1_99							@"product_1_99"				//appId = 987925769
#define Product_2_99							@"product_2_99"				//appId	= 987927544
#define Product_3_99                            @"product_3_99"             //appId = 987927542
#define Product_4_99                            @"product_4_99"				//appId	= 987928637

#pragma mark    NOtification center
#define replyPopup                  @"showReplyPopUpForIndex"
#define Wishback_Actionsheet        @"WishBackToUser"

#pragma mark -	ResponseData Key Name

#define USER_NAME				@"UserName"
#define NAME					@"Name"
#define EMAIL					@"Email"
#define FB_ID					@"FacebookID"
#define USER_ID					@"ID"
#define USER_PHOTO_PATH			@"PhotoPath"
#define DESCRIPTION				@"Description"
#define NOTIF_AUDIO_PATH		@"SoundPath"
#define IS_FRIEND				@"IsFriend"
#define IS_FRND_REQ_REC			@"IsRequestReceive"
#define IS_FRND_REQ_SENT		@"IsRequestSent"
#define IsMsgReadNotifSent      @"IsMsgRead"

#define SENDER_ID				@"SenderID"
#define RECEIVER_ID				@"ReceiverID"
#define NOTIF_ID				@"ID"
#define REQUESTER_ID			@"CreateBy"
#define IS_NOTIF_READ			@"IsRead"
#define GRP_NAME				@"GroupName"
#define GRP_ID					@"ID"
#define GRP_MEMBERS_IDS			@"GroupUserIDs"
#define IS_USER_BLOCKED			@"IsBlock"
#define IS_Follow               @"IsFollow"
#define NOTIF_SENT_BEFORE		@"strDate"
#define NOTIF_Category			@"CName"
#define CATEGORY_PHOTO_PATH		@"LogoPath"
#define SUBCATEGORY_LOGO_PATH	@"LogoPath"
#define IS_CAT_HAS_SUBCATS		@"IsSubMaster"
#define CATEGORY_ID				@"ID"
#define IS_LIKE                 @"IsLike"
#define NEW_YAPEEY_ID           @"ID"
#define IS_PRIVATE              @"IsPrivate"
#define TOTAL_FRIENDS_REQUEST   @"TotalFRCount"
#define TOTAL_ALARM_REQUEST     @"TotalARCount"
#define TOTAL_UNREAD_NOTIF      @"TotalMsgUnReadCount"
#define TOTAL_KEEP_REQUEST      @"TotalKRCount"
#define TOTAL_NOTIF_COUNT       @"TotalCounts"
#define TOTAL_CHANNELS          @"TotalChannels"
#define ImagePath               @"ImagePath"
#define VideoPath               @"VideoPath"
#define CaptionForImage         @"Caption"
#define IS_ADDED_TO_MY_INTEREST @"IsAdded"
#define MAP_LIST_USER_ID        @"UserID"
#define USER_CONVERSATION_ID    @"ConversationID"
#define USER_CONVERSATION_USERID    @"UserID"
#define MESSAGE_CHAT_ID         @"ID"
#define UNREAD_MESSAGE_COUNT    @"UnreadCount"
#define IS_REPORTED_FOR_ABUSE   @"IsAbuse"
#define NOTIF_SUB_CATEGORY      @"SBCName"
#define GROUP_IDs               @"GroupIDs"
#define IsRequestSent           @"IsRequestSent"
#define Grp_PhotoPath           @"PhotoPath"
#define GRP_IMAGE_PATH          @"GroupImage"
#define IS_GRP_ADMIN            @"IsAdmin"
#define Banner_Photo_Path       @"PhotoPath"
#define LOCALNOTIF_RECORDED     @""
#define USERTYPE                @"UserTypeID"
#define IS_PAID                 @"IsPaid"
#define IS_PURCHASED            @"IsPurchase"
#define USER_REMINDER_REQUEST_STATUS    @"StatusType"
#define FULL_DESCRIPTION        @"FullDescription"

#pragma mark -  APNS Payload

#define APNS_CONTENT_ID			@"ContentID"
#define APNS_ID					@"ID"
#define APNS_CONTENT_PATH		@"SoundPath"
#define APNS_TYPE_ID			@"TypeID"
#define APNS_USER_ID			@"UserID"
#define APNS_PAYLOAD_DIC		@"aps"
#define APNS_ALERT_MESSAGE		@"alert"
#define APNS_ALERT_BADGE		@"badge"
#define APNS_ALERT_SOUND_NAME	@"sound"

#pragma mark		Key Name

#define KeyName				@"keyName"
#define KeyValue			@"keyValue"
#define AlbumName           @"Blabeey"
#endif
