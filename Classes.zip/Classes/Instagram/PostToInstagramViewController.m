//
//  PostToInstagramViewController.m
//  InstragramSample
//
//  Created by Neha Sinha on 29/01/14.
//  Copyright (c) 2014 Mindfire Solutions. All rights reserved.

#import "PostToInstagramViewController.h"
#import "ViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>

@interface PostToInstagramViewController ()

@end

@implementation PostToInstagramViewController

#pragma mark -- View Controller life cycle

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void) viewWillAppear:(BOOL)animated
{
    appDelegate.currentVc = self;
    [super viewWillAppear:animated];
    self.title = @"Post Photo";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void) dealloc
{
    _imageView = nil;
}

#pragma mark -- action when Post To Instagram button is clicked

- (IBAction)postToInstagramClicked:(id)sender
{
//    [self shareImageWithInstagram];
    
//    NSURL *url = [NSURL URLWithString:[[NSBundle mainBundle] pathForResource:@"tmpMov" ofType:@"mp4" inDirectory:@""]];
    
//    NSURL *url = [NSURL fileURLWithPath:[[NSBundle mainBundle]
//                                         pathForResource:@"tmpMov" ofType:@"mp4"]];
    
    NSURL*url=[[NSBundle mainBundle] URLForResource:@"tmpMov" withExtension:@"mp4"];
//    NSURL*url=[NSURL fileURLWithPath:thePath];
    
    
    [self loadCameraRollAssetToInstagram:url andMessage:@"Hi"];
}


- (void)loadCameraRollAssetToInstagram:(NSURL*)assetsLibraryURL andMessage:(NSString*)message
{
//    NSString *escapedString   = [assetsLibraryURL.absoluteString urlencodedString];
//    NSString *escapedCaption  = [message urlencodedString];
   
    
    NSURL *instagramURL = [NSURL URLWithString:@"instagram://app"];
    if ([[UIApplication sharedApplication] canOpenURL:instagramURL])
    {
        NSURL *videoFilePath = [NSURL URLWithString:[NSString stringWithFormat:@"%@",assetsLibraryURL]]; // Your local path to the video
//        NSString *caption = @"Some Preloaded Caption";
        ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
        [library writeVideoAtPathToSavedPhotosAlbum:videoFilePath completionBlock:^(NSURL *assetURL, NSError *error) {
//            NSString *escapedString   = [self urlencodedString:videoFilePath.absoluteString];
//            NSString *escapedCaption  = [self urlencodedString:caption];
            NSURL *instagramURL = [NSURL URLWithString:[NSString stringWithFormat:@"instagram://library?AssetPath=%@&InstagramCaption=%@",assetsLibraryURL.absoluteString,message]];
            if ([[UIApplication sharedApplication] canOpenURL:instagramURL]) {
                [[UIApplication sharedApplication] openURL:instagramURL];
            }
        }];
    }
}
/*
- (NSString*)urlencodedString
{
    return [self stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]];
}

- (void) shareImageWithInstagram
{
    NSURL *instagramURL = [NSURL URLWithString:@"instagram://"];
    if ([[UIApplication sharedApplication] canOpenURL:instagramURL])
    {
        NSData* imageData = UIImagePNGRepresentation(_imageView.image);
        NSString* imagePath = [UIUtils documentDirectoryWithSubpath:@"image.igo"];
        [imageData writeToFile:imagePath atomically:NO];
        NSURL* fileURL = [NSURL fileURLWithPath:[NSString stringWithFormat:@"file://%@",imagePath]];
        
        self.docFile = [[self setupControllerWithURL:fileURL usingDelegate:self] retain];
        self.docFile.annotation = [NSDictionary dictionaryWithObject: @"This is a demo caption"
                                                              forKey:@"InstagramCaption"];
        self.docFile.UTI = @"com.instagram.photo";
        
//        NSURL *assetURL;
//        
//        NSURL *instagramURL = [NSURL URLWithString:[NSString stringWithFormat:@"instagram://library?AssetPath=%@&InstagramCaption=%@",[assetURL absoluteString].percentEscape,caption.percentEscape]];
//        if ([[UIApplication sharedApplication] canOpenURL:instagramURL]) {
//            [[UIApplication sharedApplication] openURL:instagramURL];
//        }
        
        // OPEN THE HOOK
        [self.docFile presentOpenInMenuFromRect:self.view.frame inView:self.view animated:YES];
    }
    else
    {
        [UIUtils messageAlert:@"Instagram not installed in this device!\nTo share image please install instagram." title:nil delegate:nil];
    }
}
*/
#pragma mark -- UIDocumentInteractionController delegate

- (UIDocumentInteractionController *) setupControllerWithURL:(NSURL*)fileURL
                                               usingDelegate: (id <UIDocumentInteractionControllerDelegate>) interactionDelegate
{
    UIDocumentInteractionController *interactionController = [UIDocumentInteractionController interactionControllerWithURL: fileURL];
    interactionController.delegate = interactionDelegate;
    
    return interactionController;
}

- (void)documentInteractionControllerWillPresentOpenInMenu:(UIDocumentInteractionController *)controller
{
    NSLog(@"OPEN");
    
    ViewController *obj = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
    [self.navigationController pushViewController:obj animated:YES];
}

@end
