//
//  UserInterestList.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 21/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

//@protocol CategoryListForUploadVCDelegate <NSObject>
//- (void)setCategoryDetail:(NSDictionary *)dic WithRowIndex:(NSString *)strIndex;
//
//@end


@interface UserInterestList : UIViewController <UITableViewDataSource, UITableViewDelegate,UICollectionViewDataSource, UICollectionViewDelegate>



@property (nonatomic, strong) IBOutlet UITableView			*tblData;
@property (nonatomic, strong) IBOutlet UIButton             *btnBack;
@property (nonatomic, strong) NSMutableArray				*arrData;
@property (nonatomic, strong) NSMutableArray				*arrSubCat;

@property (nonatomic, strong) IBOutlet UILabel				*lblTitle;

@property (nonatomic, strong) ASIFormDataRequest			*request;
@property (nonatomic, strong) IBOutlet  UIButton            *btnSave;
@property (nonatomic, strong) IBOutlet  UIButton            *btnSkip;
//@property (nonatomic, strong) UIActivityIndicatorView		*activityLoading;

@property (nonatomic, strong) NSString                      *strShowSkip;

@property (nonatomic, readwrite) BOOL						isShowSubCategories;
@property (nonatomic, readwrite) BOOL						isShowFooter;
@property (nonatomic, readwrite) int						selectedSection;
@property (nonatomic, readwrite) int						selectedRow;
@property (nonatomic, readwrite) int                        pageCounter;
@property (nonatomic, readwrite) BOOL						isDataNull;
@property (nonatomic, assign) BOOL                          isFromRegister;
@property (nonatomic, strong) NSMutableDictionary           *contentOffsetDictionary;
//@property (nonatomic ,assign) id <CategoryListForUploadVCDelegate>       delegate;

//@property (nonatomic, retain) UIImageView                   *imgSelection;


@end
