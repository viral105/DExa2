//
//  ShowiAdsVC.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/21/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowiAdsVC : UIViewController <ADBannerViewDelegate>

@property (nonatomic, strong) ADBannerView	*adBanner;

@end
