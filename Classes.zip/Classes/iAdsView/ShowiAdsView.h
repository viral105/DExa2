//
//  ShowiAdsView.h
//  WWHHAAZZAAPP
//
//  Created by s on 8/21/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowiAdsView : UIView <ADBannerViewDelegate>

@property (nonatomic, strong) ADBannerView	*adBanner;
@property (nonatomic, readwrite) BOOL       isFullScreenAd;
@property (nonatomic, strong) NSString      *notifName;

-(void)showBanner;
-(void)HideBanner;
-(void)setDelegateToAdView;
-(void)cancelCurrentAdFor:(NSString *)NotificationName;
@end
