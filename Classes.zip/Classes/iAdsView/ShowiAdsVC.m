//
//  ShowiAdsVC.m
//  WWHHAAZZAAPP
//
//  Created by s on 8/21/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "ShowiAdsVC.h"

@interface ShowiAdsVC ()

@end

@implementation ShowiAdsVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	self.adBanner = [[ADBannerView alloc] initWithAdType:ADAdTypeBanner];
	self.adBanner.delegate = self;
	[self.view addSubview:self.adBanner];
	self.view.frame = CGRectMake(0, 0,	320, [[UIScreen mainScreen] bounds].size.height);
	[[[UIApplication sharedApplication] keyWindow] addSubview:self.view];
//	[self didMoveToParentViewController:self];
//	[self addChildViewController:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)showBanner{
	[[[UIApplication sharedApplication] keyWindow] addSubview:self.view];
}
-(void)HideBanner{
	[self.view removeFromSuperview];
}

#pragma mark	ADBannerViewDelegate

- (void)bannerViewWillLoadAd:(ADBannerView *)banner{
	NSLog(@"bannerViewWillLoadAd");
	[self.view setHidden:FALSE];
}
- (void)bannerViewDidLoadAd:(ADBannerView *)banner{
	NSLog(@"bannerViewDidLoadAd");
	[self.view setHidden:FALSE];
}
- (void)bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error{
	NSLog(@"didFailToReceiveAdWithError");
	if (!appDelegate.isBannerVisible) {
		[self.view setHidden:TRUE];
	}
}
- (BOOL)bannerViewActionShouldBegin:(ADBannerView *)banner willLeaveApplication:(BOOL)willLeave{
	NSLog(@"willLeaveApplication");
	return  TRUE;
}
- (void)bannerViewActionDidFinish:(ADBannerView *)banner{
	NSLog(@"bannerViewActionDidFinish");
	[self.view setHidden:FALSE];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
