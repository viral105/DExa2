//
//  ShowiAdsView.m
//  WWHHAAZZAAPP
//
//  Created by s on 8/21/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "ShowiAdsView.h"

@implementation ShowiAdsView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
		self.backgroundColor = [UIColor clearColor];
		self.adBanner = [[ADBannerView alloc] initWithAdType:ADAdTypeBanner];
		self.adBanner.delegate = self;
		[self addSubview:self.adBanner];
		self.adBanner.backgroundColor = [UIColor clearColor];
		appDelegate.isBannerVisible = NO;
		//self.frame = CGRectMake(0, 0,	320, [[UIScreen mainScreen] bounds].size.height);
	 }
    return self;
}

-(void)showBanner{
	[[[UIApplication sharedApplication] keyWindow] addSubview:self];
}
-(void)HideBanner{
	//[self removeFromSuperview];
}

-(void)setDelegateToAdView{
	self.adBanner.delegate = self;
	self.backgroundColor = [UIColor clearColor];
}

#pragma mark	ADBannerViewDelegate

- (void)bannerViewWillLoadAd:(ADBannerView *)banner{
	NSLog(@"bannerViewWillLoadAd");
}
- (void)bannerViewDidLoadAd:(ADBannerView *)banner{
	NSLog(@"bannerViewDidLoadAd");
	//here you find it
	appDelegate.isBannerVisible = YES;
	[Validation ResizeViewForAds];
}
- (void)bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error{
	NSLog(@"didFailToReceiveAdWithError");
	if (!appDelegate.isBannerVisible) {
		[Validation ResizeViewForAds];
	}
	
//	if (appDelegate.isBannerVisible) {
//		appDelegate.isBannerVisible = NO;
//		[Validation ResizeViewForAds];
//	}
}
- (BOOL)bannerViewActionShouldBegin:(ADBannerView *)banner willLeaveApplication:(BOOL)willLeave{
    NSLog(@"willLeaveApplication");
    self.isFullScreenAd = TRUE;
    return  TRUE;
}


- (void)bannerViewActionDidFinish:(ADBannerView *)banner{
    NSLog(@"bannerViewActionDidFinish");
    //	if (appDelegate.isBannerVisible) {
    //		appDelegate.isBannerVisible = NO;
    //		[Validation ResizeViewForAds];
    if (self.isFullScreenAd) {
//        self.isFullScreenAd = FALSE;
        [[NSNotificationCenter defaultCenter]
         postNotificationName:self.notifName
         object:nil];
    }
}

-(void)cancelCurrentAdFor:(NSString *)NotificationName{
    self.notifName = NotificationName;
    [self.adBanner cancelBannerViewAction];
}/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
