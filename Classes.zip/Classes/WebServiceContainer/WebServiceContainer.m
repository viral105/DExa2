//
//  WebServiceContainer.m
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "WebServiceContainer.h"
#import "ASINetworkQueue.h"

//#define BASE_URL			@"http://wwhhaazzuupp.com/api/"
#define HEADER_USERNAME_KEY	@"userid"
#define HEADER_PWD_KEY		@"password"

@implementation WebServiceContainer

+(NSString *)getServiceURL:(NSString *)ServiceName withParameters:(NSDictionary *)dicParam{
	
	NSString *strURL = [BASE_URL stringByAppendingFormat:@"%@",ServiceName];
	if (dicParam!=nil) {
		for (int i = 1; i<=[[dicParam allKeys]count]; i++) {
			if (i==1) {
				strURL = [strURL stringByAppendingFormat:@"%@",[dicParam valueForKey:[NSString stringWithFormat:@"param%d",i]]];
			}
			else{
				strURL = [strURL stringByAppendingFormat:@"&%@",[dicParam valueForKey:[NSString stringWithFormat:@"param%d",i]]];
			}
		}
	}
	NSLog(@"strURL = %@",strURL);
	return strURL;
}

+(ASIHTTPRequest *)CallWebserviceWithGet:(NSDictionary *)dic forURL:(NSString *)strURL{
	
	if (![Validation checkInternetConnection]) {
		//[Validation hideLoadingIndicator];

		return nil;
	}
	else{
		ASINetworkQueue *queue = [ASINetworkQueue queue];
		
		// Increase the risk of this crash
		[queue setMaxConcurrentOperationCount:25];
		
		ASIHTTPRequest *request =[ASIHTTPRequest requestWithURL:[NSURL URLWithString:[strURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
		[request addRequestHeader:HEADER_USERNAME_KEY value:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]];
		NSString *strT1 = [Validation GetUTCDate];
		[request addRequestHeader:@"T1" value:strT1];
		[request addRequestHeader:@"T2" value:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE]];

		[queue addOperation:request];
		[queue go];
		return request;
	}
}

+(ASIFormDataRequest *)CallWebserviceWithPost:(NSDictionary *)dic forURL:(NSString *)strURL isAddHeader:(BOOL)isAddHeader{
	
	NSLog(@"CallWebserviceWithPost:");
	//NSLog(@"CallWebserviceWithPost: ------->> Dictionary:\n %@",dic);
	if (![Validation checkInternetConnection]) {
	//	[Validation hideLoadingIndicator];
		return nil;
	}
	else{
		ASINetworkQueue *queue = [ASINetworkQueue queue];
		
		// Increase the risk of this crash
		[queue setMaxConcurrentOperationCount:25];
		ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[strURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
        
		if (isAddHeader) {
			[request addRequestHeader:HEADER_USERNAME_KEY value:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]];
			NSString *strT1 = [Validation GetUTCDate];
			[request addRequestHeader:@"T1" value:strT1];
			[request addRequestHeader:@"T2" value:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE]];
		}

		if (dic != nil) {
			NSArray *arr = [dic allKeys];
			for (int i =0; i<dic.count; i++) {
				NSDictionary *dValue = [dic valueForKey:[NSString stringWithFormat:@"%@",[arr objectAtIndex:i]]];
				if ([[dValue valueForKey:KeyName] isEqualToString:@"ImgData"]) {
					if ([[dValue valueForKey:KeyValue] isKindOfClass:[UIImage class]] ) {
						NSData *data = [Validation compressImage:[dValue valueForKey:KeyValue]];
						[request addData:data withFileName:@"profilePic.jpg" andContentType:@"multipart/form-data" forKey:[dValue valueForKey:KeyName]];
					}
                    else if ([[dValue valueForKey:KeyValue] isKindOfClass:[NSData class]] ) {
                        NSData *data = [dValue valueForKey:KeyValue];
                        [request addData:data withFileName:@"profilePic.jpg" andContentType:@"multipart/form-data" forKey:[dValue valueForKey:KeyName]];
                    }
				}
                else if ([[dValue valueForKey:KeyName] isEqualToString:@"SoundData"]) {
                    NSFileManager *fm = [NSFileManager defaultManager];
                    NSString *strPath = [NSString stringWithFormat:@"%@",[dValue valueForKey:KeyValue]];
                    
                    if ([fm fileExistsAtPath:strPath]) {
                        NSLog(@"file exist");
                    }
					NSMutableData *data = [NSMutableData dataWithContentsOfFile:strPath];
                    [request addData:data withFileName:@"userSound.m4a" andContentType:@"multipart/form-data" forKey:[dValue valueForKey:KeyName]];
				}
                else if ([[dValue valueForKey:KeyName] isEqualToString:@"VideoData"]){
                    //video
                    if ([[dValue valueForKey:KeyValue] isKindOfClass:[NSData class]] ) {
                        NSData *data = [dValue valueForKey:KeyValue];
                        [request addData:data withFileName:@"myVidi.mp4" andContentType:@"multipart/form-data" forKey:[dValue valueForKey:KeyName]];
                    }
                }
				else{
					[request setPostValue:[NSString stringWithFormat:@"%@",[dValue valueForKey:KeyValue]] forKey:[dValue valueForKey:KeyName]];
				}
				dValue = nil;
			}
		}
		[queue addOperation:request];
		[queue go];
		return request;
	}
}

+(ASIFormDataRequest *)CallWebserviceWithPut:(NSDictionary *)dic forURL:(NSString *)strURL isAddHeader:(BOOL)isAddHeader{
	if (![Validation checkInternetConnection]) {
	//	[Validation hideLoadingIndicator];
		return nil;
	}
	else{
//		ASINetworkQueue *queue = [ASINetworkQueue queue];
//		
//		// Increase the risk of this crash
//		[queue setMaxConcurrentOperationCount:25];
		ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[strURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
		[request setRequestMethod:@"PUT"];
		
		if (isAddHeader) {
			[request addRequestHeader:HEADER_USERNAME_KEY value:[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_EMAIL]];
			NSString *strT1 = [Validation GetUTCDate];
			[request addRequestHeader:@"T1" value:strT1];
			[request addRequestHeader:@"T2" value:[Validation getEncryptedTextForString:strT1 isGeneral:FALSE]];
		}
	
		if (dic != nil) {
			NSArray *arr = [dic allKeys];
			for (int i =0; i<dic.count; i++) {
				NSDictionary *dValue = [dic valueForKey:[NSString stringWithFormat:@"%@",[arr objectAtIndex:i]]];
				[request setPostValue:[NSString stringWithFormat:@"%@",[dValue valueForKey:KeyValue]] forKey:[dValue valueForKey:KeyName]];
				dValue = nil;
			}
		}
		
		
//		[queue addOperation:request];
//		[queue go];
		return request;
	}
}


@end
