//
//  WebServiceContainer.h
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WebServiceContainer : NSObject

+(ASIHTTPRequest *)CallWebserviceWithGet:(NSDictionary *)dic forURL:(NSString *)strURL;
+(NSString *)getServiceURL:(NSString *)ServiceName withParameters:(NSDictionary *)dicParam;
+(ASIFormDataRequest *)CallWebserviceWithPost:(NSDictionary *)dic forURL:(NSString *)strURL isAddHeader:(BOOL)isAddHeader;
+(ASIFormDataRequest *)CallWebserviceWithPut:(NSDictionary *)dic forURL:(NSString *)strURL isAddHeader:(BOOL)isAddHeader;

@end
