//
//  RecordAudioForVideoBlabVC.h
//  WWHHAAZZAAPP
//
//  Created by multicore on 5/12/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "UserConversationChatVC.h"
// Import EZAudio header
#import "CreateHBlabVC.h"
#import "GeneralDelegate.h"

#import "ASIFormDataRequest.h"

@interface RecordAudioForVideoBlabVC : UIViewController<AVAudioRecorderDelegate,AVAudioPlayerDelegate,UIAlertViewDelegate,AFNetworkingDataTransactionDelegate>


@property (nonatomic, strong) MPMoviePlayerViewController   *moviePlayer;
@property (nonatomic, strong) AVPlayer *mPlayer;
@property (nonatomic, strong) IBOutlet UIScrollView *scrlView;
@property (nonatomic, strong) IBOutlet UIView *viewMain;
@property (nonatomic, retain) IBOutlet UIButton     *btnRecord;
@property (nonatomic, retain) IBOutlet UIButton     *btnPreview;
@property (nonatomic, retain) IBOutlet UIButton     *btnNext;
@property (nonatomic, strong) IBOutlet UIButton         *btnPlay;

@property (nonatomic, strong) AVAudioPlayer *audioPlayer;

@property (nonatomic, strong) IBOutlet UIView       *viewlbl;
@property (nonatomic, strong) IBOutlet UIView       *viewMasterLbl;
@property (nonatomic, retain) IBOutlet UILabel      *lblTime;
@property (nonatomic,assign) CMTime                 videoDuration;
@property (nonatomic,assign) int                 maxAudioLength;
@property (nonatomic, retain) IBOutlet UILabel      *lblSec;
@property (nonatomic, strong) NSTimer               *timerRecord;
@property (nonatomic, strong) IBOutlet UILabel		*lblTitle;
@property (nonatomic, readwrite) int				timeRemaining;
@property (nonatomic, readwrite) BOOL               isShouldStop;
@property (nonatomic, readwrite) BOOL               isPrivate;
@property (nonatomic, strong) NSString              *strFilePath;
@property (nonatomic, strong) NSArray				*arrSelectedIds;
@property (nonatomic, strong) AFNetworkingDataTransaction		*request;
@property (nonatomic, readwrite) BOOL				isGroupNotif;
@property (nonatomic, readwrite) BOOL				isNotifSendToAll;

@property (nonatomic, strong) NSTimer               *timer;
@property (nonatomic, strong) UIProgressView			*progress;
@property (nonatomic, strong) CreateHBlabVC *childController;
@property (nonatomic, strong) id<GeneralDelegate> delegate;

@end
