//
//  SetVideoAndPrivacyVC.m
//  WWHHAAZZAAPP
//
//  Created by Nivid on 08/04/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "SetVideoAndPrivacyVC.h"
#import "ALAssetsLibrary+CustomPhotoAlbum.h"
#import "PBJViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>

#import "VideoListVC.h"

#import "PBJStrobeView.h"
#import "PBJFocusView.h"

#import "PBJVision.h"
#import "PBJVisionUtilities.h"

#import <GLKit/GLKit.h>


#define TextViewPlaceHolder         @"Add caption"

@interface SetVideoAndPrivacyVC ()

@end

@implementation SetVideoAndPrivacyVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    appDelegate.isRecordingFromCamera = FALSE;
    // Do any additional setup after loading the view.
    self.selectedPrivacy = 2;
    self.selectedTimePeriod = 2;
    appDelegate.FlagVideo=0;
    self.isKeyboardHidden = YES;
    [self LoadViewSetting];
    
    self.library = [[ALAssetsLibrary alloc] init];
    [self.library addAssetsGroupAlbumWithName:AlbumName
                                  resultBlock:^(ALAssetsGroup *group) {
                                      NSLog(@"added album:%@", AlbumName);
                                  }
                                 failureBlock:^(NSError *error) {
                                     NSLog(@"error adding album");
                                 }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    appDelegate.currentVc = self;
    
    if ([self.btnNext isHidden]) {
        self.scrollContainer.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-64);
    }
    else{
        self.scrollContainer.frame = CGRectMake(0, 64, 320, DEVICE_HEIGHT-64-50);
    }
    
    if (self.pickedImg.image != nil && appDelegate.FlagVideo!=1) {
        self.btnNext.hidden = FALSE;
        self.btnPlay.hidden = FALSE;
        [Validation removeAdviewFromSuperView];
        [Validation ResizeViewForAds];
    }
    else{
        self.btnPlay.hidden = TRUE;
        self.btnNext.hidden = TRUE;
        self.pickedImg.image = nil;

        [Validation removeAdviewFromSuperView];
        [self.view addSubview:[Validation sharedBannerView]];
        [Validation ResizeViewForAds];

        if (appDelegate.FlagVideo == 5) {
            appDelegate.isRecordingFromCamera = FALSE;
            VideoListVC *obj = [[VideoListVC alloc]initWithNibName:@"VideoListVC" bundle:nil];
            [self.navigationController pushViewController:obj animated:YES];
        }
    }
}

#pragma mark    Custom Methods

-(void)LoadViewSetting{
    
    self.view.backgroundColor = UIColorFromRGB(0Xefefef);
    
    self.lblTitle.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
    [self.lblTitle setTextColor:UIColorFromRGB(0Xffffff)];
    
    self.lblAddPictureFrom.numberOfLines = 0;
    self.lblAddPictureFrom.text = @"Attach Video From\n\n\n";
    self.lblAddPictureFrom.textColor = UIColorFromRGB(0X616161);
    self.lblAddPictureFrom.font = [UIFont fontWithName:Font_Montserrat_Regular size:15];
    
    self.pickedImg.backgroundColor = UIColorFromRGB(0Xe2e2e2);
    self.pickedImg.image = nil;
    
    self.tv_caption.textColor = UIColorFromRGB(0X757575);
    self.tv_caption.font = [UIFont fontWithName:Font_Montserrat_Regular size:17];
    
    self.tv_caption.text = TextViewPlaceHolder;
    
    self.btnNext.hidden = TRUE;
    self.btnPlay.hidden = TRUE;
    
    self.lblPrivacy.textColor = UIColorFromRGB(0X616161);
    self.lblPrivacy.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    self.lblSetTimePeriod.textColor = UIColorFromRGB(0X616161);
    self.lblSetTimePeriod.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    self.lblRecipientCanOnly.textColor = UIColorFromRGB(0X616161);
    self.lblRecipientCanOnly.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
    
    self.lblCharCounter.font = [UIFont fontWithName:Font_Montserrat_Regular size:10];
    
    [self resetPrivacy];
    [self resetTimePeriod];
    
    if ([[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue]) {
        [self hidePrivacyView];
    }
    else{
        [self showPrivacyView];
        if (self.selectedPrivacy == 1) {
            [self showTimePeriodView];
        }
        else{
            [self.btnPublic setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
            [self hideTimePeriodView];
        }
    }
}

-(IBAction)btnImageOptionClicked:(id)sender{
    
    UIButton *btn = ((UIButton *) sender);
    
    [self.tv_caption resignFirstResponder];
    
    if (btn.tag == 0){
        //camera
       // appDelegate.FlagVideo = 5;

        PBJViewController *obj = [[PBJViewController alloc]init];
        [self.navigationController pushViewController:obj animated:YES];

    }
    else if (btn.tag == 1){
        //library
//        appDelegate.FlagVideo = 10;
        self.picker =[[UIImagePickerController alloc] init];
        self.picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        self.picker.delegate = self;
        self.picker.allowsEditing = YES;
        self.picker.videoMaximumDuration = 15.0f;
        self.picker.mediaTypes =@[(NSString *) kUTTypeMovie];
        
        
        
        [self presentViewController:self.picker animated:YES completion:nil];
    }
}

- (void)SetSelectedImage:(UIImage *)image{
    self.pickedImg.image = image;
    self.btnNext.hidden = FALSE;
    self.btnPlay.hidden = FALSE;
    
    // self.objCustomCamera = nil;
    [self cancelButtonPressed];
}

- (void)cancelButtonPressed{
    self.objCustomCamera.delegate = nil;
    [self.objCustomCamera.view removeFromSuperview];
    [self.objCustomCamera removeFromParentViewController];
    self.objCustomCamera = nil;
}

-(IBAction)btnBackClicked:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)showPrivacyView{
    
    self.viewPrivacyContianer.hidden = FALSE;
    [self.btnPublic setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    self.selectedPrivacy = 2;
}

-(void)hidePrivacyView{
    
    self.viewPrivacyContianer.hidden = TRUE;
    float yStart = self.lblAddPictureFrom.frame.origin.y;
    yStart += self.lblAddPictureFrom.frame.size.height+30;
    
    self.ViewDescriptionContainer.frame = CGRectMake(0, yStart, 320, self.ViewDescriptionContainer.frame.size.height);
    float height = yStart+self.ViewDescriptionContainer.frame.size.height+10;
    self.scrollContainer.contentSize  = CGSizeMake(self.scrollContainer.contentSize.width,  (height <DEVICE_HEIGHT)?DEVICE_HEIGHT:height);
}

-(void)showTimePeriodView{
    
    float yStart = self.viewPrivacyContianer.frame.origin.y;
    yStart += self.viewPrivacyContianer.frame.size.height+20;
    
    
    self.ViewSetTimePeriod.hidden = FALSE;
    [self.btnNever setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
    
    yStart += self.ViewSetTimePeriod.frame.size.height+20;
    
    self.ViewDescriptionContainer.frame = CGRectMake(0, yStart, 320, self.ViewDescriptionContainer.frame.size.height);
    self.scrollContainer.contentSize  = CGSizeMake(self.scrollContainer.contentSize.width, yStart+self.ViewDescriptionContainer.frame.size.height+10);
}

-(void)hideTimePeriodView{
    
    self.ViewSetTimePeriod.hidden = TRUE;
    float yStart = self.viewPrivacyContianer.frame.origin.y;
    yStart += self.viewPrivacyContianer.frame.size.height+20;
    
    self.ViewDescriptionContainer.frame = CGRectMake(0, yStart, 320, self.ViewDescriptionContainer.frame.size.height);
    self.scrollContainer.contentSize  = CGSizeMake(self.scrollContainer.contentSize.width,  yStart+self.ViewDescriptionContainer.frame.size.height+10);
}

-(IBAction)btnPrivacyClicked:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    [self resetPrivacy];
    
    if (btn.tag == 1) {
        [self.btnPrivate setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        self.selectedPrivacy  = 1;
        [self showTimePeriodView];
    }
    else {
        [self.btnPublic setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        self.selectedPrivacy  = 2;
        [self hideTimePeriodView];
    }
}

-(void)resetPrivacy{
    
    [self.btnPrivate setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnPublic setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
}

-(void)resetTimePeriod{
    
    [self.btnOnce setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnNever setTitleColor:UIColorFromRGB(0X8a8a8a) forState:UIControlStateNormal];
    [self.btnNever setTitle:[NSString stringWithFormat:@"Keep but\nnot Share"] forState:UIControlStateNormal];
}

-(IBAction)btnTimePeriodClicked:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    [self resetTimePeriod];
    if (btn.tag == 1) {
        [self.btnOnce setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        self.selectedTimePeriod = 1;
    }
    else {
        [self.btnNever setTitleColor:TWITTER_BLUE_COLOR forState:UIControlStateNormal];
        self.selectedTimePeriod = 2;
    }
}

-(IBAction)btnNextClicked:(id)sender{
    
    NSString *strCaption = [self.tv_caption.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if ([strCaption isEqualToString:TextViewPlaceHolder]) {
        strCaption = @"";
    }
    if (self.pickedImg.image == nil) {
        [Validation showToastMessage:@"Please select picture." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        /*
         public enum MessageKeepStatus
         {
         Once = 1,
         NeverGo = 2
         }
         public enum MessageType
         {
         Sound = 0,
         stickr = 1,
         Video = 2
         }
         */
        [appDelegate.dic_NotificationReleatedData setValue:self.pickedImg.image forKey:CapturedImage];
        [appDelegate.dic_NotificationReleatedData setValue:@"2" forKey:BlabType];
        [appDelegate.dic_NotificationReleatedData setValue:[appDelegate.vedioURL absoluteString] forKey:CapturedVideo];
        [appDelegate.dic_NotificationReleatedData setValue:strCaption forKey:ImageCaption];
        [appDelegate.dic_NotificationReleatedData setValue:(self.selectedPrivacy == 1)?@"false":@"true" forKeyPath:IsPublicImg];
        [appDelegate.dic_NotificationReleatedData setValue:[NSString stringWithFormat:@"%d",self.selectedTimePeriod] forKeyPath:RequestedKeepStatus];
        
        if ([[NSUserDefaults standardUserDefaults] boolForKey:IS_SAVE_TO_GALLERY]) {
            void (^completion)(NSURL *, NSError *) = ^(NSURL *assetURL, NSError *error) {
                if (error) {
                    NSLog(@"%s: Write the image data to the assets library (camera roll): %@",
                          __PRETTY_FUNCTION__, [error localizedDescription]);
                }
                
                NSLog(@"%s: Save image with asset url %@ (absolute path: %@), type: %@", __PRETTY_FUNCTION__,
                      assetURL, [assetURL absoluteString], [assetURL class]);
                
            };
            
            void (^failure)(NSError *) = ^(NSError *error) {
                if (error) NSLog(@"%s: Failed to add the asset to the custom photo album: %@",
                                 __PRETTY_FUNCTION__, [error localizedDescription]);
            };
            
            [self.library saveVideo:appDelegate.vedioURL
                            toAlbum:AlbumName
                         completion:completion
                            failure:failure];
            
        }
        
        [self performSegueWithIdentifier:RECORD_OPTION_VC sender:nil];
    }
}

-(IBAction)btnPlayClicked:(id)sender{
    NSString *strPath = [appDelegate.vedioURL absoluteString];

    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
    self.theMoviPlayer = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL fileURLWithPath:strPath]];
    // Register this class as an observer instead
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(movieFinishedCallback:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:self.theMoviPlayer];
    [self.theMoviPlayer.view setFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    [self.navigationController presentMoviePlayerViewControllerAnimated:self.theMoviPlayer];
    
    [self.theMoviPlayer.moviePlayer prepareToPlay];
    [self.theMoviPlayer.moviePlayer play];
}

- (void)movieFinishedCallback:(NSNotification*)aNotification
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    [self.theMoviPlayer.moviePlayer stop];
    [self.navigationController dismissMoviePlayerViewControllerAnimated];
    self.theMoviPlayer = nil;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [[event allTouches] anyObject];
    if (![touch.view isKindOfClass:[UITextView class]]) {
        if (self.isKeyboardHidden == NO) {
            [self.tv_caption resignFirstResponder];
            self.isKeyboardHidden = YES;
        }
    }
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView == self.scrollContainer) {
        if (self.isKeyboardHidden == NO) {
            self.isKeyboardHidden = YES;
            
            [self.tv_caption resignFirstResponder];
        }
    }
}
-(void)textViewDidBeginEditing:(UITextView *)textView{
    
    self.scrollContainer.contentSize = CGSizeMake(self.scrollContainer.contentSize.width, self.ViewDescriptionContainer.frame.origin.y+self.ViewDescriptionContainer.frame.size.height+10+216);
    
    
    float ver = [[[UIDevice currentDevice] systemVersion] floatValue];
    
    if (ver >= 8.0) {
        self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, self.scrollContainer.contentOffset.y+216+45);
    }
    else{
        self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, self.scrollContainer.contentOffset.y+216);
        
    }
    
    if ([textView.text isEqualToString:TextViewPlaceHolder]) {
        textView.text = @"";
    }
    
    self.lblCharCounter.text = [NSString stringWithFormat:@"%d/100",(int)(textView.text.length)];
    
    self.isKeyboardHidden = NO;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    
    if ([text isEqualToString:@"\n"]) {
        self.isKeyboardHidden = NO;
        [textView resignFirstResponder];
        self.scrollContainer.contentOffset = CGPointMake(self.scrollContainer.contentOffset.x, 0);
        return FALSE;
    }
    else if ([text isEqualToString:@""]){
        if (textView.text.length == 0) {
            return FALSE;
        }
        
        self.lblCharCounter.text = [NSString stringWithFormat:@"%d/100",(int)(textView.text.length-1)];
        return TRUE;
    }
    else if ([text isEqualToString:@" "]){
        if (textView.text.length == 0) {
            return FALSE;
        }
        else if ((textView.text.length+1)>100) {
            return FALSE;
        }
    }
    else if ((textView.text.length+1)>100) {
        return FALSE;
        
    }
    self.lblCharCounter.text = [NSString stringWithFormat:@"%d/100",(int)(textView.text.length+1)];
    return TRUE;
}

- (void)textViewDidEndEditing:(UITextView *)textView{
    if ([DataValidation checkNullString:textView.text].length == 0) {
        self.tv_caption.text = TextViewPlaceHolder;
        if ([textView.text isEqualToString:TextViewPlaceHolder]) {
            self.lblCharCounter.text = [NSString stringWithFormat:@"0/100"];
        }
        else{
            self.lblCharCounter.text = [NSString stringWithFormat:@"%d/100",(int)(textView.text.length-1)];
        }
    }
    self.scrollContainer.contentSize  = CGSizeMake(self.scrollContainer.contentSize.width,  self.ViewDescriptionContainer.frame.origin.y+self.ViewDescriptionContainer.frame.size.height+10);
    [self.scrollContainer setContentOffset:CGPointZero animated:NO];
}

-(IBAction)btnHelpVideo_Clicked:(id)sender{
    self.viewVideoContainer.hidden = NO;
    self.moviePlayer = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:@"http://upload.blabeey.com//HelpVideo/XEIGHASK11420539_Video_1.mp4"]];
    
    self.moviePlayer.moviePlayer.shouldAutoplay = YES;
    
    [self.moviePlayer.moviePlayer prepareToPlay];
    
    self.moviePlayer.view.frame = CGRectMake(0, 0, DEVICE_WIDTH, DEVICE_HEIGHT);
    self.moviePlayer.moviePlayer.controlStyle = MPMovieControlStyleNone;
    
    [self.moviePlayer.moviePlayer play];
    self.moviePlayer.moviePlayer.scalingMode = MPMovieScalingModeAspectFit;
    [self.viewVideoContainer addSubview:self.moviePlayer.view];
    [self.viewVideoContainer bringSubviewToFront:self.btnClose];
    [self.view bringSubviewToFront:self.viewVideoContainer];
}
-(IBAction)btnCloseVideo_Clicked:(id)sender{
    if (self.moviePlayer) {
        [self.moviePlayer.moviePlayer stop];
        [self.moviePlayer.view removeFromSuperview];
        self.moviePlayer = nil;
    }
    self.viewVideoContainer.hidden = YES;
}

# pragma mark -
# pragma mark GKImagePicker Delegate Methods

- (UIImage *)fixrotation:(UIImage *)image{
    
    if (image.imageOrientation == UIImageOrientationUp) return image;
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    switch (image.imageOrientation) {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.width, image.size.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.width, 0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, image.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationUpMirrored:
            break;
    }
    
    switch (image.imageOrientation) {
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.width, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
            
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.height, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationDown:
        case UIImageOrientationLeft:
        case UIImageOrientationRight:
            break;
    }
    
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, image.size.width, image.size.height,
                                             CGImageGetBitsPerComponent(image.CGImage), 0,
                                             CGImageGetColorSpace(image.CGImage),
                                             CGImageGetBitmapInfo(image.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (image.imageOrientation) {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,image.size.height,image.size.width), image.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,image.size.width,image.size.height), image.CGImage);
            break;
    }
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
}

#pragma mark    UIImagePickerDelegate

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
   
    NSString *type = [info objectForKey:UIImagePickerControllerMediaType];

    if ([type isEqualToString:(NSString *)kUTTypeVideo] || [type isEqualToString:(NSString *)kUTTypeMovie]){
        
        // movie != video
        
        self.pickedImg.image = nil;
        
        AVAsset *myAsset = [[AVURLAsset alloc] initWithURL:[info objectForKey:UIImagePickerControllerMediaURL] options:nil];
        AVAssetTrack *VideoTrack = [[myAsset tracksWithMediaType:AVMediaTypeVideo] lastObject];
        
        CMTime duration = myAsset.duration;
        
        NSLog(@"CMTimeGetSeconds(duration) %f",CMTimeGetSeconds(duration));
        
        if (CMTimeGetSeconds(duration) <3.0) {
            [picker dismissViewControllerAnimated:YES completion:NULL];
            [self performSelector:@selector(showRecordSecondsAlert:) withObject:@"1" afterDelay:1];
        }
        else if (CMTimeGetSeconds(duration) >300.0) {
            [picker dismissViewControllerAnimated:YES completion:NULL];
            [self performSelector:@selector(showRecordSecondsAlert:) withObject:@"2" afterDelay:1];
        }
        else{
            appDelegate.vedioURL = [info objectForKey:UIImagePickerControllerMediaURL];
            
            NSData *videoData = [NSData dataWithContentsOfURL:appDelegate.vedioURL ];
            
            NSFileManager *fm = [NSFileManager defaultManager];
            
            if (![fm fileExistsAtPath:VIDEO_RECORDING_FOLDER]){
                
                [fm createDirectoryAtPath:VIDEO_RECORDING_FOLDER
              withIntermediateDirectories:YES
                               attributes:nil
                                    error:NULL];
            }
            
            NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
            
            BOOL success = [videoData writeToFile:tempPath atomically:NO];
            NSLog(@"success=%d",success);
            
            
            
            CGAffineTransform txf = [VideoTrack preferredTransform];
            appDelegate.videoPrefferedTransform = txf;
            
            UIImage *img = [self generateThumbImage:[NSURL fileURLWithPath:tempPath]];
            
            
            UIImageOrientation oldOrientation = img.imageOrientation;
            switch (oldOrientation) {
                case UIImageOrientationUp:{
                    NSLog(@"UIImageOrientationUp"); //-1
                    //newOrientation = UIImageOrientationRight;
                }
                    break;
                case UIImageOrientationLeft:{
                    NSLog(@"UIImageOrientationLeft");
                    //newOrientation = UIImageOrientationDown;
                }
                    break;
                case UIImageOrientationDown:{
                    NSLog(@"UIImageOrientationDown");
                    //            newOrientation = UIImageOrientationLandscapeRight;
                }
                    break;
                case UIImageOrientationRight:{
                    NSLog(@"UIImageOrientationRight");
                    //          newOrientation = UIImageOrientationUp;
                }
                    break;
                case  UIImageOrientationUpMirrored:{
                    NSLog(@"UIImageOrientationUpMirrored");
                }
                    break;
                case UIImageOrientationDownMirrored:{
                    NSLog(@"UIImageOrientationDownMirrored");
                }
                    break;
                case UIImageOrientationLeftMirrored:{
                    NSLog(@"UIImageOrientationLeftMirrored");
                }
                    break;
                case UIImageOrientationRightMirrored:{
                    NSLog(@"UIImageOrientationRightMirrored:");
                }
                    break;
                    // you can also handle mirrored orientations similarly ...
            }
            NSLog(@"%f",txf.a);
            appDelegate.videoPrefferedTransform = txf;
            appDelegate.FlagVideo=5;
            [picker dismissViewControllerAnimated:YES completion:NULL];

            
        }
    }
}

-(void)showRecordSecondsAlert:(NSString *)str{
    if ([str isEqualToString:@"1"]) {
        [Validation showToastMessage:@"Your video should be atleast 3seconds." displayDuration:ERROR_MSG_DURATION];
    }
    else{
        [Validation showToastMessage:@"Selected video is too big.\nPlease select video having length less than 5 minutes." displayDuration:INFO_MSG_DURATION];
    }
}

-(UIImage *)generateThumbImage : (NSURL *)url
{
    AVAsset *asset = [AVAsset assetWithURL:url];
    AVAssetImageGenerator *imageGenerator = [[AVAssetImageGenerator alloc]initWithAsset:asset];
    CMTime time = CMTimeMakeWithSeconds(0,1);
    CGImageRef imageRef = [imageGenerator copyCGImageAtTime:time actualTime:NULL error:NULL];
    UIImage *thumbnail = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);  // CGImageRef won't be released by ARC
    return thumbnail;
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:NULL];
}
//bhavik 13-Feb-2015
#pragma mark - Photo Selected Status bar Color not Change

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
