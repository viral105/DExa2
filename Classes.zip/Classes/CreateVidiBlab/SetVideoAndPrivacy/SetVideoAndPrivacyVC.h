//
//  SetVideoAndPrivacyVC.h
//  WWHHAAZZAAPP
//
//  Created by Nivid on 08/04/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GKImagePicker.h"
#import "CustomCameraVC.h"
#import "AppDelegate.h"
#import <AssetsLibrary/AssetsLibrary.h>

@interface SetVideoAndPrivacyVC : UIViewController<UITextViewDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIActionSheetDelegate,GKImagePickerDelegate,CustomCameraVCDelegate>
@property (nonatomic, strong) IBOutlet UIScrollView     *scrollContainer;


@property (nonatomic, strong) IBOutlet UIImageView      *pickedImg;
@property (nonatomic, strong) IBOutlet UIButton         *btnNext;
@property (nonatomic, retain) IBOutlet UILabel          *lblAddPictureFrom;
@property (nonatomic, strong) IBOutlet UILabel          *lblTitle;
//@property (nonatomic, strong) GKImagePicker      x       *picker;
@property (nonatomic, strong) UIImagePickerController             *picker;
@property (nonatomic, strong) IBOutlet UIButton             *btnHelpVideo;

//Add description
@property (nonatomic, retain) IBOutlet UIView           *ViewDescriptionContainer;
@property (nonatomic, strong) IBOutlet UITextView       *tv_caption;
@property (nonatomic, strong) IBOutlet UILabel          *lblCharCounter;

//Privacy
@property (nonatomic, strong) IBOutlet UIView           *viewPrivacyContianer;
@property (nonatomic, retain) IBOutlet UILabel          *lblPrivacy;
@property (nonatomic, strong) IBOutlet UIButton         *btnPrivate;
@property (nonatomic, strong) IBOutlet UIButton         *btnPublic;

//Set Time Period
@property (nonatomic, retain) IBOutlet UIView           *ViewSetTimePeriod;
@property (nonatomic, retain) IBOutlet UILabel          *lblSetTimePeriod;
@property (nonatomic, retain) IBOutlet UILabel          *lblRecipientCanOnly;
@property (nonatomic, strong) IBOutlet UIButton         *btnOnce;
@property (nonatomic, strong) IBOutlet UIButton         *btnNever;


@property (nonatomic, readwrite) int                    selectedPrivacy;
@property (nonatomic, readwrite) int                    selectedTimePeriod;

@property (nonatomic, readwrite) BOOL                   isKeyboardHidden;

@property (nonatomic, strong) CustomCameraVC            *objCustomCamera;

@property (nonatomic, strong) IBOutlet UIButton         *btnPlay;
@property (strong,nonatomic) MPMoviePlayerViewController    *theMoviPlayer;
@property (strong, atomic) ALAssetsLibrary* library;

@property (nonatomic, strong) IBOutlet UIView *viewVideoContainer;
@property (nonatomic, strong) IBOutlet UIButton *btnClose;
@property (nonatomic,strong)MPMoviePlayerViewController *moviePlayer;

@end
