//
//  RecordAudioForVideoBlabVC.m
//  WWHHAAZZAAPP
//
//  Created by multicore on 5/12/15.
//  Copyright (c) 2015 s. All rights reserved.
//

#import "RecordAudioForVideoBlabVC.h"
#import "IQAudioRecorderController.h"

@interface RecordAudioForVideoBlabVC ()<MBProgressHUDDelegate,IQAudioRecorderControllerDelegate>{
    IQAudioRecorderController *objIQRecorder;
    MBProgressHUD *HUD;
    BOOL isVideoPlaying;
}
@property (nonatomic,strong)IQAudioRecorderController *objIQRecorder;
@end

@implementation RecordAudioForVideoBlabVC
@synthesize objIQRecorder;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSArray *array = [self.navigationController viewControllers];
    for (int i=0;i<array.count;i++) {
        if ([[array objectAtIndex:i] isKindOfClass:[CreateHBlabVC class]]) {
            NSLog(@"going in loop");
            self.childController = [array objectAtIndex:i];
            self.delegate = self.childController;
        }
        
    }
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    
    [self LoadViewSetting];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    if (!Validation.adView.isFullScreenAd) {
        
        NSLog(@"adview is not full screen");
    }
    
    [self setVideoDurationLblTime];
    self.btnPlay.hidden =YES;
    NSLog(@"viewWillAppear");
    
    appDelegate.currentVc = self;
    
    [self.scrlView setScrollEnabled:YES];
    [Validation removeAdviewFromSuperView];
    [self.view addSubview:[Validation sharedBannerView]];
    [Validation ResizeViewForAds];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)LoadViewSetting{
    
    self.view.backgroundColor = UIColorFromRGB(0Xffffff);
    
    NSString *strPath = [appDelegate.dic_NotificationReleatedData valueForKey:CapturedVideo];
    
    AVAsset *myAsset = [[AVURLAsset alloc] initWithURL:[NSURL fileURLWithPath:strPath] options:nil];
    self.videoDuration = myAsset.duration;
    myAsset = nil;

    //bhavik 12-Oct-2015
    
    [self.viewlbl setAlpha:0.5]; //0.7
    self.viewlbl.backgroundColor = UIColorFromRGB(0X00c2d9);
    self.viewlbl.layer.cornerRadius = 5;
    self.viewlbl.layer.masksToBounds = YES;
    
    self.viewMasterLbl.backgroundColor = [UIColor clearColor];
    
    [self setVideoDurationLblTime];
    
    [self playVideo:strPath isMute:YES isInitialPlaying:YES];

    
    // Create a new Player, and set the player to use the player item
    // with the muted audio mix
//    AVPlayer *player = [AVPlayer playerWithPlayerItem:playerItem];
//    
//    self.mPlayer = player;
//    
//    [self.mPlayer play];

    
    self.objIQRecorder = [[IQAudioRecorderController alloc]  init];
    self.objIQRecorder.delegate = self;
    self.objIQRecorder.isFromBlabover = YES;
    self.objIQRecorder.videoDuration = CMTimeGetSeconds(self.videoDuration);
    CGRect frame = CGRectMake(10, 340, 300, 100);
    self.objIQRecorder.view.frame = frame;
    [self.objIQRecorder willMoveToParentViewController:self];
    [self.viewMain addSubview:self.objIQRecorder.view];
    [self.viewMain sendSubviewToBack:self.objIQRecorder.view];
    [self addChildViewController:self.objIQRecorder];
    [self.objIQRecorder didMoveToParentViewController:self];
}
-(void)playVideo:(NSString *)strPath isMute:(BOOL)isMute isInitialPlaying:(BOOL)isInitialPlaying{
    
    
    AVURLAsset * asset = [AVURLAsset URLAssetWithURL:[NSURL fileURLWithPath:strPath] options:nil];
    AVPlayerItem *playerItem =[[AVPlayerItem alloc]initWithAsset:asset];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(itemDidFinishPlaying:) name:AVPlayerItemDidPlayToEndTimeNotification object:playerItem];

    
    NSLog(@"%f",CMTimeGetSeconds(asset.duration));
    
    //    [playerItem setAudioMix:audioZeroMix];
    
    if (self.mPlayer) {
        self.mPlayer = nil;
    }
    
    self.mPlayer = [[AVPlayer alloc]initWithPlayerItem:playerItem];
    if (isMute) {
        [self.mPlayer setVolume:0.0f];
    }
    else{
        [self.mPlayer setVolume:1.0f];
    }
    AVPlayerLayer *avPlayerLayer =[AVPlayerLayer playerLayerWithPlayer:self.mPlayer];
    [avPlayerLayer setFrame:CGRectMake(0, 0, DEVICE_WIDTH, 320)];
//    [self.viewMain.layer insertSublayer:avPlayerLayer below:self.viewlbl.layer];
    //bhavik 12-Oct-2015
    [self.viewMain.layer insertSublayer:avPlayerLayer below:self.viewMasterLbl.layer];

    [self.mPlayer seekToTime:kCMTimeZero];
    if (!isInitialPlaying) {
        [self.mPlayer play];
    }
    
    playerItem = nil;
}
-(void)itemDidFinishPlaying:(NSNotification *) notification {
    self.btnPlay.hidden = NO;
}
-(void)setVideoDurationLblTime{
    float totalSeconds = CMTimeGetSeconds(self.videoDuration);
    int min = (int)totalSeconds/60;
    int sec = (int)totalSeconds % 60;
    self.lblTime.text = [NSString stringWithFormat:@"%d:",min];
    if (totalSeconds<9.5) {
        self.lblTime.text = [self.lblTime.text stringByAppendingFormat:@"0%d",sec];
        self.maxAudioLength = sec;
    }
    else if (totalSeconds>9.3 && totalSeconds<totalRecordingDuration){
        self.lblTime.text = [self.lblTime.text stringByAppendingString:@"10"];
        self.maxAudioLength = 10;
    }
    else{
        self.lblTime.text = [self.lblTime.text stringByAppendingFormat:@"%d",sec];
        self.maxAudioLength = sec;
    }
    NSLog(@"self.maxAudioLength %d",self.maxAudioLength);
}

#pragma mark IQAudioRecorderControllerDelegate

-(void)updateRemainingTimeLabel:(NSString*)str{
    if (!self.btnPlay.isHidden) {
        self.btnPlay.hidden = YES;
    }

    if (!isVideoPlaying) {
        
        NSLog(@"still going here");

        isVideoPlaying = YES;
        [self playVideo:[appDelegate.dic_NotificationReleatedData valueForKey:CapturedVideo] isMute:YES isInitialPlaying:NO];
    }
 
    if ([str intValue]==0 && self.maxAudioLength==10) {
        self.lblTime.text = [NSString stringWithFormat:@"0:%d",self.maxAudioLength-[str intValue]];
    }
    else{
        self.lblTime.text = [NSString stringWithFormat:@"0:0%d",self.maxAudioLength-[str intValue]];
    }
    NSLog(@"self.lblTime.text %@",self.lblTime.text);
}
-(void)checkForIsAudioPlaying{
    if( self.audioPlayer )
    {
        if( self.audioPlayer.playing)
        {
            [self.audioPlayer stop];
        }
        self.audioPlayer.delegate = nil;
        self.audioPlayer = nil;
        [self.btnPreview setTitle:@"Preview" forState:UIControlStateNormal];
    }
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 1) {
        //recording finished
        [HUD show:YES];
        [self mergeRecording_AudioFileAtPath:self.strFilePath];

    }
}
-(void)audioRecorderController:(IQAudioRecorderController *)controller didFinishWithAudioAtPath:(NSString *)filePath
{
    if (self.mPlayer) {
        [self.mPlayer pause];
    }
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [session setActive:NO error:nil];
    BOOL success = [session setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionMixWithOthers|AVAudioSessionCategoryOptionDefaultToSpeaker error:nil];
    if (!success) {
        NSLog(@"setCategoryError");
    }
    
    isVideoPlaying = NO;
    
    self.strFilePath = filePath;
    
    [AlertHandler alertTitle:MESSAGE message:@"Recording over" delegate:self tag:1 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
    
        //    buttonPlayAudio.enabled = YES;
}

-(void)audioRecorderControllerDidCancel:(IQAudioRecorderController *)controller
{
    //    buttonPlayAudio.enabled = NO;
}
#pragma mark Merge Audio and Video

-(void)mergeRecording_AudioFileAtPath:(NSString *)strAudioPath{
    
    AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
    // 2 - Video track
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSURL* sourceMovieURL = [NSURL fileURLWithPath:[appDelegate.dic_NotificationReleatedData valueForKey:CapturedVideo]];
    NSError *error = nil;
    //------ create Audio and Video Assets
    
    AVURLAsset *VideoAsset = [[AVURLAsset alloc]initWithURL:sourceMovieURL options:nil];
    AVURLAsset* audioAsset = [[AVURLAsset alloc]initWithURL:[NSURL fileURLWithPath:strAudioPath] options:nil];
    
    //------
    
    //1 ---- add external audio - Soundtrack
    
    AVMutableCompositionTrack *AudioOfSoundTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
    
    [AudioOfSoundTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, VideoAsset.duration) ofTrack:([audioAsset tracksWithMediaType:AVMediaTypeAudio].count > 0)?[[audioAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
    //------
    
    //2 ---- video
    
    AVMutableCompositionTrack *VideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo preferredTrackID:kCMPersistentTrackID_Invalid];
    
    [VideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, VideoAsset.duration)
                        ofTrack:([VideoAsset tracksWithMediaType:AVMediaTypeVideo].count >0)?[[VideoAsset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
    //------
    
    //    //3	----- url of first path - audio of video
    //    AVMutableCompositionTrack *VideoAudioTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
    //
    //    [VideoAudioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, VideoAsset.duration) ofTrack:([VideoAsset tracksWithMediaType:AVMediaTypeAudio].count > 0)?[[VideoAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]:nil atTime:kCMTimeZero error:&error];
    //-------
    
    //---- ------- ------- ------- ------
    //----
    AVMutableVideoCompositionInstruction *instruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
    instruction.timeRange = CMTimeRangeMake(kCMTimeZero, [mixComposition duration]);
    AVAssetTrack *videoTrack = [[mixComposition tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
    AVMutableVideoCompositionLayerInstruction* layerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoTrack];
    
    instruction.layerInstructions = [NSArray arrayWithObject:layerInstruction];
    
    //---- ------- ------- ------- ------
    
    AVAssetExportSession* _assetExport = [[AVAssetExportSession alloc] initWithAsset:mixComposition presetName:AVAssetExportPresetMediumQuality];
    
    NSString *strPath = [VIDEO_RECORDING_FOLDER stringByAppendingPathComponent:@"newMergedMovie111.mp4"];
    
    if ([fileManager fileExistsAtPath:strPath]) {
        [fileManager removeItemAtPath:strPath error:nil];
    }
    
    NSURL *exportURL = [NSURL fileURLWithPath:strPath];
    _assetExport.outputURL = exportURL;
    _assetExport.shouldOptimizeForNetworkUse = YES;
    _assetExport.outputFileType = @"com.apple.quicktime-movie";
    
    [_assetExport exportAsynchronouslyWithCompletionHandler:^{
        switch ([ _assetExport status]) {
                
            case AVAssetExportSessionStatusFailed:{
                [HUD hide:YES];
                [Validation showToastMessage:@"merging failed" displayDuration:SUCCESS_MSG_DURATION];
            }
                break;
            case AVAssetExportSessionStatusCancelled:{
                [HUD hide:YES];
                [Validation showToastMessage:@"merging cancelled" displayDuration:SUCCESS_MSG_DURATION];
            }
                break;
            case AVAssetExportSessionStatusCompleted:{
                // [HUD hide:YES];
//                [appDelegate.dic_NotificationReleatedData setValue:strPath forKey:CapturedVideo];
                [self mergeComplete];
            }
                break;
            default:{
                [HUD hide:YES];
            }
                break;
        }
    }];
}

-(void)mergeComplete{
    dispatch_sync(dispatch_get_main_queue(), ^{
        [HUD hide:YES];
        self.btnPlay.hidden = NO;
        [self setVideoDurationLblTime];
        NSLog(@"done merge");
//        [self sendNotifMsgAtIndexForVidiBlabAtIndex];
    });
}
#pragma mark IBAction Methods
-(IBAction)btnPlay_Clicked:(id)sender{
    self.btnPlay.hidden = YES;
    NSString *strPath;
    if ([[NSFileManager defaultManager] fileExistsAtPath:[VIDEO_RECORDING_FOLDER stringByAppendingPathComponent:@"newMergedMovie111.mp4"]]) {
        strPath = [VIDEO_RECORDING_FOLDER stringByAppendingPathComponent:@"newMergedMovie111.mp4"];
        [self playVideo:strPath isMute:NO isInitialPlaying:NO];
    }
    else{
        strPath = [appDelegate.dic_NotificationReleatedData valueForKey:CapturedVideo];
        [self playVideo:strPath isMute:YES isInitialPlaying:NO];
    }
    
}
-(IBAction)btnBack_Clicked:(id)sender{
    NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingPathComponent:@"newMergedMovie111.mp4"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
        [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
    }
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnSend_Clicked:(id)sender{
    if (self.mPlayer) {
        [self.mPlayer pause];
        //        [self.moviePlayer.view removeFromSuperview];
        //        self.moviePlayer = nil;
    }
    if ([[NSFileManager defaultManager] fileExistsAtPath:[VIDEO_RECORDING_FOLDER stringByAppendingPathComponent:@"newMergedMovie111.mp4"]]) {
        [appDelegate.dic_NotificationReleatedData setValue:[VIDEO_RECORDING_FOLDER stringByAppendingPathComponent:@"newMergedMovie111.mp4"] forKey:CapturedVideo];
        [self sendNotifMsgAtIndexForVidiBlabAtIndex];
    }
    else{
        [Validation showToastMessage:@"Please record audio before you proceed" displayDuration:INFO_MSG_DURATION];
    }
}

#pragma mark After Web Service Call
-(void)popToCreateHBlab{
    
    //    [Validation cleanNotifcationRelatedDicData];
    
    [HUD hide:YES];
    
    //    self.isNotifSentMsgVisible = NO;
    //    [self.request CancleOngoingRequest];
    //    self.request = nil;
    
    NSArray *arr = [self.navigationController viewControllers];
    //    BOOL isGotPopViewController = FALSE;
    
    
    //    [self removeFilesFromDir];
    
    for (UIViewController *v in arr) {
        
        if ([v isKindOfClass:[CreateHBlabVC class]]) {
            [self.navigationController popToViewController:v animated:YES];
            break;
        }
    }
    
}
-(void)popToNotifListScreen:(NSNumber*)isBlabSendFail{
    
    [Validation cleanNotifcationRelatedDicData];
    
    [HUD hide:YES];
    
//    self.isNotifSentMsgVisible = NO;
    [self.request CancleOngoingRequest];
    self.request = nil;
    
    NSArray *arr = [self.navigationController viewControllers];
    BOOL isGotPopViewController = FALSE;
    
    
    [self removeFilesFromDir];
    
    for (UIViewController *v in arr) {
        if ([v isKindOfClass:[UserConversationChatVC class]]) {
            isGotPopViewController = TRUE;
            [self.navigationController popToViewController:v animated:YES];
            break;
        }
    }
    
    
    if (!isGotPopViewController) {
        
        [self removeViewControllersFromStack];
        
        if (appDelegate.selectedMenuIndex>0) {
            appDelegate.selectedMenuIndex = 0;
        }
        SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
        
        [UIView transitionWithView:self.navigationController.view
                          duration:0.5
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.navigationController pushViewController:ivc animated:NO];
                        }
                        completion:nil];
    }
    
}
-(void)removeViewControllersFromStack{
    //   NSArray *arrVC = self.navigationController.viewControllers;
    for (id vc in self.navigationController.viewControllers){
        if ([vc isKindOfClass:[FavoritesVC class]]) {
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[SearchFriendVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[OtherFriendNotifListVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[SettingsVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[CategoryListForUploadVC class]]){
            [self removeFromNavigationController:vc animated:NO];
        }
        else if ([vc isKindOfClass:[GroupListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[UserListVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
        else if ([vc isKindOfClass:[RecordingOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO ];
        }
    }
    
}
-(void)removeFromNavigationController:(UIViewController *)controller animated:(BOOL)animated {
    
    NSMutableArray *allViewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];;
    [allViewControllers removeObjectIdenticalTo:controller];
    self.navigationController.viewControllers = allViewControllers;
    
}
-(void)removeFilesFromDir{
    NSError *error = nil;
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *arrPath = [fm contentsOfDirectoryAtPath:VIDEO_RECORDING_FOLDER error:&error];
    for (int i=0; i<arrPath.count; i++) {
        [fm removeItemAtPath:[VIDEO_RECORDING_FOLDER stringByAppendingPathComponent:[arrPath objectAtIndex:i]] error:&error];
    }
}
#pragma mark Web Service Call

-(void)sendNotifMsgAtIndexForVidiBlabAtIndex{
    
    NSArray *arrSelectedIds = [NSArray arrayWithArray:(NSArray *)[appDelegate.dic_NotificationReleatedData valueForKey:SelectedIds]];
    BOOL isGroupNotif = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_GroupNotif] boolValue];
    //   BOOL isNotifSendToAll = [[appDelegate.dic_NotificationReleatedData valueForKey:IS_NotifSendToAll] boolValue];
    NSString *strCaption = [NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:ImageCaption]];
    
    NSString *strPath = [appDelegate.dic_NotificationReleatedData valueForKey:CapturedVideo];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    
    if ([fm fileExistsAtPath:strPath]) {
        NSLog(@"file exist");
    }
    NSMutableData *data;
    if(![self.delegate respondsToSelector:@selector(passBlabDataForHBlab:)]) {
        
         data = [NSMutableData dataWithContentsOfFile:strPath];
    }
    
    [HUD show:YES];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"SenderID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:(isGroupNotif)?@"":[NSString stringWithFormat:@"%@",[arrSelectedIds componentsJoinedByString:@"|"]],KeyValue,@"ReceiverIDs",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"Ctype",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:(isGroupNotif)?[NSString stringWithFormat:@"%@",[arrSelectedIds componentsJoinedByString:@"|"]]:@"0",KeyValue,@"GroupIDs",KeyName, nil],@"4",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"SubCatID",KeyName, nil],@"5",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"0",KeyValue,@"ID",KeyName, nil],@"6",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",(self.isNotifSendToAll)?@"true":@"false"],KeyValue,@"AllFriend",KeyName, nil],@"7",
                         [NSDictionary dictionaryWithObjectsAndKeys:((data!= nil)?data:@""),KeyValue,@"VideoData",KeyName, nil],@"8",
                         [NSDictionary dictionaryWithObjectsAndKeys:([DataValidation checkNullString:strCaption].length > 0)?strCaption:@"",KeyValue,@"Caption",KeyName, nil],@"9",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:IsPublicImg]],KeyValue, IsPublicImg,KeyName, nil],@"10",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:RequestedKeepStatus]],KeyValue, RequestedKeepStatus, KeyName, nil],@"11",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[appDelegate.dic_NotificationReleatedData valueForKey:BlabType]],KeyValue, BlabType, KeyName, nil],@"12",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue, @"OS", KeyName, nil],@"13",
                         nil];
    
    //only @"ID" represents notif If that we want to forward, in this screen it will be 0 as we arent forwarding any notif
    if([self.delegate respondsToSelector:@selector(passBlabDataForHBlab:)]) {
        [self.delegate passBlabDataForHBlab:dic];
        [HUD hide:YES];
        [self popToCreateHBlab];
        return;
    }
    NSString *strUrl = [WebServiceContainer getServiceURL:SEND_NOTIF_MSG withParameters:nil];       //SEND_TEST_MSG     //SEND_NOTIF_MSG
    
    AFNetworkingDataTransaction *request = [AFNetworkingDataTransaction sharedManager];
    //[request SetCallForURL:strUrl WithDic:dic isAddHeader:TRUE];
    [request SetCallForURLWithImg:strUrl WithDic:dic isAddHeader:TRUE forLoader:HUD];
    
    if (request._currentRequest == nil) {
        [HUD hide:YES];
    }
    else{
        [request setDelegate:self];
        [request setTag:2];
        HUD.mode = MBProgressHUDModeDeterminate;
        HUD.delegate = self;
        HUD.labelText = @"Sending blab";
        
        [request._currentRequest setUploadProgressBlock:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) {
            double percentDone = (double)totalBytesWritten / (double)totalBytesExpectedToWrite;
            //Upload Progress bar here
            NSLog(@"progress updated(percentDone) : %f", percentDone);
            [HUD setProgress:percentDone];
            if (percentDone == 1.0) {
                //     [self.timer invalidate];
                HUD.mode = MBProgressHUDModeIndeterminate;
                HUD.labelText = @"";
            }
        }];
    }
}
- (void)successResponseWithData:(id)request withTag:(int)tag{
    //	NSError *error = nil;
    
   	NSDictionary *dicResponse  = [NSDictionary dictionaryWithDictionary:(NSDictionary *)request];
    
    //NSLog(@"dictionary = %@",dicResponse);
        if (dicResponse != nil) {
            if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
                NSLog(@"dic = %@",dicResponse);
                [HUD hide:YES];
                [appDelegate callLogOutService];
            }
            else{
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        if (tag == 2){
                            //send notification
                            
                            // [HUD hide:YES];
                            NSLog(@"%@",[dicResponse objectForKey:RESPONSE]);

                            // [Validation showToastMessage:@"Sent" displayDuration:3];
                            __block UIImageView *imageView;
                            UIImage *image = [UIImage imageNamed:@"37x-Checkmark.png"];
                            imageView = [[UIImageView alloc] initWithImage:image];
                            
                            HUD.customView = imageView;
                            HUD.mode = MBProgressHUDModeText;
                            HUD.labelText = @"Sent";
                            imageView = nil;
                            [self performSelector:@selector(popToNotifListScreen:) withObject:[NSNumber numberWithBool:NO] afterDelay:3];
                        }
                    }
                    else{
                        if (tag==2) {
                            if ([[dicResponse objectForKey:RESPONSE] isKindOfClass:[NSArray class]]) {
                                
                                //[Validation showToastMessage:[[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] displayDuration:ERROR_MSG_DURATION];
                                HUD.mode = MBProgressHUDModeText;
                                HUD.delegate = self;
                                HUD.detailsLabelFont = [UIFont boldSystemFontOfSize:16];
                                HUD.detailsLabelText = [[((NSArray *)[dicResponse objectForKey:RESPONSE]) objectAtIndex:0] valueForKey:@"Message"] ;
                                [self performSelector:@selector(popToNotifListScreen:) withObject:[NSNumber numberWithBool:YES] afterDelay:4];
                            }
                            else{
                                [HUD hide:YES];
                                
                            }
                        }
                        else{
                            [HUD hide:YES];
                        }
                    }
                    self.request = nil;
                }
                else{
                    [HUD hide:YES];
                    
                }
                
                dicResponse = nil;
            }
            
        }
        else{
            [HUD hide:YES];
        }
    
    dicResponse = nil;
}
- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
    [HUD hide:YES];
}
@end
