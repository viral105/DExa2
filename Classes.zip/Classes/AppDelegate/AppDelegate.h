//
//  AppDelegate.h
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataValidation.h"
#import "sqlite3.h"
#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MediaPlayer.h>
#import "ToastMessageView.h"
//#import <MobileAppTracker/MobileAppTracker.h>
#import <AdSupport/AdSupport.h>


// Alarm Request Status Type


#define appDelegate			((AppDelegate *)[[UIApplication sharedApplication] delegate])
#define MainStoryboard          ((UIStoryboard *)[UIStoryboard storyboardWithName:@"Main" bundle:nil])

#define Validation			((AppDelegate *)[[UIApplication sharedApplication] delegate]).validation
#define DEVICE_WIDTH		((AppDelegate *)[[UIApplication sharedApplication] delegate]).deviceWidth
#define DEVICE_HEIGHT		((AppDelegate *)[[UIApplication sharedApplication] delegate]).deviceHeight

#define LOADERVIEW  ((AppDelegate *)[[UIApplication sharedApplication] delegate]).viewLoader

#define LOAD_LOADER(fmt) if(fmt){ [fmt addSubview:LOADERVIEW];  LOADERVIEW.hidden = NO;}
#define HIDE_LOADER { LOADERVIEW.hidden = YES; [LOADERVIEW removeFromSuperview]; }


@interface AppDelegate : UIResponder <UIApplicationDelegate,AVAudioPlayerDelegate,UIAlertViewDelegate,UIActionSheetDelegate>


@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong) UINavigationController	*navigationController;

@property (nonatomic, readwrite) int					deviceWidth;
@property (nonatomic, readwrite) int					deviceHeight;
@property (nonatomic, strong) DataValidation			*validation;
@property (nonatomic, readwrite) BOOL					is_Login;
@property (nonatomic, strong) UIImage					*userProfileImg;
@property (nonatomic, strong) id						currentVc;
@property (nonatomic,strong) AVPlayer					*player;
@property (nonatomic,strong) AVAudioSession             *aSession;
@property (nonatomic, strong) NSMutableDictionary		*dic_APNS;
@property (nonatomic, strong) NSMutableDictionary		*dic_SelectedAPNSToPlay;
@property (nonatomic, readwrite) BOOL					isBannerVisible;
@property (nonatomic, strong) NSMutableArray			*arrAPNS;
@property (nonatomic, strong) UIView					*viewLoader;
@property (nonatomic, strong) ToastMessageView			*toastAPNS;
@property (nonatomic, readwrite) BOOL                   isForwarded;
@property (nonatomic, strong) MPVolumeView              *volumeView;
@property (nonatomic, strong) UISlider					*volumeSlider;
@property (nonatomic, readwrite) int                    selectedMenuIndex;
@property (nonatomic, readwrite) BOOL                   isAppInActive;
@property (nonatomic, readwrite) BOOL                   isShouldShowReplyPopUp;
@property (nonatomic, strong) NSMutableDictionary       *dic_NotificationReleatedData;
@property (nonatomic, strong) NSMutableArray             *arrAnimation;
@property (nonatomic, readwrite) double                 UserCurrentLatitude;
@property (nonatomic, readwrite) double                 UserCurrentLongitude;
@property (nonatomic, strong) UIImageView               *imgPlayAnimation;
@property (nonatomic, readwrite) BOOL                   isPlayingFromPopUp;
@property (nonatomic, readwrite) BOOL                   is90SecondsVideoRec;


@property (nonatomic, assign) BOOL isPlaying;

@property (nonatomic, strong) MPMoviePlayerViewController   *moviePlayer;

@property (nonatomic, strong) NSSet						*arrInAppProduct;

@property (nonatomic, readwrite) BOOL                   isRecordingFromCamera;
@property (nonatomic,strong) NSURL                      *vedioURL;
@property (nonatomic,readwrite) CGAffineTransform          videoPrefferedTransform;
@property (nonatomic,readwrite) int                     CameraOrientationForVideo;

@property (nonatomic, readwrite) int                    FlagVideo;
@property (nonatomic, readwrite) BOOL                       CamreBack;
@property (nonatomic, assign) BOOL                       isLoadConversationFromNotif;
@property (nonatomic, assign) BOOL                       isChannelStaticBadgeShow;


//@property (nonatomic, strong) MPMoviePlayerController	*player;

@property (strong, nonatomic) NSString *databaseName;
@property (strong, nonatomic) NSString *databasePath;
-(NSString *)InfoSaveAlarm:(NSDictionary *)dicSel;
-(void)selectAllAlarm:(NSMutableArray *)arrAlarm;
-(BOOL)InfoDeleteAlarm:(NSDictionary *)dic;
-(BOOL)InfoDeleteAllAlarm;
-(BOOL)InfoUpdateAlarm:(NSDictionary *)dic;

-(void)playSoundForURL:(NSURL *)url;
//-(void)audioPlayerDidFinishPlaying;

-(void)callLogOutService;
-(void)closeReplyPopup;
-(void)apnsReplyToUser;
-(void)PlayNotification:(id)sender;
-(void)handleAPNSWithDic:(NSDictionary *)userInfo;
-(void)checkForNotification;
-(void)checkForHeadset;
-(void)removeViewControllersFromStack:(NSArray *)arrVC;

-(void)playSoundWithoutUIForURL:(NSURL *)url;   //inView:(id)viewToPlayAnimationIn;
-(void)ClosePopUpWithoutUI;
-(void)ClosePopUpWithoutUIFromFrienRequest;
-(void)playLocalAlarm:(NSDictionary *)dic;
- (void)InitiatePurchaseFromProdutIds:(NSArray *)arrProducts andPrice:(NSString *)value;
-(void)showReplyPopUpForChannelFirstBlabPlay:(NSMutableDictionary*)dicChannel;
-(void)addStaticBadgeForChannels:(int)badgeCnt;
-(void)showChannelDetail:(id)sender;

@end


/*
 public enum FriendType
 {
 Blabeey = 0,
 Facebook = 1,
 Contact = 2
 }
 
 public enum BlabType
 {
 NormalBlab = 0,
 HashBlab = 1
 }
 
 public enum ShareContentType
 {
 blab = 0,
 hashBlab = 1
 }
 
 public enum AbuseType
 {
 blab = 0,
 hashBlab = 1
 }
 
 public enum MessageType
 {
 Sound = 0,
 stickr = 1,
 Video = 2,
 Text = 3
 }
 
 public enum NotifType
 {
 Sound = 1,
 SendFriendRequest = 2,
 AcceptFriend = 3,
 Birthday = 4,
 Anniversary = 5,
 KeepMsgRequest = 6,
 KeepMsgRequestAccept = 7,
 KeepMsgRequestDeny = 8,
 ReadOnceMsg = 9,
 SendAlarmRequest = 10,
 AcceptAlarm = 11,
 ReceiveAlarm = 12,
 ReadMsg = 13,
 HashBlab = 14,
 Follow = 15,
 ReplyToOneHashBlab = 16,
 AddFriendToGroup = 17,
 FriendFbOrContact = 18
 HashBlabNewMsg = 19
 }
 
 // Alarm Request Status Type
 public enum StatusType
 {
 Pending = 0,
 Accept = 1,
 Denied = 2
 }
 
 //for admin announcements
 
 [23/02/15 5:56:19 pm] Brijesh: UserTypeID
 [23/02/15 5:56:40 pm] Brijesh: public enum UserType
 {
 Admin = 1,
 User = 2,
 AdminUser = 3
 }
 
 in get all conversation service,
 you will get isAdmin for group Admin.
 consider this flag if GroupID is not = 0
 
 [02/12/14 6:30:29 pm] Brijesh: IsPublicImg
 [02/12/14 6:30:32 pm] Brijesh: KeepStatus
 [02/12/14 6:30:44 pm] Brijesh: bool and int
 
 SetRequestSent
 GetKeepRequestListByUserID
 
 
 //--------
 [14/10/14 11:48:23 am] Brijesh: notification enum
 [14/10/14 11:48:23 am] Brijesh: public enum NotifType
 {
 Sound = 1,
 SendFriendRequest = 2,
 AcceptFriend = 3,
 Birthday = 4,
 Anniversary = 5,
 KeepMsgRequest = 6,
 KeepMsgRequestAccept = 7,
 KeepMsgRequestDeny = 8

 }
 
 public enum MessageKeepStatus
 {
 Once = 1,
 NeverGo = 2
 }
 
 public enum Gender
 {
 NotToDisclose = 0,
 Male = 1,
 Female = 2
 }
*/

/*
 public enum NotifType
 {
 Sound = 1,
 SendFriendRequest = 2,
 AcceptFriend = 3
 
 }
*/