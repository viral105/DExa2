//
//  AppDelegate.m
//  WWHHAAZZAAPP
//
//  Created by s on 7/28/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "AppDelegate.h"
#import "DataValidation.h"
#import "NotificationVC.h"
#import "OtherFriendNotifListVC.h"
#import "NotifOptionVC.h"
#import "RecordingOptionVC.h"
#import "CaptureImageVC.h"
#import "UserConversationChatVC.h"
#import <StoreKit/StoreKit.h>
#import "RageIAPHelper.h"
#import "IAPHelper.h"
#import "SelectedStore_SelectedItem_DetailVC.h"
#import "AlarmRequestListVC.h"
#import "AlarmMainVC.h"
#import "SetVideoAndPrivacyVC.h"
#import "TextBlabVC.h"
#import "HashBlabHomeVC.h"

NSString * const kAppDelegateDemoStyleSheetImageIconError = @"iconAlert-error.png";
NSString * const kAppDelegateDemoStyleSheetImageIconSuccess = @"iconAlert-success.png";
NSString * const kAppDelegateDemoStyleSheetImageIconInfo = @"iconAlert-info.png";

#define kRateKey			 @"rate"
#define kStatusKey			 @"status"
#define kCurrentItemKey		 @"currentItem"

static void *AVPlayerDemoPlaybackViewControllerRateObservationContext = &AVPlayerDemoPlaybackViewControllerRateObservationContext;
static void *AVPlayerDemoPlaybackViewControllerStatusObservationContext = &AVPlayerDemoPlaybackViewControllerStatusObservationContext;
static void *AVPlayerDemoPlaybackViewControllerCurrentItemObservationContext = &AVPlayerDemoPlaybackViewControllerCurrentItemObservationContext;


//@interface TWAppDelegateDemoStyleSheet : NSObject <TWMessageBarStyleSheet>

//+ (TWAppDelegateDemoStyleSheet *)styleSheet;

//@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
	[NSThread sleepForTimeInterval:(0.0f)];
    
//    [MobileAppTracker initializeWithMATAdvertiserId:@"189172"
//                                   MATConversionKey:@"3ed31f359241642d36f8e1db3ab9ce42"];
    
    // Pass the Apple Identifier for Advertisers (IFA) to MAT; enables accurate 1-to-1 attribution.
    // REQUIRED for attribution on iOS devices.
//    [MobileAppTracker setAppleAdvertisingIdentifier:[[ASIdentifierManager sharedManager] advertisingIdentifier]
//                         advertisingTrackingEnabled:[[ASIdentifierManager sharedManager] isAdvertisingTrackingEnabled]];
    
    
    NSLog(@"filepath is %@",NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES));
    //-------------
    AVAudioSession *session = [AVAudioSession sharedInstance];
    
    BOOL success = [session setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionMixWithOthers|AVAudioSessionCategoryOptionDefaultToSpeaker error:nil];
    if (!success) {
        NSLog(@"setCategoryError");
    }

    //-----------
    
	[FBLoginView class];
    [self dbconnect];
	UINavigationController *vc = (UINavigationController*)self.window.rootViewController;
	self.navigationController = vc;
	
	self.deviceWidth = [[UIScreen mainScreen] bounds].size.width;
	self.deviceHeight = [[UIScreen mainScreen] bounds].size.height;
	self.validation = [[DataValidation alloc] init] ;
	[self.validation setArrayOfColor];
//    self.validation.dicNotifCount = [NSDictionary dictionaryWithObjectsAndKeys:@"0",TOTAL_FRIENDS_REQUEST, @"0",TOTAL_UNREAD_NOTIF,@"0",TOTAL_NOTIF_COUNT, nil];

    self.validation.dicNotifCount = [NSDictionary
                                     dictionaryWithObjectsAndKeys:
                                     @"0",TOTAL_FRIENDS_REQUEST,
                                     @"0",TOTAL_UNREAD_NOTIF,
                                     @"0",TOTAL_KEEP_REQUEST,
                                     @"0", TOTAL_NOTIF_COUNT,
                                     @"0",TOTAL_ALARM_REQUEST,
                                     nil];
    
//    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    if (self.volumeView == nil) {
        self.volumeView = [MPVolumeView new];
    }
    
  //  [self.validation setAudioPropertyForRecording];
	
	self.is_Login = [[NSUserDefaults standardUserDefaults] boolForKey:IS_LOGIN];
	NSLog(@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_KEY]);

    //bhavik 13-FEB-2015
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    
	[[UIApplication sharedApplication] setStatusBarHidden:FALSE];

    if ([[UIApplication sharedApplication] respondsToSelector:@selector(registerUserNotificationSettings:)])
    {
        //for ios 8 Push notification
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
        [[UIApplication sharedApplication] registerForRemoteNotifications];
    }
    else{
        // iOS < 8 Notifications
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes: (UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    }
    
//	[[UIApplication sharedApplication] registerForRemoteNotificationTypes: (UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    
	NSDictionary *pushDict = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
    if(pushDict)
    {
        [self application:application didReceiveRemoteNotification:pushDict];
    }
		
	[UIApplication sharedApplication].applicationIconBadgeNumber = 0;
	
    [AVAudioSession sharedInstance];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(audioRouteChangeListenerCallback:)
                                                 name:AVAudioSessionRouteChangeNotification
                                               object:nil];

    
    return YES;
}

-(void)checkForNotification{
    
    //to check notification handling
    /*
     ContentID = 113;
	 ID = "<null>";
	 SoundPath = "http://wwhhaazzuupp.com/Sound/chillin_21.mp3";
	 TypeID = 1;
	 UserID = 7;
	 aps =     {
	 alert = "New Wwhhaazzuupp from Shreya123";
	 badge = 1;
	 sound = default;
     
     */
    
    /*
     ContentID = 10182;
     ID = "<null>";
     SoundPath = "http://wwhhaazzuupp.com/Content/UserImages/2.jpg";
     TypeID = 2;
     UserID = 63;
     aps =     {
     alert = "You have received friend request from Shreya13";
     badge = 1;
     sound = default;

     */
    
    
    
    if (self.arrAPNS == nil) {
        self.arrAPNS = [[NSMutableArray alloc] init];
    }
    
    NSDictionary *dic = [NSDictionary
                         dictionaryWithObjectsAndKeys:
                         @"New Wwhhaazzuupp from Shreya123",@"alert",
                         @"1",@"badge",
                         @"default",@"sound",
                         nil];
    
/*
    NSDictionary *userInfo = [NSDictionary
                              dictionaryWithObjectsAndKeys:
                              @"113",@"ContentID",
                              @"1",@"ID",
                              @"1",@"TypeID",
                              @"20191",@"UserID",
                              @"http://wwhhaazzuupp.com/Sound/chillin_21.mp3",@"SoundPath",
                              @"shreya",@"Name",
                              dic,@"aps",
                              nil];
*/
    NSDictionary *userInfo = [NSDictionary
                              dictionaryWithObjectsAndKeys:
                              @"4",@"TypeID",
                              @"20191",@"UserID",
                              @"http://www.blabeey.com/Content/UserImages/30217_Y8UY2521458.jpg",@"PhotoPath",
                              @"viral",@"Name",
                              dic,@"aps",
                              nil];

    //TypeID
    //      UserID
    //             PhotoPath
    //             Name
  /*
    NSDictionary *dic = [NSDictionary
                         dictionaryWithObjectsAndKeys:
                         @"You have received friend request from Shreya13.",@"alert",
                         @"1",@"badge",
                         @"default",@"sound",
                         nil];
    
    
    NSDictionary *userInfo = [NSDictionary
                              dictionaryWithObjectsAndKeys:
                              @"10182",@"ContentID",
                              @"1",@"ID",
                              @"2",@"TypeID",
                              @"63",@"UserID",
                              @"",@"PhotoPath",
                              @"shreya",@"Name",
                              dic,@"aps",
                              nil];
   */
    self.dic_APNS = [NSMutableDictionary dictionaryWithDictionary:userInfo];
    [self handleAPNSWithDic:userInfo];
    
    //notification check over
}
- (void)application:(UIApplication *)application didChangeStatusBarFrame:(CGRect)oldStatusBarFrame;
{
    NSLog(@"oldStatusBarFrame %@",NSStringFromCGRect(oldStatusBarFrame));
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:@"trigger" forKey:@"frame"];
    if ([self.currentVc isKindOfClass:[UserConversationChatVC class]] || [self.currentVc isKindOfClass:[HBlabConversation class]]){
    [[NSNotificationCenter defaultCenter] postNotificationName:@"trigger"
                                                        object:self
                                                      userInfo:@{@"height":[NSString stringWithFormat:@"%f",oldStatusBarFrame.size.height]}];

//        [[NSNotificationCenter defaultCenter] postNotificationName:@"trigger" object:[NSString stringWithFormat:@"%f",oldStatusBarFrame.size.height]];
    }
}
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
	NSLog(@"User Info = %@",userInfo);
		
	if (self.dic_APNS != nil) {
		self.dic_APNS = nil;
	}
	switch ([[UIApplication sharedApplication] applicationState]) {
		case 0:
			NSLog(@"Active");
			break;
		case 1:
			NSLog(@"In-Active");
			break;
		case 2:
			NSLog(@"Background");
			break;
			
		default:
			break;
	}
	
	/*
	 public enum NotifType
	 {
	 Sound = 1,
	 SendFriendRequest = 2,
	 AcceptFriend = 3
	 
	 }
	 */
	
	/*
	
	 ContentID = 113;
	 ID = "<null>";
	 SoundPath = "http://wwhhaazzuupp.com/Sound/chillin_21.mp3";
	 TypeID = 1;
	 UserID = 7;
	 aps =     {
	 alert = "New Wwhhaazzuupp from Shreya123";
	 badge = 1;
	 sound = default;
	 };
	 
	*/
    
	self.dic_APNS = [NSMutableDictionary dictionaryWithDictionary:userInfo];
    
    if ([[UIApplication sharedApplication] applicationState] == 0) {
        self.isAppInActive = NO;
        [self handleAPNSWithDic:userInfo];

    }
    else{
        
        if ([NSStringFromClass([self.navigationController.visibleViewController class]) isKindOfClass:[UIViewController class]] || [DataValidation checkNullString:NSStringFromClass([self.currentVc class])].length == 0) {
                //was removed from multitasking
            NSLog(@"its null so wait");
            self.isAppInActive = YES;
        }
        else {
            [self handleAPNSWithDic:userInfo];
        }
    }
}
- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification{
    NSLog(@"notification.userInfo %@",notification.userInfo);
//    /*    if Repet found then schedule notification again.
//    if ([DataValidation checkNullString:[notification.userInfo valueForKey:@"AlarmRepet"]].length!=0) {
//        [[UIApplication sharedApplication] scheduleLocalNotification:notification];
//    }
//  */
    self.dic_APNS = [NSMutableDictionary dictionaryWithDictionary:notification.userInfo];
    if ([[self.dic_APNS valueForKey:@"TypeID"] isEqualToString:@"2"]) {
        UIAlertView *aView = [[UIAlertView alloc] initWithTitle:@"Alarm Reminder" message:[NSString stringWithFormat:@"%@ %@",[self.dic_APNS valueForKey:@"Alarmdate"],[self.dic_APNS valueForKey:@"Alarmtime"]] delegate:self cancelButtonTitle:nil otherButtonTitles:OK_BUTTON_TITLE, nil];
        aView.tag = -1;
        [aView show];
    }
    else{
//        [self.validation showAPNS_PopUp:self.dic_APNS forId:1];
        [self.validation showAPNS_PopUp:self.dic_APNS forId:1];
        if (self.arrAPNS == nil) {
            self.arrAPNS = [[NSMutableArray alloc] init];
        }
        
        NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
        [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
        
        [self.arrAPNS addObject:self.dic_APNS];
        self.validation.apnsPopUp.btnPlay.tag = (int)interval;
//        [self showReplyPopUpForIndex:self.validation.apnsPopUp.btnPlay];
        [self showReminderPopUpForIndex:self.validation.apnsPopUp.btnPlay];
    }
}
-(void)addStaticBadgeForChannels:(int)badgeCnt{
    if (Validation.dicNotifCount) {
        if (badgeCnt==1) {
            NSString *strFR = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_FRIENDS_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSString *strNotif = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_UNREAD_NOTIF]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSString *strKeepReq = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_KEEP_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSString *strTotalCount = [[NSString stringWithFormat:@"%d",[[Validation.dicNotifCount valueForKey:TOTAL_NOTIF_COUNT] intValue]+1] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSString *strARCount = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_ALARM_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSString *strChannelCount = @"1";
            
            Validation.dicNotifCount = [NSDictionary
                                        dictionaryWithObjectsAndKeys:
                                        strFR,TOTAL_FRIENDS_REQUEST,
                                        strNotif,TOTAL_UNREAD_NOTIF,
                                        strKeepReq,TOTAL_KEEP_REQUEST,
                                        strTotalCount, TOTAL_NOTIF_COUNT,
                                        strARCount,TOTAL_ALARM_REQUEST,
                                        strChannelCount,TOTAL_CHANNELS,
                                        nil];
        }
        else{
            NSString *strFR = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_FRIENDS_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSString *strNotif = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_UNREAD_NOTIF]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSString *strKeepReq = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_KEEP_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSString *strTotalCount = [[NSString stringWithFormat:@"%d",[[Validation.dicNotifCount valueForKey:TOTAL_NOTIF_COUNT] intValue]-1] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSString *strARCount = [[NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_ALARM_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSString *strChannelCount = @"0";
            
            Validation.dicNotifCount = [NSDictionary
                                        dictionaryWithObjectsAndKeys:
                                        strFR,TOTAL_FRIENDS_REQUEST,
                                        strNotif,TOTAL_UNREAD_NOTIF,
                                        strKeepReq,TOTAL_KEEP_REQUEST,
                                        strTotalCount, TOTAL_NOTIF_COUNT,
                                        strARCount,TOTAL_ALARM_REQUEST,
                                        strChannelCount,TOTAL_CHANNELS,
                                        nil];
        }
    }
    else{
        NSString *strFR = @"0";
        NSString *strNotif = @"0";
        NSString *strKeepReq = @"0";
        NSString *strTotalCount = @"1";
        NSString *strARCount = @"0";
        NSString *strChannelCount = @"1";
        
        Validation.dicNotifCount = [NSDictionary
                                    dictionaryWithObjectsAndKeys:
                                    strFR,TOTAL_FRIENDS_REQUEST,
                                    strNotif,TOTAL_UNREAD_NOTIF,
                                    strKeepReq,TOTAL_KEEP_REQUEST,
                                    strTotalCount, TOTAL_NOTIF_COUNT,
                                    strARCount,TOTAL_ALARM_REQUEST,
                                    strChannelCount,TOTAL_CHANNELS,
                                    nil];
    }
    
}
-(void)playLocalAlarm:(NSDictionary *)dic{
    self.dic_APNS = [NSMutableDictionary dictionaryWithDictionary:dic];
//    [self.validation showAPNS_PopUp:self.dic_APNS forId:1];
    [self.validation ShowAlarm_PopUp:self.dic_APNS forId:1];
    if (self.arrAPNS == nil) {
        self.arrAPNS = [[NSMutableArray alloc] init];
    }
    
    [Validation createAlramFolder];
    NSLog(@"soundpath %@",[self.dic_APNS valueForKey:@"SoundPath"]);
    if ([[NSFileManager defaultManager] fileExistsAtPath:[self.dic_APNS valueForKey:@"SoundPath"]]) {
        NSLog(@"file Exists");
    }
    
    NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
    [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
    
    [self.arrAPNS addObject:self.dic_APNS];
    self.validation.apnsPopUp.btnPlay.tag = (int)interval;
//    [self showReplyPopUpForIndex:self.validation.apnsPopUp.btnPlay];
    [self showReminderPopUpForIndex:self.validation.apnsPopUp.btnPlay];
}

-(void)handleAPNSWithDic:(NSDictionary *)userInfo{
    
    int typeId = [[NSString stringWithFormat:@"%@",[self.dic_APNS valueForKey:APNS_TYPE_ID]] intValue];
    
    if (self.validation.apnsPopUp != nil) {
        [self.validation.apnsPopUp.btnClose removeTarget:self action:NULL forControlEvents:UIControlEventAllEvents];
        [self.validation.apnsPopUp.btnPlay removeTarget:self action:NULL forControlEvents:UIControlEventAllEvents];
        [self.validation.apnsPopUp.btnPlayPause removeTarget:self action:NULL forControlEvents:UIControlEventAllEvents];
    }
    switch (typeId) {
        case 1:{
            //sound notif
            
            /*
             response with group id
             
             User Info = {
             CName = Chat;
             Caption = "";
             ContentID = 10450;
             ConversationID = 20158;
             GroupIDs = 10157;
             ID = "<null>";
             ImagePath = "<null>";
             Name = developer2;
             PhotoPath = "http://wwhhaazzuupp.com/Content/UserImages/20191_2LJC26737.jpg";
             SoundPath = "http://wwhhaazzuupp.com/Sound/hello_female_13.mp3";
             TypeID = 1;
             UserID = 20191;
             aps =     {
             alert = "Your friend developer2 is blab'n with you about Chat";
             badge = 1;
             sound = default;
             };
             }
             */
            if ([self.currentVc isKindOfClass:[NotificationVC class]]) {
                NotificationVC *obj = (NotificationVC *)self.currentVc;
                if (!obj.isServiceWaitingForResponse) {
                    if (!obj.isSentNotifList) {
                        obj.pageCounter = 1;
                        obj.isDataNull= NO;
                        [obj.arrData removeAllObjects];
                        [obj viewWillAppear:NO];
                    }
                    else{
                        [obj.lblChangeNotifMode setText:@"Feed"];
                        obj.isSentNotifList = NO;
//                        [obj performSelectorInBackground:@selector(get_RecSent_NotifList) withObject:nil];
                        [obj performSelectorInBackground:@selector(get_ConversationListWithUsers) withObject:nil];
                    }
                }
            }
            else if ([self.currentVc isKindOfClass:[UserConversationChatVC class]]){
                UserConversationChatVC *obj = (UserConversationChatVC *)self.currentVc;
                [obj performSelectorInBackground:@selector(reloadChatViewForNewBlab) withObject:nil];
            }
            else if ([self.currentVc isKindOfClass:[NotifOptionVC class]]){
                NotifOptionVC *obj = (NotifOptionVC *)self.currentVc;
                if (obj.isNotifSentMsgVisible) {
                    [obj popToNotifListScreen:[NSNumber numberWithBool:NO]];
                }
            }
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init];
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            
            if ([[DataValidation checkNullString:[NSString stringWithFormat:@"%@",[self.dic_APNS valueForKey:@"BlabTypeID"]] ] isEqualToString:@"3"]) {
                // this is for text blab
                [self.validation showAPNS_PopUp:userInfo forId:101];
                self.validation.apnsPopUp.btnClose.tag = (int)interval;
                [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            }
            //tag = 1 is for sound apns
            //show play close button
//            if ([DataValidation checkNullString:[self.dic_APNS valueForKey:@"SoundPath"]].length==0) {
            else if ([DataValidation checkNullString:[self.dic_APNS valueForKey:@"SoundPath"]].length==0 && [DataValidation checkNullString:[self.dic_APNS valueForKey:@"VideoPath"]].length==0) {
                // this is for stickers
                [self.validation showAPNS_PopUp:userInfo forId:101];
                self.validation.apnsPopUp.btnClose.tag = (int)interval;
                [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            }
            else{
                if ([[NSString stringWithFormat:@"%@",[self.dic_APNS valueForKey:@"IsPrivate"]] boolValue] && [[NSString stringWithFormat:@"%@",[self.dic_APNS valueForKey:@"KeepStatus"]] intValue]==1) {
                    // This is for private image view once
                    [self.validation showAPNS_PopUp:userInfo forId:101];
                    self.validation.apnsPopUp.btnClose.tag = (int)interval;
                    [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
                }
                else{
                    [self.validation showAPNS_PopUp:userInfo forId:1];
                    self.validation.apnsPopUp.btnClose.tag = (int)interval;
                    self.validation.apnsPopUp.btnPlay.tag = (int)interval;
                    self.isPlayingFromPopUp = YES;
                    [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
                    [self.validation.apnsPopUp.btnPlay addTarget:self action:@selector(showReplyPopUpForIndex:) forControlEvents:UIControlEventTouchUpInside];
                }
            }
        }
            break;
        case 2:{
            // (you have rec friend request)
            /*
             ContentID = 10182;
             ID = "<null>";
             SoundPath = "http://wwhhaazzuupp.com/Content/UserImages/2.jpg";
             TypeID = 2;
             UserID = 63;
             aps =     {
             alert = "You have received friend request from Shreya13";
             badge = 1;
             sound = default;
             };
             */
            
            if ([self.currentVc isKindOfClass:[NotificationVC class]]) {
                NotificationVC *obj = (NotificationVC *)self.currentVc;
                if (!obj.isServiceWaitingForResponse) {
                    if (!obj.isSentNotifList) {
                        [obj viewWillAppear:NO];
                    }
                    else{
                        [obj.lblChangeNotifMode setText:@"Feed"];
                        obj.isSentNotifList = NO;
                        //[obj performSelectorInBackground:@selector(get_RecSent_NotifList) withObject:nil];
                        [obj performSelectorInBackground:@selector(get_ConversationListWithUsers) withObject:nil];
                    }
                }
            }
            else if ([self.currentVc isKindOfClass:[NotifOptionVC class]]){
                NotifOptionVC *obj = (NotifOptionVC *)self.currentVc;
                if (obj.isNotifSentMsgVisible) {
                    [obj popToNotifListScreen:[NSNumber numberWithBool:NO]];
                }
            }
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init];
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.validation showAPNS_PopUp:userInfo forId:2];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            [self.validation.apnsPopUp.btnPlay addTarget:self action:@selector(btnShowFriendRequestClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
        }
            break;
        case 3:{
            //AcceptFriend
            /*
             {
             ContentID = 10430;
             ID = "<null>";
             SoundPath = "http://wwhhaazzuupp.com/Content/UserImages/no_image.jpg";
             TypeID = 3;
             UserID = 2;
             aps =     {
             alert = "Your friend request has been accepted by ajjjjaayy";
             badge = 1;
             sound = default;
             };
             }
             */
            
            if ([self.currentVc isKindOfClass:[NotificationVC class]]) {
                NotificationVC *obj = (NotificationVC *)self.currentVc;
                if (!obj.isServiceWaitingForResponse) {
                    if (!obj.isSentNotifList) {
                        [obj viewWillAppear:NO];
                    }
                    else{
                        [obj.lblChangeNotifMode setText:@"Feed"];
                        obj.isSentNotifList = NO;
//                        [obj performSelectorInBackground:@selector(get_RecSent_NotifList) withObject:nil];
                        [obj performSelectorInBackground:@selector(get_ConversationListWithUsers) withObject:nil];
                    }
                }
            }
            else if ([self.currentVc isKindOfClass:[NotifOptionVC class]]){
                NotifOptionVC *obj = (NotifOptionVC *)self.currentVc;
                if (obj.isNotifSentMsgVisible) {
                    [obj popToNotifListScreen:[NSNumber numberWithBool:NO]];
                }
            }
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init];
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];

            [self.validation showAPNS_PopUp:userInfo forId:3];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            self.validation.apnsPopUp.btnPlay.tag = (int)interval;
            self.isPlayingFromPopUp = NO;
            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            
            [self.validation.apnsPopUp.btnPlay addTarget:self action:@selector(showConversation:) forControlEvents:UIControlEventTouchUpInside];
            
        }
            break;
        case 4:{                //birthday
//             TypeID
//             UserID
//             PhotoPath
//             Name
            
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init];
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:4];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            self.validation.apnsPopUp.btnPlay.tag = [[userInfo valueForKey:@"UserID"] intValue];

            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            [self.validation.apnsPopUp.btnPlay addTarget:self action:@selector(WishBackToUser:) forControlEvents:UIControlEventTouchUpInside];
            
            
        }
            break;
        case 5:{
            //anniversary
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init] ;
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:5];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            self.validation.apnsPopUp.btnPlay.tag = [[userInfo valueForKey:@"UserID"] intValue];
            
            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            [self.validation.apnsPopUp.btnPlay addTarget:self action:@selector(WishBackToUser:) forControlEvents:UIControlEventTouchUpInside];

        }
            break;
        case 6:{
            //keep request
            /*
             User Info = {
             CName = "<null>";
             Caption = "<null>";
             ContentID = 129280;
             ConversationID = "<null>";
             GroupIDs = "<null>";
             ID = "<null>";
             ImagePath = "http://upload.wwhhaazzuupp.com/UserSoundImages/L1ACFK2EC1056421_20190.jpg";
             Name = "<null>";
             PhotoPath = "http://wwhhaazzuupp.com/Content/UserImages/20191_2LJC26737.jpg";
             SoundPath = "http://wwhhaazzuupp.com/Sound/girlsnight_female_4.mp3";
             TypeID = 6;
             UserID = "<null>";
             aps =     {
             alert = "developer2 has requested to keep your picture";
             badge = 1;
             sound = default;
             };
             }
             */
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init] ;
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:6];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
//            self.validation.apnsPopUp.btnPlay.tag = [[userInfo valueForKey:@"UserID"] intValue];
            
            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
//            [self.validation.apnsPopUp.btnPlay addTarget:self action:@selector(WishBackToUser:) forControlEvents:UIControlEventTouchUpInside];

        }
            break;
        case 7:{
            //keep ACCEPT
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init] ;
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:7];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            
            if ([self.currentVc isKindOfClass:[UserConversationChatVC class]]){
                UserConversationChatVC *obj = (UserConversationChatVC *)self.currentVc;
                //[obj performSelectorInBackground:@selector(reloadChatViewForNewBlab) withObject:nil];
                NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[userInfo valueForKey:@"ContentID"]],@"ContentID",@"true",@"requestStatus", nil];
//                [obj performSelectorInBackground:@selector(setBlabvisibilityWithData:) withObject:dic];
                [obj performSelector:@selector(setBlabvisibilityWithData:) withObject:dic];
                dic = nil;
            }
        }
            break;

        case 8:{
            //keep REJECT
            
            /*
             User Info = {
             CName = "<null>";
             Caption = "<null>";
             ContentID = 129280;
             ConversationID = "<null>";
             GroupIDs = "<null>";
             ID = "<null>";
             ImagePath = "<null>";
             Name = "<null>";
             PhotoPath = "http://wwhhaazzuupp.com/Content/UserImages/20191_2LJC26737.jpg";
             SoundPath = "<null>";
             TypeID = 8;
             UserID = "<null>";
             aps =     {
             alert = "Developer1 has denied your request to keep his Picture";
             badge = 1;
             sound = default;
             };
             }
             */
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init] ;
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:8];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            
            if ([self.currentVc isKindOfClass:[UserConversationChatVC class]]){
                UserConversationChatVC *obj = (UserConversationChatVC *)self.currentVc;
                NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[userInfo valueForKey:@"ContentID"]],@"ContentID",@"false",@"requestStatus", nil];
                [obj performSelectorInBackground:@selector(setBlabvisibilityWithData:) withObject:dic];
                dic = nil;
            }
        }
            break;
            // private blab view once
        case 9:
            /*
             User Info = {
             CName = "<null>";
             Caption = "<null>";
             ContentID = 160407;
             ConversationID = "<null>";
             GroupIDs = "<null>";
             ID = "<null>";
             ImagePath = "<null>";
             Name = "<null>";
             PhotoPath = "http://wwhhaazzuupp.com/Content/UserImages/20190_I5QE857151.jpg";
             SoundPath = "<null>";
             TypeID = 9;
             UserID = "<null>";
             aps =     {
             alert = "Your blab has been viewed by Developer2";
             badge = 1;
             sound = default;
             };
             }
             */
        {
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init];
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:9];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            
            if ([self.currentVc isKindOfClass:[UserConversationChatVC class]]){
                UserConversationChatVC *obj = (UserConversationChatVC *)self.currentVc;
                [obj performSelectorInBackground:@selector(reloadChatViewForNewBlab) withObject:nil];
            }

        }
            break;
        case 10:{
            /*
             Alarm req received
             {
             CName = "<null>";
             Caption = "<null>";
             ContentID = 40;
             ConversationID = "<null>";
             GroupIDs = "<null>";
             ID = 40;
             ImagePath = "<null>";
             Name = "<null>";
             PhotoPath = "http://wwhhaazzuupp.com/Content/UserImages/20190_I5QE857151.jpg";
             SoundPath = "http://wwhhaazzuupp.com/Sound/10092_20143_EY3L49RE8201391.mp3";
             TypeID = 10;
             UserID = "<null>";
             aps =     {
             alert = "You have received alarm request from Developer2";
             badge = 1;
             sound = "audio_push_notif.aiff";
             };
             }
             */
            if ([self.currentVc isKindOfClass:[AlarmRequestListVC class]]) {
                AlarmRequestListVC *obj = (AlarmRequestListVC *)self.currentVc;
                [obj viewWillAppear:NO];
            }
            else if ([self.currentVc isKindOfClass:[AlarmMainVC class]]){
                AlarmMainVC *obj = (AlarmMainVC *)self.currentVc;
                [obj alarmRequestArrived];
            }
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init];
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:10];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            if ([self.currentVc isKindOfClass:[AlarmRequestListVC class]] || [self.currentVc isKindOfClass:[AlarmMainVC class]]) {
                [self.validation.apnsPopUp.btnClose setFrame:CGRectMake(self.validation.apnsPopUp.frame.size.width-50, self.validation.apnsPopUp.frame.size.height-45, 40, 40)];
                [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
                self.validation.apnsPopUp.btnPlay.hidden = YES;
            }
            else{
                [self.validation.apnsPopUp.btnPlay removeTarget:self action:nil forControlEvents:UIControlEventTouchUpInside];
                [self.validation.apnsPopUp.btnPlay addTarget:self action:@selector(btnShowReminderRequestClicked:) forControlEvents:UIControlEventTouchUpInside];
                [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            }
            
            
        }
            break;
        case 11:{
            /*
             
             {
             CName = "<null>";
             Caption = "<null>";
             ContentID = 18;
             ConversationID = "<null>";
             GroupIDs = "<null>";
             ID = 18;
             ImagePath = "<null>";
             Name = "<null>";
             PhotoPath = "http://wwhhaazzuupp.com/Content/UserImages/20191_9CG22015602.jpg";
             SoundPath = "http://wwhhaazzuupp.com/Sound/10039_20020_JTMPITNEB1652174.mp3";
             TypeID = 11;
             UserID = "<null>";
             aps =     {
             alert = "Your  alarm request has been accepted by Developer1";
             badge = 1;
             sound = "audio_push_notif.aiff";
             };
             }
             */
            
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init];
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:11];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
        }
            break;
        case 13:{
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init];
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:13];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
        }
            break;
        case 14:{
            /*
             New #blab created
             {
             BlabTypeID = 0;
             CName = Greetings;
             Caption = "<null>";
             ContentID = 113866;
             ConversationID = 136;
             GroupIDs = "<null>";
             ID = 369;
             ImagePath = "<null>";
             IsPrivate = "<null>";
             KeepStatus = "<null>";
             Name = Bs;
             PhotoPath = "http://www.wwhhaazzuupp.com/Content/UserImages/30267_OJEG2653848.jpg";
             SoundPath = "http://www.wwhhaazzuupp.com/Sound/10078_20086_3VPPKXMON537774.mp3";
             TypeID = 14;
             UserID = 30267;
             VideoPath = "<null>";
             aps =     {
             alert = "Bs has created new HashBlab";
             badge = 0;
             sound = "audio_push_notif.aiff";
             };
             }
             */
/*            if ([self.currentVc isKindOfClass:[ActiveHBlabVC class]]) {
                ActiveHBlabVC *obj = (ActiveHBlabVC *)self.currentVc;
                [obj viewWillAppear:NO];
            }
            
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init]  ;
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:14];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
*/

/*            if ([self.currentVc isKindOfClass:[HBlabConversation class]]) {
                
            }
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init];
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            
            if ([[DataValidation checkNullString:[NSString stringWithFormat:@"%@",[self.dic_APNS valueForKey:@"BlabTypeID"]] ] isEqualToString:@"3"]) {
                // this is for text blab
                [self.validation showAPNS_PopUp:userInfo forId:101];
                self.validation.apnsPopUp.btnClose.tag = (int)interval;
                [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            }
            //tag = 1 is for sound apns
            //show play close button
            //            if ([DataValidation checkNullString:[self.dic_APNS valueForKey:@"SoundPath"]].length==0) {
            else if ([DataValidation checkNullString:[self.dic_APNS valueForKey:@"SoundPath"]].length==0 && [DataValidation checkNullString:[self.dic_APNS valueForKey:@"VideoPath"]].length==0) {
                // this is for stickers
                [self.validation showAPNS_PopUp:userInfo forId:101];
                self.validation.apnsPopUp.btnClose.tag = (int)interval;
                [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            }
            else{
                if ([[NSString stringWithFormat:@"%@",[self.dic_APNS valueForKey:@"IsPrivate"]] boolValue] && [[NSString stringWithFormat:@"%@",[self.dic_APNS valueForKey:@"KeepStatus"]] intValue]==1) {
                    // This is for private image view once
                    [self.validation showAPNS_PopUp:userInfo forId:101];
                    self.validation.apnsPopUp.btnClose.tag = (int)interval;
                    [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
                }
                else{
                    [self.validation showAPNS_PopUp:userInfo forId:1];
                    self.validation.apnsPopUp.btnClose.tag = (int)interval;
                    self.validation.apnsPopUp.btnPlay.tag = (int)interval;
                    self.isPlayingFromPopUp = YES;
                    [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
                    [self.validation.apnsPopUp.btnPlay addTarget:self action:@selector(showReplyPopUpForIndex:) forControlEvents:UIControlEventTouchUpInside];
                }
            }
*/

            self.isChannelStaticBadgeShow = YES;
            
//            if ([self.currentVc isKindOfClass:[HBlabConversation class]]) {
                if (self.arrAPNS == nil) {
                    self.arrAPNS = [[NSMutableArray alloc] init];
                }
                
                NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
                [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
                
                [self.arrAPNS addObject:self.dic_APNS];
                
                [self.validation showAPNS_PopUp:userInfo forId:1];
                self.validation.apnsPopUp.btnClose.tag = (int)interval;
                self.validation.apnsPopUp.btnPlay.tag = (int)interval;
                self.isPlayingFromPopUp = NO;
                [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
                [self.validation.apnsPopUp.btnPlay addTarget:self action:@selector(showChannelDetail:) forControlEvents:UIControlEventTouchUpInside];
/*            }
            else{
                if (self.arrAPNS == nil) {
                    self.arrAPNS = [[NSMutableArray alloc] init];
                }
                
                NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
                [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
                
                [self.arrAPNS addObject:self.dic_APNS];
                
                [self.validation showAPNS_PopUp:userInfo forId:11];
                
                self.validation.apnsPopUp.btnClose.tag = (int)interval;
                
                [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
                
            }
*/
        }
            break;
        case 15:{
            /*
             if any follow to login user.This notification will not come as of now.
             */
            }
            break;
        case 16:{
            /*
             New #blab created
             {
             CName = "<null>";
             Caption = "<null>";
             ContentID = 40;
             ConversationID = "<null>";
             GroupIDs = "<null>";
             ID = 40;
             ImagePath = "<null>";
             Name = "<null>";
             PhotoPath = "http://wwhhaazzuupp.com/Content/UserImages/20190_I5QE857151.jpg";
             SoundPath = "http://wwhhaazzuupp.com/Sound/10092_20143_EY3L49RE8201391.mp3";
             TypeID = 10;
             UserID = "<null>";
             aps =     {
             alert = "You have received alarm request from Developer2";
             badge = 1;
             sound = "audio_push_notif.aiff";
             };
             }
             
            if ([self.currentVc isKindOfClass:[ActiveHBlabVC class]]) {
                ActiveHBlabVC *obj = (ActiveHBlabVC *)self.currentVc;
                [obj viewWillAppear:NO];
            }
            
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init]  ;
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:16];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            */
            
            if ([self.currentVc isKindOfClass:[NotificationVC class]]) {
                NotificationVC *obj = (NotificationVC *)self.currentVc;
                if (!obj.isServiceWaitingForResponse) {
                    if (!obj.isSentNotifList) {
                        obj.pageCounter = 1;
                        obj.isDataNull= NO;
                        [obj.arrData removeAllObjects];
                        [obj viewWillAppear:NO];
                    }
                    else{
                        [obj.lblChangeNotifMode setText:@"Feed"];
                        obj.isSentNotifList = NO;
                        //                        [obj performSelectorInBackground:@selector(get_RecSent_NotifList) withObject:nil];
                        [obj performSelectorInBackground:@selector(get_ConversationListWithUsers) withObject:nil];
                    }
                }
            }
            else if ([self.currentVc isKindOfClass:[UserConversationChatVC class]]){
                UserConversationChatVC *obj = (UserConversationChatVC *)self.currentVc;
                [obj performSelectorInBackground:@selector(reloadChatViewForNewBlab) withObject:nil];
            }
            else if ([self.currentVc isKindOfClass:[NotifOptionVC class]]){
                NotifOptionVC *obj = (NotifOptionVC *)self.currentVc;
                if (obj.isNotifSentMsgVisible) {
                    [obj popToNotifListScreen:[NSNumber numberWithBool:NO]];
                }
            }

            
        }
            break;
        case 17:{
            /* added me in new group.
             {
            CName = "<null>";
            Caption = "<null>";
            ContentID = 40331;
            ConversationID = "<null>";
            GroupIDs = "<null>";
            ID = "<null>";
            ImagePath = "<null>";
            Name = Bs;
            PhotoPath = "http://wwhhaazzuupp.com/Content/UserImages/30267_Q6H4843806.jpg";
            SoundPath = "<null>";
            TypeID = 17;
            UserID = 30267;
            aps =     {
                alert = "Devx you have been added to the Group called July 8-1";
                badge = 2;
                sound = "audio_push_notif.aiff";
            };
        }
             */
            
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init]  ;
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:17];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
        }
        case 18:{
            /*
             
             {
             CName = "<null>";
             Caption = "<null>";
             ContentID = 0;
             ConversationID = "<null>";
             GroupIDs = "<null>";
             ID = "<null>";
             ImagePath = "<null>";
             Name = Devx;
             PhotoPath = "http://wwhhaazzuupp.com/Content/UserImages/30268_KV8U829264.jpg";
             SoundPath = "http://wwhhaazzuupp.com/Content/UserImages/30268_KV8U829264.jpg";
             TypeID = 18;
             UserID = 30273;
             aps =     {
             alert = "Your friend Devx has joined Blabeey";
             badge = 1;
             sound = "audio_push_notif.aiff";
             };
             }
             */
            
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init];
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:11];
            
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
        }
            break;
        case 19:{
            /*
             
             {
             BlabTypeID = 0;
             CName = PartyTIME;
             Caption = "<null>";
             ContentID = 134633;
             ConversationID = 248;
             GroupIDs = "<null>";
             ID = 1244;
             ImagePath = "<null>";
             IsPrivate = "<null>";
             KeepStatus = "<null>";
             Name = Bs1;
             PhotoPath = "http://www.wwhhaazzuupp.com/Content/UserImages/30268_8NYT248378.jpg";
             SoundPath = "http://www.wwhhaazzuupp.com/Sound/10080_20075_L8QIK9Y1K1742867.mp3";
             TypeID = 19;
             UserID = 30268;
             VideoPath = "<null>";
             aps =     {
             alert = "Bs1 has commented on your channel in #Audio blab";
             badge = 5;
             sound = "audio_push_notif.aiff";
             };
             }
             */
            
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init];
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:1];
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            self.validation.apnsPopUp.btnPlay.tag = (int)interval;
            self.isPlayingFromPopUp = NO;
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            [self.validation.apnsPopUp.btnPlay addTarget:self action:@selector(showChannelDetail:) forControlEvents:UIControlEventTouchUpInside];
        }
            break;
        case 20:{
            /*
             
             {
             BlabTypeID = 0;
             CName = PartyTIME;
             Caption = "<null>";
             ContentID = 134633;
             ConversationID = 248;
             GroupIDs = "<null>";
             ID = 1244;
             ImagePath = "<null>";
             IsPrivate = "<null>";
             KeepStatus = "<null>";
             Name = Bs1;
             PhotoPath = "http://www.wwhhaazzuupp.com/Content/UserImages/30268_8NYT248378.jpg";
             SoundPath = "http://www.wwhhaazzuupp.com/Sound/10080_20075_L8QIK9Y1K1742867.mp3";
             TypeID = 19;
             UserID = 30268;
             VideoPath = "<null>";
             aps =     {
             alert = "Bs1 has commented on your channel in #Audio blab";
             badge = 5;
             sound = "audio_push_notif.aiff";
             };
             }
             */
            
            
            if (self.arrAPNS == nil) {
                self.arrAPNS = [[NSMutableArray alloc] init];
            }
            
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [self.dic_APNS setValue:[NSNumber numberWithInt:(int)interval] forKey:apnsTag];
            
            [self.arrAPNS addObject:self.dic_APNS];
            
            [self.validation showAPNS_PopUp:userInfo forId:1];
            self.validation.apnsPopUp.btnClose.tag = (int)interval;
            self.validation.apnsPopUp.btnPlay.tag = (int)interval;
            self.isPlayingFromPopUp = NO;
            [self.validation.apnsPopUp.btnClose addTarget:self action:@selector(closeNotificationPopup:) forControlEvents:UIControlEventTouchUpInside];
            [self.validation.apnsPopUp.btnPlay addTarget:self action:@selector(showChannelDetail:) forControlEvents:UIControlEventTouchUpInside];
        }
            break;
        default:
            break;
    }
}

-(void)btnShowFriendRequestClicked:(id)sender{
//    NSArray *arrapnsTags = [self.arrAPNS valueForKey:apnsTag];
//	int index = (int)[arrapnsTags indexOfObject:[NSNumber numberWithInt:(int)((UIButton *)sender).tag]];
//	self.dic_SelectedAPNSToPlay = [NSMutableDictionary dictionaryWithDictionary:[self.arrAPNS objectAtIndex:index]];
    
    [Validation removeAdviewFromSuperView];
    [self closeNotificationPopup:sender];
    
    self.selectedMenuIndex = 2;
  //  UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
    
    [UIView transitionWithView:self.navigationController.view
                      duration:0.5
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        [self.navigationController pushViewController:ivc animated:NO];
                    }
                    completion:nil];

    
//    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    OtherFriendNotifListVC *ivc = [storyboard instantiateViewControllerWithIdentifier:OTHER_FRNDREQ_NOTIF_LIST_VC];
//    
//    [(UINavigationController*)self.window.rootViewController pushViewController:ivc animated:NO];
    
}
-(void)btnShowReminderRequestClicked:(id)sender{
    //    NSArray *arrapnsTags = [self.arrAPNS valueForKey:apnsTag];
    //	int index = (int)[arrapnsTags indexOfObject:[NSNumber numberWithInt:(int)((UIButton *)sender).tag]];
    //	self.dic_SelectedAPNSToPlay = [NSMutableDictionary dictionaryWithDictionary:[self.arrAPNS objectAtIndex:index]];
     [Validation removeAdviewFromSuperView];
    [self closeNotificationPopup:sender];
    
    self.selectedMenuIndex = 5;
    //  UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
    
    [UIView transitionWithView:self.navigationController.view
                      duration:0.0
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        [self.navigationController pushViewController:ivc animated:NO];
                    }
                    completion:nil];
    
    
    //    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    //    OtherFriendNotifListVC *ivc = [storyboard instantiateViewControllerWithIdentifier:OTHER_FRNDREQ_NOTIF_LIST_VC];
    //
    //    [(UINavigationController*)self.window.rootViewController pushViewController:ivc animated:NO];
    
}
-(void)showConversation:(id)sender{
    if ([self.currentVc isKindOfClass:[NotificationVC class]]) {
        NotificationVC *obj = (NotificationVC*)self.currentVc;
        self.isLoadConversationFromNotif = YES;
        [obj loadConversationFromNotif];
    }
    else{
        self.selectedMenuIndex = 0;
        //            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
        self.isLoadConversationFromNotif = YES;
        
        [UIView transitionWithView:self.navigationController.view
                          duration:0.5
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.navigationController pushViewController:ivc animated:NO];
                        }
                        completion:nil];
    }
}
-(void)showChannelDetail:(id)sender{
    NSLog(@"self.selectedMenuIndex %d",self.selectedMenuIndex);
    if ([self.currentVc isKindOfClass:[HBlabConversation class]]) {
        HBlabConversation *obj = (HBlabConversation*)self.currentVc;
        NSArray *arrapnsTags = [self.arrAPNS valueForKey:apnsTag];
        
        int index = (int)[arrapnsTags indexOfObject:[NSNumber numberWithInt:(int)self.validation.apnsPopUp.btnPlay.tag]];
        NSDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self.arrAPNS objectAtIndex:index]];
        obj.strConvoIdFromNotif = [dic valueForKey:@"ConversationID"];
        [obj.dicConversationDetail setObject:[dic valueForKey:@"ConversationID"] forKey:@"ID"];

        [obj get_ChannelData];
    }
    else if ([self.currentVc isKindOfClass:[HashBlabHomeVC class]]) {
        HashBlabHomeVC *obj = (HashBlabHomeVC*)self.currentVc;
        obj.isLoadChannelFromNotif = YES;
        [obj callGetFeatured];
/*
        if ([self.currentVc isKindOfClass:[HashBlabHomeVC class]]) {
            HashBlabHomeVC *obj = (HashBlabHomeVC*)self.currentVc;
            obj.isLoadChannelFromNotif = YES;
            [obj callGetFeatured];
        }
        else{
            NSLog(@"self.navigationController.viewControllers %@",self.navigationController.viewControllers);
            for (UIViewController *obj in self.navigationController.viewControllers) {
                if ([obj isKindOfClass:[HBlabConversation class]]) {
                    HBlabConversation *objNew = (HBlabConversation*)obj;
                    
                    NSArray *arrapnsTags = [self.arrAPNS valueForKey:apnsTag];
                    int index = (int)[arrapnsTags indexOfObject:[NSNumber numberWithInt:(int)self.validation.apnsPopUp.btnPlay.tag]];
                    NSDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self.arrAPNS objectAtIndex:index]];
                    objNew.strConvoIdFromNotif = [dic valueForKey:@"ConversationID"];
                    
                    [self.navigationController popToViewController:obj animated:YES];
                }
            }
        }
*/        
    }
    else{
        //in other view
        //			UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        //			OtherFriendNotifListVC *ivc = [storyboard instantiateViewControllerWithIdentifier:OTHER_FRNDREQ_NOTIF_LIST_VC];
        //
        //			[(UINavigationController*)self.window.rootViewController pushViewController:ivc animated:NO];
        self.selectedMenuIndex = 4;
        //            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
        
        [UIView transitionWithView:self.navigationController.view
                          duration:0.5
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.navigationController pushViewController:ivc animated:NO];
                        }
                        completion:nil];
/*
        HBlabConversation *obj = [MainStoryboard instantiateViewControllerWithIdentifier:@"HBlabConversation"];
        NSArray *arrapnsTags = [self.arrAPNS valueForKey:apnsTag];
        int index = (int)[arrapnsTags indexOfObject:[NSNumber numberWithInt:(int)self.validation.apnsPopUp.btnPlay.tag]];
        NSDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self.arrAPNS objectAtIndex:index]];
        
        obj.strConvoIdFromNotif = [NSString stringWithFormat:@"%@",[dic valueForKey:@"ConversationID"]];
        
        [self.navigationController pushViewController:obj animated:YES];
*/ 
    }
    
}
-(void)showReminderPopUpForIndex:(id)sender{
    //set play button tag to 1
     [Validation removeAdviewFromSuperView];
    [self closeNotificationPopup:sender];
    [Validation DisableScreenLockWhilePlaying:YES];
    NSArray *arrapnsTags = [self.arrAPNS valueForKey:apnsTag];
    int index = (int)[arrapnsTags indexOfObject:[NSNumber numberWithInt:(int)((UIButton *)sender).tag]];
    self.dic_SelectedAPNSToPlay = [NSMutableDictionary dictionaryWithDictionary:[self.arrAPNS objectAtIndex:index]];
    
    [self.validation ShowAlarm_PopUp:self.dic_SelectedAPNSToPlay forId:1];
    
    [self.validation.apnsReplyPopUp.btnClose addTarget:self action:@selector(closeReplyPopup) forControlEvents:UIControlEventTouchUpInside];
    [self.validation.apnsReplyPopUp.btnPlay addTarget:self action:@selector(apnsReplyToUser) forControlEvents:UIControlEventTouchUpInside];
    if ([[self.dic_SelectedAPNSToPlay valueForKey:@"Name"] isEqualToString:TXT_ALARM]) {
        self.validation.apnsReplyPopUp.btnPlay.hidden = YES;
    }
    else{
        self.validation.apnsReplyPopUp.btnPlay.hidden = NO;
    }
    [self.validation.apnsReplyPopUp.btnPlayPause addTarget:self action:@selector(PlayNotification:) forControlEvents:UIControlEventTouchUpInside];
    
    self.validation.apnsReplyPopUp.btnPlayPause.tag = 1;
    [self PlayNotification:self.validation.apnsReplyPopUp.btnPlayPause];
}
-(void)showReplyPopUpForIndex1:(id)sender{
	//set play button tag to 1
    if (Validation.adView.isFullScreenAd) {
        Validation.adView.isFullScreenAd = FALSE;
        [[NSNotificationCenter defaultCenter] removeObserver:self name:replyPopup object:nil];
    }
     [Validation removeAdviewFromSuperView];
	[self closeNotificationPopup:sender];
    [Validation DisableScreenLockWhilePlaying:YES];
	NSArray *arrapnsTags = [self.arrAPNS valueForKey:apnsTag];
	
    int index = (int)[arrapnsTags indexOfObject:[NSNumber numberWithInt:(int)self.validation.apnsPopUp.btnPlay.tag]];
    self.dic_SelectedAPNSToPlay = [NSMutableDictionary dictionaryWithDictionary:[self.arrAPNS objectAtIndex:index]];

    
	[self.validation showAPNS_ReplyPopUp:self.dic_SelectedAPNSToPlay forId:1];
	
	[self.validation.apnsReplyPopUp.btnClose addTarget:self action:@selector(closeReplyPopup) forControlEvents:UIControlEventTouchUpInside];
	[self.validation.apnsReplyPopUp.btnPlay addTarget:self action:@selector(apnsReplyToUser) forControlEvents:UIControlEventTouchUpInside];
    if ([[self.dic_SelectedAPNSToPlay valueForKey:@"Name"] isEqualToString:TXT_ALARM]) {
        self.validation.apnsReplyPopUp.btnPlay.hidden = YES;
    }
    else{
        self.validation.apnsReplyPopUp.btnPlay.hidden = NO;
    }
	[self.validation.apnsReplyPopUp.btnPlayPause addTarget:self action:@selector(PlayNotification:) forControlEvents:UIControlEventTouchUpInside];
	
    self.validation.apnsReplyPopUp.btnPlayPause.tag = 1;
    
    if ([DataValidation checkNullString:[self.dic_SelectedAPNSToPlay valueForKey:VideoPath]].length==0) {
        [self PlayNotification:self.validation.apnsReplyPopUp.btnPlayPause];
    }
}

-(void)showReplyPopUpForIndex:(id)sender{
    if (Validation.adView.isFullScreenAd) {
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(showReplyPopUpForIndex1:) name:replyPopup object:nil];
        [Validation.adView cancelCurrentAdFor:replyPopup];
        [self closeNotificationPopup:sender];
    }
    else{
        [self closeNotificationPopup:sender];
        [self showReplyPopUpForIndex1:sender];
    }
}
-(void)showReplyPopUpForChannelFirstBlabPlay:(NSMutableDictionary*)dicChannel{
    if (Validation.adView.isFullScreenAd) {
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(showReplyPopUpForIndex1:) name:replyPopup object:nil];
        [Validation.adView cancelCurrentAdFor:replyPopup];
        [self closeNotificationPopup:nil];
    }
    else{
        [self closeNotificationPopup:nil];
        //set play button tag to 1
        if (Validation.adView.isFullScreenAd) {
            Validation.adView.isFullScreenAd = FALSE;
            [[NSNotificationCenter defaultCenter] removeObserver:self name:replyPopup object:nil];
        }
        [Validation removeAdviewFromSuperView];
        [self closeNotificationPopup:nil];
        [Validation DisableScreenLockWhilePlaying:YES];
//        NSArray *arrapnsTags = [self.arrAPNS valueForKey:apnsTag];
//        
//        int index = (int)[arrapnsTags indexOfObject:[NSNumber numberWithInt:(int)self.validation.apnsPopUp.btnPlay.tag]];
        self.dic_SelectedAPNSToPlay = dicChannel;
        
        
        [self.validation showAPNS_ReplyPopUp:self.dic_SelectedAPNSToPlay forId:1];
        
        [self.validation.apnsReplyPopUp.btnClose addTarget:self action:@selector(closeReplyPopup) forControlEvents:UIControlEventTouchUpInside];
        [self.validation.apnsReplyPopUp.btnPlay addTarget:self action:@selector(apnsReplyToUser) forControlEvents:UIControlEventTouchUpInside];
        self.validation.apnsReplyPopUp.btnPlay.hidden = YES;
        [self.validation.apnsReplyPopUp.btnPlayPause addTarget:self action:@selector(PlayNotification:) forControlEvents:UIControlEventTouchUpInside];
        
        self.validation.apnsReplyPopUp.btnPlayPause.tag = 1;
        
        if ([DataValidation checkNullString:[self.dic_SelectedAPNSToPlay valueForKey:VideoPath]].length==0) {
            [self PlayNotification:self.validation.apnsReplyPopUp.btnPlayPause];
        }
    }
}
-(void)closeNotificationPopup:(id)sender{

  //  [HUD hide:YES];
    [Validation DisableScreenLockWhilePlaying:NO];
	[NSObject cancelPreviousPerformRequestsWithTarget:self.validation selector:@selector(hideAPNS_PopUp) object:nil];
	[self.validation hideAPNS_PopUp];

}

-(void)closeReplyPopup{
    if ([DataValidation checkNullString:[self.dic_SelectedAPNSToPlay valueForKey:VideoPath]].length==0) {
        if (self.player) {
            [self.player pause];
        }
        [self.player pause];
        [self.player removeObserver:self forKeyPath:kRateKey];
        [self.player removeObserver:self forKeyPath:kStatusKey];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
        self.player = nil;
        [self.toastAPNS removeFromSuperview];
        //    if ([DataValidation checkNullString:[self.dic_APNS valueForKey:NOTIF_AUDIO_PATH]].length >0) {
        //        if ([[NSFileManager defaultManager] fileExistsAtPath:[self.dic_APNS valueForKey:NOTIF_AUDIO_PATH]]) {
        //            NSError *error;
        //            [[NSFileManager defaultManager] removeItemAtPath:[self.dic_APNS valueForKey:NOTIF_AUDIO_PATH] error:&error];
        //        }
        //    }
        
        
        //    [self.toastAPNS release];
        self.toastAPNS = nil;
        
        //    if (self.validation.apnsPopUp.moviePlayer) {
        
        //    }

    }
    else{
        [self.validation.apnsReplyPopUp stopPlayingVideo];
    }
	 
	[self.validation hideAPNS_ReplyPopup];
    
}

-(void)WishBackToUser:(id)sender{
    if (Validation.adView.isFullScreenAd) {
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(WishBackToUser1:) name:Wishback_Actionsheet object:nil];
        [Validation.adView cancelCurrentAdFor:Wishback_Actionsheet];
        [self closeNotificationPopup:sender];
    }
    else{
        [self closeNotificationPopup:sender];
        [self WishBackToUser1:sender];
    }
    
}

-(void)WishBackToUser1:(id)sender{
    
    if (Validation.adView.isFullScreenAd) {
        Validation.adView.isFullScreenAd = FALSE;
        [[NSNotificationCenter defaultCenter] removeObserver:self name:Wishback_Actionsheet object:nil];
    }
    
    [Validation removeAdviewFromSuperView];
    [self closeNotificationPopup:sender];
    
    
    if (appDelegate.dic_NotificationReleatedData != nil) {
        appDelegate.dic_NotificationReleatedData = nil;
    }
    
    appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                [NSArray arrayWithObjects:[NSString stringWithFormat:@"%d",(int)self.validation.apnsPopUp.btnPlay.tag], nil],SelectedIds,
                                                [NSNumber numberWithBool:FALSE],IS_GroupNotif,
                                                [NSNumber numberWithBool:NO],IS_NotifSendToAll,
                                                nil];
    [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
    [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];
    [self showYapOptions];
}


-(void)apnsReplyToUser{
	[self closeReplyPopup];
	
	
    if (appDelegate.dic_NotificationReleatedData != nil) {
        appDelegate.dic_NotificationReleatedData = nil;
    }
    
    //---
    /*
     User Info = {
     CName = Chat;
     Caption = "";
     ContentID = 10450;
     ConversationID = 20158;                        //to take user to particular conversation screen
     GroupIDs = 10157;                              // to let user reply the sender of the APNS
     ID = "<null>";
     ImagePath = "<null>";
     Name = developer2;
     PhotoPath = "http://wwhhaazzuupp.com/Content/UserImages/20191_2LJC26737.jpg";
     SoundPath = "http://wwhhaazzuupp.com/Sound/hello_female_13.mp3";
     TypeID = 1;
     UserID = 20191;
     aps =     {
     alert = "Your friend developer2 is blab'n with you about Chat";
     badge = 1;
     sound = default;
     };
     }
     */
    NSString *strReceiverId = @"";
    BOOL isGroupMessage = FALSE;
    if ([DataValidation checkNullString:[self.dic_APNS valueForKey:GROUP_IDs]].length >0 && ([[self.dic_APNS valueForKey:GROUP_IDs] intValue]!=0)) {
        //it is group message
        strReceiverId = [NSString stringWithFormat:@"%@",[self.dic_APNS valueForKey:GROUP_IDs]];
        isGroupMessage = TRUE;
    }
    else{
        strReceiverId = [NSString stringWithFormat:@"%@",[self.dic_SelectedAPNSToPlay valueForKey:APNS_USER_ID]];
    }
    
    appDelegate.dic_NotificationReleatedData = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                                [NSArray arrayWithObjects:strReceiverId, nil],SelectedIds,
                                                [NSNumber numberWithBool:isGroupMessage],IS_GroupNotif,
                                                [NSNumber numberWithBool:NO],IS_NotifSendToAll,
                                                nil];
    [appDelegate.dic_NotificationReleatedData setValue:@"true" forKeyPath:IsPublicImg];
    [appDelegate.dic_NotificationReleatedData setValue:@"2" forKeyPath:RequestedKeepStatus];
    
    NSLog(@"%@",appDelegate.dic_NotificationReleatedData);
    [self showYapOptions];
}

-(void)GoToRecordOptionScreen{
    
 //   UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    RecordingOptionVC *obj = [MainStoryboard instantiateViewControllerWithIdentifier:RECORD_OPTION_VC];
  	
	[(UINavigationController*)self.window.rootViewController pushViewController:obj animated:NO];
}

-(void)GoToPictureCaptureScreen{
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:STORYBOARD bundle:nil];
    CaptureImageVC *ivc = [storyboard instantiateViewControllerWithIdentifier:CAPTURE_IMAGE_VC];
    [self.navigationController pushViewController:ivc animated:NO];
}
-(void)GoToVideoCaptureScreen{
  
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:STORYBOARD bundle:nil];
    SetVideoAndPrivacyVC *ivc = [storyboard instantiateViewControllerWithIdentifier:SET_VIDEO_PRIVACY_VC];
    [self.navigationController pushViewController:ivc animated:NO];
}

-(void)showYapOptions{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Select" delegate:self cancelButtonTitle:CANCLE_BUTTON_TITLE destructiveButtonTitle:nil otherButtonTitles:Only_Yap,Yap_With_Image,Yap_With_Video,Text_Blab, nil];
    [action showInView:((UIViewController *)self.currentVc).view];
}

-(void)PlayNotification:(id)sender{
    
	UIButton *btn = (UIButton *)sender;
    [Validation removeAdviewFromSuperView];
	[self closeNotificationPopup:sender];
	
	if (btn.tag == 1) {
        
		//sound notif
		[Validation clearImageCache];
        if ([[NSString stringWithFormat:@"%@",[self.dic_SelectedAPNSToPlay valueForKey:@"IsPrivate"]] boolValue] && [[NSString stringWithFormat:@"%@",[self.dic_SelectedAPNSToPlay valueForKey:@"KeepStatus"]] intValue]==2) {
            [self setNotifAsRead];
        }
        //playing alarm     shreya  12-mar-2015     /*
        //so if this is UserConversation view and playAll is TRUE then stop play all
        if ([self.currentVc isKindOfClass:[UserConversationChatVC class]]) {
            UserConversationChatVC *obj  = (UserConversationChatVC *)self.currentVc;
            //check if play is playing
            if (obj.isPlayAll) {
                //then stop play all and listen this alarm
                obj.isStoppedForceFully = TRUE;
                [appDelegate ClosePopUpWithoutUI];
                [obj removeAnimationFromSuperView];
                obj.isPlayAll = FALSE;
            }
        }
        //        */
        
		//play notification
        NSURL *url;
        
        //changed by viral /*
        BOOL exists = [self.dic_SelectedAPNSToPlay objectForKey:@"IsFromRequest"] != nil;//This key will come when playing from scheduled reminder
        if ([[DataValidation checkNullString:[self.dic_SelectedAPNSToPlay valueForKey:NOTIF_Category]] isEqualToString:LOCALNOTIF_RECORDED] && exists) {
            if ([[self.dic_SelectedAPNSToPlay valueForKey:@"IsFromRequest"] boolValue]) {
                url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self.dic_SelectedAPNSToPlay valueForKey:NOTIF_AUDIO_PATH]]];
            }
            else{
                url = [[NSURL alloc] initFileURLWithPath:[self.dic_SelectedAPNSToPlay valueForKey:NOTIF_AUDIO_PATH]];
            }
        }
        else{
            url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self.dic_SelectedAPNSToPlay valueForKey:NOTIF_AUDIO_PATH]]];
        }
        // */
		[self performSelector:@selector(playSoundForURL:) withObject:url afterDelay:0.1];
		url = nil;
		
	}
	else if (btn.tag == 2){
		//rec friend req
		[Validation clearImageCache];
		
		if ([self.currentVc isKindOfClass:[OtherFriendNotifListVC class]]) {
			OtherFriendNotifListVC *obj = (OtherFriendNotifListVC *)self.currentVc;
			obj.pageCounter = 1;
			obj.isDataNull = NO;
			[obj.arrData removeAllObjects];
			[obj performSelectorInBackground:@selector(getRequestList) withObject:nil];
		}
		else{
			//in other view
//			UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//			OtherFriendNotifListVC *ivc = [storyboard instantiateViewControllerWithIdentifier:OTHER_FRNDREQ_NOTIF_LIST_VC];
//			
//			[(UINavigationController*)self.window.rootViewController pushViewController:ivc animated:NO];
            self.selectedMenuIndex = 2;
//            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
            
            [UIView transitionWithView:self.navigationController.view
                              duration:0.5
                               options:UIViewAnimationOptionTransitionCrossDissolve
                            animations:^{
                                [self.navigationController pushViewController:ivc animated:NO];
                            }
                            completion:nil];

		}
		
	}
	else if (btn.tag == 3){
		//accepted
	}
//	[NSObject cancelPreviousPerformRequestsWithTarget:self.validation selector:@selector(hideAPNS_PopUp) object:nil];
//	[self.validation hideAPNS_PopUp];

}

-(void)checkForHeadset{
    [self requestForHeadSetUse];
    [AVAudioSession sharedInstance];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(audioRouteChangeListenerCallback:)
                                                 name:AVAudioSessionRouteChangeNotification
                                               object:nil];
}

-(void)requestForHeadSetUse{
    if([[AVAudioSession sharedInstance] respondsToSelector:@selector(requestRecordPermission:)]) {
        [[AVAudioSession sharedInstance] requestRecordPermission:^(BOOL granted) {
            if (!granted) {
                NSLog(@"User will not be able to use the microphone!");
            }
        }];
    }
}

- (BOOL)isHeadsetPluggedIn {
    AVAudioSessionRouteDescription* route = [[AVAudioSession sharedInstance] currentRoute];
    for (AVAudioSessionPortDescription* desc in [route outputs]) {
        if ([[desc portType] isEqualToString:AVAudioSessionPortHeadphones])
            return YES;
    }
    [Validation setAudioPropertyForRecording];
    return NO;
    
}

- (void)audioRouteChangeListenerCallback:(NSNotification*)notification
{
    NSDictionary *interuptionDict = notification.userInfo;
    
    NSInteger routeChangeReason = [[interuptionDict valueForKey:AVAudioSessionRouteChangeReasonKey] integerValue];
    
    switch (routeChangeReason) {
            
        case AVAudioSessionRouteChangeReasonNewDeviceAvailable:{
            //headphone available
            NSLog(@"AVAudioSessionRouteChangeReasonNewDeviceAvailable");
            NSLog(@"Headphone/Line plugged in");
            NSError *error;
            
            [[AVAudioSession sharedInstance] setCategory:
             AVAudioSessionCategoryPlayAndRecord error:&error];
            [[AVAudioSession sharedInstance] requestRecordPermission:^(BOOL response){
                if (!response) {
                    //	NSLog(@"Microphone mute");
                }
            }];
        }
            break;
            
        case AVAudioSessionRouteChangeReasonOldDeviceUnavailable:{
            //speaker
            NSLog(@"AVAudioSessionRouteChangeReasonOldDeviceUnavailable");
            NSLog(@"Headphone/Line was pulled. Stopping player....");
            [Validation setAudioPropertyForRecording];
        }
            break;
            
        case AVAudioSessionRouteChangeReasonCategoryChange:{
            // called at start - also when other audio wants to play
            NSLog(@"AVAudioSessionRouteChangeReasonCategoryChange");
        }
            break;
    }
}


-(void)removeViewControllersFromStack:(NSArray *)arrVC{
//     NSArray *arrVC = self.navigationController.viewControllers;
    for (id vc in arrVC){
		if ([vc isKindOfClass:[FavoritesVC class]]) {
			[self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
		}
        else if ([vc isKindOfClass:[SearchFriendVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[OtherFriendNotifListVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[AddFriendFromExistingFriendListVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[SettingsVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[NotifOptionVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[CategoryListForUploadVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[GroupListVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
        else if ([vc isKindOfClass:[UserListVC class]]){
            [self removeFromNavigationController:vc animated:NO WithVCArray:arrVC];
        }
	}
    
}

-(void)removeFromNavigationController:(UIViewController *)controller animated:(BOOL)animated WithVCArray:(NSArray *)arrVC {
    
    NSMutableArray *allViewControllers = [NSMutableArray arrayWithArray:arrVC];
    [allViewControllers removeObjectIdenticalTo:controller];
    self.navigationController.viewControllers = allViewControllers;
	
}


#pragma mark    UIActionsheet Delegate

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"button index = %d",(int)buttonIndex);
    
    NSLog(@"clickedButtonAtIndex = %@", appDelegate.dic_NotificationReleatedData);
    if (buttonIndex == actionSheet.cancelButtonIndex) {
        
    }
    else if (buttonIndex == 0){
        //only yap
        [appDelegate.dic_NotificationReleatedData setValue:@"0" forKey:BlabType];

        [self GoToRecordOptionScreen];
    }
    else if (buttonIndex == 1){
        //yap with image
        [appDelegate.dic_NotificationReleatedData setValue:@"0" forKey:BlabType];
        
        [self GoToPictureCaptureScreen];
    }
    else if (buttonIndex == 2){
        //yap with Video
        if ([[NSFileManager defaultManager] fileExistsAtPath:VIDEO_RECORDING_FOLDER]) {
            //when folder exists
            NSString *tempPath = [VIDEO_RECORDING_FOLDER stringByAppendingFormat:@"/tmpMov.mp4"];
            if ([[NSFileManager defaultManager] fileExistsAtPath:tempPath]) {
                [[NSFileManager defaultManager] removeItemAtPath:tempPath error:NULL];
            }
        }
        [appDelegate.dic_NotificationReleatedData setValue:@"2" forKey:BlabType];


        [self GoToVideoCaptureScreen];
    }
    else if (buttonIndex == 3){
        TextBlabVC *objVc = [MainStoryboard instantiateViewControllerWithIdentifier:@"TextBlabVC"];
        objVc.isGroupMessage = FALSE;
        if ([DataValidation checkNullString:[self.dic_APNS valueForKey:GROUP_IDs]].length >0 && ([[self.dic_APNS valueForKey:GROUP_IDs] intValue]!=0)) {
            //it is group message
            objVc.strReceiverId = [NSString stringWithFormat:@"%@",[self.dic_APNS valueForKey:GROUP_IDs]];
            objVc.isGroupMessage = TRUE;
        }
        else{
            objVc.strReceiverId = [NSString stringWithFormat:@"%@",[self.dic_SelectedAPNSToPlay valueForKey:APNS_USER_ID]];
        }
        [self.navigationController pushViewController:objVc animated:YES];
    }
    NSLog(@"clickedButtonAtIndex = %@", appDelegate.dic_NotificationReleatedData);

}


- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
	//here you need change
	
    NSString *deviceToken1 = [[deviceToken description] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
	deviceToken1 = [deviceToken1 stringByReplacingOccurrencesOfString:@" " withString:@""];
	if ([DataValidation checkNullString:deviceToken1].length == 0) {
		deviceToken1 = @"";
	}
	NSLog(@"deviceToken = %@",deviceToken1);
	[[NSUserDefaults standardUserDefaults] setValue:deviceToken1 forKey:DEVICE_TOKEN];
	[[NSUserDefaults standardUserDefaults] synchronize];
    
    BOOL isLogin = [[NSUserDefaults standardUserDefaults] boolForKey:IS_LOGIN];
    if (!isLogin) {
        //set call for removing device token
        [self callUserDeviceLogOutWithURL];
    }
}
-(void)callUserDeviceLogOutWithURL{
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:@"",KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]],KeyValue,@"RegID",KeyName, nil],@"2",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"IOS",KeyValue,@"OS",KeyName, nil],@"3",
                         [NSDictionary dictionaryWithObjectsAndKeys:@"true",KeyValue,@"IsDelete",KeyName, nil],@"4",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:REMOVE_DEVICETOKEN withParameters:nil];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:strUrl parameters:dic success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"JSON: %@", responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}
/*
- (void)applicationWillResignActive:(UIApplication *)application
{
	// Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
	// Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    
    [self.validation.apnsReplyPopUp.btnPlayPause setImage:[UIImage imageNamed:BtnNotifUnRead] forState:UIControlStateNormal];
    [self.validation.apnsReplyPopUp.btnPlayPause setHidden:NO];
    [self.validation.apnsReplyPopUp.imgPlayAnimation setHidden:YES];
    //   [self.validation.apnsReplyPopUp.activityView stopAnimating];
    [Validation.apnsReplyPopUp.imgPlayAnimation stopAnimating];
    
	[self.player removeObserver:self forKeyPath:kRateKey];
	[self.player removeObserver:self forKeyPath:kStatusKey];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
	self.player = nil;
	
	[self.toastAPNS removeFromSuperview];
//	[self.toastAPNS release];
	self.toastAPNS = nil;
}
 */

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    
    [self.validation.apnsReplyPopUp.btnPlayPause setImage:[UIImage imageNamed:BtnNotifUnRead] forState:UIControlStateNormal];
    [self.validation.apnsReplyPopUp.btnPlayPause setHidden:NO];
    [self.validation.apnsReplyPopUp.imgPlayAnimation setHidden:YES];
    [self.validation.apnsReplyPopUp.imgPlayAnimation stopAnimating];
    [self.validation.apnsReplyPopUp.activityView stopAnimating];
    [self.validation.apnsReplyPopUp.activityView setHidden:YES];
    
    if (self.player) {
        [self.player pause];
        [self.player removeObserver:self forKeyPath:kRateKey];
        [self.player removeObserver:self forKeyPath:kStatusKey];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
        self.player = nil;
    }
    
    
    
    [self.toastAPNS removeFromSuperview];
    self.toastAPNS = nil;
    
    if ([self.currentVc isKindOfClass:[UserConversationChatVC class]]) {
        UserConversationChatVC *obj = (UserConversationChatVC *)self.currentVc;
        
        obj.isStoppedForceFully = TRUE;
        [appDelegate ClosePopUpWithoutUI];
        [obj btnCloseImageClicked:nil];
        [obj removeAnimationFromSuperView];
        obj.isPlayAll = FALSE;
    }
    
//    [self closeReplyPopup];
//    [self closeNotificationPopup:nil];
//    [self ClosePopUpWithoutUI];
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    UIBackgroundTaskIdentifier bgTask = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
        [[UIApplication sharedApplication] endBackgroundTask:bgTask];
    }];
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [session setActive:NO error:nil];
	[[NSUserDefaults standardUserDefaults] synchronize];
    NSLog(@"applicationDidEnterBackground");
    UIApplicationState state = [application applicationState];
    if (state == UIApplicationStateInactive) {
        NSLog(@"state UIApplicationStateInactive");
    }
    else if (state == UIApplicationStateActive) {
        NSLog(@"state UIApplicationStateInactive");
    }
    else if (state == UIApplicationStateBackground) {
        NSLog(@"state UIApplicationStateInactive");
    }
	// Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
	// If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    NSLog(@"applicationWillEnterForeground");
//    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
	// Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    NSLog(@"applicationDidBecomeActive");
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    if ([self.currentVc isKindOfClass:[UserConversationChatVC class]]) {
        UserConversationChatVC *obj = (UserConversationChatVC *)self.currentVc;
        [obj viewWillAppear:YES];
    }
    else if ([self.currentVc isKindOfClass:[NotificationVC class]]){
        NotificationVC *obj = (NotificationVC *)self.currentVc;
        [obj viewWillAppear:YES];
    }
    else if ([self.currentVc isKindOfClass:[OtherFriendNotifListVC class]]){
        OtherFriendNotifListVC *obj = (OtherFriendNotifListVC *)self.currentVc;
        [obj.tblData reloadData];
    }
    //[MobileAppTracker measureSession];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
	// Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
	NSLog(@"applicationWillTerminate");
	[Validation clearImageCache];
}


- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation {
	
//    [MobileAppTracker applicationDidOpenURL:[url absoluteString] sourceApplication:sourceApplication];
    
	// Call FBAppCall's handleOpenURL:sourceApplication to handle Facebook app responses
	BOOL wasHandled = [FBAppCall handleOpenURL:url sourceApplication:sourceApplication];
	
	// You can add your app-specific url handling code here if needed

	return wasHandled;
}

#pragma mark UIALertView DElegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
	if (alertView.tag == 0){
		//deactivated user
		[self UserDeactivated_CallLogout];
	}
	else if (alertView.tag == 1) {
		//sound notif
		[Validation clearImageCache];

		//play notification
		if (buttonIndex==alertView.cancelButtonIndex) {
			
		}
		else{
            //playing alarm     shreya  12-mar-2015     /*
            //so if this is UserConversation view and playAll is TRUE then stop play all
            if ([self.currentVc isKindOfClass:[UserConversationChatVC class]]) {
                UserConversationChatVC *obj  = (UserConversationChatVC *)self.currentVc;
                //check if play is playing
                if (obj.isPlayAll) {
                    //then stop play all and listen this alarm
                    obj.isStoppedForceFully = TRUE;
                    [appDelegate ClosePopUpWithoutUI];
                    [obj removeAnimationFromSuperView ];
                    obj.isPlayAll = FALSE;
                }
            }
            //              */
			[self showAPNSAudioLoader];
            NSURL *url;
            //changed by viral /*
            BOOL exists = [self.dic_APNS objectForKey:@"IsFromRequest"] != nil;//This key will come when playing from scheduled reminder

            if ([[DataValidation checkNullString:[self.dic_APNS valueForKey:NOTIF_Category]] isEqualToString:LOCALNOTIF_RECORDED] && exists) {
                
                if ([[self.dic_APNS valueForKey:@"IsFromRequest"] boolValue]) {
                    url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self.dic_APNS valueForKey:NOTIF_AUDIO_PATH]]];
                }
                else{
                    url = [[NSURL alloc] initFileURLWithPath:[self.dic_APNS valueForKey:NOTIF_AUDIO_PATH]];
                }
            }
            else{
                url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self.dic_APNS valueForKey:NOTIF_AUDIO_PATH]]];
            }
			// */
            
			[self performSelector:@selector(playSoundForURL:) withObject:url afterDelay:0.1];
			url = nil;
		}
	}
	else if (alertView.tag == 2){
		//rec friend req
		[Validation clearImageCache];
		
		if (buttonIndex == alertView.cancelButtonIndex) {
			
		}
		else{
			if ([self.currentVc isKindOfClass:[OtherFriendNotifListVC class]]) {
				OtherFriendNotifListVC *obj = (OtherFriendNotifListVC *)self.currentVc;
				obj.pageCounter = 1;
				obj.isDataNull = NO;
				[obj.arrData removeAllObjects];
				[obj performSelectorInBackground:@selector(getRequestList) withObject:nil];
			}
			else{
				//in other view
//				UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//				OtherFriendNotifListVC *ivc = [storyboard instantiateViewControllerWithIdentifier:OTHER_FRNDREQ_NOTIF_LIST_VC];
//								
//				[(UINavigationController*)self.window.rootViewController pushViewController:ivc animated:NO];
                self.selectedMenuIndex = 2;
  //              UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                SWRevealViewController *ivc = [MainStoryboard instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
                
                [UIView transitionWithView:self.navigationController.view
                                  duration:0.5
                                   options:UIViewAnimationOptionTransitionCrossDissolve
                                animations:^{
                                    [self.navigationController pushViewController:ivc animated:NO];
                                }
                                completion:nil];

			}
		}
	}
	else if (alertView.tag == 3){
		//accepted
	}
}

-(void)showAPNSAudioLoader{
	
	if (self.toastAPNS != nil) {
		[self.toastAPNS removeFromSuperview];
	//	[self.toastAPNS release];
		self.toastAPNS = nil;
	}
	
	self.toastAPNS = [[ToastMessageView alloc] initWithFrame:CGRectMake(0, 0, DEVICE_WIDTH, DEVICE_HEIGHT)];
	
	[self.toastAPNS ShowLoader];
	[self.navigationController.visibleViewController.view addSubview:self.toastAPNS];
}

-(void)getMicePermission{
    
	NSError *error;
	[[AVAudioSession sharedInstance] setCategory:
	 AVAudioSessionCategoryPlayAndRecord error:&error];
	[[AVAudioSession sharedInstance] requestRecordPermission:^(BOOL response){
		if (!response) {
			//	NSLog(@"Microphone mute");
		}
	}];
}

-(void)initializeAnimationArray{
    if (self.arrAnimation == nil){
        self.arrAnimation = [[NSMutableArray alloc] init];
        for (int i = 1 ; i<=28; i++) {
            [self.arrAnimation addObject:[UIImage imageNamed:[NSString stringWithFormat:@"player_loader_%d.png",i]]];
        }
    }
    
    if (self.isPlayingFromPopUp) {
        Validation.apnsReplyPopUp.imgPlayAnimation.animationImages = self.arrAnimation;
        Validation.apnsReplyPopUp.imgPlayAnimation.animationRepeatCount = 0;
    }
    else{
        self.imgPlayAnimation.animationImages = self.arrAnimation;
        self.imgPlayAnimation.animationRepeatCount = 0;
    }
}

-(void)conitnuePlayAnimationInView:(id)viewToPlayAnimationIn{
    if ([viewToPlayAnimationIn isKindOfClass:[UIImageView class]]) {
        UIImageView *img = (UIImageView *)viewToPlayAnimationIn;
        [self.imgPlayAnimation setFrame:CGRectMake(0, 0, img.frame.size.width,img.frame.size.height)];
        // self.imgPlayAnimation.center = img.center;
        [img addSubview:self.imgPlayAnimation];
    }
    else if ([viewToPlayAnimationIn isKindOfClass:[UIButton class]]){
        UIButton *img = (UIButton *)viewToPlayAnimationIn;
        [self.imgPlayAnimation setFrame:CGRectMake(0, 0, img.frame.size.width,img.frame.size.height)];
        //   self.imgPlayAnimation.center = img.center;
        [img addSubview:self.imgPlayAnimation];
        [img bringSubviewToFront:self.imgPlayAnimation];
    }
}

-(void)playSoundWithoutUIForURL:(NSURL *)url{    //inView:(id)viewToPlayAnimationIn{
    if ([self isHeadsetPluggedIn]) {
//        [self getMicePermission];
    }
    [self closeNotificationPopup:nil];
  
    if (self.player) {
		[self.player pause];
		[self.player removeObserver:self forKeyPath:kRateKey];
		[self.player removeObserver:self forKeyPath:kStatusKey];
		[[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
		self.player = nil;
	}
    NSLog(@"%@",[url absoluteString]);
    AVPlayerItem *playerItem = [AVPlayerItem playerItemWithURL:url];
    AVPlayer *player = [[AVPlayer alloc]initWithURL:url];
    player = [AVPlayer playerWithPlayerItem:playerItem];
    self.player = player;
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(audioPlayerDidFinishPlaying)
                                                 name:AVPlayerItemDidPlayToEndTimeNotification
                                               object:[self.player currentItem]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(audioPlayerDidFinishPlaying)
                                                 name:AVPlayerItemFailedToPlayToEndTimeErrorKey
                                               object:[self.player currentItem]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(audioPlayerDidFinishPlaying)
                                                 name:AVPlayerItemFailedToPlayToEndTimeNotification
                                               object:[self.player currentItem]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleAudioSessionInterruption:)
                                                 name:AVAudioSessionInterruptionNotification
                                               object:[self.player currentItem]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleMediaServicesReset)
                                                 name:AVAudioSessionMediaServicesWereResetNotification
                                               object:[self.player currentItem]];

    [self.player setVolume:1.0];
    
    for (UIView *view in [self.volumeView subviews]){
        if ([[[view class] description] isEqualToString:@"MPVolumeSlider"]) {
            self.volumeSlider = (UISlider *) view;
            NSLog(@"%f",self.volumeSlider.value);
            if (self.volumeSlider.value == 0) {
                [self.volumeSlider setValue:0.5];
            }
        }
    }
	
    [self.player addObserver:self
				  forKeyPath:kRateKey
					 options:NSKeyValueObservingOptionInitial | NSKeyValueObservingOptionNew
					 context:AVPlayerDemoPlaybackViewControllerRateObservationContext];
	
	[self.player addObserver:self
				  forKeyPath:kStatusKey
					 options:NSKeyValueObservingOptionInitial | NSKeyValueObservingOptionNew
					 context:AVPlayerDemoPlaybackViewControllerStatusObservationContext];
}

-(void)ClosePopUpWithoutUI{
    [self.imgPlayAnimation stopAnimating];
    [self.imgPlayAnimation setHidden:YES];
    if (self.player) {
        [self.player pause];
    }
    [self.player pause];
    [self.player removeObserver:self forKeyPath:kRateKey];
    [self.player removeObserver:self forKeyPath:kStatusKey];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
    self.player = nil;
}
-(void)ClosePopUpWithoutUIFromFrienRequest{
//    [self.imgPlayAnimation stopAnimating];
//    [self.imgPlayAnimation setHidden:YES];
    if (self.player) {
        [self.player pause];
    }
    [self.player pause];
    [self.player removeObserver:self forKeyPath:kRateKey];
    [self.player removeObserver:self forKeyPath:kStatusKey];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
    self.player = nil;
}
/*
-(void)playSoundForURL:(NSURL *)url{
	if ([self isHeadsetPluggedIn]) {
//        [self getMicePermission];
    }
    [self ClosePopUpWithoutUI];
    self.isPlayingFromPopUp = YES;
	[self initializeAnimationArray];
    //[self.validation.apnsReplyPopUp.btnPlayPause setImage:[UIImage imageNamed:Btn_Pause] forState:UIControlStateNormal];
    [self.validation.apnsReplyPopUp.btnPlayPause setHidden:YES];
    [self.validation.apnsReplyPopUp.imgPlayAnimation setHidden:YES];
    [Validation.apnsReplyPopUp.imgPlayAnimation stopAnimating];
    [self.validation.apnsReplyPopUp.activityView setHidden:NO];
    [self.validation.apnsReplyPopUp.activityView startAnimating];
    
    
	if (self.player) {
		[self.player pause];
		[self.player removeObserver:self forKeyPath:kRateKey];
		[self.player removeObserver:self forKeyPath:kStatusKey];
		[[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
		self.player = nil;
	}
    //playing alarm     shreya  12-mar-2015 /////
    //so if this is UserConversation view and playAll is TRUE then stop play all
    if ([self.currentVc isKindOfClass:[UserConversationChatVC class]]) {
        UserConversationChatVC *obj  = (UserConversationChatVC *)self.currentVc;
        //check if play is playing
        if (obj.isPlayAll) {
            //then stop play all and listen this alarm
            obj.isStoppedForceFully = TRUE;
            [appDelegate ClosePopUpWithoutUI];
            [obj removeAnimationFromSuperView];
            obj.isPlayAll = FALSE;
        }
    }
    //      //////
    
    AVPlayer *player;
    //changed by viral /////////
    BOOL exists = [self.dic_APNS objectForKey:@"IsFromRequest"] != nil;//This key will come when playing from scheduled reminder

    if ([[DataValidation checkNullString:[self.dic_APNS valueForKey:NOTIF_Category]] isEqualToString:LOCALNOTIF_RECORDED] && exists) {
        NSLog(@"url playing...... %@",[url absoluteString]);
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:[url absoluteString]]) {
            NSLog(@"file exist to play...");
        }
        else{
            NSLog(@"file does not exist to play...");
        }
        AVAsset *eightBarAsset = [AVAsset assetWithURL:url];
        AVPlayerItem *eightBarsPlayerItem = [[AVPlayerItem alloc] initWithAsset:eightBarAsset];
        player = [[AVPlayer alloc] initWithPlayerItem:eightBarsPlayerItem];
    }
    else{
        player = [[AVPlayer alloc]initWithURL:url];
    }
    // //////
    self.player = player;
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(audioPlayerDidFinishPlaying)
                                                 name:AVPlayerItemDidPlayToEndTimeNotification
                                               object:[self.player currentItem]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(audioPlayerDidFinishPlaying)
                                                 name:AVPlayerItemFailedToPlayToEndTimeErrorKey
                                               object:[self.player currentItem]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(audioPlayerDidFinishPlaying)
                                                 name:AVPlayerItemFailedToPlayToEndTimeNotification
                                               object:[self.player currentItem]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleAudioSessionInterruption:)
                                                 name:AVAudioSessionInterruptionNotification
                                               object:[self.player currentItem]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleMediaServicesReset)
                                                 name:AVAudioSessionMediaServicesWereResetNotification
                                               object:[self.player currentItem]];

    [self.player setVolume:1.0];
    
    for (UIView *view in [self.volumeView subviews]){
        if ([[[view class] description] isEqualToString:@"MPVolumeSlider"]) {
            self.volumeSlider = (UISlider *) view;
            NSLog(@"%f",self.volumeSlider.value);
            if (self.volumeSlider.value == 0) {
                [self.volumeSlider setValue:0.5];
            }
        }
    }
	
    [self.player addObserver:self
				  forKeyPath:kRateKey
					 options:NSKeyValueObservingOptionInitial | NSKeyValueObservingOptionNew
					 context:AVPlayerDemoPlaybackViewControllerRateObservationContext];
	
	[self.player addObserver:self
				  forKeyPath:kStatusKey
					 options:NSKeyValueObservingOptionInitial | NSKeyValueObservingOptionNew
					 context:AVPlayerDemoPlaybackViewControllerStatusObservationContext];
}
*/
-(void)playSoundForURL:(NSURL *)url{
    if ([self isHeadsetPluggedIn]) {
        //        [self getMicePermission];
    }
    [self ClosePopUpWithoutUI];
    self.isPlayingFromPopUp = YES;
    [self initializeAnimationArray];
    //[self.validation.apnsReplyPopUp.btnPlayPause setImage:[UIImage imageNamed:Btn_Pause] forState:UIControlStateNormal];
    [self.validation.apnsReplyPopUp.btnPlayPause setHidden:YES];
    [self.validation.apnsReplyPopUp.imgPlayAnimation setHidden:YES];
    [Validation.apnsReplyPopUp.imgPlayAnimation stopAnimating];
    [self.validation.apnsReplyPopUp.activityView setHidden:NO];
    [self.validation.apnsReplyPopUp.activityView startAnimating];
    
    
    if (self.player) {
        [self.player pause];
        [self.player removeObserver:self forKeyPath:kRateKey];
        [self.player removeObserver:self forKeyPath:kStatusKey];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
        self.player = nil;
    }
    //playing alarm     shreya  12-mar-2015 /*
    //so if this is UserConversation view and playAll is TRUE then stop play all
    if ([self.currentVc isKindOfClass:[UserConversationChatVC class]]) {
        UserConversationChatVC *obj  = (UserConversationChatVC *)self.currentVc;
        //check if play is playing
        if (obj.isPlayAll) {
            //then stop play all and listen this alarm
            obj.isStoppedForceFully = TRUE;
            [appDelegate ClosePopUpWithoutUI];
            [obj removeAnimationFromSuperView];
            obj.isPlayAll = FALSE;
        }
    }
    //      */
    
    //changed by viral /*
    BOOL exists = [self.dic_APNS objectForKey:@"IsFromRequest"] != nil;//This key will come when playing from scheduled reminder
    
    if ([[DataValidation checkNullString:[self.dic_APNS valueForKey:NOTIF_Category]] isEqualToString:LOCALNOTIF_RECORDED] && exists) {
        NSLog(@"url playing...... %@",[url absoluteString]);
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:[url absoluteString]]) {
            NSLog(@"file exist to play...");
        }
        else{
            NSLog(@"file does not exist to play...");
        }
        
        AVPlayerItem *playerItem = [AVPlayerItem playerItemWithURL:url];
        AVPlayer * player = [[AVPlayer alloc]initWithURL:url];
        player = [AVPlayer playerWithPlayerItem:playerItem];
        self.player = player;
        
        
        //        AVAsset *eightBarAsset = [AVAsset assetWithURL:url];
        //        AVPlayerItem *eightBarsPlayerItem = [[AVPlayerItem alloc] initWithAsset:eightBarAsset];
        //        player = [[AVPlayer alloc] initWithPlayerItem:eightBarsPlayerItem];
    }
    else{
        //player = [[AVPlayer alloc]initWithURL:url];
        AVPlayerItem *playerItem = [AVPlayerItem playerItemWithURL:url];
        AVPlayer * player = [[AVPlayer alloc]initWithURL:url];
        player = [AVPlayer playerWithPlayerItem:playerItem];
        self.player = player;
    }
    // */
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(audioPlayerDidFinishPlaying)
                                                 name:AVPlayerItemDidPlayToEndTimeNotification
                                               object:[self.player currentItem]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(audioPlayerDidFinishPlaying)
                                                 name:AVPlayerItemFailedToPlayToEndTimeErrorKey
                                               object:[self.player currentItem]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(audioPlayerDidFinishPlaying)
                                                 name:AVPlayerItemFailedToPlayToEndTimeNotification
                                               object:[self.player currentItem]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleAudioSessionInterruption:)
                                                 name:AVAudioSessionInterruptionNotification
                                               object:[self.player currentItem]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleMediaServicesReset)
                                                 name:AVAudioSessionMediaServicesWereResetNotification
                                               object:[self.player currentItem]];
    
    [self.player setVolume:1.0];
    
    for (UIView *view in [self.volumeView subviews]){
        if ([[[view class] description] isEqualToString:@"MPVolumeSlider"]) {
            self.volumeSlider = (UISlider *) view;
            NSLog(@"%f",self.volumeSlider.value);
            if (self.volumeSlider.value == 0) {
                [self.volumeSlider setValue:0.5];
            }
        }
    }
    
    [self.player addObserver:self
                  forKeyPath:kRateKey
                     options:NSKeyValueObservingOptionInitial | NSKeyValueObservingOptionNew
                     context:AVPlayerDemoPlaybackViewControllerRateObservationContext];
    
    [self.player addObserver:self
                  forKeyPath:kStatusKey
                     options:NSKeyValueObservingOptionInitial | NSKeyValueObservingOptionNew
                     context:AVPlayerDemoPlaybackViewControllerStatusObservationContext];
}
-(void)stopPlayingConversationSoundFile{
    
}
-(void)audioPlayerDidFinishPlaying{
    
	NSLog(@"finish playing");
    if (self.isPlayingFromPopUp) {
        [self.validation.apnsReplyPopUp.btnPlayPause setImage:[UIImage imageNamed:BtnNotifUnRead] forState:UIControlStateNormal];
        [self.validation.apnsReplyPopUp.btnPlayPause setHidden:NO];
        [self.validation.apnsReplyPopUp.imgPlayAnimation setHidden:YES];
        [Validation.apnsReplyPopUp.imgPlayAnimation stopAnimating];
    }
    else{
        [self ClosePopUpWithoutUI];
    }
    
	[self.player removeObserver:self forKeyPath:kRateKey];
	[self.player removeObserver:self forKeyPath:kStatusKey];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
	self.player = nil;
	   
	[self.toastAPNS removeFromSuperview];
//	[self.toastAPNS release];
	self.toastAPNS = nil;
	if ([self.currentVc isKindOfClass:[NotificationVC class]]) {
		NotificationVC *obj = (NotificationVC *)self.currentVc;
		[obj.activityLoading stopAnimating];
	}
    
    if ([self.currentVc isKindOfClass:[UserConversationChatVC class]]) {
        [self.currentVc removeAnimationFromSuperView];
//        if ([self.currentVc isPlayAll]) {
//            [self.currentVc removeAnimationFromSuperView];
//        }
    }
    if ([self.currentVc isKindOfClass:[HBlabConversation class]]) {
        [self.currentVc removeAnimationFromSuperView];
    }
    if ([self.currentVc isKindOfClass:[OtherFriendNotifListVC class]]) {
        [self.currentVc removeAnimationFromSuperView];
    }
}

-(void)PlayAgain{
    [self.player play];
}

- (void)observeValueForKeyPath:(NSString*) path
					  ofObject:(id)object
						change:(NSDictionary*)change
					   context:(void*)context
{
    if ([path isEqualToString:@"rate"])
    {
        if (self.isPlaying) {
            if (self.player.rate == 0 && CMTimeGetSeconds(self.player.currentItem.duration) != CMTimeGetSeconds(self.player.currentItem.currentTime) )  //&& self.videoPlaying)
            {
                CMTime currentTime = self.player.currentItem.currentTime; //playing time
                NSLog(@"PlayedSeconds = %f",CMTimeGetSeconds(currentTime));
                
                CMTime duration = self.player.currentItem.duration; //total time
                NSLog(@"totalTime = %f", CMTimeGetSeconds(duration));
                
                if (CMTimeCompare(currentTime, duration) == 1) {
                    //current time> total
                    self.isPlaying = FALSE;
                    [self audioPlayerDidFinishPlaying];
                }
                else{
                    if (((int)(CMTimeGetSeconds(currentTime)) % 5) == 0) {
                        [self.player play];
                        [self.player setVolume:1.0];
                        for (UIView *view in [self.volumeView subviews]){
                            if ([[[view class] description] isEqualToString:@"MPVolumeSlider"]) {
                                self.volumeSlider = (UISlider *) view;
                                if (self.volumeSlider.value == 0) {
                                    [self.volumeSlider setValue:0.5];
                                }
                            }
                        }
                    }
                    else{
                        
                        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(PlayAgain) userInfo:nil repeats:NO];
                    }
                }
            }
        }
    }

	/* AVPlayerItem "status" property value observer. */
	if (context == AVPlayerDemoPlaybackViewControllerRateObservationContext)
	{
		NSLog(@">>>>>>>>>>>>>>>>>>>> AVPlayerDemoPlaybackViewControllerRateObservationContext");
//        CMTime duration = self.player.currentItem.duration; //total time
//        CMTime currentTime = self.player.currentItem.currentTime; //playing time
//        NSLog(@"totalTime = %f", CMTimeGetSeconds(duration));
//        NSLog(@"PlayedSeconds = %f",CMTimeGetSeconds(currentTime));
        

	}
	else if (context == AVPlayerDemoPlaybackViewControllerStatusObservationContext)
	{
		NSLog(@"========> AVPlayerDemoPlaybackViewControllerStatusObservationContext");
        AVPlayerStatus status = [[change objectForKey:NSKeyValueChangeNewKey] integerValue];
        switch (status)
        {
				/* Indicates that the status of the player is not yet known because
				 it has not tried to load new media resources for playback */
            case AVPlayerStatusUnknown:
            {
				NSLog(@"AVPlayerStatusUnknown");
            }
				break;
                
            case AVPlayerStatusReadyToPlay:
            {
                /* Once the AVPlayerItem becomes ready to play, i.e.
                 [playerItem status] == AVPlayerItemStatusReadyToPlay,
                 its duration can be fetched from the item. */
                NSLog(@"ready to play");
//                CMTime duration = self.player.currentItem.duration; //total time
//                CMTime currentTime = self.player.currentItem.currentTime; //playing time
//                NSLog(@"totalTime = %f", CMTimeGetSeconds(duration));
//                NSLog(@"PlayedSeconds = %f",CMTimeGetSeconds(currentTime));
                
				[self.player play];
                [self.player setVolume:1.0];
                
                self.isPlaying = TRUE;
                if (!self.isPlayingFromPopUp) {
                        [self.imgPlayAnimation setHidden:NO];
                }
                else{
                    [Validation.apnsReplyPopUp.btnPlayPause setHidden:YES];
                    [self.validation.apnsReplyPopUp.activityView stopAnimating];
                    [Validation.apnsReplyPopUp.imgPlayAnimation setHidden:NO];
                    [Validation.apnsReplyPopUp.imgPlayAnimation startAnimating];
                }
                
                for (UIView *view in [self.volumeView subviews]){
                    if ([[[view class] description] isEqualToString:@"MPVolumeSlider"]) {
                        self.volumeSlider = (UISlider *) view;
                        if (self.volumeSlider.value == 0) {
                            [self.volumeSlider setValue:0.5];
                        }
                    }
                }
            }
				break;
                
            case AVPlayerStatusFailed:
            {
				NSLog(@"AVPlayerStatusFailed");
			//	[HUD hide:YES];
            }
				break;
        }
	}
}
- (void)handleAudioSessionInterruption:(NSNotification*)notification {
    
    NSLog(@"handleAudioSessionInterruption");
    NSNumber *interruptionType = [[notification userInfo] objectForKey:AVAudioSessionInterruptionTypeKey];
    NSNumber *interruptionOption = [[notification userInfo] objectForKey:AVAudioSessionInterruptionOptionKey];
    
    switch (interruptionType.unsignedIntegerValue) {
        case AVAudioSessionInterruptionTypeBegan:{
            // • Audio has stopped, already inactive
            // • Change state of UI, etc., to reflect non-playing state
        } break;
        case AVAudioSessionInterruptionTypeEnded:{
            // • Make session active
            // • Update user interface
            // • AVAudioSessionInterruptionOptionShouldResume option
            if (interruptionOption.unsignedIntegerValue == AVAudioSessionInterruptionOptionShouldResume) {
                // Here you should continue playback.
                [self.player play];
            }
        } break;
        default:
            break;
    }
}
- (void)handleMediaServicesReset {
    NSLog(@"handleMediaServicesReset");
    // • No userInfo dictionary for this notification
    // • Audio streaming objects are invalidated (zombies)
    // • Handle this notification by fully reconfiguring audio
}
-(void)UserDeactivated_CallLogout{
    
	//[Validation showLoadingIndicator];
	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:DEVICE_TOKEN]],KeyValue,@"RegID",KeyName, nil],@"2",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:LOG_OUT withParameters:nil];
	ASIHTTPRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:FALSE];
    
	request.delegate = appDelegate;
	request.tag = 1;
	strUrl = nil;
}

-(void)callLogOutService{
    
//	[HUD hide:YES];
	[AlertHandler alertTitle:MESSAGE message:ACCOUNT_DEACTIVATED delegate:self tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
}
-(void)setNotifAsRead{
    
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
                         [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[self.dic_APNS valueForKey:@"ID"]],KeyValue,@"MsgID",KeyName, nil],@"2",
                         nil];
    
    NSString *strUrl = [WebServiceContainer getServiceURL:NOTIF_READ withParameters:nil];
    ASIHTTPRequest *request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
//    request.delegate = self;
    request.tag = 14;
    strUrl = nil;
}
- (void)requestFinished:(ASIHTTPRequest *)request{
    if (request.tag==1) {
        [Validation removeAllKeyValue];
        appDelegate.is_Login = NO;
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
	
	//[HUD hide:YES];
}

- (void)FailurResponseWithErroe:(NSError *)error{
    NSLog(@"Error = %@",error.description);
//    [HUD hide:YES];
}
#pragma mark LOCAL DB FUNCTIONS

-(void) dbconnect{
    // Setup some globals
    
    self.databaseName = @"Blabeey.sqlite";
    
    // Get the path to the documents directory and append the databaseName
    NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDir = [documentPaths objectAtIndex:0];
    self.databasePath = [documentsDir stringByAppendingPathComponent:self.databaseName];
    
    // Execute the “checkAndCreateDatabase” function
    NSLog(@"self.databasePath %@",self.databasePath);
    [self checkAndCreateDatabase];
}
-(void) checkAndCreateDatabase{
    // Check if the SQL database has already been saved to the users phone, if not then copy it over
    BOOL success;
    
    // Create a FileManager object, we will use this to check the status
    // of the database and to copy it over if required
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    // Check if the database has already been created in the users filesystem
    success = [fileManager fileExistsAtPath:self.databasePath];
    
    // If the database already exists then return without doing anything
    if(success) {
        //[fileManager removeFileAtPath:databasePath handler:nil]; //************************************************************
        NSLog(@"db file already created");
        return;
    }
    // If not then proceed to copy the database from the application to the users filesystem
    
    // Get the path to the database in the application package
    NSString *databasePathFromApp = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:self.databaseName];
    
    // Copy the database from the package to the users filesystem
    NSError *error;
    
    [fileManager copyItemAtPath:databasePathFromApp toPath:self.databasePath error:&error];
    
    
    NSLog(@"error.description %@",error.description);
    
}
-(NSString *)InfoSaveAlarm:(NSDictionary *)dicSel{
    sqlite3 *database;
    if(sqlite3_open([self.databasePath UTF8String], &database) == SQLITE_OK) {
        const char* sql = "INSERT INTO AlarmRecord (AlarmRecord_Cname,AlarmRecord_Alarmname,AlarmRecord_TypeID,AlarmRecord_Alarmdate,AlarmRecord_Alarmtime,AlarmRecord_PhotoPath,AlarmRecord_Name,AlarmRecord_Createdby,AlarmRecord_IsFromRequest,AlarmRecord_Createdbyphotopath,AlarmRecord_ContentID,AlarmRecord_SoundPath,AlarmRecord_RandomSoundID,AlarmRecord_AlarmDateTime,AlarmRecord_SelectedAlertOptionIndex,AlarmRecord_SelectedRepeatOptionIndex) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      
        sqlite3_stmt *statement;
        
        if(sqlite3_prepare_v2(database, sql, -1, &statement, NULL) == SQLITE_OK) {
            int a1 = sqlite3_bind_text(statement, 1, [[dicSel valueForKey:NOTIF_Category] UTF8String], -1, SQLITE_TRANSIENT);
            int a2 = sqlite3_bind_text(statement, 2, [[dicSel valueForKey:@"Alarmname"] UTF8String], -1, SQLITE_TRANSIENT);
            int a3 = sqlite3_bind_text(statement, 3, [[dicSel valueForKey:@"TypeID"] UTF8String], -1, SQLITE_TRANSIENT);
            int a4 = sqlite3_bind_text(statement, 4, [[dicSel valueForKey:@"Alarmdate"] UTF8String], -1, SQLITE_TRANSIENT);
            int a5 = sqlite3_bind_text(statement, 5, [[dicSel valueForKey:@"Alarmtime"] UTF8String], -1, SQLITE_TRANSIENT);
            int a6 = sqlite3_bind_text(statement, 6, [[dicSel valueForKey:@"PhotoPath"] UTF8String], -1, SQLITE_TRANSIENT);
            int a7 = sqlite3_bind_text(statement, 7, [[dicSel valueForKey:@"Name"] UTF8String], -1, SQLITE_TRANSIENT);
            int a8 = sqlite3_bind_text(statement, 8, [[dicSel valueForKey:@"Createdby"] UTF8String], -1, SQLITE_TRANSIENT);
            int a9 = sqlite3_bind_text(statement, 9, [[dicSel valueForKey:@"IsFromRequest"] UTF8String], -1, SQLITE_TRANSIENT);
            int a10 = sqlite3_bind_text(statement, 10, [[dicSel valueForKey:@"Createdbyphotopath"] UTF8String], -1, SQLITE_TRANSIENT);
            int a11 = sqlite3_bind_text(statement, 11, [[NSString stringWithFormat:@"%@",[dicSel valueForKey:@"ContentID"]] UTF8String], -1, SQLITE_TRANSIENT);
            int a12 = sqlite3_bind_text(statement, 12, [[dicSel valueForKey:@"SoundPath"] UTF8String], -1, SQLITE_TRANSIENT);
            int a13 = sqlite3_bind_text(statement, 13, [[NSString stringWithFormat:@"%@",[dicSel valueForKey:@"RandomSoundID"]] UTF8String], -1, SQLITE_TRANSIENT);
            int a14 = sqlite3_bind_text(statement, 14, [[NSString stringWithFormat:@"%@ %@",[dicSel valueForKey:@"Alarmdate"],[dicSel valueForKey:@"Alarmtime"]] UTF8String], -1, SQLITE_TRANSIENT);
            NSLog(@"appdel<<<--->>> %@ %@",[dicSel valueForKey:@"SelectedAlertOptionIndexpath"],[dicSel valueForKey:@"SelectedRepeatOptionIndexpath"]);
            NSString *str1,*str2;
            if ([DataValidation checkNullString:[dicSel valueForKey:@"SelectedAlertOptionIndexpath"]].length==0) {
                str1 = @"";
            }
            else{
                str1 = [NSString stringWithFormat:@"%@",[dicSel valueForKey:@"SelectedAlertOptionIndexpath"]];
            }
            if ([DataValidation checkNullString:[dicSel valueForKey:@"SelectedRepeatOptionIndexpath"]].length==0) {
                str2 = @"";
            }
            else{
                str2 = [NSString stringWithFormat:@"%@",[dicSel valueForKey:@"SelectedRepeatOptionIndexpath"]];
            }
            int a15 = sqlite3_bind_text(statement, 15, [str1 UTF8String], -1, SQLITE_TRANSIENT);
            int a16 = sqlite3_bind_text(statement, 16, [str2 UTF8String], -1, SQLITE_TRANSIENT);
            if (statement)
            {
                if (a1 != SQLITE_OK || a2 != SQLITE_OK || a3 != SQLITE_OK || a4 != SQLITE_OK || a5 != SQLITE_OK || a6 != SQLITE_OK || a7 != SQLITE_OK || a8 != SQLITE_OK || a9 != SQLITE_OK || a10 != SQLITE_OK || a11 != SQLITE_OK || a12 != SQLITE_OK || a13 != SQLITE_OK || a14 != SQLITE_OK || a15 != SQLITE_OK || a16 != SQLITE_OK)
                {
                    NSLog(@"%s",sqlite3_errmsg(database));
                    NSAssert1(0, @"Error while inserting data. '%s'", sqlite3_errmsg(database));

                    sqlite3_finalize(statement);
                    NSLog(@"not inserted");
                    return @"";
                }
                sqlite3_step(statement);
            }
            sqlite3_finalize(statement);
        }
        else {
            NSLog(@"%s",sqlite3_errmsg(database));
            NSAssert1(0, @"Error while inserting data. '%s'", sqlite3_errmsg(database));

        }
    }
    sqlite3_close(database);
//    [self.navigationController popViewControllerAnimated:YES];
    NSMutableArray *arrr = [[NSMutableArray alloc] init];
    [self selectAllAlarm:arrr];
    NSLog(@"arrrr ===========>>  %@",arrr);
    
    NSString *str = [self getAlarmid];
    return str;
}
-(NSString *) getAlarmid{
    sqlite3 *database;
    
    // Open the database from the users filessytem
    NSString *strlastid = @"0";
    if(sqlite3_open([self.databasePath UTF8String], &database) == SQLITE_OK) {
        
        // Setup the SQL Statement and compile it for faster access
        
        NSString *strSql = [NSString stringWithFormat:@"SELECT max(AlarmRecord_Id) FROM AlarmRecord"];
        
        const char *sqlStatement = [strSql UTF8String];
        
        sqlite3_stmt *compiledStatement;
        
        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
            
            // Loop through the results and add them to the feeds array
            
            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
                
                //                  Note: column number start from 0 we are taking terabitz id so we have used 1
                //Shreya: here app was crashing as it was returning 0 data
                
                int numberOfRows = sqlite3_column_int(compiledStatement, 0);
                if (numberOfRows > 0) {
                        strlastid = [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 0)];
                }
            }
        }
        
        // Release the compiled statement from memory
        
    }
    sqlite3_close(database);
    NSLog(@"getAlarmId = %@",strlastid);
    return strlastid;
}
-(void)selectAllAlarm:(NSMutableArray *)arrAlarm{
    
    sqlite3 *database;
//    arrAlarm=[[NSMutableArray alloc] init];
    
    // Open the database from the users filessytem
    
    if(sqlite3_open([self.databasePath UTF8String], &database) == SQLITE_OK) {
        
        // Setup the SQL Statement and compile it for faster access
        
        NSString *strSql = [NSString stringWithFormat:@"SELECT * FROM AlarmRecord order by AlarmRecord_AlarmDateTime asc"];
        NSLog(@"strSql==== %@",strSql);
        const char *sqlStatement = [strSql UTF8String];
        
        sqlite3_stmt *compiledStatement;
        
        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
            
            // Loop through the results and add them to the feeds array
            
            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
                
                //                  Note: column number start from 0 we are taking terabitz id so we have used 1
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                
                NSString *strAlarmRecordId= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 0)];
                [dic setValue:strAlarmRecordId forKey:@"Aid"];
                
                NSString *strcname= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 1)];
                [dic setValue:strcname forKey:NOTIF_Category];
                
                NSString *strAlarmname= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 2)];
                [dic setValue:strAlarmname forKey:@"Alarmname"];
                
                NSString *strTypeID= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 3)];
                [dic setValue:strTypeID forKey:@"TypeID"];
                
                NSString *strAlarmdate= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 4)];
                [dic setValue:strAlarmdate forKey:@"Alarmdate"];
                
                NSString *strAlarmtime= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 5)];
                [dic setValue:strAlarmtime forKey:@"Alarmtime"];
                
                NSString *strPhotoPath= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 6)];
                [dic setValue:strPhotoPath forKey:@"PhotoPath"];
                
                NSString *strName= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 7)];
                [dic setValue:strName forKey:@"Name"];
                
                NSString *strCreatedby= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 8)];
                [dic setValue:strCreatedby forKey:@"Createdby"];
                
                NSString *strIsFromRequest= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 9)];
                [dic setValue:strIsFromRequest forKey:@"IsFromRequest"];
                
                NSString *strCreatedbyphotopath= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 10)];
                [dic setValue:strCreatedbyphotopath forKey:@"Createdbyphotopath"];
                
                NSString *strContentID= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 11)];
                [dic setValue:strContentID forKey:@"ContentID"];
                
                NSString *strSoundPath= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 12)];
                [dic setValue:strSoundPath forKey:@"SoundPath"];
                
                NSString *strRandomSoundID= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 13)];
                [dic setValue:strRandomSoundID forKey:@"RandomSoundID"];
                
                NSString *strSelectedAlertOptionIndexpath= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 15)];
                [dic setValue:strSelectedAlertOptionIndexpath forKey:@"SelectedAlertOptionIndexpath"];
                
                NSString *strSelectedRepeatOptionIndexpath= [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(compiledStatement, 16)];
                [dic setValue:strSelectedRepeatOptionIndexpath forKey:@"SelectedRepeatOptionIndexpath"];
                
                [arrAlarm addObject:dic];
            }
            
        }
        
        // Release the compiled statement from memory
        
        }

        sqlite3_close(database);
}

-(BOOL)InfoDeleteAlarm:(NSDictionary *)dic{

    sqlite3 *database;
    if(sqlite3_open([self.databasePath UTF8String], &database) == SQLITE_OK) {
        NSString *strqu = [NSString stringWithFormat:@"DELETE FROM AlarmRecord WHERE AlarmRecord_Id = '%@'",[dic valueForKey:@"Aid"]];
        const char* sql = [strqu UTF8String];
        sqlite3_stmt *statement;

        if(sqlite3_prepare_v2(database, sql, -1, &statement, NULL) == SQLITE_OK) {
           if (statement)
           {
               if( sqlite3_step(statement) == SQLITE_DONE )
               {
                   return YES;
               }
               else
               {
                   NSLog( @"DeleteFromDataBase: Failed from sqlite3_step. Error is: %s", sqlite3_errmsg(database) );
                   return NO;
               }
           }
           sqlite3_finalize(statement);
        }
    }

    sqlite3_close(database);
    return NO;
}

-(BOOL)InfoUpdateAlarm:(NSDictionary *)dic{
    
    sqlite3 *database;
    if(sqlite3_open([self.databasePath UTF8String], &database) == SQLITE_OK) {
        NSString *strqu = [NSString stringWithFormat:@"UPDATE AlarmRecord Set AlarmRecord_Cname = ?, AlarmRecord_Alarmname = ?, AlarmRecord_TypeID = ?, AlarmRecord_Alarmdate = ?, AlarmRecord_Alarmtime = ?, AlarmRecord_PhotoPath = ?, AlarmRecord_Name = ?, AlarmRecord_Createdby = ?, AlarmRecord_IsFromRequest = ?, AlarmRecord_Createdbyphotopath = ?, AlarmRecord_ContentID = ?, AlarmRecord_SoundPath = ?, AlarmRecord_RandomSoundID = ?, AlarmRecord_AlarmDateTime WHERE AlarmRecord_Id = '%@'",[dic valueForKey:@"Aid"]];
        
        const char* sql = [strqu UTF8String];
        sqlite3_stmt *statement;

        
        if(sqlite3_prepare_v2(database, sql, -1, &statement, NULL) == SQLITE_OK) {
            sqlite3_bind_text(statement, 1, [[dic valueForKey:NOTIF_Category] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 2, [[dic valueForKey:@"Alarmname"] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 3, [[dic valueForKey:@"TypeID"] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 4, [[dic valueForKey:@"Alarmdate"] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 5, [[dic valueForKey:@"Alarmtime"] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 6, [[dic valueForKey:@"PhotoPath"] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 7, [[dic valueForKey:@"Name"] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 8, [[dic valueForKey:@"Createdby"] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 9, [[dic valueForKey:@"IsFromRequest"] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 10, [[dic valueForKey:@"Createdbyphotopath"] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 11, [[NSString stringWithFormat:@"%@",[dic valueForKey:@"ContentID"]] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 12, [[dic valueForKey:@"SoundPath"] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 13, [[NSString stringWithFormat:@"%@",[dic valueForKey:@"RandomSoundID"]] UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(statement, 14, [[NSString stringWithFormat:@"%@ %@",[dic valueForKey:@"Alarmdate"],[dic valueForKey:@"Alarmtime"]] UTF8String], -1, SQLITE_TRANSIENT);
        }
        
        
        char* errmsg;	
        sqlite3_exec(database, "COMMIT", NULL, NULL, &errmsg);
        
        if(SQLITE_DONE != sqlite3_step(statement)){
            NSLog( @"UpdateFromDataBase: Failed from sqlite3_step. Error is: %s", sqlite3_errmsg(database) );
            return NO;

        }
        else{
            return YES;
        }
        
        sqlite3_finalize(statement);
    }
    
    sqlite3_close(database);
    return NO;
}

- (void)InitiatePurchaseFromProdutIds:(NSArray *)arrProducts andPrice:(NSString *)value {
    
    //	NSLog(@"value = %@",value);
    
    SKProduct *product = nil;
    if (arrProducts == nil) {
        [self.currentVc Hideloader];
        //        HIDE_LOADER
        //        [CustomAlert HeaderTitle:MESSAGE message:@"Cannot process your transaction." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK otherButtonTitle:nil];
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:MESSAGE message:@"Cannot process your transaction." delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
    }
    else{
        if (arrProducts.count>0) {
            if ([value isEqualToString:@"0.99"] ) {
                product = arrProducts[0];
            }
            else if ([value isEqualToString:@"1.99"] ) {
                product = arrProducts[1];
            }
            else if ([value isEqualToString:@"2.99"] ) {
                product = arrProducts[2];
            }
            else if ([value isEqualToString:@"3.99"] ) {
                product = arrProducts[3];
            }
            else if ([value isEqualToString:@"4.99"] ) {
                product = arrProducts[4];
            }
            
            //    NSLog(@"Buying %@...", product.productIdentifier);
            [[RageIAPHelper sharedInstance] buyProduct:product];
        }
        else{
            HIDE_LOADER
            //            [CustomAlert HeaderTitle:MESSAGE message:@"Cannot process your transaction." delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK otherButtonTitle:nil];
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:MESSAGE message:@"Cannot process your transaction." delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
        }
    }
}

-(BOOL)InfoDeleteAllAlarm{
    sqlite3 *database;
    if(sqlite3_open([self.databasePath UTF8String], &database) == SQLITE_OK) {
        NSString *strqu = [NSString stringWithFormat:@"DELETE FROM AlarmRecord"];
        const char* sql = [strqu UTF8String];
        sqlite3_stmt *statement;
        
        if(sqlite3_prepare_v2(database, sql, -1, &statement, NULL) == SQLITE_OK) {
            if (statement)
            {
                if( sqlite3_step(statement) == SQLITE_DONE )
                {
                    return YES;
                }
                else
                {
                    NSLog( @"DeleteFromDataBase: Failed from sqlite3_step. Error is: %s", sqlite3_errmsg(database) );
                    return NO;
                }
            }
            sqlite3_finalize(statement);
        }
    }
    
    sqlite3_close(database);
    return NO;
}


@end

/*
@implementation TWAppDelegateDemoStyleSheet

#pragma mark - Alloc/Init

+ (TWAppDelegateDemoStyleSheet *)styleSheet
{
    return [[TWAppDelegateDemoStyleSheet alloc] init];
}

#pragma mark - TWMessageBarStyleSheet

- (UIColor *)backgroundColorForMessageType:(TWMessageBarMessageType)type
{
    UIColor *backgroundColor = nil;
    switch (type)
    {
        case TWMessageBarMessageTypeError:
            backgroundColor = [UIColor colorWithRed:1.0 green:0.0 blue:0.0 alpha:0.75];
            break;
        case TWMessageBarMessageTypeSuccess:
            backgroundColor = [UIColor colorWithRed:0.0 green:1.0 blue:0.0 alpha:0.75];
            break;
        case TWMessageBarMessageTypeInfo:
            backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:1.0 alpha:0.75];
            break;
        default:
            break;
    }
    return backgroundColor;
}

- (UIColor *)strokeColorForMessageType:(TWMessageBarMessageType)type
{
    UIColor *strokeColor = nil;
    switch (type)
    {
        case TWMessageBarMessageTypeError:
            strokeColor = [UIColor colorWithRed:1.0 green:0.0 blue:0.0 alpha:1.0];
            break;
        case TWMessageBarMessageTypeSuccess:
            strokeColor = [UIColor colorWithRed:0.0 green:1.0 blue:0.0 alpha:1.0];
            break;
        case TWMessageBarMessageTypeInfo:
            strokeColor = [UIColor colorWithRed:0.0 green:0.0 blue:1.0 alpha:1.0];
            break;
        default:
            break;
    }
    return strokeColor;
}

- (UIImage *)iconImageForMessageType:(TWMessageBarMessageType)type
{
    UIImage *iconImage = nil;
    switch (type)
    {
        case TWMessageBarMessageTypeError:
            iconImage = [UIImage imageNamed:kAppDelegateDemoStyleSheetImageIconError];
            break;
        case TWMessageBarMessageTypeSuccess:
            iconImage = [UIImage imageNamed:kAppDelegateDemoStyleSheetImageIconSuccess];
            break;
        case TWMessageBarMessageTypeInfo:
            iconImage = [UIImage imageNamed:kAppDelegateDemoStyleSheetImageIconInfo];
            break;
        default:
            break;
    }
    return iconImage;
}

- (UIFont *)titleFontForMessageType:(TWMessageBarMessageType)type
{
    return [UIFont fontWithName:@"AvenirNext-DemiBold" size:16.0f];
}

- (UIFont *)descriptionFontForMessageType:(TWMessageBarMessageType)type
{
    return [UIFont fontWithName:@"AvenirNext-Regular" size:14.0f];
}

- (UIColor *)titleColorForMessageType:(TWMessageBarMessageType)type
{
    return [UIColor blackColor];
}

- (UIColor *)descriptionColorForMessageType:(TWMessageBarMessageType)type
{
    return [UIColor purpleColor];
}
 
@end
*/


/*

 - (void)btnShareClicked:(id)sender {
 UIButton *btn = ((UIButton *)sender);
 NSLog(@"%d",(int)btn.tag);
 
 if (![[[self.arrData objectAtIndex:btn.tag] valueForKey:IS_PRIVATE] boolValue]) {
 self.selectedIndex = (int)btn.tag;
 if (self.objShareVC == nil) {
 UIStoryboard *storyBoard=  [UIStoryboard storyboardWithName:@"Main" bundle:nil];
 self.objShareVC = [storyBoard instantiateViewControllerWithIdentifier:SOCIAL_SHARE_VC];
 self.objShareVC.viewContainer.tag = btn.tag;
 self.objShareVC.delegate = self;
 self.objShareVC.view.frame = self.view.frame;
 [self.view addSubview:self.objShareVC.view];
 [self.objShareVC didMoveToParentViewController:self];
 [self addChildViewController:self.objShareVC];
 }
 
 //fb
 UIButton *btnFb = (UIButton *)[self.objShareVC.viewContainer viewWithTag:1];      //fb
 [btnFb removeTarget:self action:@selector(shareWithFBClicked:) forControlEvents:UIControlEventTouchUpInside];
 [btnFb addTarget:self action:@selector(shareWithFBClicked:) forControlEvents:UIControlEventTouchUpInside];
 
 //twitter
 UIButton *btnTwitter = (UIButton *)[self.objShareVC.viewContainer viewWithTag:2];      //twitter
 [btnTwitter removeTarget:self action:@selector(shareWithTwitterClicked:) forControlEvents:UIControlEventTouchUpInside];
 [btnTwitter addTarget:self action:@selector(shareWithTwitterClicked:) forControlEvents:UIControlEventTouchUpInside];
 
 //mail
 UIButton *btnMail = (UIButton *)[self.objShareVC.viewContainer viewWithTag:3];      //twitter
 [btnMail removeTarget:self action:@selector(ShareThroughMail:) forControlEvents:UIControlEventTouchUpInside];
 [btnMail addTarget:self action:@selector(ShareThroughMail:) forControlEvents:UIControlEventTouchUpInside];
 
 //sms
 UIButton *btnMessage = (UIButton *)[self.objShareVC.viewContainer viewWithTag:4];      //twitter
 [btnMessage removeTarget:self action:@selector(ShareThroughSMS:) forControlEvents:UIControlEventTouchUpInside];
 [btnMessage addTarget:self action:@selector(ShareThroughSMS:) forControlEvents:UIControlEventTouchUpInside];
 
 btnFb.tag = btn.tag;
 btnTwitter.tag = btn.tag;
 btnMail.tag = btn.tag;
 btnMessage.tag = btn.tag;
 
 }
 else{
 [Validation showToastMessage:@"You cannot share a private Blabeey!!" displayDuration:ERROR_MSG_DURATION];
 }
 }
 
 -(void)shareWithFBClicked:(id)sender{
 [self RemoveSocialViewFromSuperView];
 
 if (!FBSession.activeSession.isOpen) {
 // if the session is closed, then we open it here, and establish a handler for state changes
 [FBSession openActiveSessionWithReadPermissions:@[@"public_profile", @"email", @"user_friends"]
 allowLoginUI:YES
 completionHandler:^(FBSession *session,
 FBSessionState state,
 NSError *error) {
 if (error) {
 [HUD hide:YES];
 UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
 message:@"Could not get your Facebook data.\nPlease check you internet connectivity or try later."
 delegate:nil
 cancelButtonTitle:@"OK"
 otherButtonTitles:nil];
 [alertView show];
 } else if (session.isOpen) {
 NSLog(@"facebook login");
 [self PostOnFB:(int)((UIButton *)sender).tag];
 }
 }];
 return;
 }
 else if (FBSession.activeSession.isOpen) {
 NSLog(@"facebook activeSession.isOpen");
 [self PostOnFB:(int)((UIButton *)sender).tag];
 }
 }
 
 -(void)PostOnFB:(int)Index{
 NSString *strURL = [[self.arrData objectAtIndex:Index] valueForKey:NOTIF_AUDIO_PATH];
 
 FBLinkShareParams *params = [[FBLinkShareParams alloc] init];
 //    http://wwhhaazzuupp.com/content/content/6kkTrbUma2SIRbp8VY34cA==
 NSLog(@"%@",[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_ID]]);
 

// Replace("_", "+"));
// Replace("-","/");


NSString *strEncryptText = [Validation getEncryptedShareUrlId:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_ID]]];

params.link = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SHARE_URL,strEncryptText]];
params.name = @"Blabeey";
params.caption = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_Category]];

// If the Facebook app is installed and we can present the share dialog
if ([FBDialogs canPresentShareDialogWithParams:params]) {
    // Present the share dialog
    [FBDialogs presentShareDialogWithLink:params.link
                                  handler:^(FBAppCall *call, NSDictionary *results, NSError *error) {
                                      if(error) {
                                          // An error occurred, we need to handle the error
                                          // See: https://developers.facebook.com/docs/ios/errors
                                          NSLog(@"Error publishing story: %@", error.description);
                                      } else {
                                          // Success
                                          NSLog(@"result %@", results);
                                          if (![[results valueForKey:@"completionGesture"] isEqualToString:@"cancel"]) {
                                              [Validation showToastMessage:@"Successfully posted" displayDuration:SUCCESS_MSG_DURATION];
                                          }
                                          
                                      }
                                  }];
} else {
    // Present the feed dialog
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   @"Blabeey", @"name",
                                   [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_Category]], @"caption",
                                   //                                       @"Allow your users to share stories on Facebook from your app using the iOS SDK.", @"description",
                                   strURL, @"link",
                                   //                                       @"http://i.imgur.com/g3Qc1HN.png", @"picture",
                                   nil];
    
    // Show the feed dialog
    [FBWebDialogs presentFeedDialogModallyWithSession:nil
                                           parameters:params
                                              handler:^(FBWebDialogResult result, NSURL *resultURL, NSError *error) {
                                                  if (error) {
                                                      // An error occurred, we need to handle the error
                                                      // See: https://developers.facebook.com/docs/ios/errors
                                                      NSLog(@"Error publishing story: %@", error.description);
                                                  } else {
                                                      if (result == FBWebDialogResultDialogNotCompleted) {
                                                          // User cancelled.
                                                          NSLog(@"User cancelled.");
                                                      } else {
                                                          // Handle the publish feed callback
                                                          NSDictionary *urlParams = [Validation parseURLParams:[resultURL query]];
                                                          
                                                          if (![urlParams valueForKey:@"post_id"]) {
                                                              // User cancelled.
                                                              NSLog(@"User cancelled.");
                                                              
                                                          } else {
                                                              // User clicked the Share button
                                                              NSString *result = [NSString stringWithFormat: @"Posted story, id: %@", [urlParams valueForKey:@"post_id"]];
                                                              NSLog(@"result %@", result);
                                                          }
                                                      }
                                                  }
                                              }];
}

}

-(void)shareWithGooglePlusClicked:(id)sender{
    [self RemoveSocialViewFromSuperView];
}

-(void)shareWithPinterestClicked:(id)sender{
    [self RemoveSocialViewFromSuperView];
}

-(void)shareWithTwitterClicked:(id)sender{
    [self RemoveSocialViewFromSuperView];
    [self PostOnTwitter:(int)((UIButton *)sender).tag];
}

-(void)PostOnTwitter:(int)Index{
    
    
    SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
    SLComposeViewControllerCompletionHandler myBlock = ^(SLComposeViewControllerResult result){
        if (result == SLComposeViewControllerResultCancelled) {
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Cancelled" message:@"You Cancelled posting the Tweet." delegate:nil cancelButtonTitle:OK_BUTTON_TITLE otherButtonTitles: nil] ;
            
            [alert show];
            //       [alert release];
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Success" message:@"The Tweet was posted successfully." delegate:nil cancelButtonTitle:OK_BUTTON_TITLE otherButtonTitles: nil] ;
            
            [alert show];
            //        [alert release];
        }
        
        [controller dismissViewControllerAnimated:YES completion:Nil];
    };
    
    controller.completionHandler =myBlock;
    
    //Adding the Text to the facebook post value from iOS
    [controller setInitialText:[NSString stringWithFormat:@"Check this Blabeey!! - %@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_Category]]];
    
    //Adding the URL to the facebook post value from iOS
    NSString *strEncryptText = [Validation getEncryptedShareUrlId:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:Index] valueForKey:NOTIF_ID]]];
    
    
    [controller addURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SHARE_URL,strEncryptText]]];
    
    //Adding the Image to the facebook post value from iOS
    NSData *imageData=[NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Icon114x114" ofType:@"png"]];
    
    UIImage *image = [UIImage imageWithData:imageData];
    if (image != nil) {
        [controller addImage:image];
    }
    
    [self presentViewController:controller animated:YES completion:Nil];
}

-(void)ShareThroughSMS:(id)sender{
	
	[self RemoveSocialViewFromSuperView];
	
    UIButton *btn = (UIButton *)sender;
    
	MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
	
	if([MFMessageComposeViewController canSendText])
	{
        [AlertHandler alertTitle:MESSAGE message:SMS_CHARGE_ALERT delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
        
        NSString *strEncryptText = [Validation getEncryptedShareUrlId:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:btn.tag] valueForKey:NOTIF_ID]]];
        
		NSString *strUrl = [NSString stringWithFormat:@"%@%@",SHARE_URL,strEncryptText];
        
        NSString *strTitle = [NSString stringWithFormat:@"%@ send you %@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_NAME],[[self.arrData objectAtIndex:btn.tag] valueForKey:NOTIF_Category]];
        
        
		NSString *strShareText = [NSString stringWithFormat:@"%@ - %@",strTitle,strUrl];
		
		controller.body = strShareText;
        
		controller.messageComposeDelegate = self;
        [self presentViewController:controller animated:YES completion:nil];
	}
	
    //	[controller release];
}

-(void)ShareThroughMail:(id)sender{
	
	[self RemoveSocialViewFromSuperView];
	UIButton *btn = (UIButton *)sender;
    
	MFMailComposeViewController *mailViewController = [[MFMailComposeViewController alloc] init] ;
	
	if (mailViewController != nil)
	{
		if ([MFMailComposeViewController canSendMail]) {
			
            NSString *strEncryptText = [Validation getEncryptedShareUrlId:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:btn.tag] valueForKey:NOTIF_ID]]];
            
            
			NSString *strUrl = [NSString stringWithFormat:@"%@%@",SHARE_URL,strEncryptText];
            
            NSString *strTitle = [NSString stringWithFormat:@"%@ send you %@",[[NSUserDefaults standardUserDefaults] valueForKey:LOGIN_USER_NAME],[[self.arrData objectAtIndex:btn.tag] valueForKey:NOTIF_Category]];
            
			mailViewController.mailComposeDelegate = self;
			[mailViewController setSubject:@"Blabeey"];
			NSString *bodyText =@"<html>";
			bodyText = [bodyText stringByAppendingString:@"<head>"];
			bodyText = [bodyText stringByAppendingString:@"</head>"];
			bodyText = [bodyText stringByAppendingString:@"<body>"];
			bodyText = [bodyText stringByAppendingFormat:@"%@ <a href=\"%@\">%@",strTitle,strUrl,strUrl];
			bodyText = [bodyText stringByAppendingString:@"</a>"];
			
			[mailViewController setMessageBody:bodyText isHTML:YES];
            
            [self presentViewController:mailViewController animated:YES completion:nil];
		}
		else
		{
			[self launchMailAppOnDevice];
		}
	}
	else
	{
		[self launchMailAppOnDevice];
	}
    //	[mailViewController release];
}

#pragma mark
#pragma MFMessageComposeViewController
#pragma mark

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [self dismissViewControllerAnimated:YES completion:nil];
	
	if (result == MessageComposeResultCancelled){
        [AlertHandler alertTitle:CANCELLED message:MESSAGE_CANCELLED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else if (result == MessageComposeResultSent){
        [AlertHandler alertTitle:SUCCESS message:MESSAGE_SENT delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else{
        [AlertHandler alertTitle:FAILURE message:MESSAGE_FAILED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
}

#pragma mark
#pragma MFMailComposeViewController
#pragma mark

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error{
	
    [self dismissViewControllerAnimated:YES completion:nil];
	
	if (result == MFMailComposeResultCancelled){
        [AlertHandler alertTitle:CANCELLED message:MAIL_SENDING_CANCELLED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else if (result == MFMailComposeResultSent){
        [AlertHandler alertTitle:SUCCESS message:MAIL_SEND delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else if (result == MFMailComposeResultFailed){
        [AlertHandler alertTitle:FAILURE message:MAIL_SENDING_FAILED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
	else if(result == MFMailComposeResultSaved){
        [AlertHandler alertTitle:SUCCESS message:MAIL_SAVED delegate:nil tag:0 cancelButtonTitle:nil OKButtonTitle:OK_BUTTON_TITLE otherButtonTitle:nil];
	}
}

-(void)launchMailAppOnDevice
{
    NSString *strEncryptText = [Validation getEncryptedShareUrlId:[NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:NOTIF_ID]]];
    
    
	NSString *strUrl = [NSString stringWithFormat:@"%@%@",SHARE_URL,strEncryptText];
    
    NSString *strTitle = [NSString stringWithFormat:@"%@",[[self.arrData objectAtIndex:self.selectedIndex] valueForKey:NOTIF_Category]];
    
    NSString *strShareText = [NSString stringWithFormat:@"%@ - %@",strTitle,strUrl];
    
	NSString *bodyText =@"<html>";
	bodyText = [bodyText stringByAppendingString:@"<head>"];
	bodyText = [bodyText stringByAppendingString:@"</head>"];
	bodyText = [bodyText stringByAppendingString:@"<body>"];
	bodyText = [bodyText stringByAppendingFormat:@"<a href=\"%@\">%@",strUrl,strShareText];
	bodyText = [bodyText stringByAppendingString:@"</a>"];
	
	NSString *recipients = [NSString stringWithFormat:@"mailto:?cc=&subject=%@",@"Songstagram"];
	NSString *body = [NSString stringWithFormat:@"&body=%@",bodyText];
	
	NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
	email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}

*/
