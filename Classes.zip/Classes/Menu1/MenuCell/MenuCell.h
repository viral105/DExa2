//
//  MenuCell.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 01/10/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuCell : UITableViewCell

@property (nonatomic, retain) IBOutlet UIView           *viewBG;
@property (nonatomic, retain) IBOutlet UIImageView      *imgIcon;
@property (nonatomic, retain) IBOutlet UILabel          *lblMenuName;
@property (nonatomic, retain) IBOutlet UILabel          *lblSeparator;
@property (nonatomic, retain) IBOutlet UILabel          *lblRequestCountLabel;
@end
