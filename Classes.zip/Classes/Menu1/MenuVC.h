//
//  MenuVC.h
//  WWHHAAZZAAPP
//
//  Created by shreya on 30/09/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MenuVCDelegate;

@protocol MenuVCDelegate <NSObject>
- (void)SetVc;
- (void)hideVC;

@end


@interface MenuVC : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, retain) IBOutlet UITableView *tblMenu;

@property (nonatomic, strong) NSString *strSelectedIndex;

@property (nonatomic, retain) IBOutlet UIButton          *btnMenu;

@property (nonatomic ,assign) id <MenuVCDelegate>       delegate;

@property (nonatomic, strong) ASIFormDataRequest		*request;

@property (nonatomic, readwrite) BOOL                   isVisible;

@property (nonatomic, assign) int                   indexShowFriendReq;


-(void)get_NptofCount;
@end
