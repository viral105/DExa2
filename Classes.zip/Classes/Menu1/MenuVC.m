//
//  MenuVC.m
//  WWHHAAZZAAPP
//
//  Created by shreya on 30/09/14.
//  Copyright (c) 2014 s. All rights reserved.
//

#import "MenuVC.h"
#import "MenuCell.h"
#import "SWRevealViewController.h"
#import "AddFriendsVC.h"

#define CellHeight         95
#define TotalNumberOfRows   9

@interface MenuVC ()

@end

@implementation MenuVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    //bhavik 13-Feb-2015
    self.parentViewController.automaticallyAdjustsScrollViewInsets = NO;
    
    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationFade];
    
 //   [self performSelectorInBackground:@selector(get_NptofCount) withObject:nil];
    self.isVisible = YES;
    
    NSLog(@"appDelegate.selectedMenuIndex = %d",appDelegate.selectedMenuIndex);
    //self.navigationController.navigationBar.frame = CGRectOffset(self.navigationController.navigationBar.frame, 0.0, -20.0);

    
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.isVisible = NO;
    [self.request clearDelegatesAndCancel];
    appDelegate.isShouldShowReplyPopUp = NO;
    //bhavik 13-Feb-2015
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationFade];
}
-(void) didTapOnTableView:(id) sender {
/*    CGPoint tapLocation = [recognizer locationInView:self.tblMenu];
    NSIndexPath *indexPath = [self.tblMenu indexPathForRowAtPoint:tapLocation];
    
    if (indexPath) { //we are in a tableview cell, let the gesture be handled by the view
        recognizer.cancelsTouchesInView = NO;
    } else { // anywhere else, do what is needed for your case
        [self.navigationController popViewControllerAnimated:YES];
    }
*/
    NSLog(@"did tap on table view");
    self.strSelectedIndex = @"2";
    self.indexShowFriendReq = 0;
    appDelegate.selectedMenuIndex = [self.strSelectedIndex intValue];
    
    [self performSegueWithIdentifier:ADD_FRIENDS_VC sender:nil];
}
-(IBAction)btnMenuClicked:(id)sender{
    //[self RemoveSelfFromParentVC];
    [self.revealViewController revealToggle:self];
}

#pragma mark Methods

-(void)get_NptofCount{

	NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:W_ID]],KeyValue,@"UserID",KeyName, nil],@"1",
						 nil];
	
	NSString *strUrl = [WebServiceContainer getServiceURL:GET_REQUEST_COUNT withParameters:nil];
	
	self.request = [WebServiceContainer CallWebserviceWithPost:dic forURL:strUrl isAddHeader:TRUE];
	self.request.delegate = self;
	self.request.tag = 1;
	strUrl = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark  UITableViewDelegate

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return CellHeight;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	//return self.arrData.count;
	return TotalNumberOfRows;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
	MenuCell *cell = (MenuCell*)[tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    [cell clearsContextBeforeDrawing];
    
    cell.viewBG.backgroundColor = [UIColor clearColor];
    
    cell.lblMenuName.font = [UIFont fontWithName:Font_Montserrat_Regular size:16];
        switch (indexPath.row) {
            case 0:{
                //cell.textLabel.text = @"Home";
                cell.lblSeparator.backgroundColor = UIColorFromRGB(0X43a047);
                if (appDelegate.selectedMenuIndex == indexPath.row) {
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Home_Selected];
                    cell.viewBG.backgroundColor = UIColorFromRGB(0X43a047);
                    cell.lblMenuName.textColor = [UIColor whiteColor];
                }
                else{
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Home];
                    [cell.lblMenuName setTextColor:UIColorFromRGB(0X43a047)];
                }
                
                cell.lblRequestCountLabel.hidden = TRUE;
                if ([[Validation.dicNotifCount valueForKey:TOTAL_UNREAD_NOTIF] intValue] >0) {
                    
                    cell.lblRequestCountLabel.backgroundColor = UIColorFromRGB(0Xfcc848);
                    cell.lblRequestCountLabel.textColor = [UIColor whiteColor];
                    cell.lblRequestCountLabel.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
                    cell.lblRequestCountLabel.text = [NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_UNREAD_NOTIF]];
                    CGSize size = CGSizeMake(1000, 50);
                    CGRect text = [cell.lblRequestCountLabel.text boundingRectWithSize:size
                                                                               options:NSStringDrawingUsesLineFragmentOrigin
                                                                            attributes:@{NSFontAttributeName:cell.lblRequestCountLabel.font}
                                                                               context:nil];
                    
                    cell.lblRequestCountLabel.frame = CGRectMake(cell.lblRequestCountLabel.frame.origin.x, 10, text.size.width+17, text.size.width+17);
                    cell.lblRequestCountLabel.layer.borderColor = TWITTER_BLUE_COLOR.CGColor;
                    cell.lblRequestCountLabel.layer.borderWidth = 2;
                    cell.lblRequestCountLabel.clipsToBounds = YES;
                    cell.lblRequestCountLabel.textAlignment = NSTextAlignmentCenter;
                    cell.lblRequestCountLabel.layer.cornerRadius = (text.size.width+17)/2;
                    cell.lblRequestCountLabel.hidden = FALSE;
                    //   [cell.contentView addSubview:lblCount];
                }
                
                cell.lblMenuName.text = @"CONVOS";
            }
                break;
            
            case 1:{
             //cell.textLabel.text = @"Yapeey";
                cell.lblSeparator.backgroundColor = UIColorFromRGB(0X00c2d9);
                if (appDelegate.selectedMenuIndex == indexPath.row) {
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_FriendList_Selected];
                    cell.viewBG.backgroundColor = UIColorFromRGB(0X00c2d9);
                    cell.lblMenuName.textColor = [UIColor whiteColor];
                }
                else{
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_FriendList];
                    [cell.lblMenuName setTextColor:UIColorFromRGB(0X00c2d9)];
                }
                cell.lblMenuName.text = @"BLAB";
                cell.lblRequestCountLabel.hidden = YES;
            }
                break;
            case 2:{
                //   cell.textLabel.text = @"Request";
                cell.lblSeparator.backgroundColor = UIColorFromRGB(0Xff5252);
                if (appDelegate.selectedMenuIndex == indexPath.row) {
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Frnd_Request_selected];
                    cell.viewBG.backgroundColor = UIColorFromRGB(0Xff5252);
                    cell.lblMenuName.textColor = [UIColor whiteColor];
                }
                else{
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Frnd_Request];
                    [cell.lblMenuName setTextColor:UIColorFromRGB(0Xff5252)];
                }
                
                cell.lblRequestCountLabel.hidden = TRUE;
                if ([[Validation.dicNotifCount valueForKey:TOTAL_FRIENDS_REQUEST] intValue] >0) {
                    
                    cell.lblRequestCountLabel.backgroundColor = UIColorFromRGB(0Xfcc848);
                    cell.lblRequestCountLabel.textColor = [UIColor whiteColor];
                    cell.lblRequestCountLabel.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
                    cell.lblRequestCountLabel.text = [NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_FRIENDS_REQUEST]];
                    CGSize size = CGSizeMake(1000, 50);
                    CGRect text = [cell.lblRequestCountLabel.text boundingRectWithSize:size
                                                                               options:NSStringDrawingUsesLineFragmentOrigin
                                                                            attributes:@{NSFontAttributeName:cell.lblRequestCountLabel.font}
                                                                               context:nil];
                    
                    cell.lblRequestCountLabel.frame = CGRectMake(cell.lblRequestCountLabel.frame.origin.x, 10, text.size.width+17, text.size.width+17);
                    cell.lblRequestCountLabel.layer.borderColor = TWITTER_BLUE_COLOR.CGColor;
                    cell.lblRequestCountLabel.layer.borderWidth = 2;
                    cell.lblRequestCountLabel.clipsToBounds = YES;
                    cell.lblRequestCountLabel.textAlignment = NSTextAlignmentCenter;
                    cell.lblRequestCountLabel.layer.cornerRadius = (text.size.width+17)/2;
                    cell.lblRequestCountLabel.hidden = FALSE;
                    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
                    [btn setFrame:cell.lblRequestCountLabel.frame];
                    [btn addTarget:self action:@selector(didTapOnTableView:) forControlEvents:UIControlEventTouchUpInside];
//                    [btn setBackgroundColor:[UIColor blueColor]];
                    [cell.contentView addSubview:btn];
                    [cell.contentView bringSubviewToFront:btn];
                    
                    //   [cell.contentView addSubview:lblCount];
                }
                
                cell.lblMenuName.numberOfLines = 2;
                cell.lblMenuName.text = @"ADD FRIEND";
                
            }
                break;
            case 3:{
                //   cell.textLabel.text = @"Search";
                cell.lblSeparator.backgroundColor = UIColorFromRGB(0X00bfa5);
                if (appDelegate.selectedMenuIndex == indexPath.row) {
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Help_Selected];
                    cell.viewBG.backgroundColor = UIColorFromRGB(0X00bfa5);
                    cell.lblMenuName.textColor = [UIColor whiteColor];
                }
                else{
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Help];
                    [cell.lblMenuName setTextColor:UIColorFromRGB(0X00bfa5)];
                }
                cell.lblMenuName.text = @"Help";
                cell.lblRequestCountLabel.hidden = YES;
            }
                
                break;
            
            case 4:{
                //                cell.textLabel.text = @"Settings";
                cell.lblSeparator.backgroundColor = UIColorFromRGB(0X2196f3);
                if (appDelegate.selectedMenuIndex == indexPath.row) {
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_HBLAB_Selected];
                    cell.viewBG.backgroundColor = UIColorFromRGB(0X2196f3);
                    cell.lblMenuName.textColor = [UIColor whiteColor];
                }
                else{
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_HBLAB];
                    cell.viewBG.backgroundColor = [UIColor whiteColor];
                    [cell.lblMenuName setTextColor:UIColorFromRGB(0X2196f3)];
                }
                cell.lblRequestCountLabel.hidden = TRUE;
                if (appDelegate.isChannelStaticBadgeShow) {
                    
                    cell.lblRequestCountLabel.backgroundColor = UIColorFromRGB(0Xfcc848);
                    cell.lblRequestCountLabel.textColor = [UIColor whiteColor];
                    cell.lblRequestCountLabel.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
                    cell.lblRequestCountLabel.text = @"1";
                    CGSize size = CGSizeMake(1000, 50);
                    CGRect text = [cell.lblRequestCountLabel.text boundingRectWithSize:size
                                                                               options:NSStringDrawingUsesLineFragmentOrigin
                                                                            attributes:@{NSFontAttributeName:cell.lblRequestCountLabel.font}
                                                                               context:nil];
                    
                    cell.lblRequestCountLabel.frame = CGRectMake(cell.lblRequestCountLabel.frame.origin.x, 10, text.size.width+17, text.size.width+17);
                    cell.lblRequestCountLabel.layer.borderColor = TWITTER_BLUE_COLOR.CGColor;
                    cell.lblRequestCountLabel.layer.borderWidth = 2;
                    cell.lblRequestCountLabel.clipsToBounds = YES;
                    cell.lblRequestCountLabel.textAlignment = NSTextAlignmentCenter;
                    cell.lblRequestCountLabel.layer.cornerRadius = (text.size.width+17)/2;
                    cell.lblRequestCountLabel.hidden = FALSE;
                    
                    //   [cell.contentView addSubview:lblCount];
                }
                cell.lblMenuName.text = @"Channels";
            }
            
                break;
/*            case 5:{
                //cell.textLabel.text = @"Yapeey";
                cell.lblSeparator.backgroundColor = UIColorFromRGB(0Xec407a);
                if (appDelegate.selectedMenuIndex == indexPath.row) {
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Alarm_Selected];
                    cell.viewBG.backgroundColor = UIColorFromRGB(0Xec407a);
                    cell.lblMenuName.textColor = [UIColor whiteColor];
                }
                else{
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Alarm];
                    [cell.lblMenuName setTextColor:UIColorFromRGB(0Xec407a)];
                }
                NSLog(@"Validation.dicNotifCount---> %@",Validation.dicNotifCount);
                cell.lblRequestCountLabel.hidden = TRUE;
                if ([[Validation.dicNotifCount valueForKey:TOTAL_ALARM_REQUEST] intValue] >0) {
                    
                    cell.lblRequestCountLabel.backgroundColor = UIColorFromRGB(0Xfcc848);
                    cell.lblRequestCountLabel.textColor = [UIColor whiteColor];
                    cell.lblRequestCountLabel.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
                    cell.lblRequestCountLabel.text = [NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_ALARM_REQUEST]];
                    CGSize size = CGSizeMake(1000, 50);
                    CGRect text = [cell.lblRequestCountLabel.text boundingRectWithSize:size
                                                                               options:NSStringDrawingUsesLineFragmentOrigin
                                                                            attributes:@{NSFontAttributeName:cell.lblRequestCountLabel.font}
                                                                               context:nil];
                    
                    cell.lblRequestCountLabel.frame = CGRectMake(cell.lblRequestCountLabel.frame.origin.x, 10, text.size.width+17, text.size.width+17);
                    cell.lblRequestCountLabel.layer.borderColor = TWITTER_BLUE_COLOR.CGColor;
                    cell.lblRequestCountLabel.layer.borderWidth = 2;
                    cell.lblRequestCountLabel.clipsToBounds = YES;
                    cell.lblRequestCountLabel.textAlignment = NSTextAlignmentCenter;
                    cell.lblRequestCountLabel.layer.cornerRadius = (text.size.width+17)/2;
                    cell.lblRequestCountLabel.hidden = FALSE;
                    //   [cell.contentView addSubview:lblCount];
                }
                cell.lblMenuName.text = @"REMINDERS";
                
            }
                break;
*/
/*            case 5:{
                cell.lblSeparator.backgroundColor = UIColorFromRGB(0X00bfa5);
                if (appDelegate.selectedMenuIndex == indexPath.row) {
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_KeepNotif_Selected];
                    cell.viewBG.backgroundColor = UIColorFromRGB(0X00bfa5);
                    cell.lblMenuName.textColor = [UIColor whiteColor];
                }
                else{
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_KeepNotif];
                    [cell.lblMenuName setTextColor:UIColorFromRGB(0X00bfa5)];
                }
                
                cell.lblRequestCountLabel.hidden = TRUE;
                
                if ([[Validation.dicNotifCount valueForKey:TOTAL_KEEP_REQUEST] intValue] >0) {
                    
                    cell.lblRequestCountLabel.backgroundColor = UIColorFromRGB(0Xfcc848);
                    cell.lblRequestCountLabel.textColor = [UIColor whiteColor];
                    cell.lblRequestCountLabel.font = [UIFont fontWithName:Font_Montserrat_Regular size:12];
                    cell.lblRequestCountLabel.text = [NSString stringWithFormat:@"%@",[Validation.dicNotifCount valueForKey:TOTAL_KEEP_REQUEST]];
                    CGSize size = CGSizeMake(1000, 50);
                    CGRect text = [cell.lblRequestCountLabel.text boundingRectWithSize:size
                                                                               options:NSStringDrawingUsesLineFragmentOrigin
                                                                            attributes:@{NSFontAttributeName:cell.lblRequestCountLabel.font}
                                                                               context:nil];
                    
                    cell.lblRequestCountLabel.frame = CGRectMake(cell.lblRequestCountLabel.frame.origin.x, 10, text.size.width+17, text.size.width+17);
                    cell.lblRequestCountLabel.layer.borderColor = TWITTER_BLUE_COLOR.CGColor;
                    cell.lblRequestCountLabel.layer.borderWidth = 2;
                    cell.lblRequestCountLabel.clipsToBounds = YES;
                    cell.lblRequestCountLabel.textAlignment = NSTextAlignmentCenter;
                    cell.lblRequestCountLabel.layer.cornerRadius = (text.size.width+17)/2;
                    cell.lblRequestCountLabel.hidden = FALSE;
                    //   [cell.contentView addSubview:lblCount];
                }
                
                cell.lblMenuName.font = [UIFont fontWithName:Font_Montserrat_Regular size:15];

                cell.lblMenuName.text = @"NOTIFICATIONS";
            }
                break;
*/

            case 5:{
                //   cell.textLabel.text = @"Search";
                cell.lblSeparator.backgroundColor = UIColorFromRGB(0Xfbc02d);
                if (appDelegate.selectedMenuIndex == indexPath.row) {
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Search_Selected];
                    cell.viewBG.backgroundColor = UIColorFromRGB(0Xfbc02d);
                    cell.lblMenuName.textColor = [UIColor whiteColor];
                }
                else{
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Search];
                    [cell.lblMenuName setTextColor:UIColorFromRGB(0Xfbc02d)];
                }
                cell.lblMenuName.text = @"SEARCH";
                cell.lblRequestCountLabel.hidden = YES;
            }
                
                break;
            
            case 6:{
                cell.lblSeparator.backgroundColor = UIColorFromRGB(0X3f51b5);
                if (appDelegate.selectedMenuIndex == indexPath.row) {
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Store_Selected];
                    cell.viewBG.backgroundColor = UIColorFromRGB(0X3f51b5);
                    cell.lblMenuName.textColor = [UIColor whiteColor];
                }
                else{
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Store];
                    [cell.lblMenuName setTextColor:UIColorFromRGB(0X3f51b5)];
                }
                cell.lblMenuName.text = @"STORE";
                cell.lblRequestCountLabel.hidden = YES;
                
            }
                break;
            case 7:{
                // cell.textLabel.text = @"Favorites";
                cell.lblSeparator.backgroundColor = UIColorFromRGB(0Xd32f2f);
                if (appDelegate.selectedMenuIndex == indexPath.row) {
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Favorite_Selected];
                    cell.viewBG.backgroundColor = UIColorFromRGB(0Xd32f2f);
                    cell.lblMenuName.textColor = [UIColor whiteColor];
                }
                else{
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Favorite];
                    [cell.lblMenuName setTextColor:UIColorFromRGB(0Xd32f2f)];
                }
                cell.lblMenuName.text = @"FAVORITES";
                cell.lblRequestCountLabel.hidden = YES;
            }
                break;

            case 8:{
                //                cell.textLabel.text = @"Settings";
                cell.lblSeparator.backgroundColor = UIColorFromRGB(0X0e303c);
                if (appDelegate.selectedMenuIndex == indexPath.row) {
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Settings_Selected];
                    cell.viewBG.backgroundColor = UIColorFromRGB(0X0e303c);
                    cell.lblMenuName.textColor = [UIColor whiteColor];
                }
                else{
                    cell.imgIcon.image = [UIImage imageNamed:btnMenu_Settings];
                    [cell.lblMenuName setTextColor:UIColorFromRGB(0X0e303c)];
                }
                cell.lblMenuName.text = @"SETTINGS";
                cell.lblRequestCountLabel.hidden = YES;
            }
                break;
            
            default:
                break;
        }
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    switch (indexPath.row) {
        case 0:{
            self.strSelectedIndex = @"0";
            [self performSegueWithIdentifier:NOTIFICATION_VC sender:nil];
        }
            break;
        
        case 1:{
           self.strSelectedIndex = @"1";
            [self performSegueWithIdentifier:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC sender:nil];
        }
            break;
        case 2:{
            self.strSelectedIndex = @"2";
            self.indexShowFriendReq = 1;
            [self performSegueWithIdentifier:ADD_FRIENDS_VC sender:nil];
        }
            break;
        case 3:{
            self.strSelectedIndex = @"3";
            [self performSegueWithIdentifier:HELP_VIDEO_LIST_VC sender:nil];
        }
            break;
        case 4:{
            self.strSelectedIndex = @"4";
            appDelegate.isChannelStaticBadgeShow = NO;
            [self performSegueWithIdentifier:HASH_BLAB_VC sender:nil];
        }
            break;
/*        case 5:
            self.strSelectedIndex = @"5";
            [Validation CancelOnGoingRequests:self.request];
            appDelegate.isForwarded = NO;
            [self performSegueWithIdentifier:ALARM_MAIN_VC sender:nil];
            
            break;
*/
/*        case 5:
            self.strSelectedIndex = @"5";
            [self performSegueWithIdentifier:KEEP_REQUEST_LIST_VC sender:nil];
            break;
*/
        case 5:{
            self.strSelectedIndex = @"5";
            [self performSegueWithIdentifier:SEARCH_NEW_FRIEND_FROM_WHAZUP_VC sender:nil];
        }
            break;
        case 6:
            self.strSelectedIndex = @"6";
            [self performSegueWithIdentifier:SELECT_STORE_VC sender:nil];
            break;
        case 7:
            self.strSelectedIndex = @"7";
            [self performSegueWithIdentifier:FAVORITES_LIST_VC sender:nil];
            break;
        case 8:
            self.strSelectedIndex = @"8";
            [self performSegueWithIdentifier:SETTINGS_VC sender:nil];
            break;
        
        default:
            break;
    }
    
    //currently there is no menu applied so first row will be selected in all cases
    //appDelegate.selectedMenuIndex = (int)indexPath.row;
    appDelegate.selectedMenuIndex = [self.strSelectedIndex intValue];
    
   // [self.delegate SetVc];
   // [self RemoveSelfFromParentVC];
}

-(void)RemoveSelfFromParentVC{
    
    [UIView beginAnimations:@"showMenu" context:NULL];
    [UIView setAnimationDuration:0.2];
    self.tblMenu.frame = CGRectMake(-140, 0, 120, self.view.frame.size.height);
    self.btnMenu.frame = CGRectMake(-20, self.btnMenu.frame.origin.y, self.btnMenu.frame.size.width, self.btnMenu.frame.size.height);
    [UIView commitAnimations];
    
    [self performSelector:@selector(callParentDelegateMethod) withObject:nil afterDelay:0.25];
}

-(void)callParentDelegateMethod{
    [self.delegate SetVc];
}

- (void) prepareForSegue: (UIStoryboardSegue *) segue sender: (id) sender
{
    if ([segue.identifier isEqualToString:NOTIFICATION_VC]) {
     
    }
	else if ([segue.identifier isEqualToString:ADD_FRIEND_FROM_EXISTING_FRNDLIST_VC]) {
		
    }
	else if ([segue.identifier isEqualToString:SEARCH_CONTAINER_VC]){
		
	}
	else if ([segue.identifier isEqualToString:OTHER_FRNDREQ_NOTIF_LIST_VC]){
		
	}
	else if ([segue.identifier isEqualToString:USER_LOCATION_VC]){
		
	}
	else if ([segue.identifier isEqualToString:SETTINGS_VC]){
		
	}
    else if ([segue.identifier isEqualToString:ADD_FRIENDS_VC]){
        AddFriendsVC *obj = [segue destinationViewController];
        obj.index = 0;
        obj.indexShowFriendReq = self.indexShowFriendReq;
    }
		
    if ( [segue isKindOfClass: [SWRevealViewControllerSegue class]] ) {
        SWRevealViewControllerSegue *swSegue = (SWRevealViewControllerSegue*) segue;
        
        swSegue.performBlock = ^(SWRevealViewControllerSegue* rvc_segue, UIViewController* svc, UIViewController* dvc) {
            
            UINavigationController* navController = (UINavigationController*)self.revealViewController.frontViewController;
            [navController setViewControllers:@[dvc] animated: NO ];
            [self.revealViewController setFrontViewPosition:FrontViewPositionLeft animated: NO];
        };
    }
}


#pragma marl        WEBSERVICE RESPONSE

#pragma mark
#pragma mark web service method

- (void)requestFinished:(ASIHTTPRequest *)request{
	NSError *error = nil;
	
    NSLog(@"notification Response");
	
	NSDictionary *dicResponse  = [NSJSONSerialization JSONObjectWithData:[request responseData]
																 options:0
																   error:&error];;
	
     NSLog(@"dic = %@",dicResponse);
    if (dicResponse != nil) {
        if (![[NSString stringWithFormat:@"%@",[[dicResponse valueForKey:USER_STATUS] valueForKey:IS_ACTIVE]] boolValue]) {
            NSLog(@"dic = %@",dicResponse);
        //    [HUD hide:YES];
            [appDelegate callLogOutService];
        }
        else{
            if (request.tag == 1) {
                if ([dicResponse objectForKey:RESPONSE] != nil) {
                    
                    if ([[dicResponse valueForKey:STATUS] intValue] != 0) {
                        
                        //received
                        id response = [dicResponse objectForKey:RESPONSE];
                        if (response != nil) {
                            NSLog(@"rezponse = %@",[response objectAtIndex:0]);
                            NSString *strFR = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_FRIENDS_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strNotif = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_UNREAD_NOTIF]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strKeepReq = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_KEEP_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strTotalCount = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_NOTIF_COUNT]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            NSString *strARCount = [[NSString stringWithFormat:@"%@",[[response objectAtIndex:0] valueForKey:TOTAL_ALARM_REQUEST]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                            
                            Validation.dicNotifCount = [NSDictionary
                                                        dictionaryWithObjectsAndKeys:
                                                        strFR,TOTAL_FRIENDS_REQUEST,
                                                        strNotif,TOTAL_UNREAD_NOTIF,
                                                        strKeepReq,TOTAL_KEEP_REQUEST,
                                                        strTotalCount, TOTAL_NOTIF_COUNT,
                                                        strARCount,TOTAL_ALARM_REQUEST,
                                                        nil];
                            
                            strFR = nil;
                            strNotif = nil;
                            
                            if (self.isVisible) {
                                [self.tblMenu reloadData];
//                                NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:2 inSection:0]];
//                                [self.tblMenu beginUpdates];
//                                [self.tblMenu reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
//                                [self.tblMenu endUpdates];
                            }
                        }
                        
                    }
                    else{
                   
                        Validation.dicNotifCount = [NSDictionary
                                                    dictionaryWithObjectsAndKeys:
                                                    @"",TOTAL_FRIENDS_REQUEST,
                                                    @"",TOTAL_UNREAD_NOTIF,
                                                    @"",TOTAL_KEEP_REQUEST,
                                                    @"",TOTAL_NOTIF_COUNT,
                                                    @"",TOTAL_ALARM_REQUEST,
                                                    nil];
                        
                        if (self.isVisible) {
                            [self.tblMenu reloadData];
//                            NSArray *indexPathArray = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:2 inSection:0]];
//                            [self.tblMenu beginUpdates];
//                            [self.tblMenu reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
//                            [self.tblMenu endUpdates];
                        }
                        
                    }
                }
            }
        }
    }
    
    request = nil;
    self.request = nil;
	dicResponse = nil;
	
}
- (void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"requestFailed");
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
