//
//  WebServices.swift
//  demo7
//
//  Created by Viral Narshana on 9/12/16.
//  Copyright © 2016 ISM. All rights reserved.
//

import Foundation
import Alamofire
class WebServices {

    class func getOrders(serviceName: String, params:NSDictionary, completionHandler: (NSDictionary?, NSError?) -> ()) {
        makeCall(serviceName, params: params, completionHandler: completionHandler)
    }
    
    class func makeCall(section: String, params:NSDictionary, completionHandler: (NSDictionary?, NSError?) -> ()) {
        
        Alamofire.request(.POST, "\(Base_URL)\(section)", parameters: params as? [String : AnyObject])
            .responseJSON { response in
                switch response.result {
                case .Success(let value):
                    completionHandler(value as? NSDictionary, nil)
                case .Failure(let error):
                    completionHandler(nil, error)
                }
        }
        
    }
}
