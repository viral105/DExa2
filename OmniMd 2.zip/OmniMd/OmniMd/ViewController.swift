//
//  ViewController.swift
//  OmniMd
//
//  Created by Viral Narshana on 11/7/16.
//  Copyright © 2016 ISM. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    @IBOutlet var txtView: UITextView!
    var request: Alamofire.Request?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.callfunc()
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func syncDataTap() {
        //        let loadingNotification = MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        //        loadingNotification.mode = MBProgressHUDMode.Indeterminate
        //loadingNotification.customView = blackSquare
        //        loadingNotification.label.text = "Loading"
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) {
            let loginInfo : Dictionary<String,AnyObject> = ["DeviceID": "F3559779-CDC8-461B-8C17-7AB51B790ADE","UserID": "6c431d0010ac45399b0b5ca8f4af928e","CampignCompanyID": "1","Timestamp": "0"]
            print("\(NSDate()) start req");
            WebServices.getOrders("SyncData", params: loginInfo){ responseObject, error in
                // use responseObject and error here
                //                MBProgressHUD.hideHUDForView(self.view, animated: true)
                print("\(NSDate()) responseObject syncdata = \(responseObject); error = \(error)")
                self.txtView.text = NSString(format: "%@",responseObject!) as String
                return
            }
        }
    }
    
    func callfunc(){
        var dic = NSMutableDictionary()
        print("\(NSDate()) + start req")
        self.request = Alamofire.request(
            .POST,
            "http://api.omnisaleshub.com/api/SyncData",
            parameters: ["DeviceID": "F3559779-CDC8-461B-8C17-7AB51B790ADE","UserID": "6c431d0010ac45399b0b5ca8f4af928e","CampignCompanyID": "1","Timestamp": "0"],
            encoding: .URL)
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else {
                    print("Error while fetching remote rooms: \(response.result.error)")
                    //                    completion(nil)
                    return
                }
                
                
                print("get data")
                dic = response.result.value as! NSMutableDictionary
                
                print("\(NSDate()) + \(dic.objectForKey("Campaigns")?.objectAtIndex(0).objectForKey("Assets")?.objectAtIndex(0))")
                self.txtView.text = NSString(format: "%@",dic) as String
                
                
        }
        print("return data")
        
    }

    @IBAction func btnCancel_Clicked(){
        self.request?.cancel()
    }
}

