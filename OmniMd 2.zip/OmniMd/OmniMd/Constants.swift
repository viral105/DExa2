//
//  Constants.swift
//  demo7
//
//  Created by Viral Narshana on 9/1/16.
//  Copyright © 2016 ISM. All rights reserved.
//

import Foundation
import UIKit

let uuid = NSUUID().UUIDString
let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate



#if RELEASE_VERSION
let SERVER_URL = "https://production-server/"
let SERVER_URL1 = "https://production-server1/"
#else
let SERVER_URL = "https://staging-server/"
let SERVER_URL1 = "https://staging-server1/"
#endif

let Base_URL = "http://api.omnisaleshub.com/api/"
        