//
//  ViewController.h
//  YoutubeUploaded
//
//  Created by Viral Narshana on 6/7/16.
//  Copyright © 2016 Viral Narshana. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <YouToobAPI/YouToobAPI.h>

@interface ViewController : UIViewController<YouTubeHelperDelegate>

@property (nonatomic, strong) YouTubeHelper * youtubeHelper;
@end

