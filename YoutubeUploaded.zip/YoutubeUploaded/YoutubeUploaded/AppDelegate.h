//
//  AppDelegate.h
//  YoutubeUploaded
//
//  Created by Viral Narshana on 6/7/16.
//  Copyright © 2016 Viral Narshana. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

