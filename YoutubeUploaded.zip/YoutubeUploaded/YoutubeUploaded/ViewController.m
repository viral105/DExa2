//
//  ViewController.m
//  YoutubeUploaded
//
//  Created by Viral Narshana on 6/7/16.
//  Copyright © 2016 Viral Narshana. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.youtubeHelper = [[YouTubeHelper alloc] initWithDelegate:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSString *)youtubeAPIClientID {
    return @"YOUR_CLIENT_ID";
}

- (NSString *)youtubeAPIClientSecret {
    return @"YOUR_CLIENT_SECRET";
}

- (void)showAuthenticationViewController:(UIViewController *)authView {
    [self.navigationController presentViewController:authView animated:NO completion:nil];
}

- (void)authenticationEndedWithError:(NSError *)error {
    if (error) {
        NSLog(@"Auth failed with error: %@", error.description);
    }
}
-(IBAction)btnAuth_Clicked:(id)sender{
    [self.youtubeHelper authenticate];
}
@end
